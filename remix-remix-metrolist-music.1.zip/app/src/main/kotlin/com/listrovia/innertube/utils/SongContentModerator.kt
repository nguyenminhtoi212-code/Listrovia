package com.listrovia.innertube.utils

import timber.log.Timber

/**
 * Song Content Moderation Engine that screens songs and recommendations,
 * blocking inappropriate/prohibited content from search and suggestions.
 * (Hệ thống kiểm duyệt bài hát ngăn chặn nội dung không phù hợp trong tìm kiếm và đề xuất).
 */
object SongContentModerator {
    private val blockedKeywords = listOf(
        "prohibited_explicit_test",
        "nsfw_sample",
        "restricted_content_flag"
    )

    fun isAllowed(title: String, artistName: String? = null): Boolean {
        val combined = "$title ${artistName.orEmpty()}".lowercase()
        for (keyword in blockedKeywords) {
            if (combined.contains(keyword)) {
                Timber.tag("SongModerator").w("Content blocked by moderation filter: matched keyword '$keyword'")
                return false
            }
        }
        return true
    }
}
