package com.listrovia.music.theme

import androidx.compose.ui.graphics.Color
import java.util.Calendar

data class HolidayThemeInfo(
    val isHoliday: Boolean,
    val holidayNameEn: String = "",
    val holidayNameVi: String = "",
    val themeColor: Color = Color(0xFF6750A4),
    val secondaryColor: Color = Color(0xFFFFD700),
    val descriptionEn: String = "",
    val descriptionVi: String = "",
) {
    val holidayName: String
        get() = if (java.util.Locale.getDefault().language == "vi") {
            holidayNameVi.ifEmpty { holidayNameEn }
        } else {
            holidayNameEn.ifEmpty { holidayNameVi }
        }
}

object HolidayThemeManager {

    fun getActiveHoliday(
        countryCode: String,
        calendar: Calendar = Calendar.getInstance()
    ): HolidayThemeInfo {
        val solarDay = calendar.get(Calendar.DAY_OF_MONTH)
        val solarMonth = calendar.get(Calendar.MONTH) + 1 // 1..12
        val lunar = LunarCalendarUtil.getLunarDate(calendar)

        val country = countryCode.uppercase()

        // 1. VIETNAM (VN) HOLIDAYS - Strict Lunar & Solar Checks
        if (country == "VN" || country == "VIETNAM" || country == "SYSTEM_DEFAULT" || country.isEmpty()) {
            // Tết Nguyên Đán (Lunar 12/28 - 01/06)
            if ((lunar.month == 12 && lunar.day >= 28) || (lunar.month == 1 && lunar.day <= 6)) {
                return HolidayThemeInfo(
                    isHoliday = true,
                    holidayNameEn = "Tet Lunar New Year",
                    holidayNameVi = "Tết Nguyên Đán",
                    themeColor = Color(0xFFD32F2F), // Festive Red
                    secondaryColor = Color(0xFFFFD54F), // Gold
                    descriptionEn = "Happy Lunar New Year! Festive crimson red & gold theme.",
                    descriptionVi = "Mừng Xuân Mới! Giao diện Tết màu Đỏ & Vàng Kim rực rỡ."
                )
            }

            // Tết Nguyên Tiêu (Lunar 01/14 - 01/16)
            if (lunar.month == 1 && lunar.day in 14..16) {
                return HolidayThemeInfo(
                    isHoliday = true,
                    holidayNameEn = "First Full Moon Festival (Rằm tháng Giêng)",
                    holidayNameVi = "Tết Nguyên Tiêu (Rằm tháng Giêng)",
                    themeColor = Color(0xFF7B1FA2), // Lantern Purple
                    secondaryColor = Color(0xFFFFB300),
                    descriptionEn = "Rằm tháng Giêng - First Full Moon lantern festival theme.",
                    descriptionVi = "Rằm tháng Giêng - Giao diện Đèn lồng Tím & Hổ Phách."
                )
            }

            // Giỗ Tổ Hùng Vương (Lunar 03/09 - 03/11)
            if (lunar.month == 3 && lunar.day in 9..11) {
                return HolidayThemeInfo(
                    isHoliday = true,
                    holidayNameEn = "Hung Kings Commemoration Day",
                    holidayNameVi = "Giỗ Tổ Hùng Vương (10/3 âm lịch)",
                    themeColor = Color(0xFFB71C1C), // Imperial Crimson
                    secondaryColor = Color(0xFFFF8F00),
                    descriptionEn = "Hung Kings Commemoration Day - Ancient royal bronze & crimson theme.",
                    descriptionVi = "Giỗ Tổ Hùng Vương - Giao diện Đỏ Đồng Hoàng Gia."
                )
            }

            // Tết Đoan Ngọ (Lunar 05/04 - 05/06)
            if (lunar.month == 5 && lunar.day in 4..6) {
                return HolidayThemeInfo(
                    isHoliday = true,
                    holidayNameEn = "Dragon Boat Festival (Tết Đoan Ngọ)",
                    holidayNameVi = "Tết Đoan Ngọ (5/5 âm lịch)",
                    themeColor = Color(0xFF2E7D32), // Herbal Green
                    secondaryColor = Color(0xFFFFC107),
                    descriptionEn = "Mid-year Dragon Boat festival herbal green theme.",
                    descriptionVi = "Tết Đoan Ngọ - Giao diện xanh lá thảo mộc tươi mát."
                )
            }

            // Tết Trung Thu (Lunar 08/14 - 08/16)
            if (lunar.month == 8 && lunar.day in 14..16) {
                return HolidayThemeInfo(
                    isHoliday = true,
                    holidayNameEn = "Mid-Autumn Lantern Moon Festival",
                    holidayNameVi = "Tết Trung Thu (Rằm tháng Tám)",
                    themeColor = Color(0xFFFF8F00), // Lantern Gold
                    secondaryColor = Color(0xFFE65100),
                    descriptionEn = "Mid-Autumn Lantern Moon festival warm amber gold theme.",
                    descriptionVi = "Tết Trung Thu - Giao diện Đèn lồng Vàng Ấm áp."
                )
            }

            // Ngày Lễ 30/4 & 1/5 (Solar 04/29 - 05/02)
            if ((solarMonth == 4 && solarDay >= 29) || (solarMonth == 5 && solarDay <= 2)) {
                return HolidayThemeInfo(
                    isHoliday = true,
                    holidayNameEn = "Reunification & Labor Day",
                    holidayNameVi = "Lễ 30/4 - 1/5",
                    themeColor = Color(0xFFC62828), // Victory Red
                    secondaryColor = Color(0xFFFFEB3B),
                    descriptionEn = "Vietnam Reunification & International Labor Day celebration.",
                    descriptionVi = "Chào mừng Lễ Giải Phóng 30/4 & Quốc Tế Lao Động 1/5."
                )
            }

            // Quốc Khánh Việt Nam 2/9 (Solar 09/01 - 09/03)
            if (solarMonth == 9 && solarDay in 1..3) {
                return HolidayThemeInfo(
                    isHoliday = true,
                    holidayNameEn = "Vietnam National Day 2/9",
                    holidayNameVi = "Quốc Khánh Việt Nam 2/9",
                    themeColor = Color(0xFFD32F2F), // Flag Red
                    secondaryColor = Color(0xFFFFD54F),
                    descriptionEn = "Vietnam Independence National Day red & gold theme.",
                    descriptionVi = "Chào mừng Ngày Quốc Khánh Việt Nam 2/9 Cờ Đỏ Sao Vàng!"
                )
            }

            // Ngày Phụ Nữ Việt Nam 20/10 (Solar 10/19 - 10/21)
            if (solarMonth == 10 && solarDay in 19..21) {
                return HolidayThemeInfo(
                    isHoliday = true,
                    holidayNameEn = "Vietnamese Women's Day 20/10",
                    holidayNameVi = "Ngày Phụ Nữ Việt Nam 20/10",
                    themeColor = Color(0xFFE91E63), // Rose Pink
                    secondaryColor = Color(0xFFF48FB1),
                    descriptionEn = "Vietnamese Women's Day elegant rose pink theme.",
                    descriptionVi = "Tôn vinh Ngày Phụ Nữ Việt Nam 20/10 với màu Hồng Hoa Hồng tươi thắm."
                )
            }
        }

        // 2. INTERNATIONAL / REGIONAL HOLIDAYS
        // Christmas Season (Solar 12/20 - 12/26)
        if (solarMonth == 12 && solarDay in 20..26) {
            return HolidayThemeInfo(
                isHoliday = true,
                holidayNameEn = "Christmas Season",
                holidayNameVi = "Lễ Giáng Sinh (Christmas)",
                themeColor = Color(0xFF1B5E20), // Pine Green
                secondaryColor = Color(0xFFC62828), // Crimson Red
                descriptionEn = "Merry Christmas! Festive Pine Green & Santa Red theme.",
                descriptionVi = "Giáng Sinh An Lành! Giao diện Thông Xanh & Đỏ Giáng Sinh."
            )
        }

        // New Year (Solar 12/31 - 01/02)
        if ((solarMonth == 12 && solarDay == 31) || (solarMonth == 1 && solarDay <= 2)) {
            return HolidayThemeInfo(
                isHoliday = true,
                holidayNameEn = "New Year Celebration",
                holidayNameVi = "Tết Dương Lịch (New Year)",
                themeColor = Color(0xFF6A1B9A), // Royal Purple
                secondaryColor = Color(0xFFFFD700),
                descriptionEn = "Happy New Year! Royal purple & gold party theme.",
                descriptionVi = "Mừng Năm Mới! Giao diện Tím Hoàng Gia & Vàng Kim Rực Rỡ."
            )
        }

        // Halloween (Solar 10/28 - 11/01)
        if ((solarMonth == 10 && solarDay >= 28) || (solarMonth == 11 && solarDay == 1)) {
            return HolidayThemeInfo(
                isHoliday = true,
                holidayNameEn = "Halloween Spooky Season",
                holidayNameVi = "Lễ Hội Halloween",
                themeColor = Color(0xFFE65100), // Pumpkin Orange
                secondaryColor = Color(0xFF424242),
                descriptionEn = "Spooky Halloween pumpkin orange & dark theme.",
                descriptionVi = "Lễ Hội Halloween - Giao diện Cam Bí Ngô & Đêm Ma Mị."
            )
        }

        // Valentine's Day (Solar 02/13 - 02/15)
        if (solarMonth == 2 && solarDay in 13..15) {
            return HolidayThemeInfo(
                isHoliday = true,
                holidayNameEn = "Valentine's Day",
                holidayNameVi = "Lễ Tình Nhân (Valentine)",
                themeColor = Color(0xFFD81B60), // Ruby Red
                secondaryColor = Color(0xFFF48FB1),
                descriptionEn = "Happy Valentine's Day! Sweet romantic ruby red theme.",
                descriptionVi = "Lễ Tình Nhân Valentine - Giao diện Đỏ Hồng Ngọt Ngào Lãng Mạn."
            )
        }

        // Japanese Sakura / Golden Week (JP)
        if ((country == "JP" || country == "JAPAN") && ((solarMonth == 4 && solarDay >= 28) || (solarMonth == 5 && solarDay <= 6))) {
            return HolidayThemeInfo(
                isHoliday = true,
                holidayNameEn = "Japan Golden Week & Cherry Blossom",
                holidayNameVi = "Tuần Lễ Vàng & Hoa Anh Đào Nhật Bản",
                themeColor = Color(0xFFF06292), // Sakura Pink
                secondaryColor = Color(0xFFF8BBD0),
                descriptionEn = "Japanese Sakura & Golden Week pink theme.",
                descriptionVi = "Tuần Lễ Vàng Nhật Bản - Giao diện Sakura Hồng Tươi Mát."
            )
        }

        // If today is NOT a holiday, strictly return isHoliday = false!
        return HolidayThemeInfo(isHoliday = false)
    }
}
