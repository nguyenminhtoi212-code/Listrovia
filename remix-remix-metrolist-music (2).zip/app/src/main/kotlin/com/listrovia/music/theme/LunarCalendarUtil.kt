package com.listrovia.music.theme

import java.util.Calendar

data class LunarDate(
    val day: Int,
    val month: Int,
    val year: Int,
    val isLeap: Boolean = false
)

/**
 * Astronomical Lunar Calendar Utility for Vietnam (UTC+7) & East Asia
 * Based on Dr. Ho Ngoc Duc's astronomical conversion algorithm.
 */
object LunarCalendarUtil {

    private fun jdFromDate(dd: Int, mm: Int, yy: Int): Int {
        val a = (14 - mm) / 12
        val y = yy + 4800 - a
        val m = mm + 12 * a - 3
        return dd + (153 * m + 2) / 5 + 365 * y + y / 4 - y / 100 + y / 400 - 32045
    }

    private fun getNewMoonDay(k: Int, timeZone: Double = 7.0): Int {
        val t = k / 1236.85
        val t2 = t * t
        val t3 = t2 * t
        val dr = Math.PI / 180.0
        var jd1 = 2415020.75933 + 29.53058868 * k + 0.0001178 * t2 - 0.000000155 * t3
        jd1 += 0.00033 * Math.sin((166.56 + 132.87 * t - 0.009173 * t2) * dr)

        val m = 359.2242 + 29.10535608 * k - 0.0000333 * t2 - 0.00000347 * t3
        val mpr = 306.0253 + 385.81691806 * k + 0.0107306 * t2 + 0.00001236 * t3
        val f = 21.2964 + 390.67050646 * k - 0.0016528 * t2 - 0.00000239 * t3

        var c = (0.1734 - 0.000393 * t) * Math.sin(m * dr) + 0.0021 * Math.sin(2 * m * dr)
        c -= 0.4068 * Math.sin(mpr * dr) - 0.0161 * Math.sin(2 * mpr * dr)
        c += 0.0104 * Math.sin(2 * f * dr)
        c -= 0.0051 * Math.sin((m + mpr) * dr)
        c -= 0.0074 * Math.sin((m - mpr) * dr)
        c += 0.0004 * Math.sin((2 * f + m) * dr)
        c -= 0.0004 * Math.sin((2 * f - m) * dr)
        c -= 0.0006 * Math.sin((2 * f + mpr) * dr)
        c += 0.0010 * Math.sin((2 * f - mpr) * dr)
        c += 0.0005 * Math.sin((m + 2 * mpr) * dr)

        val jdNew = jd1 + c
        return Math.floor(jdNew + 0.5 + timeZone / 24.0).toInt()
    }

    private fun getSunLongitude(dayNumber: Int, timeZone: Double = 7.0): Double {
        val t = (dayNumber - 2451545.5 - timeZone / 24.0) / 36525.0
        val t2 = t * t
        val dr = Math.PI / 180.0
        val m = 357.52910 + 35999.05030 * t - 0.0001559 * t2 - 0.00000048 * t * t2
        val l0 = 280.46645 + 36000.76983 * t + 0.0003032 * t2
        val dl = (1.914600 - 0.004817 * t - 0.000014 * t2) * Math.sin(m * dr) +
                (0.019993 - 0.000101 * t) * Math.sin(2 * m * dr) +
                0.000289 * Math.sin(3 * m * dr)
        var l = l0 + dl
        l = (l % 360.0 + 360.0) % 360.0
        return Math.floor(l / 30.0)
    }

    private fun getLunarMonth11(year: Int, timeZone: Double = 7.0): Int {
        val off = jdFromDate(31, 12, year) - 2415021
        val k = Math.floor(off / 29.53058868).toInt()
        var nm = getNewMoonDay(k, timeZone)
        val sunLong = getSunLongitude(nm, timeZone)
        if (sunLong >= 9.0) {
            nm = getNewMoonDay(k - 1, timeZone)
        }
        return nm
    }

    fun convertSolarToLunar(solarDay: Int, solarMonth: Int, solarYear: Int, timeZone: Double = 7.0): LunarDate {
        val dayNumber = jdFromDate(solarDay, solarMonth, solarYear)
        val k = Math.floor((dayNumber - 2415021) / 29.53058868).toInt()
        var monthStart = getNewMoonDay(k + 1, timeZone)
        if (monthStart > dayNumber) {
            monthStart = getNewMoonDay(k, timeZone)
        }
        var a11 = getLunarMonth11(solarYear, timeZone)
        var b11 = a11
        val lunarYear: Int
        if (a11 >= monthStart) {
            lunarYear = solarYear
            a11 = getLunarMonth11(solarYear - 1, timeZone)
        } else {
            lunarYear = solarYear + 1
            b11 = getLunarMonth11(solarYear + 1, timeZone)
        }
        val lunarDay = dayNumber - monthStart + 1
        val diff = Math.floor((monthStart - a11) / 29.53058868).toInt()
        var lunarMonth = diff + 11
        var isLeap = false
        if (b11 - a11 > 365) {
            val leapMonthDiff = Math.floor((b11 - a11) / 29.53058868).toInt()
            if (diff >= leapMonthDiff) {
                lunarMonth -= 1
                if (diff == leapMonthDiff) isLeap = true
            }
        }
        if (lunarMonth > 12) {
            lunarMonth -= 12
        }

        return LunarDate(lunarDay, lunarMonth, lunarYear, isLeap)
    }

    fun getLunarDate(calendar: Calendar = Calendar.getInstance()): LunarDate {
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val month = calendar.get(Calendar.MONTH) + 1
        val year = calendar.get(Calendar.YEAR)
        return convertSolarToLunar(day, month, year)
    }
}
