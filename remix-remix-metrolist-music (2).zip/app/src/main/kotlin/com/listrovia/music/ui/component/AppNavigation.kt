/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.component

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import com.listrovia.music.LocalIsTvMode
import com.listrovia.music.R
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.listrovia.music.constants.ChromaticAberrationKey
import com.listrovia.music.constants.DepthEffectKey
import com.listrovia.music.constants.EnableLiquidGlassKey
import com.listrovia.music.constants.FloatingNavBarKey
import com.listrovia.music.constants.GlassBlurRadiusKey
import com.listrovia.music.constants.GlassNavBarKey
import com.listrovia.music.constants.GlassSaturationKey
import com.listrovia.music.constants.LensRefractionAmountKey
import com.listrovia.music.constants.LensRefractionHeightKey
import com.listrovia.music.constants.NavigationBarHeight
import com.listrovia.music.constants.SlimNavBarHeight
import com.listrovia.music.constants.SurfaceOpacityKey
import com.listrovia.music.ui.components.liquidGlass
import com.listrovia.music.ui.components.rememberClassifiedLiquidGlassStyle
import com.listrovia.music.ui.screens.Screens
import com.listrovia.music.utils.rememberPreference
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest

@Immutable
private data class NavItemState(
    val isSelected: Boolean,
    val iconRes: Int
)

@Stable
private fun isRouteSelected(currentRoute: String?, screenRoute: String, navigationItems: List<Screens>): Boolean {
    if (currentRoute == null) return false
    if (currentRoute == screenRoute) return true
    if (navigationItems.any { it.route == screenRoute } &&
        currentRoute.startsWith("$screenRoute/")) return true

    // Fix: match the route template, not the resolved route
    if (screenRoute == "search_input" &&
        (currentRoute.startsWith("search/") || currentRoute == "search/{query}")) return true

    return false
}

@Composable
fun AppNavigationRail(
    navigationItems: List<Screens>,
    currentRoute: String?,
    onItemClick: (Screens, Boolean) -> Unit,
    modifier: Modifier = Modifier,
    pureBlack: Boolean = false,
    onSearchLongClick: (() -> Unit)? = null
) {
    val enableLiquidGlass by rememberPreference(EnableLiquidGlassKey, defaultValue = false)
    val glassNavBar by rememberPreference(GlassNavBarKey, defaultValue = true)
    val glassBlurRadius by rememberPreference(GlassBlurRadiusKey, defaultValue = 16f)
    val glassSaturation by rememberPreference(GlassSaturationKey, defaultValue = 1.15f)
    val refractionHeight by rememberPreference(LensRefractionHeightKey, defaultValue = 12f)
    val refractionAmount by rememberPreference(LensRefractionAmountKey, defaultValue = 18f)
    val chromaticAberration by rememberPreference(ChromaticAberrationKey, defaultValue = 0.15f)
    val depthEffect by rememberPreference(DepthEffectKey, defaultValue = 0.35f)
    val surfaceOpacity by rememberPreference(SurfaceOpacityKey, defaultValue = 0.80f)

    val isGlassActive = enableLiquidGlass && glassNavBar
    val classifiedStyle = rememberClassifiedLiquidGlassStyle(
        pureBlack = pureBlack,
        surfaceOpacity = surfaceOpacity,
        saturation = glassSaturation,
        depthEffect = depthEffect,
    )

    val containerColor = when {
        isGlassActive -> Color.Transparent
        pureBlack -> Color.Black
        else -> MaterialTheme.colorScheme.surfaceContainer
    }
    val haptics = LocalHapticFeedback.current
    val viewConfiguration = LocalViewConfiguration.current
    val railItemColors = NavigationRailItemDefaults.colors(
        selectedIconColor = if (isGlassActive) classifiedStyle.activeAccentColor else MaterialTheme.colorScheme.onSecondaryContainer,
        selectedTextColor = if (isGlassActive) classifiedStyle.contentColor else MaterialTheme.colorScheme.onSurface,
        indicatorColor = if (isGlassActive) classifiedStyle.indicatorContainerColor else MaterialTheme.colorScheme.secondaryContainer,
        unselectedIconColor = if (isGlassActive) classifiedStyle.secondaryContentColor else MaterialTheme.colorScheme.onSurfaceVariant,
        unselectedTextColor = if (isGlassActive) classifiedStyle.secondaryContentColor else MaterialTheme.colorScheme.onSurfaceVariant
    )

    val focusRequesters = remember(navigationItems) { List(navigationItems.size) { FocusRequester() } }

    NavigationRail(
        modifier = if (isGlassActive) {
            modifier.liquidGlass(
                enabled = true,
                blurRadiusDp = glassBlurRadius,
                saturation = glassSaturation,
                refractionHeight = refractionHeight,
                refractionAmount = refractionAmount,
                chromaticAberration = chromaticAberration,
                depthEffect = depthEffect,
                surfaceOpacity = surfaceOpacity,
                pureBlack = pureBlack,
                shape = RoundedCornerShape(0.dp)
            )
        } else {
            modifier
        },
        containerColor = containerColor
    ) {
        Spacer(modifier = Modifier.weight(1f))

        navigationItems.forEachIndexed { index, screen ->
            val prevRequester = focusRequesters[if (index > 0) index - 1 else navigationItems.lastIndex]
            val nextRequester = focusRequesters[if (index < navigationItems.lastIndex) index + 1 else 0]

            val isSelected = remember(currentRoute, screen.route) {
                isRouteSelected(currentRoute, screen.route, navigationItems)
            }
            val currentIsSelected by rememberUpdatedState(isSelected)
            val iconRes = remember(isSelected, screen) {
                if (isSelected) screen.iconIdActive else screen.iconIdInactive
            }

            val isSearchItem = screen == Screens.Search && onSearchLongClick != null
            val interactionSource = remember { MutableInteractionSource() }

            // Long press detection using InteractionSource
            if (isSearchItem) {
                LaunchedEffect(interactionSource) {
                    var isLongClick = false
                    interactionSource.interactions.collectLatest { interaction ->
                        when (interaction) {
                            is PressInteraction.Press -> {
                                isLongClick = false
                                delay(viewConfiguration.longPressTimeoutMillis)
                                isLongClick = true
                                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                onSearchLongClick?.invoke()
                            }
                            is PressInteraction.Release -> {
                                if (!isLongClick) {
                                    onItemClick(screen, currentIsSelected)
                                }
                            }
                            is PressInteraction.Cancel -> {
                                isLongClick = false
                            }
                        }
                    }
                }
            }

            NavigationRailItem(
                selected = isSelected,
                onClick = {
                    if (!isSearchItem) {
                        onItemClick(screen, currentIsSelected)
                    }
                },
                modifier = Modifier
                    .focusRequester(focusRequesters[index])
                    .focusProperties {
                        up = prevRequester
                        down = nextRequester
                    }
                    .tvFocusHighlight(
                        shape = RoundedCornerShape(12.dp),
                        focusedScale = 1.05f
                    ),
                interactionSource = interactionSource,
                colors = railItemColors,
                icon = {
                    Icon(
                        painter = painterResource(id = iconRes),
                        contentDescription = stringResource(screen.titleId)
                    )
                }
            )
        }

        Spacer(modifier = Modifier.weight(1f))
    }
}

@Composable
fun AppNavigationBar(
    navigationItems: List<Screens>,
    currentRoute: String?,
    onItemClick: (Screens, Boolean) -> Unit,
    modifier: Modifier = Modifier,
    pureBlack: Boolean = false,
    slimNav: Boolean = false,
    onSearchLongClick: (() -> Unit)? = null
) {
    val floatingNavBar by rememberPreference(FloatingNavBarKey, defaultValue = true)
    val enableLiquidGlass by rememberPreference(EnableLiquidGlassKey, defaultValue = false)
    val glassNavBar by rememberPreference(GlassNavBarKey, defaultValue = true)
    val glassBlurRadius by rememberPreference(GlassBlurRadiusKey, defaultValue = 16f)
    val glassSaturation by rememberPreference(GlassSaturationKey, defaultValue = 1.15f)
    val refractionHeight by rememberPreference(LensRefractionHeightKey, defaultValue = 12f)
    val refractionAmount by rememberPreference(LensRefractionAmountKey, defaultValue = 18f)
    val chromaticAberration by rememberPreference(ChromaticAberrationKey, defaultValue = 0.15f)
    val depthEffect by rememberPreference(DepthEffectKey, defaultValue = 0.35f)
    val surfaceOpacity by rememberPreference(SurfaceOpacityKey, defaultValue = 0.80f)

    val isGlassActive = enableLiquidGlass && glassNavBar
    val classifiedStyle = rememberClassifiedLiquidGlassStyle(
        pureBlack = pureBlack,
        surfaceOpacity = surfaceOpacity,
        saturation = glassSaturation,
        depthEffect = depthEffect,
    )

    val navShape = if (floatingNavBar) RoundedCornerShape(28.dp) else RoundedCornerShape(0.dp)

    val floatingPadding by animateDpAsState(
        targetValue = if (floatingNavBar) 20.dp else 0.dp,
        animationSpec = tween(250),
        label = "floatingPadding"
    )

    val containerColor = when {
        isGlassActive -> Color.Transparent
        pureBlack -> Color.Black
        floatingNavBar -> MaterialTheme.colorScheme.surfaceContainerHigh
        else -> MaterialTheme.colorScheme.surfaceContainer
    }
    val contentColor = when {
        isGlassActive -> classifiedStyle.contentColor
        pureBlack -> Color.White
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    val borderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
    val haptics = LocalHapticFeedback.current
    val viewConfiguration = LocalViewConfiguration.current
    val navItemIndication = LocalIndication.current

    val barHeight = if (slimNav) SlimNavBarHeight else NavigationBarHeight

    val navBarModifier = if (floatingNavBar) {
        modifier
            .padding(horizontal = floatingPadding)
            .widthIn(max = 480.dp)
            .shadow(
                elevation = 6.dp,
                shape = navShape,
                clip = false
            )
            .then(
                if (isGlassActive) {
                    Modifier.liquidGlass(
                        enabled = true,
                        blurRadiusDp = glassBlurRadius,
                        saturation = glassSaturation,
                        refractionHeight = refractionHeight,
                        refractionAmount = refractionAmount,
                        chromaticAberration = chromaticAberration,
                        depthEffect = depthEffect,
                        surfaceOpacity = surfaceOpacity,
                        pureBlack = pureBlack,
                        shape = navShape
                    )
                } else {
                    Modifier
                        .clip(navShape)
                        .border(
                            width = 1.dp,
                            color = borderColor,
                            shape = navShape
                        )
                }
            )
    } else {
        if (isGlassActive) {
            modifier.liquidGlass(
                enabled = true,
                blurRadiusDp = glassBlurRadius,
                saturation = glassSaturation,
                refractionHeight = refractionHeight,
                refractionAmount = refractionAmount,
                chromaticAberration = chromaticAberration,
                depthEffect = depthEffect,
                surfaceOpacity = surfaceOpacity,
                pureBlack = pureBlack,
                shape = navShape
            )
        } else {
            modifier
        }
    }

    val focusRequesters = remember(navigationItems) { List(navigationItems.size) { FocusRequester() } }

    Surface(
        modifier = navBarModifier,
        color = containerColor,
        contentColor = contentColor,
        shape = navShape
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(barHeight)
                .padding(horizontal = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            navigationItems.forEachIndexed { index, screen ->
                val prevRequester = focusRequesters[if (index > 0) index - 1 else navigationItems.lastIndex]
                val nextRequester = focusRequesters[if (index < navigationItems.lastIndex) index + 1 else 0]

                val isSelected = remember(currentRoute, screen.route) {
                    isRouteSelected(currentRoute, screen.route, navigationItems)
                }
                val currentIsSelected by rememberUpdatedState(isSelected)
                val iconRes = remember(isSelected, screen) {
                    if (isSelected) screen.iconIdActive else screen.iconIdInactive
                }

                val isSearchItem = screen == Screens.Search && onSearchLongClick != null
                val interactionSource = remember { MutableInteractionSource() }

                if (isSearchItem) {
                    LaunchedEffect(interactionSource) {
                        var isLongClick = false
                        interactionSource.interactions.collectLatest { interaction ->
                            when (interaction) {
                                is PressInteraction.Press -> {
                                    isLongClick = false
                                    delay(viewConfiguration.longPressTimeoutMillis)
                                    isLongClick = true
                                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                    onSearchLongClick?.invoke()
                                }
                                is PressInteraction.Release -> {
                                    if (!isLongClick) {
                                        onItemClick(screen, currentIsSelected)
                                    }
                                }
                                is PressInteraction.Cancel -> {
                                    isLongClick = false
                                }
                            }
                        }
                    }
                }

                val activeColor = when {
                    isGlassActive -> classifiedStyle.activeAccentColor
                    pureBlack -> Color.White
                    else -> MaterialTheme.colorScheme.primary
                }
                val inactiveColor = when {
                    isGlassActive -> classifiedStyle.secondaryContentColor
                    pureBlack -> Color.White.copy(alpha = 0.65f)
                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                }
                val indicatorColor = when {
                    isGlassActive -> classifiedStyle.indicatorContainerColor
                    pureBlack -> Color.White.copy(alpha = 0.20f)
                    else -> MaterialTheme.colorScheme.secondaryContainer
                }

                val animatedItemColor by animateColorAsState(
                    targetValue = if (isSelected) activeColor else inactiveColor,
                    animationSpec = tween(200),
                    label = "itemColor"
                )

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .focusRequester(focusRequesters[index])
                        .focusProperties {
                            left = prevRequester
                            right = nextRequester
                        }
                        .tvFocusHighlight(
                            shape = RoundedCornerShape(18.dp),
                            focusedScale = 1.05f
                        )
                        .clickable(
                            interactionSource = interactionSource,
                            indication = navItemIndication,
                            onClick = {
                                if (!isSearchItem) {
                                    onItemClick(screen, currentIsSelected)
                                }
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(vertical = 2.dp)
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .height(if (slimNav) 30.dp else 24.dp)
                                .width(if (slimNav) 44.dp else 40.dp)
                                .background(
                                    color = if (isSelected) indicatorColor else Color.Transparent,
                                    shape = RoundedCornerShape(12.dp)
                                )
                        ) {
                            Icon(
                                painter = painterResource(id = iconRes),
                                contentDescription = stringResource(screen.titleId),
                                tint = animatedItemColor,
                                modifier = Modifier.size(19.dp)
                            )
                        }

                        if (!slimNav) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = stringResource(screen.titleId),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 10.5.sp,
                                    lineHeight = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                ),
                                color = animatedItemColor
                            )
                        }
                    }
                }
            }
        }
    }
}

