/**
 * OmnisSecurity: Hệ thống bảo mật cấp cao 2026.
 * Nhà phát triển: Nguyễn Minh Tới.
 * Cập nhật: Siết chặt chống can thiệp mã nguồn suốt đời, chặn Trợ năng (Accessibility Bypass),
 * chặn Bootloader/Custom ROM quân sự, chặn VPN/Fake IP và đồng bộ hệ thống tự hủy.
 */
package com.example.myempty.vietcore

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.UiModeManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.*
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import com.listrovia.music.ui.screens.OmnisSecurityBlockActivity
import timber.log.Timber
import java.io.File
import java.io.IOException
import java.net.NetworkInterface
import java.util.*
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.zip.ZipFile
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

class OmnisSecurity(private val context: Context) {

    private val AES_KEY = "VIETCORE_SECURE_KEY_2026_TOI_MOD" 
    private val securityExecutor = Executors.newScheduledThreadPool(2) { runnable ->
        Thread(runnable, "OmnisSecurityThread").apply { isDaemon = true }
    }
    private val audioManager = try {
        context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    } catch (e: Exception) { null }

    fun startRealTimeIntelligence() {
        try {
            securityExecutor.scheduleWithFixedDelay({
                try {
                    if (isIntegrityCompromised()) {
                        Timber.tag("OmnisSecurity").w("Integrity compromised detected by VietCore engine!")
                        triggerSecurityBlockade()
                    }
                } catch (e: Exception) {
                    Timber.tag("OmnisSecurity").d("Error in integrity check loop: ${e.message}")
                }
            }, 0, 2, TimeUnit.SECONDS)

            securityExecutor.scheduleWithFixedDelay({
                try {
                    activateAudioShield()
                } catch (e: Exception) {
                    Timber.tag("OmnisSecurity").d("Error in audio shield loop: ${e.message}")
                }
            }, 0, 5, TimeUnit.SECONDS)
        } catch (e: Exception) {
            Timber.tag("OmnisSecurity").e(e, "Failed to start real-time intelligence scheduler")
        }
    }

    private fun triggerSecurityBlockade() {
        try {
            val intent = Intent(context, OmnisSecurityBlockActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Timber.tag("OmnisSecurity").e(e, "Failed to launch OmnisSecurityBlockActivity")
        }
    }

    fun isIntegrityCompromised(): Boolean {
        return try {
            isClassesDexTampered() || 
            isRooted() || 
            isHackerToolsDetected() || 
            isAppCloned() || 
            isDebugging() || 
            isManifestTampered() || 
            isResourceModified() || 
            isWifiDebuggingEnabled() || 
            isEmulatorOrVirtualMachine() || 
            isRemoteControlActive() || 
            isAccessibilityExploitDetected() || 
            isNetworkProxyOrVPNDetected() ||     
            isHardwareLockCompromised()
        } catch (e: Exception) {
            false
        }
    }

    // --- NGĂN CHẶN ANDROID TV, TV BOX VÀ PC ---

    fun isNonMobileHardwareDetected(): Boolean {
        return try {
            val uiModeManager = context.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
            val isTV = uiModeManager?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION
            
            val pm = context.packageManager
            val isMissingPhoneFeatures = !pm.hasSystemFeature(PackageManager.FEATURE_TELEPHONY) && 
                                         !pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN)
            
            val isPC = pm.hasSystemFeature("android.hardware.type.pc") || 
                       Build.DEVICE.contains("arc") || 
                       Build.BRAND.contains("chromium")

            val model = Build.MODEL.lowercase(Locale.ROOT)
            val isBox = model.contains("tvbox") || model.contains("smarttv") || model.contains("mibox")

            isTV || isPC || isBox || (isMissingPhoneFeatures && !pm.hasSystemFeature(PackageManager.FEATURE_CAMERA))
        } catch (e: Exception) {
            false
        }
    }

    // --- CƠ CHẾ NGĂN CHẶN TÙY CHỌN NHÀ PHÁT TRIỂN ---

    fun isDeveloperOptionsEnabled(): Boolean {
        return try {
            val devOptions = Settings.Global.getInt(
                context.contentResolver,
                Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0
            ) != 0
            val adbEnabled = Settings.Global.getInt(
                context.contentResolver,
                Settings.Global.ADB_ENABLED, 0
            ) != 0
            devOptions || adbEnabled
        } catch (e: Exception) { false }
    }

    // --- CHẶN THIẾT BỊ BIẾN THỂ NỘI ĐỊA ---

    fun isRestrictedRegionDevice(): Boolean {
        return try {
            val region = Locale.getDefault().country.uppercase(Locale.ROOT)
            val manufacturer = Build.MANUFACTURER.lowercase(Locale.ROOT)
            val restrictedTags = arrayOf("cn", "kp", "kr")
            restrictedTags.contains(region.lowercase(Locale.ROOT)) && 
                   (manufacturer.contains("xiaomi") || manufacturer.contains("huawei") || manufacturer.contains("samsung")) &&
                   isCustomROMDetected()
        } catch (e: Exception) {
            false
        }
    }

    // --- TOÀN VẸN MÃ NGUỒN ---

    fun isClassesDexTampered(): Boolean {
        return try {
            val ai = context.applicationInfo ?: return false
            val sourceDir = ai.sourceDir ?: return false
            val file = File(sourceDir)
            if (!file.exists()) return false
            ZipFile(file).use { zf ->
                val dexEntry = zf.getEntry("classes.dex") ?: return true
                val isModified = zf.getEntry("assets/bin/Data/Managed") != null || zf.getEntry("re75") != null 
                isModified || isManifestStructuralTampered()
            }
        } catch (e: Exception) { false }
    }

    fun isManifestStructuralTampered(): Boolean {
        return try {
            val info = context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_PERMISSIONS or PackageManager.GET_ACTIVITIES)
            (info.requestedPermissions?.size ?: 0 > 50 || info.activities?.size ?: 0 > 30)
        } catch (e: Exception) { false }
    }

    fun isSignatureValid(): Boolean {
        return try {
            val pm = context.packageManager
            val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES).signingInfo?.apkContentsSigners
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES).signatures
            }
            signatures != null && signatures.isNotEmpty()
        } catch (e: Exception) { true } // Default true to avoid false positive blocks on development environments
    }

    // --- PHÁT HIỆN GIẢ LẬP & MÔI TRƯỜNG LẠ ---

    fun isEmulatorOrVirtualMachine(): Boolean {
        return try {
            val finger = Build.FINGERPRINT ?: ""
            val model = Build.MODEL.lowercase(Locale.ROOT)
            val hardware = Build.HARDWARE.lowercase(Locale.ROOT)
            (finger.startsWith("generic") || model.contains("emulator") || 
                    hardware.contains("goldfish") || hardware.contains("ranchu") ||
                    model.contains("sdk_gphone") || Build.PRODUCT.contains("sdk_google") ||
                    Build.MANUFACTURER.contains("Genymotion"))
        } catch (e: Exception) {
            false
        }
    }

    fun isHackerToolsDetected(): Boolean {
        return try {
            val file = File("/proc/self/maps")
            if (file.exists()) {
                val content = file.readText()
                content.contains("frida") || content.contains("xposed") || 
                content.contains("com.chelpus.lackypatch") || content.contains("libsubstrate.so")
            } else false
        } catch (e: Exception) { false }
    }

    fun isRooted(): Boolean {
        return try {
            val paths = arrayOf("/system/bin/su", "/system/xbin/su", "/sbin/su", "/data/local/xbin/su", "/system/app/Superuser.apk")
            paths.any { File(it).exists() }
        } catch (e: Exception) {
            false
        }
    }

    fun isAppCloned(): Boolean {
        return try {
            val path = context.filesDir?.absolutePath ?: return false
            path.contains("999") || path.contains("101") || !path.startsWith("/data/user/0/")
        } catch (e: Exception) {
            false
        }
    }

    // --- GIÁM SÁT KẾT NỐI VÀ TẤNG BẢO MẬT MỚI ---

    fun isRemoteControlActive(): Boolean {
        return try {
            val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager ?: return false
            val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            enabledServices.any { service ->
                val pkg = service.resolveInfo?.serviceInfo?.packageName ?: ""
                !pkg.contains("com.google.android.gms") && 
                (service.capabilities and AccessibilityServiceInfo.CAPABILITY_CAN_RETRIEVE_WINDOW_CONTENT) != 0
            }
        } catch (e: Exception) { false }
    }

    fun isAccessibilityExploitDetected(): Boolean {
        return try {
            val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager ?: return false
            val runningServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            runningServices.any { service ->
                val pkgName = service.resolveInfo?.serviceInfo?.packageName ?: ""
                service.capabilities and AccessibilityServiceInfo.CAPABILITY_CAN_RETRIEVE_WINDOW_CONTENT != 0 &&
                !pkgName.contains("com.google.android.marvin.talkback") &&
                !pkgName.contains("com.android.server.accessibility")
            }
        } catch (e: Exception) { false }
    }

    fun isNetworkProxyOrVPNDetected(): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
            val activeNetwork = cm.activeNetwork
            val caps = cm.getNetworkCapabilities(activeNetwork)
            val hasVPN = caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) ?: false

            val proxyAddress = System.getProperty("http.proxyHost")
            val proxyPort = System.getProperty("http.proxyPort")
            val hasProxy = !proxyAddress.isNullOrEmpty() && !proxyPort.isNullOrEmpty()

            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            val hasVpnInterface = interfaces.any { 
                val name = it.name.lowercase(Locale.ROOT)
                name.contains("tun") || name.contains("ppp") || name.contains("p2p") || name.contains("tap")
            }

            hasVPN || hasProxy || hasVpnInterface
        } catch (e: Exception) { false }
    }

    fun isHardwareLockCompromised(): Boolean {
        return isBootloaderUnlocked() || isCustomROMDetected()
    }

    fun isMicrophoneInUse(): Boolean {
        return try {
            audioManager?.let {
                it.mode == AudioManager.MODE_IN_COMMUNICATION || 
                (it.isMicrophoneMute.not() && it.mode != AudioManager.MODE_NORMAL)
            } ?: false
        } catch (e: Exception) {
            false
        }
    }

    fun isWifiDebuggingEnabled(): Boolean = try {
        Settings.Global.getInt(context.contentResolver, "adb_wifi_enabled", 0) != 0
    } catch (e: Exception) { false }

    fun isDebugging(): Boolean = try {
        Debug.isDebuggerConnected()
    } catch (e: Exception) { false }

    fun isBootloaderUnlocked(): Boolean = try {
        (Build.BOOTLOADER?.lowercase(Locale.ROOT)?.contains("unlock") == true) || 
        (Build.VERSION.INCREMENTAL?.lowercase(Locale.ROOT)?.contains("test-keys") == true)
    } catch (e: Exception) { false }
    
    fun isCustomROMDetected(): Boolean = try {
        (Build.TAGS?.contains("test-keys") == true) || 
        (Build.HOST?.lowercase(Locale.ROOT)?.contains("ubuntu") == true)
    } catch (e: Exception) { false }

    // --- TIỆN ÍCH MÃ HÓA ---

    fun encryptData(data: String): String {
        return try {
            val keyBytes = AES_KEY.toByteArray(Charsets.UTF_8).let { it.copyOf(32) }
            val skeySpec = SecretKeySpec(keyBytes, "AES")
            val cipher = Cipher.getInstance("AES/ECB/PKCS5Padding")
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec)
            val encrypted = cipher.doFinal(data.toByteArray(Charsets.UTF_8))
            android.util.Base64.encodeToString(encrypted, android.util.Base64.NO_WRAP)
        } catch (e: Exception) { "ERR" }
    }

    fun isOriginalPackage(): Boolean = try {
        val pkg = context.packageName
        pkg == "com.example.myempty.vietcore" || pkg == "com.aistudio.listrovia.ykdbdj" || pkg == "com.listrovia.music"
    } catch (e: Exception) { true }

    fun isManifestTampered(): Boolean = !isOriginalPackage() || isManifestStructuralTampered()
    fun isResourceModified(): Boolean = !isSignatureValid()

    fun activateAudioShield() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && audioManager != null) {
                val focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                    .setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build())
                    .build()
                audioManager.requestAudioFocus(focusRequest)
            }
        } catch (e: Exception) {
            // Ignore audio focus exceptions in background
        }
    }
}
