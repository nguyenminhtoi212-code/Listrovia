/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.lyrics

import android.content.Context
import com.listrovia.music.db.MusicDatabase
import com.listrovia.music.db.entities.LyricsEntity
import com.listrovia.music.db.entities.SongEntity
import com.listrovia.music.api.DeepLService
import com.listrovia.music.api.MistralService
import com.listrovia.music.api.OpenRouterModelManager
import com.listrovia.music.api.OpenRouterService
import com.listrovia.music.api.OpenRouterStreamingService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import timber.log.Timber
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * A helper class that provides AI-powered translation for lyrics.
 */
object LyricsTranslationHelper {
    private val _status = MutableStateFlow<TranslationStatus>(TranslationStatus.Idle)
    val status: StateFlow<TranslationStatus> = _status.asStateFlow()

    private val _hasActiveTranslations = MutableStateFlow(false)
    val hasActiveTranslations: StateFlow<Boolean> = _hasActiveTranslations.asStateFlow()

    private val _translationSaved = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val translationSaved: SharedFlow<Unit> = _translationSaved.asSharedFlow()

    private val _manualTrigger = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val manualTrigger: SharedFlow<Unit> = _manualTrigger.asSharedFlow()

    private val _clearTranslationsTrigger = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val clearTranslationsTrigger: SharedFlow<Unit> = _clearTranslationsTrigger.asSharedFlow()

    private var translationJob: kotlinx.coroutines.Job? = null
    private var isCompositionActive = true

    // Cache translations in memory to avoid redundant API calls during a session
    private val translationCache = ConcurrentHashMap<String, List<String>>()

    // Map of language codes to full names for better AI understanding
    private val LanguageCodeToName = mapOf(
        "en" to "English",
        "es" to "Spanish",
        "fr" to "French",
        "de" to "German",
        "it" to "Italian",
        "pt" to "Portuguese",
        "ru" to "Russian",
        "ja" to "Japanese",
        "ko" to "Korean",
        "zh" to "Chinese",
        "ar" to "Arabic",
        "hi" to "Hindi",
        "bn" to "Bengali",
        "pa" to "Punjabi",
        "tr" to "Turkish",
        "vi" to "Vietnamese",
        "th" to "Thai",
        "id" to "Indonesian",
        "pl" to "Polish",
        "nl" to "Dutch",
        "sv" to "Swedish",
        "uk" to "Ukrainian"
    )

    fun setCompositionActive(active: Boolean) {
        isCompositionActive = active
    }

    fun triggerManualTranslation() {
        _manualTrigger.tryEmit(Unit)
    }

    fun triggerClearTranslations() {
        _clearTranslationsTrigger.tryEmit(Unit)
        _hasActiveTranslations.value = false
    }

    fun clearTranslations(lyrics: LyricsEntity): LyricsEntity {
        return lyrics.copy(
            translatedLyrics = "",
            translationLanguage = "",
            translationMode = ""
        )
    }

    fun cancelTranslation() {
        translationJob?.cancel()
        if (_status.value is TranslationStatus.Translating) {
            _status.value = TranslationStatus.Idle
        }
    }

    private fun getCacheKey(text: String, mode: String, targetLanguage: String): String {
        return "${text.hashCode()}_${mode}_${targetLanguage}"
    }

    /**
     * Phân tích nội dung dịch từng phần theo thời gian thực khi đang nhận luồng dữ liệu (SSE stream) từ API.
     * Hỗ trợ trích xuất trực tiếp từng chuỗi trong mảng JSON ["dòng 1", "dòng 2 đang gõ... ngay cả khi chưa đóng ngoặc kép,
     * giúp giao diện hiển thị chữ chạy theo thời gian thực từng từ/câu.
     */
    fun tryParsePartialTranslation(content: String, expectedLines: Int): List<String> {
        val cleaned = content
            .replace("```json", "")
            .replace("```", "")
            .trim()
        if (cleaned.isEmpty()) return emptyList()

        val bracketIndex = cleaned.indexOf('[')
        if (bracketIndex != -1) {
            val extracted = mutableListOf<String>()
            var inString = false
            var escaped = false
            val currentToken = StringBuilder()

            for (i in (bracketIndex + 1) until cleaned.length) {
                val c = cleaned[i]
                if (!inString) {
                    if (c == '"') {
                        inString = true
                        currentToken.setLength(0)
                    } else if (c == ']') {
                        break
                    }
                } else {
                    if (escaped) {
                        when (c) {
                            'n' -> currentToken.append('\n')
                            'r' -> {}
                            't' -> currentToken.append('\t')
                            '"' -> currentToken.append('"')
                            '\\' -> currentToken.append('\\')
                            '/' -> currentToken.append('/')
                            else -> currentToken.append(c)
                        }
                        escaped = false
                    } else if (c == '\\') {
                        escaped = true
                    } else if (c == '"') {
                        inString = false
                        extracted.add(currentToken.toString().trim())
                        currentToken.setLength(0)
                    } else {
                        currentToken.append(c)
                    }
                }
            }

            // Nếu một chuỗi đang được truyền dở dang (chưa có dấu ngoặc kép đóng), vẫn hiển thị chữ theo thời gian thực
            if (inString && currentToken.isNotEmpty()) {
                extracted.add(currentToken.toString().trim())
            }

            if (extracted.isNotEmpty()) {
                return extracted
            }
        }

        // Dự phòng cho trường hợp mô hình trả về từng dòng văn bản thuần túy
        return cleaned.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() && it != "[" && it != "]" }
            .map { line ->
                line.removePrefix("\"")
                    .removeSuffix(",")
                    .removeSuffix("\"")
                    .replace(Regex("^\\d+\\.\\s*"), "")
                    .replace(Regex("^Line\\s+\\d+:\\s*", RegexOption.IGNORE_CASE), "")
                    .replace(Regex("^-\\s*"), "")
                    .trim()
            }
            .filter { it.isNotBlank() }
    }

    fun loadTranslationsFromDatabase(
        lyrics: List<LyricsEntry>,
        lyricsEntity: LyricsEntity?,
        targetLanguage: String,
        mode: String
    ) {
        if (lyricsEntity == null || lyricsEntity.translatedLyrics.isNullOrBlank()) {
            _hasActiveTranslations.value = false
            lyrics.forEach { it.translatedTextFlow.value = null }
            return
        }
        
        // Only load if language and mode match
        if (lyricsEntity.translationLanguage != targetLanguage || lyricsEntity.translationMode != mode) {
            _hasActiveTranslations.value = false
            lyrics.forEach { it.translatedTextFlow.value = null }
            return
        }
        
        val translatedLines = lyricsEntity.translatedLyrics.split("\n")
        val nonEmptyEntries = lyrics.filter { it.text.isNotBlank() }
        
        if (translatedLines.size >= nonEmptyEntries.size) {
            var transIndex = 0
            lyrics.forEach { entry ->
                if (entry.text.isNotBlank() && transIndex < translatedLines.size) {
                    entry.translatedTextFlow.value = translatedLines[transIndex]
                    transIndex++
                }
            }
            
            // Also cache them
            val fullText = nonEmptyEntries.joinToString("\n") { it.text }
            val cacheKey = getCacheKey(fullText, mode, targetLanguage)
            translationCache[cacheKey] = translatedLines
            _hasActiveTranslations.value = true
        }
    }

    fun translateLyrics(
        lyrics: List<LyricsEntry>,
        targetLanguage: String,
        apiKey: String,
        baseUrl: String,
        model: String,
        mode: String,
        scope: CoroutineScope,
        context: Context,
        provider: String = "OpenRouter",
        deeplApiKey: String = "",
        deeplFormality: String = "default",
        useStreaming: Boolean = true,
        songId: String = "",
        database: MusicDatabase? = null,
        systemPrompt: String = "",
    ) {
        translationJob?.cancel()
        _status.value = TranslationStatus.Translating

        // Clear existing translations to indicate re-translation
        lyrics.forEach { it.translatedTextFlow.value = null }

        translationJob =
            scope.launch(Dispatchers.IO) {
                try {
                    if (lyrics.isEmpty()) {
                        _status.value = TranslationStatus.Error(context.getString(com.listrovia.music.R.string.ai_error_no_lyrics))
                        return@launch
                    }

                    // Filter out empty lines and keep track of their indices
                    val nonEmptyEntries =
                        lyrics.mapIndexedNotNull { index, entry ->
                            if (entry.text.isNotBlank()) index to entry else null
                        }

                    if (nonEmptyEntries.isEmpty()) {
                        _status.value = TranslationStatus.Error(context.getString(com.listrovia.music.R.string.ai_error_lyrics_empty))
                        return@launch
                    }

                    // Create text from non-empty lines only
                    val fullText = nonEmptyEntries.joinToString("\n") { it.second.text }

                    // Check cache first
                    val cacheKey = getCacheKey(fullText, mode, targetLanguage)
                    val cachedTranslations = translationCache[cacheKey]
                    if (cachedTranslations != null && cachedTranslations.size >= nonEmptyEntries.size) {
                        // Use cached translations
                        nonEmptyEntries.forEachIndexed { idx, (originalIndex, _) ->
                            if (idx < cachedTranslations.size) {
                                lyrics[originalIndex].translatedTextFlow.value = cachedTranslations[idx]
                            }
                        }
                        _hasActiveTranslations.value = true
                        _status.value = TranslationStatus.Success

                        // Persist cached translations to DB so loadTranslationsFromDatabase can't
                        // overwrite them with a stale empty entity (e.g. after an untranslate race).
                        if (songId.isNotBlank() && database != null) {
                            try {
                                val currentLyrics = database.lyrics(songId).first()
                                if (currentLyrics != null && currentLyrics.translatedLyrics.isNullOrBlank()) {
                                    database.query {
                                        upsert(
                                            currentLyrics.copy(
                                                translatedLyrics = cachedTranslations.joinToString("\n"),
                                                translationLanguage = targetLanguage,
                                                translationMode = mode,
                                            ),
                                        )
                                    }
                                    _translationSaved.tryEmit(Unit)
                                }
                            } catch (e: Exception) {
                                Timber.e(e, "Failed to persist cached translations to database")
                            }
                        }

                        delay(3000)
                        if (_status.value is TranslationStatus.Success && isCompositionActive) {
                            _status.value = TranslationStatus.Idle
                        }
                        return@launch
                    }

                    // Validate language for all modes
                    if (targetLanguage.isBlank()) {
                        _status.value = TranslationStatus.Error(context.getString(com.listrovia.music.R.string.ai_error_language_required))
                        return@launch
                    }

                    // Convert language code to full language name for better AI understanding
                    val fullLanguageName =
                        LanguageCodeToName[targetLanguage]
                            ?: try {
                                Locale.forLanguageTag(targetLanguage).displayLanguage.takeIf { it.isNotBlank() && it != targetLanguage }
                            } catch (e: Exception) {
                                null
                            }
                            ?: targetLanguage

                    val effectiveApiKey = if (provider == "DeepL") deeplApiKey else apiKey

                    // Siết chặt kiểm tra: Ngăn chặn mã giả mạo, chuỗi lậu hoặc lách luật trước khi gọi bất kỳ AI API nào
                    if (effectiveApiKey.isNotBlank() && !OpenRouterService.isKeyFormatValid(effectiveApiKey, provider)) {
                        _status.value = TranslationStatus.Error(
                            context.getString(com.listrovia.music.R.string.ai_api_key_fake_blocked_desc)
                        )
                        return@launch
                    }

                    val effectiveModel =
                        if (model.isNotBlank()) {
                            model
                        } else if (provider == "OpenRouter") {
                            try {
                                OpenRouterModelManager.getInstance(context).getModelsForApp().firstOrNull()?.id
                                    ?: com.listrovia.music.constants.OpenRouterDefaultModel
                            } catch (e: Exception) {
                                com.listrovia.music.constants.OpenRouterDefaultModel
                            }
                        } else if (provider == "DeepInfra") {
                            com.listrovia.music.constants.DeepInfraDefaultModel
                        } else {
                            model
                        }

                    val result =
                        if (effectiveApiKey.isBlank() && provider != "DeepInfra") {
                            Timber.d("No API key provided, using free Google Translate")
                            translateWithGoogleFree(fullText, targetLanguage)
                        } else if (provider == "DeepL") {
                            Timber.d("Using DeepL for translation")
                            // DeepL only supports translation mode
                            DeepLService.translate(
                                text = fullText,
                                targetLanguage = targetLanguage,
                                apiKey = deeplApiKey,
                                formality = deeplFormality,
                            )
                        } else if (provider == "Mistral") {
                            Timber.d("Using Mistral for translation")
                            // Use Mistral API directly
                            MistralService.translate(
                                text = fullText,
                                targetLanguage = fullLanguageName,
                                apiKey = apiKey,
                                model = effectiveModel,
                                mode = mode,
                                customSystemPrompt = systemPrompt,
                            )
                        } else if (useStreaming && provider != "Custom") {
                            Timber.d("Using streaming for translation with provider: $provider, model: $effectiveModel")
                            // Use streaming for supported providers
                            var translatedLines: List<String>? = null
                            var hasError = false
                            var errorMessage = ""
                            val contentAccumulator = StringBuilder()

                            OpenRouterStreamingService
                                .streamTranslation(
                                    text = fullText,
                                    targetLanguage = fullLanguageName,
                                    apiKey = apiKey,
                                    baseUrl = baseUrl,
                                    model = effectiveModel,
                                    mode = mode,
                                    customSystemPrompt = systemPrompt,
                                    provider = provider,
                                ).collect { chunk ->
                                    Timber.v("Received streaming chunk: $chunk")
                                    when (chunk) {
                                        is OpenRouterStreamingService.StreamChunk.Content -> {
                                            // Accumulate content for progressive parsing
                                            contentAccumulator.append(chunk.text)

                                            // Try to parse partial content and update UI progressively
                                            val partialContent = contentAccumulator.toString()
                                            val partialResult = tryParsePartialTranslation(partialContent, nonEmptyEntries.size)
                                            if (partialResult.isNotEmpty()) {
                                                // Update lyrics with partial translations as they become available
                                                partialResult.forEachIndexed { idx, translation ->
                                                    if (idx < nonEmptyEntries.size && translation.isNotBlank()) {
                                                        val originalIndex = nonEmptyEntries[idx].first
                                                        lyrics[originalIndex].translatedTextFlow.value = translation
                                                    }
                                                }
                                                _status.value = TranslationStatus.Translating
                                            }
                                        }

                                        is OpenRouterStreamingService.StreamChunk.Complete -> {
                                            Timber.d("Streaming complete with ${chunk.translatedLines.size} lines")
                                            translatedLines = chunk.translatedLines
                                        }

                                        is OpenRouterStreamingService.StreamChunk.Error -> {
                                            Timber.e("Streaming error: ${chunk.message}")
                                            hasError = true
                                            errorMessage = chunk.message
                                        }
                                    }
                                }

                            Timber.d("Streaming collection complete. hasError=$hasError, translatedLines=${translatedLines?.size}")
                            if (hasError) {
                                Result.failure(Exception(errorMessage))
                            } else if (translatedLines != null) {
                                Result.success(translatedLines)
                            } else {
                                Result.failure(Exception("No translation received"))
                            }
                        } else {
                            Timber.d("Using non-streaming for translation")
                            // Use non-streaming for Custom provider or when streaming is disabled
                            OpenRouterService.translate(
                                text = fullText,
                                targetLanguage = fullLanguageName,
                                apiKey = apiKey,
                                baseUrl = baseUrl,
                                model = effectiveModel,
                                mode = mode,
                                customSystemPrompt = systemPrompt,
                                provider = provider,
                            )
                        }

                    result
                        .onSuccess { lines ->
                            // Check if composition is still active before updating state
                            if (lines == null || !isCompositionActive) {
                                return@onSuccess
                            }

                            // Cache the translations
                            val cacheKey = getCacheKey(fullText, mode, targetLanguage)
                            translationCache[cacheKey] = lines

                            // Save to database if songId is provided
                            if (songId.isNotBlank() && database != null) {
                                try {
                                    val currentLyrics = database.lyrics(songId).first()
                                    if (currentLyrics != null) {
                                        database.query {
                                            upsert(
                                                currentLyrics.copy(
                                                    translatedLyrics = lines.joinToString("\n"),
                                                    translationLanguage = targetLanguage,
                                                    translationMode = mode,
                                                ),
                                            )
                                        }
                                        // Signal that translations have been saved
                                        _translationSaved.tryEmit(Unit)
                                    }
                                } catch (e: Exception) {
                                    Timber.e(e, "Failed to save translated lyrics to database")
                                }
                            }

                            // Map translations back to original non-empty entries only
                            val expectedCount = nonEmptyEntries.size

                            when {
                                lines.size >= expectedCount -> {
                                    // Perfect match or more - map to non-empty entries
                                    nonEmptyEntries.forEachIndexed { idx, (originalIndex, _) ->
                                        lyrics[originalIndex].translatedTextFlow.value = lines[idx]
                                    }
                                    _hasActiveTranslations.value = true
                                    _status.value = TranslationStatus.Success
                                }

                                lines.size < expectedCount -> {
                                    // Fewer translations than expected - map what we have
                                    lines.forEachIndexed { idx, translation ->
                                        if (idx < nonEmptyEntries.size) {
                                            val originalIndex = nonEmptyEntries[idx].first
                                            lyrics[originalIndex].translatedTextFlow.value = translation
                                        }
                                    }
                                    _hasActiveTranslations.value = true
                                    _status.value = TranslationStatus.Success
                                }
                            }

                            // Auto-hide success message after 3 seconds
                            delay(3000)
                            if (_status.value is TranslationStatus.Success && isCompositionActive) {
                                _status.value = TranslationStatus.Idle
                            }
                        }
                        .onFailure { error ->
                            if (!isCompositionActive) {
                                return@onFailure
                            }

                            val errorMessage = error.message ?: context.getString(com.listrovia.music.R.string.ai_error_unknown)

                            // Show error in UI
                            _status.value = TranslationStatus.Error(errorMessage)
                        }
                } catch (e: Exception) {
                    // Ignore cancellation exceptions or if composition is no longer active
                    if (e !is kotlinx.coroutines.CancellationException && isCompositionActive) {
                        val errorMessage = e.message ?: context.getString(com.listrovia.music.R.string.ai_error_translation_failed)
                        _status.value = TranslationStatus.Error(errorMessage)
                    }
                }
            }
    }

    data class DebugTranslationResult(
        val originalLines: List<String>,
        val translatedLines: List<String>,
        val latencyMs: Long,
        val provider: String,
        val model: String,
        val isGoogleFreeFallback: Boolean = false,
        val rawContent: String? = null,
    )

    suspend fun testTranslate(
        text: String,
        targetLanguage: String,
        apiKey: String,
        baseUrl: String,
        model: String,
        mode: String,
        provider: String = "OpenRouter",
        deeplApiKey: String = "",
        deeplFormality: String = "default",
        systemPrompt: String = "",
        onPartialUpdate: ((List<String>, String) -> Unit)? = null,
    ): Result<DebugTranslationResult> = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val nonEmptyLines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
        if (nonEmptyLines.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("No lyrics available to translate"))
        }

        val fullText = nonEmptyLines.joinToString("\n")
        val fullLanguageName =
            LanguageCodeToName[targetLanguage]
                ?: try {
                    Locale.forLanguageTag(targetLanguage).displayLanguage.takeIf { it.isNotBlank() && it != targetLanguage }
                } catch (e: Exception) {
                    null
                }
                ?: targetLanguage

        val effectiveApiKey = if (provider == "DeepL") deeplApiKey else apiKey
        val effectiveModel =
            if (model.isNotBlank()) {
                model
            } else if (provider == "OpenRouter") {
                com.listrovia.music.constants.OpenRouterDefaultModel
            } else if (provider == "DeepInfra") {
                com.listrovia.music.constants.DeepInfraDefaultModel
            } else {
                model
            }

        var rawStreamedText: String? = null
        val isGoogleFree = effectiveApiKey.isBlank() && provider != "DeepL" && provider != "DeepInfra"
        val res: Result<List<String>> = when {
            isGoogleFree -> {
                translateWithGoogleFree(fullText, targetLanguage)
            }
            provider == "DeepL" -> {
                DeepLService.translate(
                    text = fullText,
                    targetLanguage = targetLanguage,
                    apiKey = deeplApiKey,
                    formality = deeplFormality,
                )
            }
            provider == "Mistral" -> {
                MistralService.translate(
                    text = fullText,
                    targetLanguage = fullLanguageName,
                    apiKey = apiKey,
                    model = effectiveModel,
                    mode = mode,
                    customSystemPrompt = systemPrompt,
                )
            }
            provider != "Custom" -> {
                var finalLines: List<String>? = null
                var streamError: String? = null
                val accumulator = StringBuilder()

                OpenRouterStreamingService
                    .streamTranslation(
                        text = fullText,
                        targetLanguage = fullLanguageName,
                        apiKey = apiKey,
                        baseUrl = baseUrl,
                        model = effectiveModel,
                        mode = mode,
                        customSystemPrompt = systemPrompt,
                        provider = provider,
                    ).collect { chunk ->
                        when (chunk) {
                            is OpenRouterStreamingService.StreamChunk.Content -> {
                                accumulator.append(chunk.text)
                                val rawNow = accumulator.toString()
                                rawStreamedText = rawNow
                                val partialLines = tryParsePartialTranslation(rawNow, nonEmptyLines.size)
                                if (partialLines.isNotEmpty()) {
                                    onPartialUpdate?.invoke(partialLines, rawNow)
                                }
                            }
                            is OpenRouterStreamingService.StreamChunk.Complete -> {
                                finalLines = chunk.translatedLines
                            }
                            is OpenRouterStreamingService.StreamChunk.Error -> {
                                streamError = chunk.message
                            }
                        }
                    }

                if (finalLines != null) {
                    Result.success(finalLines!!)
                } else if (streamError != null) {
                    OpenRouterService.translate(
                        text = fullText,
                        targetLanguage = fullLanguageName,
                        apiKey = apiKey,
                        baseUrl = baseUrl,
                        model = effectiveModel,
                        mode = mode,
                        customSystemPrompt = systemPrompt,
                        provider = provider,
                    )
                } else {
                    Result.failure(Exception("No translation received from stream"))
                }
            }
            else -> {
                OpenRouterService.translate(
                    text = fullText,
                    targetLanguage = fullLanguageName,
                    apiKey = apiKey,
                    baseUrl = baseUrl,
                    model = effectiveModel,
                    mode = mode,
                    customSystemPrompt = systemPrompt,
                    provider = provider,
                )
            }
        }

        val elapsed = System.currentTimeMillis() - startTime
        res.map { lines ->
            DebugTranslationResult(
                originalLines = nonEmptyLines,
                translatedLines = lines,
                latencyMs = elapsed,
                provider = if (isGoogleFree) "Google Translate (Free)" else provider,
                model = if (isGoogleFree) "gtx-free" else effectiveModel,
                isGoogleFreeFallback = isGoogleFree,
                rawContent = rawStreamedText ?: lines.joinToString("\n"),
            )
        }
    }

    suspend fun translateWithGoogleFree(
        text: String,
        targetLanguage: String
    ): Result<List<String>> = withContext(Dispatchers.IO) {
        val client = okhttp3.OkHttpClient.Builder()
            .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
            .build()
        try {
            val encodedText = java.net.URLEncoder.encode(text, "UTF-8")
            val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=$targetLanguage&dt=t&q=$encodedText"
            val request = okhttp3.Request.Builder()
                .url(url)
                .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .build()
            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val body = response.body?.string()
                if (body != null) {
                    val jsonArray = org.json.JSONArray(body)
                    val innerArray = jsonArray.optJSONArray(0)
                    if (innerArray != null && innerArray.length() > 0) {
                        val sb = StringBuilder()
                        for (i in 0 until innerArray.length()) {
                            val item = innerArray.optJSONArray(i)
                            if (item != null && item.length() > 0) {
                                sb.append(item.optString(0))
                            }
                        }
                        val translatedText = sb.toString()
                        val translatedLines = translatedText.lines().map { it.trim() }
                        Result.success(translatedLines)
                    } else {
                        Result.failure(Exception("Empty translation response"))
                    }
                } else {
                    Result.failure(Exception("Null response body"))
                }
            } else {
                Result.failure(Exception("HTTP error: ${response.code}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    sealed class TranslationStatus {
        data object Idle : TranslationStatus()
        data object Translating : TranslationStatus()
        data object Success : TranslationStatus()
        data class Error(val message: String) : TranslationStatus()
    }
}
