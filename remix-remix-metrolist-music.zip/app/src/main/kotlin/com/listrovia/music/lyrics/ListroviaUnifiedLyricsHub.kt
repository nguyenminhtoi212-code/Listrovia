/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 *
 * ListroviaUnifiedLyricsHub.kt
 * Unified lyrics hub consolidating all parsers, models, helpers, translation,
 * romanization engines, and providers into a single resilient module.
 */

package com.listrovia.music.lyrics

import android.content.Context
import android.text.format.DateUtils
import android.util.Base64
import android.util.LruCache
import com.atilika.kuromoji.ipadic.Tokenizer
import com.github.promeg.pinyinhelper.Pinyin
import com.listrovia.innertube.WatchEndpoint
import com.listrovia.innertube.YouTube
import com.listrovia.music.api.DeepLService
import com.listrovia.music.api.MistralService
import com.listrovia.music.api.OpenRouterModelManager
import com.listrovia.music.api.OpenRouterService
import com.listrovia.music.api.OpenRouterStreamingService
import com.listrovia.music.constants.EnableBetterLyricsKey
import com.listrovia.music.constants.EnableKugouKey
import com.listrovia.music.constants.EnableLrcLibKey
import com.listrovia.music.constants.EnableLyricsPlus
import com.listrovia.music.constants.EnablePaxsenixKey
import com.listrovia.music.constants.EnableSimpMusicKey
import com.listrovia.music.constants.EnableZemerKey
import com.listrovia.music.constants.LyricsProviderOrderKey
import com.listrovia.music.db.MusicDatabase
import com.listrovia.music.db.entities.LyricsEntity
import com.listrovia.music.db.entities.LyricsEntity.Companion.LYRICS_NOT_FOUND
import com.listrovia.music.db.entities.SongEntity
import com.listrovia.music.models.MediaMetadata
import com.listrovia.music.utils.NetworkConnectivityObserver
import com.listrovia.music.utils.dataStore
import com.listrovia.music.utils.get
import com.listrovia.music.utils.reportException
import dagger.hilt.android.qualifiers.ApplicationContext
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.defaultRequest
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.parameter
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.http.contentType
import io.ktor.http.isSuccess
import io.ktor.serialization.kotlinx.json.json
import java.io.ByteArrayInputStream
import java.net.URLEncoder
import java.util.Locale
import java.util.Stack
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger
import java.util.regex.Pattern
import javax.inject.Inject
import javax.xml.parsers.SAXParserFactory
import kotlin.math.abs
import kotlin.random.Random
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.xml.sax.Attributes
import org.xml.sax.helpers.DefaultHandler
import timber.log.Timber

// ============================================================================
// [LYRICS ENTRY & WORD TIMESTAMPS] Source: LyricsEntry.kt
// ============================================================================

data class WordTimestamp(
    val text: String,
    val startTime: Double,
    val endTime: Double,
    val hasTrailingSpace: Boolean = true
)

data class LyricsEntry(
    val time: Long,
    val text: String,
    val words: List<WordTimestamp>? = null,
    val romanizedTextFlow: MutableStateFlow<String?> = MutableStateFlow(null),
    val translatedTextFlow: MutableStateFlow<String?> = MutableStateFlow(null),
    val agent: String? = null,
    val isBackground: Boolean = false
) : Comparable<LyricsEntry> {
    override fun compareTo(other: LyricsEntry): Int = (time - other.time).toInt()

    companion object {
        val HEAD_LYRICS_ENTRY = LyricsEntry(0L, "")
    }
}

// ============================================================================
// [LYRICS FORMAT DETECTOR] Source: LyricsFormat.kt
// ============================================================================

private val LRC_TIMESTAMP_HINT = Regex("""\[\d{1,2}:\d{2}""")

/**
 * Whether raw lyrics text appears to be time-synced (LRC-style), including when a BOM or
 * leading blank lines precede the first `[mm:ss.xx]` tag.
 */
fun lyricsTextLooksSynced(lyrics: String?): Boolean {
    if (lyrics.isNullOrBlank()) return false
    val t = lyrics.trim().removePrefix("\uFEFF").trimStart()
    if (t.startsWith('[')) return true
    return LRC_TIMESTAMP_HINT.containsMatchIn(t.take(4096))
}

// ============================================================================
// [LRC PARSER & TIMESTAMPS] Source: LyricParser.kt
// ============================================================================

/**
 * Structured metadata extracted from .lrc file header tags.
 * Supports standard tags ([ar:], [ti:], [al:], [by:], [offset:], [length:]) as well as custom tags.
 */
data class LrcMetadata(
    val artist: String? = null,
    val title: String? = null,
    val album: String? = null,
    val author: String? = null,
    val creator: String? = null,
    val fileOffset: Long = 0L,
    val length: String? = null,
    val program: String? = null,
    val version: String? = null,
    val language: String? = null,
    val availableLanguages: List<String> = emptyList(),
    val customTags: Map<String, String> = emptyMap()
) {
    val isNotEmpty: Boolean
        get() = !artist.isNullOrBlank() ||
                !title.isNullOrBlank() ||
                !album.isNullOrBlank() ||
                !author.isNullOrBlank() ||
                !creator.isNullOrBlank() ||
                fileOffset != 0L ||
                !length.isNullOrBlank() ||
                !language.isNullOrBlank() ||
                availableLanguages.isNotEmpty() ||
                customTags.isNotEmpty()

    val isEmpty: Boolean
        get() = !isNotEmpty

    /**
     * Returns a concise display credit combining title, artist, and creator.
     */
    fun getFormattedCredit(): String? {
        val parts = mutableListOf<String>()
        if (!title.isNullOrBlank()) parts.add(title)
        if (!artist.isNullOrBlank()) parts.add(artist)
        if (!creator.isNullOrBlank() && creator != artist) parts.add("by $creator")
        return if (parts.isNotEmpty()) parts.joinToString(" • ") else null
    }

    /**
     * Converts metadata back to map representation.
     */
    fun toMap(): Map<String, String> {
        val map = mutableMapOf<String, String>()
        artist?.let { map["ar"] = it }
        title?.let { map["ti"] = it }
        album?.let { map["al"] = it }
        author?.let { map["au"] = it }
        creator?.let { map["by"] = it }
        if (fileOffset != 0L) map["offset"] = fileOffset.toString()
        length?.let { map["length"] = it }
        program?.let { map["re"] = it }
        version?.let { map["ve"] = it }
        language?.let { map["lang"] = it }
        if (availableLanguages.isNotEmpty()) map["languages"] = availableLanguages.joinToString(",")
        map.putAll(customTags)
        return map
    }
}

/**
 * Result data class when parsing an LRC file with metadata.
 */
data class ParsedLyrics(
    val entries: List<LyricsEntry>,
    val metadata: LrcMetadata = LrcMetadata(),
    val rawMetadata: Map<String, String> = emptyMap(),
    val isSynced: Boolean = false
)

/**
 * Utility class that handles .lrc file formats, parsing, serializing,
 * metadata extraction, and mapping playback timestamps to lyric lines.
 */
object LyricParser {

    private val TIMESTAMP_REGEX = Pattern.compile("\\[(\\d{1,2}):(\\d{2})(?:[.:](\\d{2,3}))?\\]")
    private val METADATA_TAG_REGEX = Pattern.compile("^\\[(ti|ar|al|au|by|offset|length|re|ve|tool|[a-zA-Z0-9_-]+):([^\\]]*)\\]$", Pattern.CASE_INSENSITIVE)
    private val AGENT_TAG_REGEX = Pattern.compile("\\{agent:([^}]+)\\}", Pattern.CASE_INSENSITIVE)
    private val BG_TAG_REGEX = Pattern.compile("\\{bg\\}", Pattern.CASE_INSENSITIVE)
    private val PIPE_WORD_BLOCK_REGEX = Pattern.compile("^<(.+)>$")
    private val INLINE_WORD_TAG_REGEX = Pattern.compile("<(\\d{1,2}):(\\d{2})(?:[.:](\\d{2,3}))?>")

    /**
     * Parses a raw LRC string into a list of sorted [LyricsEntry].
     * Supports standard LRC, multi-timestamp lines, TTML pipe word timings, and enhanced LRC.
     * @param lrcContent Raw LRC text.
     * @param userOffsetMs Additional user-configured offset in milliseconds.
     */
    fun parse(lrcContent: String, userOffsetMs: Long = 0L): List<LyricsEntry> {
        return parseWithMetadata(lrcContent, userOffsetMs).entries
    }

    /**
     * Extracts only the metadata tags from an LRC string without parsing all lyric lines.
     */
    fun extractMetadata(lrcContent: String): LrcMetadata {
        if (lrcContent.isBlank()) return LrcMetadata()
        val rawMap = mutableMapOf<String, String>()
        for (line in lrcContent.lines()) {
            val trimmed = line.trim()
            if (trimmed.isEmpty()) continue
            if (!trimmed.startsWith("[")) break
            val metaMatcher = METADATA_TAG_REGEX.matcher(trimmed)
            if (metaMatcher.matches()) {
                val key = metaMatcher.group(1)?.lowercase(Locale.ROOT) ?: ""
                val value = metaMatcher.group(2)?.trim() ?: ""
                rawMap[key] = value
            } else if (TIMESTAMP_REGEX.matcher(trimmed).find()) {
                break
            }
        }
        return buildLrcMetadata(rawMap)
    }

    /**
     * Parses an LRC string into [ParsedLyrics] containing sorted entries, structured [LrcMetadata], and sync state.
     * @param lrcContent Raw LRC text.
     * @param userOffsetMs Additional user-configured offset in milliseconds.
     */
    fun parseWithMetadata(lrcContent: String, userOffsetMs: Long = 0L): ParsedLyrics {
        if (lrcContent.isBlank()) {
            return ParsedLyrics(emptyList(), LrcMetadata(), emptyMap(), false)
        }

        val rawMetadata = mutableMapOf<String, String>()
        val rawEntries = mutableListOf<LyricsEntry>()
        var fileOffsetMs = 0L

        // Fast unescape if wrapped in quotes or contains escape chars
        val cleanContent = unescape(lrcContent)
        val lines = cleanContent.lines()

        var currentLineIndex = 0
        while (currentLineIndex < lines.size) {
            val rawLine = lines[currentLineIndex].trim()
            if (rawLine.isEmpty()) {
                currentLineIndex++
                continue
            }

            // Check metadata tag (e.g. [ar:Artist], [ti:Title], [offset:500])
            val metaMatcher = METADATA_TAG_REGEX.matcher(rawLine)
            if (metaMatcher.matches()) {
                val key = metaMatcher.group(1)?.lowercase(Locale.ROOT) ?: ""
                val value = metaMatcher.group(2)?.trim() ?: ""
                rawMetadata[key] = value
                if (key == "offset") {
                    fileOffsetMs = value.toLongOrNull() ?: 0L
                }
                currentLineIndex++
                continue
            }

            // Check for pipe word-level block (<word:start:end|...>) on subsequent line
            var wordTimings: List<WordTimestamp>? = null
            if (currentLineIndex + 1 < lines.size) {
                val nextLine = lines[currentLineIndex + 1].trim()
                val pipeMatcher = PIPE_WORD_BLOCK_REGEX.matcher(nextLine)
                if (pipeMatcher.matches()) {
                    val inner = pipeMatcher.group(1) ?: ""
                    wordTimings = parsePipeWordTimings(inner)
                    currentLineIndex++ // consume the word timings line
                }
            }

            // Parse timestamp tags and text from current line
            val parsedLines = parseLrcLine(rawLine, wordTimings)
            if (parsedLines.isNotEmpty()) {
                rawEntries.addAll(parsedLines)
            } else if (rawEntries.isEmpty() && !rawLine.startsWith("[")) {
                // If the entire text has no timestamps (plain text lyrics), generate sequential entries
                rawEntries.add(LyricsEntry(rawEntries.size * 1000L, rawLine))
            }

            currentLineIndex++
        }

        val totalOffset = fileOffsetMs + userOffsetMs

        // Apply total offset if present
        val finalEntries = if (totalOffset != 0L) {
            rawEntries.map { entry ->
                entry.copy(time = maxOf(0L, entry.time + totalOffset))
            }
        } else {
            rawEntries
        }

        val sortedEntries = finalEntries.sortedBy { it.time }
        val isSynced = sortedEntries.any { it.time > 0L } || (sortedEntries.size > 1 && sortedEntries.first().time != sortedEntries.last().time)

        val metadata = buildLrcMetadata(rawMetadata)

        return ParsedLyrics(
            entries = sortedEntries,
            metadata = metadata,
            rawMetadata = rawMetadata,
            isSynced = isSynced
        )
    }

    private fun buildLrcMetadata(rawMap: Map<String, String>): LrcMetadata {
        val custom = mutableMapOf<String, String>()
        var artist: String? = null
        var title: String? = null
        var album: String? = null
        var author: String? = null
        var creator: String? = null
        var offset = 0L
        var length: String? = null
        var program: String? = null
        var version: String? = null
        var language: String? = null
        var availableLanguages = emptyList<String>()

        rawMap.forEach { (k, v) ->
            when (k.lowercase(Locale.ROOT)) {
                "ar" -> artist = v
                "ti" -> title = v
                "al" -> album = v
                "au" -> author = v
                "by" -> creator = v
                "offset" -> offset = v.toLongOrNull() ?: 0L
                "length" -> length = v
                "re", "tool" -> program = v
                "ve" -> version = v
                "lang", "language", "lan" -> language = v
                "languages", "langs" -> {
                    availableLanguages = v.split(",", ";", "/", "|").map { it.trim() }.filter { it.isNotEmpty() }
                }
                else -> custom[k] = v
            }
        }

        return LrcMetadata(
            artist = artist,
            title = title,
            album = album,
            author = author,
            creator = creator,
            fileOffset = offset,
            length = length,
            program = program,
            version = version,
            language = language,
            availableLanguages = availableLanguages,
            customTags = custom
        )
    }

    /**
     * Parses a single line that may contain one or multiple timestamps.
     */
    private fun parseLrcLine(line: String, externalWords: List<WordTimestamp>?): List<LyricsEntry> {
        val timestamps = mutableListOf<Long>()
        val tsMatcher = TIMESTAMP_REGEX.matcher(line)
        var lastEnd = 0

        while (tsMatcher.find()) {
            val min = tsMatcher.group(1)?.toLongOrNull() ?: 0L
            val sec = tsMatcher.group(2)?.toLongOrNull() ?: 0L
            val fracStr = tsMatcher.group(3)
            val ms = when {
                fracStr == null -> 0L
                fracStr.length == 2 -> (fracStr.toLongOrNull() ?: 0L) * 10L
                fracStr.length == 3 -> fracStr.toLongOrNull() ?: 0L
                else -> (fracStr.take(3).toLongOrNull() ?: 0L)
            }
            val timeMs = min * 60_000L + sec * 1_000L + ms
            timestamps.add(timeMs)
            lastEnd = tsMatcher.end()
        }

        if (timestamps.isEmpty()) return emptyList()

        var textPart = line.substring(lastEnd).trim()

        // Extract {agent:...} tag
        var agent: String? = null
        val agentMatcher = AGENT_TAG_REGEX.matcher(textPart)
        if (agentMatcher.find()) {
            agent = agentMatcher.group(1)
            textPart = agentMatcher.replaceAll("").trim()
        }

        // Extract {bg} tag
        var isBackground = false
        val bgMatcher = BG_TAG_REGEX.matcher(textPart)
        if (bgMatcher.find()) {
            isBackground = true
            textPart = bgMatcher.replaceAll("").trim()
        }

        // Check for inline enhanced LRC word timings: <00:12.34>word <00:13.00>word2
        val inlineWords = if (externalWords == null && INLINE_WORD_TAG_REGEX.matcher(textPart).find()) {
            parseInlineWordTimings(textPart)
        } else {
            null
        }

        val cleanedText = if (inlineWords != null) {
            cleanInlineTimestamps(textPart)
        } else {
            textPart
        }

        val wordsToUse = externalWords ?: inlineWords

        return timestamps.map { timeMs ->
            LyricsEntry(
                time = timeMs,
                text = cleanedText,
                words = wordsToUse,
                agent = agent,
                isBackground = isBackground
            )
        }
    }

    /**
     * Parses word timestamps formatted as <word:startTimeSec:endTimeSec|...>
     */
    private fun parsePipeWordTimings(raw: String): List<WordTimestamp> {
        val parts = raw.split('|')
        val list = mutableListOf<WordTimestamp>()
        for (part in parts) {
            val seg = part.split(':')
            if (seg.size >= 3) {
                val wordText = seg[0]
                val sTime = seg[1].toDoubleOrNull() ?: continue
                val eTime = seg[2].toDoubleOrNull() ?: continue
                list.add(
                    WordTimestamp(
                        text = wordText,
                        startTime = sTime,
                        endTime = eTime,
                        hasTrailingSpace = true
                    )
                )
            }
        }
        return list
    }

    /**
     * Parses inline word timestamps like: <00:01.20>Hello <00:02.00>World
     */
    private fun parseInlineWordTimings(text: String): List<WordTimestamp> {
        val words = mutableListOf<WordTimestamp>()
        val matcher = INLINE_WORD_TAG_REGEX.matcher(text)
        var lastTimeSec = 0.0
        var lastWord: String? = null

        while (matcher.find()) {
            val min = matcher.group(1)?.toLongOrNull() ?: 0L
            val sec = matcher.group(2)?.toLongOrNull() ?: 0L
            val fracStr = matcher.group(3)
            val ms = when {
                fracStr == null -> 0L
                fracStr.length == 2 -> (fracStr.toLongOrNull() ?: 0L) * 10L
                fracStr.length == 3 -> fracStr.toLongOrNull() ?: 0L
                else -> (fracStr.take(3).toLongOrNull() ?: 0L)
            }
            val timeSec = (min * 60_000L + sec * 1_000L + ms) / 1000.0

            if (lastWord != null) {
                words.add(WordTimestamp(lastWord, lastTimeSec, timeSec, hasTrailingSpace = true))
            }

            val textStart = matcher.end()
            val nextTag = text.indexOf('<', textStart)
            val currentWord = if (nextTag != -1) {
                text.substring(textStart, nextTag).trim()
            } else {
                text.substring(textStart).trim()
            }

            lastWord = currentWord
            lastTimeSec = timeSec
        }

        if (!lastWord.isNullOrEmpty()) {
            words.add(WordTimestamp(lastWord, lastTimeSec, lastTimeSec + 0.5, hasTrailingSpace = true))
        }

        return words
    }

    /**
     * Strips inline timestamp tags <mm:ss.xx> from text.
     */
    private fun cleanInlineTimestamps(text: String): String {
        return text.replace(INLINE_WORD_TAG_REGEX.toRegex(), "").trim()
    }

    /**
     * Fast binary search to find the active lyric line index for a given playback position in milliseconds.
     * Returns the index in [entries], or -1 if entries is empty or playback position is before the first line.
     * @param entries Sorted lyric lines.
     * @param positionMs Current audio playback position in milliseconds.
     * @param userOffsetMs Additional fine-tune offset applied to position (effectivePosition = positionMs + userOffsetMs).
     */
    fun findCurrentLineIndex(entries: List<LyricsEntry>, positionMs: Long, userOffsetMs: Long = 0L): Int {
        if (entries.isEmpty()) return -1
        val effectivePosition = positionMs + userOffsetMs
        if (effectivePosition < entries.first().time) return -1

        var low = 0
        var high = entries.size - 1
        var result = -1

        while (low <= high) {
            val mid = (low + high) ushr 1
            val entryTime = entries[mid].time
            if (entryTime <= effectivePosition) {
                result = mid
                low = mid + 1
            } else {
                high = mid - 1
            }
        }
        return result
    }

    /**
     * Returns all active lyric line indices at [positionMs], including simultaneous vocal tracks/background lines.
     */
    fun findActiveLineIndices(
        entries: List<LyricsEntry>,
        positionMs: Long,
        userOffsetMs: Long = 0L,
        toleranceMs: Long = 3000L
    ): List<Int> {
        val primaryIdx = findCurrentLineIndex(entries, positionMs, userOffsetMs)
        if (primaryIdx == -1) return emptyList()

        val primary = entries[primaryIdx]
        val active = mutableListOf(primaryIdx)

        // Check neighboring lines with identical or close timestamps (background vocals / multi-agent)
        var i = primaryIdx - 1
        while (i >= 0 && Math.abs(entries[i].time - primary.time) <= 100L) {
            active.add(0, i)
            i--
        }

        var j = primaryIdx + 1
        while (j < entries.size && Math.abs(entries[j].time - primary.time) <= 100L) {
            active.add(j)
            j++
        }

        return active
    }

    /**
     * Gets the lyric entry at the specified playback position.
     */
    fun getLineAt(entries: List<LyricsEntry>, positionMs: Long, userOffsetMs: Long = 0L): LyricsEntry? {
        val index = findCurrentLineIndex(entries, positionMs, userOffsetMs)
        return if (index in entries.indices) entries[index] else null
    }

    /**
     * Calculates the progress ratio (0.0 to 1.0) of the current lyric line based on the next line timestamp.
     */
    fun getLineProgress(
        entries: List<LyricsEntry>,
        currentIndex: Int,
        positionMs: Long,
        userOffsetMs: Long = 0L
    ): Float {
        if (currentIndex !in entries.indices) return 0f
        val current = entries[currentIndex]
        val effectivePosition = positionMs + userOffsetMs
        if (effectivePosition < current.time) return 0f

        val nextTime = if (currentIndex + 1 < entries.size) {
            entries[currentIndex + 1].time
        } else {
            current.time + 4000L
        }

        val duration = nextTime - current.time
        if (duration <= 0L) return 1f

        return ((effectivePosition - current.time).toFloat() / duration).coerceIn(0f, 1f)
    }

    /**
     * Formats a list of [LyricsEntry] and optional metadata back into standard .lrc file text.
     */
    fun formatToLrc(entries: List<LyricsEntry>, metadata: LrcMetadata? = null): String {
        val sb = StringBuilder()

        metadata?.let { meta ->
            meta.title?.let { sb.append("[ti:").append(it).append("]\n") }
            meta.artist?.let { sb.append("[ar:").append(it).append("]\n") }
            meta.album?.let { sb.append("[al:").append(it).append("]\n") }
            meta.creator?.let { sb.append("[by:").append(it).append("]\n") }
            meta.author?.let { sb.append("[au:").append(it).append("]\n") }
            if (meta.fileOffset != 0L) sb.append("[offset:").append(meta.fileOffset).append("]\n")
            meta.length?.let { sb.append("[length:").append(it).append("]\n") }
            meta.program?.let { sb.append("[re:").append(it).append("]\n") }
            meta.version?.let { sb.append("[ve:").append(it).append("]\n") }
            meta.customTags.forEach { (k, v) ->
                sb.append('[').append(k).append(':').append(v).append("]\n")
            }
        }

        for (entry in entries) {
            sb.append(formatTime(entry.time))
            if (entry.isBackground) {
                sb.append("{bg}")
            }
            if (!entry.agent.isNullOrBlank()) {
                sb.append("{agent:").append(entry.agent).append('}')
            }
            sb.append(entry.text).append('\n')

            val words = entry.words
            if (!words.isNullOrEmpty()) {
                sb.append('<')
                words.forEachIndexed { idx, w ->
                    sb.append(w.text).append(':').append(w.startTime).append(':').append(w.endTime)
                    if (idx < words.size - 1) sb.append('|')
                }
                sb.append(">\n")
            }
        }

        return sb.toString()
    }

    /**
     * Formats a millisecond timestamp to [mm:ss.xx]
     */
    fun formatTime(timeMs: Long): String {
        val totalSec = maxOf(0L, timeMs) / 1000
        val min = totalSec / 60
        val sec = totalSec % 60
        val hundredths = (maxOf(0L, timeMs) % 1000) / 10
        return String.format(Locale.US, "[%02d:%02d.%02d]", min, sec, hundredths)
    }

    /**
     * Unescape HTML / escape codes in raw LRC string.
     */
    private fun unescape(s: String): String {
        if (!s.contains('\\') && !s.startsWith("\"") && !s.contains('&')) {
            return s
        }
        val unquoted = s.trim().removePrefix("\"").removeSuffix("\"")
        val sb = StringBuilder(unquoted.length)
        var i = 0
        while (i < unquoted.length) {
            val c = unquoted[i]
            if (c == '\\' && i + 1 < unquoted.length) {
                when (val next = unquoted[i + 1]) {
                    '\\' -> sb.append('\\')
                    'n' -> sb.append('\n')
                    'r' -> sb.append('\r')
                    't' -> sb.append('\t')
                    else -> sb.append(c).append(next)
                }
                i += 2
            } else {
                sb.append(c)
                i++
            }
        }
        return sb.toString()
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&apos;", "'")
    }
}

// ============================================================================
// [LYRICS PROVIDER INTERFACE] Source: LyricsProvider.kt
// ============================================================================

interface LyricsProvider {
    val name: String

    fun isEnabled(context: Context): Boolean

    suspend fun getLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String? = null,
    ): Result<String>

    suspend fun getAllLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String? = null,
        callback: (String) -> Unit,
    ) {
        getLyrics(context, id, title, artist, duration, album).onSuccess(callback)
    }
}

// ============================================================================
// [LYRICS RESYNC HELPER] Source: LyricsResyncHelper.kt
// ============================================================================

object LyricsResyncHelper {
    private val _resyncTrigger = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val resyncTrigger: SharedFlow<Unit> = _resyncTrigger.asSharedFlow()

    fun triggerResync() {
        _resyncTrigger.tryEmit(Unit)
    }
}

// ============================================================================
// [BETTER LYRICS PROVIDER & TTML PARSER] Source: providers/BetterLyricsProvider.kt
// ============================================================================

// --- Data Models ---

@Serializable
data class TTMLResponse(
    val ttml: String? = null,
)

@Serializable
data class SearchResponse(
    val results: List<Track>
)

@Serializable
data class Track(
    val title: String,
    val artist: String,
    val album: String? = null,
    val duration: Double,
    val lyrics: Lyrics? = null
)

@Serializable
data class Lyrics(
    val lines: List<Line>
)

@Serializable
data class Line(
    val text: String,
    val startTime: Double,
    val words: List<Word>? = null
)

@Serializable
data class Word(
    val text: String,
    val startTime: Double,
    val endTime: Double
)

data class LyricLine(
    val startTime: Double,
    val endTime: Double,
    val text: String,
    val agent: String?,
    val isBackground: Boolean,
    val words: List<Word>
)

// --- BetterLyrics HTTP Client & Service ---

object BetterLyrics {
    private const val TAG = "BetterLyrics"

    private val client by lazy {
        HttpClient(OkHttp) {
            install(ContentNegotiation) {
                json(
                    Json {
                        isLenient = true
                        ignoreUnknownKeys = true
                    },
                )
            }

            install(HttpTimeout) {
                requestTimeoutMillis = 15000
                connectTimeoutMillis = 10000
                socketTimeoutMillis = 15000
            }

            defaultRequest {
                url("https://lyrics-api.boidu.dev")
                header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                header("Accept", "application/json")
            }

            expectSuccess = false
        }
    }

    private suspend fun fetchTTML(
        artist: String,
        title: String,
        duration: Int = -1,
        album: String? = null,
    ): String? = try {
        Timber.tag(TAG).d("Fetching TTML for: $title by $artist (dur=$duration, album=$album)")
        val response = client.get("/getLyrics") {
            parameter("s", title)
            parameter("a", artist)
            if (duration > 0) {
                parameter("d", duration)
            }
            if (!album.isNullOrBlank()) {
                parameter("al", album)
            }
        }
        if (response.status == HttpStatusCode.OK) {
            val ttml = response.body<TTMLResponse>().ttml?.trim()?.takeIf { it.isNotEmpty() }
            ttml
        } else {
            Timber.tag(TAG).w("API returned status: ${response.status}")
            null
        }
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Timber.tag(TAG).e(e, "Exception during fetchTTML")
        null
    }

    suspend fun getLyrics(
        title: String,
        artist: String,
        duration: Int,
        album: String? = null,
    ): Result<String> = runCatching {
        val ttml = fetchTTML(artist, title, duration, album)
            ?: throw IllegalStateException("Lyrics unavailable")

        val lrc = TTMLParser.parse(ttml)
        if (lrc.isBlank()) {
            throw IllegalStateException("Failed to parse lyrics")
        }
        lrc
    }
}

// --- BetterLyrics Provider (LyricsProvider Implementation) ---

object BetterLyricsProvider : LyricsProvider {
    override val name = "BetterLyrics"

    override fun isEnabled(context: Context): Boolean = context.dataStore[EnableBetterLyricsKey] ?: true

    override suspend fun getLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): Result<String> = BetterLyrics.getLyrics(title, artist, duration, album)

    override suspend fun getAllLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
        callback: (String) -> Unit,
    ) {
        getLyrics(context, id, title, artist, duration, album).onSuccess(callback)
    }
}

// --- TTML Parser ---

object TTMLParser {

    private sealed interface SaxNode {
        class Text(var content: String) : SaxNode
        class Span(val element: SaxSpanElement) : SaxNode
    }

    private class SaxPElement(
        val agent: String?,
        val role: String?,
        val begin: String,
        val end: String
    ) {
        val contentNodes = mutableListOf<SaxNode>()
    }

    private class SaxSpanElement(
        val role: String?,
        val begin: String,
        val end: String
    ) {
        val contentNodes = mutableListOf<SaxNode>()
    }

    /**
     * Parses TTML XML into standard LRC string.
     */
    fun parse(ttml: String): String {
        val lines = parseTTML(ttml)
        return if (lines.isNotEmpty()) toLRC(lines).trim() else ""
    }

    /**
     * Parses TTML XML string into a list of [LyricLine] using SAX parser.
     */
    fun parseTTML(xmlString: String): List<LyricLine> {
        try {
            val factory = SAXParserFactory.newInstance().apply {
                isNamespaceAware = true
            }
            val parser = factory.newSAXParser()
            val handler = TTMLHandler()
            parser.parse(ByteArrayInputStream(xmlString.toByteArray(Charsets.UTF_8)), handler)
            return handler.parsedLines
        } catch (e: Exception) {
            Timber.e(e, "Failed to parse TTML via SAX")
            return emptyList()
        }
    }

    private class TTMLHandler : DefaultHandler() {
        var lyricOffset = 0.0
        val agentTypes = mutableMapOf<String, String>()
        val parsedLines = mutableListOf<LyricLine>()

        private var currentP: SaxPElement? = null
        private val spanStack = Stack<SaxSpanElement>()

        override fun startElement(
            uri: String,
            localName: String,
            qName: String,
            attributes: Attributes
        ) {
            val name = localName.ifEmpty { qName.substringAfter(':') }

            when (name) {
                "audio" -> {
                    val offsetStr = getAttribute(attributes, "lyricOffset")
                    if (offsetStr.isNotEmpty()) {
                        lyricOffset = offsetStr.toDoubleOrNull() ?: 0.0
                    }
                }
                "agent" -> {
                    val id = getAttribute(attributes, "id", "http://www.w3.org/XML/1998/namespace")
                        .ifEmpty { getAttribute(attributes, "id") }
                    val type = getAttribute(attributes, "type")
                    if (id.isNotEmpty()) {
                        agentTypes[id] = type
                    } else {
                        Timber.w("Agent element found with missing ID attribute")
                    }
                }
                "p" -> {
                    if (currentP != null) {
                        Timber.w("Malformed nesting: <p> element started inside an already active paragraph.")
                    }
                    val agent = getAttribute(attributes, "agent", "http://www.w3.org/ns/ttml#metadata")
                        .ifEmpty { getAttribute(attributes, "agent") }
                        .ifEmpty { null }
                    val role = getAttribute(attributes, "role", "http://www.w3.org/ns/ttml#metadata")
                        .ifEmpty { getAttribute(attributes, "role") }
                        .ifEmpty { null }
                    val begin = getAttribute(attributes, "begin", "http://www.w3.org/ns/ttml#parameter")
                        .ifEmpty { getAttribute(attributes, "begin") }
                    val end = getAttribute(attributes, "end", "http://www.w3.org/ns/ttml#parameter")
                        .ifEmpty { getAttribute(attributes, "end") }

                    currentP = SaxPElement(agent, role, begin, end)
                    spanStack.clear()
                }
                "span" -> {
                    val p = currentP
                    if (p == null) {
                        Timber.w("Malformed TTML: <span> found outside a <p> container.")
                    } else {
                        val role = getAttribute(attributes, "role", "http://www.w3.org/ns/ttml#metadata")
                            .ifEmpty { getAttribute(attributes, "role") }
                            .ifEmpty { null }
                        val begin = getAttribute(attributes, "begin", "http://www.w3.org/ns/ttml#parameter")
                            .ifEmpty { getAttribute(attributes, "begin") }
                        val end = getAttribute(attributes, "end", "http://www.w3.org/ns/ttml#parameter")
                            .ifEmpty { getAttribute(attributes, "end") }

                        val newSpan = SaxSpanElement(role, begin, end)
                        if (spanStack.isNotEmpty()) {
                            spanStack.peek().contentNodes.add(SaxNode.Span(newSpan))
                        } else {
                            p.contentNodes.add(SaxNode.Span(newSpan))
                        }
                        spanStack.push(newSpan)
                    }
                }
            }
        }

        override fun characters(ch: CharArray, start: Int, length: Int) {
            val content = String(ch, start, length)
            val p = currentP ?: return

            val targetNodes = if (spanStack.isNotEmpty()) {
                spanStack.peek().contentNodes
            } else {
                p.contentNodes
            }

            if (targetNodes.isNotEmpty() && targetNodes.last() is SaxNode.Text) {
                val lastText = targetNodes.last() as SaxNode.Text
                lastText.content += content
            } else {
                targetNodes.add(SaxNode.Text(content))
            }
        }

        override fun endElement(uri: String, localName: String, qName: String) {
            val name = localName.ifEmpty { qName.substringAfter(':') }

            when (name) {
                "p" -> {
                    val p = currentP
                    if (p != null) {
                        processParagraph(p)
                        currentP = null
                    } else {
                        Timber.w("Malformed XML: </p> found without matching <p>.")
                    }
                }
                "span" -> {
                    if (spanStack.isNotEmpty()) {
                        spanStack.pop()
                    } else {
                        Timber.w("Malformed XML: </span> found without matching <span>.")
                    }
                }
            }
        }

        private fun getAttribute(attributes: Attributes, localName: String, uri: String? = null): String {
            if (uri != null) {
                val valUri = attributes.getValue(uri, localName)
                if (!valUri.isNullOrEmpty()) return valUri
            }
            val valLocal = attributes.getValue(localName)
            if (!valLocal.isNullOrEmpty()) return valLocal

            for (i in 0 until attributes.length) {
                val qName = attributes.getQName(i)
                val nameOnly = qName.substringAfter(':')
                if (nameOnly == localName) {
                    val value = attributes.getValue(i)
                    if (!value.isNullOrEmpty()) return value
                }
            }
            return ""
        }

        private fun getRecursiveText(span: SaxSpanElement): String {
            val sb = StringBuilder()
            for (node in span.contentNodes) {
                when (node) {
                    is SaxNode.Text -> sb.append(node.content)
                    is SaxNode.Span -> sb.append(getRecursiveText(node.element))
                }
            }
            return sb.toString()
        }

        private fun getRecursiveTextOfNode(node: SaxNode): String {
            return when (node) {
                is SaxNode.Text -> node.content
                is SaxNode.Span -> getRecursiveText(node.element)
            }
        }

        private fun processParagraph(p: SaxPElement) {
            val pAgent = p.agent
            val pRole = p.role
            val isPBackground = pRole == "x-bg"

            if (pAgent != null && !agentTypes.containsKey(pAgent)) {
                Timber.w("Paragraph refers to an undefined agent ID: '$pAgent'")
            }

            val rawSpans = p.contentNodes.filterIsInstance<SaxNode.Span>().map { it.element }
            val filteredSpans = rawSpans.filter { span ->
                val role = span.role
                role != "x-roman" && role != "x-translation"
            }

            val pText = p.contentNodes.joinToString("") { getRecursiveTextOfNode(it) }

            if (filteredSpans.isEmpty() && pText.trim().isEmpty()) {
                return
            }

            val pBeginStr = p.begin
            val pEndStr = p.end

            val pStart = if (pBeginStr.isNotEmpty()) {
                val time = parseTime(pBeginStr)
                if (time == 0.0 && pBeginStr != "0" && pBeginStr != "0s" && pBeginStr != "00:00:00") {
                    Timber.w("Malformed begin time format in <p>: '$pBeginStr'")
                }
                time + lyricOffset
            } else null

            val pEnd = if (pEndStr.isNotEmpty()) {
                val time = parseTime(pEndStr)
                if (time == 0.0 && pEndStr != "0" && pEndStr != "0s" && pEndStr != "00:00:00") {
                    Timber.w("Malformed end time format in <p>: '$pEndStr'")
                }
                time + lyricOffset
            } else null

            val wordsList = mutableListOf<Word>()
            val bgWords = mutableListOf<Word>()

            for (span in filteredSpans) {
                val spanRole = span.role

                if (spanRole == "x-bg") {
                    val innerSpans = span.contentNodes.filterIsInstance<SaxNode.Span>().map { it.element }.filter { inner ->
                        val innerRole = inner.role
                        innerRole != "x-roman" && innerRole != "x-translation"
                    }

                    if (innerSpans.isNotEmpty()) {
                        for (inner in innerSpans) {
                            val wordText = inner.contentNodes.filterIsInstance<SaxNode.Text>().joinToString("") { it.content }.trim()
                            if (wordText.isNotEmpty()) {
                                val sTimeStr = inner.begin
                                val eTimeStr = inner.end
                                val sTime = parseTime(sTimeStr).takeIf { sTimeStr.isNotEmpty() }?.plus(lyricOffset) ?: pStart ?: lyricOffset
                                val eTime = parseTime(eTimeStr).takeIf { eTimeStr.isNotEmpty() }?.plus(lyricOffset) ?: pEnd ?: lyricOffset
                                bgWords.add(Word(wordText, sTime, eTime))
                            }
                        }
                    } else {
                        val wordText = span.contentNodes.filterIsInstance<SaxNode.Text>().joinToString("") { it.content }.trim()
                        if (wordText.isNotEmpty()) {
                            val sTimeStr = span.begin
                            val eTimeStr = span.end
                            val sTime = parseTime(sTimeStr).takeIf { sTimeStr.isNotEmpty() }?.plus(lyricOffset) ?: pStart ?: lyricOffset
                            val eTime = parseTime(eTimeStr).takeIf { eTimeStr.isNotEmpty() }?.plus(lyricOffset) ?: pEnd ?: lyricOffset
                            bgWords.add(Word(wordText, sTime, eTime))
                        }
                    }
                } else {
                    val innerSpans = span.contentNodes.filterIsInstance<SaxNode.Span>().map { it.element }.filter { inner ->
                        val innerRole = inner.role
                        innerRole != "x-roman" && innerRole != "x-translation"
                    }

                    if (innerSpans.isNotEmpty()) {
                        for (inner in innerSpans) {
                            val wordText = inner.contentNodes.filterIsInstance<SaxNode.Text>().joinToString("") { it.content }.trim()
                            if (wordText.isNotEmpty()) {
                                val sTimeStr = inner.begin
                                val eTimeStr = inner.end
                                if (sTimeStr.isNotEmpty() || eTimeStr.isNotEmpty()) {
                                    val sTime = parseTime(sTimeStr).takeIf { sTimeStr.isNotEmpty() }?.plus(lyricOffset) ?: pStart ?: lyricOffset
                                    val eTime = parseTime(eTimeStr).takeIf { eTimeStr.isNotEmpty() }?.plus(lyricOffset) ?: pEnd ?: lyricOffset
                                    wordsList.add(Word(wordText, sTime, eTime))
                                }
                            }
                        }
                    } else {
                        val wordText = span.contentNodes.filterIsInstance<SaxNode.Text>().joinToString("") { it.content }.trim()
                        if (wordText.isNotEmpty()) {
                            val sTimeStr = span.begin
                            val eTimeStr = span.end
                            if (sTimeStr.isNotEmpty() || eTimeStr.isNotEmpty()) {
                                val sTime = parseTime(sTimeStr).takeIf { sTimeStr.isNotEmpty() }?.plus(lyricOffset) ?: pStart ?: lyricOffset
                                val eTime = parseTime(eTimeStr).takeIf { eTimeStr.isNotEmpty() }?.plus(lyricOffset) ?: pEnd ?: lyricOffset
                                wordsList.add(Word(wordText, sTime, eTime))
                            }
                        }
                    }
                }
            }

            val mergedWordsList = mergeSyllables(wordsList)
            val mergedBgWordsList = mergeSyllables(bgWords)

            val finalStart = pStart ?: mergedWordsList.firstOrNull()?.startTime ?: mergedBgWordsList.firstOrNull()?.startTime ?: 0.0
            val finalEnd = pEnd ?: mergedWordsList.lastOrNull()?.endTime ?: mergedBgWordsList.lastOrNull()?.endTime ?: 0.0

            val lineText = if (mergedWordsList.isNotEmpty()) {
                mergedWordsList.joinToString(" ") { it.text }
            } else {
                pText.trim()
            }

            if (lineText.isNotEmpty()) {
                parsedLines.add(LyricLine(finalStart, finalEnd, lineText, pAgent, isPBackground, mergedWordsList))
            }

            if (mergedBgWordsList.isNotEmpty()) {
                val bgStart = mergedBgWordsList.minOf { it.startTime }
                val bgEnd = mergedBgWordsList.maxOf { it.endTime }
                val bgText = mergedBgWordsList.joinToString(" ") { it.text }
                parsedLines.add(LyricLine(bgStart, bgEnd, bgText, pAgent, true, mergedBgWordsList))
            }
        }

        private fun mergeSyllables(words: List<Word>): List<Word> {
            if (words.size < 2) return words
            val merged = mutableListOf<Word>()
            var current = words[0]
            for (i in 1 until words.size) {
                val next = words[i]
                if (Math.abs(current.endTime - next.startTime) < 0.001) {
                    current = Word(current.text + next.text, current.startTime, next.endTime)
                } else {
                    merged.add(current)
                    current = next
                }
            }
            merged.add(current)
            return merged
        }
    }

    private fun parseTime(time: String): Double {
        val t = time.trim()
        if (t.isEmpty()) return 0.0
        val c1 = t.indexOf(':')
        if (c1 != -1) {
            val c2 = t.lastIndexOf(':')
            return if (c1 == c2) {
                (t.substring(0, c1).toIntOrNull() ?: 0) * 60.0 + (t.substring(c1 + 1).toDoubleOrNull() ?: 0.0)
            } else {
                (t.substring(0, c1).toIntOrNull() ?: 0) * 3600.0 + (t.substring(c1 + 1, c2).toIntOrNull() ?: 0) * 60.0 + (t.substring(c2 + 1).toDoubleOrNull() ?: 0.0)
            }
        }
        if (t.endsWith("ms")) return (t.substring(0, t.length - 2).toDoubleOrNull() ?: 0.0) / 1000.0
        val s = if (t.endsWith("s") || t.endsWith("m") || t.endsWith("h")) t.substring(0, t.length - 1) else t
        val v = s.toDoubleOrNull() ?: 0.0
        return when {
            t.endsWith("m") -> v * 60.0
            t.endsWith("h") -> v * 3600.0
            else -> v
        }
    }

    fun toLRC(lines: List<LyricLine>): String {
        val agentMap = mutableMapOf<String, String>()

        // Phase 1: Preserve explicit v1, v2, v1000
        lines.forEach { line ->
            line.agent?.lowercase()?.let { raw ->
                if (raw == "v1" || raw == "v2" || raw == "v1000") {
                    agentMap[raw] = raw
                }
            }
        }

        // Phase 2: Map other agents to v1/v2 if available
        var nextNum = 1
        lines.forEach { line ->
            line.agent?.lowercase()?.let { raw ->
                if (!agentMap.containsKey(raw)) {
                    while (nextNum <= 2 && (agentMap.containsKey("v$nextNum") || agentMap.values.contains("v$nextNum"))) {
                        nextNum++
                    }
                    agentMap[raw] = if (nextNum <= 2) "v$nextNum" else "v1"
                }
            }
        }

        if (agentMap.containsKey("v1000") && agentMap.containsKey("v1")) {
            agentMap["v1000"] = "v2"
        }

        val hasBackgroundLine = lines.any { it.isBackground }
        val multi =
            agentMap.size > 1 ||
                (agentMap.size == 1 && !agentMap.containsKey("v1")) ||
                (hasBackgroundLine && agentMap.size == 1 && agentMap.containsKey("v1"))

        val sb = StringBuilder(lines.size * 128)
        var lastBg = false
        lines.forEach { line ->
            val time = formatLrcTime(line.startTime)
            val isBg = line.isBackground
            if (!isBg) lastBg = false

            val agentId = agentMap[line.agent?.lowercase()]
            val tag = when {
                isBg -> if (lastBg) "" else "{bg}"
                multi && agentId != null -> "{agent:$agentId}"
                else -> ""
            }
            if (isBg) lastBg = true

            sb.append(time).append(tag).append(line.text).append('\n')
            if (line.words.isNotEmpty()) {
                sb.append('<')
                line.words.forEachIndexed { i, w ->
                    sb.append(w.text).append(':').append(w.startTime).append(':').append(w.endTime)
                    if (i < line.words.lastIndex) sb.append('|')
                }
                sb.append(">\n")
            }
        }
        return sb.toString()
    }

    private fun formatLrcTime(time: Double): String {
        val ms = (time * 1000).toLong()
        val m = ms / 60000
        val s = (ms % 60000) / 1000
        val c = (ms % 1000) / 10
        val sb = StringBuilder(10)
        sb.append('[')
        if (m < 10) sb.append('0')
        sb.append(m).append(':')
        if (s < 10) sb.append('0')
        sb.append(s).append('.')
        if (c < 10) sb.append('0')
        sb.append(c).append(']')
        return sb.toString()
    }
}

// ============================================================================
// [KUGOU LYRICS PROVIDER] Source: providers/KuGouProvider.kt
// ============================================================================

data class Keyword(
    val title: String,
    val artist: String,
    val album: String? = null,
)

@Serializable
data class KuGouSearchSongResponse(
    val status: Int = 0,
    val errcode: Int = 0,
    val error: String = "",
    val data: SongData? = null,
) {
    @Serializable
    data class SongData(
        val info: List<SongInfo> = emptyList(),
    )

    @Serializable
    data class SongInfo(
        val duration: Int = 0,
        val hash: String = "",
    )
}

@Serializable
data class KuGouSearchLyricsResponse(
    val status: Int = 0,
    val info: String = "",
    val errcode: Int = 0,
    val errmsg: String = "",
    val expire: Int = 0,
    val candidates: List<Candidate> = emptyList(),
) {
    @Serializable
    data class Candidate(
        val id: Long = 0,
        @SerialName("product_from")
        val productFrom: String = "",
        val duration: Long = 0,
        val accesskey: String = "",
    )
}

@Serializable
data class KuGouDownloadLyricsResponse(
    val content: String = "",
)

/**
 * KuGou Lyrics Retrieval Engine
 */
object KuGou {
    private const val TAG = "KuGou"
    private const val PAGE_SIZE = 8
    private const val DURATION_TOLERANCE = 8

    var useTraditionalChinese: Boolean = false

    private val client by lazy {
        HttpClient(OkHttp) {
            install(ContentNegotiation) {
                val json = Json {
                    ignoreUnknownKeys = true
                    explicitNulls = false
                    encodeDefaults = true
                    isLenient = true
                }
                json(json)
                json(json, ContentType.Text.Html)
                json(json, ContentType.Text.Plain)
            }
            install(HttpTimeout) {
                requestTimeoutMillis = 15000
                connectTimeoutMillis = 10000
            }
            expectSuccess = false
        }
    }

    suspend fun getLyrics(
        title: String,
        artist: String,
        duration: Int,
        album: String? = null,
    ): Result<String> = runCatching {
        val keyword = generateKeyword(title, artist, album)
        val candidate = getLyricsCandidate(keyword, duration)
            ?: throw IllegalStateException("No lyrics candidate found for $title")

        val downloaded = downloadLyrics(candidate.id, candidate.accesskey)
        if (downloaded.content.isBlank()) {
            throw IllegalStateException("Empty lyrics content returned from KuGou")
        }

        val decoded = Base64.decode(downloaded.content, Base64.DEFAULT).decodeToString()
        decoded.normalizeLyrics().ifBlank {
            throw IllegalStateException("Normalized lyrics empty for $title")
        }
    }

    suspend fun getAllPossibleLyricsOptions(
        title: String,
        artist: String,
        duration: Int,
        album: String? = null,
        callback: (String) -> Unit,
    ) {
        try {
            val keyword = generateKeyword(title, artist, album)
            val songs = searchSongs(keyword)
            songs.data?.info?.forEach { song ->
                if (duration == -1 || abs(song.duration - duration) <= DURATION_TOLERANCE) {
                    val candidate = searchLyricsByHash(song.hash).candidates.firstOrNull()
                    if (candidate != null) {
                        runCatching {
                            val content = downloadLyrics(candidate.id, candidate.accesskey).content
                            if (content.isNotBlank()) {
                                val lyrics = Base64.decode(content, Base64.DEFAULT).decodeToString().normalizeLyrics()
                                if (lyrics.isNotBlank()) callback(lyrics)
                            }
                        }
                    }
                }
            }

            val keywordCandidates = searchLyricsByKeyword(keyword, duration).candidates
            keywordCandidates.forEach { candidate ->
                runCatching {
                    val content = downloadLyrics(candidate.id, candidate.accesskey).content
                    if (content.isNotBlank()) {
                        val lyrics = Base64.decode(content, Base64.DEFAULT).decodeToString().normalizeLyrics()
                        if (lyrics.isNotBlank()) callback(lyrics)
                    }
                }
            }
        } catch (e: Exception) {
            Timber.tag(TAG).w(e, "Error fetching all possible lyrics from KuGou")
        }
    }

    suspend fun getLyricsCandidate(
        keyword: Keyword,
        duration: Int,
    ): KuGouSearchLyricsResponse.Candidate? {
        val songResponse = searchSongs(keyword)
        songResponse.data?.info?.forEach { song ->
            if (duration == -1 || abs(song.duration - duration) <= DURATION_TOLERANCE) {
                val candidate = searchLyricsByHash(song.hash).candidates.firstOrNull()
                if (candidate != null) return candidate
            }
        }
        return searchLyricsByKeyword(keyword, duration).candidates.firstOrNull()
    }

    private suspend fun searchSongs(keyword: Keyword): KuGouSearchSongResponse {
        val query = buildString {
            append(keyword.title)
            append(" - ")
            append(keyword.artist)
            if (!keyword.album.isNullOrBlank()) {
                append(" ")
                append(keyword.album)
            }
        }
        return client.get("https://mobileservice.kugou.com/api/v3/search/song") {
            parameter("version", 9108)
            parameter("plat", 0)
            parameter("pagesize", PAGE_SIZE)
            parameter("showtype", 0)
            parameter("keyword", query)
        }.body()
    }

    private suspend fun searchLyricsByKeyword(
        keyword: Keyword,
        duration: Int,
    ): KuGouSearchLyricsResponse {
        val query = buildString {
            append(keyword.title)
            append(" - ")
            append(keyword.artist)
            if (!keyword.album.isNullOrBlank()) {
                append(" ")
                append(keyword.album)
            }
        }
        return client.get("https://lyrics.kugou.com/search") {
            parameter("ver", 1)
            parameter("man", "yes")
            parameter("client", "pc")
            if (duration != -1) {
                parameter("duration", duration * 1000)
            }
            parameter("keyword", query)
        }.body()
    }

    private suspend fun searchLyricsByHash(hash: String): KuGouSearchLyricsResponse =
        client.get("https://lyrics.kugou.com/search") {
            parameter("ver", 1)
            parameter("man", "yes")
            parameter("client", "pc")
            parameter("hash", hash)
        }.body()

    private suspend fun downloadLyrics(id: Long, accessKey: String): KuGouDownloadLyricsResponse =
        client.get("https://lyrics.kugou.com/download") {
            parameter("fmt", "lrc")
            parameter("charset", "utf8")
            parameter("client", "pc")
            parameter("ver", 1)
            parameter("id", id)
            parameter("accesskey", accessKey)
        }.body()

    private fun normalizeTitle(title: String) =
        title.replace(Regex("""\(.*?\)"""), "")
            .replace(Regex("""（.*?）"""), "")
            .replace(Regex("""「.*?」"""), "")
            .replace(Regex("""『.*?』"""), "")
            .replace(Regex("""<.*?>"""), "")
            .replace(Regex("""《.*?》"""), "")
            .replace(Regex("""〈.*?〉"""), "")
            .replace(Regex("""＜.*?＞"""), "")
            .trim()

    private fun normalizeArtist(artist: String) =
        artist.replace(", ", "、")
            .replace(" & ", "、")
            .replace(".", "")
            .replace("和", "、")
            .replace(Regex("""\(.*?\)"""), "")
            .replace(Regex("""（.*?）"""), "")
            .trim()

    fun generateKeyword(title: String, artist: String, album: String? = null) =
        Keyword(normalizeTitle(title), normalizeArtist(artist), album?.trim())

    private val ACCEPTED_REGEX = Regex("""^\[(\d\d):(\d\d)\.(\d{2,3})\].*""")
    private val BANNED_REGEX = Regex(""".+].+[:：].+""")

    private fun String.normalizeLyrics(): String {
        val lines = lines().filter { it.matches(ACCEPTED_REGEX) }
        if (lines.isEmpty()) return this

        var headCut = 0
        val headLimit = minOf(30, lines.size)
        for (i in 0 until headLimit) {
            if (lines[i].matches(BANNED_REGEX)) {
                headCut = i + 1
            }
        }
        val filtered = lines.drop(headCut)

        var tailCut = 0
        val tailLimit = minOf(30, filtered.size)
        for (i in 0 until tailLimit) {
            if (filtered[filtered.size - 1 - i].matches(BANNED_REGEX)) {
                tailCut = i + 1
            }
        }
        return filtered.dropLast(tailCut).joinToString("\n")
    }
}

/**
 * KuGou Lyrics Provider
 */
object KuGouLyricsProvider : LyricsProvider {
    override val name = "KuGou"

    override fun isEnabled(context: Context): Boolean =
        context.dataStore[EnableKugouKey] ?: true

    override suspend fun getLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): Result<String> = KuGou.getLyrics(title, artist, duration, album)

    override suspend fun getAllLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
        callback: (String) -> Unit,
    ) {
        KuGou.getAllPossibleLyricsOptions(title, artist, duration, album, callback)
    }
}

// ============================================================================
// [LRCLIB LYRICS PROVIDER] Source: providers/LrcLibProvider.kt
// ============================================================================

@Serializable
data class LrcLibTrack(
    val id: Long = 0,
    val trackName: String = "",
    val artistName: String = "",
    val albumName: String? = null,
    val duration: Double = 0.0,
    val plainLyrics: String? = null,
    val syncedLyrics: String? = null,
    val instrumental: Boolean = false,
) {
    val bestLyrics: String?
        get() = syncedLyrics?.takeIf { it.isNotBlank() } ?: plainLyrics?.takeIf { it.isNotBlank() }
}

/**
 * LrcLib Lyrics Engine
 */
object LrcLib {
    private const val TAG = "LrcLib"

    private val client by lazy {
        HttpClient(OkHttp) {
            install(ContentNegotiation) {
                json(
                    Json {
                        isLenient = true
                        ignoreUnknownKeys = true
                        encodeDefaults = true
                    },
                )
            }
            install(HttpTimeout) {
                requestTimeoutMillis = 15000
                connectTimeoutMillis = 10000
            }
            defaultRequest {
                url("https://lrclib.net")
                header("User-Agent", "Listrovia/Lyrics")
            }
            expectSuccess = false
        }
    }

    private val titleCleanupPatterns = listOf(
        Regex("""\s*\(.*?(official|video|audio|lyrics|lyric|visualizer|hd|hq|4k|remaster|remix|live|acoustic|version|edit|extended|radio|clean|explicit).*?\)""", RegexOption.IGNORE_CASE),
        Regex("""\s*\[.*?(official|video|audio|lyrics|lyric|visualizer|hd|hq|4k|remaster|remix|live|acoustic|version|edit|extended|radio|clean|explicit).*?\]""", RegexOption.IGNORE_CASE),
        Regex("""\s*【.*?】"""),
        Regex("""\s*\|.*$"""),
        Regex("""\s*-\s*(official|video|audio|lyrics|lyric|visualizer).*$""", RegexOption.IGNORE_CASE),
        Regex("""\s*\(feat\..*?\)""", RegexOption.IGNORE_CASE),
        Regex("""\s*\(ft\..*?\)""", RegexOption.IGNORE_CASE),
        Regex("""\s*feat\..*$""", RegexOption.IGNORE_CASE),
        Regex("""\s*ft\..*$""", RegexOption.IGNORE_CASE),
    )

    private val artistSeparators = listOf(" & ", " and ", ", ", " x ", " X ", " feat. ", " feat ", " ft. ", " ft ", " featuring ", " with ")

    private fun cleanTitle(title: String): String {
        var cleaned = title.trim()
        for (pattern in titleCleanupPatterns) {
            cleaned = cleaned.replace(pattern, "")
        }
        return cleaned.trim()
    }

    private fun cleanArtist(artist: String): String {
        var cleaned = artist.trim()
        for (separator in artistSeparators) {
            if (cleaned.contains(separator, ignoreCase = true)) {
                cleaned = cleaned.split(separator, ignoreCase = true, limit = 2)[0]
                break
            }
        }
        return cleaned.trim()
    }

    private suspend fun querySearch(
        trackName: String? = null,
        artistName: String? = null,
        albumName: String? = null,
        query: String? = null,
    ): List<LrcLibTrack> = runCatching {
        val response = client.get("/api/search") {
            if (!query.isNullOrBlank()) parameter("q", query)
            if (!trackName.isNullOrBlank()) parameter("track_name", trackName)
            if (!artistName.isNullOrBlank()) parameter("artist_name", artistName)
            if (!albumName.isNullOrBlank()) parameter("album_name", albumName)
        }
        if (response.status == HttpStatusCode.OK) {
            response.body<List<LrcLibTrack>>()
        } else {
            emptyList()
        }
    }.getOrDefault(emptyList())

    suspend fun getLyrics(
        title: String,
        artist: String,
        duration: Int,
        album: String? = null,
    ): Result<String> = runCatching {
        val cleanedTitle = cleanTitle(title)
        val cleanedArtist = cleanArtist(artist)

        var tracks = querySearch(trackName = cleanedTitle, artistName = cleanedArtist, albumName = album)
        if (tracks.isEmpty()) {
            tracks = querySearch(query = "$cleanedTitle $cleanedArtist")
        }
        if (tracks.isEmpty() && (cleanedTitle != title || cleanedArtist != artist)) {
            tracks = querySearch(query = "$title $artist")
        }

        val nonInstrumental = tracks.filterNot { it.instrumental }
        val matched = findBestTrack(nonInstrumental, duration)
            ?: throw IllegalStateException("No matching lyrics found on LrcLib for $title")

        matched.bestLyrics ?: throw IllegalStateException("Track matched on LrcLib has no lyrics")
    }

    suspend fun getAllLyrics(
        title: String,
        artist: String,
        duration: Int,
        album: String? = null,
        callback: (String) -> Unit,
    ) {
        try {
            val cleanedTitle = cleanTitle(title)
            val cleanedArtist = cleanArtist(artist)

            val tracks = querySearch(query = "$cleanedTitle $cleanedArtist")
            tracks.filterNot { it.instrumental }.forEach { track ->
                if (duration == -1 || abs(track.duration.toInt() - duration) <= 5) {
                    track.bestLyrics?.let(callback)
                }
            }
        } catch (e: Exception) {
            Timber.tag(TAG).w(e, "Error fetching all lyrics from LrcLib")
        }
    }

    private fun findBestTrack(tracks: List<LrcLibTrack>, duration: Int): LrcLibTrack? {
        if (tracks.isEmpty()) return null
        if (duration == -1) {
            return tracks.firstOrNull { it.syncedLyrics != null } ?: tracks.firstOrNull()
        }

        // 1. Strict ±2s tolerance with synced lyrics
        val strictSynced = tracks.filter { it.syncedLyrics != null }
            .minByOrNull { abs(it.duration.toInt() - duration) }
            ?.takeIf { abs(it.duration.toInt() - duration) <= 2 }
        if (strictSynced != null) return strictSynced

        // 2. Relaxed ±5s tolerance with synced lyrics
        val relaxedSynced = tracks.filter { it.syncedLyrics != null }
            .minByOrNull { abs(it.duration.toInt() - duration) }
            ?.takeIf { abs(it.duration.toInt() - duration) <= 5 }
        if (relaxedSynced != null) return relaxedSynced

        // 3. Any lyrics within ±5s tolerance
        return tracks.minByOrNull { abs(it.duration.toInt() - duration) }
            ?.takeIf { abs(it.duration.toInt() - duration) <= 5 }
    }
}

/**
 * LrcLib Lyrics Provider
 */
object LrcLibLyricsProvider : LyricsProvider {
    override val name = "LrcLib"

    override fun isEnabled(context: Context): Boolean =
        context.dataStore[EnableLrcLibKey] ?: true

    override suspend fun getLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): Result<String> = LrcLib.getLyrics(title, artist, duration, album)

    override suspend fun getAllLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
        callback: (String) -> Unit,
    ) {
        LrcLib.getAllLyrics(title, artist, duration, album, callback)
    }
}

// ============================================================================
// [PAXSENIX LYRICS PROVIDER] Source: providers/PaxsenixProvider.kt
// ============================================================================

@Serializable
data class PaxsenixSearchResult(
    val id: String,
    val songName: String? = null,
    val trackName: String? = null,
    val artistName: String? = null,
    val albumName: String? = null,
    val duration: Int? = null,
    val artwork: String? = null,
) {
    val displayName: String get() = trackName ?: songName ?: ""
    val displayArtist: String get() = artistName ?: ""
}

@Serializable
data class PaxsenixLyricText(
    val text: String = "",
    val timestamp: Long = 0,
    val endtime: Long = 0,
    val duration: Long = 0,
    val part: Boolean = false,
)

@Serializable
data class PaxsenixLyricsContent(
    val timestamp: Long = 0,
    val endtime: Long = 0,
    val duration: Long = 0,
    val structure: String? = null,
    val text: List<PaxsenixLyricText> = emptyList(),
    val background: Boolean = false,
    val backgroundText: List<PaxsenixLyricText> = emptyList(),
    val oppositeTurn: Boolean = false,
)

@Serializable
data class PaxsenixMetadata(
    val songwriters: List<String> = emptyList(),
)

@Serializable
data class PaxsenixLyricsResponse(
    val type: String? = null,
    val metadata: PaxsenixMetadata? = null,
    val content: List<PaxsenixLyricsContent> = emptyList(),
    val elrc: String? = null,
    val elrcMultiPerson: String? = null,
    val ttmlContent: String? = null,
    val plain: String? = null,
)

/**
 * Paxsenix Lyrics Retrieval Engine
 */
object Paxsenix {
    private const val TAG = "Paxsenix"
    private const val BASE_URL = "https://lyrics.paxsenix.org"

    @Volatile
    private var appVersion: String = "Unknown"

    private val json = Json {
        isLenient = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val httpClient by lazy {
        HttpClient(OkHttp) {
            install(HttpTimeout) {
                requestTimeoutMillis = 15000
                connectTimeoutMillis = 10000
            }
            install(ContentNegotiation) {
                json(json)
            }
            defaultRequest {
                url(BASE_URL)
                header("User-Agent", "Listrovia/$appVersion")
            }
            expectSuccess = false
        }
    }

    fun init(context: Context) {
        try {
            appVersion = context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "Unknown"
        } catch (e: Exception) {
            Timber.tag(TAG).d(e, "Could not fetch app version")
        }
    }

    private val titleCleanupPatterns = listOf(
        Regex("""\s*\(.*?(official|video|audio|lyrics|lyric|visualizer|hd|hq|4k|remaster|remix|live|acoustic|version|edit|extended|radio|clean|explicit).*?\)""", RegexOption.IGNORE_CASE),
        Regex("""\s*\[.*?(official|video|audio|lyrics|lyric|visualizer|hd|hq|4k|remaster|remix|live|acoustic|version|edit|extended|radio|clean|explicit).*?\]""", RegexOption.IGNORE_CASE),
        Regex("""\s*【.*?】"""),
        Regex("""\s*\|.*$"""),
        Regex("""\s*-\s*(official|video|audio|lyrics|lyric|visualizer).*$""", RegexOption.IGNORE_CASE),
        Regex("""\s*\(feat\..*?\)""", RegexOption.IGNORE_CASE),
        Regex("""\s*\(ft\..*?\)""", RegexOption.IGNORE_CASE),
        Regex("""\s*feat\..*$""", RegexOption.IGNORE_CASE),
        Regex("""\s*ft\..*$""", RegexOption.IGNORE_CASE),
    )

    private val artistSeparators = listOf(" & ", " and ", ", ", " x ", " X ", " feat. ", " feat ", " ft. ", " ft ", " featuring ", " with ")

    private fun cleanTitle(title: String): String {
        var cleaned = title.trim()
        for (pattern in titleCleanupPatterns) {
            cleaned = cleaned.replace(pattern, "")
        }
        return cleaned.trim()
    }

    private fun cleanArtist(artist: String): String {
        var cleaned = artist.trim()
        for (separator in artistSeparators) {
            if (cleaned.contains(separator, ignoreCase = true)) {
                cleaned = cleaned.split(separator, ignoreCase = true, limit = 2)[0]
                break
            }
        }
        return cleaned.trim()
    }

    private suspend fun search(query: String): List<PaxsenixSearchResult> = runCatching {
        val res = httpClient.get("/search") {
            parameter("q", query)
        }
        if (res.status == HttpStatusCode.OK) {
            res.body<List<PaxsenixSearchResult>>()
        } else {
            emptyList()
        }
    }.getOrDefault(emptyList())

    private suspend fun fetchLyricsById(id: String): PaxsenixLyricsResponse? = runCatching {
        val res = httpClient.get("/lyrics") {
            parameter("id", id)
        }
        if (res.status == HttpStatusCode.OK) {
            res.body<PaxsenixLyricsResponse>()
        } else {
            null
        }
    }.getOrNull()

    suspend fun getLyrics(
        title: String,
        artist: String,
        duration: Int,
        album: String? = null,
    ): Result<String> = runCatching {
        val cleanedTitle = cleanTitle(title)
        val cleanedArtist = cleanArtist(artist)

        var searchResults = search("$cleanedTitle $cleanedArtist")
        if (searchResults.isEmpty()) {
            searchResults = search("$title $artist")
        }

        val track = findBestMatch(searchResults, duration)
            ?: throw IllegalStateException("No matching track found on Paxsenix for $title")

        val lyricsResp = fetchLyricsById(track.id)
            ?: throw IllegalStateException("Failed to load lyrics from Paxsenix for track ${track.id}")

        extractBestLyrics(lyricsResp)
            ?: throw IllegalStateException("No usable lyrics payload from Paxsenix for ${track.id}")
    }

    suspend fun getAllLyrics(
        title: String,
        artist: String,
        duration: Int,
        album: String? = null,
        callback: (String) -> Unit,
    ) {
        try {
            val cleanedTitle = cleanTitle(title)
            val cleanedArtist = cleanArtist(artist)

            val searchResults = search("$cleanedTitle $cleanedArtist")
            searchResults.forEach { track ->
                if (duration == -1 || track.duration == null || abs(track.duration - duration) <= 5) {
                    val lyricsResp = fetchLyricsById(track.id)
                    lyricsResp?.let { extractBestLyrics(it)?.let(callback) }
                }
            }
        } catch (e: Exception) {
            Timber.tag(TAG).w(e, "Error fetching all lyrics from Paxsenix")
        }
    }

    private fun findBestMatch(tracks: List<PaxsenixSearchResult>, duration: Int): PaxsenixSearchResult? {
        if (tracks.isEmpty()) return null
        if (duration == -1) return tracks.firstOrNull()

        return tracks.minByOrNull { track ->
            val trackDuration = track.duration ?: 0
            abs(trackDuration - duration)
        }?.takeIf { track ->
            val trackDuration = track.duration ?: 0
            abs(trackDuration - duration) <= 5
        } ?: tracks.firstOrNull()
    }

    private fun extractBestLyrics(response: PaxsenixLyricsResponse): String? {
        // 1. TTML formatted content
        response.ttmlContent?.takeIf { it.isNotBlank() }?.let { ttml ->
            val parsed = TTMLParser.parse(ttml)
            if (parsed.isNotBlank()) return parsed
        }

        // 2. Multi-person ELRC (word-synced)
        response.elrcMultiPerson?.takeIf { it.isNotBlank() }?.let { return it }

        // 3. Standard ELRC
        response.elrc?.takeIf { it.isNotBlank() }?.let { return it }

        // 4. Content lines formatted to LRC
        if (response.content.isNotEmpty()) {
            val lrc = formatContentToLrc(response.content)
            if (lrc.isNotBlank()) return lrc
        }

        // 5. Plain text
        return response.plain?.takeIf { it.isNotBlank() }
    }

    private fun formatContentToLrc(content: List<PaxsenixLyricsContent>): String {
        return content.joinToString("\n") { line ->
            val minutes = (line.timestamp / 1000) / 60
            val seconds = (line.timestamp / 1000) % 60
            val millis = (line.timestamp % 1000) / 10
            val timeTag = String.format(Locale.US, "[%02d:%02d.%02d]", minutes, seconds, millis)
            val text = line.text.joinToString("") { it.text }
            "$timeTag$text"
        }.trim()
    }
}

/**
 * Paxsenix Lyrics Provider
 */
object PaxsenixLyricsProvider : LyricsProvider {
    override val name = "Paxsenix"

    override fun isEnabled(context: Context): Boolean =
        context.dataStore[EnablePaxsenixKey] ?: true

    override suspend fun getLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): Result<String> {
        Paxsenix.init(context)
        return Paxsenix.getLyrics(title, artist, duration, album)
    }

    override suspend fun getAllLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
        callback: (String) -> Unit,
    ) {
        Paxsenix.init(context)
        Paxsenix.getAllLyrics(title, artist, duration, album, callback)
    }
}

// ============================================================================
// [SHAZAM RECOGNITION & LYRICS PROVIDER] Source: providers/ShazamProvider.kt
// ============================================================================

data class RecognitionResult(
    val trackId: String,
    val title: String,
    val artist: String,
    val album: String?,
    val coverArtUrl: String?,
    val coverArtHqUrl: String?,
    val genre: String?,
    val releaseDate: String?,
    val label: String?,
    val lyrics: List<String>?,
    val shazamUrl: String?,
    val appleMusicUrl: String?,
    val spotifyUrl: String?,
    val isrc: String?,
    val youtubeVideoId: String? = null,
)

sealed class RecognitionStatus {
    data object Ready : RecognitionStatus()
    data object Listening : RecognitionStatus()
    data object Processing : RecognitionStatus()
    data class Success(val result: RecognitionResult) : RecognitionStatus()
    data class NoMatch(val message: String = "No matches found") : RecognitionStatus()
    data class Error(val message: String) : RecognitionStatus()
}

@Serializable
data class ShazamRequestJson(
    @SerialName("geolocation")
    val geolocation: Geolocation,
    @SerialName("signature")
    val signature: Signature,
    @SerialName("timestamp")
    val timestamp: Long,
    @SerialName("timezone")
    val timezone: String,
) {
    @Serializable
    data class Geolocation(
        @SerialName("altitude")
        val altitude: Double,
        @SerialName("latitude")
        val latitude: Double,
        @SerialName("longitude")
        val longitude: Double,
    )

    @Serializable
    data class Signature(
        @SerialName("samplems")
        val samplems: Long,
        @SerialName("timestamp")
        val timestamp: Long,
        @SerialName("uri")
        val uri: String,
    )
}

@Serializable
data class ShazamResponseJson(
    @SerialName("matches")
    val matches: List<Match?>? = null,
    @SerialName("location")
    val location: Location? = null,
    @SerialName("timestamp")
    val timestamp: Long? = null,
    @SerialName("timezone")
    val timezone: String? = null,
    @SerialName("track")
    val track: Track? = null,
    @SerialName("tagid")
    val tagid: String? = null,
) {
    @Serializable
    data class Match(
        @SerialName("id")
        val id: String? = null,
        @SerialName("offset")
        val offset: Double? = null,
        @SerialName("timeskew")
        val timeskew: Double? = null,
        @SerialName("frequencyskew")
        val frequencyskew: Double? = null,
    )

    @Serializable
    data class Location(
        @SerialName("latitude")
        val latitude: Double? = null,
        @SerialName("longitude")
        val longitude: Double? = null,
        @SerialName("altitude")
        val altitude: Double? = null,
        @SerialName("accuracy")
        val accuracy: Double? = null,
    )

    @Serializable
    data class Track(
        @SerialName("layout")
        val layout: String? = null,
        @SerialName("type")
        val type: String? = null,
        @SerialName("key")
        val key: String? = null,
        @SerialName("title")
        val title: String? = null,
        @SerialName("subtitle")
        val subtitle: String? = null,
        @SerialName("images")
        val images: Images? = null,
        @SerialName("share")
        val share: Share? = null,
        @SerialName("hub")
        val hub: Hub? = null,
        @SerialName("sections")
        val sections: List<Section?>? = null,
        @SerialName("url")
        val url: String? = null,
        @SerialName("artists")
        val artists: List<Artist?>? = null,
        @SerialName("isrc")
        val isrc: String? = null,
        @SerialName("genres")
        val genres: Genres? = null,
        @SerialName("relatedtracksurl")
        val relatedtracksurl: String? = null,
        @SerialName("albumadamid")
        val albumadamid: String? = null,
    ) {
        @Serializable
        data class Images(
            @SerialName("background")
            val background: String? = null,
            @SerialName("coverart")
            val coverart: String? = null,
            @SerialName("coverarthq")
            val coverarthq: String? = null,
            @SerialName("joecolor")
            val joecolor: String? = null,
        )

        @Serializable
        data class Share(
            @SerialName("subject")
            val subject: String? = null,
            @SerialName("text")
            val text: String? = null,
            @SerialName("href")
            val href: String? = null,
            @SerialName("image")
            val image: String? = null,
            @SerialName("twitter")
            val twitter: String? = null,
            @SerialName("html")
            val html: String? = null,
            @SerialName("avatar")
            val avatar: String? = null,
            @SerialName("snapchat")
            val snapchat: String? = null,
        )

        @Serializable
        data class Hub(
            @SerialName("type")
            val type: String? = null,
            @SerialName("image")
            val image: String? = null,
            @SerialName("actions")
            val actions: List<Action?>? = null,
            @SerialName("options")
            val options: List<Option?>? = null,
            @SerialName("providers")
            val providers: List<Provider?>? = null,
            @SerialName("explicit")
            val explicit: Boolean? = null,
            @SerialName("displayname")
            val displayname: String? = null,
        ) {
            @Serializable
            data class Action(
                @SerialName("name")
                val name: String? = null,
                @SerialName("type")
                val type: String? = null,
                @SerialName("id")
                val id: String? = null,
                @SerialName("uri")
                val uri: String? = null,
            )

            @Serializable
            data class Option(
                @SerialName("caption")
                val caption: String? = null,
                @SerialName("actions")
                val actions: List<OptionAction?>? = null,
                @SerialName("beacondata")
                val beacondata: Beacondata? = null,
                @SerialName("image")
                val image: String? = null,
                @SerialName("type")
                val type: String? = null,
                @SerialName("listcaption")
                val listcaption: String? = null,
                @SerialName("overflowimage")
                val overflowimage: String? = null,
                @SerialName("colouroverflowimage")
                val colouroverflowimage: Boolean? = null,
                @SerialName("providername")
                val providername: String? = null,
            ) {
                @Serializable
                data class OptionAction(
                    @SerialName("name")
                    val name: String? = null,
                    @SerialName("type")
                    val type: String? = null,
                    @SerialName("uri")
                    val uri: String? = null,
                    @SerialName("id")
                    val id: String? = null,
                )

                @Serializable
                data class Beacondata(
                    @SerialName("type")
                    val type: String? = null,
                    @SerialName("providername")
                    val providername: String? = null,
                )
            }

            @Serializable
            data class Provider(
                @SerialName("caption")
                val caption: String? = null,
                @SerialName("images")
                val images: ProviderImages? = null,
                @SerialName("actions")
                val actions: List<ProviderAction?>? = null,
                @SerialName("type")
                val type: String? = null,
            ) {
                @Serializable
                data class ProviderImages(
                    @SerialName("overflow")
                    val overflow: String? = null,
                    @SerialName("default")
                    val default: String? = null,
                )

                @Serializable
                data class ProviderAction(
                    @SerialName("name")
                    val name: String? = null,
                    @SerialName("type")
                    val type: String? = null,
                    @SerialName("uri")
                    val uri: String? = null,
                )
            }
        }

        @Serializable
        data class Section(
            @SerialName("type")
            val type: String? = null,
            @SerialName("metapages")
            val metapages: List<Metapage?>? = null,
            @SerialName("tabname")
            val tabname: String? = null,
            @SerialName("metadata")
            val metadata: List<Metadata?>? = null,
            @SerialName("url")
            val url: String? = null,
            @SerialName("text")
            val text: List<String>? = null,
        ) {
            @Serializable
            data class Metapage(
                @SerialName("image")
                val image: String? = null,
                @SerialName("caption")
                val caption: String? = null,
            )

            @Serializable
            data class Metadata(
                @SerialName("title")
                val title: String? = null,
                @SerialName("text")
                val text: String? = null,
            )
        }

        @Serializable
        data class Artist(
            @SerialName("id")
            val id: String? = null,
            @SerialName("adamid")
            val adamid: String? = null,
        )

        @Serializable
        data class Genres(
            @SerialName("primary")
            val primary: String? = null,
        )
    }
}

/**
 * Shazam Music Recognition Engine
 */
object Shazam {
    private const val TAG = "ShazamApi"

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private const val MAX_CONCURRENT_REQUESTS = 2
    private const val MIN_REQUEST_INTERVAL_MS = 1000L
    private const val MAX_RETRIES = 3
    private const val INITIAL_RETRY_DELAY_MS = 2000L
    private const val CACHE_DURATION_MS = 300000L
    private const val MAX_QUEUE_SIZE = 50

    private val activeRequests = AtomicInteger(0)
    private var lastRequestTime = 0L
    private val requestMutex = Mutex()
    private val requestQueue = ConcurrentLinkedQueue<PendingRequest>()
    private val resultCache = ConcurrentHashMap<String, CachedResult>()
    private var nextRequestId = 0L
    private var isProcessingQueue = false

    private val client by lazy {
        HttpClient(OkHttp) {
            install(ContentNegotiation) {
                json(
                    Json {
                        isLenient = true
                        ignoreUnknownKeys = true
                        encodeDefaults = true
                    },
                )
            }
            install(HttpTimeout) {
                requestTimeoutMillis = 30000
            }
            expectSuccess = false
        }
    }

    private val userAgents = listOf(
        "Dalvik/2.1.0 (Linux; U; Android 14; Pixel 8 Build/UD1A.230803.041)",
        "Dalvik/2.1.0 (Linux; U; Android 13; SM-S918B Build/TP1A.220624.014)",
        "Dalvik/2.1.0 (Linux; U; Android 12; Pixel 6 Build/SQ1D.220205.004)",
        "Dalvik/2.1.0 (Linux; U; Android 11; SM-G998B Build/RP1A.200720.012)",
    )

    private val timezones = listOf(
        "Europe/Paris", "Europe/London", "America/New_York",
        "America/Los_Angeles", "Asia/Tokyo", "Asia/Dubai", "Asia/Ho_Chi_Minh",
    )

    suspend fun recognize(signature: String, sampleDurationMs: Long): Result<RecognitionResult> {
        val cacheKey = signature.hashCode().toString()
        getCachedResult(cacheKey)?.let {
            Timber.tag(TAG).d("Cache hit for key=%s", cacheKey)
            return Result.success(it)
        }

        Timber.tag(TAG).d("No cache hit, enqueueing request (pending=%d, active=%d)", requestQueue.size, activeRequests.get())
        return enqueueRequest(signature, sampleDurationMs)
    }

    fun getPendingRequestsCount(): Int = requestQueue.size
    fun getActiveRequestsCount(): Int = activeRequests.get()

    fun clearCache() {
        resultCache.clear()
    }

    fun cancelPendingRequests() {
        while (requestQueue.isNotEmpty()) {
            requestQueue.poll()?.completeWith(Result.failure(Exception("Request cancelled")))
        }
    }

    fun cleanup() {
        cancelPendingRequests()
        clearCache()
        client.close()
    }

    private suspend fun enqueueRequest(
        signature: String,
        sampleDurationMs: Long,
    ): Result<RecognitionResult> = requestMutex.withLock {
        if (requestQueue.size >= MAX_QUEUE_SIZE) {
            Timber.tag(TAG).w("Request queue full (%d/%d), rejecting request", requestQueue.size, MAX_QUEUE_SIZE)
            return Result.failure(Exception("Request queue is full. Please wait."))
        }

        val requestId = nextRequestId++
        val request = PendingRequest(
            id = requestId,
            signature = signature,
            sampleDurationMs = sampleDurationMs,
        )

        requestQueue.offer(request)
        Timber.tag(TAG).d("Request #%d enqueued (queue size=%d)", requestId, requestQueue.size)

        if (!isProcessingQueue) {
            isProcessingQueue = true
            scope.launch { processQueue() }
        }

        return request.awaitResult()
    }

    private suspend fun processQueue() {
        while (true) {
            val request = requestQueue.poll() ?: break

            while (activeRequests.get() >= MAX_CONCURRENT_REQUESTS) {
                delay(100)
            }

            activeRequests.incrementAndGet()

            scope.launch {
                try {
                    val result = executeRequest(request.signature, request.sampleDurationMs)
                    request.completeWith(result)
                } catch (e: Exception) {
                    Timber.tag(TAG).w(e, "Request #%d failed in queue processor", request.id)
                    request.completeWith(Result.failure(e))
                } finally {
                    activeRequests.decrementAndGet()
                }
            }

            enforceRateLimit()
        }

        isProcessingQueue = false
    }

    private suspend fun executeRequest(
        signature: String,
        sampleDurationMs: Long,
    ): Result<RecognitionResult> {
        var lastException: Exception? = null

        for (attempt in 0 until MAX_RETRIES) {
            try {
                enforceRateLimit()
                val result = performRecognition(signature, sampleDurationMs)
                cacheResult(signature.hashCode().toString(), result)
                Timber.tag(TAG).d("Request succeeded on attempt %d", attempt + 1)
                return Result.success(result)
            } catch (e: Exception) {
                lastException = e
                Timber.tag(TAG).w(e, "Request failed on attempt %d/%d: %s", attempt + 1, MAX_RETRIES, e.message)

                if (e.message?.contains("429") == true || e.message?.contains("Too many requests", ignoreCase = true) == true) {
                    if (attempt < MAX_RETRIES - 1) {
                        val delayTime = INITIAL_RETRY_DELAY_MS * (1 shl attempt)
                        delay(delayTime)
                        continue
                    }
                } else {
                    throw e
                }
            }
        }

        throw lastException ?: Exception("Recognition failed after $MAX_RETRIES attempts")
    }

    private suspend fun performRecognition(
        signature: String,
        sampleDurationMs: Long,
    ): RecognitionResult {
        val timestamp = System.currentTimeMillis() / 1000
        val uuid1 = UUID.randomUUID().toString().uppercase()
        val uuid2 = UUID.randomUUID().toString()

        val request = ShazamRequestJson(
            geolocation = ShazamRequestJson.Geolocation(
                altitude = Random.nextDouble() * 400 + 100,
                latitude = Random.nextDouble() * 180 - 90,
                longitude = Random.nextDouble() * 360 - 180,
            ),
            signature = ShazamRequestJson.Signature(
                samplems = sampleDurationMs,
                timestamp = timestamp,
                uri = signature,
            ),
            timestamp = timestamp,
            timezone = timezones.random(),
        )

        val response = client.post("https://amp.shazam.com/discovery/v5/en/US/android/-/tag/$uuid1/$uuid2") {
            parameter("sync", "true")
            parameter("webv3", "true")
            parameter("sampling", "true")
            parameter("connected", "")
            parameter("shazamapiversion", "v3")
            parameter("sharehub", "true")
            parameter("video", "v3")
            header("User-Agent", userAgents.random())
            header("Content-Language", "en_US")
            contentType(ContentType.Application.Json)
            setBody(request)
        }

        if (!response.status.isSuccess()) {
            val statusCode = response.status.value
            when (statusCode) {
                429 -> throw Exception("Too many requests")
                404 -> throw Exception("No match found")
                in 500..599 -> throw Exception("Shazam service temporarily unavailable")
                else -> throw Exception("Recognition failed (error $statusCode)")
            }
        }

        val shazamResponse = response.body<ShazamResponseJson>()
        return shazamResponse.toRecognitionResult()
            ?: throw Exception("No match found")
    }

    private suspend fun enforceRateLimit() {
        val currentTime = System.currentTimeMillis()
        val timeSinceLastRequest = currentTime - lastRequestTime
        if (timeSinceLastRequest < MIN_REQUEST_INTERVAL_MS) {
            val delayTime = MIN_REQUEST_INTERVAL_MS - timeSinceLastRequest
            delay(delayTime)
        }
        lastRequestTime = System.currentTimeMillis()
    }

    private fun getCachedResult(key: String): RecognitionResult? {
        val cached = resultCache[key] ?: return null
        if (System.currentTimeMillis() - cached.timestamp > CACHE_DURATION_MS) {
            resultCache.remove(key)
            return null
        }
        return cached.result
    }

    private fun cacheResult(key: String, result: RecognitionResult) {
        resultCache[key] = CachedResult(System.currentTimeMillis(), result)
        if (resultCache.size > 100) {
            val currentTime = System.currentTimeMillis()
            resultCache.entries.removeIf { currentTime - it.value.timestamp > CACHE_DURATION_MS }
        }
    }

    private fun ShazamResponseJson.toRecognitionResult(): RecognitionResult? {
        val track = this.track ?: return null

        val songSection = track.sections?.find { it?.type == "SONG" }
        val metadata = songSection?.metadata
        val album = metadata?.find { it?.title == "Album" }?.text
        val label = metadata?.find { it?.title == "Label" }?.text
        val releaseDate = metadata?.find { it?.title == "Released" }?.text

        val lyricsSection = track.sections?.find { it?.type == "LYRICS" }
        val lyrics = lyricsSection?.text

        val appleAction = track.hub?.options?.firstOrNull {
            it?.providername?.contains("apple", ignoreCase = true) == true
        }?.actions?.firstOrNull()

        val spotifyProvider = track.hub?.providers?.find {
            it?.caption?.contains("spotify", ignoreCase = true) == true
        }

        val youtubeAction = track.hub?.options?.find {
            it?.type?.contains("video", ignoreCase = true) == true
        }?.actions?.firstOrNull()

        val youtubeVideoId = youtubeAction?.uri?.let { uri ->
            uri.substringAfterLast("v=", "").takeIf { it.isNotEmpty() }
                ?: uri.substringAfterLast("/", "").takeIf { it.isNotEmpty() && it.length == 11 }
        }

        return RecognitionResult(
            trackId = track.key ?: tagid ?: "",
            title = track.title ?: "",
            artist = track.subtitle ?: "",
            album = album,
            coverArtUrl = track.images?.coverart,
            coverArtHqUrl = track.images?.coverarthq,
            genre = track.genres?.primary,
            releaseDate = releaseDate,
            label = label,
            lyrics = lyrics,
            shazamUrl = track.url,
            appleMusicUrl = appleAction?.uri,
            spotifyUrl = spotifyProvider?.actions?.firstOrNull()?.uri,
            isrc = track.isrc,
            youtubeVideoId = youtubeVideoId,
        )
    }

    private class PendingRequest(
        val id: Long,
        val signature: String,
        val sampleDurationMs: Long,
    ) {
        private val deferred = CompletableDeferred<Result<RecognitionResult>>()

        suspend fun awaitResult(): Result<RecognitionResult> = deferred.await()

        fun completeWith(result: Result<RecognitionResult>) {
            deferred.complete(result)
        }
    }

    private data class CachedResult(
        val timestamp: Long,
        val result: RecognitionResult,
    )

    suspend fun getLyrics(
        title: String,
        artist: String,
        duration: Int,
        album: String? = null,
    ): Result<String> = runCatching {
        val query = "$title $artist".trim()
        val searchResponse = client.get("https://core.shazam.com/v1/en/US/android/search") {
            parameter("query", query)
            parameter("numResults", "3")
            header("User-Agent", userAgents.random())
        }
        val text = searchResponse.bodyAsText()
        val trackKey = Regex(""""key"\s*:\s*"(\d+)"""").find(text)?.groupValues?.get(1)
            ?: throw IllegalStateException("No Shazam track key found for $title")

        val trackResponse = client.get("https://amp.shazam.com/discovery/v5/en/US/android/-/track/$trackKey") {
            header("User-Agent", userAgents.random())
        }
        val trackJson = trackResponse.body<ShazamResponseJson.Track>()
        val lyrics = trackJson.sections?.find { it?.type == "LYRICS" }?.text
            ?: throw IllegalStateException("No lyrics found in Shazam track")

        lyrics.joinToString("\n").ifBlank {
            throw IllegalStateException("Empty lyrics for Shazam track")
        }
    }

    suspend fun getAllLyrics(
        title: String,
        artist: String,
        duration: Int,
        album: String? = null,
        callback: (String) -> Unit,
    ) {
        getLyrics(title, artist, duration, album).onSuccess(callback)
    }
}

/**
 * ShazamKit Lyrics Provider
 */
object ShazamLyricsProvider : LyricsProvider {
    override val name = "ShazamKit"

    override fun isEnabled(context: Context): Boolean = true

    override suspend fun getLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): Result<String> = Shazam.getLyrics(title, artist, duration, album)

    override suspend fun getAllLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
        callback: (String) -> Unit,
    ) {
        Shazam.getAllLyrics(title, artist, duration, album, callback)
    }
}

// ============================================================================
// [LYRICS PLUS PROVIDER] Source: LyricsPlusProvider.kt
// ============================================================================

@Serializable
private data class AgentInfo(
    val type: String? = null,
    val name: String? = null,
    val alias: String? = null, // "v1", "v2", etc.
)

@Serializable
private data class SongPart(
    val name: String? = null,
    val time: Long? = null,
    val duration: Long? = null,
)

@Serializable
private data class LyricsMetadata(
    val agents: Map<String, AgentInfo>? = null,
    val songParts: List<SongPart>? = null,
    val songWriters: List<String>? = null,
    val title: String? = null,
    val language: String? = null,
    val totalDuration: String? = null,
)

@Serializable
private data class Translation(
    val lang: String? = null,
    val text: String? = null,
)

@Serializable
private data class LyricWord(
    val time: Long = 0,       // milliseconds
    val duration: Long = 0,   // milliseconds
    val text: String = "",
    val isBackground: Boolean = false,
)

@Serializable
private data class Transliteration(
    val lang: String? = null,
    val text: String? = null,
    val syllabus: List<LyricWord>? = null,
)

@Serializable
private data class LineElement(
    val key: String? = null,
    val singer: String? = null,       // already-resolved alias, e.g. "v1"
    val songPartIndex: Int? = null,
)

@Serializable
private data class LyricsPlusLine(
    val time: Long = 0,               // milliseconds
    val duration: Long = 0,           // milliseconds
    val text: String = "",
    val syllabus: List<LyricWord>? = null,
    val element: LineElement? = null,
    val translation: Translation? = null,
    val transliteration: Transliteration? = null,
)

@Serializable
private data class LyricsPlusResponse(
    val type: String? = null,
    val metadata: LyricsMetadata? = null,
    val lyrics: List<LyricsPlusLine>? = null,
    val cached: String? = null,
)

@Serializable
private data class BinimumLyricsApiResponse(
    val total: Int? = null,
    val source: String? = null,
    val results: List<BinimumLyricsResult> = emptyList(),
    val error: String? = null,
)

@Serializable
private data class BinimumLyricsResult(
    val id: String? = null,
    val track_name: String? = null,
    val artist_name: String? = null,
    val album_name: String? = null,
    val duration: Int? = null,
    val isrc: String? = null,
    val timing_type: String? = null,
    val lyricsUrl: String? = null,
)

private data class BinimumLyricsFetchResult(
    val lrc: String,
    val isWordSync: Boolean,
)

object LyricsPlusProvider : LyricsProvider {
    override val name = "LyricsPlus"
    // ISRC format: 2-letter country code + 3-char alphanumeric registrant + 2-digit year + 5-digit designation.
    private const val ISRC_PATTERN = "^[A-Z]{2}[A-Z0-9]{3}\\d{2}\\d{5}$"
    private val ISRC_REGEX by lazy { Regex(ISRC_PATTERN) }
    private const val BINIMUM_API_BASE_URL = "https://lyrics-api.binimum.org/"

    private val baseUrls = listOf(
        "https://lyricsplus.binimum.org", //binimum's alternate server
        "https://lyricsplus.atomix.one/", //meow's mirror
        "https://lyricsplus.prjktla.my.id", //main server
        "https://lyricsplus-seven.vercel.app", //jigen's mirror
        //"https://lyricsplus.prjktla.workers.dev", //ibra's cf workers (disabled due it has 100000 request per day limit)
        //"https://lyrics-plus-backend.vercel.app", //ibra's vercel (disabled due it's disabled)
    )

    @Volatile
    private var lastWorkingServer: String? = null

    private fun getPrioritizedServers(): List<String> {
        val last = lastWorkingServer
        return if (last != null && last in baseUrls) {
            listOf(last) + baseUrls.filter { it != last }
        } else {
            baseUrls
        }
    }

    private val client by lazy {
        HttpClient(OkHttp) {
            install(ContentNegotiation) {
                json(Json {
                    isLenient = true
                    ignoreUnknownKeys = true
                })
            }

            install(HttpTimeout) {
                requestTimeoutMillis = 15000
                connectTimeoutMillis = 10000
                socketTimeoutMillis = 15000
            }

            expectSuccess = false
        }
    }

    override fun isEnabled(context: Context): Boolean =
        context.dataStore[EnableLyricsPlus] ?: false

    private suspend fun fetchFromUrl(
        url: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): LyricsPlusResponse? = runCatching {
        val response = client.get("$url/v2/lyrics/get") {
            parameter("title", title)
            parameter("artist", artist)
            // LyricsPlus expects duration in seconds, while MediaMetadata stores milliseconds.
            if (duration > 0) parameter("duration", duration / 1000)
            if (!album.isNullOrBlank()) parameter("album", album)
        }
        if (response.status == HttpStatusCode.OK) response.body<LyricsPlusResponse>() else null
    }.getOrNull()

    private suspend fun fetchLyrics(
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): LyricsPlusResponse? {
        if (title.isBlank() || artist.isBlank()) {
            Timber.tag("LyricsPlus").d("Skipping fetch: missing title or artist")
            return null
        }

        for (baseUrl in getPrioritizedServers()) {
            try {
                val result = fetchFromUrl(baseUrl, title, artist, duration, album)
                if (result != null && !result.lyrics.isNullOrEmpty()) {
                    lastWorkingServer = baseUrl
                    return result
                }
            } catch (e: Exception) {
                Timber.tag("LyricsPlus").d(e, "Failed to fetch from $baseUrl")
            }
        }
        return null
    }

    private suspend fun fetchBinimumLyricsApi(
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): BinimumLyricsFetchResult? {
        val normalizedId = id.trim()
        val normalizedIsrc = normalizedId.uppercase()
        val canUseIsrc = normalizedIsrc.matches(ISRC_REGEX)
        val hasMetadata = title.isNotBlank() && artist.isNotBlank()
        // Search is valid when we have an ISRC, or when metadata (title + artist) is present.
        if (!canUseIsrc && !hasMetadata) return null

        suspend fun requestByTrackMetadata() = runCatching {
            client.get(BINIMUM_API_BASE_URL) {
                parameter("track", title)
                parameter("artist", artist)
                if (!album.isNullOrBlank()) parameter("album", album)
                if (duration > 0) parameter("duration", duration)
            }
        }.getOrNull()

        suspend fun requestByIsrc() = runCatching {
            client.get(BINIMUM_API_BASE_URL) {
                parameter("isrc", normalizedIsrc)
            }
        }.getOrNull()

        val response = if (canUseIsrc) {
            requestByIsrc() ?: requestByTrackMetadata()
        } else {
            requestByTrackMetadata()
        } ?: run {
            Timber.tag("LyricsPlus").w("Binimum API request failed (canUseIsrc=$canUseIsrc, hasMetadata=$hasMetadata)")
            return null
        }

        if (!response.status.isSuccess()) return null

        val payload = runCatching { response.body<BinimumLyricsApiResponse>() }.getOrNull()
            ?: return null
        if (payload.results.isEmpty()) return null

        val selectedResult = payload.results
            .firstOrNull { !it.lyricsUrl.isNullOrBlank() }
            ?: return null
        val lyricsUrl = selectedResult.lyricsUrl.orEmpty()
        val ttml = runCatching {
            client.get(lyricsUrl)
        }.getOrNull()?.let { ttmlResponse ->
            if (ttmlResponse.status.isSuccess()) {
                runCatching { ttmlResponse.body<String>() }.getOrNull()
            } else {
                null
            }
        } ?: return null

        val parsedLines = runCatching { TTMLParser.parseTTML(ttml) }
            .onFailure { Timber.tag("LyricsPlus").w(it, "Failed parsing binimum TTML") }
            .getOrNull()
            ?.takeIf { it.isNotEmpty() } ?: return null
        val lrc = runCatching { TTMLParser.toLRC(parsedLines).trim() }
            .getOrNull()
            ?.takeIf { it.isNotBlank() }
            ?: return null

        return BinimumLyricsFetchResult(
            lrc = lrc,
            isWordSync = selectedResult.timing_type.equals("word", ignoreCase = true),
        )
    }

    /**
     * Converts a LyricsPlus JSON response to
     * Listrovia's extended LRC:
     *
     *   [mm:ss.cc]{agent:v1}line text     ← multi-voice agent tag
     *   <word:startSec:endSec|word:...>   ← word-sync block (Word mode only)
     *   [mm:ss.cc]{bg}bg vocal text       ← first in a consecutive bg run
     *   <word:startSec:endSec|...>
     */
    private fun convertToLrc(response: LyricsPlusResponse?): String? {
        val lyrics = response?.lyrics?.takeIf { it.isNotEmpty() } ?: return null
        val isWordSync = response.type.equals("Word", ignoreCase = true)

        // Agent mapping
        // The JSON aliases (v1, v2, v1000) are used directly. Others get mapped
        // to the next free v1/v2 slot, falling back to v1.
        val agentMap = linkedMapOf<String, String>() // raw alias -> lrc id
        lyrics.forEach { line ->
            val raw = line.element?.singer?.lowercase() ?: return@forEach
            if (raw !in agentMap) {
                agentMap[raw] = when {
                    raw == "v1" || raw == "v2" || raw == "v1000" -> raw
                    else -> {
                        val taken = agentMap.values.toSet()
                        listOf("v1", "v2").firstOrNull { it !in taken } ?: "v1"
                    }
                }
            }
        }
        val isMultiAgent = agentMap.size > 1 ||
            (agentMap.size == 1 && !agentMap.containsKey("v1"))

        val sb = StringBuilder(lyrics.size * 128)
        var lastWasBg = false

        for (line in lyrics) {
            val mainWords = line.syllabus?.filter { !it.isBackground } ?: emptyList()
            val bgWords   = line.syllabus?.filter {  it.isBackground } ?: emptyList()

            val isFullBgLine = line.syllabus != null &&
                mainWords.isEmpty() && bgWords.isNotEmpty()

            val mainText = when {
                isWordSync && mainWords.isNotEmpty() -> buildText(mainWords)
                isFullBgLine                         -> ""
                else                                 -> line.text.trim()
            }

            // main line
            if (mainText.isNotBlank()) {
                lastWasBg = false
                val agentId  = agentMap[line.element?.singer?.lowercase()]
                val agentTag = if (isMultiAgent && agentId != null) "{agent:$agentId}" else ""
                sb.appendLrcLine(line.time, agentTag, mainText)
                if (isWordSync && mainWords.isNotEmpty()) sb.appendWordBlock(mainWords)
            }

            // background vocals
            val bgToEmit = when {
                bgWords.isNotEmpty() -> bgWords
                else                 -> emptyList()
            }
            if (bgToEmit.isNotEmpty()) {
                val bgText = if (isWordSync) buildText(bgToEmit) else line.text.trim()
                if (bgText.isNotBlank()) {
                    val bgTime = bgToEmit.minOf { it.time }
                    val bgTag  = if (lastWasBg) "" else "{bg}"
                    sb.appendLrcLine(bgTime, bgTag, bgText)
                    lastWasBg = true
                    if (isWordSync) sb.appendWordBlock(bgToEmit)
                }
            }
        }

        return sb.toString().trimEnd().ifBlank { null }
    }

    /** Joins word texts as-is (spaces are embedded in each text value by the API). */
    private fun buildText(words: List<LyricWord>): String =
        words.joinToString("") { it.text }.trim()

    /** Appends `[mm:ss.cc]<tag>text\n` */
    private fun StringBuilder.appendLrcLine(timeMs: Long, tag: String, text: String) {
        append(formatLrcTime(timeMs))
        append(tag)
        append(text)
        append('\n')
    }

    /** Appends `<word:startSec:endSec|...>\n` */
    private fun StringBuilder.appendWordBlock(words: List<LyricWord>) {
        val valid = words.filter { it.text.isNotBlank() }
        if (valid.isEmpty()) return
        append('<')
        valid.forEachIndexed { i, w ->
            val startSec = w.time / 1000.0
            val endSec   = (w.time + w.duration) / 1000.0
            append(w.text.trim())
            append(':').append(startSec)
            append(':').append(endSec)
            if (i < valid.lastIndex) append('|')
        }
        append(">\n")
    }

    private fun formatLrcTime(timeMs: Long): String {
        val m = timeMs / 60000
        val s = (timeMs % 60000) / 1000
        val c = (timeMs % 1000) / 10
        return buildString {
            append('[')
            if (m < 10) append('0')
            append(m).append(':')
            if (s < 10) append('0')
            append(s).append('.')
            if (c < 10) append('0')
            append(c).append(']')
        }
    }

    override suspend fun getLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): Result<String> = runCatching {
        val binimumResult = fetchBinimumLyricsApi(id, title, artist, duration, album)
        if (binimumResult?.isWordSync == true) {
            return@runCatching binimumResult.lrc
        }

        val response = fetchLyrics(title, artist, duration, album)
        val lyricsPlusLrc = convertToLrc(response)
        resolveLyricsWithFallback(binimumResult, response, lyricsPlusLrc)
            ?: throw IllegalStateException("Lyrics unavailable")
    }

    private fun resolveLyricsWithFallback(
        binimumResult: BinimumLyricsFetchResult?,
        lyricsPlusResponse: LyricsPlusResponse?,
        lyricsPlusLrc: String?,
    ): String? {
        if (binimumResult?.isWordSync == false) {
            val hasWordSyncFromLyricsPlus = lyricsPlusResponse?.type.equals("Word", ignoreCase = true)
            return if (hasWordSyncFromLyricsPlus && !lyricsPlusLrc.isNullOrBlank()) {
                lyricsPlusLrc
            } else {
                binimumResult.lrc
            }
        }
        return lyricsPlusLrc
    }

    override suspend fun getAllLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
        callback: (String) -> Unit,
    ) {
        getLyrics(context, id, title, artist, duration, album).onSuccess { callback(it) }
    }
}

// ============================================================================
// [UNIFIED, SIMPMUSIC, YOUTUBE & ZEMER PROVIDERS] Source: LyricsProviders.kt
// ============================================================================

/**
 * Unified Lyrics Provider: Always enabled and unifies all lyric sources
 * into a single resilient pipeline that cannot be disabled.
 */
object UnifiedLyricsProvider : LyricsProvider {
    override val name = "Unified"

    // Always enabled - cannot be disabled by user preference
    override fun isEnabled(context: Context): Boolean = true

    override suspend fun getLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): Result<String> {
        val providers = listOf(
            BetterLyricsProvider,
            ShazamLyricsProvider,
            PaxsenixLyricsProvider,
            LrcLibLyricsProvider,
            KuGouLyricsProvider,
            SimpMusicLyricsProvider,
            ZemerLyricsProvider,
            YouTubeSubtitleLyricsProvider,
            YouTubeLyricsProvider,
        )

        for (provider in providers) {
            try {
                val res = provider.getLyrics(context, id, title, artist, duration, album)
                if (res.isSuccess && !res.getOrNull().isNullOrBlank()) {
                    return res
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Timber.tag("UnifiedLyrics").d(e, "Provider ${provider.name} failed in unified pipeline")
            }
        }
        return Result.failure(IllegalStateException("No lyrics found in unified pipeline"))
    }

    override suspend fun getAllLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
        callback: (String) -> Unit,
    ) {
        val providers = listOf(
            BetterLyricsProvider,
            ShazamLyricsProvider,
            PaxsenixLyricsProvider,
            LrcLibLyricsProvider,
            KuGouLyricsProvider,
            SimpMusicLyricsProvider,
            ZemerLyricsProvider,
            YouTubeSubtitleLyricsProvider,
            YouTubeLyricsProvider,
        )

        for (provider in providers) {
            try {
                provider.getAllLyrics(context, id, title, artist, duration, album, callback)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Timber.tag("UnifiedLyrics").d(e, "Provider ${provider.name} error during getAllLyrics")
            }
        }
    }
}

/**
 * SimpMusic Lyrics Provider
 */
object SimpMusicLyricsProvider : LyricsProvider {
    override val name = "SimpMusic"

    override fun isEnabled(context: Context): Boolean = context.dataStore[EnableSimpMusicKey] ?: true

    override suspend fun getLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): Result<String> {
        return LrcLibLyricsProvider.getLyrics(context, id, title, artist, duration, album)
    }

    override suspend fun getAllLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
        callback: (String) -> Unit,
    ) {
        LrcLibLyricsProvider.getAllLyrics(context, id, title, artist, duration, album, callback)
    }
}

/**
 * YouTube Lyrics Provider
 */
object YouTubeLyricsProvider : LyricsProvider {
    override val name = "YouTube Music"

    override fun isEnabled(context: Context) = true

    override suspend fun getLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val nextResult = YouTube.next(WatchEndpoint(videoId = id)).getOrThrow()
            Result.success(
                YouTube
                    .lyrics(
                        endpoint = nextResult.lyricsEndpoint
                            ?: throw IllegalStateException("Lyrics endpoint not found"),
                    ).getOrThrow() ?: throw IllegalStateException("Lyrics unavailable")
            )
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            Result.failure(e)
        }
    }
}

/**
 * YouTube Subtitle Lyrics Provider
 */
object YouTubeSubtitleLyricsProvider : LyricsProvider {
    override val name = "YouTube Subtitle"

    override fun isEnabled(context: Context) = true

    override suspend fun getLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): Result<String> = YouTube.transcript(id)
}

/**
 * ZemerLyrics Provider: verified lyrics for Jewish and international music.
 */
object ZemerLyricsProvider : LyricsProvider {
    override val name = "Zemer"
    private const val BASE_URL = "https://search.zemer.io"

    @Serializable
    private data class Source(
        val type: String,
        val url: String? = null,
        val songId: Long? = null,
        val feedUrl: String? = null,
        val trackId: Long? = null,
        val plain: String? = null,
        val syncedLrc: String? = null,
        val synced: Boolean = false,
    )

    @Serializable
    private data class Resolved(
        val videoId: String,
        val lang: String? = null,
        val verified: Boolean = false,
        val hasSynced: Boolean = false,
        val sources: List<Source> = emptyList(),
    )

    private val json = Json { ignoreUnknownKeys = true; isLenient = true; explicitNulls = false }

    private val client by lazy {
        HttpClient(OkHttp) {
            install(ContentNegotiation) { json(json) }
            install(HttpTimeout) {
                requestTimeoutMillis = 15000
                connectTimeoutMillis = 10000
                socketTimeoutMillis = 15000
            }
            expectSuccess = false
        }
    }

    override fun isEnabled(context: Context): Boolean =
        context.dataStore[EnableZemerKey] ?: true

    override suspend fun getLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): Result<String> = runCatching {
        val resolved = resolve(id) ?: throw IllegalStateException("Zemer has no lyrics for $id")
        for (source in resolved.sources.sortedWith(compareBy({ it.synced != true }, { rank(it) }))) {
            val body = runCatching { fetchBody(source) }
                .onFailure { Timber.tag("Zemer").d(it, "source ${source.type} failed") }
                .getOrNull()
            if (body != null && hasBody(body)) return@runCatching body
        }
        throw IllegalStateException("No Zemer source yielded a body")
    }

    private fun rank(s: Source) = when (s.type) {
        "jkaraoke" -> 0
        "lrclib", "jyrics", "shironet", "zingmusic", "tab4u", "zemirotdb" -> 1
        "booklet", "manual" -> 2
        "canonical", "community" -> 3
        else -> 9
    }

    private suspend fun fetchBody(s: Source): String? = when (s.type) {
        "jkaraoke" -> s.feedUrl?.let { fetchText(it) }?.let { page -> s.songId?.let { jkaraokeLrc(page, it) } }
        "lrclib" -> s.trackId?.let { fetchText("https://lrclib.net/api/get/$it") }?.let { lrclibBody(it) }
        "jyrics" -> s.url?.let { fetchText(it) }?.let { parseJyrics(it) }
        "shironet" -> s.url?.let { fetchText(it) }?.let { parseShironet(it) }
        "zingmusic" -> s.trackId?.let { zingLyricsHtml(it) }?.let { zingToPlain(it) }
        "tab4u" -> s.url?.let { fetchText(it) }?.let { parseTab4u(it) }
        "zemirotdb" -> s.url?.let { fetchText(it) }?.let { parseZemirotDb(it) }
        "booklet", "manual", "canonical", "community" ->
            s.syncedLrc?.takeIf { it.isNotBlank() } ?: s.plain?.takeIf { it.isNotBlank() }
        else -> null
    }

    private suspend fun resolve(videoId: String): Resolved? {
        val r = client.get("$BASE_URL/lyrics/resolve") {
            parameter("videoId", videoId)
            header(HttpHeaders.Accept, "application/json")
        }
        return if (r.status == HttpStatusCode.OK) r.body<Resolved>() else null
    }

    private suspend fun fetchText(url: String): String? {
        val r = client.get(url) { header(HttpHeaders.Accept, "text/html,application/json") }
        return if (r.status == HttpStatusCode.OK) r.bodyAsText() else null
    }

    private fun hasBody(text: String) = text.lineSequence().count { it.isNotBlank() } >= 4

    @Serializable
    private data class FeedLine(val start: Double? = null, val text: String? = null)

    @Serializable
    private data class FeedSong(val id: Long, val duration: Int? = null, val lyrics: List<FeedLine> = emptyList())

    @Serializable
    private data class FeedPage(val data: List<FeedSong> = emptyList())

    private fun jkaraokeLrc(pageJson: String, songId: Long): String? {
        val song = runCatching { json.decodeFromString(FeedPage.serializer(), pageJson) }.getOrNull()
            ?.data?.firstOrNull { it.id == songId } ?: return null
        val ls = song.lyrics.filter { it.start != null && !it.text.isNullOrBlank() }
        if (ls.size < 4) return null
        for (k in 1 until ls.size) if (ls[k].start!! + 0.01 < ls[k - 1].start!!) return null
        val dur = song.duration
        if (ls.first().start!! < 0 || (dur != null && dur > 0 && ls.last().start!! > dur + 2)) return null
        return ls.joinToString("\n") { "[${lrcTime(it.start!!)}]${it.text!!.trim()}" }
    }

    private fun lrcTime(s: Double): String {
        val m = (s / 60).toInt()
        return String.format(Locale.US, "%02d:%05.2f", m, s - m * 60)
    }

    @Serializable
    private data class LrcLibTrack(val syncedLyrics: String? = null, val plainLyrics: String? = null, val instrumental: Boolean = false)

    private fun lrclibBody(body: String): String? =
        runCatching { json.decodeFromString(LrcLibTrack.serializer(), body) }.getOrNull()
            ?.takeUnless { it.instrumental }
            ?.let { t -> t.syncedLyrics?.takeIf { it.isNotBlank() } ?: t.plainLyrics?.takeIf { it.isNotBlank() } }

    private suspend fun zingLyricsHtml(trackId: Long): String? {
        val r = client.post("https://jewishmusic.fm:8443/graphql") {
            header(HttpHeaders.ContentType, "application/json")
            setBody("""{"query":"{ track(where:{id:$trackId}){ heLyrics enLyrics } }"}""")
        }
        if (r.status != HttpStatusCode.OK) return null
        val track = runCatching {
            json.parseToJsonElement(r.bodyAsText()).jsonObject["data"]?.jsonObject?.get("track")?.jsonObject
        }.getOrNull() ?: return null
        return track["heLyrics"]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() }
            ?: track["enLyrics"]?.jsonPrimitive?.contentOrNull
    }

    private val NUMERIC_ENTITY = Regex("""&#(\d+);""")
    private val TAG = Regex("""<[^>]+>""")
    private val BR = Regex("""<br\s*/?>""", RegexOption.IGNORE_CASE)
    private val SPACES = Regex("""[ \t ]+""")

    private fun unescape(s: String): String = s
        .replace("&#8217;", "'").replace("&rsquo;", "'")
        .replace("&#8211;", "–").replace("&ndash;", "–")
        .replace("&amp;", "&").replace("&quot;", "\"").replace("&#039;", "'").replace("&nbsp;", " ")
        .replace(NUMERIC_ENTITY) { m -> m.groupValues[1].toInt().toChar().toString() }

    private fun tidy(lines: List<String>): String {
        val out = ArrayList<String>()
        for (raw in lines) {
            val l = raw.replace(SPACES, " ").trim()
            if (l.isNotEmpty() || (out.isNotEmpty() && out.last().isNotEmpty())) out.add(l)
        }
        while (out.isNotEmpty() && out.last().isEmpty()) out.removeAt(out.size - 1)
        while (out.isNotEmpty() && out.first().isEmpty()) out.removeAt(0)
        return out.joinToString("\n")
    }

    private val JYRICS_CUT = Regex("""<ul[^>]*class="[^"]*related-list|<h\d[^>]*>\s*Other Songs from""", RegexOption.IGNORE_CASE)
    private val JYRICS_SCRIPT = Regex("""<script[\s\S]*?</script>|<style[\s\S]*?</style>|<!--[\s\S]*?-->""")
    private val JYRICS_NAV = Regex("""^(Print|SHARE|Added by|admin)$""", RegexOption.IGNORE_CASE)
    private val LABEL = Regex("""^\(?\s*(verse|chorus|bridge|intro|outro|pre-?chorus|hook|refrain|interlude|פזמון|בית|גשר|מעבר|סיום|פתיחה)\s*[\d\w]*\s*:?\s*\)?$""", RegexOption.IGNORE_CASE)
    private val CREDIT = Regex("""^\(?\s*(composed|arranged|written|lyrics|words|music|produced|recorded|later recorded|originally|from the album|album)\b[^\n]*\bby\b|^\(?\s*(composed|arranged|recorded)\b|^(מילים|לחן|עיבוד|הפקה)\s*:""", RegexOption.IGNORE_CASE)

    private fun parseJyrics(html: String): String? {
        var art = Regex("""<article[\s\S]*?</article>""").find(html)?.value ?: html
        JYRICS_CUT.find(art)?.let { art = art.substring(0, it.range.first) }
        val text = unescape(
            art.replace(JYRICS_SCRIPT, "").replace(BR, "\n")
                .replace(Regex("""</p>\s*""", RegexOption.IGNORE_CASE), "\n\n")
                .replace(Regex("""</(div|h\d|li)>\s*""", RegexOption.IGNORE_CASE), "\n")
                .replace(TAG, ""),
        )
        val lines = text.split("\n").map { it.replace(SPACES, " ").trim() }
        val i = lines.indexOfFirst { it.equals("LYRIC", ignoreCase = true) }
        val body = lines.subList(if (i >= 0) i + 1 else 0, lines.size)
            .filterNot { JYRICS_NAV.matches(it) }.toMutableList()
        while (body.isNotEmpty() && body.first().isEmpty()) body.removeAt(0)
        if (body.isNotEmpty()) body.removeAt(0)
        return tidy(body.filterNot { LABEL.matches(it) || CREDIT.containsMatchIn(it) }).ifBlank { null }
    }

    private fun parseShironet(html: String): String? {
        val span = Regex("""<span[^>]*class="artist_lyrics_text"[^>]*>([\s\S]*?)</span>""").find(html)
            ?.groupValues?.get(1) ?: return null
        val text = unescape(span.replace(BR, "\n").replace(TAG, ""))
        return tidy(text.split("\n").filterNot { LABEL.matches(it.trim()) }).ifBlank { null }
    }

    private fun zingToPlain(html: String): String? {
        val text = unescape(
            html.replace(BR, "\n")
                .replace(Regex("""</(p|div|pre|li|h\d)>""", RegexOption.IGNORE_CASE), "\n")
                .replace(TAG, "").replace("&lt;", "<").replace("&gt;", ">"),
        )
        return tidy(
            text.split("\n").filterNot {
                val l = it.trim()
                Regex("""^\[[^\]]*\]$""").matches(l) ||
                    Regex("""^\((?:verse|chorus|bridge|intro|outro|פזמון|בית|מעבר|גשר)\b[^)]*\)$""", RegexOption.IGNORE_CASE).matches(l)
            },
        ).ifBlank { null }
    }

    private fun parseTab4u(html: String): String? {
        val lines = ArrayList<String>()
        for (m in Regex("""<td class="song[^"]*"[^>]*>([\s\S]*?)</td>""").findAll(html)) {
            val t = unescape(m.groupValues[1].replace(TAG, "")).replace(SPACES, " ").trim()
            if (t.isEmpty() || !t.contains(Regex("""[א-ת]"""))) continue
            lines.add(t)
        }
        return tidy(lines).ifBlank { null }
    }

    private fun parseZemirotDb(html: String): String? {
        val div = Regex("""<div id=['"]hebrew['"][^>]*>([\s\S]*?)</div>""").find(html)
            ?.groupValues?.get(1) ?: return null
        val text = unescape(
            div.replace(BR, "\n").replace(Regex("""</p>\s*""", RegexOption.IGNORE_CASE), "\n\n").replace(TAG, ""),
        )
        return tidy(text.split("\n")).ifBlank { null }
    }
}

// ============================================================================
// [LYRICS PROVIDER REGISTRY] Source: LyricsProviderRegistry.kt
// ============================================================================

object LyricsProviderRegistry {
    private val providerMap = mapOf(
        "Unified" to UnifiedLyricsProvider,
        "BetterLyrics" to BetterLyricsProvider,
        "ShazamKit" to ShazamLyricsProvider,
        "Paxsenix" to PaxsenixLyricsProvider,
        "LrcLib" to LrcLibLyricsProvider,
        "KuGou" to KuGouLyricsProvider,
        "LyricsPlus" to LyricsPlusProvider,
        "SimpMusic" to SimpMusicLyricsProvider,
        "Zemer" to ZemerLyricsProvider,
        "YouTubeSubtitle" to YouTubeSubtitleLyricsProvider,
        "YouTube" to YouTubeLyricsProvider,
    )

    val providerNames = providerMap.keys.toList()

    fun getProviderByName(name: String): LyricsProvider? = providerMap[name]

    fun getProviderName(provider: LyricsProvider): String? =
        providerMap.entries.find { it.value == provider }?.key

    fun deserializeProviderOrder(orderString: String): List<String> {
        if (orderString.isBlank()) {
            return getDefaultProviderOrder()
        }
        return orderString.split(",").map { it.trim() }.filter { it in providerNames }
    }

    fun serializeProviderOrder(providers: List<String>): String {
        return providers.filter { it in providerNames }.joinToString(",")
    }

    fun getDefaultProviderOrder(): List<String> = listOf(
        "BetterLyrics",
        "LrcLib",
        "KuGou",
        "SimpMusic",
        "Paxsenix",
        "LyricsPlus",
        "Zemer",
        "YouTubeSubtitle",
        "YouTube",
    )

    fun getOrderedProviders(orderString: String): List<LyricsProvider> {
        val order = deserializeProviderOrder(orderString)
        return order.mapNotNull { getProviderByName(it) }
    }
}

// ============================================================================
// [LYRICS HELPER CORE ORCHESTRATOR] Source: LyricsHelper.kt
// ============================================================================

private const val MAX_LYRICS_FETCH_MS = 25000L
private const val PER_PROVIDER_TIMEOUT_MS = 8000L
private const val PROVIDER_NONE = ""

class LyricsHelper
@Inject
constructor(
    @ApplicationContext private val context: Context,
    private val networkConnectivity: NetworkConnectivityObserver,
) {
    val preferred =
        context.dataStore.data
            .map { preferences ->
                resolveLyricsProviders(preferences)
            }.distinctUntilChanged()

    private val cache = LruCache<String, List<LyricsResult>>(MAX_CACHE_SIZE)
    private var currentLyricsJob: Job? = null

    suspend fun getLyrics(mediaMetadata: MediaMetadata): LyricsWithProvider {
        currentLyricsJob?.cancel()

        val cached = cache.get(mediaMetadata.id)?.firstOrNull()
        if (cached != null) {
            return LyricsWithProvider(cached.lyrics, cached.providerName)
        }

        val orderedProviders = context.dataStore.data
            .map { preferences -> resolveLyricsProviders(preferences) }
            .first()

        val isNetworkAvailable = try {
            networkConnectivity.isCurrentlyConnected()
        } catch (e: Exception) {
            true
        }

        if (!isNetworkAvailable) {
            return LyricsWithProvider(LYRICS_NOT_FOUND, PROVIDER_NONE)
        }

        val result = withTimeoutOrNull(MAX_LYRICS_FETCH_MS) {
            val cleanedTitle = LyricsUtils.cleanTitleForSearch(mediaMetadata.title)
            val enabledProviders = orderedProviders.filter { it.isEnabled(context) }

            Timber.tag("LyricsHelper").d("Starting sequential fetch for: $cleanedTitle by ${mediaMetadata.artists.joinToString { it.name }}")
            Timber.tag("LyricsHelper").d("Enabled providers in order: ${enabledProviders.joinToString { it.name }}")

            for (provider in enabledProviders) {
                Timber.tag("LyricsHelper").d("Trying provider: ${provider.name}")
                val providerResult = try {
                    withTimeoutOrNull(PER_PROVIDER_TIMEOUT_MS) {
                        provider.getLyrics(
                            context,
                            mediaMetadata.id,
                            cleanedTitle,
                            mediaMetadata.artists.joinToString { it.name },
                            mediaMetadata.duration,
                            mediaMetadata.album?.title,
                        )
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Timber.tag("LyricsHelper").w("${provider.name} threw: ${e.message}")
                    null
                }

                if (providerResult != null && providerResult.isSuccess) {
                    Timber.tag("LyricsHelper").i("Got lyrics from ${provider.name}")
                    val filtered = LyricsUtils.filterLyricsCreditLines(providerResult.getOrNull()!!)
                    cache.put(mediaMetadata.id, listOf(LyricsResult(provider.name, filtered)))
                    return@withTimeoutOrNull LyricsWithProvider(filtered, provider.name)
                } else {
                    val errorMsg = providerResult?.exceptionOrNull()?.message ?: "timeout or exception"
                    Timber.tag("LyricsHelper").w("${provider.name} failed: $errorMsg")
                }
            }

            Timber.tag("LyricsHelper").w("No lyrics found after checking all providers")
            LyricsWithProvider(LYRICS_NOT_FOUND, PROVIDER_NONE)
        }

        return result ?: LyricsWithProvider(LYRICS_NOT_FOUND, PROVIDER_NONE)
    }

    suspend fun getAllLyrics(
        mediaId: String,
        songTitle: String,
        songArtists: String,
        duration: Int,
        album: String? = null,
        callback: (LyricsResult) -> Unit,
    ) {
        currentLyricsJob?.cancel()

        val cacheKey = "$songArtists-$songTitle".replace(" ", "")
        cache.get(cacheKey)?.let { results ->
            results.forEach { callback(it) }
            return
        }

        val isNetworkAvailable = try {
            networkConnectivity.isCurrentlyConnected()
        } catch (e: Exception) {
            true
        }

        if (!isNetworkAvailable) return

        val allResult = mutableListOf<LyricsResult>()
        currentLyricsJob = CoroutineScope(SupervisorJob()).launch {
            val cleanedTitle = LyricsUtils.cleanTitleForSearch(songTitle)
            val allProviders = context.dataStore.data
                .map { preferences -> resolveLyricsProviders(preferences) }
                .first()
            val enabledProviders = allProviders.filter { it.isEnabled(context) }

            val otherProviders = enabledProviders.filter { it.name != "LyricsPlus" }
            val lyricsPlusProvider = enabledProviders.find { it.name == "LyricsPlus" }

            val callbackMutex = Any()

            val otherJobs = otherProviders.map { provider ->
                launch {
                    try {
                        provider.getAllLyrics(context, mediaId, cleanedTitle, songArtists, duration, album) { lyrics ->
                            val filteredLyrics = LyricsUtils.filterLyricsCreditLines(lyrics)
                            val result = LyricsResult(provider.name, filteredLyrics)
                            synchronized(callbackMutex) {
                                allResult += result
                                callback(result)
                            }
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        reportException(e)
                    }
                }
            }
            otherJobs.forEach { it.join() }

            val otherLyricsCount = allResult.count { it.providerName != "LyricsPlus" }
            if (lyricsPlusProvider != null && otherLyricsCount <= 2) {
                launch {
                    try {
                        lyricsPlusProvider.getAllLyrics(context, mediaId, cleanedTitle, songArtists, duration, album) { lyrics ->
                            val filteredLyrics = LyricsUtils.filterLyricsCreditLines(lyrics)
                            val result = LyricsResult(lyricsPlusProvider.name, filteredLyrics)
                            synchronized(callbackMutex) {
                                allResult += result
                                callback(result)
                            }
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        reportException(e)
                    }
                }.join()
            }

            cache.put(cacheKey, allResult)
        }

        currentLyricsJob?.join()
    }

    private fun resolveLyricsProviders(preferences: androidx.datastore.preferences.core.Preferences): List<LyricsProvider> {
        val providerOrder = preferences[LyricsProviderOrderKey].orEmpty()
        if (providerOrder.isNotBlank()) {
            return LyricsProviderRegistry.getOrderedProviders(providerOrder)
        }

        return LyricsProviderRegistry.getDefaultProviderOrder()
            .mapNotNull { LyricsProviderRegistry.getProviderByName(it) }
    }

    companion object {
        private const val MAX_CACHE_SIZE = 20
    }
}

data class LyricsResult(
    val providerName: String,
    val lyrics: String,
)

data class LyricsWithProvider(
    val lyrics: String,
    val provider: String,
)

// ============================================================================
// [LYRICS TRANSLATION HELPER] Source: LyricsTranslationHelper.kt
// ============================================================================

/**
 * A helper class that provides AI-powered translation for lyrics.
 */
object LyricsTranslationHelper {
    private val _status = MutableStateFlow<TranslationStatus>(TranslationStatus.Idle)
    val status: StateFlow<TranslationStatus> = _status.asStateFlow()

    private val _hasActiveTranslations = MutableStateFlow(false)
    val hasActiveTranslations: StateFlow<Boolean> = _hasActiveTranslations.asStateFlow()

    private val _translationSaved = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val translationSaved: SharedFlow<Unit> = _translationSaved.asSharedFlow()

    private val _manualTrigger = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val manualTrigger: SharedFlow<Unit> = _manualTrigger.asSharedFlow()

    private val _clearTranslationsTrigger = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val clearTranslationsTrigger: SharedFlow<Unit> = _clearTranslationsTrigger.asSharedFlow()

    private var translationJob: kotlinx.coroutines.Job? = null
    private var isCompositionActive = true

    // Cache translations in memory to avoid redundant API calls during a session
    private val translationCache = ConcurrentHashMap<String, List<String>>()

    // Map of language codes to full names for better AI understanding
    private val LanguageCodeToName = mapOf(
        "en" to "English",
        "es" to "Spanish",
        "fr" to "French",
        "de" to "German",
        "it" to "Italian",
        "pt" to "Portuguese",
        "ru" to "Russian",
        "ja" to "Japanese",
        "ko" to "Korean",
        "zh" to "Chinese",
        "ar" to "Arabic",
        "hi" to "Hindi",
        "bn" to "Bengali",
        "pa" to "Punjabi",
        "tr" to "Turkish",
        "vi" to "Vietnamese",
        "th" to "Thai",
        "id" to "Indonesian",
        "pl" to "Polish",
        "nl" to "Dutch",
        "sv" to "Swedish",
        "uk" to "Ukrainian"
    )

    fun setCompositionActive(active: Boolean) {
        isCompositionActive = active
    }

    fun triggerManualTranslation() {
        _manualTrigger.tryEmit(Unit)
    }

    fun triggerClearTranslations() {
        _clearTranslationsTrigger.tryEmit(Unit)
        _hasActiveTranslations.value = false
    }

    fun clearTranslations(lyrics: LyricsEntity): LyricsEntity {
        return lyrics.copy(
            translatedLyrics = "",
            translationLanguage = "",
            translationMode = ""
        )
    }

    fun cancelTranslation() {
        translationJob?.cancel()
        if (_status.value is TranslationStatus.Translating) {
            _status.value = TranslationStatus.Idle
        }
    }

    private fun getCacheKey(text: String, mode: String, targetLanguage: String): String {
        return "${text.hashCode()}_${mode}_${targetLanguage}"
    }

    /**
     * Phân tích nội dung dịch từng phần theo thời gian thực khi đang nhận luồng dữ liệu (SSE stream) từ API.
     * Hỗ trợ trích xuất trực tiếp từng chuỗi trong mảng JSON ["dòng 1", "dòng 2 đang gõ... ngay cả khi chưa đóng ngoặc kép,
     * giúp giao diện hiển thị chữ chạy theo thời gian thực từng từ/câu.
     */
    fun tryParsePartialTranslation(content: String, expectedLines: Int): List<String> {
        val cleaned = content
            .replace("```json", "")
            .replace("```", "")
            .trim()
        if (cleaned.isEmpty()) return emptyList()

        val bracketIndex = cleaned.indexOf('[')
        if (bracketIndex != -1) {
            val extracted = mutableListOf<String>()
            var inString = false
            var escaped = false
            val currentToken = StringBuilder()

            for (i in (bracketIndex + 1) until cleaned.length) {
                val c = cleaned[i]
                if (!inString) {
                    if (c == '"') {
                        inString = true
                        currentToken.setLength(0)
                    } else if (c == ']') {
                        break
                    }
                } else {
                    if (escaped) {
                        when (c) {
                            'n' -> currentToken.append('\n')
                            'r' -> {}
                            't' -> currentToken.append('\t')
                            '"' -> currentToken.append('"')
                            '\\' -> currentToken.append('\\')
                            '/' -> currentToken.append('/')
                            else -> currentToken.append(c)
                        }
                        escaped = false
                    } else if (c == '\\') {
                        escaped = true
                    } else if (c == '"') {
                        inString = false
                        extracted.add(currentToken.toString().trim())
                        currentToken.setLength(0)
                    } else {
                        currentToken.append(c)
                    }
                }
            }

            // Nếu một chuỗi đang được truyền dở dang (chưa có dấu ngoặc kép đóng), vẫn hiển thị chữ theo thời gian thực
            if (inString && currentToken.isNotEmpty()) {
                extracted.add(currentToken.toString().trim())
            }

            if (extracted.isNotEmpty()) {
                return extracted
            }
        }

        // Dự phòng cho trường hợp mô hình trả về từng dòng văn bản thuần túy
        return cleaned.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() && it != "[" && it != "]" }
            .map { line ->
                line.removePrefix("\"")
                    .removeSuffix(",")
                    .removeSuffix("\"")
                    .replace(Regex("^\\d+\\.\\s*"), "")
                    .replace(Regex("^Line\\s+\\d+:\\s*", RegexOption.IGNORE_CASE), "")
                    .replace(Regex("^-\\s*"), "")
                    .trim()
            }
            .filter { it.isNotBlank() }
    }

    fun loadTranslationsFromDatabase(
        lyrics: List<LyricsEntry>,
        lyricsEntity: LyricsEntity?,
        targetLanguage: String,
        mode: String
    ) {
        if (lyricsEntity == null || lyricsEntity.translatedLyrics.isNullOrBlank()) {
            _hasActiveTranslations.value = false
            lyrics.forEach { it.translatedTextFlow.value = null }
            return
        }
        
        // Only load if language and mode match
        if (lyricsEntity.translationLanguage != targetLanguage || lyricsEntity.translationMode != mode) {
            _hasActiveTranslations.value = false
            lyrics.forEach { it.translatedTextFlow.value = null }
            return
        }
        
        val translatedLines = lyricsEntity.translatedLyrics.split("\n")
        val nonEmptyEntries = lyrics.filter { it.text.isNotBlank() }
        
        if (translatedLines.size >= nonEmptyEntries.size) {
            var transIndex = 0
            lyrics.forEach { entry ->
                if (entry.text.isNotBlank() && transIndex < translatedLines.size) {
                    entry.translatedTextFlow.value = translatedLines[transIndex]
                    transIndex++
                }
            }
            
            // Also cache them
            val fullText = nonEmptyEntries.joinToString("\n") { it.text }
            val cacheKey = getCacheKey(fullText, mode, targetLanguage)
            translationCache[cacheKey] = translatedLines
            _hasActiveTranslations.value = true
        }
    }

    fun translateLyrics(
        lyrics: List<LyricsEntry>,
        targetLanguage: String,
        apiKey: String,
        baseUrl: String,
        model: String,
        mode: String,
        scope: CoroutineScope,
        context: Context,
        provider: String = "OpenRouter",
        deeplApiKey: String = "",
        deeplFormality: String = "default",
        useStreaming: Boolean = true,
        songId: String = "",
        database: MusicDatabase? = null,
        systemPrompt: String = "",
    ) {
        translationJob?.cancel()
        _status.value = TranslationStatus.Translating

        // Clear existing translations to indicate re-translation
        lyrics.forEach { it.translatedTextFlow.value = null }

        translationJob =
            scope.launch(Dispatchers.IO) {
                try {
                    if (lyrics.isEmpty()) {
                        _status.value = TranslationStatus.Error(context.getString(com.listrovia.music.R.string.ai_error_no_lyrics))
                        return@launch
                    }

                    // Filter out empty lines and keep track of their indices
                    val nonEmptyEntries =
                        lyrics.mapIndexedNotNull { index, entry ->
                            if (entry.text.isNotBlank()) index to entry else null
                        }

                    if (nonEmptyEntries.isEmpty()) {
                        _status.value = TranslationStatus.Error(context.getString(com.listrovia.music.R.string.ai_error_lyrics_empty))
                        return@launch
                    }

                    // Create text from non-empty lines only
                    val fullText = nonEmptyEntries.joinToString("\n") { it.second.text }

                    // Check cache first
                    val cacheKey = getCacheKey(fullText, mode, targetLanguage)
                    val cachedTranslations = translationCache[cacheKey]
                    if (cachedTranslations != null && cachedTranslations.size >= nonEmptyEntries.size) {
                        // Use cached translations
                        nonEmptyEntries.forEachIndexed { idx, (originalIndex, _) ->
                            if (idx < cachedTranslations.size) {
                                lyrics[originalIndex].translatedTextFlow.value = cachedTranslations[idx]
                            }
                        }
                        _hasActiveTranslations.value = true
                        _status.value = TranslationStatus.Success

                        // Persist cached translations to DB so loadTranslationsFromDatabase can't
                        // overwrite them with a stale empty entity (e.g. after an untranslate race).
                        if (songId.isNotBlank() && database != null) {
                            try {
                                val currentLyrics = database.lyrics(songId).first()
                                if (currentLyrics != null && currentLyrics.translatedLyrics.isNullOrBlank()) {
                                    database.query {
                                        upsert(
                                            currentLyrics.copy(
                                                translatedLyrics = cachedTranslations.joinToString("\n"),
                                                translationLanguage = targetLanguage,
                                                translationMode = mode,
                                            ),
                                        )
                                    }
                                    _translationSaved.tryEmit(Unit)
                                }
                            } catch (e: Exception) {
                                Timber.e(e, "Failed to persist cached translations to database")
                            }
                        }

                        delay(3000)
                        if (_status.value is TranslationStatus.Success && isCompositionActive) {
                            _status.value = TranslationStatus.Idle
                        }
                        return@launch
                    }

                    // Validate language for all modes
                    if (targetLanguage.isBlank()) {
                        _status.value = TranslationStatus.Error(context.getString(com.listrovia.music.R.string.ai_error_language_required))
                        return@launch
                    }

                    // Convert language code to full language name for better AI understanding
                    val fullLanguageName =
                        LanguageCodeToName[targetLanguage]
                            ?: try {
                                Locale.forLanguageTag(targetLanguage).displayLanguage.takeIf { it.isNotBlank() && it != targetLanguage }
                            } catch (e: Exception) {
                                null
                            }
                            ?: targetLanguage

                    val effectiveApiKey = if (provider == "DeepL") deeplApiKey else apiKey

                    // Siết chặt kiểm tra: Ngăn chặn mã giả mạo, chuỗi lậu hoặc lách luật trước khi gọi bất kỳ AI API nào
                    if (effectiveApiKey.isNotBlank() && !OpenRouterService.isKeyFormatValid(effectiveApiKey, provider)) {
                        _status.value = TranslationStatus.Error(
                            context.getString(com.listrovia.music.R.string.ai_api_key_fake_blocked_desc)
                        )
                        return@launch
                    }

                    val effectiveModel =
                        if (model.isNotBlank()) {
                            model
                        } else if (provider == "OpenRouter") {
                            try {
                                OpenRouterModelManager.getInstance(context).getModelsForApp().firstOrNull()?.id
                                    ?: com.listrovia.music.constants.OpenRouterDefaultModel
                            } catch (e: Exception) {
                                com.listrovia.music.constants.OpenRouterDefaultModel
                            }
                        } else if (provider == "DeepInfra") {
                            com.listrovia.music.constants.DeepInfraDefaultModel
                        } else {
                            model
                        }

                    val result =
                        if (effectiveApiKey.isBlank() && provider != "DeepInfra") {
                            Timber.d("No API key provided, using free Google Translate")
                            translateWithGoogleFree(fullText, targetLanguage)
                        } else if (provider == "DeepL") {
                            Timber.d("Using DeepL for translation")
                            // DeepL only supports translation mode
                            DeepLService.translate(
                                text = fullText,
                                targetLanguage = targetLanguage,
                                apiKey = deeplApiKey,
                                formality = deeplFormality,
                            )
                        } else if (provider == "Mistral") {
                            Timber.d("Using Mistral for translation")
                            // Use Mistral API directly
                            MistralService.translate(
                                text = fullText,
                                targetLanguage = fullLanguageName,
                                apiKey = apiKey,
                                model = effectiveModel,
                                mode = mode,
                                customSystemPrompt = systemPrompt,
                            )
                        } else if (useStreaming && provider != "Custom") {
                            Timber.d("Using streaming for translation with provider: $provider, model: $effectiveModel")
                            // Use streaming for supported providers
                            var translatedLines: List<String>? = null
                            var hasError = false
                            var errorMessage = ""
                            val contentAccumulator = StringBuilder()

                            OpenRouterStreamingService
                                .streamTranslation(
                                    text = fullText,
                                    targetLanguage = fullLanguageName,
                                    apiKey = apiKey,
                                    baseUrl = baseUrl,
                                    model = effectiveModel,
                                    mode = mode,
                                    customSystemPrompt = systemPrompt,
                                    provider = provider,
                                ).collect { chunk ->
                                    Timber.v("Received streaming chunk: $chunk")
                                    when (chunk) {
                                        is OpenRouterStreamingService.StreamChunk.Content -> {
                                            // Accumulate content for progressive parsing
                                            contentAccumulator.append(chunk.text)

                                            // Try to parse partial content and update UI progressively
                                            val partialContent = contentAccumulator.toString()
                                            val partialResult = tryParsePartialTranslation(partialContent, nonEmptyEntries.size)
                                            if (partialResult.isNotEmpty()) {
                                                // Update lyrics with partial translations as they become available
                                                partialResult.forEachIndexed { idx, translation ->
                                                    if (idx < nonEmptyEntries.size && translation.isNotBlank()) {
                                                        val originalIndex = nonEmptyEntries[idx].first
                                                        lyrics[originalIndex].translatedTextFlow.value = translation
                                                    }
                                                }
                                                _status.value = TranslationStatus.Translating
                                            }
                                        }

                                        is OpenRouterStreamingService.StreamChunk.Complete -> {
                                            Timber.d("Streaming complete with ${chunk.translatedLines.size} lines")
                                            translatedLines = chunk.translatedLines
                                        }

                                        is OpenRouterStreamingService.StreamChunk.Error -> {
                                            Timber.e("Streaming error: ${chunk.message}")
                                            hasError = true
                                            errorMessage = chunk.message
                                        }
                                    }
                                }

                            Timber.d("Streaming collection complete. hasError=$hasError, translatedLines=${translatedLines?.size}")
                            if (hasError) {
                                Result.failure(Exception(errorMessage))
                            } else if (translatedLines != null) {
                                Result.success(translatedLines)
                            } else {
                                Result.failure(Exception("No translation received"))
                            }
                        } else {
                            Timber.d("Using non-streaming for translation")
                            // Use non-streaming for Custom provider or when streaming is disabled
                            OpenRouterService.translate(
                                text = fullText,
                                targetLanguage = fullLanguageName,
                                apiKey = apiKey,
                                baseUrl = baseUrl,
                                model = effectiveModel,
                                mode = mode,
                                customSystemPrompt = systemPrompt,
                                provider = provider,
                            )
                        }

                    result
                        .onSuccess { lines ->
                            // Check if composition is still active before updating state
                            if (lines == null || !isCompositionActive) {
                                return@onSuccess
                            }

                            // Cache the translations
                            val cacheKey = getCacheKey(fullText, mode, targetLanguage)
                            translationCache[cacheKey] = lines

                            // Save to database if songId is provided
                            if (songId.isNotBlank() && database != null) {
                                try {
                                    val currentLyrics = database.lyrics(songId).first()
                                    if (currentLyrics != null) {
                                        database.query {
                                            upsert(
                                                currentLyrics.copy(
                                                    translatedLyrics = lines.joinToString("\n"),
                                                    translationLanguage = targetLanguage,
                                                    translationMode = mode,
                                                ),
                                            )
                                        }
                                        // Signal that translations have been saved
                                        _translationSaved.tryEmit(Unit)
                                    }
                                } catch (e: Exception) {
                                    Timber.e(e, "Failed to save translated lyrics to database")
                                }
                            }

                            // Map translations back to original non-empty entries only
                            val expectedCount = nonEmptyEntries.size

                            when {
                                lines.size >= expectedCount -> {
                                    // Perfect match or more - map to non-empty entries
                                    nonEmptyEntries.forEachIndexed { idx, (originalIndex, _) ->
                                        lyrics[originalIndex].translatedTextFlow.value = lines[idx]
                                    }
                                    _hasActiveTranslations.value = true
                                    _status.value = TranslationStatus.Success
                                }

                                lines.size < expectedCount -> {
                                    // Fewer translations than expected - map what we have
                                    lines.forEachIndexed { idx, translation ->
                                        if (idx < nonEmptyEntries.size) {
                                            val originalIndex = nonEmptyEntries[idx].first
                                            lyrics[originalIndex].translatedTextFlow.value = translation
                                        }
                                    }
                                    _hasActiveTranslations.value = true
                                    _status.value = TranslationStatus.Success
                                }
                            }

                            // Auto-hide success message after 3 seconds
                            delay(3000)
                            if (_status.value is TranslationStatus.Success && isCompositionActive) {
                                _status.value = TranslationStatus.Idle
                            }
                        }
                        .onFailure { error ->
                            if (!isCompositionActive) {
                                return@onFailure
                            }

                            val errorMessage = error.message ?: context.getString(com.listrovia.music.R.string.ai_error_unknown)

                            // Show error in UI
                            _status.value = TranslationStatus.Error(errorMessage)
                        }
                } catch (e: Exception) {
                    // Ignore cancellation exceptions or if composition is no longer active
                    if (e !is kotlinx.coroutines.CancellationException && isCompositionActive) {
                        val errorMessage = e.message ?: context.getString(com.listrovia.music.R.string.ai_error_translation_failed)
                        _status.value = TranslationStatus.Error(errorMessage)
                    }
                }
            }
    }

    data class DebugTranslationResult(
        val originalLines: List<String>,
        val translatedLines: List<String>,
        val latencyMs: Long,
        val provider: String,
        val model: String,
        val isGoogleFreeFallback: Boolean = false,
        val rawContent: String? = null,
    )

    suspend fun testTranslate(
        text: String,
        targetLanguage: String,
        apiKey: String,
        baseUrl: String,
        model: String,
        mode: String,
        provider: String = "OpenRouter",
        deeplApiKey: String = "",
        deeplFormality: String = "default",
        systemPrompt: String = "",
        onPartialUpdate: ((List<String>, String) -> Unit)? = null,
    ): Result<DebugTranslationResult> = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val nonEmptyLines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
        if (nonEmptyLines.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("No lyrics available to translate"))
        }

        val fullText = nonEmptyLines.joinToString("\n")
        val fullLanguageName =
            LanguageCodeToName[targetLanguage]
                ?: try {
                    Locale.forLanguageTag(targetLanguage).displayLanguage.takeIf { it.isNotBlank() && it != targetLanguage }
                } catch (e: Exception) {
                    null
                }
                ?: targetLanguage

        val effectiveApiKey = if (provider == "DeepL") deeplApiKey else apiKey
        val effectiveModel =
            if (model.isNotBlank()) {
                model
            } else if (provider == "OpenRouter") {
                com.listrovia.music.constants.OpenRouterDefaultModel
            } else if (provider == "DeepInfra") {
                com.listrovia.music.constants.DeepInfraDefaultModel
            } else {
                model
            }

        var rawStreamedText: String? = null
        val isGoogleFree = effectiveApiKey.isBlank() && provider != "DeepL" && provider != "DeepInfra"
        val res: Result<List<String>> = when {
            isGoogleFree -> {
                translateWithGoogleFree(fullText, targetLanguage)
            }
            provider == "DeepL" -> {
                DeepLService.translate(
                    text = fullText,
                    targetLanguage = targetLanguage,
                    apiKey = deeplApiKey,
                    formality = deeplFormality,
                )
            }
            provider == "Mistral" -> {
                MistralService.translate(
                    text = fullText,
                    targetLanguage = fullLanguageName,
                    apiKey = apiKey,
                    model = effectiveModel,
                    mode = mode,
                    customSystemPrompt = systemPrompt,
                )
            }
            provider != "Custom" -> {
                var finalLines: List<String>? = null
                var streamError: String? = null
                val accumulator = StringBuilder()

                OpenRouterStreamingService
                    .streamTranslation(
                        text = fullText,
                        targetLanguage = fullLanguageName,
                        apiKey = apiKey,
                        baseUrl = baseUrl,
                        model = effectiveModel,
                        mode = mode,
                        customSystemPrompt = systemPrompt,
                        provider = provider,
                    ).collect { chunk ->
                        when (chunk) {
                            is OpenRouterStreamingService.StreamChunk.Content -> {
                                accumulator.append(chunk.text)
                                val rawNow = accumulator.toString()
                                rawStreamedText = rawNow
                                val partialLines = tryParsePartialTranslation(rawNow, nonEmptyLines.size)
                                if (partialLines.isNotEmpty()) {
                                    onPartialUpdate?.invoke(partialLines, rawNow)
                                }
                            }
                            is OpenRouterStreamingService.StreamChunk.Complete -> {
                                finalLines = chunk.translatedLines
                            }
                            is OpenRouterStreamingService.StreamChunk.Error -> {
                                streamError = chunk.message
                            }
                        }
                    }

                if (finalLines != null) {
                    Result.success(finalLines!!)
                } else if (streamError != null) {
                    OpenRouterService.translate(
                        text = fullText,
                        targetLanguage = fullLanguageName,
                        apiKey = apiKey,
                        baseUrl = baseUrl,
                        model = effectiveModel,
                        mode = mode,
                        customSystemPrompt = systemPrompt,
                        provider = provider,
                    )
                } else {
                    Result.failure(Exception("No translation received from stream"))
                }
            }
            else -> {
                OpenRouterService.translate(
                    text = fullText,
                    targetLanguage = fullLanguageName,
                    apiKey = apiKey,
                    baseUrl = baseUrl,
                    model = effectiveModel,
                    mode = mode,
                    customSystemPrompt = systemPrompt,
                    provider = provider,
                )
            }
        }

        val elapsed = System.currentTimeMillis() - startTime
        res.map { lines ->
            DebugTranslationResult(
                originalLines = nonEmptyLines,
                translatedLines = lines,
                latencyMs = elapsed,
                provider = if (isGoogleFree) "Google Translate (Free)" else provider,
                model = if (isGoogleFree) "gtx-free" else effectiveModel,
                isGoogleFreeFallback = isGoogleFree,
                rawContent = rawStreamedText ?: lines.joinToString("\n"),
            )
        }
    }

    suspend fun translateWithGoogleFree(
        text: String,
        targetLanguage: String
    ): Result<List<String>> = withContext(Dispatchers.IO) {
        val client = okhttp3.OkHttpClient.Builder()
            .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
            .build()
        try {
            val encodedText = java.net.URLEncoder.encode(text, "UTF-8")
            val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=$targetLanguage&dt=t&q=$encodedText"
            val request = okhttp3.Request.Builder()
                .url(url)
                .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .build()
            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val body = response.body?.string()
                if (body != null) {
                    val jsonArray = org.json.JSONArray(body)
                    val innerArray = jsonArray.optJSONArray(0)
                    if (innerArray != null && innerArray.length() > 0) {
                        val sb = StringBuilder()
                        for (i in 0 until innerArray.length()) {
                            val item = innerArray.optJSONArray(i)
                            if (item != null && item.length() > 0) {
                                sb.append(item.optString(0))
                            }
                        }
                        val translatedText = sb.toString()
                        val translatedLines = translatedText.lines().map { it.trim() }
                        Result.success(translatedLines)
                    } else {
                        Result.failure(Exception("Empty translation response"))
                    }
                } else {
                    Result.failure(Exception("Null response body"))
                }
            } else {
                Result.failure(Exception("HTTP error: ${response.code}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    sealed class TranslationStatus {
        data object Idle : TranslationStatus()
        data object Translating : TranslationStatus()
        data object Success : TranslationStatus()
        data class Error(val message: String) : TranslationStatus()
    }
}

// ============================================================================
// [LYRICS UTILITIES & MULTI-LANGUAGE ROMANIZATION] Source: LyricsUtils.kt
// ============================================================================

val LINE_REGEX = "((\\[\\d{1,2}:\\d{2}(?:[.:]\\d{1,3})?\\] ?)+)(.*)".toRegex()
val TIME_REGEX = "\\[(\\d{1,2}):(\\d{2})(?:[.:](\\d{1,3}))?\\]".toRegex()

// Regex for rich sync format: [MM:SS.mm]<MM:SS.mm> word <MM:SS.mm> word ...
private val RICH_SYNC_LINE_REGEX = "\\[(\\d{1,2}):(\\d{2})\\.(\\d{2,3})\\](.*)".toRegex()
private val RICH_SYNC_WORD_REGEX = "<(\\d{1,2}):(\\d{2})\\.(\\d{2,3})>([^<]+)".toRegex()

// Regex for Paxsenix v1/v2/bg format
// [00:00.000]v1: <00:00.000>I <00:00.154>promise...
// [bg: <02:18.078>Yeah<02:19.341>]
private val PAXSENIX_AGENT_LINE_REGEX = "\\[(\\d{1,2}):(\\d{2})\\.(\\d{2,3})\\](v\\d+):\\s*(.*)".toRegex()
private val PAXSENIX_BG_LINE_REGEX = "^\\[bg:\\s*(.*)\\]$".toRegex()

// Regex for agent and background markers (existing format)
private val AGENT_REGEX = "\\{agent:([^}]+)\\}".toRegex()
private val BACKGROUND_REGEX = "^\\{bg\\}".toRegex()

@Suppress("RegExpRedundantEscape")
object LyricsUtils {
    fun cleanTitleForSearch(title: String): String {
        return title.replace(Regex("\\s*[(\\[].*?[)\\]]"), "").trim()
    }

    fun filterLyricsCreditLines(lyrics: String): String {
        return lyrics.lines().filter { line ->
            // Strip leading bracketed/braced content, version tags, and timestamps
            // Handles [00:00.00], {agent:v1}, {bg}, [bg: ...], v1: etc.
            var textContent = line.trim()
            
            // Repeatedly strip prefixes while they match common patterns
            var stripping = true
            while (stripping) {
                val prevLength = textContent.length
                textContent = textContent
                    .replaceFirst(Regex("^\\[\\d\\d:\\d\\d\\.\\d{2,3}\\]"), "")
                    .replaceFirst(Regex("^\\{agent:[^}]+\\}"), "")
                    .replaceFirst(Regex("^\\{bg\\}"), "")
                    .replaceFirst(Regex("^\\[bg:.*\\]"), "")
                    .replaceFirst(Regex("^v\\d+:"), "")
                    .trim()
                stripping = textContent.length < prevLength
            }

            val lowerText = textContent.lowercase(Locale.getDefault())
            
            val isCredit = lowerText.startsWith("synced by") ||
                    lowerText.startsWith("lyrics by") ||
                    lowerText.startsWith("music by") ||
                    lowerText.startsWith("arranged by") ||
                    (lowerText.startsWith("[") && lowerText.endsWith("]") && lowerText.length < 40 && lowerText.contains("synced by"))
            
            !isCredit
        }.joinToString("\n")
    }

    private val KANA_ROMAJI_MAP: Map<String, String> = mapOf(
        // Digraphs (Yōon - combinations like kya, sho)
        "キャ" to "kya", "キュ" to "kyu", "キョ" to "kyo",
        "シャ" to "sha", "シュ" to "shu", "ショ" to "sho",
        "チャ" to "cha", "チュ" to "chu", "チョ" to "cho",
        "ニャ" to "nya", "ニュ" to "nyu", "ニョ" to "nyo",
        "ヒャ" to "hya", "ヒュ" to "hyu", "ヒョ" to "hyo",
        "ミャ" to "mya", "ミュ" to "myu", "ミョ" to "myo",
        "リャ" to "rya", "リュ" to "ryu", "リョ" to "ryo",
        "ギャ" to "gya", "ギュ" to "gyu", "ギョ" to "gyo",
        "ジャ" to "ja", "ジュ" to "ju", "ジョ" to "jo",
        "ヂャ" to "ja", "ヂュ" to "ju", "ヂョ" to "jo",
        "ビャ" to "bya", "ビュ" to "byu", "ビョ" to "byo",
        "ピャ" to "pya", "ピュ" to "pyu", "ピョ" to "pyo",
        // Basic Katakana Characters
        "ア" to "a", "イ" to "i", "ウ" to "u", "エ" to "e", "オ" to "o",
        "カ" to "ka", "キ" to "ki", "ク" to "ku", "ケ" to "ke", "コ" to "ko",
        "サ" to "sa", "シ" to "shi", "ス" to "su", "セ" to "se", "ソ" to "so",
        "タ" to "ta", "チ" to "chi", "ツ" to "tsu", "テ" to "te", "ト" to "to",
        "ナ" to "na", "ニ" to "ni", "ヌ" to "nu", "ネ" to "ne", "ノ" to "no",
        "ハ" to "ha", "ヒ" to "hi", "フ" to "fu", "ヘ" to "he", "ホ" to "ho",
        "マ" to "ma", "ミ" to "mi", "ム" to "mu", "メ" to "me", "モ" to "mo",
        "ヤ" to "ya", "ユ" to "yu", "ヨ" to "yo",
        "ラ" to "ra", "リ" to "ri", "ル" to "ru", "レ" to "re", "ロ" to "ro",
        "ワ" to "wa", "ヲ" to "o", "ン" to "n",
        // Dakuten (voiced consonants)
        "ガ" to "ga", "ギ" to "gi", "グ" to "gu", "ゲ" to "ge", "ゴ" to "go",
        "ザ" to "za", "ジ" to "ji", "ズ" to "zu", "ゼ" to "ze", "ゾ" to "zo",
        "ダ" to "da", "ヂ" to "ji", "ヅ" to "zu", "デ" to "de", "ド" to "do",
        // Handakuten (p-sounds for 'h' group)
        "バ" to "ba", "ビ" to "bi", "ブ" to "bu", "ベ" to "be", "ボ" to "bo",
        "パ" to "pa", "ピ" to "pi", "プ" to "pu", "ペ" to "pe", "ポ" to "po",
        // Chōonpu (long vowel mark)
        "ー" to ""
    )

    private val HANGUL_ROMAJA_MAP: Map<String, Map<String, String>> = mapOf(
        "cho" to mapOf(
            "ᄀ" to "g", "ᄁ" to "kk", "ᄂ" to "n", "ᄃ" to "d",
            "ᄄ" to "tt", "ᄅ" to "r", "ᄆ" to "m", "ᄇ" to "b",
            "ᄈ" to "pp", "ᄉ" to "s", "ᄊ" to "ss", "ᄋ" to "",
            "ᄌ" to "j", "ᄍ" to "jj", "ᄎ" to "ch", "ᄏ" to "k",
            "ᄐ" to "t", "ᄑ" to "p", "ᄒ" to "h"
        ),
        "jung" to mapOf(
            "ᅡ" to "a", "ᅢ" to "ae", "ᅣ" to "ya", "ᅤ" to "yae",
            "ᅥ" to "eo", "ᅦ" to "e", "ᅧ" to "yeo", "ᅨ" to "ye",
            "ᅩ" to "o", "ᅪ" to "wa", "ᅫ" to "wae", "ᅬ" to "oe",
            "ᅭ" to "yo", "ᅮ" to "u", "ᅯ" to "wo", "ᅰ" to "we",
            "ᅱ" to "wi", "ᅲ" to "yu", "ᅳ" to "eu", "ᅴ" to "eui",
            "ᅵ" to "i"
        ),
        "jong" to mapOf(
            "ᆨ" to "k", "ᆨᄋ" to "g", "ᆨᄂ" to "ngn", "ᆨᄅ" to "ngn", "ᆨᄆ" to "ngm", "ᆨᄒ" to "kh",
            "ᆩ" to "kk", "ᆩᄋ" to "kg", "ᆩᄂ" to "ngn", "ᆩᄅ" to "ngn", "ᆩᄆ" to "ngm", "ᆩᄒ" to "kh",
            "ᆪ" to "k", "ᆪᄋ" to "ks", "ᆪᄂ" to "ngn", "ᆪᄅ" to "ngn", "ᆪᄆ" to "ngm", "ᆪᄒ" to "kch",
            "ᆫ" to "n", "ᆫᄅ" to "ll", "ᆬ" to "n", "ᆬᄋ" to "nj", "ᆬᄂ" to "nn", "ᆬᄅ" to "nn",
            "ᆬᄆ" to "nm", "ᆬㅎ" to "nch", "ᆭ" to "n", "ᆭᄋ" to "nh", "ᆭᄅ" to "nn", "ᆮ" to "t",
            "ᆮᄋ" to "d", "ᆮᄂ" to "nn", "ᆮᄅ" to "nn", "ᆮᄆ" to "nm", "ᆮᄒ" to "th", "ᆯ" to "l",
            "ᆯᄋ" to "r", "ᆯᄂ" to "ll", "ᆯᄅ" to "ll", "ᆰ" to "k", "ᆰᄋ" to "lg", "ᆰᄂ" to "ngn",
            "ᆰᄅ" to "ngn", "ᆰᄆ" to "ngm", "ᆰᄒ" to "lkh", "ᆱ" to "m", "ᆱᄋ" to "lm", "ᆱᄂ" to "mn",
            "ᆱᄅ" to "mn", "ᆱᄆ" to "mm", "ᆱᄒ" to "lmh", "ᆲ" to "p", "ᆲᄋ" to "lb", "ᆲᄂ" to "mn",
            "ᆲᄅ" to "mn", "ᆲᄆ" to "mm", "ᆲᄒ" to "lph", "ᆳ" to "t", "ᆳᄋ" to "ls", "ᆳᄂ" to "nn",
            "ᆳᄅ" to "nn", "ᆳᄆ" to "nm", "ᆳᄒ" to "lsh", "ᆴ" to "t", "ᆴᄋ" to "lt", "ᆴᄂ" to "nn",
            "ᆴᄅ" to "nn", "ᆴᄆ" to "nm", "ᆴᄒ" to "lth", "ᆵ" to "p", "ᆵᄋ" to "lp", "ᆵᄂ" to "mn",
            "ᆵᄅ" to "mn", "ᆵᄆ" to "mm", "ᆵᄒ" to "lph", "ᆶ" to "l", "ᆶᄋ" to "lh", "ᆶᄂ" to "ll",
            "ᆶᄅ" to "ll", "ᆶᄆ" to "lm", "ᆶᄒ" to "lh", "ᆷ" to "m", "ᆷᄅ" to "mn", "ᆸ" to "p",
            "ᆸᄋ" to "b", "ᆸᄂ" to "mn", "ᆸᄅ" to "mn", "ᆸᄆ" to "mm", "ᆸᄒ" to "ph", "ᆹ" to "p",
            "ᆹᄋ" to "ps", "ᆹᄂ" to "mn", "ᆹᄅ" to "mn", "ᆹᄆ" to "mm", "ᆹᄒ" to "psh", "ᆺ" to "t",
            "ᆺᄋ" to "s", "ᆺᄂ" to "nn", "ᆺᄅ" to "nn", "ᆺᄆ" to "nm", "ᆺᄒ" to "sh", "ᆻ" to "t",
            "ᆻᄋ" to "ss", "ᆻᄂ" to "tn", "ᆻᄅ" to "tn", "ᆻᄆ" to "nm", "ᆻᄒ" to "th", "ᆼ" to "ng",
            "ᆽ" to "t", "ᆽᄋ" to "j", "ᆽᄂ" to "nn", "ᆽᄅ" to "nn", "ᆽᄆ" to "nm", "ᆽᄒ" to "ch",
            "ᆾ" to "t", "ᆾᄋ" to "ch", "ᆾᄂ" to "nn", "ᆾᄅ" to "nn", "ᆾᄆ" to "nm", "ᆾᄒ" to "ch",
            "ᆿ" to "k", "ᆿᄋ" to "k", "ᆿᄂ" to "ngn", "ᆿᄅ" to "ngn", "ᆿᄆ" to "ngm", "ᆿᄒ" to "kh",
            "ᇀ" to "t", "ᇀᄋ" to "t", "ᇀᄂ" to "nn", "ᇀᄅ" to "nn", "ᇀᄆ" to "nm", "ᇀᄒ" to "th",
            "ᇁ" to "p", "ᇁᄋ" to "p", "ᇁᄂ" to "mn", "ᇁᄅ" to "mn", "ᇁᄆ" to "mm", "ᇁᄒ" to "ph",
            "ᇂ" to "t", "ᇂᄋ" to "h", "ᇂᄂ" to "nn", "ᇂᄅ" to "nn", "ᇂᄆ" to "mm", "ᇂᄒ" to "t",
            "ᇂᄀ" to "k"
        )
    )

    private val DEVANAGARI_ROMAJI_MAP: Map<String, String> = mapOf(
        "अ" to "a", "आ" to "aa", "इ" to "i", "ई" to "ee", "उ" to "u", "ऊ" to "oo",
        "ऋ" to "ri", "ए" to "e", "ऐ" to "ai", "ओ" to "o", "औ" to "au",
        "क" to "k", "ख" to "kh", "ग" to "g", "घ" to "gh", "ङ" to "ng",
        "च" to "ch", "छ" to "chh", "ज" to "j", "झ" to "jh", "ञ" to "ny",
        "ट" to "t", "ठ" to "th", "ड" to "d", "ढ" to "dh", "ण" to "n",
        "त" to "t", "थ" to "th", "द" to "d", "ध" to "dh", "न" to "n",
        "प" to "p", "फ" to "ph", "ब" to "b", "भ" to "bh", "म" to "m",
        "य" to "y", "र" to "r", "ल" to "l", "व" to "v",
        "श" to "sh", "ष" to "sh", "स" to "s", "ह" to "h",
        "क्ष" to "ksh", "त्र" to "tr", "ज्ञ" to "gy", "श्र" to "shr",
        "ा" to "aa", "ि" to "i", "ी" to "ee", "ु" to "u", "ू" to "oo",
        "ृ" to "ri", "े" to "e", "ै" to "ai", "ो" to "o", "ौ" to "au",
        "ं" to "n", "ः" to "h", "ँ" to "n", "़" to "", "्" to "",
        "०" to "0", "१" to "1", "२" to "2", "३" to "3", "४" to "4",
        "५" to "5", "६" to "6", "७" to "7", "८" to "8", "९" to "9",
        "ॐ" to "Om", "ऽ" to "",
        "क़" to "q", "ख़" to "kh", "ग़" to "g", "ज़" to "z", "ड़" to "r", "ढ़" to "rh", "फ़" to "f", "य़" to "y",
        // Decomposed characters with Nukta
        "क\u093C" to "q", "ख\u093C" to "kh", "ग\u093C" to "g", "ज\u093C" to "z", "ड\u093C" to "r", "ढ\u093C" to "rh", "फ\u093C" to "f", "य\u093C" to "y"
    )

    private val GURMUKHI_ROMAJI_MAP: Map<String, String> = mapOf(
        "ੳ" to "o", "ਅ" to "a", "ੲ" to "e", "ਸ" to "s", "ਹ" to "h",
        "ਕ" to "k", "ਖ" to "kh", "ਗ" to "g", "ਘ" to "gh", "ਙ" to "ng",
        "ਚ" to "ch", "ਛ" to "chh", "ਜ" to "j", "ਝ" to "jh", "ਞ" to "ny",
        "ਟ" to "t", "ਠ" to "th", "ਡ" to "d", "ਢ" to "dh", "ਣ" to "n",
        "ਤ" to "t", "ਥ" to "th", "ਦ" to "d", "ਧ" to "dh", "ਨ" to "n",
        "ਪ" to "p", "ਫ" to "ph", "ਬ" to "b", "ਭ" to "bh", "ਮ" to "m",
        "ਯ" to "y", "ਰ" to "r", "ਲ" to "l", "ਵ" to "v", "ੜ" to "r",
        "ਸ਼" to "sh", "ਖ਼" to "kh", "ਗ਼" to "g", "ਜ਼" to "z", "ਫ਼" to "f", "ਲ਼" to "l",
        "ਾ" to "aa", "ਿ" to "i", "ੀ" to "ee", "ੁ" to "u", "ੂ" to "oo",
        "ੇ" to "e", "ੈ" to "ai", "ੋ" to "o", "ੌ" to "au",
        "ੰ" to "n", "ਂ" to "n", "ੱ" to "", "੍" to "", "਼" to "",
        "ੴ" to "Ek Onkar",
        "੦" to "0", "੧" to "1", "੨" to "2", "੩" to "3", "੪" to "4",
        "੫" to "5", "੬" to "6", "੭" to "7", "੮" to "8", "੯" to "9"
    )

    private val GENERAL_CYRILLIC_ROMAJI_MAP: Map<String, String> = mapOf(
        "А" to "A", "Б" to "B", "В" to "V", "Г" to "G", "Ґ" to "G", "Д" to "D",
        "Ѓ" to "Ǵ", "Ђ" to "Đ", "Е" to "E", "Ё" to "Yo", "Є" to "Ye", "Ж" to "Zh",
        "З" to "Z", "Ѕ" to "Dz", "И" to "I", "І" to "I", "Ї" to "Yi", "Й" to "Y",
        "Ј" to "Y", "К" to "K", "Л" to "L", "Љ" to "Ly", "М" to "M", "Н" to "N",
        "Њ" to "Ny", "О" to "O", "П" to "P", "Р" to "R", "С" to "S", "Т" to "T",
        "Ћ" to "Ć", "У" to "U", "Ў" to "Ŭ", "Ф" to "F", "Х" to "Kh", "Ц" to "Ts",
        "Ч" to "Ch", "Џ" to "Dž", "Ш" to "Sh", "Щ" to "Shch", "Ъ" to "ʺ", "Ы" to "Y",
        "Ь" to "ʹ", "Э" to "E", "Ю" to "Yu", "Я" to "Ya",
        "Ѡ" to "O", "Ѣ" to "Ya", "Ѥ" to "Ye", "Ѧ" to "Ya", "Ѩ" to "Ya",
        "Ѫ" to "U", "Ѭ" to "Yu", "Ѯ" to "Ks", "Ѱ" to "Ps", "Ѳ" to "F",
        "Ѵ" to "I", "Ѷ" to "I", "Ғ" to "Gh", "Ҕ" to "G", "Җ" to "Zh",
        "Ҙ" to "Dz", "Қ" to "Q", "Ҝ" to "K", "Ҟ" to "K", "Ҡ" to "K",
        "Ң" to "Ng", "Ҥ" to "Ng", "Ҧ" to "P", "Ҩ" to "O", "Ҫ" to "S",
        "Ҭ" to "T", "Ү" to "U", "Ұ" to "U", "Ҳ" to "Kh", "Ҵ" to "Ts",
        "Ҷ" to "Ch", "Ҹ" to "Ch", "Һ" to "H", "Ҽ" to "Ch", "Ҿ" to "Ch",
        "Ќ" to "Ḱ", "Ө" to "Ö",

        "а" to "a", "б" to "b", "в" to "v", "г" to "g", "ґ" to "g", "д" to "d",
        "ѓ" to "ǵ", "ђ" to "đ", "е" to "e", "ё" to "yo", "є" to "ye", "ж" to "zh",
        "з" to "z", "ѕ" to "dz", "и" to "i", "і" to "i", "ї" to "yi", "й" to "y",
        "ј" to "y", "к" to "k", "л" to "l", "љ" to "ly", "м" to "m", "н" to "n",
        "њ" to "ny", "о" to "o", "п" to "p", "р" to "r", "с" to "s", "т" to "t",
        "ћ" to "ć", "у" to "u", "ў" to "ŭ", "ф" to "f", "х" to "kh", "ц" to "ts",
        "ч" to "ch", "џ" to "dž", "ш" to "sh", "щ" to "shch", "ъ" to "ʺ", "ы" to "y",
        "ь" to "ʹ", "э" to "e", "ю" to "yu", "я" to "ya",
        "ѡ" to "o", "ѣ" to "ya", "ѥ" to "ye", "ѧ" to "ya", "ѩ" to "ya",
        "ѫ" to "u", "ѭ" to "yu", "ѯ" to "ks", "ѱ" to "ps", "ѳ" to "f",
        "ѵ" to "i", "ѷ" to "i", "ғ" to "gh", "ҕ" to "g", "җ" to "zh",
        "ҙ" to "dz", "қ" to "q", "ҝ" to "k", "ҟ" to "k", "ҡ" to "k",
        "ң" to "ng", "ҥ" to "ng", "ҧ" to "p", "ҩ" to "o", "ҫ" to "s",
        "ҭ" to "t", "ү" to "u", "ұ" to "u", "ҳ" to "kh", "ҵ" to "ts",
        "ҷ" to "ch", "ҹ" to "ch", "һ" to "h", "ҽ" to "ch", "ҿ" to "ch",
        "ќ" to "ḱ", "ө" to "ö"
    )

    private val RUSSIAN_ROMAJI_MAP: Map<String, String> = mapOf(
        "ого" to "ovo", "Ого" to "Ovo", "его" to "evo", "Его" to "Evo"
    )

    private val UKRAINIAN_ROMAJI_MAP: Map<String, String> = mapOf(
        "Г" to "H", "г" to "h",
        "Ґ" to "G", "ґ" to "g",
        "Є" to "Ye", "є" to "ye",
        "І" to "I", "і" to "i",
        "Ї" to "Yi", "ї" to "yi"
    )

    private val SERBIAN_ROMAJI_MAP: Map<String, String> = mapOf(
        "Ж" to "Ž", "Љ" to "Lj", "Њ" to "Nj", "Ц" to "C", "Ч" to "Č",
        "Џ" to "Dž", "Ш" to "Š", "Х" to "H",

        "ж" to "ž", "љ" to "lj", "њ" to "nj", "ц" to "c", "ч" to "č",
        "џ" to "dž", "ш" to "š", "х" to "h"
    )

    private val BULGARIAN_ROMAJI_MAP: Map<String, String> = mapOf(
        "Ж" to "Zh", "Ц" to "Ts", "Ч" to "Ch", "Ш" to "Sh", "Щ" to "Sht",
        "Ъ" to "A", "Ь" to "Y", "Ю" to "Yu", "Я" to "Ya",

        "ж" to "zh", "ц" to "ts", "ч" to "ch", "ш" to "sh", "щ" to "sht",
        "ъ" to "a", "ь" to "y", "ю" to "yu", "я" to "ya"
    )

    private val BELARUSIAN_ROMAJI_MAP: Map<String, String> = mapOf(
        "Г" to "H", "г" to "h", "Ў" to "W", "ў" to "w"
    )

    private val KYRGYZ_ROMAJI_MAP: Map<String, String> = mapOf(
        "Ү" to "Ü", "ү" to "ü", "Ы" to "Y", "ы" to "y"
    )

    private val MACEDONIAN_ROMAJI_MAP: Map<String, String> = mapOf(
        "Ѓ" to "Gj", "Ѕ" to "Dz", "И" to "I", "Ј" to "J", "Љ" to "Lj",
        "Њ" to "Nj", "Ќ" to "Kj", "Џ" to "Dž", "Ч" to "Č", "Ш" to "Sh",
        "Ж" to "Zh", "Ц" to "C", "Х" to "H",

        "ѓ" to "gj", "ѕ" to "dz", "и" to "i", "ј" to "j", "љ" to "lj",
        "њ" to "nj", "ќ" to "kj", "џ" to "dž", "ч" to "č", "ш" to "sh",
        "ж" to "zh", "ц" to "c", "х" to "h"
    )

    private val RUSSIAN_CYRILLIC_LETTERS = setOf(
        "А", "Б", "В", "Г", "Д", "Е", "Ё", "Ж", "З", "И", "Й", "К", "Л", "М", "Н",
        "О", "П", "Р", "С", "Т", "У", "Ф", "Х", "Ц", "Ч", "Ш", "Щ", "Ъ", "Ы", "Ь",
        "Э", "Ю", "Я",

        "а", "б", "в", "г", "д", "е", "ё", "ж", "з", "и", "й", "к", "л", "м", "н",
        "о", "п", "р", "с", "т", "у", "ф", "х", "ц", "ч", "ш", "щ", "ъ", "ы", "ь",
        "э", "ю", "я"
    )

    private val UKRAINIAN_CYRILLIC_LETTERS = setOf(
       "А", "Б", "В", "Г", "Ґ", "Д", "Е", "Є", "Ж", "З", "И", "І", "Ї", "Й",
        "К", "Л", "М", "Н", "О", "П", "Р", "С", "Т", "У", "Ф", "Х", "Ц", "Ч",
        "Ш", "Щ", "Ь", "Ю", "Я",

        "а", "б", "в", "г", "ґ", "д", "е", "є", "ж", "з", "и", "і", "ї", "й",
        "к", "л", "м", "н", "о", "п", "р", "с", "т", "у", "ф", "х", "ц", "ч",
        "ш", "щ", "ь", "ю", "я"
    )

    private val SERBIAN_CYRILLIC_LETTERS = setOf(
        "А", "Б", "В", "Г", "Д", "Ђ", "Е", "Ж", "З", "И", "Ј", "К", "Л", "Љ", "М",
        "Н", "Њ", "О", "П", "Р", "С", "Т", "Ћ", "У", "Ф", "Х", "Ц", "Ч", "Џ", "Ш",

        "а", "б", "в", "г", "д", "ђ", "е", "ж", "з", "и", "ј", "к", "л", "љ", "м",
        "н", "њ", "о", "п", "р", "с", "т", "ћ", "у", "ф", "х", "ц", "ч", "џ", "ш"
    )

    private val BULGARIAN_CYRILLIC_LETTERS = setOf(
        "А", "Б", "В", "Г", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М",
        "Н", "О", "П", "Р", "С", "Т", "У", "Ф", "Х", "Ц", "Ч", "Ш", "Щ",
        "Ъ", "Ь", "Ю", "Я",

        "а", "б", "в", "г", "д", "е", "ж", "з", "и", "й", "к", "л", "м",
        "н", "о", "п", "р", "с", "т", "у", "ф", "х", "ц", "ч", "ш", "щ",
        "ъ", "ь", "ю", "я"
    )

    private val BELARUSIAN_CYRILLIC_LETTERS = setOf(
        "А", "Б", "В", "Г", "Д", "Е", "Ё", "Ж", "З", "І", "Й", "К", "Л", "М", "Н",
        "О", "П", "Р", "С", "Т", "У", "Ў", "Ф", "Х", "Ц", "Ч", "Ш", "Ь", "Ю", "Я",
        "Ы", "Э",

        "а", "б", "в", "г", "д", "е", "ё", "ж", "з", "і", "й", "к", "л", "м", "н",
        "о", "п", "р", "с", "т", "у", "ў", "ф", "х", "ц", "ч", "ш", "ь", "ю", "я",
        "ы", "э"
    )

    private val KYRGYZ_CYRILLIC_LETTERS = setOf(
        "А", "Б", "В", "Г", "Д", "Е", "Ё", "Ж", "З", "И", "Й", "К", "Л", "М", "Н",
        "Ң", "О", "Ө", "П", "Р", "С", "Т", "У", "Ү", "Ф", "Х", "Ц", "Ч", "Ш", "Щ",
        "Ъ", "Ы", "Ь", "Э", "Ю", "Я",

        "а", "б", "в", "г", "д", "е", "ё", "ж", "з", "и", "й", "к", "л", "м", "н",
        "ң", "о", "ө", "п", "р", "с", "т", "у", "ү", "ф", "х", "ц", "ч", "ш", "щ",
        "ъ", "ы", "ь", "э", "ю", "я"
    )

    private val MACEDONIAN_CYRILLIC_LETTERS = setOf(
        "А", "Б", "В", "Г", "Д", "Ѓ", "Е", "Ж", "З", "Ѕ", "И", "Ј", "К", "Л",
        "Љ", "М", "Н", "Њ", "О", "П", "Р", "С", "Т", "Ќ", "У", "Ф", "Х",
        "Ц", "Ч", "Џ", "Ш",

        "а", "б", "в", "г", "д", "ѓ", "е", "ж", "з", "ѕ", "и", "ј", "к", "л",
        "љ", "м", "н", "њ", "о", "п", "р", "с", "т", "ќ", "у", "ф", "х",
        "ц", "ч", "џ", "ш"
    )

    private val UKRAINIAN_SPECIFIC_CYRILLIC_LETTERS = setOf(
        "Ґ", "ґ", "Є", "є", "І", "і", "Ї", "ї"
    )

    private val SERBIAN_SPECIFIC_CYRILLIC_LETTERS = setOf(
        "Ђ", "ђ", "Ј", "ј", "Љ", "љ", "Њ", "њ", "Ћ", "ћ", "Џ", "џ"
    )

    private val BELARUSIAN_SPECIFIC_CYRILLIC_LETTERS = setOf(
        "Ў", "ў", "І", "і"
    )

    private val KYRGYZ_SPECIFIC_CYRILLIC_LETTERS = setOf(
        "Ң", "ң", "Ө", "ө", "Ү", "ү"
    )

    private val MACEDONIAN_SPECIFIC_CYRILLIC_LETTERS = setOf(
        "Ѓ", "ѓ", "Ѕ", "ѕ", "Ќ", "ќ"
    )

    // Lazy initialized Tokenizer
    private val kuromojiTokenizer: Tokenizer by lazy {
        Tokenizer()
    }

    private val HEX_ENTITY_REGEX = "&#x([0-9a-fA-F]+);".toRegex()
    private val DEC_ENTITY_REGEX = "&#(\\d+);".toRegex()

    private fun decodeHtmlEntities(text: String): String {
        if (!text.contains('&')) return text
        val sb = StringBuilder(text.length)
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (c == '&') {
                val end = text.indexOf(';', i + 1)
                if (end != -1 && end - i < 12) {
                    val entity = text.substring(i, end + 1)
                    val decoded = when {
                        entity == "&apos;" -> "'"
                        entity == "&quot;" -> "\""
                        entity == "&lt;" -> "<"
                        entity == "&gt;" -> ">"
                        entity == "&nbsp;" -> " "
                        entity == "&amp;" -> "&"
                        entity.startsWith("&#x") -> {
                            entity.substring(3, entity.length - 1).toIntOrNull(16)?.let { codePoint ->
                                if (Character.isValidCodePoint(codePoint)) String(Character.toChars(codePoint)) else "\uFFFD"
                            }
                        }
                        entity.startsWith("&#") -> {
                            entity.substring(2, entity.length - 1).toIntOrNull()?.let { codePoint ->
                                if (Character.isValidCodePoint(codePoint)) String(Character.toChars(codePoint)) else "\uFFFD"
                            }
                        }
                        else -> null
                    }
                    if (decoded != null) {
                        sb.append(decoded)
                        i = end + 1
                        continue
                    }
                }
            }
            sb.append(c)
            i++
        }
        return sb.toString()
    }

    fun parseLyrics(lyrics: String): List<LyricsEntry> {
        if (lyrics.isBlank()) return emptyList()

        // Fast unescape
        val unescapedLyrics = if (lyrics.contains('\\') || lyrics.startsWith("\"")) {
            val s = lyrics.trim().removePrefix("\"").removeSuffix("\"")
            val sb = StringBuilder(s.length)
            var j = 0
            while (j < s.length) {
                val c = s[j]
                if (c == '\\' && j + 1 < s.length) {
                    when (val next = s[j + 1]) {
                        '\\' -> sb.append('\\')
                        'n' -> sb.append('\n')
                        'r' -> sb.append('\r')
                        't' -> sb.append('\t')
                        else -> sb.append(c).append(next)
                    }
                    j += 2
                } else {
                    sb.append(c)
                    j++
                }
            }
            sb.toString()
        } else lyrics

        val decodedLyrics = decodeHtmlEntities(unescapedLyrics)

        val lines = decodedLyrics.lines()
            .filter { 
                it.isNotBlank() || it.trim().startsWith("[") || it.trim().startsWith("<")
            }
            .filter { !it.trim().startsWith("[offset:") }

        // Check if this is rich sync format (contains <MM:SS.mm> patterns)
        val isRichSync = lines.any { line ->
            RICH_SYNC_LINE_REGEX.matches(line.trim()) &&
            RICH_SYNC_WORD_REGEX.containsMatchIn(line)
        }

        return if (isRichSync) {
            parseRichSyncLyrics(lines)
        } else {
            parseStandardLyrics(lines)
        }
    }

    /**
     * Parse rich sync lyrics format: [MM:SS.mm]<MM:SS.mm> word <MM:SS.mm> word ...
     * This format provides word-by-word timing for karaoke-style highlighting
     */
    private fun parseRichSyncLyrics(lines: List<String>): List<LyricsEntry> {
        val result = mutableListOf<LyricsEntry>()
        var lastNonBgAgent: String? = null

        lines.forEachIndexed { index, line ->
            val trimmedLine = line.trim()
            
            // Try Paxsenix bg format first: [bg: <02:18.078>Yeah<02:19.341>]
            val bgMatch = PAXSENIX_BG_LINE_REGEX.find(trimmedLine)
            if (bgMatch != null) {
                val content = bgMatch.groupValues[1]
                
                // Parse word-level timestamps from content
                val wordTimings = parseRichSyncWords(content, index, lines)
                    ?: run {
                        val nextLine = lines.getOrNull(index + 1)?.trim() ?: ""
                        if (nextLine.startsWith("<") && nextLine.endsWith(">")) {
                            parseWordTimestamps(nextLine.removeSurrounding("<", ">"))
                        } else null
                    }
                
                // Extract plain text (remove all <MM:SS.mm> tags)
                val plainText = content.replace(Regex("<\\d{1,2}:\\d{2}\\.\\d{2,3}>\\s*"), "").trim()
                
                val lineTimeMs = wordTimings?.firstOrNull()?.startTime?.let { (it * 1000).toLong() } ?: 0L
                result.add(LyricsEntry(lineTimeMs, plainText, wordTimings, agent = lastNonBgAgent ?: "bg", isBackground = true))
                return@forEachIndexed
            }
            
            // Try Paxsenix agent format: [00:00.000]v1: <00:00.000>I <00:00.154>promise...
            val agentMatch = PAXSENIX_AGENT_LINE_REGEX.find(trimmedLine)
            if (agentMatch != null) {
                val minutes = agentMatch.groupValues[1].toLongOrNull() ?: 0L
                val seconds = agentMatch.groupValues[2].toLongOrNull() ?: 0L
                val centiseconds = agentMatch.groupValues[3].toLongOrNull() ?: 0L
                val agent = agentMatch.groupValues[4] // v1, v2, etc.
                val content = agentMatch.groupValues[5]
                
                val millisPart = if (agentMatch.groupValues[3].length == 3) centiseconds else centiseconds * 10
                val lineTimeMs = minutes * DateUtils.MINUTE_IN_MILLIS + seconds * DateUtils.SECOND_IN_MILLIS + millisPart
                
                // Parse word-level timestamps from content
                val wordTimings = parseRichSyncWords(content, index, lines)
                    ?: run {
                        val nextLine = lines.getOrNull(index + 1)?.trim() ?: ""
                        if (nextLine.startsWith("<") && nextLine.endsWith(">")) {
                            parseWordTimestamps(nextLine.removeSurrounding("<", ">"))
                        } else null
                    }
                
                // Extract plain text (remove all <MM:SS.mm> tags)
                val plainText = content.replace(Regex("<\\d{1,2}:\\d{2}\\.\\d{2,3}>\\s*"), "").trim()
                
                if (!agent.isNullOrBlank()) {
                    lastNonBgAgent = agent
                }
                result.add(LyricsEntry(lineTimeMs, plainText, wordTimings, agent = agent, isBackground = false))
                return@forEachIndexed
            }
            
            // Try existing format: [MM:SS.mm]{agent:v1}... or [MM:SS.mm]{bg}...
            val matchResult = RICH_SYNC_LINE_REGEX.matchEntire(trimmedLine)
            if (matchResult != null) {
                val minutes = matchResult.groupValues[1].toLongOrNull() ?: 0L
                val seconds = matchResult.groupValues[2].toLongOrNull() ?: 0L
                val centiseconds = matchResult.groupValues[3].toLongOrNull() ?: 0L

                // Convert to milliseconds
                val millisPart = if (matchResult.groupValues[3].length == 3) centiseconds else centiseconds * 10
                val lineTimeMs = minutes * DateUtils.MINUTE_IN_MILLIS + seconds * DateUtils.SECOND_IN_MILLIS + millisPart

                var content = matchResult.groupValues[4].trimStart()

                // Parse agent marker {agent:v1}
                val oldAgentMatch = AGENT_REGEX.find(content)
                val agent = oldAgentMatch?.groupValues?.get(1)
                if (oldAgentMatch != null) {
                    content = content.replaceFirst(AGENT_REGEX, "")
                }

                // Parse background marker {bg}
                val isBackground = BACKGROUND_REGEX.containsMatchIn(content)
                if (isBackground) {
                    content = content.replaceFirst(BACKGROUND_REGEX, "")
                }

                // Parse word-level timestamps from content
                val wordTimings = parseRichSyncWords(content, index, lines)
                    ?: run {
                        val nextLine = lines.getOrNull(index + 1)?.trim() ?: ""
                        if (nextLine.startsWith("<") && nextLine.endsWith(">")) {
                            parseWordTimestamps(nextLine.removeSurrounding("<", ">"))
                        } else null
                    }

                // Extract plain text (remove all <MM:SS.mm> tags)
                val plainText = content.replace(Regex("<\\d{1,2}:\\d{2}\\.\\d{2,3}>\\s*"), "").trim()

                if (!isBackground && !agent.isNullOrBlank()) {
                    lastNonBgAgent = agent
                }
                result.add(LyricsEntry(lineTimeMs, plainText, wordTimings, agent = if (isBackground) lastNonBgAgent ?: "bg" else agent, isBackground = isBackground))
            }
        }

        return result.sorted()
    }

    /**
     * Parse word timestamps from rich sync content
     * Format: <MM:SS.mm> word <MM:SS.mm> word ...
     */
    private fun parseRichSyncWords(content: String, currentIndex: Int, allLines: List<String>): List<WordTimestamp>? {
        val wordMatches = RICH_SYNC_WORD_REGEX.findAll(content).toList()

        if (wordMatches.isEmpty()) return null

        // Check for a trailing end timestamp after the last word.
        // The provider uses two formats:
        //   - Angle brackets: <MM:SS.mmm> (used in v1:/v2: prefixed lines)
        //   - Square brackets: [MM:SS.xx] (used in non-prefixed lines)
        val lastMatchEnd = wordMatches.last().range.last
        val trailingContent = content.substring(lastMatchEnd + 1).trim()
        val angleTrailingMatch = "<(\\d{1,2}):(\\d{2})\\.(\\d{2,3})>".toRegex().find(trailingContent)
        val squareTrailingMatch = "\\[(\\d{1,2}):(\\d{2})\\.(\\d{2,3})\\]".toRegex().find(trailingContent)
        val trailingTimeMatch = angleTrailingMatch ?: squareTrailingMatch
        val trailingEndTime: Double? = if (trailingTimeMatch != null && trailingContent.substring(trailingTimeMatch.range.last + 1).removeSuffix("]").isBlank()) {
            val tMin = trailingTimeMatch.groupValues[1].toLongOrNull() ?: 0L
            val tSec = trailingTimeMatch.groupValues[2].toLongOrNull() ?: 0L
            val tFrac = trailingTimeMatch.groupValues[3].toLongOrNull() ?: 0L
            val tFracPart = if (trailingTimeMatch.groupValues[3].length == 3) tFrac / 1000.0 else tFrac / 100.0
            tMin * 60.0 + tSec + tFracPart
        } else null

        val wordTimings = mutableListOf<WordTimestamp>()

        wordMatches.forEachIndexed { index, match ->
            val minutes = match.groupValues[1].toLongOrNull() ?: 0L
            val seconds = match.groupValues[2].toLongOrNull() ?: 0L
            val fraction = match.groupValues[3].toLongOrNull() ?: 0L

            val fractionPart = if (match.groupValues[3].length == 3) fraction / 1000.0 else fraction / 100.0
            val startTimeSeconds = minutes * 60.0 + seconds + fractionPart

            val rawText = match.groupValues[4]
            val hasTrailingSpace = rawText.endsWith(" ")
            val words = rawText.trim().split(Regex("\\s+")).filter { it.isNotBlank() }

            // Get the next timestamp for end time calculation
            val nextTimestamp: Double
            val nextLineTime: Double?

            if (index < wordMatches.size - 1) {
                val nextMatch = wordMatches[index + 1]
                val nextMin = nextMatch.groupValues[1].toLongOrNull() ?: 0L
                val nextSec = nextMatch.groupValues[2].toLongOrNull() ?: 0L
                val nextFrac = nextMatch.groupValues[3].toLongOrNull() ?: 0L
                val nextFracPart = if (nextMatch.groupValues[3].length == 3) nextFrac / 1000.0 else nextFrac / 100.0
                nextTimestamp = nextMin * 60.0 + nextSec + nextFracPart
                nextLineTime = null
            } else {
                nextLineTime = getNextLineStartTime(currentIndex, allLines)
                nextTimestamp = trailingEndTime ?: nextLineTime ?: (startTimeSeconds + 0.5)
            }

            words.forEachIndexed { wordIndex, word ->
                val isLastWordInGroup = wordIndex == words.lastIndex
                val isLastWordOverall = index == wordMatches.lastIndex && isLastWordInGroup

                val wordStartTime = startTimeSeconds + (nextTimestamp - startTimeSeconds) * wordIndex / words.size
                val wordEndTime = if (!isLastWordInGroup) {
                    startTimeSeconds + (nextTimestamp - startTimeSeconds) * (wordIndex + 1) / words.size
                } else if (!isLastWordOverall) {
                    nextTimestamp
                } else {
                    trailingEndTime ?: nextLineTime ?: (startTimeSeconds + 0.5)
                }

                val wordHasTrailingSpace = if (!isLastWordInGroup) {
                    true
                } else if (!isLastWordOverall) {
                    hasTrailingSpace
                } else {
                    // Last word of last match - check if there's text after it (excluding our optional trailing timestamp)
                    val textAfterMatch = if (trailingTimeMatch != null) {
                        trailingContent.substring(0, trailingTimeMatch.range.first)
                    } else {
                        trailingContent
                    }
                    textAfterMatch.isNotBlank()
                }

                if (word.isNotBlank()) {
                    wordTimings.add(WordTimestamp(word, wordStartTime, wordEndTime, wordHasTrailingSpace))
                }
            }
        }

        return if (wordTimings.isNotEmpty()) wordTimings else null
    }

    /**
     * Get the start time of the next line for calculating the last word's end time
     */
    private fun getNextLineStartTime(currentIndex: Int, allLines: List<String>): Double? {
        if (currentIndex + 1 >= allLines.size) return null

        val nextLine = allLines[currentIndex + 1].trim()
        
        // Try standard rich sync line
        val matchResult = RICH_SYNC_LINE_REGEX.matchEntire(nextLine)
        if (matchResult != null) {
            val minutes = matchResult.groupValues[1].toLongOrNull() ?: return null
            val seconds = matchResult.groupValues[2].toLongOrNull() ?: return null
            val fraction = matchResult.groupValues[3].toLongOrNull() ?: 0L

            val fractionPart = if (matchResult.groupValues[3].length == 3) fraction / 1000.0 else fraction / 100.0
            return minutes * 60.0 + seconds + fractionPart
        }
        
        // Try background line
        val bgMatch = PAXSENIX_BG_LINE_REGEX.matchEntire(nextLine)
        if (bgMatch != null) {
            val content = bgMatch.groupValues[1]
            val wordMatch = RICH_SYNC_WORD_REGEX.find(content) ?: return null
            val minutes = wordMatch.groupValues[1].toLongOrNull() ?: return null
            val seconds = wordMatch.groupValues[2].toLongOrNull() ?: return null
            val fraction = wordMatch.groupValues[3].toLongOrNull() ?: 0L
            val fractionPart = if (wordMatch.groupValues[3].length == 3) fraction / 1000.0 else fraction / 100.0
            return minutes * 60.0 + seconds + fractionPart
        }

        return null
    }

    /**
     * Parse standard synced lyrics format: [MM:SS.mm] text
     */
    private fun parseStandardLyrics(lines: List<String>): List<LyricsEntry> {
        val result = mutableListOf<LyricsEntry>()

        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            if (!line.trim().startsWith("<") || !line.trim().endsWith(">")) {
                val entries = parseLine(line, null)
                if (entries != null) {
                    val wordTimestamps = if (i + 1 < lines.size) {
                        val nextLine = lines[i + 1]
                        if (nextLine.trim().startsWith("<") && nextLine.trim().endsWith(">")) {
                            parseWordTimestamps(nextLine.trim().removeSurrounding("<", ">"))
                        } else null
                    } else null

                    if (wordTimestamps != null) {
                        result.addAll(entries.map { entry ->
                            LyricsEntry(entry.time, entry.text, wordTimestamps, agent = entry.agent, isBackground = entry.isBackground)
                        })
                    } else {
                        result.addAll(entries)
                    }
                }
            }
            i++
        }
        return result.sorted()
    }

    private fun parseWordTimestamps(data: String): List<WordTimestamp>? {
        if (data.isBlank()) return null
        return try {
            data.split("|").mapNotNull { wordData ->
                val parts = wordData.split(":")
                if (parts.size >= 3) {
                    val text = parts.dropLast(2).joinToString(":")
                    val startTime = parts[parts.size - 2].toDoubleOrNull() ?: 0.0
                    val endTime = parts[parts.size - 1].toDoubleOrNull() ?: 0.0
                    val isLast = wordData == data.split("|").last()
                    WordTimestamp(
                        text = text,
                        startTime = startTime,
                        endTime = endTime,
                        hasTrailingSpace = !isLast
                    )
                } else null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun parseLine(line: String, words: List<WordTimestamp>? = null): List<LyricsEntry>? {
        val matchResult = LINE_REGEX.matchEntire(line.trim()) ?: return null
        val times = matchResult.groupValues[1]
        var text = matchResult.groupValues[3]
        val timeMatchResults = TIME_REGEX.findAll(times)

        // Parse agent marker {agent:v1}
        val agentMatch = AGENT_REGEX.find(text)
        val agent = agentMatch?.groupValues?.get(1)
        if (agentMatch != null) {
            text = text.replaceFirst(AGENT_REGEX, "")
        }

        // Parse background marker {bg}
        val isBackground = BACKGROUND_REGEX.containsMatchIn(text)
        if (isBackground) {
            text = text.replaceFirst(BACKGROUND_REGEX, "")
        }

        return timeMatchResults
            .map { timeMatchResult ->
                val min = timeMatchResult.groupValues[1].toLongOrNull() ?: 0L
                val sec = timeMatchResult.groupValues[2].toLongOrNull() ?: 0L
                val milString = timeMatchResult.groupValues[3]
                val mil = when (milString.length) {
                    1 -> (milString.toLongOrNull() ?: 0L) * 100
                    2 -> (milString.toLongOrNull() ?: 0L) * 10
                    3 -> milString.toLongOrNull() ?: 0L
                    else -> 0L
                }
                val time = min * DateUtils.MINUTE_IN_MILLIS + sec * DateUtils.SECOND_IN_MILLIS + mil
                LyricsEntry(time, text, words, agent = agent, isBackground = isBackground)
            }.toList()
    }

    fun findCurrentLineIndex(
        lines: List<LyricsEntry>,
        position: Long,
    ): Int {
        val threshold = 100L
        for (index in lines.indices) {
            if (lines[index].time >= position + threshold) {
                return index - 1
            }
        }
        return lines.lastIndex
    }

    /**
     * Returns the set of line indices that are currently active (being sung).
     * A line is active if playback position >= line.time AND position < line end time.
     * Line end time = the last word's endTime if word timings exist, otherwise the next line's start time.
     * This supports simultaneous singers whose lines overlap in time.
     */
    fun findActiveLineIndices(
        lines: List<LyricsEntry>,
        position: Long,
        allowConnectedLines: Boolean = true
    ): Set<Int> {
        val active = mutableSetOf<Int>()
        val hasWordTimings = lines.any { !it.words.isNullOrEmpty() }

        for (index in lines.indices) {
            val line = lines[index]
            if (line.time > position) break // Past current position, stop early

            // Determine this line's end time
            val lineEndMs: Long = if (!line.words.isNullOrEmpty()) {
                // Use last word's endTime converted to ms
                (line.words.last().endTime * 1000).toLong()
            } else {
                // Fallback: next line's start time
                if (index + 1 < lines.size) lines[index + 1].time else Long.MAX_VALUE
            }

            if (position <= lineEndMs) {
                active.add(index)
            }
        }

        if (!allowConnectedLines && active.size > 1) {
            val maxActive = active.maxOrNull()
            if (maxActive != null) {
                active.clear()
                active.add(maxActive)
            }
        } else if (!hasWordTimings && active.size > 1) {
            val mainActive = active.filter { lines[it].isBackground == false }
            if (mainActive.size > 1) {
                val maxTime = mainActive.maxOf { lines[it].time }
                active.removeAll { it in mainActive && lines[it].time < maxTime }
            }
        }

        return active
    }

    // TODO: Will be useful if we let the user pick the language, useless for now
    /* enum class CyrillicLanguage {
        RUSSIAN,
        UKRAINIAN,
        SERBIAN,
        BULGARIAN,
        BELARUSIAN,
        KYRGYZ,
        MACEDONIAN
    } */

    suspend fun romanizeJapanese(text: String): String = withContext(Dispatchers.Default) {
        val tokens = kuromojiTokenizer.tokenize(text)
        val romanizedTokens = tokens.mapIndexed { index, token ->
            val currentReading = if (token.reading.isNullOrEmpty() || token.reading == "*") {
                token.surface
            } else {
                token.reading
            }
            val nextTokenReading = if (index + 1 < tokens.size) {
                tokens[index + 1].reading?.takeIf { it.isNotEmpty() && it != "*" } ?: tokens[index + 1].surface
            } else {
                null
            }
            katakanaToRomaji(currentReading, nextTokenReading)
        }
        romanizedTokens.joinToString(" ")
    }

    fun katakanaToRomaji(katakana: String?, nextKatakana: String? = null): String {
        if (katakana.isNullOrEmpty()) return ""

        val romajiBuilder = StringBuilder(katakana.length)
        var i = 0
        val n = katakana.length
        while (i < n) {
            var consumed = false
            if (i + 1 < n) {
                val twoCharCandidate = katakana.substring(i, i + 2)
                val mappedTwoChar = KANA_ROMAJI_MAP[twoCharCandidate]
                if (mappedTwoChar != null) {
                    romajiBuilder.append(mappedTwoChar)
                    i += 2
                    consumed = true
                }
            }

            if (!consumed && katakana[i] == 'ッ') {
                val nextCharToDouble = nextKatakana?.getOrNull(0)
                if (nextCharToDouble != null) {
                    val nextCharRomaji = KANA_ROMAJI_MAP[nextCharToDouble.toString()]?.getOrNull(0)?.toString()
                        ?: nextCharToDouble.toString()
                    romajiBuilder.append(nextCharRomaji.lowercase().trim())
                }
                i += 1
                consumed = true
            }

            if (!consumed) {
                val oneCharCandidate = katakana[i].toString()
                val mappedOneChar = KANA_ROMAJI_MAP[oneCharCandidate]
                if (mappedOneChar != null) {
                    romajiBuilder.append(mappedOneChar)
                } else {
                    romajiBuilder.append(oneCharCandidate)
                }
                i += 1
            }
        }
        return romajiBuilder.toString().lowercase()
    }

    suspend fun romanizeKorean(text: String): String = withContext(Dispatchers.Default) {
        val romajaBuilder = StringBuilder()
        var prevFinal: String? = null

        for (i in text.indices) {
            val char = text[i]
            if (char in '\uAC00'..'\uD7A3') {
                val syllableIndex = char.code - 0xAC00
                val choIndex = syllableIndex / (21 * 28)
                val jungIndex = (syllableIndex % (21 * 28)) / 28
                val jongIndex = syllableIndex % 28

                val choChar = (0x1100 + choIndex).toChar().toString()
                val jungChar = (0x1161 + jungIndex).toChar().toString()
                val jongChar = if (jongIndex == 0) null else (0x11A7 + jongIndex).toChar().toString()

                if (prevFinal != null) {
                    val contextKey = prevFinal + choChar
                    val jong = HANGUL_ROMAJA_MAP["jong"]?.get(contextKey)
                        ?: HANGUL_ROMAJA_MAP["jong"]?.get(prevFinal)
                        ?: prevFinal
                    romajaBuilder.append(jong)
                }

                val cho = HANGUL_ROMAJA_MAP["cho"]?.get(choChar) ?: choChar
                val jung = HANGUL_ROMAJA_MAP["jung"]?.get(jungChar) ?: jungChar
                romajaBuilder.append(cho).append(jung)
                prevFinal = jongChar
            } else {
                if (prevFinal != null) {
                    val jong = HANGUL_ROMAJA_MAP["jong"]?.get(prevFinal) ?: prevFinal
                    romajaBuilder.append(jong)
                    prevFinal = null
                }
                romajaBuilder.append(char)
            }
        }

        if (prevFinal != null) {
            val jong = HANGUL_ROMAJA_MAP["jong"]?.get(prevFinal) ?: prevFinal
            romajaBuilder.append(jong)
        }

        romajaBuilder.toString()
    }

    suspend fun romanizeChinese(text: String): String = withContext(Dispatchers.Default) {
        if (text.isEmpty()) return@withContext ""
        val builder = StringBuilder(text.length * 2)
        for (ch in text) {
            if (ch in '\u4E00'..'\u9FFF') {
                val py = Pinyin.toPinyin(ch).lowercase(Locale.getDefault())
                builder.append(py).append(' ')
            } else {
                builder.append(ch)
            }
        }
        // Remove whitespaces before ASCII and CJK punctuations
        builder.toString()
            .replace(Regex("\\s+([,.!?;:])"), "$1")
            .replace(Regex("\\s+([，。！？；：、（）《》〈〉【】『』「」])"), "$1")
            .trim()
    }

    suspend fun romanizeCyrillic(text: String, language: String? = null): String? = withContext(Dispatchers.Default) {
        if (text.isEmpty()) return@withContext null

        val cyrillicChars = text.filter { it in '\u0400'..'\u04FF' }

        if (cyrillicChars.isEmpty() ||
            (cyrillicChars.length == 1 && (cyrillicChars[0] == 'е' || cyrillicChars[0] == 'Е'))) {
            return@withContext null
        }

        when (language) {
            "Russian" -> romanizeRussianInternal(text)
            "Ukrainian" -> romanizeUkrainianInternal(text)
            "Serbian" -> romanizeSerbianInternal(text)
            "Bulgarian" -> romanizeBulgarianInternal(text)
            "Belarusian" -> romanizeBelarusianInternal(text)
            "Kyrgyz" -> romanizeKyrgyzInternal(text)
            "Macedonian" -> romanizeMacedonianInternal(text)
            else -> when {
                isRussian(text) -> romanizeRussianInternal(text)
                isUkrainian(text) -> romanizeUkrainianInternal(text)
                isSerbian(text) -> romanizeSerbianInternal(text)
                isBulgarian(text) -> romanizeBulgarianInternal(text)
                isBelarusian(text) -> romanizeBelarusianInternal(text)
                isKyrgyz(text) -> romanizeKyrgyzInternal(text)
                isMacedonian(text) -> romanizeMacedonianInternal(text)
                else -> null
            }
        }
    }

    private fun romanizeRussianInternal(text: String): String {
        val romajiBuilder = StringBuilder(text.length)
        val words = text.split("((?<=\\s|[.,!?;])|(?=\\s|[.,!?;]))".toRegex())
            .filter { it.isNotEmpty() }

        words.forEachIndexed { _, word ->
            if (word.matches("[.,!?;]".toRegex()) || word.isBlank()) {
                romajiBuilder.append(word)
            } else {
                var charIndex = 0
                while (charIndex < word.length) {
                    var consumed = false
                    // Check for 3-character sequences
                    if (charIndex + 2 < word.length) {
                        val threeCharCandidate = word.substring(charIndex, charIndex + 3)
                        if (RUSSIAN_ROMAJI_MAP.containsKey(threeCharCandidate)) {
                            romajiBuilder.append(RUSSIAN_ROMAJI_MAP[threeCharCandidate])
                            charIndex += 3
                            consumed = true
                        }
                    }

                    if (!consumed) {
                        val charStr = word[charIndex].toString()
                        // Special case for 'е' or 'Е' at the start of a word
                        if ((charStr == "е" || charStr == "Е") && (charIndex == 0 || word[charIndex - 1].isWhitespace())) {
                            romajiBuilder.append(if (charStr == "е") "ye" else "Ye")
                        } else {
                            // Apply general Cyrillic mapping (Russian is no different so there's no need to apply a russian map)
                            val romanizedChar = GENERAL_CYRILLIC_ROMAJI_MAP[charStr] ?: charStr
                            romajiBuilder.append(romanizedChar)
                        }
                        charIndex += 1
                    }
                }
            }
        }
        return romajiBuilder.toString()
    }

    private fun romanizeUkrainianInternal(text: String): String {
        val romajiBuilder = StringBuilder(text.length)
        val words = text.split("((?<=\\s|[.,!?;])|(?=\\s|[.,!?;]))".toRegex())
            .filter { it.isNotEmpty() }

        words.forEachIndexed { _, word ->
            if (word.matches("[.,!?;]".toRegex()) || word.isBlank()) {
                romajiBuilder.append(word)
            } else {
                var charIndex = 0
                while (charIndex < word.length) {
                    val charStr = word[charIndex].toString()
                    var processed = false

                    if (charIndex > 0 && word[charIndex - 1].isLetter() && !isCyrillicVowel(word[charIndex - 1])) {
                        // Check if the current character is Ю or Я and is preceded by a consonant
                        if (charStr == "Ю") {
                            romajiBuilder.append("Iu")
                            processed = true
                        } else if (charStr == "ю") {
                            romajiBuilder.append("iu")
                            processed = true
                        } else if (charStr == "Я") {
                            romajiBuilder.append("Ia")
                            processed = true
                        } else if (charStr == "я") {
                            romajiBuilder.append("ia")
                            processed = true
                        }
                    }

                    if (!processed) {
                        romajiBuilder.append(UKRAINIAN_ROMAJI_MAP[charStr] ?: GENERAL_CYRILLIC_ROMAJI_MAP[charStr] ?: charStr)
                    }
                    charIndex++
                }
            }
        }
        return romajiBuilder.toString()
    }

    private fun romanizeSerbianInternal(text: String): String {
        val romajiBuilder = StringBuilder(text.length)
        val words = text.split("((?<=\\s|[.,!?;])|(?=\\s|[.,!?;]))".toRegex())
            .filter { it.isNotEmpty() }

        words.forEachIndexed { _, word ->
            if (word.matches("[.,!?;]".toRegex()) || word.isBlank()) {
                romajiBuilder.append(word)
            } else {
                var charIndex = 0
                while (charIndex < word.length) {
                    val charStr = word[charIndex].toString()
                    val romanizedChar = SERBIAN_ROMAJI_MAP[charStr] ?: GENERAL_CYRILLIC_ROMAJI_MAP[charStr] ?: charStr
                    romajiBuilder.append(romanizedChar)
                    charIndex++
                }
            }
        }
        return romajiBuilder.toString()
    }

    private fun romanizeBulgarianInternal(text: String): String {
        val romajiBuilder = StringBuilder(text.length)
        val words = text.split("((?<=\\s|[.,!?;])|(?=\\s|[.,!?;]))".toRegex())
            .filter { it.isNotEmpty() }

        words.forEachIndexed { _, word ->
            if (word.matches("[.,!?;]".toRegex()) || word.isBlank()) {
                romajiBuilder.append(word)
            } else {
                var charIndex = 0
                while (charIndex < word.length) {
                    val charStr = word[charIndex].toString()
                    val romanizedChar = BULGARIAN_ROMAJI_MAP[charStr] ?: GENERAL_CYRILLIC_ROMAJI_MAP[charStr] ?: charStr
                    romajiBuilder.append(romanizedChar)
                    charIndex++
                }
            }
        }
        return romajiBuilder.toString()
    }

    private fun romanizeBelarusianInternal(text: String): String {
        val romajiBuilder = StringBuilder(text.length)
        val words = text.split("((?<=\\s|[.,!?;])|(?=\\s|[.,!?;]))".toRegex())
            .filter { it.isNotEmpty() }

        words.forEach { word ->
            if (word.matches("[.,!?;]".toRegex()) || word.isBlank()) {
                romajiBuilder.append(word)
            } else {
                var charIndex = 0
                while (charIndex < word.length) {
                    val charStr = word[charIndex].toString()
                    // Special case for 'е' or 'Е' at the start of a word
                    if ((charStr == "е" || charStr == "Е") && (charIndex == 0 || word[charIndex - 1].isWhitespace())) {
                        romajiBuilder.append(if (charStr == "е") "ye" else "Ye")
                    } else {
                        // General mapping
                        val romanizedChar = BELARUSIAN_ROMAJI_MAP[charStr] ?: GENERAL_CYRILLIC_ROMAJI_MAP[charStr] ?: charStr
                        romajiBuilder.append(romanizedChar)
                    }
                    charIndex += 1
                }
            }
        }

        return romajiBuilder.toString()
    }

    private fun romanizeKyrgyzInternal(text: String): String {
        val romajiBuilder = StringBuilder(text.length)
        val words = text.split("((?<=\\s|[.,!?;])|(?=\\s|[.,!?;]))".toRegex())
            .filter { it.isNotEmpty() }

        words.forEachIndexed { _, word ->
            if (word.matches("[.,!?;]".toRegex()) || word.isBlank()) {
                romajiBuilder.append(word)
            } else {
                var charIndex = 0
                while (charIndex < word.length) {
                    val charStr = word[charIndex].toString()
                    val romanizedChar = KYRGYZ_ROMAJI_MAP[charStr] ?: GENERAL_CYRILLIC_ROMAJI_MAP[charStr] ?: charStr
                    romajiBuilder.append(romanizedChar)
                    charIndex++
                }
            }
        }
        return romajiBuilder.toString()
    }

    private fun romanizeMacedonianInternal(text: String): String {
        val romajiBuilder = StringBuilder(text.length)
        val words = text.split("((?<=\\s|[.,!?;])|(?=\\s|[.,!?;]))".toRegex())
            .filter { it.isNotEmpty() }

        words.forEachIndexed { _, word ->
            if (word.matches("[.,!?;]".toRegex()) || word.isBlank()) {
                romajiBuilder.append(word)
            } else {
                var charIndex = 0
                while (charIndex < word.length) {
                    val charStr = word[charIndex].toString()
                    val romanizedChar = MACEDONIAN_ROMAJI_MAP[charStr] ?: GENERAL_CYRILLIC_ROMAJI_MAP[charStr] ?: charStr
                    romajiBuilder.append(romanizedChar)
                    charIndex++
                }
            }
        }
        return romajiBuilder.toString()
    }

    // TODO: This function might be used later if we let the user choose the language manually
    /** private suspend fun romanizeCyrillicWithLanguage(text: String, language: CyrillicLanguage): String = withContext(Dispatchers.Default) {
        if (text.isEmpty()) return@withContext ""

        val detectedLanguage = language ?: when {
            isRussian(text) -> CyrillicLanguage.RUSSIAN
            isUkrainian(text) -> CyrillicLanguage.UKRAINIAN
            isSerbian(text) -> CyrillicLanguage.SERBIAN
            isBelarusian(text) -> CyrillicLanguage.BELARUSIAN
            isKyrgyz(text) -> CyrillicLanguage.KYRGYZ
            isMacedonian(text) -> CyrillicLanguage.MACEDONIAN
            else -> return@withContext text
        }

        val languageMap: Map<String, String> = when (detectedLanguage) {
            CyrillicLanguage.RUSSIAN -> RUSSIAN_ROMAJI_MAP
            CyrillicLanguage.UKRAINIAN -> UKRAINIAN_ROMAJI_MAP
            CyrillicLanguage.SERBIAN -> SERBIAN_ROMAJI_MAP
            CyrillicLanguage.BELARUSIAN -> BELARUSIAN_ROMAJI_MAP
            CyrillicLanguage.KYRGYZ -> KYRGYZ_ROMAJI_MAP
            CyrillicLanguage.MACEDONIAN -> MACEDONIAN_ROMAJI_MAP
            // else -> emptyMap()
        }
        val languageLetters = when (language) {
            CyrillicLanguage.RUSSIAN -> RUSSIAN_CYRILLIC_LETTERS
            CyrillicLanguage.UKRAINIAN -> UKRAINIAN_CYRILLIC_LETTERS
            CyrillicLanguage.SERBIAN -> SERBIAN_CYRILLIC_LETTERS
            CyrillicLanguage.BELARUSIAN -> BELARUSIAN_CYRILLIC_LETTERS
            CyrillicLanguage.KYRGYZ -> KYRGYZ_CYRILLIC_LETTERS
            CyrillicLanguage.MACEDONIAN -> MACEDONIAN_CYRILLIC_LETTERS
            else -> GENERAL_CYRILLIC_ROMAJI_MAP.keys
        }

        val romajiBuilder = StringBuilder(text.length)
        val words = text.split("((?<=\\s|[.,!?;])|(?=\\s|[.,!?;]))".toRegex())
            .filter { it.isNotEmpty() }

        words.forEachIndexed { _, word ->
            if (word.matches("[.,!?;]".toRegex()) || word.isBlank()) {
                // Preserve punctuation or spaces as is
                romajiBuilder.append(word)
            } else {
                // Process word
                var charIndex = 0
                while (charIndex < word.length) {
                    var consumed = false
                    // Check for 3-character sequences (language-specific, e.g., Russian)
                    if (detectedLanguage == CyrillicLanguage.RUSSIAN && charIndex + 2 < word.length) {
                        val threeCharCandidate = word.substring(charIndex, charIndex + 3)
                        if (languageLetters is Set<*> && languageLetters.containsAll(threeCharCandidate.toList().map { it.toString() })) {
                            val mappedThreeChar = languageMap[threeCharCandidate]
                            if (mappedThreeChar != null) {
                                romajiBuilder.append(mappedThreeChar)
                                charIndex += 3
                                consumed = true
                            }
                        }
                    }
                    if (!consumed) {
                        val charStr = word[charIndex].toString()
                        val isSpecificLanguageChar = languageLetters is Set<*> && languageLetters.contains(charStr)
                        val isGeneralCyrillicChar = GENERAL_CYRILLIC_ROMAJI_MAP.containsKey(charStr)

                        if (isSpecificLanguageChar || isGeneralCyrillicChar) {
                            if (detectedLanguage == CyrillicLanguage.RUSSIAN && (charStr == "е" || charStr == "Е") && charIndex == 0 && (charIndex == 0 || word[charIndex-1].isWhitespace())) {
                                romajiBuilder.append(if (charStr == "е") "ye" else "Ye")
                            } else {
                                val romanizedChar = languageMap[charStr] ?: GENERAL_CYRILLIC_ROMAJI_MAP[charStr]
                                if (romanizedChar != null) {
                                    romajiBuilder.append(romanizedChar)
                                } else {
                                    romajiBuilder.append(charStr)
                                }
                            }
                        } else {
                            romajiBuilder.append(charStr)
                        }
                        charIndex += 1
                    }
                }
            }
        }
        romajiBuilder.toString()
    } */

    fun isRussian(text: String): Boolean {
        return text.any { char ->
            RUSSIAN_CYRILLIC_LETTERS.contains(char.toString())
        } && text.all { char ->
            val charStr = char.toString()
            RUSSIAN_CYRILLIC_LETTERS.contains(charStr) || !charStr.matches("[\\u0400-\\u04FF]".toRegex())
        }
    }

    fun isUkrainian(text: String): Boolean {
        return text.any { char ->
            UKRAINIAN_CYRILLIC_LETTERS.contains(char.toString()) || UKRAINIAN_SPECIFIC_CYRILLIC_LETTERS.contains(char.toString())
        } && text.all { char ->
            UKRAINIAN_CYRILLIC_LETTERS.contains(char.toString()) || UKRAINIAN_SPECIFIC_CYRILLIC_LETTERS.contains(char.toString()) || !char.toString().matches("[\\u0400-\\u04FF]".toRegex())
        }
    }

    fun isSerbian(text: String): Boolean {
        return text.any { char ->
            SERBIAN_CYRILLIC_LETTERS.contains(char.toString()) || SERBIAN_SPECIFIC_CYRILLIC_LETTERS.contains(char.toString())
        } && text.all { char ->
            SERBIAN_CYRILLIC_LETTERS.contains(char.toString()) || SERBIAN_SPECIFIC_CYRILLIC_LETTERS.contains(char.toString()) || !char.toString().matches("[\\u0400-\\u04FF]".toRegex())
        }
    }

    fun isBulgarian(text: String): Boolean {
        return text.any { char ->
            BULGARIAN_CYRILLIC_LETTERS.contains(char.toString()) // Bulgarian doesn't have any language specific letters
        } && text.all { char ->
            BULGARIAN_CYRILLIC_LETTERS.contains(char.toString()) || !char.toString().matches("[\\u0400-\\u04FF]".toRegex())
        }
    }

    fun isBelarusian(text: String): Boolean {
        return text.any { char ->
            BELARUSIAN_CYRILLIC_LETTERS.contains(char.toString()) || BELARUSIAN_SPECIFIC_CYRILLIC_LETTERS.contains(char.toString())
        } && text.all { char ->
            BELARUSIAN_CYRILLIC_LETTERS.contains(char.toString()) || BELARUSIAN_SPECIFIC_CYRILLIC_LETTERS.contains(char.toString()) || !char.toString().matches("[\\u0400-\\u04FF]".toRegex())
        }
    }

    fun isKyrgyz(text: String): Boolean {
        return text.any { char ->
            KYRGYZ_CYRILLIC_LETTERS.contains(char.toString()) || KYRGYZ_SPECIFIC_CYRILLIC_LETTERS.contains(char.toString())
        } && text.all { char ->
            KYRGYZ_CYRILLIC_LETTERS.contains(char.toString()) || KYRGYZ_SPECIFIC_CYRILLIC_LETTERS.contains(char.toString()) || !char.toString().matches("[\\u0400-\\u04FF]".toRegex())
        }
    }

    fun isMacedonian(text: String): Boolean {
        return text.any { char ->
            MACEDONIAN_CYRILLIC_LETTERS.contains(char.toString()) || MACEDONIAN_SPECIFIC_CYRILLIC_LETTERS.contains(char.toString())
        } && text.all { char ->
            MACEDONIAN_CYRILLIC_LETTERS.contains(char.toString()) || MACEDONIAN_SPECIFIC_CYRILLIC_LETTERS.contains(char.toString()) || !char.toString().matches("[\\u0400-\\u04FF]".toRegex())
        }
    }

    fun isJapanese(text: String): Boolean {
        return text.any { char ->
            (char in '\u3040'..'\u309F') || // Hiragana
                    (char in '\u30A0'..'\u30FF') || // Katakana
                    (char in '\u4E00'..'\u9FFF') // CJK Unified Ideographs
        }
    }

    fun isKorean(text: String): Boolean {
        return text.any { char ->
            (char in '\uAC00'..'\uD7A3') // Hangul Syllables
        }
    }

    fun isChinese(text: String): Boolean {
        if (text.isEmpty()) return false
        val cjkCharCount = text.count { char -> char in '\u4E00'..'\u9FFF' }
        val hiraganaKatakanaCount = text.count { char -> (char in '\u3040'..'\u309F') || (char in '\u30A0'..'\u30FF') }
        return cjkCharCount > 0 && (hiraganaKatakanaCount.toDouble() / text.length.toDouble()) < 0.1
    }

    fun isHindi(text: String): Boolean {
        return text.any { char ->
            char in '\u0900'..'\u097F'
        }
    }

    suspend fun romanizeHindi(text: String): String = withContext(Dispatchers.Default) {
        val sb = StringBuilder(text.length)
        var i = 0
        while (i < text.length) {
            var consumed = false
            // Check for 2-character sequences (e.g. char + nukta)
            if (i + 1 < text.length) {
                val twoCharCandidate = text.substring(i, i + 2)
                val mappedTwoChar = DEVANAGARI_ROMAJI_MAP[twoCharCandidate]
                if (mappedTwoChar != null) {
                    sb.append(mappedTwoChar)
                    i += 2
                    consumed = true
                }
            }

            if (!consumed) {
                val charStr = text[i].toString()
                sb.append(DEVANAGARI_ROMAJI_MAP[charStr] ?: charStr)
                i += 1
            }
        }
        sb.toString()
    }

    fun isPunjabi(text: String): Boolean {
        return text.any { char ->
            char in '\u0A00'..'\u0A7F'
        }
    }

    suspend fun romanizePunjabi(text: String): String = withContext(Dispatchers.Default) {
        val sb = StringBuilder(text.length)
        var i = 0
        while (i < text.length) {
            val char = text[i]
            var consumed = false

            // Check for Adhak (Gemination)
            if (char == '\u0A71') {
                 // Double next consonant if possible
                 if (i + 1 < text.length) {
                     val nextCharStr = text[i+1].toString()
                     val nextMapped = GURMUKHI_ROMAJI_MAP[nextCharStr]
                     if (nextMapped != null && nextMapped.isNotEmpty()) {
                         sb.append(nextMapped[0])
                     }
                 }
                 i++
                 continue
            }

            // Check for 2-character sequences (e.g. char + nukta)
            if (i + 1 < text.length) {
                val twoCharCandidate = text.substring(i, i + 2)
                val mappedTwoChar = GURMUKHI_ROMAJI_MAP[twoCharCandidate]
                if (mappedTwoChar != null) {
                    sb.append(mappedTwoChar)
                    i += 2
                    consumed = true
                }
            }

            if (!consumed) {
                val str = char.toString()
                sb.append(GURMUKHI_ROMAJI_MAP[str] ?: str)
                i++
            }
        }
        sb.toString()
    }

    suspend fun romanize(
        text: String,
        line: String,
        enabledLanguages: List<String>,
        romanizeCyrillicByLine: Boolean
    ): String? {
        val detectionText = if (romanizeCyrillicByLine) line else text
        return when {
            "Japanese" in enabledLanguages && isJapanese(detectionText) && !isChinese(detectionText) -> romanizeJapanese(line)
            "Korean" in enabledLanguages && isKorean(detectionText) -> romanizeKorean(line)
            "Chinese" in enabledLanguages && isChinese(detectionText) -> romanizeChinese(line)
            "Hindi" in enabledLanguages && isHindi(detectionText) -> romanizeHindi(line)
            "Ukrainian" in enabledLanguages && isUkrainian(detectionText) -> romanizeCyrillic(line, "Ukrainian")
            "Russian" in enabledLanguages && isRussian(detectionText) -> romanizeCyrillic(line, "Russian")
            "Serbian" in enabledLanguages && isSerbian(detectionText) -> romanizeCyrillic(line, "Serbian")
            "Bulgarian" in enabledLanguages && isBulgarian(detectionText) -> romanizeCyrillic(line, "Bulgarian")
            "Belarusian" in enabledLanguages && isBelarusian(detectionText) -> romanizeCyrillic(line, "Belarusian")
            "Kyrgyz" in enabledLanguages && isKyrgyz(detectionText) -> romanizeCyrillic(line, "Kyrgyz")
            "Macedonian" in enabledLanguages && isMacedonian(detectionText) -> romanizeCyrillic(line, "Macedonian")
            else -> null
        }
    }

    private fun isCyrillicVowel(char: Char): Boolean {
        return "АаЕеЄєИиІіЇїОоУуЮюЯяЫыЭэ".contains(char)
    }

    fun isWordSynced(lyrics: String): Boolean {
        return (lyrics.contains("<") && lyrics.contains(">") && (lyrics.contains("|") || lyrics.contains(":"))) ||
                lyrics.contains(RICH_SYNC_WORD_REGEX)
    }

    fun isLineSynced(lyrics: String): Boolean {
        return lyrics.contains(TIME_REGEX) ||
                lyrics.contains(PAXSENIX_AGENT_LINE_REGEX) ||
                lyrics.contains(PAXSENIX_BG_LINE_REGEX)
    }

    fun getLyricsQuality(lyrics: String): Int {
        if (lyrics.isBlank() || lyrics == "Lyrics not found") return 0
        if (isWordSynced(lyrics)) return 3
        if (isLineSynced(lyrics)) return 2
        return 1
    }
}
