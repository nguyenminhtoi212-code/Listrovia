/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.component

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.listrovia.music.R
import com.listrovia.music.api.AgeCategory
import com.listrovia.music.api.AiAgeProtectionManager
import com.listrovia.music.api.AgeProtectionState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Locale

enum class VerificationTab {
    DOB_AGE,
    BIOMETRIC_FINGERPRINT,
    FACE_SCAN,
    ID_DOCUMENT
}

@Composable
fun AiAgeVerificationModal(
    currentState: AgeProtectionState,
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val isVietnamese = remember { Locale.getDefault().language == "vi" }

    var selectedTab by remember { mutableStateOf(VerificationTab.DOB_AGE) }

    // DOB state
    var birthYear by remember { mutableStateOf("2010") }
    var birthMonth by remember { mutableStateOf("5") }
    var birthDay by remember { mutableStateOf("15") }

    // Face / ID scanning animation simulation state
    var isScanningFace by remember { mutableStateOf(false) }
    var isFaceDone by remember { mutableStateOf(currentState.faceVerified) }

    var isScanningId by remember { mutableStateOf(false) }
    var isIdDone by remember { mutableStateOf(currentState.idDocumentVerified) }

    var isScanningBiometric by remember { mutableStateOf(false) }
    var isBiometricDone by remember { mutableStateOf(currentState.biometricVerified) }

    // Parental PIN
    var pinInput by remember { mutableStateOf("") }
    var pinMessage by remember { mutableStateOf("") }

    val infiniteTransition = rememberInfiniteTransition(label = "scanner")
    val scanY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scanY"
    )

    Dialog(onDismissRequest = onDismissRequest) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (isVietnamese) "Xác Thực Tuổi & Vân Tay / Khuôn Mặt" else "Age & Identity Verification",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isVietnamese) "Giới hạn bảo vệ trẻ em & thiếu niên" else "Child & Teen Protection Gating",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismissRequest) {
                        Icon(painter = painterResource(R.drawable.close), contentDescription = "Close")
                    }
                }

                // Current Age Category Banner
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (currentState.isMinor) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.primaryContainer
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = if (isVietnamese) "NHÓM ĐỘ TUỔI TÀI KHOẢN" else "ACCOUNT AGE GROUP",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = if (isVietnamese) currentState.ageCategory.labelVi else currentState.ageCategory.labelEn,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }

                        Surface(
                            shape = CircleShape,
                            color = if (currentState.isMinor) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                        ) {
                            Text(
                                text = if (currentState.isMinor) (if (isVietnamese) "ĐANG BẢO VỆ" else "PROTECTED") else (if (isVietnamese) "NGƯỜI LỚN 18+" else "ADULT 18+"),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                // Navigation Tabs between DOB, Biometric, Face Scan, ID Document
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    VerificationTab.entries.forEach { tab ->
                        val isSel = selectedTab == tab
                        val tabTitle = when (tab) {
                            VerificationTab.DOB_AGE -> if (isVietnamese) "Ngày Sinh" else "DOB"
                            VerificationTab.BIOMETRIC_FINGERPRINT -> if (isVietnamese) "Vân Tay" else "Biometrics"
                            VerificationTab.FACE_SCAN -> if (isVietnamese) "Khuôn Mặt" else "Face Scan"
                            VerificationTab.ID_DOCUMENT -> if (isVietnamese) "CCCD/ID" else "ID Scan"
                        }
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedTab = tab }
                        ) {
                            Text(
                                text = tabTitle,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        }
                    }
                }

                HorizontalDivider()

                when (selectedTab) {
                    VerificationTab.DOB_AGE -> {
                        // Date of Birth Section
                        Text(
                            text = if (isVietnamese) "Thiết Lập Ngày Tháng Năm Sinh:" else "Set Date of Birth:",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = birthDay,
                                onValueChange = { birthDay = it },
                                label = { Text(if (isVietnamese) "Ngày" else "Day") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = birthMonth,
                                onValueChange = { birthMonth = it },
                                label = { Text(if (isVietnamese) "Tháng" else "Month") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = birthYear,
                                onValueChange = { birthYear = it },
                                label = { Text(if (isVietnamese) "Năm" else "Year") },
                                singleLine = true,
                                modifier = Modifier.weight(1.2f)
                            )
                        }

                        Button(
                            onClick = {
                                val y = birthYear.toIntOrNull() ?: 2010
                                val m = (birthMonth.toIntOrNull() ?: 5) - 1
                                val d = birthDay.toIntOrNull() ?: 15
                                scope.launch {
                                    AiAgeProtectionManager.setUserBirthDate(context, y, m, d)
                                    onDismissRequest()
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = if (isVietnamese) "Lưu Ngày Sinh & Xác Nhận Độ Tuổi" else "Save DOB & Update Age Category")
                        }
                    }

                    VerificationTab.BIOMETRIC_FINGERPRINT -> {
                        // Biometric / Fingerprint Prompt
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.security),
                                contentDescription = null,
                                tint = if (isBiometricDone) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(64.dp)
                            )
                            Text(
                                text = if (isBiometricDone)
                                    (if (isVietnamese) "Vân Tay Đã Được Xác Thực" else "Biometrics Verified")
                                else
                                    (if (isVietnamese) "Chạm Vào Cảm Biến Vân Tay Để Xác Thực" else "Touch Biometric Sensor to Verify"),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )

                            Button(
                                onClick = {
                                    isScanningBiometric = true
                                    scope.launch {
                                        delay(1000L) // Simulate Android BiometricPrompt match
                                        AiAgeProtectionManager.updateBiometricVerification(context, true)
                                        isScanningBiometric = false
                                        isBiometricDone = true
                                    }
                                },
                                enabled = !isScanningBiometric,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                if (isScanningBiometric) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                } else {
                                    Text(text = if (isVietnamese) "Quét Vân Tay / Biometrics" else "Scan Fingerprint")
                                }
                            }
                        }
                    }

                    VerificationTab.FACE_SCAN -> {
                        // Face Scan Viewport Simulation
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(160.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                                    .border(
                                        width = 3.dp,
                                        color = if (isFaceDone) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                        shape = CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isScanningFace) {
                                    CircularProgressIndicator(modifier = Modifier.size(120.dp), strokeWidth = 3.dp)
                                } else {
                                    Icon(
                                        painter = painterResource(R.drawable.artist),
                                        contentDescription = null,
                                        modifier = Modifier.size(80.dp),
                                        tint = if (isFaceDone) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Text(
                                text = if (isFaceDone)
                                    (if (isVietnamese) "Xác Thực Khuôn Mặt Thành Công" else "Face Identity Verified")
                                else
                                    (if (isVietnamese) "Giữ Khuôn Mặt Trong Khung Hình Bán Kính" else "Align Face Inside Oval Viewport"),
                                style = MaterialTheme.typography.bodyMedium,
                                textAlign = TextAlign.Center
                            )

                            Button(
                                onClick = {
                                    isScanningFace = true
                                    scope.launch {
                                        delay(1500L) // Simulate Face Recognition
                                        AiAgeProtectionManager.updateFaceVerification(context, true)
                                        isScanningFace = false
                                        isFaceDone = true
                                    }
                                },
                                enabled = !isScanningFace,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                if (isScanningFace) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                } else {
                                    Text(text = if (isVietnamese) "Bắt Đầu Xác Thực Khuôn Mặt" else "Start Face Verification")
                                }
                            }
                        }
                    }

                    VerificationTab.ID_DOCUMENT -> {
                        // ID Document Scan Simulation
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(110.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                                    .border(
                                        width = 2.dp,
                                        color = if (isIdDone) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                        shape = RoundedCornerShape(16.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        painter = painterResource(R.drawable.security),
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = if (isIdDone)
                                            (if (isVietnamese) "Giấy Tờ Hợp Lệ (CCCD/Passport)" else "ID Document Verified")
                                        else
                                            (if (isVietnamese) "Chụp Mặt Trước CCCD / Giấy Tờ Tùy Thân" else "Scan Front ID Document / Passport"),
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }

                            Button(
                                onClick = {
                                    isScanningId = true
                                    scope.launch {
                                        delay(1500L)
                                        AiAgeProtectionManager.updateIdDocumentVerification(context, true)
                                        isScanningId = false
                                        isIdDone = true
                                    }
                                },
                                enabled = !isScanningId,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                if (isScanningId) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                } else {
                                    Text(text = if (isVietnamese) "Quét CCCD / Giấy Tờ" else "Scan ID Document")
                                }
                            }
                        }
                    }
                }

                // Parental PIN Setup
                HorizontalDivider()
                Text(
                    text = if (isVietnamese) "Mã PIN Phụ Huynh / Khóa Trẻ Em:" else "Parental Control PIN:",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { if (it.length <= 6) pinInput = it },
                        label = { Text(if (isVietnamese) "Mã PIN 4-6 số" else "4-6 Digit PIN") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    Button(
                        onClick = {
                            if (pinInput.length >= 4) {
                                scope.launch {
                                    AiAgeProtectionManager.setParentalPin(context, pinInput)
                                    pinMessage = if (isVietnamese) "Đã lưu PIN thành công!" else "PIN saved!"
                                }
                            }
                        },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(if (isVietnamese) "Lưu PIN" else "Set PIN")
                    }
                }

                if (pinMessage.isNotBlank()) {
                    Text(
                        text = pinMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                TextButton(
                    onClick = onDismissRequest,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text(text = if (isVietnamese) "Đóng" else "Close")
                }
            }
        }
    }
}
