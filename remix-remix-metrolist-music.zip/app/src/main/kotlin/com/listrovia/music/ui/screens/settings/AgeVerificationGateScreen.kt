/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.screens.settings

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.compose.AsyncImage
import com.listrovia.music.api.AgeCategory
import com.listrovia.music.api.AiAgeProtectionManager
import com.listrovia.music.security.BiometricAuthManager
import com.listrovia.music.security.BiometricStatus
import kotlinx.coroutines.launch
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgeVerificationGateScreen(
    onNavigateBack: () -> Unit,
    onVerificationComplete: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? FragmentActivity
    val scope = rememberCoroutineScope()

    val ageProtectionState by AiAgeProtectionManager.getAgeProtectionState(context)
        .collectAsStateWithLifecycle(initialValue = com.listrovia.music.api.AgeProtectionState())

    // DOB selection states
    val currentYear = Calendar.getInstance().get(Calendar.YEAR)
    var selectedYear by remember { mutableIntStateOf(2005) }
    var selectedMonth by remember { mutableIntStateOf(0) } // 0-based
    var selectedDay by remember { mutableIntStateOf(15) }

    LaunchedEffect(ageProtectionState.birthMillis) {
        if (ageProtectionState.birthMillis > 0L) {
            val cal = Calendar.getInstance().apply { timeInMillis = ageProtectionState.birthMillis }
            selectedYear = cal.get(Calendar.YEAR)
            selectedMonth = cal.get(Calendar.MONTH)
            selectedDay = cal.get(Calendar.DAY_OF_MONTH)
        }
    }

    // Biometric & ID verification states
    var biometricStatusMessage by remember { mutableStateOf("") }
    var idDocumentUri by remember { mutableStateOf<Uri?>(null) }
    var showPinDialog by remember { mutableStateOf(false) }
    var pinInput by remember { mutableStateOf("") }

    // Test moderation prompt
    var testPromptInput by remember { mutableStateOf("") }
    var moderationResult by remember { mutableStateOf<com.listrovia.music.api.ModerationCheckResult?>(null) }

    // Visual media picker for zero-permission document verification
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            idDocumentUri = uri
            scope.launch {
                AiAgeProtectionManager.updateIdDocumentVerification(context, true)
                Toast.makeText(context, "Giấy tờ tùy thân đã được ghi nhận", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Bảo vệ trẻ em & Xác thực độ tuổi",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Youth Protection & Age Gate",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("age_gate_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Quay lại"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(modifier = Modifier.height(8.dp)) }

            // 1. AGE CATEGORY HEADER CARD
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = when (ageProtectionState.ageCategory) {
                            AgeCategory.CHILD -> MaterialTheme.colorScheme.errorContainer
                            AgeCategory.TEEN -> MaterialTheme.colorScheme.tertiaryContainer
                            AgeCategory.ADULT -> MaterialTheme.colorScheme.primaryContainer
                        }
                    ),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f),
                                    modifier = Modifier.size(44.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = when (ageProtectionState.ageCategory) {
                                                AgeCategory.CHILD -> Icons.Default.ChildCare
                                                AgeCategory.TEEN -> Icons.Default.Person
                                                AgeCategory.ADULT -> Icons.Default.Shield
                                            },
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = ageProtectionState.ageCategory.labelVi,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = ageProtectionState.ageCategory.labelEn,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface
                            ) {
                                Text(
                                    text = "${ageProtectionState.calculatedAge} tuổi",
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = if (ageProtectionState.isMinor)
                                "Chế độ an toàn cho Trẻ em & Thiếu niên đang được kích hoạt tự động. Mọi nội dung AI sẽ được lọc nghiêm ngặt."
                            else
                                "Xác nhận độ tuổi người lớn (18+) cho phép mở khóa toàn bộ tính năng Mô hình AI & Bài hát AI nâng cao.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            // 2. DATE OF BIRTH PICKER CARD
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "1. Nhập Ngày Sinh (Date of Birth)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Hệ thống xác định mức độ bảo vệ dựa trên ngày sinh của bạn.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Day Dropdown
                            var dayExpanded by remember { mutableStateOf(false) }
                            Box(modifier = Modifier.weight(1f)) {
                                OutlinedButton(
                                    onClick = { dayExpanded = true },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Ngày: $selectedDay")
                                }
                                DropdownMenu(
                                    expanded = dayExpanded,
                                    onDismissRequest = { dayExpanded = false }
                                ) {
                                    (1..31).forEach { day ->
                                        DropdownMenuItem(
                                            text = { Text("Ngày $day") },
                                            onClick = {
                                                selectedDay = day
                                                dayExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            // Month Dropdown
                            var monthExpanded by remember { mutableStateOf(false) }
                            Box(modifier = Modifier.weight(1f)) {
                                OutlinedButton(
                                    onClick = { monthExpanded = true },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Tháng: ${selectedMonth + 1}")
                                }
                                DropdownMenu(
                                    expanded = monthExpanded,
                                    onDismissRequest = { monthExpanded = false }
                                ) {
                                    (0..11).forEach { m ->
                                        DropdownMenuItem(
                                            text = { Text("Tháng ${m + 1}") },
                                            onClick = {
                                                selectedMonth = m
                                                monthExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            // Year Dropdown
                            var yearExpanded by remember { mutableStateOf(false) }
                            Box(modifier = Modifier.weight(1.2f)) {
                                OutlinedButton(
                                    onClick = { yearExpanded = true },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Năm: $selectedYear")
                                }
                                DropdownMenu(
                                    expanded = yearExpanded,
                                    onDismissRequest = { yearExpanded = false }
                                ) {
                                    (currentYear downTo 1930).forEach { yr ->
                                        DropdownMenuItem(
                                            text = { Text("$yr") },
                                            onClick = {
                                                selectedYear = yr
                                                yearExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                scope.launch {
                                    AiAgeProtectionManager.setUserBirthDate(context, selectedYear, selectedMonth, selectedDay)
                                    Toast.makeText(
                                        context,
                                        "Đã cập nhật ngày sinh!",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("save_dob_button")
                        ) {
                            Icon(imageVector = Icons.Default.Check, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Cập Nhật Ngày Sinh & Phân Loại")
                        }
                    }
                }
            }

            // 3. BIOMETRIC AUTHENTICATION CARD
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "2. Xác Thực Sinh Trắc Học (Vân Tay / Face ID)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (ageProtectionState.biometricVerified) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = CircleShape
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp),
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Đã Xác Thực",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Sử dụng BiometricPrompt API để bảo vệ quyền truy cập các cài đặt AI nhạy cảm và xác nhận độ tuổi chính chủ.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                if (activity != null) {
                                    val status = BiometricAuthManager.checkBiometricAvailability(context)
                                    if (status.isAvailable) {
                                        BiometricAuthManager.showBiometricPrompt(
                                            activity = activity,
                                            title = "Xác Thực Vân Tay / Face ID",
                                            subtitle = "Xác nhận danh tính người dùng ứng dụng AI",
                                            description = "Chạm vào cảm biến vân tay hoặc quét khuôn mặt để tiếp tục.",
                                            onSuccess = {
                                                scope.launch {
                                                    AiAgeProtectionManager.updateBiometricVerification(context, true)
                                                    biometricStatusMessage = "Xác thực vân tay/khuôn mặt thành công!"
                                                    Toast.makeText(context, biometricStatusMessage, Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            onError = { _, errString ->
                                                biometricStatusMessage = "Lỗi xác thực: $errString"
                                            }
                                        )
                                    } else {
                                        biometricStatusMessage = status.messageVi
                                        Toast.makeText(context, status.messageVi, Toast.LENGTH_LONG).show()
                                    }
                                } else {
                                    Toast.makeText(context, "Không thể lấy FragmentActivity", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("biometric_auth_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (ageProtectionState.biometricVerified)
                                    MaterialTheme.colorScheme.secondary
                                else
                                    MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Icon(imageVector = Icons.Default.Fingerprint, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                if (ageProtectionState.biometricVerified) "Xác Thực Biometric Lại" else "Xác Thực Cảm Biến Vân Tay / Face ID"
                            )
                        }

                        if (biometricStatusMessage.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = biometricStatusMessage,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }
            }

            // 4. IDENTITY DOCUMENT UPLOAD CARD (CCCD / ID PHOTO PICKER)
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "3. Tải Giấy Tờ Tùy Thân (CCCD / Hộ Chiếu)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            if (ageProtectionState.idDocumentVerified) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Sử dụng Android Photo Picker an toàn (Zero-Permission) để tải ảnh CCCD/Thẻ học sinh phục vụ kiểm duyệt độ tuổi.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        if (idDocumentUri != null) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(160.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
                            ) {
                                AsyncImage(
                                    model = idDocumentUri,
                                    contentDescription = "Ảnh giấy tờ tùy thân",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                        }

                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("pick_id_photo_button")
                        ) {
                            Icon(imageVector = Icons.Default.PhotoCamera, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (idDocumentUri == null) "Chọn Ảnh CCCD / Giấy Tờ" else "Thay Đổi Ảnh Giấy Tờ")
                        }
                    }
                }
            }

            // 5. PARENTAL PIN & CHILD CONTROL CARD
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "4. Mã PIN Giám Sát Của Phụ Huynh",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Đặt mã PIN bảo vệ để chỉ phụ huynh mới có thể thay đổi cấu hình kiểm duyệt cho thiếu niên.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text(
                                    text = if (ageProtectionState.hasParentalPin) "Đã Đặt Mã PIN Phụ Huynh" else "Chưa Cài Mã PIN",
                                    fontWeight = FontWeight.SemiBold,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    text = if (ageProtectionState.hasParentalPin) "Trẻ em không thể tự gỡ bỏ kiểm duyệt" else "Nhấn để tạo mã PIN 4 chữ số",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            OutlinedButton(
                                onClick = { showPinDialog = true },
                                modifier = Modifier.testTag("set_parental_pin_button")
                            ) {
                                Icon(imageVector = Icons.Default.Lock, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (ageProtectionState.hasParentalPin) "Đổi PIN" else "Tạo PIN")
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Bật Chế Độ Giới Hạn Trẻ Em",
                                    fontWeight = FontWeight.SemiBold,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    text = "Khóa các tính năng AI âm nhạc nâng cao đối với tài khoản trẻ em",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Switch(
                                checked = ageProtectionState.childProtectionEnabled,
                                onCheckedChange = { checked ->
                                    scope.launch {
                                        AiAgeProtectionManager.setChildProtectionEnabled(context, checked)
                                    }
                                },
                                modifier = Modifier.testTag("child_protection_switch")
                            )
                        }
                    }
                }
            }

            // 6. CONTENT SAFETY MODERATION TEST CARD
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "5. Thử Nghiệm Bộ Lọc Kiểm Duyệt AI",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Nhập văn bản bài hát hoặc prompt AI để kiểm tra tính năng ngăn chặn từ ngữ cấm theo chính sách bảo vệ thanh thiếu niên.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = testPromptInput,
                            onValueChange = { testPromptInput = it },
                            label = { Text("Nhập câu lệnh AI hoặc lời bài hát mẫu") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = {
                                moderationResult = AiAgeProtectionManager.checkContentModeration(testPromptInput, ageProtectionState)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("test_moderation_button")
                        ) {
                            Icon(imageVector = Icons.Default.Shield, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Kiểm Duyệt Thử")
                        }

                        moderationResult?.let { res ->
                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                color = if (res.isAllowed) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(12.dp)
                                ) {
                                    Icon(
                                        imageVector = if (res.isAllowed) Icons.Default.CheckCircle else Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = if (res.isAllowed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = res.reasonVi,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 7. COMPLETE VERIFICATION ACTION BUTTON
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = {
                        Toast.makeText(context, "Đã lưu cài đặt xác thực độ tuổi!", Toast.LENGTH_SHORT).show()
                        onVerificationComplete()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("complete_age_verification_button"),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = "Hoàn Tất Xác Thực & Quay Lại",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // PIN SETTING DIALOG
    if (showPinDialog) {
        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            title = { Text("Cài Đặt Mã PIN Phụ Huynh") },
            text = {
                Column {
                    Text(text = "Nhập 4 chữ số để tạo hoặc thay đổi mã PIN bảo vệ cài đặt trẻ em:")
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { if (it.length <= 4 && it.all { char -> char.isDigit() }) pinInput = it },
                        label = { Text("Mã PIN (4 chữ số)") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (pinInput.length == 4) {
                            scope.launch {
                                AiAgeProtectionManager.setParentalPin(context, pinInput)
                                showPinDialog = false
                                pinInput = ""
                                Toast.makeText(context, "Mã PIN đã được lưu!", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            Toast.makeText(context, "PIN phải có đúng 4 chữ số", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("Lưu PIN")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPinDialog = false }) {
                    Text("Hủy")
                }
            }
        )
    }
}
