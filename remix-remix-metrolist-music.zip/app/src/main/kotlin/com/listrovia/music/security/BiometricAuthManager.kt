/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.security

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

enum class BiometricStatus(val isAvailable: Boolean, val messageEn: String, val messageVi: String) {
    AVAILABLE(true, "Biometric authentication available", "Xác thực sinh trắc học có sẵn"),
    NO_HARDWARE(false, "No biometric hardware found", "Thiết bị không hỗ trợ sinh trắc học"),
    HW_UNAVAILABLE(false, "Biometric hardware currently unavailable", "Cảm biến sinh trắc học hiện không khả dụng"),
    NONE_ENROLLED(false, "No fingerprints or face data registered", "Chưa đăng ký vân tay hoặc khuôn mặt"),
    SECURITY_UPDATE_REQUIRED(false, "Security update required", "Cần cập nhật bảo mật hệ thống"),
    UNKNOWN(false, "Unknown biometric state", "Trạng thái sinh trắc học không xác định")
}

object BiometricAuthManager {

    fun checkBiometricAvailability(context: Context): BiometricStatus {
        val biometricManager = BiometricManager.from(context)
        return when (biometricManager.canAuthenticate(BIOMETRIC_STRONG or DEVICE_CREDENTIAL)) {
            BiometricManager.BIOMETRIC_SUCCESS -> BiometricStatus.AVAILABLE
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> BiometricStatus.NO_HARDWARE
            BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> BiometricStatus.HW_UNAVAILABLE
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> BiometricStatus.NONE_ENROLLED
            BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED -> BiometricStatus.SECURITY_UPDATE_REQUIRED
            else -> BiometricStatus.UNKNOWN
        }
    }

    fun showBiometricPrompt(
        activity: FragmentActivity,
        title: String,
        subtitle: String = "",
        description: String = "",
        negativeButtonText: String? = null,
        onSuccess: () -> Unit,
        onError: (errorCode: Int, errString: CharSequence) -> Unit,
        onFailed: (() -> Unit)? = null
    ) {
        val executor = ContextCompat.getMainExecutor(activity)

        val callback = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                onSuccess()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                onError(errorCode, errString)
            }

            override fun onAuthenticationFailed() {
                super.onAuthenticationFailed()
                onFailed?.invoke()
            }
        }

        val biometricPrompt = BiometricPrompt(activity, executor, callback)

        val promptInfoBuilder = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setDescription(description)

        val negText = negativeButtonText
        if (!negText.isNullOrEmpty()) {
            promptInfoBuilder.setNegativeButtonText(negText)
            promptInfoBuilder.setAllowedAuthenticators(BIOMETRIC_STRONG)
        } else {
            promptInfoBuilder.setAllowedAuthenticators(BIOMETRIC_STRONG or DEVICE_CREDENTIAL)
        }

        biometricPrompt.authenticate(promptInfoBuilder.build())
    }
}

private fun String?.isNull_or_empty(): Boolean = this.isNullOrEmpty()
