/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.viewmodels

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.listrovia.music.api.ApiKeyClassification
import com.listrovia.music.api.ApiKeyManager
import com.listrovia.music.api.ApiKeyValidationResult
import com.listrovia.music.api.ClassifiedModels
import com.listrovia.music.api.DeepInfraClassifiedModels
import com.listrovia.music.api.DeepInfraModelItem
import com.listrovia.music.api.DeepInfraModelManager
import com.listrovia.music.api.OpenRouterModelItem
import com.listrovia.music.api.OpenRouterModelManager
import com.listrovia.music.api.OpenRouterService
import com.listrovia.music.api.*
import com.listrovia.music.api.NormalizedResponseSchema
import com.listrovia.music.api.SimpleApiKeyManager
import com.listrovia.music.constants.AiProviderKey
import com.listrovia.music.constants.OpenRouterApiKey
import com.listrovia.music.constants.OpenRouterApiKeyDetailsKey
import com.listrovia.music.constants.OpenRouterApiKeyStatusKey
import com.listrovia.music.constants.OpenRouterBaseUrlKey
import com.listrovia.music.constants.OpenRouterDefaultModel
import com.listrovia.music.constants.OpenRouterModelKey
import com.listrovia.music.constants.OpenRouterModelTierKey
import com.listrovia.music.constants.OpenRouterTierBeta
import com.listrovia.music.constants.OpenRouterTierDeveloper
import com.listrovia.music.constants.OpenRouterTierStable
import com.listrovia.music.security.SecureKeyStorage
import com.listrovia.music.utils.ModelFavoritesManager
import com.listrovia.music.utils.dataStore
import com.listrovia.music.utils.safeDataStoreEdit
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

/**
 * ViewModel managing the state of OpenRouter model selection across tiers
 * (Stable, Beta, Developer), fetching models from OpenRouter API, and persisting
 * user selections safely to DataStore.
 */
@HiltViewModel
class ModelViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
) : ViewModel() {

    private val modelManager = OpenRouterModelManager.getInstance(context)
    private val deepInfraModelManager = DeepInfraModelManager.getInstance(context)
    private val aionLabsModelManager = AionLabsModelManager.getInstance(context)
    private val huggingFaceModelManager = HuggingFaceModelManager.getInstance(context)

    // DataStore-persisted selected tier (Stable, Beta, Developer)
    val selectedTier: StateFlow<String> = context.dataStore.data
        .map { it[OpenRouterModelTierKey] ?: OpenRouterTierStable }
        .distinctUntilChanged()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = OpenRouterTierStable,
        )

    // DataStore-persisted selected model ID
    val selectedModel: StateFlow<String> = context.dataStore.data
        .map { it[OpenRouterModelKey] ?: OpenRouterDefaultModel }
        .distinctUntilChanged()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = OpenRouterDefaultModel,
        )

    private val _classifiedModels = MutableStateFlow<ClassifiedModels?>(null)
    val classifiedModels: StateFlow<ClassifiedModels?> = _classifiedModels.asStateFlow()

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _deepInfraModels = MutableStateFlow<DeepInfraClassifiedModels?>(null)
    val deepInfraModels: StateFlow<DeepInfraClassifiedModels?> = _deepInfraModels.asStateFlow()

    private val _isDeepInfraLoading = MutableStateFlow(false)
    val isDeepInfraLoading: StateFlow<Boolean> = _isDeepInfraLoading.asStateFlow()

    private val _aionLabsModels = MutableStateFlow<AionLabsClassifiedModels?>(null)
    val aionLabsModels: StateFlow<AionLabsClassifiedModels?> = _aionLabsModels.asStateFlow()

    private val _isAionLabsLoading = MutableStateFlow(false)
    val isAionLabsLoading: StateFlow<Boolean> = _isAionLabsLoading.asStateFlow()

    private val _huggingFaceModels = MutableStateFlow<HuggingFaceClassifiedModels?>(null)
    val huggingFaceModels: StateFlow<HuggingFaceClassifiedModels?> = _huggingFaceModels.asStateFlow()

    private val _isHuggingFaceLoading = MutableStateFlow(false)
    val isHuggingFaceLoading: StateFlow<Boolean> = _isHuggingFaceLoading.asStateFlow()

    fun loadDeepInfraModels(forceRefresh: Boolean = false) {
        viewModelScope.launch {
            _isDeepInfraLoading.value = true
            try {
                _deepInfraModels.value = deepInfraModelManager.fetchModels(forceRefresh = forceRefresh)
            } finally {
                _isDeepInfraLoading.value = false
            }
        }
    }

    fun loadAionLabsModels(forceRefresh: Boolean = false, apiKey: String = "") {
        viewModelScope.launch {
            _isAionLabsLoading.value = true
            try {
                _aionLabsModels.value = aionLabsModelManager.fetchModels(forceRefresh = forceRefresh, apiKey = apiKey)
            } finally {
                _isAionLabsLoading.value = false
            }
        }
    }

    fun loadHuggingFaceModels(forceRefresh: Boolean = false, apiKey: String = "") {
        viewModelScope.launch {
            _isHuggingFaceLoading.value = true
            try {
                _huggingFaceModels.value = huggingFaceModelManager.fetchModels(forceRefresh = forceRefresh, apiKey = apiKey)
            } finally {
                _isHuggingFaceLoading.value = false
            }
        }
    }

    // Dynamically filtered models matching the currently selected tier
    val currentTierModels: StateFlow<List<OpenRouterModelItem>> =
        combine(_classifiedModels, selectedTier) { models, tier ->
            if (models == null) emptyList()
            else when (tier) {
                OpenRouterTierBeta -> models.beta
                OpenRouterTierDeveloper -> models.developer
                else -> models.official
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = emptyList(),
        )

    init {
        SimpleApiKeyManager.init(context)
        loadModels(forceRefresh = false)
        loadHuggingFaceModels(forceRefresh = false)
    }

    /**
     * Loads and classifies OpenRouter models.
     * Uses in-memory / disk cache unless forceRefresh is true.
     */
    fun loadModels(forceRefresh: Boolean = false) {
        _isLoading.value = true
        viewModelScope.launch {
            try {
                val data = modelManager.fetchAndClassifyModels(forceRefresh = forceRefresh)
                _classifiedModels.value = data
            } catch (e: Exception) {
                Timber.e(e, "ModelViewModel failed to fetch models")
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun refresh(force: Boolean = true) {
        loadModels(forceRefresh = force)
    }

    /**
     * Selects a model tier ('Stable', 'Beta', 'Developer') and persists it to DataStore.
     * If the currently selected model is not present in the new tier, automatically picks
     * the top recommended model of the chosen tier.
     */
    fun selectTier(tier: String) {
        viewModelScope.launch {
            context.safeDataStoreEdit { prefs ->
                prefs[OpenRouterModelTierKey] = tier
            }

            val models = _classifiedModels.value
            val tierModels = when (tier) {
                OpenRouterTierBeta -> models?.beta
                OpenRouterTierDeveloper -> models?.developer
                else -> models?.official
            } ?: emptyList()

            val currentModel = selectedModel.value
            if (tierModels.isNotEmpty() && tierModels.none { it.id == currentModel }) {
                val topModel = tierModels.first().id
                context.safeDataStoreEdit { prefs ->
                    prefs[OpenRouterModelKey] = topModel
                }
            }
        }
    }

    /**
     * Selects an individual OpenRouter model ID and persists it to DataStore.
     */
    fun selectModel(modelId: String) {
        if (modelId.isBlank()) return
        viewModelScope.launch {
            ModelFavoritesManager.getInstance(context).recordModelUsage(modelId)
            context.safeDataStoreEdit { prefs ->
                prefs[OpenRouterModelKey] = modelId
            }
        }
    }

    // Trạng thái đã lưu của API Key ("valid_active", "expired", "renewed_extended", "lifetime_free", "invalid_spoofed")
    val apiKeyStatus: StateFlow<String> = context.dataStore.data
        .map { it[OpenRouterApiKeyStatusKey] ?: "" }
        .distinctUntilChanged()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = "",
        )

    val keyClassification: StateFlow<ApiKeyClassification> = apiKeyStatus
        .map { ApiKeyClassification.fromStorageKey(it) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = ApiKeyClassification.IDLE,
        )

    val isFeatureAccessGranted: StateFlow<Boolean> = combine(
        context.dataStore.data.map { it[AiProviderKey] ?: "OpenRouter" },
        apiKeyStatus,
    ) { provider, status ->
        if (provider == "DeepInfra") true else ApiKeyManager.isFeatureAccessGranted(status, provider)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = true,
    )

    private val _apiKeyValidation = MutableStateFlow<ApiKeyValidationResult>(ApiKeyValidationResult.Idle)
    val apiKeyValidation: StateFlow<ApiKeyValidationResult> = _apiKeyValidation.asStateFlow()

    /**
     * Xác thực API key tuân thủ 5 nguyên tắc phân loại nghiêm ngặt:
     * 1. Valid Active: Định dạng chuẩn, hoạt động, hạn mức hợp lệ -> Cấp quyền đầy đủ.
     * 2. Expired: Định dạng nhận diện, nhưng hết gói/hạn mức -> Khóa tính năng, yêu cầu gia hạn.
     * 3. Renewed / Extended: Chuyển từ hết hạn sang hoạt động sau gia hạn -> Tự động khôi phục quyền.
     * 4. Lifetime / Free (Unlimited): Miễn phí hoặc vĩnh viễn không cần gia hạn -> Cấp quyền vĩnh viễn.
     * 5. Invalid / Spoofed / Malformed: Chữ cái tùy tiện, sai định dạng, giả mạo -> Từ chối ngay lập tức.
     */
    fun validateApiKey(
        provider: String,
        apiKey: String,
        baseUrl: String = "",
        onComplete: ((ApiKeyValidationResult) -> Unit)? = null,
    ) {
        val trimmed = apiKey.trim()
        if (trimmed.isBlank()) {
            val emptyResult = ApiKeyValidationResult.Invalid("API Key cannot be empty")
            _apiKeyValidation.value = emptyResult
            onComplete?.invoke(emptyResult)
            return
        }

        // Kiểm tra định dạng phía Client (Chặn giả mạo / lậu / từ ngữ thông thường)
        if (!ApiKeyManager.validateKeyFormat(trimmed, provider)) {
            val spoofedResult = ApiKeyValidationResult.Invalid(
                message = "Invalid or spoofed key format. Arbitrary text, placeholder, or pirated tokens are rejected.",
                isSpoofed = true,
            )
            _apiKeyValidation.value = spoofedResult
            viewModelScope.launch {
                context.safeDataStoreEdit { prefs ->
                    prefs[OpenRouterApiKeyStatusKey] = ApiKeyClassification.INVALID_SPOOFED.storageKey
                }
            }
            onComplete?.invoke(spoofedResult)
            return
        }

        _apiKeyValidation.value = ApiKeyValidationResult.Checking
        viewModelScope.launch {
            try {
                val currentStatus = apiKeyStatus.value
                val result = ApiKeyManager.validateKey(provider, trimmed, baseUrl, currentStatus)
                _apiKeyValidation.value = result

                val statusStr = when (result) {
                    is ApiKeyValidationResult.Valid -> result.classification.storageKey
                    is ApiKeyValidationResult.Expired -> ApiKeyClassification.EXPIRED.storageKey
                    is ApiKeyValidationResult.Invalid -> ApiKeyClassification.INVALID_SPOOFED.storageKey
                    is ApiKeyValidationResult.Error -> ApiKeyClassification.ERROR.storageKey
                    else -> ""
                }

                if (statusStr.isNotEmpty()) {
                    context.safeDataStoreEdit { prefs ->
                        prefs[OpenRouterApiKeyStatusKey] = statusStr
                        if (result is ApiKeyValidationResult.Valid && (result.usage != null || result.limit != null)) {
                            prefs[OpenRouterApiKeyDetailsKey] = "${result.usage ?: 0.0}/${result.limit ?: 0.0}"
                        } else if (result is ApiKeyValidationResult.Expired && (result.usage != null || result.limit != null)) {
                            prefs[OpenRouterApiKeyDetailsKey] = "${result.usage ?: 0.0}/${result.limit ?: 0.0}"
                        }
                    }
                }

                onComplete?.invoke(result)
            } catch (e: Exception) {
                val err = ApiKeyValidationResult.Error(e.message ?: "Connection error")
                _apiKeyValidation.value = err
                onComplete?.invoke(err)
            }
        }
    }

    fun resetApiKeyValidation() {
        _apiKeyValidation.value = ApiKeyValidationResult.Idle
    }

    fun setApiKeyStatus(status: String) {
        viewModelScope.launch {
            context.safeDataStoreEdit { prefs ->
                prefs[OpenRouterApiKeyStatusKey] = status
            }
        }
    }

    /**
     * Đề xuất mô hình Trí Tuệ Nhân tạo ngẫu nhiên theo thời gian thực từ OpenRouter.
     * Tự động lấy dữ liệu mô hình mới nhất, chọn ngẫu nhiên một mô hình AI tối ưu và lưu vào cấu hình.
     */
    fun recommendRandomModel(
        forceRefresh: Boolean = false,
        onResult: (OpenRouterModelItem) -> Unit = {},
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val data = modelManager.fetchAndClassifyModels(forceRefresh = forceRefresh)
                _classifiedModels.value = data

                val favoritesManager = ModelFavoritesManager.getInstance(context)
                val tier = selectedTier.value
                val pool = when (tier) {
                    OpenRouterTierBeta -> data.beta
                    OpenRouterTierDeveloper -> data.developer
                    else -> data.official
                }.ifEmpty {
                    data.official + data.beta + data.developer
                }.filter { it.id.isNotBlank() && favoritesManager.isModelSafeAndPublished(it.id, it.name, provider = "OpenRouter") }

                val recommended = pool.randomOrNull()
                if (recommended != null) {
                    selectModel(recommended.id)
                    onResult(recommended)
                }
            } catch (e: Exception) {
                Timber.e(e, "Lỗi khi đề xuất ngẫu nhiên mô hình AI")
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Đề xuất mô hình AI thời gian thực trực tiếp từ https://huggingface.co/api/models
     */
    fun recommendRealtimeHuggingFaceModel(
        forceRefresh: Boolean = true,
        apiKey: String = "",
        onResult: (HuggingFaceModelItem) -> Unit = {},
    ) {
        viewModelScope.launch {
            _isHuggingFaceLoading.value = true
            try {
                val data = huggingFaceModelManager.fetchModels(forceRefresh = forceRefresh, apiKey = apiKey)
                _huggingFaceModels.value = data
                val pool = data.recommended.ifEmpty { data.allModels }.filter { it.id.isNotBlank() }
                val recommended = pool.take(10).randomOrNull() ?: data.topSpotlightModel
                if (recommended != null) {
                    selectModel(recommended.id)
                    onResult(recommended)
                }
            } catch (e: Exception) {
                Timber.e(e, "Failed to recommend real-time HuggingFace model")
            } finally {
                _isHuggingFaceLoading.value = false
            }
        }
    }
}
