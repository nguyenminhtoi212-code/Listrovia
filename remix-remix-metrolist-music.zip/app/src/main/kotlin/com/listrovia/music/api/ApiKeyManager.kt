/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 * 
 * Unified API Key & Validation Management System combining ApiKeyManager and SimpleApiKeyManager 
 * into a single shared file as requested, ensuring zero file fragmentation and maximum stability.
 */

package com.listrovia.music.api

import android.content.Context
import android.content.SharedPreferences
import com.listrovia.music.security.SecureKeyStorage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import timber.log.Timber
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

/**
 * FEATURE SPECIFICATION: API Key Management & Validation System
 *
 * 1. Core Objective:
 *    Secure, global API Key management and license validation system supporting
 *    standard AI service providers (Google Gemini, OpenAI, Anthropic, OpenRouter, etc.)
 *    with strict validity, security, and anti-tamper protections.
 */
enum class ApiKeyClassification(val storageKey: String) {
    VALID_ACTIVE("valid_active"),
    EXPIRED("expired"),
    RENEWED_EXTENDED("renewed_extended"),
    LIFETIME_FREE("lifetime_free"),
    INVALID_SPOOFED("invalid_spoofed"),
    ERROR("error"),
    IDLE("idle"),
    CHECKING("checking");

    companion object {
        fun fromStorageKey(key: String): ApiKeyClassification {
            return entries.firstOrNull { it.storageKey == key } ?: IDLE
        }
    }
}

sealed class ApiKeyValidationResult {
    object Idle : ApiKeyValidationResult()
    object Checking : ApiKeyValidationResult()

    data class Valid(
        val message: String,
        val classification: ApiKeyClassification = ApiKeyClassification.VALID_ACTIVE,
        val label: String? = null,
        val usage: Double? = null,
        val limit: Double? = null,
        val isFreeUnlimited: Boolean = (classification == ApiKeyClassification.LIFETIME_FREE),
        val isRenewed: Boolean = (classification == ApiKeyClassification.RENEWED_EXTENDED),
        val normalizedSchema: NormalizedResponseSchema? = null,
    ) : ApiKeyValidationResult()

    data class Expired(
        val message: String,
        val usage: Double? = null,
        val limit: Double? = null,
        val renewalUrl: String? = null,
        val normalizedSchema: NormalizedResponseSchema? = null,
    ) : ApiKeyValidationResult()

    val isExhaustedOrExpired: Boolean
        get() = this is Expired

    data class Invalid(
        val message: String,
        val isSpoofed: Boolean = false,
        val normalizedSchema: NormalizedResponseSchema? = null,
    ) : ApiKeyValidationResult()

    data class Error(
        val message: String,
        val normalizedSchema: NormalizedResponseSchema? = null,
    ) : ApiKeyValidationResult()
}

typealias ApiKeyValidationExhausted = ApiKeyValidationResult.Expired

/**
 * ValidationResult: Simple result model used across SimpleApiKeyManager checks.
 */
sealed class ValidationResult {
    data class Valid(
        val message: String,
        val statusCode: Int = 200,
        val details: String? = null,
    ) : ValidationResult()

    data class Invalid(
        val message: String,
        val isFormatError: Boolean = false,
        val statusCode: Int? = null,
    ) : ValidationResult()

    data class Error(
        val message: String,
        val throwable: Throwable? = null,
    ) : ValidationResult()
}

/**
 * ApiKeyManager: Comprehensive AI Provider Key Validation & Lifecycle Manager
 */
object ApiKeyManager {

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    private val renewalUrls = mapOf(
        "OpenRouter" to "https://openrouter.ai/credits",
        "OpenAI" to "https://platform.openai.com/account/billing",
        "Claude" to "https://console.anthropic.com/settings/plans",
        "Gemini" to "https://aistudio.google.com",
        "DeepL" to "https://www.deepl.com/pro-account",
        "Perplexity" to "https://www.perplexity.ai/settings/api",
        "Mistral" to "https://console.mistral.ai/billing",
        "XAi" to "https://console.x.ai",
        "DeepInfra" to "https://deepinfra.com/dash/api_keys",
        "AionLabs" to "https://aionlabs.ai",
        "HuggingFace" to "https://huggingface.co/settings/tokens",
        "Nvidia" to "https://build.nvidia.com",
        "Groq" to "https://console.groq.com/keys",
    )

    fun getRenewalUrl(provider: String): String {
        return renewalUrls[provider] ?: "https://openrouter.ai/credits"
    }

    fun validateKeyFormat(rawKey: String, provider: String = ""): Boolean {
        val key = rawKey.trim()
        if (provider == "DeepInfra") {
            return key.isBlank() || (key.length >= 10 && !key.contains(" "))
        }
        if (key.length < 16) return false

        val normalized = key.lowercase()
        val blacklistedKeywords = listOf(
            "dummy", "fake", "test", "demo", "sample", "placeholder",
            "example", "123456", "abcdef", "qwerty", "mykey", "apikey",
            "secret", "token", "password", "foobar", "invalid"
        )
        if (blacklistedKeywords.any { normalized.contains(it) }) return false

        val hasDigitsOrSpecial = key.any { it.isDigit() || it == '-' || it == '_' || it == '.' }
        if (!hasDigitsOrSpecial) return false

        return when (provider) {
            "OpenRouter" -> {
                key.startsWith("sk-or-v1-") && key.length >= 32 &&
                        Pattern.compile("^sk-or-v1-[a-zA-Z0-9_-]{20,}$").matcher(key).matches()
            }
            "OpenAI" -> {
                (key.startsWith("sk-") || key.startsWith("sk-proj-")) && key.length >= 24 &&
                        Pattern.compile("^sk-(proj-)?[a-zA-Z0-9_-]{20,}$").matcher(key).matches()
            }
            "Gemini" -> {
                key.startsWith("AIza") && key.length >= 25 &&
                        Pattern.compile("^AIza[0-9A-Za-z_-]{20,}$").matcher(key).matches()
            }
            "Claude" -> {
                key.startsWith("sk-ant-") && key.length >= 24 &&
                        Pattern.compile("^sk-ant-[a-zA-Z0-9_-]{16,}$").matcher(key).matches()
            }
            "Perplexity" -> {
                key.startsWith("pplx-") && key.length >= 20 &&
                        Pattern.compile("^pplx-[a-zA-Z0-9_-]{16,}$").matcher(key).matches()
            }
            "DeepL" -> {
                key.length >= 20 && !key.contains(" ") &&
                        Pattern.compile("^[a-zA-Z0-9_-]+(:fx)?$").matcher(key).matches()
            }
            "Nvidia" -> {
                key.startsWith("nvapi-") && key.length >= 24 &&
                        Pattern.compile("^nvapi-[a-zA-Z0-9_-]{16,}$").matcher(key).matches()
            }
            "Groq" -> {
                key.startsWith("gsk_") && key.length >= 24 &&
                        Pattern.compile("^gsk_[a-zA-Z0-9_-]{16,}$").matcher(key).matches()
            }
            "HuggingFace" -> {
                (key.startsWith("hf_") && key.length >= 20 &&
                        Pattern.compile("^hf_[a-zA-Z0-9_-]{16,}$").matcher(key).matches()) ||
                    (!key.contains(" ") && key.length >= 20 &&
                        Pattern.compile("^[a-zA-Z0-9_.-]{20,}$").matcher(key).matches())
            }
            else -> {
                !key.contains(" ") && key.length >= 18 &&
                        Pattern.compile("^[a-zA-Z0-9_.-]{18,}$").matcher(key).matches()
            }
        }
    }

    suspend fun validateKey(
        provider: String,
        rawKey: String,
        baseUrl: String = "",
        previousStatus: String = "",
    ): ApiKeyValidationResult = withContext(Dispatchers.IO) {
        val key = rawKey.trim()
        if (key.isBlank()) {
            return@withContext if (provider == "DeepInfra") {
                ApiKeyValidationResult.Valid(
                    message = "DeepInfra (No API key required)",
                    classification = ApiKeyClassification.LIFETIME_FREE,
                    isFreeUnlimited = true,
                )
            } else {
                ApiKeyValidationResult.Invalid("API Key cannot be empty")
            }
        }

        if (!validateKeyFormat(key, provider)) {
            return@withContext ApiKeyValidationResult.Invalid(
                message = "Invalid or malformed key format. Key should contain valid alphanumeric characters, hyphens or underscores.",
                isSpoofed = true,
            )
        }

        val wasPreviouslyExpired = previousStatus == ApiKeyClassification.EXPIRED.storageKey

        try {
            when (provider) {
                "OpenRouter", "" -> {
                    val request = Request.Builder()
                        .url("https://openrouter.ai/api/v1/auth/key")
                        .addHeader("Authorization", "Bearer $key")
                        .addHeader("HTTP-Referer", "https://listrovia.cc")
                        .addHeader("X-Title", "Listrovia Music")
                        .get()
                        .build()

                    val response = httpClient.newCall(request).execute()
                    val responseBody = response.body?.string() ?: ""
                    val code = response.code

                    when (code) {
                        200 -> {
                            val json = try { JSONObject(responseBody) } catch (e: Exception) { JSONObject() }
                            val dataObj = json.optJSONObject("data")
                            val label = dataObj?.optString("label")?.takeIf { it.isNotBlank() }
                            val usage = if (dataObj != null && dataObj.has("usage") && !dataObj.isNull("usage")) dataObj.optDouble("usage") else null
                            val hasLimit = dataObj != null && dataObj.has("limit") && !dataObj.isNull("limit")
                            val limit = if (hasLimit) dataObj?.optDouble("limit") else null
                            val isFreeTier = dataObj?.optBoolean("is_free_tier", false) ?: false

                            if (limit != null && limit > 0.0 && usage != null && usage >= limit) {
                                ApiKeyValidationResult.Expired(
                                    message = "Subscription or quota limit reached ($usage / $limit USD). Renewal required.",
                                    usage = usage,
                                    limit = limit,
                                    renewalUrl = getRenewalUrl(provider),
                                )
                            } else if (limit != null && limit == 0.0) {
                                ApiKeyValidationResult.Expired(
                                    message = "Key balance is zero or subscription ended. Renewal required.",
                                    usage = usage,
                                    limit = limit,
                                    renewalUrl = getRenewalUrl(provider),
                                )
                            } else if (limit == null || isFreeTier) {
                                ApiKeyValidationResult.Valid(
                                    message = "Lifetime / Free Key (Unlimited). Permanent access granted.",
                                    classification = ApiKeyClassification.LIFETIME_FREE,
                                    label = label,
                                    usage = usage,
                                    limit = limit,
                                    isFreeUnlimited = true,
                                )
                            } else if (wasPreviouslyExpired) {
                                ApiKeyValidationResult.Valid(
                                    message = "Key successfully renewed! Feature access automatically restored.",
                                    classification = ApiKeyClassification.RENEWED_EXTENDED,
                                    label = label,
                                    usage = usage,
                                    limit = limit,
                                    isRenewed = true,
                                )
                            } else {
                                ApiKeyValidationResult.Valid(
                                    message = "Valid Active Key. Full application access granted.",
                                    classification = ApiKeyClassification.VALID_ACTIVE,
                                    label = label,
                                    usage = usage,
                                    limit = limit,
                                )
                            }
                        }
                        401 -> {
                            ApiKeyValidationResult.Invalid(
                                message = "Key rejected by provider backend (HTTP 401 Unauthorized).",
                                isSpoofed = true,
                            )
                        }
                        402, 429 -> {
                            ApiKeyValidationResult.Expired(
                                message = "Key quota or balance expired (HTTP $code). Renewal required.",
                                renewalUrl = getRenewalUrl(provider),
                            )
                        }
                        else -> {
                            if (code in 400..499) {
                                ApiKeyValidationResult.Invalid("Provider rejected key with error HTTP $code.")
                            } else {
                                ApiKeyValidationResult.Error("Server verification error (HTTP $code).")
                            }
                        }
                    }
                }

                "OpenAI" -> {
                    val request = Request.Builder()
                        .url("https://api.openai.com/v1/models")
                        .addHeader("Authorization", "Bearer $key")
                        .get()
                        .build()

                    val response = httpClient.newCall(request).execute()
                    val code = response.code

                    when (code) {
                        200 -> {
                            if (wasPreviouslyExpired) {
                                ApiKeyValidationResult.Valid(
                                    message = "OpenAI key renewed! Feature access restored.",
                                    classification = ApiKeyClassification.RENEWED_EXTENDED,
                                    isRenewed = true,
                                )
                            } else {
                                ApiKeyValidationResult.Valid(
                                    message = "Valid Active OpenAI Key. Full application access granted.",
                                    classification = ApiKeyClassification.VALID_ACTIVE,
                                )
                            }
                        }
                        401 -> ApiKeyValidationResult.Invalid(
                            message = "Invalid or unverified OpenAI API key.",
                            isSpoofed = true,
                        )
                        429 -> {
                            ApiKeyValidationResult.Expired(
                                message = "OpenAI quota/billing period expired. Renewal required.",
                                renewalUrl = getRenewalUrl(provider),
                            )
                        }
                        else -> ApiKeyValidationResult.Error("OpenAI verification error: HTTP $code")
                    }
                }

                "Gemini" -> {
                    val request = Request.Builder()
                        .url("https://generativelanguage.googleapis.com/v1beta/models?key=$key")
                        .get()
                        .build()

                    val response = httpClient.newCall(request).execute()
                    when (response.code) {
                        200 -> {
                            ApiKeyValidationResult.Valid(
                                message = "Valid Lifetime / Free Key (Google Gemini). Permanent access granted.",
                                classification = ApiKeyClassification.LIFETIME_FREE,
                                isFreeUnlimited = true,
                            )
                        }
                        400, 403 -> ApiKeyValidationResult.Invalid(
                            message = "Google Gemini API key is invalid or spoofed.",
                            isSpoofed = true,
                        )
                        429 -> ApiKeyValidationResult.Expired(
                            message = "Gemini quota expired. Please extend or renew in Google AI Studio.",
                            renewalUrl = getRenewalUrl(provider),
                        )
                        else -> ApiKeyValidationResult.Error("Gemini error: HTTP ${response.code}")
                    }
                }

                "Claude" -> {
                    val request = Request.Builder()
                        .url("https://api.anthropic.com/v1/models")
                        .addHeader("x-api-key", key)
                        .addHeader("anthropic-version", "2023-06-01")
                        .get()
                        .build()

                    val response = httpClient.newCall(request).execute()
                    when (response.code) {
                        200 -> {
                            if (wasPreviouslyExpired) {
                                ApiKeyValidationResult.Valid(
                                    message = "Anthropic Claude key renewed! Access restored.",
                                    classification = ApiKeyClassification.RENEWED_EXTENDED,
                                    isRenewed = true,
                                )
                            } else {
                                ApiKeyValidationResult.Valid(
                                    message = "Valid Active Claude Key. Full access granted.",
                                    classification = ApiKeyClassification.VALID_ACTIVE,
                                )
                            }
                        }
                        401 -> ApiKeyValidationResult.Invalid(
                            message = "Anthropic Claude API key is invalid or unauthorized.",
                            isSpoofed = true,
                        )
                        402, 429 -> ApiKeyValidationResult.Expired(
                            message = "Claude subscription credit expired. Renewal required.",
                            renewalUrl = getRenewalUrl(provider),
                        )
                        else -> ApiKeyValidationResult.Error("Claude error: HTTP ${response.code}")
                    }
                }

                "Nvidia" -> {
                    val request = Request.Builder()
                        .url("https://integrate.api.nvidia.com/v1/models")
                        .addHeader("Authorization", "Bearer $key")
                        .get()
                        .build()

                    val response = httpClient.newCall(request).execute()
                    when (response.code) {
                        200 -> {
                            if (wasPreviouslyExpired) {
                                ApiKeyValidationResult.Valid(
                                    message = "Nvidia API key renewed! Access restored.",
                                    classification = ApiKeyClassification.RENEWED_EXTENDED,
                                    isRenewed = true,
                                )
                            } else {
                                ApiKeyValidationResult.Valid(
                                    message = "Valid Active Nvidia Key (build.nvidia.com). Access granted.",
                                    classification = ApiKeyClassification.VALID_ACTIVE,
                                )
                            }
                        }
                        401 -> ApiKeyValidationResult.Invalid(
                            message = "Nvidia API key is invalid or unauthorized. Visit build.nvidia.com for API keys.",
                            isSpoofed = true,
                        )
                        402, 429 -> ApiKeyValidationResult.Expired(
                            message = "Nvidia API credits expired. Renewal required.",
                            renewalUrl = getRenewalUrl(provider),
                        )
                        else -> ApiKeyValidationResult.Error("Nvidia error: HTTP ${response.code}")
                    }
                }

                "Groq" -> {
                    val request = Request.Builder()
                        .url("https://api.groq.com/openai/v1/models")
                        .addHeader("Authorization", "Bearer $key")
                        .get()
                        .build()

                    val response = httpClient.newCall(request).execute()
                    when (response.code) {
                        200 -> {
                            ApiKeyValidationResult.Valid(
                                message = "Valid Groq API Key (console.groq.com/keys). Free high-speed access granted.",
                                classification = ApiKeyClassification.LIFETIME_FREE,
                                isFreeUnlimited = true,
                            )
                        }
                        401 -> ApiKeyValidationResult.Invalid(
                            message = "Groq API key is invalid. Visit console.groq.com/keys for free API keys.",
                            isSpoofed = true,
                        )
                        402, 429 -> ApiKeyValidationResult.Expired(
                            message = "Groq rate limit or credits exceeded.",
                            renewalUrl = getRenewalUrl(provider),
                        )
                        else -> ApiKeyValidationResult.Error("Groq error: HTTP ${response.code}")
                    }
                }

                "HuggingFace" -> {
                    val request = Request.Builder()
                        .url("https://huggingface.co/api/whoami-v2")
                        .addHeader("Authorization", "Bearer $key")
                        .get()
                        .build()

                    val response = httpClient.newCall(request).execute()
                    when (response.code) {
                        200 -> {
                            ApiKeyValidationResult.Valid(
                                message = "Valid Hugging Face Access Token (huggingface.co). Real-time Hub & Router access granted.",
                                classification = ApiKeyClassification.LIFETIME_FREE,
                                isFreeUnlimited = true,
                            )
                        }
                        401 -> ApiKeyValidationResult.Invalid(
                            message = "Hugging Face token is invalid or unauthorized. Visit huggingface.co/settings/tokens.",
                            isSpoofed = true,
                        )
                        402, 429 -> ApiKeyValidationResult.Expired(
                            message = "Hugging Face inference quota or rate limit reached.",
                            renewalUrl = getRenewalUrl(provider),
                        )
                        else -> ApiKeyValidationResult.Error("Hugging Face verification error: HTTP ${response.code}")
                    }
                }

                else -> {
                    if (key.startsWith("sk-or-v1-")) {
                        return@withContext validateKey("OpenRouter", key, baseUrl, previousStatus)
                    }

                    val targetEndpoint = when {
                        baseUrl.isNotBlank() -> {
                            val trimmed = baseUrl.trim()
                            if (trimmed.endsWith("/chat/completions") || trimmed.endsWith("/models")) {
                                trimmed
                            } else if (trimmed.endsWith("/")) {
                                "${trimmed}models"
                            } else {
                                "${trimmed}/models"
                            }
                        }
                        else -> ""
                    }

                    if (targetEndpoint.isNotBlank()) {
                        val reqBuilder = Request.Builder().url(targetEndpoint)
                        if (key.startsWith("sk-ant-")) {
                            reqBuilder.addHeader("x-api-key", key)
                            reqBuilder.addHeader("anthropic-version", "2023-06-01")
                        } else {
                            reqBuilder.addHeader("Authorization", "Bearer $key")
                        }

                        try {
                            val response = httpClient.newCall(reqBuilder.get().build()).execute()
                            val code = response.code
                            when (code) {
                                200 -> {
                                    val schema = NormalizedResponseSchema.success(
                                        provider = if (provider.isNotBlank()) provider else "CUSTOM_PROVIDER",
                                        endpoint = targetEndpoint,
                                        keyState = if (wasPreviouslyExpired) "RENEWED_EXTENDED" else "VALID_ACTIVE",
                                    )
                                    if (wasPreviouslyExpired) {
                                        ApiKeyValidationResult.Valid(
                                            message = "Custom Provider: Khóa đã gia hạn! Quyền truy cập được khôi phục.",
                                            classification = ApiKeyClassification.RENEWED_EXTENDED,
                                            isRenewed = true,
                                            normalizedSchema = schema,
                                        )
                                    } else {
                                        ApiKeyValidationResult.Valid(
                                            message = "Custom Provider: Khóa hợp lệ (HTTP 200). Đã cấp quyền truy cập.",
                                            classification = ApiKeyClassification.VALID_ACTIVE,
                                            normalizedSchema = schema,
                                        )
                                    }
                                }
                                401 -> {
                                    val schema = NormalizedResponseSchema.error(
                                        provider = if (provider.isNotBlank()) provider else "CUSTOM_PROVIDER",
                                        endpoint = targetEndpoint,
                                        keyState = "INVALID",
                                        code = "AUTH_FAILED",
                                        message = "API Key không hợp lệ hoặc đường dẫn API nhà cung cấp không phản hồi.",
                                        rawProviderCode = 401,
                                    )
                                    ApiKeyValidationResult.Invalid(
                                        message = "API Key không hợp lệ hoặc đường dẫn API nhà cung cấp không phản hồi (HTTP 401).",
                                        isSpoofed = true,
                                        normalizedSchema = schema,
                                    )
                                }
                                402, 429 -> {
                                    val schema = NormalizedResponseSchema.error(
                                        provider = if (provider.isNotBlank()) provider else "CUSTOM_PROVIDER",
                                        endpoint = targetEndpoint,
                                        keyState = "EXPIRED",
                                        code = "QUOTA_EXCEEDED",
                                        message = "Hạn mức hoặc số dư của khóa đã hết. Vui lòng gia hạn tài khoản.",
                                        rawProviderCode = code,
                                    )
                                    ApiKeyValidationResult.Expired(
                                        message = "Hạn mức hoặc số dư đã hết (HTTP $code). Cần gia hạn.",
                                        renewalUrl = baseUrl,
                                        normalizedSchema = schema,
                                    )
                                }
                                else -> {
                                    if (code in 400..499) {
                                        val schema = NormalizedResponseSchema.error(
                                            provider = if (provider.isNotBlank()) provider else "CUSTOM_PROVIDER",
                                            endpoint = targetEndpoint,
                                            keyState = "INVALID",
                                            code = "CLIENT_ERROR",
                                            message = "Endpoint từ chối yêu cầu xác thực (HTTP $code)",
                                            rawProviderCode = code,
                                        )
                                        ApiKeyValidationResult.Invalid(
                                            message = "Endpoint từ chối yêu cầu (HTTP $code)",
                                            normalizedSchema = schema,
                                        )
                                    } else {
                                        val schema = NormalizedResponseSchema.error(
                                            provider = if (provider.isNotBlank()) provider else "CUSTOM_PROVIDER",
                                            endpoint = targetEndpoint,
                                            keyState = "INVALID",
                                            code = "SERVER_ERROR",
                                            message = "Lỗi phản hồi từ máy chủ Custom Endpoint (HTTP $code)",
                                            rawProviderCode = code,
                                        )
                                        ApiKeyValidationResult.Error(
                                            message = "Lỗi máy chủ Custom Provider: HTTP $code",
                                            normalizedSchema = schema,
                                        )
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            Timber.w("Custom Endpoint ping failed: ${e.message}")
                            val schema = NormalizedResponseSchema.error(
                                provider = if (provider.isNotBlank()) provider else "CUSTOM_PROVIDER",
                                endpoint = targetEndpoint,
                                keyState = "INVALID",
                                code = "NETWORK_UNREACHABLE",
                                message = "Không thể kết nối tới Custom Endpoint: ${e.message}",
                                rawProviderCode = null,
                            )
                            ApiKeyValidationResult.Error(
                                message = "Không thể kết nối tới Custom Endpoint: ${e.message}",
                                normalizedSchema = schema,
                            )
                        }
                    } else {
                        val schema = NormalizedResponseSchema.success(
                            provider = if (provider.isNotBlank()) provider else "CUSTOM_PROVIDER",
                            endpoint = "local_format_check",
                            keyState = "VALID_ACTIVE",
                        )
                        ApiKeyValidationResult.Valid(
                            message = "Định dạng khóa hợp lệ đã được xác minh.",
                            classification = ApiKeyClassification.VALID_ACTIVE,
                            normalizedSchema = schema,
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Timber.e("ApiKeyManager: Network ping verification failure: ${e.message}")
            ApiKeyValidationResult.Error(e.message ?: "Network connection error while verifying key")
        }
    }

    fun isFeatureAccessGranted(status: String, provider: String = ""): Boolean {
        if (provider == "DeepInfra") return true
        return when (status) {
            ApiKeyClassification.VALID_ACTIVE.storageKey,
            ApiKeyClassification.RENEWED_EXTENDED.storageKey,
            ApiKeyClassification.LIFETIME_FREE.storageKey,
            "valid",
            "valid_renewed",
            "valid_free" -> true
            else -> false
        }
    }
}

/**
 * SimpleApiKeyManager:
 * Integrated directly into ApiKeyManager.kt as requested to ensure zero file fragmentation,
 * providing clean utility functions for text config fetching, local format validation, and endpoint pings.
 */
object SimpleApiKeyManager {

    private const val PREFS_NAME = "simple_api_key_prefs"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile
    private var appContext: Context? = null

    fun init(context: Context) {
        if (appContext == null) {
            appContext = context.applicationContext
        }
    }

    fun fetchConfigFromTxtUrl(url: String, callback: (String?) -> Unit) {
        val cleanUrl = url.trim()
        if (cleanUrl.isBlank() || (!cleanUrl.startsWith("http://", ignoreCase = true) && !cleanUrl.startsWith("https://", ignoreCase = true))) {
            callback(null)
            return
        }

        scope.launch {
            val content = try {
                val request = Request.Builder()
                    .url(cleanUrl)
                    .header("User-Agent", "ListroviaMusic/1.0 (Android)")
                    .header("Accept", "text/plain, text/*, */*")
                    .build()

                OkHttpClient.Builder()
                    .connectTimeout(12, TimeUnit.SECONDS)
                    .readTimeout(15, TimeUnit.SECONDS)
                    .callTimeout(20, TimeUnit.SECONDS)
                    .build()
                    .newCall(request).execute().use { response ->
                        if (response.isSuccessful) {
                            response.body?.string()
                        } else {
                            Timber.w("fetchConfigFromTxtUrl: HTTP ${response.code}")
                            null
                        }
                    }
            } catch (e: Exception) {
                Timber.e(e, "fetchConfigFromTxtUrl: Failed to fetch from $cleanUrl")
                null
            }

            withContext(Dispatchers.Main) {
                callback(content)
            }
        }
    }

    fun checkLocalFormat(apiKey: String, providerUrl: String = ""): ValidationResult {
        val trimmedKey = apiKey.trim()
        val trimmedUrl = providerUrl.trim()
        if (trimmedUrl.isNotBlank()) {
            val isHttp = trimmedUrl.startsWith("http://", ignoreCase = true)
            val isHttps = trimmedUrl.startsWith("https://", ignoreCase = true)
            if (!isHttp && !isHttps) {
                return ValidationResult.Invalid(
                    message = "URL nhà cung cấp không hợp lệ. Phải bắt đầu bằng http:// hoặc https://",
                    isFormatError = true,
                )
            }
        }

        if (trimmedKey.isEmpty()) {
            return ValidationResult.Valid("Key rỗng")
        }

        val allowedPattern = Pattern.compile("^[a-zA-Z0-9_-]+$")
        if (!allowedPattern.matcher(trimmedKey).matches()) {
            return ValidationResult.Invalid(
                message = "Khóa chứa ký tự không hợp lệ. Chỉ chấp nhận chữ cái (A-Z, a-z), chữ số (0-9), dấu gạch ngang (-) và gạch dưới (_).",
                isFormatError = true,
            )
        }

        return ValidationResult.Valid("Cú pháp hợp lệ")
    }

    fun validateKey(
        providerUrl: String,
        apiKey: String,
        callback: (ValidationResult) -> Unit,
    ) {
        val cleanKey = apiKey.trim()
        val cleanUrl = providerUrl.trim()

        val localCheck = checkLocalFormat(cleanKey, cleanUrl)
        if (localCheck is ValidationResult.Invalid) {
            callback(localCheck)
            return
        }

        if (cleanUrl.isBlank()) {
            callback(ValidationResult.Valid("Cú pháp hợp lệ (Không có endpoint kiểm tra trực tiếp)"))
            return
        }

        scope.launch {
            val result = try {
                val reqBuilder = Request.Builder().url(cleanUrl)
                if (cleanKey.isNotBlank()) {
                    reqBuilder.addHeader("Authorization", "Bearer $cleanKey")
                }
                val response = OkHttpClient.Builder()
                    .connectTimeout(12, TimeUnit.SECONDS)
                    .readTimeout(15, TimeUnit.SECONDS)
                    .build()
                    .newCall(reqBuilder.get().build()).execute()

                val code = response.code
                when {
                    code == 401 -> ValidationResult.Invalid("API Key không hợp lệ hoặc bị từ chối (HTTP 401).", statusCode = 401)
                    code == 403 -> ValidationResult.Invalid("Truy cập bị từ chối (HTTP 403).", statusCode = 403)
                    code == 429 -> ValidationResult.Invalid("API Key đã hết hạn mức sử dụng hoặc vượt quá tần suất gọi (HTTP 429).", statusCode = 429)
                    code in 200..299 -> ValidationResult.Valid("Xác thực thành công (HTTP $code)", statusCode = code)
                    else -> {
                        val responseBody = response.body?.string() ?: ""
                        if (responseBody.contains("error", ignoreCase = true)) {
                            ValidationResult.Invalid("Nhà cung cấp từ chối yêu cầu (HTTP $code)", statusCode = code)
                        } else {
                            ValidationResult.Valid("Endpoint phản hồi khả dụng (HTTP $code)", statusCode = code)
                        }
                    }
                }
            } catch (e: Exception) {
                ValidationResult.Error(e.message ?: "Lỗi kết nối tới nhà cung cấp", throwable = e)
            }

            withContext(Dispatchers.Main) {
                callback(result)
            }
        }
    }
}
