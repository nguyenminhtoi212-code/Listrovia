/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.component

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.listrovia.music.R
import com.listrovia.music.api.DeepInfraClassifiedModels
import com.listrovia.music.api.DeepInfraModelItem
import com.listrovia.music.api.DeepInfraModelManager
import com.listrovia.music.constants.DeepInfraDefaultModel
import com.listrovia.music.utils.ModelBenchmarkUtility
import com.listrovia.music.utils.ModelFavoritesManager
import com.listrovia.music.viewmodels.ModelViewModel
import com.valentinilk.shimmer.shimmer
import kotlinx.coroutines.launch

/**
 * Reusable 'ModelSelector' Composable that fetches the model list from the DeepInfra API
 * (https://api.deepinfra.com/v1/openai/models) using Ktor and displays them in a modern,
 * Material 3 Dropdown menu for selecting AI models.
 *
 * Supports:
 * - Real-time live API reading via Ktor engine with fallback resilience.
 * - Bilingual support (Vietnamese & English) for model descriptions and ranking badges.
 * - Categorization (⭐ Ranked, 💬 Chat, 🧠 Reasoning, 🌐 All).
 * - Live search filter within the dropdown.
 * - Custom Model ID entry.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModelSelector(
    modifier: Modifier = Modifier,
    selectedModel: String,
    onModelSelected: (String) -> Unit,
    onCustomModelClick: (() -> Unit)? = null,
    onShowAllModelsClick: (() -> Unit)? = null,
    viewModel: ModelViewModel = hiltViewModel(),
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val modelManager = remember { DeepInfraModelManager.getInstance(context) }

    val vmDeepInfraModels by viewModel.deepInfraModels.collectAsStateWithLifecycle()
    val isVmLoading by viewModel.isDeepInfraLoading.collectAsStateWithLifecycle()

    var localModels by remember { mutableStateOf<DeepInfraClassifiedModels?>(vmDeepInfraModels) }
    var isLocalLoading by remember { mutableStateOf(false) }

    val activeModels = localModels ?: vmDeepInfraModels
    val isLoading = isLocalLoading || (isVmLoading && activeModels == null)

    var dropdownExpanded by remember { mutableStateOf(false) }
    var selectedCategoryIndex by remember { mutableStateOf(0) } // 0: Ranked, 1: Chat, 2: Reasoning, 3: All
    var searchQuery by remember { mutableStateOf("") }
    val isVietnamese = remember { java.util.Locale.getDefault().language == "vi" }

    val loadModels: (Boolean) -> Unit = { force ->
        coroutineScope.launch {
            isLocalLoading = true
            try {
                val fetched = modelManager.fetchModels(forceRefresh = force)
                localModels = fetched
                if (force) {
                    Toast.makeText(
                        context,
                        context.getString(R.string.ai_deepinfra_updated_success, fetched.allModels.size),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } catch (e: Exception) {
                if (force) {
                    Toast.makeText(
                        context,
                        context.getString(R.string.ai_deepinfra_error_toast, e.message ?: ""),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } finally {
                isLocalLoading = false
            }
        }
    }

    LaunchedEffect(Unit) {
        if (activeModels == null) {
            loadModels(false)
        }
    }

    val favoritesManager = remember { ModelFavoritesManager.getInstance(context) }
    val benchmarkUtility = remember { ModelBenchmarkUtility.getInstance(context) }
    var favVersion by remember { mutableStateOf(0) }
    var activeDetailModel by remember { mutableStateOf<DetailedAiModelInfo?>(null) }
    var activeProviderInfo by remember { mutableStateOf<Pair<String, String>?>(null) }

    val currentCategoryList: List<DeepInfraModelItem> = remember(activeModels, selectedCategoryIndex, favVersion) {
        val models = activeModels ?: return@remember emptyList()
        val rawList = when (selectedCategoryIndex) {
            0 -> models.recommended
            1 -> models.chatModels
            2 -> models.reasoningModels
            else -> models.allModels
        }
        rawList.filter { favoritesManager.isModelSafeAndPublished(it.id, it.name, it.description, it.providerName) }
    }

    val filteredModels: List<DeepInfraModelItem> = remember(currentCategoryList, searchQuery, favVersion) {
        val favIds = favoritesManager.getFavoriteIds()
        val searched = if (searchQuery.isBlank()) {
            currentCategoryList
        } else {
            val q = searchQuery.trim().lowercase()
            currentCategoryList.filter {
                it.id.lowercase().contains(q) ||
                    it.name.lowercase().contains(q) ||
                    it.providerName.lowercase().contains(q) ||
                    it.description.lowercase().contains(q) ||
                    it.descriptionVi.lowercase().contains(q)
            }
        }
        // Ghim mô hình yêu thích (starred) lên trên đầu danh sách
        val (favs, others) = searched.partition { favIds.contains(it.id) }
        favs + others
    }

    val activeModelObj = remember(activeModels, selectedModel) {
        activeModels?.allModels?.firstOrNull { it.id == selectedModel }
            ?: activeModels?.recommended?.firstOrNull { it.id == selectedModel }
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // Header with DeepInfra icon, title, provider info button, and refresh button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f),
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.discover_tune),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.ai_deepinfra_models_title),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = stringResource(R.string.ai_deepinfra_models_desc),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    IconButton(
                        onClick = {
                            val mId = activeModelObj?.id ?: selectedModel.ifBlank { DeepInfraDefaultModel }
                            val pName = activeModelObj?.providerName?.ifBlank { "DeepInfra" } ?: "DeepInfra"
                            activeProviderInfo = mId to pName
                        },
                        modifier = Modifier.size(34.dp),
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.info),
                            contentDescription = stringResource(R.string.ai_provider_help),
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp),
                        )
                    }

                    // Ktor Live Refresh Button
                    IconButton(
                        onClick = { loadModels(true) },
                        enabled = !isLoading,
                        modifier = Modifier.size(34.dp),
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                            )
                        } else {
                            Icon(
                                painter = painterResource(R.drawable.sync),
                                contentDescription = stringResource(R.string.ai_deepinfra_refresh),
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp),
                            )
                        }
                    }
                }
            }

            // Shimmer skeleton when loading initially
            AnimatedVisibility(
                visible = isLoading && activeModels == null,
                enter = fadeIn(),
                exit = fadeOut(),
            ) {
                ModelSelectorShimmerSkeleton()
            }

            // Main Interactive Dropdown Selector
            AnimatedVisibility(
                visible = !(isLoading && activeModels == null),
                enter = fadeIn(),
                exit = fadeOut(),
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    // Horizontal category filter chips: Ranked | Chat | Reasoning | All
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        val categories = listOf(
                            0 to stringResource(R.string.ai_deepinfra_tab_ranked_count, activeModels?.recommended?.size ?: 0),
                            1 to stringResource(R.string.ai_deepinfra_tab_chat_count, activeModels?.chatModels?.size ?: 0),
                            2 to stringResource(R.string.ai_deepinfra_tab_reasoning_count, activeModels?.reasoningModels?.size ?: 0),
                            3 to stringResource(R.string.ai_deepinfra_tab_all_count, activeModels?.allModels?.size ?: 0),
                        )

                        categories.forEach { (index, title) ->
                            FilterChip(
                                selected = selectedCategoryIndex == index,
                                onClick = { selectedCategoryIndex = index },
                                label = {
                                    Text(
                                        text = title,
                                        style = MaterialTheme.typography.labelSmall,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                    selectedLabelColor = MaterialTheme.colorScheme.primary,
                                ),
                                shape = RoundedCornerShape(8.dp),
                            )
                        }
                    }

                    // ExposedDropdownMenuBox for model selection
                    ExposedDropdownMenuBox(
                        expanded = dropdownExpanded,
                        onExpandedChange = { dropdownExpanded = !dropdownExpanded },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        val displayTitle = activeModelObj?.name
                            ?: selectedModel.ifBlank { DeepInfraDefaultModel }

                        OutlinedTextField(
                            value = displayTitle,
                            onValueChange = {},
                            readOnly = true,
                            singleLine = true,
                            leadingIcon = {
                                ProviderAvatar(
                                    modelId = selectedModel,
                                    providerName = activeModelObj?.providerName ?: "",
                                    size = 26.dp,
                                    modifier = Modifier.padding(start = 4.dp),
                                )
                            },
                            label = {
                                Text(
                                    text = stringResource(R.string.ai_deepinfra_realtime_label),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            },
                            supportingText = {
                                Text(
                                    text = activeModelObj?.let { obj ->
                                        val rankText = if (obj.rank < 999) "Rank ${obj.rank} • " else ""
                                        val costText = if (obj.inputCost == 0.0) stringResource(R.string.ai_deepinfra_free_only) else "$${obj.inputCost}/M"
                                        "$rankText${obj.id} • $costText"
                                    } ?: selectedModel.ifBlank { DeepInfraDefaultModel },
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            },
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded)
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth(),
                        )

                        ExposedDropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = {
                                dropdownExpanded = false
                                searchQuery = ""
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 420.dp),
                        ) {
                            // Search Box inside Dropdown
                            Box(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                                OutlinedTextField(
                                    value = searchQuery,
                                    onValueChange = { searchQuery = it },
                                    placeholder = {
                                        Text(
                                            text = stringResource(R.string.ai_deepinfra_search_hint),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                    },
                                    leadingIcon = {
                                        Icon(
                                            painter = painterResource(R.drawable.search),
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp),
                                        )
                                    },
                                    trailingIcon = {
                                        if (searchQuery.isNotEmpty()) {
                                            IconButton(onClick = { searchQuery = "" }) {
                                                Icon(
                                                    painter = painterResource(R.drawable.close),
                                                    contentDescription = null,
                                                    modifier = Modifier.size(16.dp),
                                                )
                                            }
                                        }
                                    },
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth(),
                                )
                            }

                            HorizontalDivider()

                            if (isLoading && filteredModels.isEmpty()) {
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        ) {
                                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                            Text(
                                                text = stringResource(R.string.ai_deepinfra_loading_ktor),
                                                style = MaterialTheme.typography.bodyMedium,
                                            )
                                        }
                                    },
                                    onClick = {},
                                    enabled = false,
                                )
                            } else if (filteredModels.isEmpty()) {
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = stringResource(R.string.ai_deepinfra_no_match),
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    },
                                    onClick = {},
                                    enabled = false,
                                )
                            } else {
                                val limitedModels = filteredModels.take(15)
                                limitedModels.forEach { item ->
                                    val isSelected = item.id == selectedModel
                                    DropdownMenuItem(
                                        leadingIcon = {
                                            ProviderAvatar(
                                                modelId = item.id,
                                                providerName = item.providerName,
                                                size = 28.dp,
                                            )
                                        },
                                        text = {
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 4.dp),
                                                verticalArrangement = Arrangement.spacedBy(2.dp),
                                            ) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                ) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        modifier = Modifier.weight(1f),
                                                    ) {
                                                        Text(
                                                            text = item.name,
                                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis,
                                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                                            modifier = Modifier.weight(1f, fill = false),
                                                        )
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        ProviderBadge(
                                                            modelId = item.id,
                                                            providerName = item.providerName,
                                                            onClick = {
                                                                activeProviderInfo = item.id to item.providerName
                                                            },
                                                        )
                                                    }

                                                    // Context Length badge
                                                    if (item.contextLength > 0) {
                                                        val contextK = item.contextLength / 1000
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Surface(
                                                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                                                            shape = RoundedCornerShape(6.dp),
                                                        ) {
                                                            Text(
                                                                text = "${contextK}k",
                                                                style = MaterialTheme.typography.labelSmall,
                                                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                                maxLines = 1,
                                                                softWrap = false,
                                                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                                                            )
                                                        }
                                                    }
                                                }

                                                // Rank Badge if available
                                                val rankTitle = item.getRankTitleByLanguage(isVietnamese)
                                                if (rankTitle.isNotBlank()) {
                                                    Text(
                                                        text = rankTitle,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.tertiary,
                                                        fontWeight = FontWeight.SemiBold,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis,
                                                    )
                                                }

                                                // Bilingual Description
                                                val description = item.getDescriptionByLanguage(isVietnamese)
                                                if (description.isNotBlank()) {
                                                    Text(
                                                        text = description,
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        maxLines = 2,
                                                        overflow = TextOverflow.Ellipsis,
                                                    )
                                                }

                                                // Model ID
                                                Text(
                                                    text = item.id,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.outline,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                )
                                            }
                                        },
                                        trailingIcon = {
                                            val isFav = favoritesManager.isFavorite(item.id)
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(2.dp),
                                            ) {
                                                IconButton(
                                                    onClick = {
                                                        activeDetailModel = item.toDetailedInfo(isVietnamese)
                                                    },
                                                    modifier = Modifier.size(28.dp),
                                                ) {
                                                    Icon(
                                                        painter = painterResource(R.drawable.info),
                                                        contentDescription = stringResource(R.string.ai_model_view_description),
                                                        tint = MaterialTheme.colorScheme.primary,
                                                        modifier = Modifier.size(16.dp),
                                                    )
                                                }
                                                IconButton(
                                                    onClick = {
                                                        favoritesManager.toggleFavorite(item.id)
                                                        favVersion++
                                                    },
                                                    modifier = Modifier.size(28.dp),
                                                ) {
                                                    Icon(
                                                        painter = painterResource(if (isFav) R.drawable.star else R.drawable.favorite_border),
                                                        contentDescription = "Favorite",
                                                        tint = if (isFav) androidx.compose.ui.graphics.Color(0xFFFFC107) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                                                        modifier = Modifier.size(16.dp),
                                                    )
                                                }
                                                if (isSelected) {
                                                    Spacer(modifier = Modifier.width(2.dp))
                                                    Icon(
                                                        painter = painterResource(R.drawable.check),
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.primary,
                                                        modifier = Modifier.size(16.dp),
                                                    )
                                                }
                                            }
                                        },
                                        onClick = {
                                            onModelSelected(item.id)
                                            dropdownExpanded = false
                                            searchQuery = ""
                                        },
                                    )
                                }

                                if (filteredModels.size > 15) {
                                    HorizontalDivider()
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                text = stringResource(R.string.ai_deepinfra_view_more_models, filteredModels.size - 15),
                                                color = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.bodyMedium,
                                            )
                                        },
                                        leadingIcon = {
                                            Icon(
                                                painter = painterResource(R.drawable.search),
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(18.dp),
                                            )
                                        },
                                        onClick = {
                                            dropdownExpanded = false
                                            searchQuery = ""
                                            onShowAllModelsClick?.invoke()
                                        },
                                    )
                                }
                            }

                            if (onCustomModelClick != null) {
                                HorizontalDivider()
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = stringResource(R.string.ai_deepinfra_custom_id_prompt),
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Medium,
                                        )
                                    },
                                    leadingIcon = {
                                        Icon(
                                            painter = painterResource(R.drawable.edit),
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(18.dp),
                                        )
                                    },
                                    onClick = {
                                        dropdownExpanded = false
                                        searchQuery = ""
                                        onCustomModelClick()
                                    },
                                )
                            }
                        }
                    }

                    // Status & Provider quick-access footer
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f),
                        ) {
                            ProviderBadge(
                                modelId = activeModelObj?.id ?: selectedModel.ifBlank { DeepInfraDefaultModel },
                                providerName = activeModelObj?.providerName ?: "",
                                onClick = {
                                    val mId = activeModelObj?.id ?: selectedModel.ifBlank { DeepInfraDefaultModel }
                                    val pName = activeModelObj?.providerName ?: ""
                                    activeProviderInfo = mId to pName
                                },
                            )
                            Text(
                                text = stringResource(R.string.ai_deepinfra_realtime_label),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.ai_deepinfra_models_ready_count, activeModels?.allModels?.size ?: 0),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            softWrap = false,
                        )
                    }
                }
            }
        }
    }

    activeDetailModel?.let { detailModel ->
        ModelDetailExpandableModal(
            model = detailModel,
            isSelected = detailModel.id == selectedModel,
            onSelect = {
                onModelSelected(detailModel.id)
                dropdownExpanded = false
                searchQuery = ""
            },
            onDismiss = { activeDetailModel = null },
            benchmarkUtility = benchmarkUtility,
        )
    }

    activeProviderInfo?.let { (provModelId, provName) ->
        ProviderInfoModalDialog(
            modelIdOrProvider = provModelId,
            providerName = provName,
            onDismiss = { activeProviderInfo = null },
        )
    }
}

@Composable
private fun ModelSelectorShimmerSkeleton() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shimmer(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.7f)
                .height(28.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
        )
        Box(
            modifier = Modifier
                .fillMaxWidth(0.5f)
                .height(16.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
        )
    }
}
