/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */
package com.listrovia.music.ui.screens.settings

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import com.listrovia.music.LocalPlayerAwareWindowInsets
import com.listrovia.music.R
import com.listrovia.music.api.DeepInfraModelItem
import com.listrovia.music.api.DeepInfraModelManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class MoodOption(
    val id: String,
    val titleRes: Int,
    val iconRes: Int,
    val description: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiMoodPlaylistScreen(
    navController: NavController
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val modelManager = remember { DeepInfraModelManager(context = context) }

    var aiModels by remember { mutableStateOf<List<DeepInfraModelItem>>(emptyList()) }
    var selectedModel by remember { mutableStateOf<DeepInfraModelItem?>(null) }
    var selectedMood by remember { mutableStateOf("happy") }
    var isGenerating by remember { mutableStateOf(false) }
    var generatedTracks by remember { mutableStateOf<List<String>>(emptyList()) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    val successText = stringResource(R.string.playlist_generated_success)

    val moods = listOf(
        MoodOption("happy", R.string.mood_happy, R.drawable.star, "Upbeat rhythms and joyful melodies"),
        MoodOption("relaxed", R.string.mood_relaxed, R.drawable.sync, "Calm acoustic and ambient soundscapes"),
        MoodOption("energetic", R.string.mood_energetic, R.drawable.queue_music, "High tempo beats for training and cardio"),
        MoodOption("focus", R.string.mood_focus, R.drawable.search, "Instrumental lo-fi for productivity and study"),
        MoodOption("sad", R.string.mood_sad, R.drawable.person, "Deep emotional chords and reflections"),
        MoodOption("party", R.string.mood_party, R.drawable.star, "Dancefloor anthems and club hits")
    )

    LaunchedEffect(Unit) {
        scope.launch {
            try {
                val classified = modelManager.fetchModels()
                val models = classified.recommended
                aiModels = models
                if (models.isNotEmpty()) {
                    selectedModel = models.first()
                }
            } catch (_: Exception) {}
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.ai_mood_playlist_title)) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(painter = painterResource(R.drawable.arrow_back), contentDescription = null)
                    }
                }
            )
        },
        contentWindowInsets = LocalPlayerAwareWindowInsets.current
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = stringResource(R.string.ai_mood_playlist_desc),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Real-time Model Suggestion Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Real-time AI Model Engine (DeepInfra & Open Providers)",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = selectedModel?.name ?: selectedModel?.id ?: "Loading active model...",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (aiModels.isNotEmpty()) {
                        Text(
                            text = "${aiModels.size} models available for real-time inference",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Text(
                text = stringResource(R.string.select_mood),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            // Mood Selection Grid / List
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(moods) { mood ->
                    val isSelected = selectedMood == mood.id
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainer
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedMood = mood.id }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                painter = painterResource(mood.iconRes),
                                contentDescription = null,
                                tint = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(mood.titleRes),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = mood.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (isSelected) {
                                Icon(
                                    painter = painterResource(R.drawable.check),
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }

                if (generatedTracks.isNotEmpty()) {
                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Generated Playlist Tracks (${generatedTracks.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(generatedTracks) { track ->
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceContainerLow,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.queue_music),
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = track,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }

            if (isGenerating) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                Text(
                    text = stringResource(R.string.generating_ai_playlist),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (successMessage != null) {
                Text(
                    text = successMessage!!,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Button(
                onClick = {
                    scope.launch {
                        isGenerating = true
                        successMessage = null
                        generatedTracks = emptyList()

                        val activeModelId = selectedModel?.id ?: com.listrovia.music.constants.DeepInfraDefaultModel
                        val moodLabel = moods.firstOrNull { it.id == selectedMood }?.description ?: selectedMood
                        val promptSeed = listOf(
                            "Track 1 for $selectedMood mood ($moodLabel)",
                            "Track 2 for $selectedMood mood ($moodLabel)",
                            "Track 3 for $selectedMood mood ($moodLabel)",
                            "Track 4 for $selectedMood mood ($moodLabel)",
                            "Track 5 for $selectedMood mood ($moodLabel)",
                        ).joinToString("\n")

                        val streamSystemPrompt = """You are a real-time AI music curator. Output ONLY a valid JSON array of 5 real or creative song titles with artist names matching the requested mood (format: "Song Title - Artist"). Do not include explanations."""

                        val accumulator = StringBuilder()
                        var streamCompleted = false

                        try {
                            com.listrovia.music.api.OpenRouterStreamingService
                                .streamTranslation(
                                    text = promptSeed,
                                    targetLanguage = "English",
                                    apiKey = "",
                                    baseUrl = com.listrovia.music.constants.DeepInfraBaseUrl,
                                    model = activeModelId,
                                    mode = "Literal",
                                    customSystemPrompt = streamSystemPrompt,
                                    provider = "DeepInfra",
                                ).collect { chunk ->
                                    when (chunk) {
                                        is com.listrovia.music.api.OpenRouterStreamingService.StreamChunk.Content -> {
                                            accumulator.append(chunk.text)
                                            val partial = com.listrovia.music.lyrics.LyricsTranslationHelper
                                                .tryParsePartialTranslation(accumulator.toString(), 5)
                                            if (partial.isNotEmpty()) {
                                                generatedTracks = partial
                                            }
                                        }
                                        is com.listrovia.music.api.OpenRouterStreamingService.StreamChunk.Complete -> {
                                            if (chunk.translatedLines.isNotEmpty()) {
                                                generatedTracks = chunk.translatedLines
                                                streamCompleted = true
                                            }
                                        }
                                        is com.listrovia.music.api.OpenRouterStreamingService.StreamChunk.Error -> {
                                            successMessage = chunk.message
                                        }
                                    }
                                }
                        } catch (e: Exception) {
                            successMessage = e.localizedMessage ?: "API Error"
                        }

                        isGenerating = false
                        if (streamCompleted || generatedTracks.isNotEmpty()) {
                            successMessage = successText
                        }
                    }
                },
                enabled = !isGenerating,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(painter = painterResource(R.drawable.sync), contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.generate_playlist_btn),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
