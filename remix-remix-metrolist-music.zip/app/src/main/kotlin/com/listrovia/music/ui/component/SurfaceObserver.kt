/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.component

import android.content.Context
import android.hardware.display.DisplayManager
import android.view.Display
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import timber.log.Timber

/**
 * SurfaceObserver component that automatically detects external screen-recording,
 * screen-mirroring, or virtual display sessions, and overlays a secure blur layer
 * to protect user data during playback.
 */
@Composable
fun SurfaceObserver(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    var isScreenRecordingOrMirroring by remember { mutableStateOf(false) }

    DisposableEffect(context) {
        val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
        
        val listener = object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(displayId: Int) {
                checkDisplays(displayManager)
            }
            override fun onDisplayRemoved(displayId: Int) {
                checkDisplays(displayManager)
            }
            override fun onDisplayChanged(displayId: Int) {
                checkDisplays(displayManager)
            }

            private fun checkDisplays(dm: DisplayManager?) {
                if (dm == null) return
                try {
                    val displays = dm.displays
                    val mirroringDetected = displays.any { display ->
                        display.displayId != Display.DEFAULT_DISPLAY &&
                        (display.flags and Display.FLAG_PRESENTATION != 0 ||
                         display.name.contains("Virtual", ignoreCase = true) ||
                         display.name.contains("Cast", ignoreCase = true) ||
                         display.name.contains("Mirror", ignoreCase = true))
                    }
                    if (mirroringDetected != isScreenRecordingOrMirroring) {
                        isScreenRecordingOrMirroring = mirroringDetected
                        if (mirroringDetected) {
                            Timber.tag("SurfaceObserver").w("External screen recording or mirroring session detected! Activating privacy blur.")
                        }
                    }
                } catch (e: Exception) {
                    Timber.tag("SurfaceObserver").d("Error checking displays: ${e.message}")
                }
            }
        }

        displayManager?.registerDisplayListener(listener, null)
        try {
            val displays = displayManager?.displays
            val activeMirror = displays?.any { it.displayId != Display.DEFAULT_DISPLAY && it.flags and Display.FLAG_PRESENTATION != 0 } == true
            isScreenRecordingOrMirroring = activeMirror
        } catch (_: Exception) {}

        onDispose {
            displayManager?.unregisterDisplayListener(listener)
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        content()

        AnimatedVisibility(
            visible = isScreenRecordingOrMirroring,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.85f)),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    color = Color(0xFF1E293B),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Text(
                        text = "🔒 Privacy Shield Active\nScreen Recording or Mirroring Detected",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        }
    }
}
