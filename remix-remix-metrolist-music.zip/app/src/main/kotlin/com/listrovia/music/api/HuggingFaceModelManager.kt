/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.api

import android.content.Context
import com.listrovia.music.constants.HuggingFaceModelsUrl
import com.listrovia.music.db.AiModelCacheDatabase
import com.listrovia.music.db.entities.AiModelCacheEntity
import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.statement.bodyAsText
import io.ktor.http.isSuccess
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import timber.log.Timber
import java.io.File
import java.util.Locale
import java.util.concurrent.TimeUnit

data class HuggingFaceModelItem(
    val id: String,
    val name: String,
    val author: String = "huggingface",
    val description: String = "",
    val pipelineTag: String = "text-generation",
    val libraryName: String = "transformers",
    val downloads: Long = 0L,
    val likes: Int = 0,
    val trendingScore: Double = 0.0,
    val contextLength: Long = 131072L,
    val isInstructOrChat: Boolean = true,
    val isMultilingual: Boolean = true,
    val supportsReasoning: Boolean = false,
    val matchScore: Int = 90,
    val contextScore: Float = 0.88f,
    val lyricNuanceScore: Float = 0.92f,
    val hubPopularityScore: Float = 0.88f,
    val recommendationBadgeEn: String = "",
    val recommendationBadgeVi: String = "",
    val tags: List<String> = emptyList(),
) {
    val formattedContext: String
        get() = when {
            contextLength >= 1_048_576L -> "${contextLength / 1_048_576L}M"
            contextLength >= 1_000_000L -> "${contextLength / 1_000_000L}M"
            contextLength >= 1024L -> "${contextLength / 1024L}K"
            contextLength > 0L -> "$contextLength"
            else -> "128K"
        }

    val formattedDownloads: String
        get() = when {
            downloads >= 1_000_000L -> String.format(Locale.US, "%.1fM", downloads / 1_000_000.0)
            downloads >= 1_000L -> String.format(Locale.US, "%.1fK", downloads / 1_000.0)
            downloads > 0L -> "$downloads"
            else -> "Live"
        }

    val formattedLikes: String
        get() = when {
            likes >= 1_000 -> String.format(Locale.US, "%.1fK", likes / 1000.0)
            likes > 0 -> "$likes"
            else -> "Hub"
        }

    fun getRecommendationBadge(isVietnamese: Boolean): String {
        return if (isVietnamese) recommendationBadgeVi else recommendationBadgeEn
    }
}

data class HuggingFaceClassifiedModels(
    val recommended: List<HuggingFaceModelItem> = emptyList(),
    val trendingHub: List<HuggingFaceModelItem> = emptyList(),
    val openWeights: List<HuggingFaceModelItem> = emptyList(),
    val multilingualLyric: List<HuggingFaceModelItem> = emptyList(),
    val allModels: List<HuggingFaceModelItem> = emptyList(),
    val topSpotlightModel: HuggingFaceModelItem? = null,
    val fetchedAtMillis: Long = System.currentTimeMillis(),
)

/**
 * Real-time AI Model Discovery & Recommendation Engine for Hugging Face Hub
 * Endpoint: https://huggingface.co/api/models
 */
class HuggingFaceModelManager(
    cacheTTLMinutes: Long = 15L,
    private val context: Context? = null,
) {
    private val baseApiUrl = "https://huggingface.co/api/models"
    private val storageKey = "huggingface_models_realtime_v1"
    private val cacheTTL = cacheTTLMinutes * 60 * 1000L

    private var memoryCache: Pair<Long, HuggingFaceClassifiedModels>? = null
    private val fetchMutex = Mutex()

    private val ktorClient: HttpClient by lazy {
        HttpClient(OkHttp) {
            install(HttpTimeout) {
                requestTimeoutMillis = 20_000L
                connectTimeoutMillis = 15_000L
                socketTimeoutMillis = 20_000L
            }
            expectSuccess = false
        }
    }

    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    private fun isNetworkAvailable(): Boolean {
        val ctx = context ?: return true
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager ?: return false
        val activeNet = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(activeNet) ?: return false
        return caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    suspend fun fetchModels(
        forceRefresh: Boolean = false,
        apiKey: String = "",
    ): HuggingFaceClassifiedModels = withContext(Dispatchers.IO) {
        fetchMutex.withLock {
            val now = System.currentTimeMillis()
            val cached = memoryCache
            if (!forceRefresh && cached != null && (now - cached.first < cacheTTL) && cached.second.allModels.isNotEmpty()) {
                return@withLock cached.second
            }

            if (!isNetworkAvailable()) {
                return@withLock HuggingFaceClassifiedModels()
            }

            try {
                val cleanKey = apiKey.trim()
                val downloadsUrl = "$baseApiUrl?pipeline_tag=text-generation&sort=downloads&direction=-1&limit=60"
                val trendingUrl = "$baseApiUrl?pipeline_tag=text-generation&sort=trendingScore&direction=-1&limit=40"

                val primaryBody = try {
                    fetchFromUrlWithKtorOrOkHttp(downloadsUrl, cleanKey)
                } catch (queryErr: Exception) {
                    Timber.w(queryErr, "Filtered HuggingFace query failed, falling back to base $baseApiUrl")
                    fetchFromUrlWithKtorOrOkHttp(baseApiUrl, cleanKey)
                }

                val trendingBody = try {
                    fetchFromUrlWithKtorOrOkHttp(trendingUrl, cleanKey)
                } catch (_: Exception) {
                    ""
                }

                val parsedItems = mutableListOf<HuggingFaceModelItem>()
                val seenIds = mutableSetOf<String>()

                val primaryArray = parseRawModelsArray(primaryBody)
                for (i in 0 until primaryArray.length()) {
                    val obj = primaryArray.optJSONObject(i) ?: continue
                    val id = obj.optString("id", obj.optString("modelId", "")).trim()
                    if (id.isBlank() || !seenIds.add(id)) continue
                    parsedItems.add(parseHuggingFaceModelObject(obj, id, parsedItems.size))
                }

                if (trendingBody.isNotBlank()) {
                    val trendingArray = parseRawModelsArray(trendingBody)
                    for (i in 0 until trendingArray.length()) {
                        val obj = trendingArray.optJSONObject(i) ?: continue
                        val id = obj.optString("id", obj.optString("modelId", "")).trim()
                        if (id.isBlank() || !seenIds.add(id)) continue
                        parsedItems.add(parseHuggingFaceModelObject(obj, id, parsedItems.size))
                    }
                }

                if (parsedItems.isEmpty()) {
                    throw Exception("No valid models returned from https://huggingface.co/api/models")
                }

                val classified = classifyAndRecommend(parsedItems, now)
                memoryCache = Pair(now, classified)
                saveToLocalCache(classified)
                Timber.i("Successfully loaded ${classified.allModels.size} real-time models from https://huggingface.co/api/models")
                classified
            } catch (e: Exception) {
                Timber.w(e, "Live https://huggingface.co/api/models fetch failed, restoring from real API cache")
                loadFromLocalCache() ?: HuggingFaceClassifiedModels(fetchedAtMillis = now)
            }
        }
    }

    suspend fun searchModelsRealtime(
        searchQuery: String,
        apiKey: String = "",
    ): List<HuggingFaceModelItem> = withContext(Dispatchers.IO) {
        val trimmedQuery = searchQuery.trim()
        if (trimmedQuery.isBlank()) {
            return@withContext fetchModels(forceRefresh = false, apiKey = apiKey).allModels
        }
        try {
            val encoded = java.net.URLEncoder.encode(trimmedQuery, "UTF-8")
            val searchUrl = "$baseApiUrl?search=$encoded&pipeline_tag=text-generation&sort=downloads&direction=-1&limit=40"
            val body = fetchFromUrlWithKtorOrOkHttp(searchUrl, apiKey.trim())
            val arr = parseRawModelsArray(body)
            val results = mutableListOf<HuggingFaceModelItem>()
            val seen = mutableSetOf<String>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val id = obj.optString("id", obj.optString("modelId", "")).trim()
                if (id.isBlank() || !seen.add(id)) continue
                results.add(parseHuggingFaceModelObject(obj, id, i))
            }
            results
        } catch (e: Exception) {
            Timber.w(e, "Real-time HuggingFace search query failed for '$trimmedQuery'")
            val current = memoryCache?.second?.allModels.orEmpty()
            val q = trimmedQuery.lowercase()
            current.filter {
                it.id.lowercase().contains(q) ||
                    it.name.lowercase().contains(q) ||
                    it.author.lowercase().contains(q) ||
                    it.description.lowercase().contains(q)
            }
        }
    }

    private suspend fun fetchFromUrlWithKtorOrOkHttp(url: String, cleanKey: String): String {
        return try {
            val response = ktorClient.get(url) {
                header("User-Agent", "Mozilla/5.0 (Android; Listrovia Music/1.0)")
                header("Accept", "application/json")
                if (cleanKey.isNotBlank()) {
                    header("Authorization", "Bearer $cleanKey")
                }
            }
            if (!response.status.isSuccess()) {
                throw Exception("Ktor HTTP ${response.status.value} from HuggingFace")
            }
            val body = response.bodyAsText()
            if (body.isBlank()) throw Exception("Empty response body from HuggingFace")
            body
        } catch (ktorErr: Exception) {
            Timber.w(ktorErr, "Ktor request to HuggingFace failed, trying OkHttp fallback")
            val reqBuilder = Request.Builder()
                .url(url)
                .addHeader("User-Agent", "Mozilla/5.0 (Android; Listrovia Music/1.0)")
                .addHeader("Accept", "application/json")
                .get()
            if (cleanKey.isNotBlank()) {
                reqBuilder.addHeader("Authorization", "Bearer $cleanKey")
            }
            val response = okHttpClient.newCall(reqBuilder.build()).execute()
            if (!response.isSuccessful) {
                throw Exception("OkHttp HTTP ${response.code} from HuggingFace")
            }
            response.body?.string() ?: throw Exception("Empty OkHttp body from HuggingFace")
        }
    }

    private fun parseRawModelsArray(body: String): JSONArray {
        val trimmed = body.trim()
        return if (trimmed.startsWith("[")) {
            JSONArray(trimmed)
        } else {
            val root = JSONObject(trimmed)
            root.optJSONArray("models")
                ?: root.optJSONArray("data")
                ?: JSONArray()
        }
    }

    private fun parseHuggingFaceModelObject(
        obj: JSONObject,
        id: String,
        index: Int,
    ): HuggingFaceModelItem {
        val idLower = id.lowercase()
        val author = obj.optString("author", id.substringBefore("/", "huggingface")).ifBlank {
            id.substringBefore("/", "huggingface")
        }
        val rawName = id.substringAfter("/", id)
        val cleanName = rawName
            .replace("-", " ")
            .replace("_", " ")
            .split(" ")
            .filter { it.isNotBlank() }
            .joinToString(" ") { word ->
                if (word.length <= 3 && word.any { it.isDigit() }) {
                    word.uppercase()
                } else {
                    word.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
                }
            }
            .ifBlank { id }

        val pipelineTag = obj.optString("pipeline_tag", "text-generation").ifBlank { "text-generation" }
        val libraryName = obj.optString("library_name", "transformers").ifBlank { "transformers" }
        val downloads = obj.optLong("downloads", 0L).coerceAtLeast(0L)
        val likes = obj.optInt("likes", 0).coerceAtLeast(0)
        val trendingScore = obj.optDouble("trendingScore", 0.0).let { if (it.isNaN()) 0.0 else it }

        val tagsList = mutableListOf<String>()
        val tagsArr = obj.optJSONArray("tags")
        if (tagsArr != null) {
            for (t in 0 until minOf(tagsArr.length(), 15)) {
                val tag = tagsArr.optString(t, "").trim()
                if (tag.isNotBlank()) tagsList.add(tag)
            }
        }
        val tagsJoined = tagsList.joinToString(" ").lowercase()

        val isInstructOrChat = idLower.contains("instruct") ||
            idLower.contains("chat") ||
            idLower.contains("-it") ||
            tagsJoined.contains("conversational") ||
            tagsJoined.contains("chat")

        val supportsReasoning = idLower.contains("r1") ||
            idLower.contains("qwq") ||
            idLower.contains("reason") ||
            idLower.contains("think")

        val isMultilingual = idLower.contains("qwen") ||
            idLower.contains("llama-3") ||
            idLower.contains("gemma") ||
            idLower.contains("mistral") ||
            idLower.contains("deepseek") ||
            idLower.contains("aya") ||
            tagsJoined.contains("multilingual") ||
            tagsJoined.contains("vi") ||
            tagsJoined.contains("translation")

        val contextLength = when {
            idLower.contains("1m") -> 1_048_576L
            idLower.contains("qwen2.5") || idLower.contains("llama-3.1") || idLower.contains("llama-3.3") || idLower.contains("deepseek") -> 131_072L
            idLower.contains("mistral") || idLower.contains("mixtral") -> 65_536L
            idLower.contains("gemma") -> 32_768L
            else -> 32_768L
        }

        val contextScore = when {
            contextLength >= 131_072L -> 0.96f
            contextLength >= 65_536L -> 0.88f
            else -> 0.78f
        }

        val lyricNuanceScore = when {
            isInstructOrChat && isMultilingual -> 0.96f
            isInstructOrChat -> 0.91f
            isMultilingual -> 0.87f
            else -> 0.82f
        }

        val hubPopularityScore = when {
            downloads >= 1_000_000L || likes >= 1000 -> 0.97f
            downloads >= 200_000L || likes >= 300 -> 0.91f
            downloads >= 50_000L || likes >= 100 -> 0.86f
            else -> (0.84f - (index * 0.004f)).coerceIn(0.72f, 0.85f)
        }

        val computedMatch = (
            (lyricNuanceScore * 45f) +
                (hubPopularityScore * 30f) +
                (contextScore * 25f) +
                (if (isInstructOrChat) 3f else 0f)
            ).toInt().coerceIn(76, 99)

        val (badgeEn, badgeVi) = when {
            supportsReasoning -> "Deep Reasoning & Context" to "Suy luận Sâu & Ngữ cảnh"
            downloads >= 1_000_000L || trendingScore >= 90.0 -> "Trending Hub Leader" to "Dẫn đầu Thịnh hành Hub"
            isMultilingual -> "Top Multilingual & Lyrics" to "Đa ngôn ngữ & Lời nhạc"
            isInstructOrChat -> "Conversational Specialist" to "Chuyên gia Hội thoại"
            else -> "Hugging Face Hub Verified" to "Xác thực Hugging Face Hub"
        }

        val description = obj.optString("description", "").ifBlank {
            "Hugging Face Hub ($pipelineTag • $libraryName) by $author. Downloads: $downloads, Likes: $likes."
        }

        return HuggingFaceModelItem(
            id = id,
            name = cleanName,
            author = author,
            description = description,
            pipelineTag = pipelineTag,
            libraryName = libraryName,
            downloads = downloads,
            likes = likes,
            trendingScore = trendingScore,
            contextLength = contextLength,
            isInstructOrChat = isInstructOrChat,
            isMultilingual = isMultilingual,
            supportsReasoning = supportsReasoning,
            matchScore = computedMatch,
            contextScore = contextScore,
            lyricNuanceScore = lyricNuanceScore,
            hubPopularityScore = hubPopularityScore,
            recommendationBadgeEn = badgeEn,
            recommendationBadgeVi = badgeVi,
            tags = tagsList,
        )
    }

    private fun classifyAndRecommend(
        items: List<HuggingFaceModelItem>,
        fetchedAt: Long,
    ): HuggingFaceClassifiedModels {
        val sortedByMatch = items.sortedWith(
            compareByDescending<HuggingFaceModelItem> { it.matchScore }
                .thenByDescending { it.downloads }
                .thenByDescending { it.likes },
        )

        val recommended = sortedByMatch.filter { it.isInstructOrChat || it.matchScore >= 88 }.ifEmpty { sortedByMatch }
        val trendingHub = items.sortedWith(
            compareByDescending<HuggingFaceModelItem> { it.trendingScore }
                .thenByDescending { it.likes }
                .thenByDescending { it.downloads },
        )
        val openWeights = sortedByMatch.filter {
            val lower = it.id.lowercase()
            lower.contains("qwen") || lower.contains("llama") || lower.contains("deepseek") ||
                lower.contains("mistral") || lower.contains("gemma") || lower.contains("phi")
        }.ifEmpty { sortedByMatch }
        val multilingualLyric = sortedByMatch.filter { it.isMultilingual }.ifEmpty { sortedByMatch }

        return HuggingFaceClassifiedModels(
            recommended = recommended,
            trendingHub = trendingHub,
            openWeights = openWeights,
            multilingualLyric = multilingualLyric,
            allModels = sortedByMatch,
            topSpotlightModel = recommended.firstOrNull() ?: sortedByMatch.firstOrNull(),
            fetchedAtMillis = fetchedAt,
        )
    }

    suspend fun getSmartRealtimeRecommendation(
        forceRefresh: Boolean = false,
        apiKey: String = "",
    ): HuggingFaceModelItem? {
        val classified = fetchModels(forceRefresh = forceRefresh, apiKey = apiKey)
        return classified.topSpotlightModel ?: classified.recommended.firstOrNull() ?: classified.allModels.firstOrNull()
    }

    private suspend fun saveToLocalCache(classified: HuggingFaceClassifiedModels) {
        val ctx = context ?: return
        try {
            val root = JSONObject()
            root.put("fetchedAtMillis", classified.fetchedAtMillis)
            val arr = JSONArray()
            for (item in classified.allModels) {
                arr.put(
                    JSONObject().apply {
                        put("id", item.id)
                        put("name", item.name)
                        put("author", item.author)
                        put("description", item.description)
                        put("pipelineTag", item.pipelineTag)
                        put("libraryName", item.libraryName)
                        put("downloads", item.downloads)
                        put("likes", item.likes)
                        put("trendingScore", item.trendingScore)
                        put("contextLength", item.contextLength)
                        put("isInstructOrChat", item.isInstructOrChat)
                        put("isMultilingual", item.isMultilingual)
                        put("supportsReasoning", item.supportsReasoning)
                        put("matchScore", item.matchScore)
                        put("contextScore", item.contextScore.toDouble())
                        put("lyricNuanceScore", item.lyricNuanceScore.toDouble())
                        put("hubPopularityScore", item.hubPopularityScore.toDouble())
                        put("recommendationBadgeEn", item.recommendationBadgeEn)
                        put("recommendationBadgeVi", item.recommendationBadgeVi)
                    },
                )
            }
            root.put("models", arr)
            val file = File(ctx.filesDir, "$storageKey.json")
            file.writeText(root.toString())

            val entities = classified.allModels.map { item ->
                AiModelCacheEntity(
                    id = item.id,
                    provider = "HuggingFace",
                    name = item.name,
                    providerName = item.author,
                    tier = if (item.matchScore >= 90) "Recommended" else "Hub",
                    sourceCategory = "VERIFIED",
                    healthStatus = "HEALTHY",
                    contextLength = item.contextLength,
                    pricingBadge = "↓ ${item.formattedDownloads} • ♥ ${item.formattedLikes}",
                    description = item.description,
                    cachedAt = classified.fetchedAtMillis,
                )
            }
            AiModelCacheDatabase.getInstance(ctx).aiModelCacheDao().insertModels(entities)
        } catch (e: Exception) {
            Timber.w(e, "Failed to persist HuggingFace cache")
        }
    }

    private suspend fun loadFromLocalCache(): HuggingFaceClassifiedModels? {
        val ctx = context ?: return null
        try {
            val file = File(ctx.filesDir, "$storageKey.json")
            if (file.exists()) {
                val root = JSONObject(file.readText())
                val fetchedAt = root.optLong("fetchedAtMillis", System.currentTimeMillis())
                val arr = root.optJSONArray("models")
                if (arr != null && arr.length() > 0) {
                    val items = mutableListOf<HuggingFaceModelItem>()
                    for (i in 0 until arr.length()) {
                        val obj = arr.optJSONObject(i) ?: continue
                        items.add(
                            HuggingFaceModelItem(
                                id = obj.optString("id"),
                                name = obj.optString("name"),
                                author = obj.optString("author", "huggingface"),
                                description = obj.optString("description"),
                                pipelineTag = obj.optString("pipelineTag", "text-generation"),
                                libraryName = obj.optString("libraryName", "transformers"),
                                downloads = obj.optLong("downloads", 0L),
                                likes = obj.optInt("likes", 0),
                                trendingScore = obj.optDouble("trendingScore", 0.0),
                                contextLength = obj.optLong("contextLength", 131_072L),
                                isInstructOrChat = obj.optBoolean("isInstructOrChat", true),
                                isMultilingual = obj.optBoolean("isMultilingual", true),
                                supportsReasoning = obj.optBoolean("supportsReasoning", false),
                                matchScore = obj.optInt("matchScore", 90),
                                contextScore = obj.optDouble("contextScore", 0.88).toFloat(),
                                lyricNuanceScore = obj.optDouble("lyricNuanceScore", 0.92).toFloat(),
                                hubPopularityScore = obj.optDouble("hubPopularityScore", 0.88).toFloat(),
                                recommendationBadgeEn = obj.optString("recommendationBadgeEn"),
                                recommendationBadgeVi = obj.optString("recommendationBadgeVi"),
                            ),
                        )
                    }
                    if (items.isNotEmpty()) {
                        return classifyAndRecommend(items, fetchedAt)
                    }
                }
            }
        } catch (e: Exception) {
            Timber.w(e, "Failed to read HuggingFace local cache")
        }

        return try {
            val dao = AiModelCacheDatabase.getInstance(ctx).aiModelCacheDao()
            val roomEntities = dao.getModelsByProvider("HuggingFace")
            if (roomEntities.isNotEmpty()) {
                val items = roomEntities.mapIndexed { idx, entity ->
                    val obj = JSONObject().apply {
                        put("id", entity.id)
                        put("author", entity.providerName)
                        put("description", entity.description)
                    }
                    parseHuggingFaceModelObject(obj, entity.id, idx)
                }
                classifyAndRecommend(items, roomEntities.first().cachedAt)
            } else {
                null
            }
        } catch (e: Exception) {
            Timber.w(e, "Failed to read HuggingFace Room cache")
            null
        }
    }

    companion object {
        @Volatile
        private var instance: HuggingFaceModelManager? = null

        fun getInstance(context: Context? = null, cacheTTLMinutes: Long = 15L): HuggingFaceModelManager {
            return instance ?: synchronized(this) {
                instance ?: HuggingFaceModelManager(cacheTTLMinutes, context?.applicationContext).also {
                    instance = it
                }
            }
        }
    }
}
