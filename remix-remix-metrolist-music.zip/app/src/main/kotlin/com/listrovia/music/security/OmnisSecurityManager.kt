/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.security

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.UiModeManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.*
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import com.listrovia.music.R
import com.listrovia.music.ui.screens.OmnisSecurityBlockActivity
import timber.log.Timber
import java.io.BufferedReader
import java.io.File
import java.io.IOException
import java.io.InputStreamReader
import java.security.MessageDigest
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.zip.ZipFile

/**
 * OmnisSecurityManager: Advanced Tamper & Intrusion Protection 2026.
 * Distinguishes legitimate app creators and authorized owners from unauthorized intruders,
 * enforcing security protection strictly when actual tampering or malicious interference occurs.
 */
object OmnisSecurityManager {
    private const val TAG = "OmnisSecurity"
    private const val AUTHORIZED_PACKAGE = "com.listrovia.music"
    private const val PREF_NAME = "omnis_security_prefs"
    private const val KEY_BASELINE_SIGNATURE = "baseline_apk_signature_hash"

    private val securityExecutor = Executors.newScheduledThreadPool(1)
    private var isInitialized = false

    fun startRealTimeIntelligence(context: Context) {
        if (isInitialized) return
        isInitialized = true

        val appContext = context.applicationContext
        securityExecutor.scheduleWithFixedDelay({
            try {
                if (checkSecurityViolations(appContext) != null) {
                    Timber.tag(TAG).w("Security violation verified! Triggering security blockade.")
                    triggerSecurityBlockade(appContext)
                }
            } catch (e: Exception) {
                Timber.tag(TAG).e(e, "Error in intelligence loop")
            }
        }, 0, 5, TimeUnit.SECONDS)

        securityExecutor.scheduleWithFixedDelay({
            activateAudioShield(appContext)
        }, 0, 15, TimeUnit.SECONDS)
    }

    fun checkThreatsAndEnforce(context: Context): Boolean {
        return try {
            activateAudioShield(context)
            if (checkSecurityViolations(context) != null) {
                triggerSecurityBlockade(context)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Error in checkThreatsAndEnforce")
            false
        }
    }

    private fun triggerSecurityBlockade(context: Context) {
        try {
            val intent = Intent(context, OmnisSecurityBlockActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to launch OmnisSecurityBlockActivity")
        }
    }

    /**
     * Kiểm tra và trả về chuỗi ID tài nguyên được dịch của vi phạm bảo mật,
     * đồng thời phân biệt chính xác nhà sáng tạo / chủ sở hữu hợp pháp.
     */
    fun checkSecurityViolations(context: Context): String? {
        val isOriginal = isOriginalPackage(context)
        val isOwner = isOriginal && isSignatureValid(context)

        if (isNonMobileHardwareDetected(context)) return context.getString(R.string.violation_hardware_restriction)
        if (isDeveloperOptionsEnabled(context)) return context.getString(R.string.violation_developer_options)
        
        if (context.packageName != AUTHORIZED_PACKAGE || isManifestTampered(context) || isManifestStructuralTampered(context)) {
            return context.getString(R.string.violation_identity_breach)
        }
        
        if (isClassesDexTampered(context)) return context.getString(R.string.violation_logic_tampered)
        if (isResourceModified(context)) return context.getString(R.string.violation_resource_breach)
        
        if (isRemoteControlActive(context)) return context.getString(R.string.violation_remote_exploit)
        if (isMicrophoneInUse(context)) return context.getString(R.string.violation_audio_surveillance)
        if (isHackerToolsDetected() || isDebugging() || isAppCloned(context)) {
            return context.getString(R.string.violation_hacker_tools)
        }
        if (isWifiDebuggingEnabled(context)) return context.getString(R.string.violation_wireless_debugging)

        if (!isOwner) {
            if (isRooted() || isEmulatorOrVirtualMachine()) return context.getString(R.string.violation_unsecure_env)
            if (isCustomROMDetected() || isBootloaderUnlocked()) return context.getString(R.string.violation_hardware_breach)
        }

        return null
    }

    fun isOriginalPackage(context: Context): Boolean {
        return try {
            context.packageName == AUTHORIZED_PACKAGE
        } catch (_: Exception) {
            false
        }
    }

    fun isNonMobileHardwareDetected(context: Context): Boolean {
        return try {
            val uiModeManager = context.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
            val isTV = uiModeManager?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION
            val pm = context.packageManager
            val isMissingPhoneFeatures = !pm.hasSystemFeature(PackageManager.FEATURE_TELEPHONY) &&
                                         !pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN)
            val isPC = pm.hasSystemFeature("android.hardware.type.pc") ||
                       Build.DEVICE.contains("arc") || Build.BRAND.contains("chromium")
            val model = Build.MODEL.lowercase()
            val isBox = model.contains("tvbox") || model.contains("smarttv") || model.contains("mibox")
            isTV || isPC || isBox || (isMissingPhoneFeatures && !pm.hasSystemFeature(PackageManager.FEATURE_CAMERA))
        } catch (_: Exception) { false }
    }

    fun isDeveloperOptionsEnabled(context: Context): Boolean {
        return try {
            val devOptions = Settings.Global.getInt(
                context.contentResolver,
                Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0
            ) != 0
            val adbEnabled = Settings.Global.getInt(
                context.contentResolver,
                Settings.Global.ADB_ENABLED, 0
            ) != 0
            devOptions || adbEnabled
        } catch (e: Exception) { false }
    }

    fun isClassesDexTampered(context: Context): Boolean {
        return try {
            val ai = context.applicationInfo
            val zf = ZipFile(File(ai.sourceDir))
            zf.getEntry("classes.dex") ?: return true
            val hasUnauthorizedPayload = zf.getEntry("assets/bin/Data/Managed") != null || zf.getEntry("re75") != null
            hasUnauthorizedPayload
        } catch (e: Exception) { false }
    }

    fun isManifestStructuralTampered(context: Context): Boolean {
        return try {
            val info = context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_PERMISSIONS or PackageManager.GET_ACTIVITIES)
            (info.requestedPermissions?.size ?: 0 > 70 || info.activities?.size ?: 0 > 90)
        } catch (e: Exception) { false }
    }

    fun isManifestTampered(context: Context): Boolean = !isOriginalPackage(context) || isManifestStructuralTampered(context)

    fun isResourceModified(context: Context): Boolean = !isSignatureValid(context)

    fun isSignatureValid(context: Context): Boolean {
        return try {
            val packageName = context.packageName
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val currentSignatureHash = getApkSignatureHash(context, packageName) ?: return true

            val baselineHash = prefs.getString(KEY_BASELINE_SIGNATURE, null)
            if (baselineHash == null) {
                prefs.edit().putString(KEY_BASELINE_SIGNATURE, currentSignatureHash).apply()
                return true
            }

            baselineHash == currentSignatureHash
        } catch (e: Exception) {
            true
        }
    }

    private fun getApkSignatureHash(context: Context, packageName: String): String? {
        try {
            val pm = context.packageManager
            val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val pkgInfo = pm.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                pkgInfo.signingInfo?.let { signingInfo ->
                    if (signingInfo.hasMultipleSigners()) {
                        signingInfo.apkContentsSigners
                    } else {
                        signingInfo.signingCertificateHistory
                    }
                }
            } else {
                @Suppress("DEPRECATION")
                val pkgInfo = pm.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
                pkgInfo.signatures
            }

            if (signatures != null && signatures.isNotEmpty()) {
                val cert = signatures[0].toByteArray()
                val md = MessageDigest.getInstance("SHA-256")
                val digest = md.digest(cert)
                return digest.joinToString("") { "%02x".format(it) }
            }
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to compute APK signature hash")
        }
        return null
    }

    fun isRemoteControlActive(context: Context): Boolean {
        return try {
            val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager ?: return false
            val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            enabledServices.any { service ->
                val pkg = service.resolveInfo.serviceInfo.packageName
                !pkg.contains("com.google.android.gms") &&
                (service.capabilities and AccessibilityServiceInfo.CAPABILITY_CAN_RETRIEVE_WINDOW_CONTENT) != 0
            }
        } catch (e: Exception) { false }
    }

    fun isMicrophoneInUse(context: Context): Boolean {
        return try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return false
            am.mode == AudioManager.MODE_IN_COMMUNICATION ||
            (am.isMicrophoneMute.not() && am.mode != AudioManager.MODE_NORMAL)
        } catch (e: Exception) { false }
    }

    fun isHackerToolsDetected(): Boolean {
        var reader: BufferedReader? = null
        try {
            val mapsFile = File("/proc/self/maps")
            if (!mapsFile.exists()) return false

            reader = BufferedReader(InputStreamReader(mapsFile.inputStream()))
            var line: String? = reader.readLine()
            val forbiddenKeywords = listOf(
                "frida", "gadget", "xposed", "cheatengine", "substrate",
                "shadowhook", "cydia", "libsubstrate", "libxposed", "libfrida"
            )

            while (line != null) {
                val lowerLine = line.lowercase(Locale.ROOT)
                for (keyword in forbiddenKeywords) {
                    if (lowerLine.contains(keyword)) return true
                }
                line = reader.readLine()
            }
        } catch (_: Exception) {
        } finally {
            try { reader?.close() } catch (_: IOException) {}
        }
        return false
    }

    fun isDebugging(): Boolean = Debug.isDebuggerConnected()

    fun isAppCloned(context: Context): Boolean {
        val path = context.filesDir.absolutePath
        return path.contains("999") || path.contains("101") || !path.startsWith("/data/user/0/")
    }

    fun isWifiDebuggingEnabled(context: Context): Boolean = try {
        Settings.Global.getInt(context.contentResolver, "adb_wifi_enabled", 0) != 0
    } catch (e: Exception) { false }

    fun isRooted(): Boolean {
        val paths = arrayOf("/system/bin/su", "/system/xbin/su", "/sbin/su", "/data/local/xbin/su", "/system/app/Superuser.apk")
        return paths.any { File(it).exists() }
    }

    fun isEmulatorOrVirtualMachine(): Boolean {
        val finger = Build.FINGERPRINT
        val model = Build.MODEL.lowercase()
        val hardware = Build.HARDWARE.lowercase()
        return (finger.startsWith("generic") || model.contains("emulator") ||
                hardware.contains("goldfish") || hardware.contains("ranchu") ||
                model.contains("sdk_gphone") || Build.PRODUCT.contains("sdk_google") ||
                Build.MANUFACTURER.contains("Genymotion"))
    }

    fun isCustomROMDetected(): Boolean = Build.TAGS?.contains("test-keys") ?: false || Build.HOST.lowercase().contains("ubuntu")

    fun isBootloaderUnlocked(): Boolean = Build.BOOTLOADER.lowercase().contains("unlock") || Build.VERSION.INCREMENTAL.lowercase().contains("test-keys")

    fun activateAudioShield(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
                val focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .build()
                audioManager.requestAudioFocus(focusRequest)
            }
        } catch (_: Exception) {}
    }
}
