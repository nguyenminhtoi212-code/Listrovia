/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.security

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import com.listrovia.music.ui.screens.OmnisSecurityBlockActivity
import timber.log.Timber
import java.io.BufferedReader
import java.io.File
import java.io.IOException
import java.io.InputStreamReader
import java.security.MessageDigest
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.zip.ZipFile

/**
 * OmnisSecurityManager: Advanced Tamper & Intrusion Protection 2026.
 * Ensures legitimate creators and users experience normal app usage without false positives,
 * blocking execution strictly when unauthorized APK modification, repackaging, manifest tampering,
 * or active memory hooking (Frida/injection) is verified.
 */
object OmnisSecurityManager {
    private const val TAG = "OmnisSecurity"
    private const val EXPECTED_PACKAGE_NAME = "com.listrovia.music"
    private const val PREF_NAME = "omnis_security_prefs"
    private const val KEY_BASELINE_SIGNATURE = "baseline_apk_signature_hash"

    private val securityExecutor = Executors.newScheduledThreadPool(1)
    private var isInitialized = false

    fun startRealTimeIntelligence(context: Context) {
        if (isInitialized) return
        isInitialized = true

        val appContext = context.applicationContext
        securityExecutor.scheduleWithFixedDelay({
            try {
                if (isActualIntrusionDetected(appContext)) {
                    Timber.tag(TAG).w("Unauthorized APK tampering / intrusion detected! Enforcing security block.")
                    triggerSecurityBlockade(appContext)
                }
            } catch (e: Exception) {
                Timber.tag(TAG).e(e, "Error in intelligence loop")
            }
        }, 0, 5, TimeUnit.SECONDS)

        securityExecutor.scheduleWithFixedDelay({
            activateAudioShield(appContext)
        }, 0, 15, TimeUnit.SECONDS)
    }

    fun checkThreatsAndEnforce(context: Context): Boolean {
        return try {
            activateAudioShield(context)
            if (isActualIntrusionDetected(context)) {
                triggerSecurityBlockade(context)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Error in checkThreatsAndEnforce")
            false
        }
    }

    private fun triggerSecurityBlockade(context: Context) {
        try {
            val intent = Intent(context, OmnisSecurityBlockActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to launch OmnisSecurityBlockActivity")
        }
    }

    /**
     * Strict Intrusion & Tamper Detection:
     * Only triggers when actual malicious code modification, signature repackaging, manifest alteration,
     * or active memory injection (Frida/hooking) is confirmed. Legitimate creator environments are preserved.
     */
    fun isActualIntrusionDetected(context: Context): Boolean {
        return isClassesDexTampered(context) ||
               isResourceModified(context) ||
               isManifestTampered(context) ||
               isHackerToolsDetected()
    }

    fun isClassesDexTampered(context: Context): Boolean {
        return try {
            val ai = context.applicationInfo
            val zf = ZipFile(File(ai.sourceDir))
            val dexEntry = zf.getEntry("classes.dex") ?: return true
            val hasUnauthorizedPayload = zf.getEntry("assets/bin/Data/Managed") != null || zf.getEntry("re75") != null
            hasUnauthorizedPayload
        } catch (e: Exception) { false }
    }

    fun isManifestStructuralTampered(context: Context): Boolean {
        return try {
            val info = context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_PERMISSIONS or PackageManager.GET_ACTIVITIES)
            (info.requestedPermissions?.size ?: 0 > 60 || info.activities?.size ?: 0 > 80)
        } catch (e: Exception) { false }
    }

    fun isSignatureValid(context: Context): Boolean {
        return try {
            val packageName = context.packageName
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val currentSignatureHash = getApkSignatureHash(context, packageName) ?: return true

            val baselineHash = prefs.getString(KEY_BASELINE_SIGNATURE, null)
            if (baselineHash == null) {
                prefs.edit().putString(KEY_BASELINE_SIGNATURE, currentSignatureHash).apply()
                Timber.tag(TAG).d("Omnis Security: Baseline signature established successfully.")
                return true
            }

            baselineHash == currentSignatureHash
        } catch (e: Exception) {
            true
        }
    }

    private fun getApkSignatureHash(context: Context, packageName: String): String? {
        try {
            val pm = context.packageManager
            val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val pkgInfo = pm.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                pkgInfo.signingInfo?.let { signingInfo ->
                    if (signingInfo.hasMultipleSigners()) {
                        signingInfo.apkContentsSigners
                    } else {
                        signingInfo.signingCertificateHistory
                    }
                }
            } else {
                @Suppress("DEPRECATION")
                val pkgInfo = pm.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
                pkgInfo.signatures
            }

            if (signatures != null && signatures.isNotEmpty()) {
                val cert = signatures[0].toByteArray()
                val md = MessageDigest.getInstance("SHA-256")
                val digest = md.digest(cert)
                return digest.joinToString("") { "%02x".format(it) }
            }
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to compute APK signature hash")
        }
        return null
    }

    fun isHackerToolsDetected(): Boolean {
        var reader: BufferedReader? = null
        try {
            val mapsFile = File("/proc/self/maps")
            if (!mapsFile.exists()) return false

            reader = BufferedReader(InputStreamReader(mapsFile.inputStream()))
            var line: String? = reader.readLine()
            val forbiddenKeywords = listOf(
                "frida", "gadget", "xposed", "cheatengine", "substrate",
                "shadowhook", "cydia", "libsubstrate", "libxposed", "libfrida"
            )

            while (line != null) {
                val lowerLine = line.lowercase(Locale.ROOT)
                for (keyword in forbiddenKeywords) {
                    if (lowerLine.contains(keyword)) {
                        Timber.tag(TAG).w("TAMPER DETECTED: Memory hook framework detected: '$keyword'")
                        return true
                    }
                }
                line = reader.readLine()
            }
        } catch (e: Exception) {
            // Ignored on standard environments
        } finally {
            try {
                reader?.close()
            } catch (_: IOException) {}
        }
        return false
    }

    fun isOriginalPackage(context: Context): Boolean = context.packageName == EXPECTED_PACKAGE_NAME

    fun isManifestTampered(context: Context): Boolean = !isOriginalPackage(context) || isManifestStructuralTampered(context)

    fun isResourceModified(context: Context): Boolean = !isSignatureValid(context)

    fun activateAudioShield(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
                val focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .build()
                audioManager.requestAudioFocus(focusRequest)
            }
        } catch (e: Exception) {
            Timber.tag(TAG).d("AudioShield note: ${e.message}")
        }
    }
}
