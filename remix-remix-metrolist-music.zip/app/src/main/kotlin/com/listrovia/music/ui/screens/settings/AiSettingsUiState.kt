package com.listrovia.music.ui.screens.settings

data class AiSettingsUiState(
    val showProviderDialog: Boolean = false,
    val showProviderHelpDialog: Boolean = false,
    val selectedProviderForDetail: String? = null,
    // ... other dialog states
)
