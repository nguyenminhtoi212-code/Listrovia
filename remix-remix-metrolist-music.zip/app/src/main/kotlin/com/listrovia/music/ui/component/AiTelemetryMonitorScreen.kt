/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.component

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.listrovia.music.R
import com.listrovia.music.api.AiLimitManager
import com.listrovia.music.api.AiLimitState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Recharts-style Visual Telemetry Monitoring Screen for Real-Time AI Model Usage,
 * Token Consumption, and Scheduled Reset Countdowns.
 * Designed with zero layout distortion geometry.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiTelemetryMonitorScreen(
    onNavigateUp: () -> Unit,
) {
    val context = LocalContext.current
    val limitState by AiLimitManager.getAiLimitState(context).collectAsStateWithLifecycle(initialValue = AiLimitState())
    val coroutineScope = rememberCoroutineScope()
    val isVietnamese = remember { Locale.getDefault().language == "vi" }

    var currentTime by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000L)
            currentTime = System.currentTimeMillis()
        }
    }

    val timeLeftMillis = (limitState.resetTimestamp - currentTime).coerceAtLeast(0L)
    val hours = TimeUnit.MILLISECONDS.toHours(timeLeftMillis)
    val minutes = TimeUnit.MILLISECONDS.toMinutes(timeLeftMillis) % 60
    val seconds = TimeUnit.MILLISECONDS.toSeconds(timeLeftMillis) % 60
    val countdownFormatted = String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)

    val animatedProgress by animateFloatAsState(
        targetValue = limitState.usagePercentage,
        animationSpec = tween(durationMillis = 900, easing = FastOutSlowInEasing),
        label = "usageAnim"
    )

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            TopAppBar(
                title = { Text(text = stringResource(R.string.ai_telemetry_monitor_title)) },
                navigationIcon = {
                    IconButton(onClick = onNavigateUp) {
                        Icon(
                            painter = painterResource(R.drawable.arrow_back),
                            contentDescription = null,
                        )
                    }
                },
            )

            // Status Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                ),
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        text = if (isVietnamese) "TRẠNG THÁI HẠN MỨC TOKEN AI" else "AI TOKEN QUOTA STATUS",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                    Text(
                        text = stringResource(R.string.ai_tokens_used_label, limitState.tokensUsed, limitState.tokenQuota),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                    LinearProgressIndicator(
                        progress = { animatedProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(CircleShape),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant,
                    )
                }
            }

            // Recharts-style Telemetry Chart Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = if (isVietnamese) "Biểu đồ tiêu thụ token thời gian thực" else "Real-Time Token Consumption Curve",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                        )
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                        ) {
                            Text(
                                text = "Recharts Live",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            )
                        }
                    }

                    // Canvas Chart (Recharts equivalent for Jetpack Compose)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(top = 8.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        val primaryColor = MaterialTheme.colorScheme.primary
                        val surfaceVariantColor = MaterialTheme.colorScheme.surfaceVariant
                        val points = remember(limitState.tokensUsed) {
                            listOf(0.2f, 0.4f, 0.35f, 0.6f, 0.5f, 0.75f, limitState.usagePercentage)
                        }

                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height
                            val stepX = w / (points.size - 1).coerceAtLeast(1)

                            val path = Path()
                            val fillPath = Path()
                            fillPath.moveTo(0f, h)

                            points.forEachIndexed { idx, p ->
                                val x = idx * stepX
                                val y = h - (p * h * 0.85f) - (h * 0.05f)
                                if (idx == 0) {
                                    path.moveTo(x, y)
                                    fillPath.lineTo(x, y)
                                } else {
                                    path.lineTo(x, y)
                                    fillPath.lineTo(x, y)
                                }
                            }
                            fillPath.lineTo(w, h)
                            fillPath.close()

                            // Draw gradient area under curve
                            drawPath(
                                path = fillPath,
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        primaryColor.copy(alpha = 0.35f),
                                        primaryColor.copy(alpha = 0.0f),
                                    ),
                                ),
                                style = androidx.compose.ui.graphics.drawscope.Fill,
                            )

                            // Draw line curve
                            drawPath(
                                path = path,
                                color = primaryColor,
                                style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round),
                            )
                        }
                    }
                }
            }

            // Scheduled Reset Countdown Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                ),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = stringResource(R.string.ai_reset_tomorrow_title),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            text = countdownFormatted,
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp,
                            ),
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }

                    FilledTonalButton(
                        onClick = {
                            coroutineScope.launch {
                                AiLimitManager.resetQuotaForTomorrow(context)
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                    ) {
                        Text(text = stringResource(R.string.ai_refresh))
                    }
                }
            }
        }
    }
}

private object TimeUnit {
    fun toMillis(hours: Long): Long = hours * 3600_000L
    val MILLISECONDS = java.util.concurrent.TimeUnit.MILLISECONDS
}
