/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.api

import android.content.Context
import androidx.datastore.preferences.core.edit
import com.listrovia.music.constants.BiometricVerifiedKey
import com.listrovia.music.constants.ChildProtectionEnabledKey
import com.listrovia.music.constants.FaceVerifiedKey
import com.listrovia.music.constants.IdDocumentVerifiedKey
import com.listrovia.music.constants.ParentalPinKey
import com.listrovia.music.constants.StrictModerationKey
import com.listrovia.music.constants.UserAgeCategoryKey
import com.listrovia.music.constants.UserDateOfBirthKey
import com.listrovia.music.utils.dataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.Calendar
import java.util.Locale

enum class AgeCategory(val labelEn: String, val labelVi: String, val isRestricted: Boolean) {
    CHILD("Child (<13)", "Trẻ em (<13 tuổi)", true),
    TEEN("Teen (13-17)", "Thiếu niên (13-17 tuổi)", true),
    ADULT("Adult (18+)", "Người lớn (18+ tuổi)", false);

    companion object {
        fun fromCode(code: String?): AgeCategory {
            return when (code?.uppercase()) {
                "CHILD" -> CHILD
                "TEEN" -> TEEN
                "ADULT" -> ADULT
                else -> ADULT
            }
        }

        fun calculateFromBirthMillis(birthMillis: Long): AgeCategory {
            if (birthMillis <= 0L) return ADULT
            val dob = Calendar.getInstance().apply { timeInMillis = birthMillis }
            val today = Calendar.getInstance()
            var age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR)
            if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)) {
                age--
            }
            return when {
                age < 13 -> CHILD
                age < 18 -> TEEN
                else -> ADULT
            }
        }
    }
}

data class AgeProtectionState(
    val birthMillis: Long = 0L,
    val ageCategory: AgeCategory = AgeCategory.ADULT,
    val childProtectionEnabled: Boolean = false,
    val strictModerationEnabled: Boolean = true,
    val biometricVerified: Boolean = false,
    val faceVerified: Boolean = false,
    val idDocumentVerified: Boolean = false,
    val hasParentalPin: Boolean = false,
) {
    val calculatedAge: Int
        get() {
            if (birthMillis <= 0L) return 18
            val dob = Calendar.getInstance().apply { timeInMillis = birthMillis }
            val today = Calendar.getInstance()
            var age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR)
            if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)) {
                age--
            }
            return age.coerceAtLeast(0)
        }

    val isMinor: Boolean
        get() = ageCategory == AgeCategory.CHILD || ageCategory == AgeCategory.TEEN || childProtectionEnabled
}

data class ModerationCheckResult(
    val isAllowed: Boolean,
    val reasonEn: String,
    val reasonVi: String,
)

/**
 * Handles User Age Verification, Child/Teen Protection, Biometric/Face/ID Verification,
 * and Content Safety Moderation for AI features.
 */
object AiAgeProtectionManager {

    fun getAgeProtectionState(context: Context): Flow<AgeProtectionState> {
        return context.dataStore.data.map { prefs ->
            val dobMillis = prefs[UserDateOfBirthKey] ?: 0L
            val categoryCode = prefs[UserAgeCategoryKey]
            val category = if (categoryCode != null) {
                AgeCategory.fromCode(categoryCode)
            } else if (dobMillis > 0L) {
                AgeCategory.calculateFromBirthMillis(dobMillis)
            } else {
                AgeCategory.ADULT
            }

            val childProtection = prefs[ChildProtectionEnabledKey] ?: (category != AgeCategory.ADULT)
            val strictModeration = prefs[StrictModerationKey] ?: true
            val biometric = prefs[BiometricVerifiedKey] ?: false
            val face = prefs[FaceVerifiedKey] ?: false
            val idDoc = prefs[IdDocumentVerifiedKey] ?: false
            val pin = prefs[ParentalPinKey] ?: ""

            AgeProtectionState(
                birthMillis = dobMillis,
                ageCategory = category,
                childProtectionEnabled = childProtection,
                strictModerationEnabled = strictModeration,
                biometricVerified = biometric,
                faceVerified = face,
                idDocumentVerified = idDoc,
                hasParentalPin = pin.isNotBlank(),
            )
        }
    }

    suspend fun setUserBirthDate(context: Context, year: Int, monthZeroBased: Int, day: Int) {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, monthZeroBased)
            set(Calendar.DAY_OF_MONTH, day)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val birthMillis = calendar.timeInMillis
        val category = AgeCategory.calculateFromBirthMillis(birthMillis)

        context.dataStore.edit { prefs ->
            prefs[UserDateOfBirthKey] = birthMillis
            prefs[UserAgeCategoryKey] = category.name
            if (category != AgeCategory.ADULT) {
                prefs[ChildProtectionEnabledKey] = true
                prefs[StrictModerationKey] = true
            }
        }
    }

    suspend fun setChildProtectionEnabled(context: Context, enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[ChildProtectionEnabledKey] = enabled
        }
    }

    suspend fun setStrictModerationEnabled(context: Context, enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[StrictModerationKey] = enabled
        }
    }

    suspend fun updateBiometricVerification(context: Context, verified: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[BiometricVerifiedKey] = verified
        }
    }

    suspend fun updateFaceVerification(context: Context, verified: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[FaceVerifiedKey] = verified
        }
    }

    suspend fun updateIdDocumentVerification(context: Context, verified: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[IdDocumentVerifiedKey] = verified
        }
    }

    suspend fun setParentalPin(context: Context, pin: String) {
        context.dataStore.edit { prefs ->
            prefs[ParentalPinKey] = pin
        }
    }

    suspend fun verifyParentalPin(context: Context, pin: String): Boolean {
        var isValid = false
        context.dataStore.data.collect { prefs ->
            val stored = prefs[ParentalPinKey] ?: ""
            isValid = stored.isNotBlank() && stored == pin
        }
        return isValid
    }

    /**
     * Real-time content moderation check for AI prompts & lyrics generation requests.
     */
    fun checkContentModeration(prompt: String, state: AgeProtectionState): ModerationCheckResult {
        if (!state.strictModerationEnabled && !state.isMinor) {
            return ModerationCheckResult(true, "Content approved", "Nội dung hợp lệ")
        }

        val promptLower = prompt.lowercase(Locale.ROOT)
        val restrictedKeywords = listOf(
            "violence", "gambling", "adult", "explicit", "bạo lực", "cờ bạc",
            "đồi trụy", "chất cấm", "nguy hiểm", "chửi bới", "hate speech"
        )

        val foundKeyword = restrictedKeywords.find { promptLower.contains(it) }
        if (foundKeyword != null) {
            return ModerationCheckResult(
                isAllowed = false,
                reasonEn = "Prompt contains restricted content for child/teen protection ($foundKeyword).",
                reasonVi = "Yêu cầu chứa nội dung bị giới hạn cho trẻ em/thiếu niên ($foundKeyword)."
            )
        }

        if (state.ageCategory == AgeCategory.CHILD && prompt.length > 500) {
            return ModerationCheckResult(
                isAllowed = false,
                reasonEn = "Prompt length exceeds safe child limits (max 500 chars).",
                reasonVi = "Độ dài văn bản vượt quá giới hạn an toàn cho trẻ em (tối đa 500 ký tự)."
            )
        }

        return ModerationCheckResult(true, "Content moderation passed", "Kiểm duyệt nội dung thành công")
    }
}
