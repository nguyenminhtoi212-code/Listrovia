/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.component

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.listrovia.music.R
import com.listrovia.music.api.AiLimitManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

data class TokenPackage(
    val id: String,
    val tokenCount: Long,
    val priceVnd: String,
    val priceUsd: String,
    val badgeVi: String,
    val badgeEn: String
)

enum class PaymentMethod(val labelVi: String, val labelEn: String) {
    BANK_TRANSFER("Ngân Hàng & VietQR", "Bank Transfer & VietQR"),
    CASH_VOUCHER("Tiền Mặt / Mã Nạp Điểm", "Cash / Point Voucher Code")
}

@Composable
fun AiTokenPurchaseModal(
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val isVietnamese = remember { Locale.getDefault().language == "vi" }

    val packages = remember {
        listOf(
            TokenPackage("p1", 50_000L, "50.000 VNĐ", "$1.99", "Phổ Thông", "Standard"),
            TokenPackage("p2", 200_000L, "180.000 VNĐ", "$6.99", "Tiết Kiệm 20%", "Save 20%"),
            TokenPackage("p3", 1_000_000L, "500.000 VNĐ", "$19.99", "Gói Ưu Đãi VIP", "VIP Best Value")
        )
    }

    var selectedPackage by remember { mutableStateOf(packages[1]) }
    var paymentMethod by remember { mutableStateOf(PaymentMethod.BANK_TRANSFER) }
    var cashVoucherCode by remember { mutableStateOf("") }
    var isProcessing by remember { mutableStateOf(false) }
    var isSuccess by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismissRequest) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (isVietnamese) "Nạp Token AI Trả Phí" else "Purchase Paid AI Tokens",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isVietnamese) "Duy trì sử dụng không gián đoạn" else "Continue uninterrupted AI features",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismissRequest) {
                        Icon(painter = painterResource(R.drawable.close), contentDescription = "Close")
                    }
                }

                if (isSuccess) {
                    // Success View
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.star),
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(48.dp)
                            )
                            Text(
                                text = if (isVietnamese) "Thanh Toán Thành Công!" else "Payment Successful!",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = if (isVietnamese)
                                    "Đã cộng +${String.format(Locale.US, "%,d", selectedPackage.tokenCount)} Tokens vào tài khoản của bạn."
                                else
                                    "Added +${String.format(Locale.US, "%,d", selectedPackage.tokenCount)} Tokens to your account balance.",
                                style = MaterialTheme.typography.bodyMedium,
                                textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Button(
                                onClick = onDismissRequest,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(text = if (isVietnamese) "Hoàn Tất" else "Done")
                            }
                        }
                    }
                } else {
                    // Package selector
                    Text(
                        text = if (isVietnamese) "1. Chọn Gói Tokens:" else "1. Select Token Package:",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        packages.forEach { pkg ->
                            val isSelected = selectedPackage.id == pkg.id
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                border = if (isSelected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedPackage = pkg }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            text = "+${String.format(Locale.US, "%,d", pkg.tokenCount)} Tokens",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = if (isVietnamese) pkg.badgeVi else pkg.badgeEn,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Text(
                                        text = if (isVietnamese) pkg.priceVnd else pkg.priceUsd,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }

                    // Payment method selection
                    Text(
                        text = if (isVietnamese) "2. Hình Thức Thanh Toán:" else "2. Payment Method:",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        PaymentMethod.entries.forEach { method ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { paymentMethod = method }
                                    .padding(vertical = 4.dp)
                            ) {
                                RadioButton(
                                    selected = (paymentMethod == method),
                                    onClick = { paymentMethod = method }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isVietnamese) method.labelVi else method.labelEn,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    // Payment details based on selected method
                    if (paymentMethod == PaymentMethod.BANK_TRANSFER) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = if (isVietnamese) "Thông Tin Chuyển Khoản VietQR / Ngân Hàng:" else "VietQR / Bank Details:",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(text = "Ngân hàng: MBBank (Ngoại Thương / Quân Đội)", style = MaterialTheme.typography.bodySmall)
                                Text(text = "Số TK: 9999LISTROVIA", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                Text(text = "Chủ TK: LISTROVIA MUSIC CORP", style = MaterialTheme.typography.bodySmall)
                                Text(text = "Nội dung: AI ${selectedPackage.id.uppercase()}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    } else {
                        OutlinedTextField(
                            value = cashVoucherCode,
                            onValueChange = { cashVoucherCode = it },
                            label = { Text(text = if (isVietnamese) "Mã Thẻ / Mã Nạp Tiền Mặt" else "Cash Voucher Code") },
                            placeholder = { Text(text = "EX: CASH-9988-7766") },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    // Confirm Purchase Button
                    Button(
                        onClick = {
                            isProcessing = true
                            scope.launch {
                                delay(1200L) // Simulate network payment check
                                AiLimitManager.purchasePaidTokens(context, selectedPackage.tokenCount, paymentMethod.name)
                                isProcessing = false
                                isSuccess = true
                            }
                        },
                        enabled = !isProcessing,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (isProcessing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        } else {
                            Text(
                                text = if (isVietnamese) "Xác Nhận Thanh Toán" else "Confirm & Pay"
                            )
                        }
                    }
                }
            }
        }
    }
}
