/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.component

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.listrovia.music.R
import com.listrovia.music.api.AionLabsClassifiedModels
import com.listrovia.music.api.AionLabsModelItem
import com.listrovia.music.api.AionLabsModelManager
import com.listrovia.music.constants.AionLabsModelsUrl
import com.listrovia.music.utils.ModelBenchmarkUtility
import com.listrovia.music.viewmodels.ModelViewModel
import kotlinx.coroutines.launch
import java.util.Locale

private val AionCyan = Color(0xFF00D2FF)
private val AionViolet = Color(0xFF7C4DFF)
private val AionEmerald = Color(0xFF00E676)

/**
 * Dedicated Real-Time Recommendation Deck exclusively crafted for AionLabs (https://api.aionlabs.ai/v1/models).
 * Features a precision-aligned horizontal Neural Carousel with unclipped circular match rings,
 * full-width capability telemetry bars, and instant smart recommendation.
 */
@Composable
fun AionLabsRealtimeDeck(
    modifier: Modifier = Modifier,
    selectedModel: String,
    apiKey: String = "",
    onModelSelected: (String) -> Unit,
    onOpenExplorerClick: () -> Unit,
    onCustomModelClick: () -> Unit,
    viewModel: ModelViewModel = hiltViewModel(),
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val modelManager = remember { AionLabsModelManager.getInstance(context) }
    val isVietnamese = remember { Locale.getDefault().language == "vi" }

    val vmModels by viewModel.aionLabsModels.collectAsStateWithLifecycle()
    val isVmLoading by viewModel.isAionLabsLoading.collectAsStateWithLifecycle()

    var localModels by remember { mutableStateOf<AionLabsClassifiedModels?>(vmModels) }
    var isLocalLoading by remember { mutableStateOf(false) }

    val activeClassified = localModels ?: vmModels
    val isLoading = isLocalLoading || (isVmLoading && activeClassified == null)

    fun refreshRealtimeModels(force: Boolean) {
        coroutineScope.launch {
            isLocalLoading = true
            try {
                val fetched = modelManager.fetchModels(forceRefresh = force, apiKey = apiKey)
                localModels = fetched
                if (force) {
                    Toast.makeText(
                        context,
                        context.getString(R.string.aionlabs_sync_toast, fetched.allModels.size),
                        Toast.LENGTH_SHORT,
                    ).show()
                }
            } finally {
                isLocalLoading = false
            }
        }
    }

    LaunchedEffect(Unit) {
        if (activeClassified == null) {
            refreshRealtimeModels(force = false)
        }
    }

    val pulseTransition = rememberInfiniteTransition(label = "aionPulse")
    val pulseAlpha by pulseTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "pulseAlpha",
    )

    val spotlightList = remember(activeClassified) {
        activeClassified?.recommended?.ifEmpty { activeClassified.allModels } ?: emptyList()
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("aionlabs_realtime_deck")
            .clip(RoundedCornerShape(24.dp))
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            AionCyan.copy(alpha = 0.14f),
                            AionViolet.copy(alpha = 0.07f),
                            Color.Transparent,
                        ),
                        center = Offset(size.width * 0.18f, size.height * 0.15f),
                        radius = size.width * 0.85f,
                    ),
                )
            },
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        border = BorderStroke(
            width = 1.2.dp,
            brush = Brush.linearGradient(
                colors = listOf(
                    AionCyan.copy(alpha = 0.55f),
                    AionViolet.copy(alpha = 0.45f),
                    MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f),
                ),
            ),
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // Top Telemetry Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Box(
                    modifier = Modifier
                        .requiredSize(42.dp)
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(AionCyan, AionViolet),
                            ),
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = "AΛ",
                        color = Color.White,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.ExtraBold,
                        softWrap = false,
                        maxLines = 1,
                    )
                }

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Text(
                            text = stringResource(R.string.aionlabs_hub_title),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false),
                        )
                        Box(
                            modifier = Modifier
                                .requiredSize(8.dp)
                                .clip(CircleShape)
                                .background(AionEmerald.copy(alpha = pulseAlpha)),
                        )
                    }
                    Text(
                        text = stringResource(R.string.aionlabs_explorer_subtitle),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 10.5.sp,
                        ),
                        color = AionCyan,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }

                IconButton(
                    onClick = { refreshRealtimeModels(force = true) },
                    modifier = Modifier
                        .requiredSize(38.dp)
                        .testTag("aionlabs_refresh_button"),
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.requiredSize(18.dp),
                            strokeWidth = 2.dp,
                            color = AionCyan,
                        )
                    } else {
                        Icon(
                            painter = painterResource(R.drawable.sync),
                            contentDescription = stringResource(R.string.aionlabs_refresh_realtime),
                            tint = AionCyan,
                            modifier = Modifier.requiredSize(20.dp),
                        )
                    }
                }
            }

            // Active Model & Smart Auto-Recommend Bar
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                    ) {
                        Text(
                            text = stringResource(R.string.aionlabs_active_stream_model),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = selectedModel.ifBlank { stringResource(R.string.not_set) },
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }

                    FilledTonalButton(
                        onClick = {
                            coroutineScope.launch {
                                isLocalLoading = true
                                try {
                                    val pick = modelManager.getSmartRealtimeRecommendation(
                                        forceRefresh = true,
                                        apiKey = apiKey,
                                    )
                                    if (pick != null) {
                                        onModelSelected(pick.id)
                                        Toast.makeText(
                                            context,
                                            context.getString(R.string.aionlabs_smart_pick_applied, pick.name),
                                            Toast.LENGTH_SHORT,
                                        ).show()
                                    }
                                } finally {
                                    isLocalLoading = false
                                }
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                        modifier = Modifier
                            .height(38.dp)
                            .testTag("aionlabs_smart_recommend_btn"),
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.shuffle),
                            contentDescription = null,
                            modifier = Modifier.requiredSize(15.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.aionlabs_smart_pick_btn),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false,
                        )
                    }
                }
            }

            // Horizontal Real-Time Recommendation Cards
            Text(
                text = stringResource(R.string.aionlabs_realtime_carousel_title),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )

            if (isLoading && spotlightList.isEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 18.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.requiredSize(22.dp),
                        strokeWidth = 2.5.dp,
                        color = AionCyan,
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = stringResource(R.string.aionlabs_fetching_live),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            } else if (spotlightList.isEmpty()) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            text = stringResource(R.string.aionlabs_empty_state),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = { refreshRealtimeModels(force = true) }) {
                            Text(
                                text = stringResource(R.string.ai_refresh),
                                maxLines = 1,
                                softWrap = false,
                            )
                        }
                    }
                }
            } else {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(horizontal = 2.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    items(spotlightList.take(8), key = { it.id }) { item ->
                        val isSelected = item.id == selectedModel
                        AionSpotlightCarouselCard(
                            item = item,
                            isSelected = isSelected,
                            isVietnamese = isVietnamese,
                            onSelect = { onModelSelected(item.id) },
                        )
                    }
                }
            }

            // Bottom Studio Actions (Uniform Height & Alignment)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                FilledTonalButton(
                    onClick = onOpenExplorerClick,
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("aionlabs_open_explorer_btn"),
                ) {
                    Icon(
                        painter = painterResource(R.drawable.discover_tune),
                        contentDescription = null,
                        modifier = Modifier.requiredSize(18.dp),
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(
                            R.string.aionlabs_open_studio_btn,
                            activeClassified?.allModels?.size ?: 0,
                        ),
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis,
                    )
                }

                OutlinedButton(
                    onClick = onCustomModelClick,
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
                    modifier = Modifier.height(44.dp),
                ) {
                    Icon(
                        painter = painterResource(R.drawable.edit),
                        contentDescription = null,
                        modifier = Modifier.requiredSize(16.dp),
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.ai_custom),
                        maxLines = 1,
                        softWrap = false,
                    )
                }
            }
        }
    }
}

@Composable
private fun AionSpotlightCarouselCard(
    item: AionLabsModelItem,
    isSelected: Boolean,
    isVietnamese: Boolean,
    onSelect: () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = if (isSelected) {
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.52f)
        } else {
            MaterialTheme.colorScheme.surfaceContainerLow
        },
        border = BorderStroke(
            width = if (isSelected) 1.6.dp else 1.dp,
            brush = if (isSelected) {
                Brush.linearGradient(listOf(AionCyan, AionViolet))
            } else {
                Brush.linearGradient(
                    listOf(
                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f),
                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f),
                    ),
                )
            },
        ),
        modifier = Modifier
            .width(248.dp)
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onSelect),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth(),
            ) {
                AionMatchRingGauge(
                    score = item.matchScore,
                    size = 42.dp,
                )

                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = AionCyan.copy(alpha = 0.15f),
                    ) {
                        Text(
                            text = "${item.formattedContext} CTX",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = AionCyan,
                            maxLines = 1,
                            softWrap = false,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                        )
                    }
                    Text(
                        text = item.pricingSummary,
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = item.id,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                    ),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            // Recommendation specialty pill (full-width aligned)
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = AionViolet.copy(alpha = 0.14f),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    text = item.getRecommendationBadge(isVietnamese),
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.5.sp),
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                )
            }

            // Precision full-width telemetry bars
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                AionMiniTelemetryBar(
                    label = stringResource(R.string.aionlabs_metric_lyric),
                    progress = item.lyricNuanceScore,
                    accentColor = AionCyan,
                )
                AionMiniTelemetryBar(
                    label = stringResource(R.string.aionlabs_metric_speed),
                    progress = item.speedEfficiencyScore,
                    accentColor = AionViolet,
                )
            }
        }
    }
}

/**
 * Unclipped, mathematically circular Match Score Ring Gauge.
 * Uses requiredSize + aspectRatio(1f) and insets the stroke by strokeWidth/2 so it never distorts or clips.
 */
@Composable
private fun AionMatchRingGauge(
    score: Int,
    size: Dp = 44.dp,
) {
    val clampedScore = score.coerceIn(0, 100)
    val sweepFraction by animateFloatAsState(
        targetValue = clampedScore / 100f,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "matchRingSweep",
    )
    val trackColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.32f)

    Box(
        modifier = Modifier
            .requiredSize(size)
            .aspectRatio(1f),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 3.5.dp.toPx()
            val diameter = minOf(this.size.width, this.size.height) - strokeWidth
            if (diameter > 0f) {
                val topLeftOffset = Offset(
                    x = (this.size.width - diameter) / 2f,
                    y = (this.size.height - diameter) / 2f,
                )
                val arcSize = Size(diameter, diameter)

                drawArc(
                    color = trackColor,
                    startAngle = -90f,
                    sweepAngle = 360f,
                    useCenter = false,
                    topLeft = topLeftOffset,
                    size = arcSize,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
                )
                drawArc(
                    brush = Brush.linearGradient(
                        colors = listOf(AionCyan, AionViolet, AionEmerald),
                    ),
                    startAngle = -90f,
                    sweepAngle = 360f * sweepFraction,
                    useCenter = false,
                    topLeft = topLeftOffset,
                    size = arcSize,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
                )
            }
        }
        Text(
            text = "$clampedScore%",
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 10.sp,
                fontWeight = FontWeight.ExtraBold,
            ),
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            softWrap = false,
            textAlign = TextAlign.Center,
        )
    }
}

/**
 * Precision 2-tier telemetry bar:
 * Top row: Label on the left + exact percentage on the right (never truncated at 54dp).
 * Bottom row: Full-width LinearProgressIndicator starting and ending at identical X coordinates.
 */
@Composable
private fun AionMiniTelemetryBar(
    label: String,
    progress: Float,
    accentColor: Color,
) {
    val clamped = progress.coerceIn(0.1f, 1f)
    val percentInt = (clamped * 100).toInt()

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "$percentInt%",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                ),
                color = accentColor,
                maxLines = 1,
                softWrap = false,
            )
        }
        LinearProgressIndicator(
            progress = { clamped },
            modifier = Modifier
                .fillMaxWidth()
                .height(5.dp)
                .clip(CircleShape),
            color = accentColor,
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
        )
    }
}

/**
 * Full-Studio AionLabs Real-Time Explorer Modal Dialog.
 * Features a Live #1 Recommendation Spotlight Matrix, 5 AionLabs filter modes,
 * and precision-aligned Bento Telemetry Cards with expandable specification drawers.
 */
@Composable
fun AionLabsModelExplorerDialog(
    currentModel: String,
    apiKey: String = "",
    onDismiss: () -> Unit,
    onSelectModel: (String) -> Unit,
    onCustomInput: () -> Unit,
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val modelManager = remember { AionLabsModelManager.getInstance(context) }
    val benchmarkUtility = remember { ModelBenchmarkUtility.getInstance(context) }
    val isVietnamese = remember { Locale.getDefault().language == "vi" }

    var classifiedModels by remember { mutableStateOf<AionLabsClassifiedModels?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var isBenchmarking by remember { mutableStateOf(false) }
    var selectedFilterMode by rememberSaveable { mutableIntStateOf(0) }
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var expandedSpecModelId by rememberSaveable { mutableStateOf<String?>(null) }

    fun syncLiveCatalog(force: Boolean) {
        coroutineScope.launch {
            isLoading = true
            try {
                val result = modelManager.fetchModels(forceRefresh = force, apiKey = apiKey)
                classifiedModels = result
                if (force) {
                    Toast.makeText(
                        context,
                        context.getString(R.string.aionlabs_sync_toast, result.allModels.size),
                        Toast.LENGTH_SHORT,
                    ).show()
                }
            } finally {
                isLoading = false
            }
        }
    }

    LaunchedEffect(Unit) {
        syncLiveCatalog(force = false)
    }

    val filteredModels = remember(classifiedModels, selectedFilterMode, searchQuery) {
        val data = classifiedModels ?: return@remember emptyList()
        val modeList = when (selectedFilterMode) {
            0 -> data.recommended
            1 -> data.flagshipSeries
            2 -> data.creativeLyric
            3 -> data.fastRealtime
            else -> data.allModels
        }
        if (searchQuery.isBlank()) {
            modeList
        } else {
            val q = searchQuery.trim().lowercase()
            modeList.filter {
                it.id.lowercase().contains(q) ||
                    it.name.lowercase().contains(q) ||
                    it.ownedBy.lowercase().contains(q) ||
                    it.description.lowercase().contains(q) ||
                    it.recommendationBadgeEn.lowercase().contains(q) ||
                    it.recommendationBadgeVi.lowercase().contains(q)
            }
        }
    }

    val topSpotlight = remember(classifiedModels) {
        classifiedModels?.topSpotlightModel ?: classifiedModels?.recommended?.firstOrNull()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .widthIn(max = 560.dp)
                .fillMaxHeight(0.88f)
                .clip(RoundedCornerShape(28.dp))
                .testTag("aionlabs_explorer_dialog"),
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            border = BorderStroke(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        AionCyan.copy(alpha = 0.5f),
                        AionViolet.copy(alpha = 0.4f),
                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                    ),
                ),
            ),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                // Studio Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .requiredSize(42.dp)
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Brush.linearGradient(listOf(AionCyan, AionViolet))),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = "AΛ",
                            color = Color.White,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1,
                            softWrap = false,
                        )
                    }

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                    ) {
                        Text(
                            text = stringResource(R.string.aionlabs_explorer_title),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = stringResource(R.string.aionlabs_explorer_subtitle),
                            style = MaterialTheme.typography.labelSmall,
                            color = AionCyan,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp),
                    ) {
                        // Ping / TTFT latency button
                        IconButton(
                            onClick = {
                                coroutineScope.launch {
                                    isBenchmarking = true
                                    try {
                                        val targetId = currentModel.ifBlank { topSpotlight?.id ?: "aion-labs/aion-1.0" }
                                        val ttft = benchmarkUtility.benchmarkModel(
                                            modelId = targetId,
                                            baseUrl = AionLabsModelsUrl,
                                        )
                                        Toast.makeText(
                                            context,
                                            context.getString(R.string.ai_model_ttft_label, ttft),
                                            Toast.LENGTH_SHORT,
                                        ).show()
                                    } finally {
                                        isBenchmarking = false
                                    }
                                }
                            },
                            enabled = !isBenchmarking,
                            modifier = Modifier.requiredSize(36.dp),
                        ) {
                            if (isBenchmarking) {
                                CircularProgressIndicator(
                                    modifier = Modifier.requiredSize(16.dp),
                                    strokeWidth = 2.dp,
                                    color = AionCyan,
                                )
                            } else {
                                Icon(
                                    painter = painterResource(R.drawable.speed),
                                    contentDescription = stringResource(R.string.aionlabs_ping_endpoint),
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.requiredSize(19.dp),
                                )
                            }
                        }

                        // Sync live catalog button
                        IconButton(
                            onClick = { syncLiveCatalog(force = true) },
                            enabled = !isLoading,
                            modifier = Modifier.requiredSize(36.dp),
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.sync),
                                contentDescription = stringResource(R.string.aionlabs_refresh_realtime),
                                tint = AionCyan,
                                modifier = Modifier.requiredSize(19.dp),
                            )
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.requiredSize(36.dp),
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.close),
                                contentDescription = stringResource(R.string.close),
                                modifier = Modifier.requiredSize(19.dp),
                            )
                        }
                    }
                }

                // Real-time Spotlight Hero Banner (#1 Recommended Model)
                if (topSpotlight != null && searchQuery.isBlank()) {
                    AionHeroRecommendationBanner(
                        spotlight = topSpotlight,
                        isCurrent = topSpotlight.id == currentModel,
                        isVietnamese = isVietnamese,
                        onApply = { onSelectModel(topSpotlight.id) },
                    )
                }

                // Search input
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            text = stringResource(R.string.aionlabs_search_placeholder),
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.search),
                            contentDescription = null,
                            modifier = Modifier.requiredSize(18.dp),
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    painter = painterResource(R.drawable.close),
                                    contentDescription = null,
                                    modifier = Modifier.requiredSize(16.dp),
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                )

                // AionLabs Exclusive Filter Matrix Pills
                val filterTabs = listOf(
                    0 to stringResource(R.string.aionlabs_tab_recommended, classifiedModels?.recommended?.size ?: 0),
                    1 to stringResource(R.string.aionlabs_tab_flagship, classifiedModels?.flagshipSeries?.size ?: 0),
                    2 to stringResource(R.string.aionlabs_tab_creative, classifiedModels?.creativeLyric?.size ?: 0),
                    3 to stringResource(R.string.aionlabs_tab_fast, classifiedModels?.fastRealtime?.size ?: 0),
                    4 to stringResource(R.string.aionlabs_tab_all, classifiedModels?.allModels?.size ?: 0),
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    filterTabs.forEach { (idx, title) ->
                        val active = selectedFilterMode == idx
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (active) {
                                AionCyan.copy(alpha = 0.18f)
                            } else {
                                MaterialTheme.colorScheme.surfaceContainerLow
                            },
                            border = BorderStroke(
                                width = 1.dp,
                                color = if (active) AionCyan else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                            ),
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { selectedFilterMode = idx },
                        ) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                                color = if (active) AionCyan else MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                softWrap = false,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            )
                        }
                    }
                }

                // Model Bento List
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                ) {
                    if (isLoading && filteredModels.isEmpty()) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            CircularProgressIndicator(color = AionCyan)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = stringResource(R.string.aionlabs_fetching_live),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                            )
                        }
                    } else if (filteredModels.isEmpty()) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 16.dp),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.explore_outlined),
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.requiredSize(40.dp),
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = stringResource(R.string.aionlabs_empty_state),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            FilledTonalButton(onClick = { syncLiveCatalog(force = true) }) {
                                Text(
                                    text = stringResource(R.string.aionlabs_refresh_realtime),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(vertical = 4.dp),
                        ) {
                            items(filteredModels, key = { it.id }) { item ->
                                val isSelected = item.id == currentModel
                                val isExpanded = expandedSpecModelId == item.id
                                AionBentoModelCard(
                                    item = item,
                                    isSelected = isSelected,
                                    isSpecExpanded = isExpanded,
                                    isVietnamese = isVietnamese,
                                    onSelect = { onSelectModel(item.id) },
                                    onToggleSpec = {
                                        expandedSpecModelId = if (isExpanded) null else item.id
                                    },
                                )
                            }
                        }
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f))

                // Footer Bar (Balanced, Non-Overlapping)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    OutlinedButton(
                        onClick = onCustomInput,
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                        modifier = Modifier
                            .weight(1f, fill = false)
                            .height(40.dp),
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.edit),
                            contentDescription = null,
                            modifier = Modifier.requiredSize(16.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.aionlabs_custom_model_btn),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.height(40.dp),
                    ) {
                        Text(
                            text = stringResource(R.string.close),
                            maxLines = 1,
                            softWrap = false,
                        )
                    }
                }
            }
        }
    }
}

/**
 * 2-tier Hero Recommendation Banner so the Vietnamese & English header badge, context chip,
 * match ring, and action button never crowd or squash each other.
 */
@Composable
private fun AionHeroRecommendationBanner(
    spotlight: AionLabsModelItem,
    isCurrent: Boolean,
    isVietnamese: Boolean,
    onApply: () -> Unit,
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
        ),
        border = BorderStroke(
            width = 1.2.dp,
            brush = Brush.linearGradient(listOf(AionCyan, AionViolet)),
        ),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            // Tier 1: Top Badge & Context/Price Pills
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = AionCyan.copy(alpha = 0.18f),
                    modifier = Modifier.weight(1f, fill = false),
                ) {
                    Text(
                        text = stringResource(R.string.aionlabs_top_realtime_pick),
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.5.sp),
                        fontWeight = FontWeight.ExtraBold,
                        color = AionCyan,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = AionViolet.copy(alpha = 0.16f),
                    ) {
                        Text(
                            text = "${spotlight.formattedContext} CTX",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            softWrap = false,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        )
                    }
                    Text(
                        text = spotlight.pricingSummary,
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        softWrap = false,
                    )
                }
            }

            // Tier 2: Circular Ring + Model Info + Action Button
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                AionMatchRingGauge(
                    score = spotlight.matchScore,
                    size = 46.dp,
                )

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    Text(
                        text = spotlight.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = spotlight.id,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                        ),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = spotlight.getRecommendationBadge(isVietnamese),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = AionCyan,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }

                FilledTonalButton(
                    onClick = onApply,
                    enabled = !isCurrent,
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = AionCyan.copy(alpha = 0.22f),
                        contentColor = MaterialTheme.colorScheme.onSurface,
                    ),
                    modifier = Modifier.height(38.dp),
                ) {
                    Text(
                        text = if (isCurrent) {
                            stringResource(R.string.ai_model_active_badge)
                        } else {
                            stringResource(R.string.aionlabs_apply_pick_btn)
                        },
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false,
                    )
                }
            }
        }
    }
}

/**
 * Precision-aligned Bento Model Card for the AionLabs Model List.
 * Prevents badge squishing, vertical text wrapping, and ring distortion.
 */
@Composable
private fun AionBentoModelCard(
    item: AionLabsModelItem,
    isSelected: Boolean,
    isSpecExpanded: Boolean,
    isVietnamese: Boolean,
    onSelect: () -> Unit,
    onToggleSpec: () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = if (isSelected) {
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.42f)
        } else {
            MaterialTheme.colorScheme.surfaceContainerLow
        },
        border = BorderStroke(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) AionCyan else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.38f),
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onSelect),
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                // Left Unclipped Circular Match Ring
                AionMatchRingGauge(
                    score = item.matchScore,
                    size = 44.dp,
                )

                // Center Structured Info Column
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    // Row 1: Model Title + Active Pill
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            text = item.name,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        if (isSelected) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = AionEmerald.copy(alpha = 0.2f),
                            ) {
                                Text(
                                    text = stringResource(R.string.ai_model_active_badge),
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.5.sp),
                                    fontWeight = FontWeight.ExtraBold,
                                    color = AionEmerald,
                                    maxLines = 1,
                                    softWrap = false,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                )
                            }
                        }
                    }

                    // Row 2: Monospace Model ID + Pricing
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            text = item.id,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.5.sp,
                            ),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        Text(
                            text = item.pricingSummary,
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            fontWeight = FontWeight.SemiBold,
                            color = AionCyan,
                            maxLines = 1,
                            softWrap = false,
                        )
                    }

                    // Row 3: Context Badge + Recommendation Specialty Badge (Weight-constrained so nothing squishes)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = AionCyan.copy(alpha = 0.14f),
                        ) {
                            Text(
                                text = "${item.formattedContext} CTX",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                fontWeight = FontWeight.Bold,
                                color = AionCyan,
                                maxLines = 1,
                                softWrap = false,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = AionViolet.copy(alpha = 0.14f),
                            modifier = Modifier.weight(1f, fill = false),
                        ) {
                            Text(
                                text = item.getRecommendationBadge(isVietnamese),
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            )
                        }
                    }
                }

                // Right Expandable Telemetry Spec Drawer Button
                IconButton(
                    onClick = onToggleSpec,
                    modifier = Modifier.requiredSize(36.dp),
                ) {
                    Icon(
                        painter = painterResource(if (isSpecExpanded) R.drawable.expand_less else R.drawable.expand_more),
                        contentDescription = stringResource(R.string.aionlabs_spec_details),
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.requiredSize(20.dp),
                    )
                }
            }

            AnimatedVisibility(
                visible = isSpecExpanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut(),
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.55f))
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    if (item.description.isNotBlank()) {
                        Text(
                            text = item.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = "${stringResource(R.string.aionlabs_spec_owner)}: ${item.ownedBy}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        Text(
                            text = "${stringResource(R.string.aionlabs_spec_pricing)}: ${item.pricingSummary}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            softWrap = false,
                        )
                    }
                    AionMiniTelemetryBar(
                        label = stringResource(R.string.aionlabs_metric_context),
                        progress = item.contextScore,
                        accentColor = AionEmerald,
                    )
                    AionMiniTelemetryBar(
                        label = stringResource(R.string.aionlabs_metric_lyric),
                        progress = item.lyricNuanceScore,
                        accentColor = AionCyan,
                    )
                    AionMiniTelemetryBar(
                        label = stringResource(R.string.aionlabs_metric_speed),
                        progress = item.speedEfficiencyScore,
                        accentColor = AionViolet,
                    )
                }
            }
        }
    }
}
