/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 * 
 * Unified AI Services Module combining OpenRouterService, OpenRouterStreamingService, 
 * MistralService, and DeepLService into a single shared file as requested, ensuring zero 
 * file fragmentation, clean sharing, and stable execution.
 */

package com.listrovia.music.api

import com.listrovia.music.constants.AionLabsBaseUrl
import com.listrovia.music.constants.AionLabsDefaultModel
import com.listrovia.music.constants.DeepInfraBaseUrl
import com.listrovia.music.constants.DeepInfraDefaultModel
import com.listrovia.music.constants.GroqBaseUrl
import com.listrovia.music.constants.GroqDefaultModel
import com.listrovia.music.constants.HuggingFaceBaseUrl
import com.listrovia.music.constants.HuggingFaceDefaultModel
import com.listrovia.music.constants.NvidiaBaseUrl
import com.listrovia.music.constants.NvidiaDefaultModel
import com.listrovia.music.constants.OpenRouterDefaultModel
import com.listrovia.music.security.SecureKeyStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.serialization.json.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import timber.log.Timber
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

/**
 * OpenRouterService: Core OpenRouter and multi-provider chat and translation service.
 */
object OpenRouterService {
    private val client =
        OkHttpClient
            .Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    private val JSON = "application/json; charset=utf-8".toMediaType()

    fun isKeyFormatValid(apiKey: String, provider: String = "OpenRouter"): Boolean {
        return ApiKeyManager.validateKeyFormat(apiKey, provider)
    }

    suspend fun translate(
        text: String,
        targetLanguage: String,
        apiKey: String,
        baseUrl: String,
        model: String,
        mode: String,
        maxRetries: Int = 3,
        sourceLanguage: String? = null,
        customSystemPrompt: String = "",
        provider: String = "OpenRouter",
    ): Result<List<String>> =
        withContext(Dispatchers.IO) {
            var currentAttempt = 0

            if (text.isBlank()) {
                return@withContext Result.failure(Exception("Input text is empty"))
            }

            val cleanKey = SecureKeyStorage.decrypt(apiKey.trim())
            if (provider != "DeepInfra" && cleanKey.isNotBlank() && !isKeyFormatValid(cleanKey, provider)) {
                return@withContext Result.failure(
                    Exception("Mã API Key của $provider không hợp lệ hoặc giả mạo. Cấm gọi API với mã không đúng chuẩn bản quyền để chống lậu và gian lận.")
                )
            }

            val lines = text.lines()
            val lineCount = lines.size

            while (currentAttempt < maxRetries) {
                try {
                    val systemPrompt =
                        if (customSystemPrompt.isNotBlank()) {
                            customSystemPrompt.replace("{lineCount}", lineCount.toString())
                        } else {
                            """You are a precise lyrics translation assistant. Your output must ALWAYS be a valid JSON array of strings.

CRITICAL RULES:
1. Output ONLY a JSON array: ["line1", "line2", "line3"]
2. NO explanations, NO questions, NO additional text
3. Each input line maps to exactly one output line
4. Preserve empty lines as empty strings ""
5. Return EXACTLY $lineCount items in the array
6. If uncertain, provide best approximation but maintain line count"""
                        }

                    val userPrompt =
                        when (mode) {
                            "Romanized" -> {
                                """Romanize/transliterate the following $lineCount lines into simple Latin script using ONLY basic English letters (a-z, A-Z).

CRITICAL REQUIREMENTS:
- Use ONLY simple ASCII characters (a-z, A-Z, 0-9, basic punctuation)
- NO special characters like ā, ī, ū, ñ, ç, etc.
- NO diacritics or accent marks
- If text is already in Latin script, return it UNCHANGED
- For non-Latin scripts (Hindi, Chinese, Japanese, Korean, Cyrillic, etc.), provide simple romanization
- DO NOT translate meaning, only convert script to simple English letters
- Keep all punctuation and formatting
- Preserve line-by-line structure exactly

Examples of correct simple romanization:
- Sanskrit/Hindi "आ" → "aa" (not "ā")
- Japanese "東京" → "toukyou" or "tokyo" (not "tōkyō")
- Korean "서울" → "seoul" (not "sŏul")

Input ($lineCount lines):
$text

Output MUST be a JSON array with EXACTLY $lineCount strings using ONLY simple ASCII characters."""
                            }

                            "Transcribed" -> {
                                """Transcribe/transliterate the following $lineCount lines phonetically into $targetLanguage script.

CRITICAL REQUIREMENTS:
- Convert the SOUND/PRONUNCIATION of the original text into $targetLanguage script
- DO NOT translate the meaning - only represent how the original words SOUND
- Use the native script of $targetLanguage (e.g., Devanagari for Hindi, Hangul for Korean, etc.)
- Preserve the original pronunciation as closely as possible in the target script
- Keep punctuation and formatting
- Preserve line-by-line structure exactly
- If text is already in $targetLanguage script, return it UNCHANGED

Examples:
- Japanese "こんにちは" to Hindi → "कोन्निचिवा" (phonetic, not translation)
- English "Hello" to Hindi → "हेलो" (phonetic)
- Korean "안녕하세요" to Hindi → "अन्न्योंग हासेयो" (phonetic)

Input ($lineCount lines):
$text

Output MUST be a JSON array with EXACTLY $lineCount strings in $targetLanguage script."""
                            }

                            else -> {
                                """Translate the following $lineCount lines to $targetLanguage.

IMPORTANT:
- Provide natural, accurate translation
- Maintain poetic flow and meaning
- Keep punctuation appropriate for target language
- Preserve line-by-line structure exactly
- For song lyrics, prioritize singability

Input ($lineCount lines):
$text

Output MUST be a JSON array with EXACTLY $lineCount strings."""
                            }
                        }

                    val messages =
                        JSONArray().apply {
                            put(
                                JSONObject().apply {
                                    put("role", "system")
                                    put("content", systemPrompt)
                                },
                            )
                            put(
                                JSONObject().apply {
                                    put("role", "user")
                                    put("content", userPrompt)
                                },
                            )
                        }

                    val defaultUrl = when (provider) {
                        "DeepInfra" -> DeepInfraBaseUrl
                        "AionLabs" -> AionLabsBaseUrl
                        "HuggingFace" -> HuggingFaceBaseUrl
                        "Nvidia" -> NvidiaBaseUrl
                        "Groq" -> GroqBaseUrl
                        else -> "https://openrouter.ai/api/v1/chat/completions"
                    }
                    val defaultModelName = when (provider) {
                        "DeepInfra" -> DeepInfraDefaultModel
                        "AionLabs" -> AionLabsDefaultModel
                        "HuggingFace" -> HuggingFaceDefaultModel
                        "Nvidia" -> NvidiaDefaultModel
                        "Groq" -> GroqDefaultModel
                        else -> OpenRouterDefaultModel
                    }
                    val jsonBody =
                        JSONObject().apply {
                            put("model", if (model.isNotBlank()) model else defaultModelName)
                            put("messages", messages)
                            put("temperature", 0.3)
                            put("max_tokens", lineCount * 100)
                        }

                    val request =
                        Request
                            .Builder()
                            .url(baseUrl.ifBlank { defaultUrl })
                            .apply {
                                if (cleanKey.isNotBlank()) {
                                    addHeader("Authorization", "Bearer $cleanKey")
                                }
                            }.addHeader("Content-Type", "application/json")
                            .addHeader("HTTP-Referer", "https://listrovia.cc")
                            .addHeader("X-Title", "Listrovia")
                            .post(jsonBody.toString().toRequestBody(JSON))
                            .build()

                    val response = client.newCall(request).execute()
                    val responseBody = response.body?.string()

                    if (!response.isSuccessful) {
                        if (response.code >= 500) {
                            currentAttempt++
                            kotlinx.coroutines.delay(1000L * currentAttempt)
                            continue
                        }

                        val errorMsg =
                            try {
                                JSONObject(responseBody ?: "").optJSONObject("error")?.optString("message")
                                    ?: "HTTP ${response.code}: ${response.message}"
                            } catch (e: Exception) {
                                "HTTP ${response.code}: ${response.message}"
                            }
                        return@withContext Result.failure(Exception("Translation failed: $errorMsg"))
                    }

                    if (responseBody == null) {
                        currentAttempt++
                        continue
                    }

                    val jsonResponse = JSONObject(responseBody)
                    val choices = jsonResponse.optJSONArray("choices")
                    if (choices != null && choices.length() > 0) {
                        val message = choices.getJSONObject(0).optJSONObject("message")
                        var content = message?.optString("content")?.trim()

                        if (!content.isNullOrBlank()) {
                            var translatedLines: List<String>? = null

                            try {
                                val jsonArray = JSONArray(content)
                                translatedLines = (0 until jsonArray.length()).map { jsonArray.optString(it) }
                            } catch (e: Exception) {
                                content = content.replace("```json", "").replace("```", "").trim()

                                try {
                                    val jsonArray = JSONArray(content)
                                    translatedLines = (0 until jsonArray.length()).map { jsonArray.optString(it) }
                                } catch (e2: Exception) {
                                    val startIdx = content.indexOf('[')
                                    val endIdx = content.lastIndexOf(']')

                                    if (startIdx != -1 && endIdx != -1 && endIdx > startIdx) {
                                        val jsonString = content.substring(startIdx, endIdx + 1)
                                        try {
                                            val jsonArray = JSONArray(jsonString)
                                            translatedLines = (0 until jsonArray.length()).map { jsonArray.optString(it) }
                                        } catch (e3: Exception) {
                                            translatedLines =
                                                content
                                                    .lines()
                                                    .filter { it.trim().isNotEmpty() }
                                                    .map { it.trim().removeSurrounding("\"").removeSurrounding("'") }
                                        }
                                    }
                                }
                            }

                            if (translatedLines != null) {
                                if (translatedLines.size == lineCount) {
                                    return@withContext Result.success(translatedLines)
                                } else if (translatedLines.size > lineCount) {
                                    return@withContext Result.success(translatedLines.take(lineCount))
                                } else {
                                    val paddedLines = translatedLines.toMutableList()
                                    while (paddedLines.size < lineCount) {
                                        paddedLines.add("")
                                    }
                                    return@withContext Result.success(paddedLines)
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    if (currentAttempt == maxRetries - 1) {
                        return@withContext Result.failure(e)
                    }
                }
                currentAttempt++
                kotlinx.coroutines.delay(1000L * currentAttempt)
            }
            return@withContext Result.failure(Exception("Max retries exceeded"))
        }

    data class AssistantResponse(
        val reply: String,
        val suggestedQuery: String? = null,
        val isMusicAction: Boolean = false,
    )

    suspend fun chatAssistant(
        prompt: String,
        history: List<Pair<String, String>> = emptyList(),
        apiKey: String = "",
        baseUrl: String = "https://openrouter.ai/api/v1/chat/completions",
        model: String = OpenRouterDefaultModel,
        provider: String = "OpenRouter",
    ): Result<AssistantResponse> =
        withContext(Dispatchers.IO) {
            val cleanPrompt = prompt.trim()
            if (cleanPrompt.isBlank()) {
                return@withContext Result.failure(Exception("Tin nhắn không được để trống"))
            }

            val cleanKey = SecureKeyStorage.decrypt(apiKey.trim())
            if (cleanKey.isNotBlank() && !isKeyFormatValid(cleanKey, provider)) {
                return@withContext Result.failure(
                    Exception("Mã API Key của $provider không hợp lệ hoặc giả mạo. Cấm thực thi cuộc gọi để ngăn chặn lách luật và dùng lậu.")
                )
            }

            val lowerPrompt = cleanPrompt.lowercase()
            val musicKeywords = listOf(
                "bật bài", "phát bài", "tìm bài", "mở bài", "nghe bài",
                "tìm nhạc", "nghe nhạc", "bật nhạc", "mở nhạc", "hát bài",
                "play song ", "play music ", "play ", "listen to ", "find song ", "find music ", "find ",
                "search for ", "search song ", "search "
            )
            var extractedQuery: String? = null
            for (kw in musicKeywords) {
                if (lowerPrompt.startsWith(kw)) {
                    extractedQuery = cleanPrompt.substring(kw.length).trim().removePrefix(":").removePrefix("-").trim()
                    break
                }
            }

            if (cleanKey.isNotBlank()) {
                try {
                    val messages = JSONArray()

                    val systemMsg = JSONObject()
                    systemMsg.put("role", "system")
                    systemMsg.put(
                        "content",
                        """You are 'Mini Assistant' (Trợ lý Mini), a smart, compact, and friendly AI music companion in the Listrovia music app.
You fluently understand and reply in English, Vietnamese, and all other languages.
Rules:
1. Always reply in the EXACT SAME language that the user spoke or typed in (Vietnamese for Vietnamese queries, English for English queries, etc.).
2. Keep your answers concise, engaging, helpful, and directly focused on music, tracks, artists, genres, moods, lyrics, and playlists.
3. Whenever you recommend or mention specific songs/tracks, ALWAYS write them in brackets like [Song Title - Artist] (for example: [Shape of You - Ed Sheeran] or [Chúng Ta Của Tương Lai - Sơn Tùng M-TP]). This allows the app to display a one-tap direct play button for the user!
4. Keep the message compact, clear, and perfectly formatted for mobile screens."""
                    )
                    messages.put(systemMsg)

                    for ((role, content) in history.takeLast(6)) {
                        val msg = JSONObject()
                        msg.put("role", if (role == "user") "user" else "assistant")
                        msg.put("content", content)
                        messages.put(msg)
                    }

                    val userMsg = JSONObject()
                    userMsg.put("role", "user")
                    userMsg.put("content", cleanPrompt)
                    messages.put(userMsg)

                    val requestBodyJson = JSONObject()
                    val actualModel = if (model.isBlank()) OpenRouterDefaultModel else model
                    requestBodyJson.put("model", actualModel)
                    requestBodyJson.put("messages", messages)
                    requestBodyJson.put("temperature", 0.7)
                    requestBodyJson.put("max_tokens", 600)

                    val effectiveUrl =
                        if (baseUrl.isBlank()) {
                            when (provider) {
                                "DeepInfra" -> DeepInfraBaseUrl
                                "AionLabs" -> AionLabsBaseUrl
                                "HuggingFace" -> HuggingFaceBaseUrl
                                "Nvidia" -> NvidiaBaseUrl
                                "Groq" -> GroqBaseUrl
                                "OpenAI" -> "https://api.openai.com/v1/chat/completions"
                                "Gemini" -> "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions"
                                "Perplexity" -> "https://api.perplexity.ai/chat/completions"
                                "Claude" -> "https://api.anthropic.com/v1/messages"
                                "XAi" -> "https://api.x.ai/v1/chat/completions"
                                "Mistral" -> "https://api.mistral.ai/v1/chat/completions"
                                "Inception" -> "https://api.inceptionlabs.ai/v1/chat/completions"
                                "OrcaRouter" -> "https://orcarouter.ai/api/v1/chat/completions"
                                else -> "https://openrouter.ai/api/v1/chat/completions"
                            }
                        } else {
                            baseUrl
                        }

                    val requestBuilder =
                        Request.Builder()
                            .url(effectiveUrl)
                            .post(requestBodyJson.toString().toRequestBody(JSON))
                            .addHeader("Content-Type", "application/json")

                    if (provider == "Claude") {
                        requestBuilder.addHeader("x-api-key", cleanKey)
                        requestBuilder.addHeader("anthropic-version", "2023-06-01")
                    } else {
                        requestBuilder.addHeader("Authorization", "Bearer $cleanKey")
                    }

                    if (provider == "OpenRouter") {
                        requestBuilder.addHeader("HTTP-Referer", "https://listrovia.cc")
                        requestBuilder.addHeader("X-Title", "Listrovia Music")
                    }

                    val response = client.newCall(requestBuilder.build()).execute()
                    val responseBody = response.body?.string()

                    if (response.isSuccessful && !responseBody.isNullOrBlank()) {
                        val jsonResponse = JSONObject(responseBody)
                        val choices = jsonResponse.optJSONArray("choices")
                        if (choices != null && choices.length() > 0) {
                            val msgObj = choices.getJSONObject(0).optJSONObject("message")
                            val replyText = msgObj?.optString("content")?.trim() ?: ""
                            if (replyText.isNotEmpty()) {
                                val songPattern = Regex("\\[(.*?)\\]")
                                val matchedSong = songPattern.find(replyText)?.groupValues?.getOrNull(1)
                                val finalQuery = extractedQuery ?: matchedSong

                                return@withContext Result.success(
                                    AssistantResponse(
                                        reply = replyText,
                                        suggestedQuery = finalQuery,
                                        isMusicAction = extractedQuery != null,
                                    )
                                )
                            }
                        }
                    }
                } catch (e: Exception) {
                    // Fall back to local assistant response below
                }
            }

            val isVietnamese = java.util.Locale.getDefault().language.equals("vi", ignoreCase = true) ||
                cleanPrompt.any { "àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổổơờớợởỡùúụủũưừứựửữỳýỵỷỹđ".contains(it, ignoreCase = true) } ||
                listOf("bài", "nhạc", "hát", "gợi ý", "thư giãn", "thịnh hành", "tìm", "mở", "bật").any { lowerPrompt.contains(it) }

            val fallbackReply = if (isVietnamese) {
                if (extractedQuery != null && extractedQuery.isNotBlank()) {
                    "Tôi đã nhận diện bài hát: \"$extractedQuery\". Đang chuẩn bị phát hoặc tìm kiếm cho bạn!"
                } else if (lowerPrompt.contains("gợi ý") || lowerPrompt.contains("nhạc hay") || lowerPrompt.contains("recommend")) {
                    "Dưới đây là một số bài hát tuyệt vời bạn có thể nghe ngay:\n• [Chúng Ta Của Tương Lai - Sơn Tùng M-TP]\n• [Nơi Này Có Anh - Sơn Tùng M-TP]\n• [Đừng Làm Trái Tim Anh Đau - Sơn Tùng M-TP]\n• [Chuyện Đôi Ta - Emcee L]\n\nChạm vào bất kỳ bài nào để phát ngay nhé!"
                } else if (lowerPrompt.contains("chill") || lowerPrompt.contains("thư giãn") || lowerPrompt.contains("buồn")) {
                    "Danh sách nhạc nhẹ nhàng, thư giãn dành riêng cho bạn:\n• [Lofi Hip Hop Chill Beats]\n• [Ghé Qua - Dick, PC, Tofu]\n• [Bao Tiền Một Mớ Bình Yên - 14 Casper]\n• [Dấu Mưa - Trung Quân Idol]\n\nBạn muốn nghe bài nào?"
                } else if (lowerPrompt.contains("hot") || lowerPrompt.contains("thịnh hành") || lowerPrompt.contains("trend")) {
                    "Các ca khúc đang thịnh hành hàng đầu:\n• [Đừng Làm Trái Tim Anh Đau - Sơn Tùng M-TP]\n• [Cắt Đôi Nỗi Sầu - Tăng Duy Tân]\n• [Hit Me Up - Binz, Touliver]\n• [Ánh Đèn Sân Khấu - Khắc Hưng]"
                } else if (apiKey.isBlank()) {
                    "Xin chào! Bạn có thể nói hoặc gõ: 'Bật bài [Tên bài hát]', 'Gợi ý nhạc chill', hoặc vào Cài đặt -> Cài đặt AI để nhập API Key (Gemini, OpenRouter...) để mở khóa toàn bộ trí tuệ nhân tạo trò chuyện không giới hạn."
                } else {
                    "Tôi đã sẵn sàng hỗ trợ! Hãy nói hoặc hỏi tôi về bất kỳ bài hát, nghệ sĩ hoặc thể loại âm nhạc nào."
                }
            } else {
                if (extractedQuery != null && extractedQuery.isNotBlank()) {
                    "Recognized track: \"$extractedQuery\". Ready to play and search for you!"
                } else if (lowerPrompt.contains("recommend") || lowerPrompt.contains("suggest") || lowerPrompt.contains("good song") || lowerPrompt.contains("best song")) {
                    "Here are some great tracks you can enjoy right now:\n• [Shape of You - Ed Sheeran]\n• [Blinding Lights - The Weeknd]\n• [Stay - The Kid LAROI & Justin Bieber]\n• [As It Was - Harry Styles]\n\nTap any song to play instantly!"
                } else if (lowerPrompt.contains("chill") || lowerPrompt.contains("relax") || lowerPrompt.contains("lofi") || lowerPrompt.contains("calm")) {
                    "Relaxing and calming playlist for you:\n• [Lofi Hip Hop Chill Beats]\n• [Sunset Lover - Petit Biscuit]\n• [Someone You Loved - Lewis Capaldi]\n• [Daylight - David Kushner]\n\nWhich song would you like to hear?"
                } else if (lowerPrompt.contains("hot") || lowerPrompt.contains("trending") || lowerPrompt.contains("popular") || lowerPrompt.contains("top")) {
                    "Top trending tracks on the charts right now:\n• [Espresso - Sabrina Carpenter]\n• [Birds of a Feather - Billie Eilish]\n• [Good Luck, Babe! - Chappell Roan]\n• [Cruel Summer - Taylor Swift]"
                } else if (apiKey.isBlank()) {
                    "Hello! You can speak or type: 'Play [Song Name]', 'Recommend chill music', or go to Settings -> AI Settings to enter your API Key (Gemini, OpenRouter...) for unlimited smart conversation."
                } else {
                    "I am ready to assist! Ask me anything about music, songs, artists, or genres."
                }
            }

            return@withContext Result.success(
                AssistantResponse(
                    reply = fallbackReply,
                    suggestedQuery = extractedQuery,
                    isMusicAction = extractedQuery != null,
                )
            )
        }

    suspend fun validateApiKey(
        provider: String,
        apiKey: String,
        baseUrl: String = "",
    ): ApiKeyValidationResult = ApiKeyManager.validateKey(provider, apiKey, baseUrl)
}

/**
 * OpenRouterStreamingService: Real-time streaming translation service.
 */
object OpenRouterStreamingService {
    private val client =
        OkHttpClient
            .Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    private val JSON = "application/json; charset=utf-8".toMediaType()
    private val json = Json { ignoreUnknownKeys = true }

    fun streamTranslation(
        text: String,
        targetLanguage: String,
        apiKey: String,
        baseUrl: String,
        model: String,
        mode: String,
        customSystemPrompt: String = "",
        provider: String = "OpenRouter",
    ): Flow<StreamChunk> =
        flow {
            if (text.isBlank()) {
                emit(StreamChunk.Error("Input text is empty"))
                return@flow
            }

            val cleanKey = SecureKeyStorage.decrypt(apiKey.trim())
            if (provider != "DeepInfra" && cleanKey.isNotBlank() && !ApiKeyManager.validateKeyFormat(cleanKey, provider)) {
                emit(StreamChunk.Error("Mã API Key không hợp lệ hoặc giả mạo. Cấm thực hiện streaming để ngăn chặn vượt rào và dùng lậu."))
                return@flow
            }

            val lines = text.lines()
            val lineCount = lines.size

            try {
                val systemPrompt =
                    if (customSystemPrompt.isNotBlank()) {
                        customSystemPrompt.replace("{lineCount}", lineCount.toString())
                    } else {
                        """You are a precise lyrics translation assistant. Your output must ALWAYS be a valid JSON array of strings.

CRITICAL RULES:
1. Output ONLY a JSON array: ["line1", "line2", "line3"]
2. NO explanations, NO questions, NO additional text
3. Each input line maps to exactly one output line
4. Preserve empty lines as empty strings ""
5. Return EXACTLY $lineCount items in the array
6. If uncertain, provide best approximation but maintain line count"""
                    }

                val userPrompt =
                    when (mode) {
                        "Transcribed" -> {
                            """Transcribe/transliterate the following $lineCount lines phonetically into $targetLanguage script.

CRITICAL REQUIREMENTS:
- Convert the SOUND/PRONUNCIATION of the original text into $targetLanguage script
- DO NOT translate the meaning - only represent how the original words SOUND
- Use the native script of $targetLanguage
- Preserve the original pronunciation as closely as possible
- Keep punctuation and formatting

Input ($lineCount lines):
$text

Output MUST be a JSON array with EXACTLY $lineCount strings."""
                        }

                        else -> {
                            """Translate the following $lineCount lines to $targetLanguage.

IMPORTANT:
- Provide natural, accurate translation
- Maintain poetic flow and meaning
- Keep punctuation appropriate for target language
- Preserve line-by-line structure exactly

Input ($lineCount lines):
$text

Output MUST be a JSON array with EXACTLY $lineCount strings."""
                        }
                    }

                val messages =
                    JSONArray().apply {
                        put(
                            JSONObject().apply {
                                put("role", "system")
                                put("content", systemPrompt)
                            },
                        )
                        put(
                            JSONObject().apply {
                                put("role", "user")
                                put("content", userPrompt)
                            },
                        )
                    }

                val defaultUrl = when (provider) {
                    "DeepInfra" -> DeepInfraBaseUrl
                    "AionLabs" -> AionLabsBaseUrl
                    "HuggingFace" -> HuggingFaceBaseUrl
                    "Nvidia" -> NvidiaBaseUrl
                    "Groq" -> GroqBaseUrl
                    else -> "https://openrouter.ai/api/v1/chat/completions"
                }
                val defaultModelName = when (provider) {
                    "DeepInfra" -> DeepInfraDefaultModel
                    "AionLabs" -> AionLabsDefaultModel
                    "HuggingFace" -> HuggingFaceDefaultModel
                    "Nvidia" -> NvidiaDefaultModel
                    "Groq" -> GroqDefaultModel
                    else -> OpenRouterDefaultModel
                }
                val jsonBody =
                    JSONObject().apply {
                        put("model", if (model.isNotBlank()) model else defaultModelName)
                        put("messages", messages)
                        put("stream", true)
                        put("temperature", 0.3)
                        put("max_tokens", lineCount * 100)
                    }

                val request =
                    Request
                        .Builder()
                        .url(baseUrl.ifBlank { defaultUrl })
                        .apply {
                            if (cleanKey.isNotBlank()) {
                                addHeader("Authorization", "Bearer $cleanKey")
                            }
                        }.addHeader("Content-Type", "application/json")
                        .addHeader("HTTP-Referer", "https://listrovia.cc")
                        .addHeader("X-Title", "Listrovia")
                        .post(jsonBody.toString().toRequestBody(JSON))
                        .build()

                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        val errorMsg =
                            try {
                                JSONObject(response.body?.string() ?: "")
                                    .optJSONObject("error")
                                    ?.optString("message")
                                    ?: "HTTP ${response.code}: ${response.message}"
                            } catch (e: Exception) {
                                "HTTP ${response.code}: ${response.message}"
                            }
                        emit(StreamChunk.Error("Translation failed: $errorMsg"))
                        return@flow
                    }

                    val reader = BufferedReader(InputStreamReader(response.body?.byteStream()))
                    var line: String?
                    val contentBuilder = StringBuilder()
                    var chunkCount = 0

                    while (reader.readLine().also { line = it } != null) {
                        line?.let { currentLine ->
                            if (currentLine.startsWith("data: ")) {
                                val data = currentLine.substring(6)
                                if (data == "[DONE]") {
                                    val fullContent = contentBuilder.toString()
                                    val result = parseTranslationContent(fullContent, lineCount)
                                    result
                                        .onSuccess { translatedLines ->
                                            emit(StreamChunk.Complete(translatedLines))
                                        }.onFailure { error ->
                                            emit(StreamChunk.Error(error.message ?: "Parsing failed"))
                                        }
                                    return@flow
                                }

                                try {
                                    val jsonObject = json.parseToJsonElement(data).jsonObject
                                    val choices = jsonObject["choices"]?.jsonArray
                                    val delta =
                                        choices
                                            ?.get(0)
                                            ?.jsonObject
                                            ?.get("delta")
                                            ?.jsonObject
                                    val content = delta?.get("content")?.jsonPrimitive?.content

                                    content?.let { chunk ->
                                        contentBuilder.append(chunk)
                                        chunkCount++
                                        emit(StreamChunk.Content(chunk))
                                    }
                                } catch (e: Exception) {
                                    // Ignore malformed chunks
                                }
                            }
                        }
                    }

                    if (contentBuilder.isNotEmpty()) {
                        val fullContent = contentBuilder.toString()
                        val result = parseTranslationContent(fullContent, lineCount)
                        result
                            .onSuccess { translatedLines ->
                                emit(StreamChunk.Complete(translatedLines))
                            }.onFailure { error ->
                                emit(StreamChunk.Error(error.message ?: "Parsing failed"))
                            }
                    }
                }
            } catch (e: Exception) {
                emit(StreamChunk.Error(e.message ?: "Unknown error"))
            }
        }.flowOn(Dispatchers.IO)

    private fun parseTranslationContent(
        content: String,
        expectedLineCount: Int,
    ): Result<List<String>> {
        var translatedLines: List<String>? = null

        try {
            val jsonArray = JSONArray(content.trim())
            translatedLines = (0 until jsonArray.length()).map { jsonArray.optString(it) }
        } catch (e: Exception) {
            val cleanedContent = content.replace("```json", "").replace("```", "").trim()

            try {
                val jsonArray = JSONArray(cleanedContent)
                translatedLines = (0 until jsonArray.length()).map { jsonArray.optString(it) }
            } catch (e2: Exception) {
                val startIdx = cleanedContent.indexOf('[')
                val endIdx = cleanedContent.lastIndexOf(']')

                if (startIdx != -1 && endIdx != -1 && endIdx > startIdx) {
                    val jsonString = cleanedContent.substring(startIdx, endIdx + 1)
                    try {
                        val jsonArray = JSONArray(jsonString)
                        translatedLines = (0 until jsonArray.length()).map { jsonArray.optString(it) }
                    } catch (e3: Exception) {
                        translatedLines =
                            cleanedContent
                                .lines()
                                .filter { it.trim().isNotEmpty() }
                                .map { it.trim().removeSurrounding("\"").removeSurrounding("'") }
                    }
                }
            }
        }

        if (translatedLines == null) {
            return Result.failure(Exception("Failed to parse translation"))
        }

        return when {
            translatedLines.size == expectedLineCount -> {
                Result.success(translatedLines)
            }
            translatedLines.size > expectedLineCount -> {
                Result.success(translatedLines.take(expectedLineCount))
            }
            else -> {
                val paddedLines = translatedLines.toMutableList()
                while (paddedLines.size < expectedLineCount) {
                    paddedLines.add("")
                }
                Result.success(paddedLines)
            }
        }
    }

    sealed class StreamChunk {
        data class Content(val text: String) : StreamChunk()
        data class Complete(val translatedLines: List<String>) : StreamChunk()
        data class Error(val message: String) : StreamChunk()
    }
}

/**
 * MistralService: Mistral AI translation service.
 */
object MistralService {
    private val client =
        OkHttpClient
            .Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    private val JSON = "application/json; charset=utf-8".toMediaType()

    suspend fun translate(
        text: String,
        targetLanguage: String,
        apiKey: String,
        model: String,
        mode: String,
        maxRetries: Int = 3,
        sourceLanguage: String? = null,
        customSystemPrompt: String = "",
    ): Result<List<String>> =
        withContext(Dispatchers.IO) {
            var currentAttempt = 0

            if (text.isBlank()) {
                return@withContext Result.failure(Exception("Input text is empty"))
            }

            val lines = text.lines()
            val lineCount = lines.size

            while (currentAttempt < maxRetries) {
                try {
                    val systemPrompt =
                        if (customSystemPrompt.isNotBlank()) {
                            customSystemPrompt.replace("{lineCount}", lineCount.toString())
                        } else {
                            """You are a precise lyrics translation assistant. Your output must ALWAYS be a valid JSON array of strings.

CRITICAL RULES:
1. Output ONLY a JSON array: ["line1", "line2", "line3"]
2. NO explanations, NO questions, NO additional text
3. Each input line maps to exactly one output line
4. Preserve empty lines as empty strings ""
5. Return EXACTLY $lineCount items in the array
6. If uncertain, provide best approximation but maintain line count"""
                        }

                    val userPrompt =
                        when (mode) {
                            "Romanized" -> {
                                """Romanize/transliterate the following $lineCount lines into simple Latin script using ONLY basic English letters (a-z, A-Z).

CRITICAL REQUIREMENTS:
- Use ONLY simple ASCII characters (a-z, A-Z, 0-9, basic punctuation)
- NO special characters like ā, ī, ū, ñ, ç, etc.
- NO diacritics or accent marks
- If text is already in Latin script, return it UNCHANGED
- For non-Latin scripts (Hindi, Chinese, Japanese, Korean, Cyrillic, etc.), provide simple romanization
- DO NOT translate meaning, only convert script to simple English letters
- Keep all punctuation and formatting
- Preserve line-by-line structure exactly

Input ($lineCount lines):
$text

Output MUST be a JSON array with EXACTLY $lineCount strings using ONLY simple ASCII characters."""
                            }

                            "Transcribed" -> {
                                """Transcribe/transliterate the following $lineCount lines phonetically into $targetLanguage script.

CRITICAL REQUIREMENTS:
- Convert the SOUND/PRONUNCIATION of the original text into $targetLanguage script
- DO NOT translate the meaning - only represent how the original words SOUND
- Use the native script of $targetLanguage
- Preserve the original pronunciation as closely as possible
- Keep punctuation and formatting
- Preserve line-by-line structure exactly

Input ($lineCount lines):
$text

Output MUST be a JSON array with EXACTLY $lineCount strings in $targetLanguage script."""
                            }

                            else -> {
                                """Translate the following $lineCount lines to $targetLanguage.

IMPORTANT:
- Provide natural, accurate translation
- Maintain poetic flow and meaning
- Keep punctuation appropriate for target language
- Preserve line-by-line structure exactly
- For song lyrics, prioritize singability

Input ($lineCount lines):
$text

Output MUST be a JSON array with EXACTLY $lineCount strings."""
                            }
                        }

                    val messages =
                        JSONArray().apply {
                            if (customSystemPrompt.isNotBlank()) {
                                put(
                                    JSONObject().apply {
                                        put("role", "system")
                                        put("content", systemPrompt)
                                    },
                                )
                            }
                            put(
                                JSONObject().apply {
                                    put("role", "user")
                                    put("content", userPrompt)
                                },
                            )
                        }

                    val jsonBody =
                        JSONObject().apply {
                            if (model.isNotBlank()) {
                                put("model", model)
                            } else {
                                put("model", "mistral-small-latest")
                            }
                            put("messages", messages)
                            put("temperature", 0.3)
                            put("max_tokens", lineCount * 100)
                        }

                    val request =
                        Request
                            .Builder()
                            .url("https://api.mistral.ai/v1/chat/completions")
                            .apply {
                                if (apiKey.isNotBlank()) {
                                    addHeader("Authorization", "Bearer ${apiKey.trim()}")
                                }
                            }.addHeader("Content-Type", "application/json")
                            .post(jsonBody.toString().toRequestBody(JSON))
                            .build()

                    val response = client.newCall(request).execute()
                    val responseBody = response.body?.string()

                    if (!response.isSuccessful) {
                        if (response.code >= 500) {
                            currentAttempt++
                            kotlinx.coroutines.delay(1000L * currentAttempt)
                            continue
                        }

                        val errorMsg =
                            try {
                                JSONObject(responseBody ?: "").optJSONObject("error")?.optString("message")
                                    ?: "HTTP ${response.code}: ${response.message}"
                            } catch (e: Exception) {
                                "HTTP ${response.code}: ${response.message}"
                            }
                        return@withContext Result.failure(Exception("Translation failed: $errorMsg"))
                    }

                    if (responseBody == null) {
                        currentAttempt++
                        continue
                    }

                    val jsonResponse = JSONObject(responseBody)
                    val choices = jsonResponse.optJSONArray("choices")
                    if (choices != null && choices.length() > 0) {
                        val message = choices.getJSONObject(0).optJSONObject("message")
                        var content = message?.optString("content")?.trim()

                        if (!content.isNullOrBlank()) {
                            var translatedLines: List<String>? = null

                            try {
                                val jsonArray = JSONArray(content)
                                translatedLines = (0 until jsonArray.length()).map { jsonArray.optString(it) }
                            } catch (e: Exception) {
                                content = content.replace("```json", "").replace("```", "").trim()

                                try {
                                    val jsonArray = JSONArray(content)
                                    translatedLines = (0 until jsonArray.length()).map { jsonArray.optString(it) }
                                } catch (e2: Exception) {
                                    val startIdx = content.indexOf('[')
                                    val endIdx = content.lastIndexOf(']')

                                    if (startIdx != -1 && endIdx != -1 && endIdx > startIdx) {
                                        val jsonString = content.substring(startIdx, endIdx + 1)
                                        try {
                                            val jsonArray = JSONArray(jsonString)
                                            translatedLines = (0 until jsonArray.length()).map { jsonArray.optString(it) }
                                        } catch (e3: Exception) {
                                            translatedLines =
                                                content
                                                    .lines()
                                                    .filter { it.trim().isNotEmpty() }
                                                    .map { it.trim().removeSurrounding("\"").removeSurrounding("'") }
                                        }
                                    }
                                }
                            }

                            if (translatedLines != null) {
                                if (translatedLines.size == lineCount) {
                                    return@withContext Result.success(translatedLines)
                                } else if (translatedLines.size > lineCount) {
                                    return@withContext Result.success(translatedLines.take(lineCount))
                                } else {
                                    val paddedLines = translatedLines.toMutableList()
                                    while (paddedLines.size < lineCount) {
                                        paddedLines.add("")
                                    }
                                    return@withContext Result.success(paddedLines)
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    if (currentAttempt == maxRetries - 1) {
                        return@withContext Result.failure(e)
                    }
                }
                currentAttempt++
                kotlinx.coroutines.delay(1000L * currentAttempt)
            }
            return@withContext Result.failure(Exception("Max retries exceeded"))
        }
}

/**
 * DeepLService: DeepL translation service.
 */
object DeepLService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
    private val JSON = "application/json; charset=utf-8".toMediaType()

    suspend fun translate(
        text: String,
        targetLanguage: String,
        apiKey: String,
        formality: String = "default",
        maxRetries: Int = 3
    ): Result<List<String>> = withContext(Dispatchers.IO) {
        var currentAttempt = 0
        
        if (text.isBlank()) {
            return@withContext Result.failure(Exception("Input text is empty"))
        }
        
        val lines = text.lines()
        val lineCount = lines.size
        
        val deeplLangCode = when (targetLanguage.lowercase()) {
            "zh", "zh-cn", "zh-hans" -> "ZH"
            "zh-tw", "zh-hant" -> "ZH"
            "en", "en-us" -> "EN-US"
            "en-gb" -> "EN-GB"
            "pt", "pt-pt" -> "PT-PT"
            "pt-br" -> "PT-BR"
            else -> targetLanguage.uppercase().take(2)
        }
        
        val baseUrl = if (apiKey.endsWith(":fx")) {
            "https://api-free.deepl.com/v2/translate"
        } else {
            "https://api.deepl.com/v2/translate"
        }
        
        while (currentAttempt < maxRetries) {
            try {
                val jsonBody = JSONObject().apply {
                    put("text", JSONArray().apply {
                        lines.forEach { put(it) }
                    })
                    put("target_lang", deeplLangCode)
                    if (formality != "default") {
                        put("formality", formality)
                    }
                    put("preserve_formatting", true)
                }

                val request = Request.Builder()
                    .url(baseUrl)
                    .addHeader("Authorization", "DeepL-Auth-Key ${apiKey.trim()}")
                    .addHeader("Content-Type", "application/json")
                    .post(jsonBody.toString().toRequestBody(JSON))
                    .build()

                val response = client.newCall(request).execute()
                val responseBody = response.body?.string()

                if (!response.isSuccessful) {
                    if (response.code >= 500) {
                        currentAttempt++
                        kotlinx.coroutines.delay(1000L * currentAttempt)
                        continue
                    }
                    
                    val errorMsg = try {
                        JSONObject(responseBody ?: "").optString("message") 
                            ?: "HTTP ${response.code}: ${response.message}"
                    } catch (e: Exception) {
                        "HTTP ${response.code}: ${response.message}"
                    }
                    return@withContext Result.failure(Exception("Translation failed: $errorMsg"))
                }

                if (responseBody == null) {
                    currentAttempt++
                    continue
                }

                val jsonResponse = JSONObject(responseBody)
                val translations = jsonResponse.optJSONArray("translations")
                if (translations != null && translations.length() > 0) {
                    val translatedLines = (0 until translations.length()).map { i ->
                        translations.getJSONObject(i).optString("text", "")
                    }
                    
                    if (translatedLines.size == lineCount) {
                        return@withContext Result.success(translatedLines)
                    } else if (translatedLines.size > lineCount) {
                        return@withContext Result.success(translatedLines.take(lineCount))
                    } else {
                        val paddedLines = translatedLines.toMutableList()
                        while (paddedLines.size < lineCount) {
                            paddedLines.add("")
                        }
                        return@withContext Result.success(paddedLines)
                    }
                }
            } catch (e: Exception) {
                if (currentAttempt == maxRetries - 1) {
                    return@withContext Result.failure(e)
                }
            }
            currentAttempt++
            kotlinx.coroutines.delay(1000L * currentAttempt)
        }
        return@withContext Result.failure(Exception("Max retries exceeded"))
    }
}
