/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.api

import android.content.Context
import android.content.SharedPreferences
import java.util.Calendar
import java.util.Locale

enum class AiRateLimitMode(val value: String) {
    TIMER_LIMITED("timer_limited"),
    UNLIMITED("unlimited"),
    REMOVE_LIMIT("remove_limit");

    companion object {
        fun fromString(value: String?): AiRateLimitMode {
            return entries.find { it.value.equals(value, ignoreCase = true) } ?: TIMER_LIMITED
        }
    }
}

data class AiUsageQuotaStatus(
    val mode: AiRateLimitMode,
    val currentTokensUsed: Long,
    val tokenLimit: Long,
    val currentSessionName: String,
    val isExceeded: Boolean,
    val cooldownRemainingMillis: Long,
) {
    val formattedCooldown: String
        get() {
            if (!isExceeded || cooldownRemainingMillis <= 0L) return "Active"
            val totalSeconds = cooldownRemainingMillis / 1000L
            val hours = totalSeconds / 3600L
            val minutes = (totalSeconds % 3600L) / 60L
            val seconds = totalSeconds % 60L
            return if (hours > 0) {
                String.format(Locale.US, "%dh %02dm", hours, minutes)
            } else {
                String.format(Locale.US, "%02dm %02ds", minutes, seconds)
            }
        }
}

/**
 * Real-time AI Token Rate Limiter & Session Timer Manager.
 * Controls AI feature access across Morning, Lunch, Afternoon, and Next Day (Tomorrow) sessions,
 * while ensuring all non-AI music playback and features operate without any restrictions.
 */
class AiUsageRateLimiter private constructor(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("ai_usage_rate_limiter_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_MODE = "ai_rate_limit_mode"
        private const val KEY_TOKENS_USED = "ai_tokens_used_count"
        private const val KEY_SESSION_ID = "ai_current_session_id"
        private const val KEY_RESET_TIMESTAMP = "ai_reset_timestamp"

        private const val SESSION_LIMIT_TOKENS = 15_000L // Token quota per real-time session window

        @Volatile
        private var instance: AiUsageRateLimiter? = null

        fun getInstance(context: Context): AiUsageRateLimiter {
            return instance ?: synchronized(this) {
                instance ?: AiUsageRateLimiter(context.applicationContext).also { instance = it }
            }
        }
    }

    fun getRateLimitMode(): AiRateLimitMode {
        val raw = prefs.getString(KEY_MODE, AiRateLimitMode.TIMER_LIMITED.value)
        return AiRateLimitMode.fromString(raw)
    }

    fun setRateLimitMode(mode: AiRateLimitMode) {
        prefs.edit().putString(KEY_MODE, mode.value).apply()
    }

    @Synchronized
    fun checkAndConsumeQuota(estimatedTokens: Int = 250): Pair<Boolean, String> {
        val mode = getRateLimitMode()
        if (mode == AiRateLimitMode.UNLIMITED || mode == AiRateLimitMode.REMOVE_LIMIT) {
            return Pair(true, "Allowed")
        }

        val (sessionId, sessionName) = getCurrentSessionInfo()
        val savedSessionId = prefs.getString(KEY_SESSION_ID, "") ?: ""
        val now = System.currentTimeMillis()

        // Check if session or day has rolled over
        if (savedSessionId != sessionId) {
            prefs.edit()
                .putString(KEY_SESSION_ID, sessionId)
                .putLong(KEY_TOKENS_USED, 0L)
                .putLong(KEY_RESET_TIMESTAMP, getNextSessionResetTimestamp())
                .apply()
        }

        val used = prefs.getLong(KEY_TOKENS_USED, 0L)
        if (used >= SESSION_LIMIT_TOKENS) {
            val resetTime = prefs.getLong(KEY_RESET_TIMESTAMP, now + 3600_000L)
            val diff = (resetTime - now).coerceAtLeast(0L)
            return Pair(false, "AI token limit reached for $sessionName session. Resets in ${formatMillis(diff)} or switch to Unlimited / Remove Limit in AI Settings.")
        }

        // Consume tokens
        val newUsed = used + estimatedTokens.toLong()
        prefs.edit().putLong(KEY_TOKENS_USED, newUsed).apply()
        return Pair(true, "Allowed")
    }

    fun getQuotaStatus(): AiUsageQuotaStatus {
        val mode = getRateLimitMode()
        val (_, sessionName) = getCurrentSessionInfo()
        val used = prefs.getLong(KEY_TOKENS_USED, 0L)
        val resetTime = prefs.getLong(KEY_RESET_TIMESTAMP, System.currentTimeMillis() + 3600_000L)
        val diff = (resetTime - System.currentTimeMillis()).coerceAtLeast(0L)
        val exceeded = (mode == AiRateLimitMode.TIMER_LIMITED && used >= SESSION_LIMIT_TOKENS)

        return AiUsageQuotaStatus(
            mode = mode,
            currentTokensUsed = used,
            tokenLimit = SESSION_LIMIT_TOKENS,
            currentSessionName = sessionName,
            isExceeded = exceeded,
            cooldownRemainingMillis = diff,
        )
    }

    private fun getCurrentSessionInfo(): Pair<String, String> {
        val cal = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        val dayOfYear = cal.get(Calendar.DAY_OF_YEAR)
        val year = cal.get(Calendar.YEAR)

        return when {
            hour in 5..11 -> Pair("$year-$dayOfYear-MORNING", "Morning (Buổi sáng)")
            hour in 12..16 -> Pair("$year-$dayOfYear-LUNCH", "Lunch (Buổi trưa)")
            hour in 17..22 -> Pair("$year-$dayOfYear-AFTERNOON", "Afternoon/Evening (Buổi chiều)")
            else -> Pair("$year-$dayOfYear-NIGHT", "Tomorrow (Đến ngày mai)")
        }
    }

    private fun getNextSessionResetTimestamp(): Long {
        val cal = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        when {
            hour in 5..11 -> {
                cal.set(Calendar.HOUR_OF_DAY, 12)
                cal.set(Calendar.MINUTE, 0)
                cal.set(Calendar.SECOND, 0)
            }
            hour in 12..16 -> {
                cal.set(Calendar.HOUR_OF_DAY, 17)
                cal.set(Calendar.MINUTE, 0)
                cal.set(Calendar.SECOND, 0)
            }
            hour in 17..22 -> {
                cal.set(Calendar.HOUR_OF_DAY, 23)
                cal.set(Calendar.MINUTE, 59)
                cal.set(Calendar.SECOND, 59)
            }
            else -> {
                cal.add(Calendar.DAY_OF_YEAR, 1)
                cal.set(Calendar.HOUR_OF_DAY, 5)
                cal.set(Calendar.MINUTE, 0)
                cal.set(Calendar.SECOND, 0)
            }
        }
        return cal.timeInMillis
    }

    private fun formatMillis(millis: Long): String {
        val totalSecs = millis / 1000L
        val hours = totalSecs / 3600L
        val minutes = (totalSecs % 3600L) / 60L
        return if (hours > 0) "${hours}h ${minutes}m" else "${minutes}m"
    }
}
