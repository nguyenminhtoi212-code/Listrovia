package com.listrovia.music.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp
import kotlin.math.max

/**
 * Theme classification categories evaluated BEFORE applying any Liquid Glass effect.
 * Ensures Light Mode, Dark Mode, Pure Black (AMOLED), and Custom/Dynamic Theme Colors
 * are properly classified with balanced luminance so the glass never appears overly dark
 * ("tối quá lố") or overly washed out.
 */
enum class LiquidGlassThemeCategory {
    LIGHT,
    DARK,
    PURE_BLACK
}

@Immutable
data class ClassifiedLiquidGlassStyle(
    val category: LiquidGlassThemeCategory,
    val baseSurfaceColor: Color,
    val tintAccentColor: Color,
    val ambientGlowColor: Color,
    val specularHighlightColor: Color,
    val refractionEdgeColor: Color,
    val borderBrush: Brush,
    val contentColor: Color,
    val secondaryContentColor: Color,
    val activeAccentColor: Color,
    val indicatorContainerColor: Color,
)

/**
 * Normalizes an accent color so low-luminance album art or dark dynamic seeds
 * are lifted in brightness before tinting the Liquid Glass surface.
 */
private fun normalizeGlassAccent(
    rawAccent: Color,
    primaryColor: Color,
    targetMinLuminance: Float,
    targetMaxLuminance: Float,
): Color {
    val safePrimary = if (primaryColor.luminance() < 0.22f) {
        lerp(primaryColor, Color.White, 0.38f)
    } else {
        primaryColor
    }
    var candidate = lerp(rawAccent, safePrimary, 0.28f)
    val lum = candidate.luminance()
    if (lum < targetMinLuminance) {
        val liftFraction = ((targetMinLuminance - lum) / (1f - lum).coerceAtLeast(0.2f))
            .coerceIn(0.18f, 0.55f)
        candidate = lerp(candidate, Color.White, liftFraction)
    } else if (lum > targetMaxLuminance) {
        val toneDownFraction = ((lum - targetMaxLuminance) / lum.coerceAtLeast(0.2f))
            .coerceIn(0.15f, 0.45f)
        candidate = lerp(candidate, safePrimary, toneDownFraction)
    }
    return candidate
}

/**
 * Classifies the current Material3 theme palette, dark/light state, Pure Black setting,
 * and optional album/custom accent color into a luminous, balanced [ClassifiedLiquidGlassStyle].
 */
fun classifyLiquidGlassTheme(
    backgroundColor: Color,
    surfaceContainerColor: Color,
    primaryColor: Color,
    secondaryContainerColor: Color,
    onSurfaceColor: Color,
    onSurfaceVariantColor: Color,
    outlineVariantColor: Color,
    pureBlack: Boolean = false,
    dominantColor: Color = Color.Unspecified,
    customSurfaceTint: Color = Color.Unspecified,
    surfaceOpacity: Float = 0.80f,
    saturation: Float = 1.15f,
    depthEffect: Float = 0.35f,
): ClassifiedLiquidGlassStyle {
    val isDarkSurface = backgroundColor.luminance() < 0.45f
    val category = when {
        pureBlack && isDarkSurface -> LiquidGlassThemeCategory.PURE_BLACK
        isDarkSurface -> LiquidGlassThemeCategory.DARK
        else -> LiquidGlassThemeCategory.LIGHT
    }

    val rawAccent = when {
        dominantColor != Color.Unspecified -> dominantColor
        customSurfaceTint != Color.Unspecified -> customSurfaceTint
        else -> primaryColor
    }

    val saturationFactor = ((saturation - 1f).coerceIn(-0.3f, 0.8f) * 0.16f)
    val clampedDepth = depthEffect.coerceIn(0f, 1f)
    val effectiveOpacity = surfaceOpacity.coerceIn(0.65f, 0.95f)

    return when (category) {
        LiquidGlassThemeCategory.LIGHT -> {
            // Keep light glass bright, airy, and pastel-tinted even if album art is dark
            val harmonizedAccent = normalizeGlassAccent(
                rawAccent = rawAccent,
                primaryColor = primaryColor,
                targetMinLuminance = 0.48f,
                targetMaxLuminance = 0.86f,
            )
            val liftedLightBase = lerp(surfaceContainerColor, Color.White, 0.42f)
            val tintStrength = (0.14f + saturationFactor).coerceIn(0.08f, 0.22f)
            val baseSurface = lerp(liftedLightBase, harmonizedAccent, tintStrength)
                .copy(alpha = effectiveOpacity.coerceIn(0.76f, 0.94f))

            val ambientGlow = lerp(harmonizedAccent, Color.White, 0.55f)
                .copy(alpha = (0.24f + 0.10f * clampedDepth).coerceIn(0.18f, 0.36f))
            val specularTop = Color.White.copy(alpha = (0.38f + 0.14f * clampedDepth).coerceIn(0.28f, 0.54f))
            val refractionBottom = harmonizedAccent.copy(alpha = (0.12f + 0.08f * clampedDepth).coerceIn(0.08f, 0.22f))

            val borderBrush = Brush.linearGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.78f),
                    harmonizedAccent.copy(alpha = 0.36f),
                    lerp(outlineVariantColor, Color.White, 0.35f).copy(alpha = 0.50f)
                )
            )

            ClassifiedLiquidGlassStyle(
                category = category,
                baseSurfaceColor = baseSurface,
                tintAccentColor = harmonizedAccent,
                ambientGlowColor = ambientGlow,
                specularHighlightColor = specularTop,
                refractionEdgeColor = refractionBottom,
                borderBrush = borderBrush,
                contentColor = onSurfaceColor,
                secondaryContentColor = onSurfaceVariantColor,
                activeAccentColor = primaryColor,
                indicatorContainerColor = lerp(secondaryContainerColor, harmonizedAccent, 0.22f)
            )
        }

        LiquidGlassThemeCategory.DARK -> {
            // Lift dark surfaces and accents so Liquid Glass in dark mode feels luminous and airy, never pitch-dark
            val harmonizedAccent = normalizeGlassAccent(
                rawAccent = rawAccent,
                primaryColor = primaryColor,
                targetMinLuminance = 0.38f,
                targetMaxLuminance = 0.78f,
            )
            val liftedDarkBase = lerp(surfaceContainerColor, Color.White, 0.12f)
            val tintStrength = (0.22f + saturationFactor).coerceIn(0.14f, 0.32f)
            val baseSurface = lerp(liftedDarkBase, harmonizedAccent, tintStrength)
                .copy(alpha = effectiveOpacity.coerceIn(0.70f, 0.88f))

            val ambientGlow = lerp(harmonizedAccent, Color.White, 0.30f)
                .copy(alpha = (0.18f + 0.10f * clampedDepth).coerceIn(0.14f, 0.28f))
            val specularTop = Color.White.copy(alpha = (0.15f + 0.09f * clampedDepth).coerceIn(0.11f, 0.25f))
            val refractionBottom = harmonizedAccent.copy(alpha = (0.16f + 0.10f * clampedDepth).coerceIn(0.10f, 0.26f))

            val borderBrush = Brush.linearGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.28f),
                    lerp(harmonizedAccent, Color.White, 0.22f).copy(alpha = 0.38f),
                    outlineVariantColor.copy(alpha = 0.28f)
                )
            )

            ClassifiedLiquidGlassStyle(
                category = category,
                baseSurfaceColor = baseSurface,
                tintAccentColor = harmonizedAccent,
                ambientGlowColor = ambientGlow,
                specularHighlightColor = specularTop,
                refractionEdgeColor = refractionBottom,
                borderBrush = borderBrush,
                contentColor = lerp(onSurfaceColor, Color.White, 0.15f),
                secondaryContentColor = lerp(onSurfaceVariantColor, Color.White, 0.12f),
                activeAccentColor = lerp(primaryColor, Color.White, 0.12f),
                indicatorContainerColor = lerp(secondaryContainerColor, harmonizedAccent, 0.28f)
            )
        }

        LiquidGlassThemeCategory.PURE_BLACK -> {
            // Smoked crystal glass for AMOLED: lifted charcoal-indigo with soft light sheen instead of pitch black
            val harmonizedAccent = normalizeGlassAccent(
                rawAccent = rawAccent,
                primaryColor = primaryColor,
                targetMinLuminance = 0.40f,
                targetMaxLuminance = 0.80f,
            )
            val smokedCrystalBase = Color(0xFF1A1D28)
            val tintStrength = (0.20f + saturationFactor).coerceIn(0.12f, 0.28f)
            val baseSurface = lerp(smokedCrystalBase, harmonizedAccent, tintStrength)
                .copy(alpha = effectiveOpacity.coerceIn(0.72f, 0.88f))

            val ambientGlow = lerp(harmonizedAccent, Color.White, 0.25f)
                .copy(alpha = (0.16f + 0.08f * clampedDepth).coerceIn(0.12f, 0.24f))
            val specularTop = Color.White.copy(alpha = (0.14f + 0.07f * clampedDepth).coerceIn(0.10f, 0.22f))
            val refractionBottom = harmonizedAccent.copy(alpha = (0.14f + 0.08f * clampedDepth).coerceIn(0.10f, 0.22f))

            val borderBrush = Brush.linearGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.26f),
                    harmonizedAccent.copy(alpha = 0.34f),
                    Color.White.copy(alpha = 0.14f)
                )
            )

            ClassifiedLiquidGlassStyle(
                category = category,
                baseSurfaceColor = baseSurface,
                tintAccentColor = harmonizedAccent,
                ambientGlowColor = ambientGlow,
                specularHighlightColor = specularTop,
                refractionEdgeColor = refractionBottom,
                borderBrush = borderBrush,
                contentColor = Color.White,
                secondaryContentColor = Color.White.copy(alpha = 0.78f),
                activeAccentColor = lerp(harmonizedAccent, Color.White, 0.45f),
                indicatorContainerColor = lerp(harmonizedAccent, Color.White, 0.20f).copy(alpha = 0.24f)
            )
        }
    }
}

@Composable
fun rememberClassifiedLiquidGlassStyle(
    pureBlack: Boolean = false,
    dominantColor: Color = Color.Unspecified,
    customSurfaceTint: Color = Color.Unspecified,
    surfaceOpacity: Float = 0.80f,
    saturation: Float = 1.15f,
    depthEffect: Float = 0.35f,
): ClassifiedLiquidGlassStyle {
    val colorScheme = MaterialTheme.colorScheme
    return remember(
        colorScheme.background,
        colorScheme.surfaceContainerHigh,
        colorScheme.primary,
        colorScheme.secondaryContainer,
        colorScheme.onSurface,
        colorScheme.onSurfaceVariant,
        colorScheme.outlineVariant,
        pureBlack,
        dominantColor,
        customSurfaceTint,
        surfaceOpacity,
        saturation,
        depthEffect,
    ) {
        classifyLiquidGlassTheme(
            backgroundColor = colorScheme.background,
            surfaceContainerColor = colorScheme.surfaceContainerHigh,
            primaryColor = colorScheme.primary,
            secondaryContainerColor = colorScheme.secondaryContainer,
            onSurfaceColor = colorScheme.onSurface,
            onSurfaceVariantColor = colorScheme.onSurfaceVariant,
            outlineVariantColor = colorScheme.outlineVariant,
            pureBlack = pureBlack,
            dominantColor = dominantColor,
            customSurfaceTint = customSurfaceTint,
            surfaceOpacity = surfaceOpacity,
            saturation = saturation,
            depthEffect = depthEffect,
        )
    }
}

/**
 * Theme-classified Liquid Glass modifier.
 * Automatically classifies Light Mode, Dark Mode, Pure Black, and Theme/Album colors
 * before drawing a luminous frosted glass finish with ambient glow and crisp rim refraction.
 */
fun Modifier.liquidGlass(
    enabled: Boolean = true,
    blurRadiusDp: Float = 16f,
    saturation: Float = 1.15f,
    refractionHeight: Float = 12f,
    refractionAmount: Float = 18f,
    chromaticAberration: Float = 0.15f,
    depthEffect: Float = 0.35f,
    surfaceOpacity: Float = 0.80f,
    surfaceTintColor: Color = Color.Unspecified,
    dominantColor: Color = Color.Unspecified,
    pureBlack: Boolean = false,
    shape: Shape = RoundedCornerShape(24.dp)
): Modifier = composed {
    if (!enabled) {
        if (surfaceTintColor != Color.Unspecified) {
            this.clip(shape).background(surfaceTintColor, shape)
        } else {
            this
        }
    } else {
        val style = rememberClassifiedLiquidGlassStyle(
            pureBlack = pureBlack,
            dominantColor = dominantColor,
            customSurfaceTint = surfaceTintColor,
            surfaceOpacity = surfaceOpacity,
            saturation = saturation,
            depthEffect = depthEffect,
        )

        val refractionRatio = (refractionAmount / 100f).coerceIn(0.05f, 0.38f)
        val chromaticShift = chromaticAberration.coerceIn(0f, 1f) * 0.08f

        this
            .clip(shape)
            .background(style.baseSurfaceColor, shape)
            .drawWithCache {
                val glowRadius = max(size.width, size.height).coerceAtLeast(1f) * 0.9f
                val ambientGlowBrush = Brush.radialGradient(
                    colors = listOf(
                        style.ambientGlowColor,
                        style.ambientGlowColor.copy(alpha = style.ambientGlowColor.alpha * 0.35f),
                        Color.Transparent,
                    ),
                    center = Offset(size.width * 0.25f, size.height * 0.18f),
                    radius = glowRadius,
                )
                val sheenBrush = Brush.linearGradient(
                    colorStops = arrayOf(
                        0.0f to style.specularHighlightColor,
                        (0.38f + refractionRatio * 0.35f).coerceIn(0.28f, 0.68f) to style.refractionEdgeColor.copy(
                            alpha = style.refractionEdgeColor.alpha * 0.55f
                        ),
                        1.0f to style.refractionEdgeColor.copy(
                            alpha = (style.refractionEdgeColor.alpha + chromaticShift).coerceIn(0.05f, 0.24f)
                        )
                    ),
                    start = Offset(0f, 0f),
                    end = Offset(size.width * 0.9f, size.height)
                )
                onDrawWithContent {
                    drawRect(brush = ambientGlowBrush)
                    drawRect(brush = sheenBrush)
                    drawContent()
                }
            }
            .border(width = 1.dp, brush = style.borderBrush, shape = shape)
    }
}

@Composable
fun LiquidGlassContainer(
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    blurRadiusDp: Float = 16f,
    saturation: Float = 1.15f,
    refractionHeight: Float = 12f,
    refractionAmount: Float = 18f,
    chromaticAberration: Float = 0.15f,
    depthEffect: Float = 0.35f,
    surfaceOpacity: Float = 0.80f,
    surfaceTintColor: Color = Color.Unspecified,
    dominantColor: Color = Color.Unspecified,
    pureBlack: Boolean = false,
    shape: Shape = RoundedCornerShape(24.dp),
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier.liquidGlass(
            enabled = enabled,
            blurRadiusDp = blurRadiusDp,
            saturation = saturation,
            refractionHeight = refractionHeight,
            refractionAmount = refractionAmount,
            chromaticAberration = chromaticAberration,
            depthEffect = depthEffect,
            surfaceOpacity = surfaceOpacity,
            surfaceTintColor = surfaceTintColor,
            dominantColor = dominantColor,
            pureBlack = pureBlack,
            shape = shape,
        ),
        content = content
    )
}
