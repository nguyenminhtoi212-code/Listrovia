/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 * 
 * Unified AI Provider definition and registry. All AI providers are consolidated 
 * into this single shared file as requested, ensuring zero file fragmentation.
 */

package com.listrovia.music.ai

import com.listrovia.music.ui.component.ProviderVisualInfo
import com.listrovia.music.ui.component.ProviderDetailedSpec
import com.listrovia.music.ui.component.getProviderDetailedSpec
import com.listrovia.music.ui.component.getProviderVisualInfo

interface AiProvider {
    val id: String
    val visualInfo: ProviderVisualInfo
    val detailedSpec: ProviderDetailedSpec
}

object OpenRouterProvider : AiProvider {
    override val id = "OpenRouter"
    override val visualInfo = getProviderVisualInfo(id)
    override val detailedSpec = getProviderDetailedSpec(id)
}

object HuggingFaceProvider : AiProvider {
    override val id = "HuggingFace"
    override val visualInfo = getProviderVisualInfo(id)
    override val detailedSpec = getProviderDetailedSpec(id)
}

object AionLabsProvider : AiProvider {
    override val id = "AionLabs"
    override val visualInfo = getProviderVisualInfo(id)
    override val detailedSpec = getProviderDetailedSpec(id)
}

object DeepInfraProvider : AiProvider {
    override val id = "DeepInfra"
    override val visualInfo = getProviderVisualInfo(id)
    override val detailedSpec = getProviderDetailedSpec(id)
}

object NvidiaProvider : AiProvider {
    override val id = "Nvidia"
    override val visualInfo = getProviderVisualInfo(id)
    override val detailedSpec = getProviderDetailedSpec(id)
}

object GroqProvider : AiProvider {
    override val id = "Groq"
    override val visualInfo = getProviderVisualInfo(id)
    override val detailedSpec = getProviderDetailedSpec(id)
}

object OpenAiProvider : AiProvider {
    override val id = "OpenAI"
    override val visualInfo = getProviderVisualInfo(id)
    override val detailedSpec = getProviderDetailedSpec(id)
}

object PerplexityProvider : AiProvider {
    override val id = "Perplexity"
    override val visualInfo = getProviderVisualInfo(id)
    override val detailedSpec = getProviderDetailedSpec(id)
}

object AnthropicProvider : AiProvider {
    override val id = "Anthropic"
    override val visualInfo = getProviderVisualInfo(id)
    override val detailedSpec = getProviderDetailedSpec(id)
}

object GoogleProvider : AiProvider {
    override val id = "Google"
    override val visualInfo = getProviderVisualInfo(id)
    override val detailedSpec = getProviderDetailedSpec(id)
}

object XAiProvider : AiProvider {
    override val id = "xAI"
    override val visualInfo = getProviderVisualInfo(id)
    override val detailedSpec = getProviderDetailedSpec(id)
}

object MistralProvider : AiProvider {
    override val id = "Mistral"
    override val visualInfo = getProviderVisualInfo(id)
    override val detailedSpec = getProviderDetailedSpec(id)
}

object InceptionProvider : AiProvider {
    override val id = "Inception"
    override val visualInfo = getProviderVisualInfo(id)
    override val detailedSpec = getProviderDetailedSpec(id)
}

object OrcaRouterProvider : AiProvider {
    override val id = "OrcaRouter"
    override val visualInfo = getProviderVisualInfo(id)
    override val detailedSpec = getProviderDetailedSpec(id)
}

object DeepLProvider : AiProvider {
    override val id = "DeepL"
    override val visualInfo = getProviderVisualInfo(id)
    override val detailedSpec = getProviderDetailedSpec(id)
}

object CustomProvider : AiProvider {
    override val id = "Custom"
    override val visualInfo = getProviderVisualInfo(id)
    override val detailedSpec = getProviderDetailedSpec(id)
}

object AiProviderRegistry {
    private val providers = mutableMapOf<String, AiProvider>()

    init {
        register(OpenRouterProvider)
        register(HuggingFaceProvider)
        register(AionLabsProvider)
        register(DeepInfraProvider)
        register(NvidiaProvider)
        register(GroqProvider)
        register(OpenAiProvider)
        register(PerplexityProvider)
        register(AnthropicProvider)
        register(GoogleProvider)
        register(XAiProvider)
        register(MistralProvider)
        register(InceptionProvider)
        register(OrcaRouterProvider)
        register(DeepLProvider)
        register(CustomProvider)
    }

    fun register(provider: AiProvider) {
        providers[provider.id] = provider
    }

    fun get(id: String): AiProvider? = providers[id] ?: providers[id.lowercase()]
    fun getAll(): List<AiProvider> = providers.values.toList()
}
