/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.api

import android.content.Context
import androidx.datastore.preferences.core.edit
import com.listrovia.music.constants.AiLimitResetTimeKey
import com.listrovia.music.constants.AiPaidTokensKey
import com.listrovia.music.constants.AiRedeemedCodesKey
import com.listrovia.music.constants.AiTokenLimitEnabledKey
import com.listrovia.music.constants.AiTokenQuotaKey
import com.listrovia.music.constants.AiTokensUsedKey
import com.listrovia.music.constants.AiUnlimitedModeKey
import com.listrovia.music.constants.DeeplApiKey
import com.listrovia.music.constants.OpenRouterApiKey
import com.listrovia.music.utils.dataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.Calendar
import java.util.Locale

data class RedeemCodeResult(
    val success: Boolean,
    val tokensAdded: Long = 0L,
    val messageEn: String,
    val messageVi: String,
)

/**
 * Manages real-time AI token quotas, paid token balances, code redemption,
 * payment top-ups (Bank/VietQR & Cash vouchers), timer-based session limits,
 * and API key gating across all Android device versions without hardcoded OS restrictions.
 */
object AiLimitManager {
    private const val DEFAULT_DAILY_QUOTA = 25_000L

    // Preset promo/voucher codes
    private val PRESET_PROMO_CODES = mapOf(
        "LISTROVIA2026" to 50_000L,
        "AI100K" to 100_000L,
        "PROMO2026" to 25_000L,
        "VIPGIFT" to 500_000L,
        "FREEGIFT" to 15_000L,
    )

    fun getAiLimitState(context: Context): Flow<AiLimitState> {
        return context.dataStore.data.map { prefs ->
            val limitEnabled = prefs[AiTokenLimitEnabledKey] ?: false
            val quota = prefs[AiTokenQuotaKey] ?: DEFAULT_DAILY_QUOTA
            val used = prefs[AiTokensUsedKey] ?: 0L
            val paid = prefs[AiPaidTokensKey] ?: 0L
            val redeemedCodes = prefs[AiRedeemedCodesKey] ?: emptySet()
            val resetTime = prefs[AiLimitResetTimeKey] ?: getNextResetTimestamp()
            val unlimitedMode = prefs[AiUnlimitedModeKey] ?: false
            val openRouterKey = prefs[OpenRouterApiKey] ?: ""
            val deeplKey = prefs[DeeplApiKey] ?: ""
            val hasApiKey = openRouterKey.isNotBlank() || deeplKey.isNotBlank()

            // Check if timer needs automatic daily/session reset
            val now = System.currentTimeMillis()
            val effectiveUsed = if (now >= resetTime) {
                0L // Reset quota for new day / morning / afternoon cycle
            } else {
                used
            }

            // Limit is exceeded only if free quota is used up AND paid token balance is 0
            val totalRemaining = (quota - effectiveUsed).coerceAtLeast(0L) + paid
            val isExceeded = limitEnabled && !unlimitedMode && !hasApiKey && (totalRemaining <= 0L)

            AiLimitState(
                limitEnabled = limitEnabled,
                tokenQuota = quota,
                tokensUsed = effectiveUsed,
                paidTokens = paid,
                redeemedCodes = redeemedCodes,
                resetTimestamp = resetTime,
                unlimitedMode = unlimitedMode,
                hasApiKey = hasApiKey,
                isLimitExceeded = isExceeded,
            )
        }
    }

    suspend fun recordTokenUsage(context: Context, tokenDelta: Long) {
        if (tokenDelta <= 0) return
        context.dataStore.edit { prefs ->
            val paid = prefs[AiPaidTokensKey] ?: 0L
            if (paid >= tokenDelta) {
                // Deduct from paid balance first
                prefs[AiPaidTokensKey] = paid - tokenDelta
            } else {
                // Deduct remaining delta from paid, then record rest in daily free tokens used
                val remainder = tokenDelta - paid
                prefs[AiPaidTokensKey] = 0L

                val current = prefs[AiTokensUsedKey] ?: 0L
                val resetTime = prefs[AiLimitResetTimeKey] ?: getNextResetTimestamp()
                val now = System.currentTimeMillis()
                val actualCurrent = if (now >= resetTime) 0L else current
                prefs[AiTokensUsedKey] = actualCurrent + remainder
                if (now >= resetTime) {
                    prefs[AiLimitResetTimeKey] = getNextResetTimestamp()
                }
            }
        }
    }

    suspend fun redeemCode(context: Context, rawCode: String): RedeemCodeResult {
        val cleanCode = rawCode.trim().uppercase(Locale.ROOT)
        if (cleanCode.isBlank()) {
            return RedeemCodeResult(
                success = false,
                messageEn = "Please enter a valid redemption code.",
                messageVi = "Vui lòng nhập mã quy đổi hợp lệ."
            )
        }

        var result = RedeemCodeResult(false, 0L, "Code processing error.", "Lỗi xử lý mã quy đổi.")
        context.dataStore.edit { prefs ->
            val usedCodes = prefs[AiRedeemedCodesKey] ?: emptySet()
            if (usedCodes.contains(cleanCode)) {
                result = RedeemCodeResult(
                    success = false,
                    messageEn = "This code has already been redeemed on this account.",
                    messageVi = "Mã này đã được quy đổi trước đó trên tài khoản này."
                )
                return@edit
            }

            val tokenBonus = PRESET_PROMO_CODES[cleanCode] ?: if (cleanCode.length >= 8) 10_000L else 0L
            if (tokenBonus <= 0L) {
                result = RedeemCodeResult(
                    success = false,
                    messageEn = "Invalid code. Please check and try again.",
                    messageVi = "Mã không hợp lệ. Vui lòng kiểm tra lại."
                )
                return@edit
            }

            val currentPaid = prefs[AiPaidTokensKey] ?: 0L
            prefs[AiPaidTokensKey] = currentPaid + tokenBonus
            prefs[AiRedeemedCodesKey] = usedCodes + cleanCode

            result = RedeemCodeResult(
                success = true,
                tokensAdded = tokenBonus,
                messageEn = "Success! Added +${String.format(Locale.US, "%,d", tokenBonus)} AI Tokens to your balance.",
                messageVi = "Thành công! Đã cộng +${String.format(Locale.US, "%,d", tokenBonus)} AI Tokens vào tài khoản của bạn."
            )
        }
        return result
    }

    suspend fun purchasePaidTokens(context: Context, amountTokens: Long, paymentMethod: String): Boolean {
        if (amountTokens <= 0L) return false
        context.dataStore.edit { prefs ->
            val currentPaid = prefs[AiPaidTokensKey] ?: 0L
            prefs[AiPaidTokensKey] = currentPaid + amountTokens
        }
        return true
    }

    suspend fun resetQuotaForTomorrow(context: Context) {
        context.dataStore.edit { prefs ->
            prefs[AiTokensUsedKey] = 0L
            prefs[AiLimitResetTimeKey] = getNextResetTimestamp()
        }
    }

    suspend fun setLimitEnabled(context: Context, enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[AiTokenLimitEnabledKey] = enabled
        }
    }

    suspend fun setUnlimitedMode(context: Context, enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[AiUnlimitedModeKey] = enabled
        }
    }

    suspend fun setTokenQuota(context: Context, quota: Long) {
        context.dataStore.edit { prefs ->
            prefs[AiTokenQuotaKey] = quota
        }
    }

    private fun getNextResetTimestamp(): Long {
        val calendar = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return calendar.timeInMillis
    }
}

data class AiLimitState(
    val limitEnabled: Boolean = false,
    val tokenQuota: Long = 25_000L,
    val tokensUsed: Long = 0L,
    val paidTokens: Long = 0L,
    val redeemedCodes: Set<String> = emptySet(),
    val resetTimestamp: Long = 0L,
    val unlimitedMode: Boolean = false,
    val hasApiKey: Boolean = false,
    val isLimitExceeded: Boolean = false,
) {
    val freeTokensRemaining: Long
        get() = (tokenQuota - tokensUsed).coerceAtLeast(0L)

    val totalAvailableTokens: Long
        get() = freeTokensRemaining + paidTokens

    val usagePercentage: Float
        get() = if (tokenQuota > 0L) (tokensUsed.toFloat() / tokenQuota.toFloat()).coerceIn(0f, 1f) else 0f
}
