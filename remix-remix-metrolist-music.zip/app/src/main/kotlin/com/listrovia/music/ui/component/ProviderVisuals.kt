/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.component

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.listrovia.music.R

data class ProviderVisualInfo(
    val name: String,
    val brandColor: Color,
    val accentColor: Color,
    val iconRes: Int? = null,
    val shortTag: String,
    val monogram: String,
)

enum class ModelSourceCategory(val labelRes: Int) {
    ALL(R.string.ai_source_filter_all),
    VERIFIED(R.string.ai_source_filter_verified),
    COMMUNITY(R.string.ai_source_filter_community),
    DEVELOPER(R.string.ai_source_filter_developer),
}

enum class ModelHealthStatus(
    val labelRes: Int,
    val textColor: Color,
    val backgroundColor: Color,
    val borderColor: Color,
) {
    STABLE(
        labelRes = R.string.ai_badge_stable,
        textColor = Color(0xFF2E7D32),
        backgroundColor = Color(0xFFE8F5E9),
        borderColor = Color(0xFF81C784),
    ),
    BETA(
        labelRes = R.string.ai_badge_beta,
        textColor = Color(0xFF1976D2),
        backgroundColor = Color(0xFFE3F2FD),
        borderColor = Color(0xFF90CAF9),
    ),
    PENDING(
        labelRes = R.string.ai_badge_pending,
        textColor = Color(0xFF7B1FA2),
        backgroundColor = Color(0xFFF3E5F5),
        borderColor = Color(0xFFCE93D8),
    ),
    DEVELOPER(
        labelRes = R.string.ai_badge_developer,
        textColor = Color(0xFFE65100),
        backgroundColor = Color(0xFFFFF3E0),
        borderColor = Color(0xFFFFB74D),
    ),
}

enum class ModelServiceHealth(
    val labelRes: Int,
    val indicatorColor: Color,
    val backgroundColor: Color,
    val borderColor: Color,
) {
    ONLINE(
        labelRes = R.string.ai_health_online,
        indicatorColor = Color(0xFF2E7D32),
        backgroundColor = Color(0xFFE8F5E9),
        borderColor = Color(0xFFA5D6A7),
    ),
    HIGH_LATENCY(
        labelRes = R.string.ai_health_high_latency,
        indicatorColor = Color(0xFFE65100),
        backgroundColor = Color(0xFFFFF3E0),
        borderColor = Color(0xFFFFCC80),
    ),
    FAST(
        labelRes = R.string.ai_health_fast,
        indicatorColor = Color(0xFF00838F),
        backgroundColor = Color(0xFFE0F7FA),
        borderColor = Color(0xFF80DEEA),
    ),
}

fun getModelServiceHealth(
    modelId: String,
    name: String = "",
    contextLength: Long = 0L,
): ModelServiceHealth {
    val idLower = modelId.lowercase().trim()
    val nameLower = name.lowercase().trim()

    // 1. Fast models
    if (idLower.contains("flash") || idLower.contains("turbo") ||
        idLower.contains("instant") || idLower.contains("speed") ||
        idLower.contains("mini") || idLower.contains("8b") ||
        idLower.contains("small")) {
        return ModelServiceHealth.FAST
    }

    // 2. High latency models: large context (>131k), reasoning models, deep thinking (>70B)
    if (contextLength >= 131072L || idLower.contains("r1") || idLower.contains("reasoner") ||
        idLower.contains("thinking") || idLower.contains("o1") || idLower.contains("o3") ||
        nameLower.contains("reasoning") || idLower.contains("70b") || idLower.contains("405b") ||
        idLower.contains("deepseek-r1")) {
        return ModelServiceHealth.HIGH_LATENCY
    }

    // 3. Default active online status
    return ModelServiceHealth.ONLINE
}

fun getModelSourceCategory(modelId: String, providerName: String = ""): ModelSourceCategory {
    val idLower = modelId.lowercase().trim()
    val pLower = providerName.lowercase().trim()

    // 1. Developer / Bleeding-edge models
    if (idLower.contains("dev") || idLower.contains("developer") ||
        idLower.contains("preview") || idLower.contains("alpha") ||
        idLower.contains("exp-") || idLower.contains("experimental") ||
        idLower.contains("test") || idLower.contains("instruct-dev")) {
        return ModelSourceCategory.DEVELOPER
    }

    // 2. Verified Major Providers
    val verifiedVendors = listOf(
        "google", "openai", "anthropic", "meta", "meta-llama", "deepseek",
        "mistral", "mistralai", "qwen", "alibaba", "nvidia", "microsoft",
        "x-ai", "xai", "cohere", "perplexity", "amazon"
    )
    val vendor = if (idLower.contains("/")) idLower.substringBefore("/") else pLower
    if (verifiedVendors.contains(vendor) || verifiedVendors.contains(pLower)) {
        return ModelSourceCategory.VERIFIED
    }

    // 3. Otherwise Community / Partner Models
    return ModelSourceCategory.COMMUNITY
}

fun getModelHealthStatus(modelId: String, name: String = ""): ModelHealthStatus {
    val idLower = modelId.lowercase().trim()
    val nameLower = name.lowercase().trim()

    return when {
        idLower.contains("dev") || idLower.contains("developer") || idLower.contains("preview") || idLower.contains("alpha") -> {
            ModelHealthStatus.DEVELOPER
        }
        idLower.contains("beta") || idLower.contains("free") || idLower.contains("exp") || nameLower.contains("beta") -> {
            ModelHealthStatus.BETA
        }
        idLower.contains("pending") || idLower.contains("rc") || idLower.contains("eval") -> {
            ModelHealthStatus.PENDING
        }
        else -> {
            ModelHealthStatus.STABLE
        }
    }
}

fun getProviderVisualInfo(modelId: String, providerName: String = ""): ProviderVisualInfo {
    val idLower = modelId.lowercase()
    val pLower = providerName.lowercase().trim()

    return when {
        idLower.startsWith("google/") || idLower.contains("gemini") || pLower == "google" -> {
            ProviderVisualInfo(
                name = "Google",
                brandColor = Color(0xFF4285F4),
                accentColor = Color(0xFF34A853),
                iconRes = R.drawable.google,
                shortTag = "Google",
                monogram = "G",
            )
        }
        idLower.startsWith("openai/") || idLower.contains("gpt-") || idLower.contains("o1-") || idLower.contains("o3-") || idLower.contains("o4-") || pLower == "openai" -> {
            ProviderVisualInfo(
                name = "OpenAI",
                brandColor = Color(0xFF10A37F),
                accentColor = Color(0xFF007A5E),
                iconRes = R.drawable.discover_tune,
                shortTag = "OpenAI",
                monogram = "OA",
            )
        }
        idLower.startsWith("deepseek") || idLower.contains("deepseek") || pLower.contains("deepseek") -> {
            ProviderVisualInfo(
                name = "DeepSeek",
                brandColor = Color(0xFF1E88E5),
                accentColor = Color(0xFF0D47A1),
                iconRes = R.drawable.star,
                shortTag = "DeepSeek",
                monogram = "DS",
            )
        }
        idLower.startsWith("anthropic/") || idLower.contains("claude") || pLower == "anthropic" -> {
            ProviderVisualInfo(
                name = "Anthropic",
                brandColor = Color(0xFFD97706),
                accentColor = Color(0xFFB45309),
                iconRes = R.drawable.token,
                shortTag = "Anthropic",
                monogram = "CL",
            )
        }
        idLower.startsWith("meta-llama/") || idLower.startsWith("meta/") || idLower.contains("llama") || pLower.contains("meta") -> {
            ProviderVisualInfo(
                name = "Meta",
                brandColor = Color(0xFF0668E1),
                accentColor = Color(0xFF04489B),
                iconRes = R.drawable.integration,
                shortTag = "Meta",
                monogram = "L",
            )
        }
        idLower.startsWith("mistralai/") || idLower.contains("mistral") || idLower.contains("codestral") || pLower.contains("mistral") -> {
            ProviderVisualInfo(
                name = "Mistral AI",
                brandColor = Color(0xFFFF5722),
                accentColor = Color(0xFFE64A19),
                iconRes = R.drawable.tune,
                shortTag = "Mistral",
                monogram = "M",
            )
        }
        idLower.startsWith("qwen/") || idLower.contains("qwen") || pLower.contains("qwen") || pLower.contains("alibaba") -> {
            ProviderVisualInfo(
                name = "Qwen",
                brandColor = Color(0xFF7C3AED),
                accentColor = Color(0xFF6D28D9),
                iconRes = R.drawable.cloud,
                shortTag = "Qwen",
                monogram = "Q",
            )
        }
        idLower.startsWith("nvidia/") || idLower.contains("nvidia") || idLower.contains("nemotron") || pLower == "nvidia" -> {
            ProviderVisualInfo(
                name = "NVIDIA",
                brandColor = Color(0xFF76B900),
                accentColor = Color(0xFF5C9100),
                iconRes = R.drawable.explore_outlined,
                shortTag = "NVIDIA",
                monogram = "NV",
            )
        }
        idLower.startsWith("microsoft/") || idLower.contains("phi-") || pLower == "microsoft" -> {
            ProviderVisualInfo(
                name = "Microsoft",
                brandColor = Color(0xFF00A4EF),
                accentColor = Color(0xFF0078D7),
                iconRes = R.drawable.grid_view,
                shortTag = "Microsoft",
                monogram = "MS",
            )
        }
        idLower.startsWith("x-ai/") || idLower.contains("grok") || pLower == "xai" || pLower == "x-ai" -> {
            ProviderVisualInfo(
                name = "xAI",
                brandColor = Color(0xFF27272A),
                accentColor = Color(0xFF18181B),
                iconRes = R.drawable.discover_tune,
                shortTag = "xAI",
                monogram = "X",
            )
        }
        idLower.startsWith("perplexity/") || idLower.contains("sonar") || pLower == "perplexity" -> {
            ProviderVisualInfo(
                name = "Perplexity",
                brandColor = Color(0xFF0D9488),
                accentColor = Color(0xFF0F766E),
                iconRes = R.drawable.search,
                shortTag = "Perplexity",
                monogram = "P",
            )
        }
        else -> {
            val fallbackName = when {
                providerName.isNotBlank() -> providerName.replaceFirstChar { it.uppercase() }
                modelId.contains("/") -> modelId.substringBefore("/").replaceFirstChar { it.uppercase() }
                else -> "AI"
            }
            val initial = fallbackName.take(2).uppercase()
            ProviderVisualInfo(
                name = fallbackName,
                brandColor = Color(0xFF6366F1),
                accentColor = Color(0xFF4F46E5),
                iconRes = R.drawable.explore_outlined,
                shortTag = fallbackName,
                monogram = initial,
            )
        }
    }
}

@Composable
fun ProviderAvatar(
    modelId: String,
    providerName: String = "",
    modifier: Modifier = Modifier,
    size: Dp = 32.dp,
) {
    val info = remember(modelId, providerName) { getProviderVisualInfo(modelId, providerName) }

    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.28f))
            .background(
                Brush.linearGradient(
                    listOf(info.brandColor, info.accentColor)
                )
            )
            .border(
                width = 1.dp,
                color = Color.White.copy(alpha = 0.25f),
                shape = RoundedCornerShape(size * 0.28f)
            ),
        contentAlignment = Alignment.Center,
    ) {
        if (info.iconRes != null && (info.name == "Google" || info.name == "DeepSeek" || info.name == "Meta" || info.name == "OpenAI")) {
            Icon(
                painter = painterResource(info.iconRes),
                contentDescription = info.name,
                tint = Color.White,
                modifier = Modifier.size(size * 0.58f)
            )
        } else {
            Text(
                text = info.monogram,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = (size.value * 0.40f).sp,
                maxLines = 1,
                softWrap = false,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
        }
    }
}

@Composable
fun ProviderBadge(
    modelId: String,
    providerName: String = "",
    modifier: Modifier = Modifier,
    showLabel: Boolean = true,
) {
    val info = remember(modelId, providerName) { getProviderVisualInfo(modelId, providerName) }

    Surface(
        modifier = modifier,
        color = info.brandColor.copy(alpha = 0.12f),
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, info.brandColor.copy(alpha = 0.35f)),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(info.brandColor)
            )
            if (showLabel) {
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = info.shortTag,
                    style = MaterialTheme.typography.labelSmall,
                    color = info.brandColor,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.sp,
                )
            }
        }
    }
}

@Composable
fun ModelStatusBadge(
    status: ModelHealthStatus,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        color = status.backgroundColor,
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(0.7.dp, status.borderColor),
    ) {
        Text(
            text = stringResource(status.labelRes),
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
            ),
            color = status.textColor,
            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.5.dp),
        )
    }
}

@Composable
fun ModelServiceHealthBadge(
    health: ModelServiceHealth,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        color = health.backgroundColor,
        shape = RoundedCornerShape(4.dp),
        border = BorderStroke(0.7.dp, health.borderColor),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.5.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(5.dp)
                    .clip(CircleShape)
                    .background(health.indicatorColor)
            )
            Text(
                text = stringResource(health.labelRes),
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                ),
                color = health.indicatorColor,
            )
        }
    }
}

@Composable
fun ModelSourceCategoryChips(
    selectedCategory: ModelSourceCategory,
    onSelectCategory: (ModelSourceCategory) -> Unit,
    modifier: Modifier = Modifier,
) {
    val scrollState = rememberScrollState()
    Row(
        modifier = modifier
            .horizontalScroll(scrollState)
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ModelSourceCategory.entries.forEach { cat ->
            val isSelected = cat == selectedCategory
            FilterChip(
                selected = isSelected,
                onClick = { onSelectCategory(cat) },
                label = {
                    Text(
                        text = stringResource(cat.labelRes),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    )
                },
                shape = RoundedCornerShape(8.dp),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = isSelected,
                    borderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                    selectedBorderColor = MaterialTheme.colorScheme.primary,
                ),
            )
        }
    }
}
