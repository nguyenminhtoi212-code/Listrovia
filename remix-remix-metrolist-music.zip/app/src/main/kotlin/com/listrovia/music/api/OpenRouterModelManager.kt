/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.api

import android.content.Context
import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.statement.bodyAsText
import io.ktor.http.isSuccess
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import timber.log.Timber
import java.io.File
import java.util.Locale
import java.util.concurrent.TimeUnit

data class OpenRouterModelItem(
    val id: String,
    val name: String,
    val providerName: String = "",
    val contextLength: Long = 0L,
    val pricing: String = "",
    val description: String = "",
)

data class ClassifiedModels(
    val official: List<OpenRouterModelItem> = emptyList(),   // Phiên bản chính thức (Stable)
    val beta: List<OpenRouterModelItem> = emptyList(),       // Phiên bản thử nghiệm (Beta)
    val developer: List<OpenRouterModelItem> = emptyList(),  // Phiên bản nhà phát triển (Preview/Dev/Experimental)
)

data class MemoryCache(
    val timestamp: Long,
    val data: ClassifiedModels,
)

/**
 * Trình quản lý mô hình OpenRouter tự động tải trực tiếp theo thời gian thực từ
 * https://openrouter.ai/api/v1/models, phân loại và lưu cache bộ nhớ & lưu trữ ngoại tuyến.
 * Tự động trích xuất thông tin nhà cung cấp (providerName) để hiển thị huy hiệu trực quan.
 */
class OpenRouterModelManager(
    cacheTTLMinutes: Long = 15L,
    private val context: Context? = null,
) {
    private val apiUrl = "https://openrouter.ai/api/v1/models"
    private val storageKey = "openrouter_models_realtime_v3"
    private val cacheTTL = cacheTTLMinutes * 60 * 1000L
    private var _memoryCache: MemoryCache? = null
    private val fetchMutex = Mutex()

    private val ktorClient: HttpClient by lazy {
        HttpClient(OkHttp) {
            install(HttpTimeout) {
                requestTimeoutMillis = 6_000L
                connectTimeoutMillis = 5_000L
                socketTimeoutMillis = 6_000L
            }
            expectSuccess = false
        }
    }

    private val client =
        OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(6, TimeUnit.SECONDS)
            .build()

    private fun isNetworkAvailable(): Boolean {
        val ctx = context ?: return true
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager ?: return false
        val activeNet = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(activeNet) ?: return false
        return caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /**
     * Tải và phân loại danh sách mô hình AI theo thời gian thực từ OpenRouter API.
     */
    suspend fun fetchAndClassifyModels(forceRefresh: Boolean = false): ClassifiedModels =
        withContext(Dispatchers.IO) {
            fetchMutex.withLock {
                val now = System.currentTimeMillis()
                val cached = _memoryCache
                if (!forceRefresh && cached != null && (now - cached.timestamp < cacheTTL)) {
                    val hasModels = cached.data.official.isNotEmpty() || cached.data.beta.isNotEmpty() || cached.data.developer.isNotEmpty()
                    if (hasModels) {
                        return@withLock cached.data
                    }
                }

                if (!isNetworkAvailable()) {
                    Timber.d("Không có mạng, lấy danh sách mô hình AI từ bộ nhớ đệm / fallback nội bộ ngay lập tức")
                    val fallback = _getOfflineFallback()
                    _memoryCache = MemoryCache(timestamp = now, data = fallback)
                    return@withLock fallback
                }

                try {
                    val responseBody = try {
                        val response = ktorClient.get(apiUrl) {
                            header("User-Agent", "Mozilla/5.0 (Android; Listrovia Music/1.0)")
                            header("Accept", "application/json")
                            header("HTTP-Referer", "https://listrovia.cc")
                            header("X-Title", "Listrovia Music")
                        }
                        if (!response.status.isSuccess()) {
                            throw Exception("Ktor HTTP Error: ${response.status.value}")
                        }
                        val body = response.bodyAsText()
                        if (body.isBlank()) throw Exception("Empty response body from Ktor")
                        body
                    } catch (ktorErr: Exception) {
                        Timber.w(ktorErr, "Ktor request to OpenRouter failed, trying OkHttp fallback")
                        val request =
                            Request.Builder()
                                .url(apiUrl)
                                .addHeader("User-Agent", "Mozilla/5.0 (Android; Listrovia Music/1.0)")
                                .addHeader("Accept", "application/json")
                                .addHeader("HTTP-Referer", "https://listrovia.cc")
                                .addHeader("X-Title", "Listrovia Music")
                                .get()
                                .build()

                        val response = client.newCall(request).execute()
                        if (!response.isSuccessful) {
                            throw Exception("HTTP Error: ${response.code}")
                        }
                        response.body?.string() ?: throw Exception("Empty response body")
                    }

                    val rawData = JSONObject(responseBody)
                    val rawModels = rawData.optJSONArray("data") ?: JSONArray()

                    val modelList = mutableListOf<RawModelData>()
                    for (i in 0 until rawModels.length()) {
                        val obj = rawModels.optJSONObject(i) ?: continue
                        val id = obj.optString("id", "").trim()
                        if (id.isBlank()) continue
                        val name = obj.optString("name", id)
                        val description = obj.optString("description", "")
                        val contextLength = obj.optLong("context_length", 0L)
                        val pricingObj = obj.optJSONObject("pricing")
                        val pricingStr = formatPricingFromApi(pricingObj, id)
                        val provider = if (id.contains("/")) id.substringBefore("/") else ""
                        modelList.add(
                            RawModelData(
                                id = id,
                                name = name,
                                provider = provider,
                                contextLength = contextLength,
                                pricing = pricingStr,
                                description = description,
                            )
                        )
                    }

                    if (modelList.isEmpty()) {
                        throw Exception("OpenRouter API returned empty model list")
                    }

                    val classified = _classifyModels(modelList)
                    _clearMemory()

                    val newMemory = MemoryCache(timestamp = now, data = classified)
                    _memoryCache = newMemory
                    saveToOfflineStorage(newMemory)

                    return@withLock classified
                } catch (error: Exception) {
                    Timber.w(error, "Lỗi kết nối hoặc tải dữ liệu OpenRouter. Đang lấy từ bộ nhớ đệm / fallback...")
                    val fallback = _getOfflineFallback()
                    _memoryCache = MemoryCache(timestamp = now, data = fallback)
                    return@withLock fallback
                }
            }
        }

    private fun formatPricingFromApi(pricingObj: JSONObject?, modelId: String): String {
        if (modelId.endsWith(":free", ignoreCase = true)) return "Free"
        if (pricingObj == null) return ""
        val promptPerToken = pricingObj.optString("prompt", "").toDoubleOrNull() ?: return ""
        val completionPerToken = pricingObj.optString("completion", "").toDoubleOrNull() ?: promptPerToken
        if (promptPerToken <= 0.0 && completionPerToken <= 0.0) return "Free"
        val promptPerMillion = promptPerToken * 1_000_000.0
        val completionPerMillion = completionPerToken * 1_000_000.0
        return String.format(Locale.US, "$%.2f / $%.2f", promptPerMillion, completionPerMillion)
    }

    private fun _classifyModels(models: List<RawModelData>): ClassifiedModels {
        val official = mutableListOf<OpenRouterModelItem>()
        val beta = mutableListOf<OpenRouterModelItem>()
        val developer = mutableListOf<OpenRouterModelItem>()

        models.forEach { model ->
            val id = model.id.lowercase()
            val name = (model.name ?: "").lowercase()
            val provider = if (model.provider.isNotBlank()) model.provider else (if (model.id.contains("/")) model.id.substringBefore("/") else "openrouter")

            val cleanedItem =
                OpenRouterModelItem(
                    id = model.id,
                    name = model.name?.ifBlank { model.id } ?: model.id,
                    providerName = provider,
                    contextLength = model.contextLength,
                    pricing = model.pricing,
                    description = model.description,
                )

            if (id.contains("dev") || id.contains("preview") || id.contains("exp") || name.contains("developer")) {
                developer.add(cleanedItem)
            } else if (id.contains("beta") || name.contains("beta") || id.contains("free")) {
                beta.add(cleanedItem)
            } else {
                official.add(cleanedItem)
            }
        }

        return ClassifiedModels(
            official = official,
            beta = beta,
            developer = developer,
        )
    }

    fun _clearMemory() {
        _memoryCache = null
    }

    private suspend fun _getOfflineFallback(): ClassifiedModels {
        // 1. Thử đọc từ Room Database
        context?.let { ctx ->
            try {
                val roomModels = com.listrovia.music.db.AiModelCacheDatabase.getInstance(ctx).aiModelCacheDao().getModelsByProvider("OpenRouter")
                if (roomModels.isNotEmpty()) {
                    fun mapToItem(entity: com.listrovia.music.db.entities.AiModelCacheEntity) = OpenRouterModelItem(
                        id = entity.id,
                        name = entity.name,
                        providerName = entity.providerName,
                        contextLength = entity.contextLength,
                        pricing = entity.pricingBadge,
                        description = entity.description,
                    )
                    val official = roomModels.filter { it.tier == "Official" }.map { mapToItem(it) }
                    val beta = roomModels.filter { it.tier == "Beta" }.map { mapToItem(it) }
                    val dev = roomModels.filter { it.tier == "Developer" }.map { mapToItem(it) }
                    if (official.isNotEmpty() || beta.isNotEmpty() || dev.isNotEmpty()) {
                        return ClassifiedModels(official = official, beta = beta, developer = dev)
                    }
                }
            } catch (e: Exception) {
                Timber.w(e, "Lỗi đọc Room cache")
            }
        }

        // 2. Thử đọc từ tệp file cache
        try {
            val file = getCacheFile()
            if (file != null && file.exists()) {
                val saved = file.readText()
                if (saved.isNotBlank()) {
                    val parsed = JSONObject(saved)
                    val dataObj = parsed.optJSONObject("data")
                    if (dataObj != null) {
                        val parsedModels = parseClassifiedFromJson(dataObj)
                        if (parsedModels.official.isNotEmpty() || parsedModels.beta.isNotEmpty() || parsedModels.developer.isNotEmpty()) {
                            return parsedModels
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Lỗi đọc dữ liệu cache cũ từ bộ nhớ thiết bị")
        }

        // Không trả về danh sách mô hình giả lập cố định; trả về rỗng nếu chưa có bộ nhớ đệm API để luôn dùng dữ liệu thời gian thực từ API
        return ClassifiedModels()
    }

    private suspend fun saveToOfflineStorage(cache: MemoryCache) {
        try {
            val file = getCacheFile()
            if (file != null) {
                val root = JSONObject()
                root.put("timestamp", cache.timestamp)

                val dataObj = JSONObject()
                dataObj.put("official", modelListToJsonArray(cache.data.official))
                dataObj.put("beta", modelListToJsonArray(cache.data.beta))
                dataObj.put("developer", modelListToJsonArray(cache.data.developer))

                root.put("data", dataObj)
                file.writeText(root.toString())
            }

            // Lưu dữ liệu vào Room Database cục bộ
            context?.let { ctx ->
                val entities = mutableListOf<com.listrovia.music.db.entities.AiModelCacheEntity>()
                fun addTier(items: List<OpenRouterModelItem>, tierName: String) {
                    items.forEach { item ->
                        entities.add(
                            com.listrovia.music.db.entities.AiModelCacheEntity(
                                id = item.id,
                                provider = "OpenRouter",
                                name = item.name,
                                providerName = item.providerName,
                                tier = tierName,
                                sourceCategory = com.listrovia.music.ui.component.getModelSourceCategory(item.id, item.providerName).name,
                                healthStatus = com.listrovia.music.ui.component.getModelHealthStatus(item.id, item.name).name,
                                contextLength = item.contextLength,
                                pricingBadge = item.pricing,
                                description = item.description,
                                cachedAt = cache.timestamp,
                            )
                        )
                    }
                }
                addTier(cache.data.official, "Official")
                addTier(cache.data.beta, "Beta")
                addTier(cache.data.developer, "Developer")
                com.listrovia.music.db.AiModelCacheDatabase.getInstance(ctx).aiModelCacheDao().insertModels(entities)
            }
        } catch (e: Exception) {
            Timber.e(e, "Không thể lưu bộ nhớ đệm offline vào Room/File")
        }
    }

    private fun getCacheFile(): File? {
        val dir = context?.cacheDir ?: File(System.getProperty("java.io.tmpdir") ?: ".")
        return File(dir, "$storageKey.json")
    }

    private fun modelListToJsonArray(list: List<OpenRouterModelItem>): JSONArray {
        val arr = JSONArray()
        list.forEach { item ->
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("name", item.name)
            obj.put("provider", item.providerName)
            obj.put("contextLength", item.contextLength)
            obj.put("pricing", item.pricing)
            obj.put("description", item.description)
            arr.put(obj)
        }
        return arr
    }

    private fun parseClassifiedFromJson(obj: JSONObject): ClassifiedModels {
        fun parseList(key: String): List<OpenRouterModelItem> {
            val arr = obj.optJSONArray(key) ?: return emptyList()
            val list = mutableListOf<OpenRouterModelItem>()
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val id = item.optString("id", "")
                val provider = item.optString("provider", if (id.contains("/")) id.substringBefore("/") else "")
                list.add(
                    OpenRouterModelItem(
                        id = id,
                        name = item.optString("name", id),
                        providerName = provider,
                        contextLength = item.optLong("contextLength", 0L),
                        pricing = item.optString("pricing", ""),
                        description = item.optString("description", ""),
                    ),
                )
            }
            return list
        }

        return ClassifiedModels(
            official = parseList("official"),
            beta = parseList("beta"),
            developer = parseList("developer"),
        )
    }

    suspend fun getModelsForApp(): List<OpenRouterModelItem> {
        val models = fetchAndClassifyModels()
        return models.official
    }

    suspend fun getModelsByTier(tier: String): List<OpenRouterModelItem> {
        val classified = fetchAndClassifyModels()
        return when (tier.lowercase()) {
            "beta" -> classified.beta
            "developer", "dev" -> classified.developer
            else -> classified.official
        }
    }

    suspend fun getRandomRecommendedModel(
        tier: String? = null,
        forceRefresh: Boolean = false,
    ): OpenRouterModelItem? {
        val classified = fetchAndClassifyModels(forceRefresh = forceRefresh)
        val pool = when (tier?.lowercase()) {
            "beta" -> classified.beta
            "developer", "dev" -> classified.developer
            "stable", "official" -> classified.official
            else -> classified.official + classified.beta + classified.developer
        }.filter { it.id.isNotBlank() }

        return pool.randomOrNull()
    }

    companion object {
        @Volatile
        private var defaultManager: OpenRouterModelManager? = null

        fun getInstance(context: Context? = null, cacheTTLMinutes: Long = 15L): OpenRouterModelManager {
            return defaultManager ?: synchronized(this) {
                defaultManager ?: OpenRouterModelManager(cacheTTLMinutes, context?.applicationContext).also {
                    defaultManager = it
                }
            }
        }

        suspend fun getModelsForApp(context: Context? = null): List<OpenRouterModelItem> {
            return getInstance(context).getModelsForApp()
        }
    }
}

private data class RawModelData(
    val id: String,
    val name: String?,
    val provider: String = "",
    val contextLength: Long = 0L,
    val pricing: String = "",
    val description: String = "",
)
