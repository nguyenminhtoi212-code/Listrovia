package com.listrovia.innertube.utils

import android.content.Context
import android.content.res.Configuration
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.listrovia.innertube.models.AlbumItem
import com.listrovia.innertube.models.ArtistItem
import com.listrovia.innertube.models.EpisodeItem
import com.listrovia.innertube.models.PlaylistItem
import com.listrovia.innertube.models.PodcastItem
import com.listrovia.innertube.models.SongItem
import com.listrovia.innertube.models.YTItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import timber.log.Timber
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Comprehensive Content Moderation & Family Protection Engine for InnerTube.
 * Protects users across devices (Mobile Phone, Tablet/iPad, Desktop/Laptop, Android TV) and regions/IPs.
 * Filters out scam/fraudulent promotions, phishing links, abusive comments, sensitive media,
 * and regulates shared YouTube Music content as well as home and external search queries.
 */
object SongContentModerator {
    private const val TAG = "SongContentModerator"

    // Counters for blocked threats
    private val _blockedScamCount = MutableStateFlow(0)
    val blockedScamCount: StateFlow<Int> = _blockedScamCount.asStateFlow()

    private val _blockedViolationsCount = MutableStateFlow(0)
    val blockedViolationsCount: StateFlow<Int> = _blockedViolationsCount.asStateFlow()

    private val _detectedFormFactor = MutableStateFlow("Phone")
    val detectedFormFactor: StateFlow<String> = _detectedFormFactor.asStateFlow()

    private val _detectedRegion = MutableStateFlow(Locale.getDefault().country.ifEmpty { "VN" })
    val detectedRegion: StateFlow<String> = _detectedRegion.asStateFlow()

    private val _detectedCountryName = MutableStateFlow("Việt Nam / Vietnam")
    val detectedCountryName: StateFlow<String> = _detectedCountryName.asStateFlow()

    private val _detectedIp = MutableStateFlow("Household IP / Mạng gia đình")
    val detectedIp: StateFlow<String> = _detectedIp.asStateFlow()

    private val _detectedHouseholdStatus = MutableStateFlow("Bảo vệ mạng gia đình an toàn / Family Guard Active")
    val detectedHouseholdStatus: StateFlow<String> = _detectedHouseholdStatus.asStateFlow()

    private val _isRegionRestricted = MutableStateFlow(false)
    val isRegionRestricted: StateFlow<Boolean> = _isRegionRestricted.asStateFlow()

    private val _outsideSearchCensorshipActive = MutableStateFlow(true)
    val outsideSearchCensorshipActive: StateFlow<Boolean> = _outsideSearchCensorshipActive.asStateFlow()

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(5, TimeUnit.SECONDS)
            .build()
    }

    // 1. Phishing, fraud, and scam keywords
    private val scamKeywords = listOf(
        "lừa đảo", "lua dao", "hack tiền", "nhận quà miễn phí", "tặng thẻ cào",
        "crypto pump", "free robux", "giveaway scam", "whatsapp crypto", "telegram signal",
        "click here for free", "claim your prize", "bot farm", "phishing", "free gift card",
        "hack coin", "mod unlimited money", "free vbucks", "earn 1000$ per day",
        "kiếm tiền online lừa đảo", "nạp thẻ cào giả mạo", "fake token", "airdrop scam",
        "bẫy tài chính", "cờ bạc bịp", "hack like", "hack view ảo"
    )

    // 2. Sensitive, offensive, and illegal violation keywords
    private val violationKeywords = listOf(
        "prohibited_explicit_test", "nsfw_sample", "restricted_content_flag",
        "bạo lực cực đoan", "hate speech", "violent gore", "illegal stream crack",
        "warez rip", "suicide encourage", "deepfake porn", "snuff",
        "khiêu dâm độc hại", "xúc phạm danh dự", "nội dung phản cảm cấm", "phát tán mã độc"
    )

    // 3. Prohibited comment spam and malicious redirection patterns
    private val suspiciousUrlPatterns = listOf(
        "bit.ly/", "t.me/", "tinyurl.com/", "wa.me/", "goo.gl/", "click.ru/", "freebonus",
        "shorturl.at/", "cutt.ly/", "adf.ly/", "linkvertise.com/"
    )

    enum class DeviceFormFactor {
        MOBILE_PHONE,
        TABLET_IPAD,
        LAPTOP_PC,
        ANDROID_TV
    }

    /**
     * Updates device environment and regional IP/locale configuration.
     */
    fun updateEnvironment(context: Context, regionCode: String? = null) {
        val formFactor = detectDeviceFormFactor(context)
        _detectedFormFactor.value = when (formFactor) {
            DeviceFormFactor.MOBILE_PHONE -> "Điện thoại di động (Phone)"
            DeviceFormFactor.TABLET_IPAD -> "Máy tính bảng / iPad (Tablet)"
            DeviceFormFactor.LAPTOP_PC -> "Máy tính xách tay / PC (Desktop)"
            DeviceFormFactor.ANDROID_TV -> "Tivi thông minh (Android TV)"
        }

        val region = regionCode?.takeIf { it != "system" && it != "SYSTEM_DEFAULT" }
            ?: Locale.getDefault().country.ifEmpty { "VN" }
        _detectedRegion.value = region.uppercase()
        updateCountryName(region.uppercase())

        // Asynchronously check IP and household network status
        detectPublicIpAndCountry(context)
    }

    fun detectDeviceFormFactor(context: Context): DeviceFormFactor {
        val config = context.resources.configuration
        val uiMode = config.uiMode and Configuration.UI_MODE_TYPE_MASK
        if (uiMode == Configuration.UI_MODE_TYPE_TELEVISION) {
            return DeviceFormFactor.ANDROID_TV
        }
        val screenWidthDp = config.screenWidthDp
        return when {
            screenWidthDp >= 900 -> DeviceFormFactor.LAPTOP_PC
            screenWidthDp >= 600 -> DeviceFormFactor.TABLET_IPAD
            else -> DeviceFormFactor.MOBILE_PHONE
        }
    }

    /**
     * Inspects IP, country code, and network classification asynchronously.
     */
    fun detectPublicIpAndCountry(context: Context) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val connMgr = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                val activeNetwork = connMgr?.activeNetwork
                val caps = connMgr?.getNetworkCapabilities(activeNetwork)
                val isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true

                _detectedHouseholdStatus.value = if (isWifi) {
                    "Mạng Wi-Fi gia đình (Family Household Wi-Fi)"
                } else {
                    "Mạng di động cá nhân (Cellular Network)"
                }

                val request = Request.Builder()
                    .url("https://api.country.is/")
                    .header("User-Agent", "Listrovia-SafeGuard/1.0")
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string()
                        if (!body.isNullOrBlank()) {
                            val json = JSONObject(body)
                            val ip = json.optString("ip", "")
                            val country = json.optString("country", "")
                            if (ip.isNotBlank()) {
                                _detectedIp.value = ip
                            }
                            if (country.isNotBlank()) {
                                _detectedRegion.value = country.uppercase()
                                updateCountryName(country.uppercase())
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.tag(TAG).d("IP and Geolocation lookup fallback to Locale: ${e.message}")
            }
        }
    }

    private fun updateCountryName(countryCode: String) {
        _detectedCountryName.value = when (countryCode) {
            "VN" -> "Việt Nam (Vietnam)"
            "US" -> "Hoa Kỳ (United States)"
            "JP" -> "Nhật Bản (Japan)"
            "KR" -> "Hàn Quốc (South Korea)"
            "SG" -> "Singapore"
            "GB", "UK" -> "Vương quốc Anh (United Kingdom)"
            "DE" -> "Đức (Germany)"
            "FR" -> "Pháp (France)"
            "CA" -> "Canada"
            "AU" -> "Úc (Australia)"
            "IN" -> "Ấn Độ (India)"
            "TH" -> "Thái Lan (Thailand)"
            "ID" -> "Indonesia"
            "PH" -> "Philippines"
            "MY" -> "Malaysia"
            else -> "$countryCode (International)"
        }
    }

    /**
     * Validates shared YouTube Music URL or text.
     * Prevents sharing or receiving scam links, malicious shorteners, and banned video content.
     */
    fun isSharedUrlAllowed(urlOrText: String): Boolean {
        val lower = urlOrText.lowercase(Locale.ROOT).trim()
        if (lower.isBlank()) return true

        // Reject known malicious shorteners or redirect trackers
        for (pattern in suspiciousUrlPatterns) {
            if (lower.contains(pattern)) {
                _blockedScamCount.value += 1
                Timber.tag(TAG).w("Blocked malicious shared link: $urlOrText")
                return false
            }
        }

        // Check for scam words embedded in shared text
        for (scam in scamKeywords) {
            if (lower.contains(scam)) {
                _blockedScamCount.value += 1
                Timber.tag(TAG).w("Blocked scam keyword in shared content: $urlOrText")
                return false
            }
        }

        // Check for severe violations
        for (violation in violationKeywords) {
            if (lower.contains(violation)) {
                _blockedViolationsCount.value += 1
                Timber.tag(TAG).w("Blocked violating keyword in shared content: $urlOrText")
                return false
            }
        }

        return true
    }

    /**
     * Checks if a title & artist name is compliant and free of scams and violations.
     */
    fun isAllowed(title: String, artistName: String? = null): Boolean {
        val combined = "$title ${artistName.orEmpty()}".lowercase(Locale.ROOT)

        for (scam in scamKeywords) {
            if (combined.contains(scam)) {
                _blockedScamCount.value += 1
                Timber.tag(TAG).w("Blocked scam/fraud item: matched '$scam' in '$title'")
                return false
            }
        }

        for (violation in violationKeywords) {
            if (combined.contains(violation)) {
                _blockedViolationsCount.value += 1
                Timber.tag(TAG).w("Blocked violating content: matched '$violation' in '$title'")
                return false
            }
        }

        return true
    }

    /**
     * Validates any generic YTItem (Song, Album, Playlist, Artist, Episode).
     */
    fun isItemAllowed(item: YTItem): Boolean {
        val title = item.title
        val artist = when (item) {
            is SongItem -> item.artists.joinToString(" ") { it.name }
            is AlbumItem -> item.artists?.joinToString(" ") { it.name }
            is PlaylistItem -> item.author?.name
            is ArtistItem -> item.title
            is EpisodeItem -> item.author?.name
            is PodcastItem -> item.author?.name
            else -> ""
        }
        if (!isAllowed(title, artist)) return false
        if (!isThumbnailSafe(item.thumbnail)) return false
        return true
    }

    /**
     * Validates in-app search queries and search suggestions.
     */
    fun isSearchAllowed(query: String): Boolean {
        val q = query.lowercase(Locale.ROOT).trim()
        if (q.isBlank()) return true

        for (scam in scamKeywords) {
            if (q.contains(scam)) {
                _blockedScamCount.value += 1
                Timber.tag(TAG).w("Blocked scam search query: '$query'")
                return false
            }
        }
        for (violation in violationKeywords) {
            if (q.contains(violation)) {
                _blockedViolationsCount.value += 1
                Timber.tag(TAG).w("Blocked violating search query: '$query'")
                return false
            }
        }
        return true
    }

    /**
     * Validates queries originating outside the home page or from deep links / external sources.
     */
    fun isOutsideSearchAllowed(query: String): Boolean {
        if (!_outsideSearchCensorshipActive.value) return isSearchAllowed(query)
        val q = query.lowercase(Locale.ROOT).trim()
        if (q.isBlank()) return true

        if (!isSearchAllowed(q)) return false

        // Stricter check for external / outside search queries
        for (pattern in suspiciousUrlPatterns) {
            if (q.contains(pattern)) {
                _blockedScamCount.value += 1
                return false
            }
        }
        return true
    }

    /**
     * Validates user comments to prevent spam, scam links, and abusive behavior.
     */
    fun isCommentAllowed(text: String): Boolean {
        val content = text.lowercase(Locale.ROOT)
        for (pattern in suspiciousUrlPatterns) {
            if (content.contains(pattern)) {
                _blockedScamCount.value += 1
                Timber.tag(TAG).w("Blocked scam link in comment: '$text'")
                return false
            }
        }
        for (scam in scamKeywords) {
            if (content.contains(scam)) {
                _blockedScamCount.value += 1
                Timber.tag(TAG).w("Blocked scam keyword in comment: '$text'")
                return false
            }
        }
        for (violation in violationKeywords) {
            if (content.contains(violation)) {
                _blockedViolationsCount.value += 1
                Timber.tag(TAG).w("Blocked violating keyword in comment: '$text'")
                return false
            }
        }
        return true
    }

    /**
     * Verifies thumbnail URL safety.
     */
    fun isThumbnailSafe(url: String?): Boolean {
        if (url == null) return true
        val lower = url.lowercase(Locale.ROOT)
        for (pattern in suspiciousUrlPatterns) {
            if (lower.contains(pattern)) return false
        }
        return true
    }

    fun setOutsideSearchCensorship(enabled: Boolean) {
        _outsideSearchCensorshipActive.value = enabled
    }
}
