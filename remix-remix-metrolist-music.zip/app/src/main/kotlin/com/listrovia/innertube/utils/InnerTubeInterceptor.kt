package com.listrovia.innertube.utils

import okhttp3.Interceptor
import okhttp3.Response
import timber.log.Timber
import java.io.IOException
import kotlinx.serialization.SerializationException

/**
 * Ktor/OkHttp Interceptor that logs all InnerTube API request and response flows using Timber,
 * categorizing errors into 'Data Structure Mismatches' or 'Parsing Failures' and pushing them to InnerTubeLogBuffer.
 */
class InnerTubeInterceptor : Interceptor {
    private val TAG = "InnerTubeNetwork"

    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val url = request.url.toString()
        val startTime = System.currentTimeMillis()

        InnerTubeLogger.logRequest(url, request.method)

        val response = try {
            chain.proceed(request)
        } catch (e: SerializationException) {
            val msg = "[Parsing Failures] Serialization error: ${e.message}"
            Timber.tag(TAG).e(e, msg)
            InnerTubeLogBuffer.addLog(ApiLogEntry.LogCategory.PARSING_FAILURE, msg, url)
            throw e
        } catch (e: IOException) {
            val msg = "[Data Structure Mismatches] Network/IO error: ${e.message}"
            Timber.tag(TAG).e(e, msg)
            InnerTubeLogBuffer.addLog(ApiLogEntry.LogCategory.DATA_STRUCTURE_MISMATCH, msg, url)
            throw e
        } catch (e: Exception) {
            val msg = "[Data Structure Mismatches] Unexpected exception: ${e.message}"
            Timber.tag(TAG).e(e, msg)
            InnerTubeLogBuffer.addLog(ApiLogEntry.LogCategory.DATA_STRUCTURE_MISMATCH, msg, url)
            throw e
        }

        val duration = System.currentTimeMillis() - startTime
        val code = response.code

        if (code in 200..299) {
            InnerTubeLogger.logResponse(url, code, response.body?.contentLength()?.toInt() ?: 0)
        } else {
            val msg = "[Data Structure Mismatches] HTTP status $code in ${duration}ms (Breaking API change suspected)"
            Timber.tag(TAG).w(msg)
            InnerTubeLogBuffer.addLog(ApiLogEntry.LogCategory.DATA_STRUCTURE_MISMATCH, msg, url)
        }

        return response
    }
}
