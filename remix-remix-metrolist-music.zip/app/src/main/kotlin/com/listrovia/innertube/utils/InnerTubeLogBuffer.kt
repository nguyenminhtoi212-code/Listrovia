package com.listrovia.innertube.utils

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Real-time API log buffer capturing categorized errors ('Data Structure Mismatches' or 'Parsing Failures').
 * (Bộ đệm log thời gian thực lưu trữ các lỗi lệch cấu trúc dữ liệu hoặc phân tích mô hình).
 */
data class ApiLogEntry(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: String = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()),
    val category: LogCategory,
    val message: String,
    val url: String
) {
    enum class LogCategory {
        DATA_STRUCTURE_MISMATCH,
        PARSING_FAILURE,
        INFO
    }
}

object InnerTubeLogBuffer {
    private val _logs = MutableStateFlow<List<ApiLogEntry>>(emptyList())
    val logs: StateFlow<List<ApiLogEntry>> = _logs.asStateFlow()

    private const val MAX_LOGS = 100

    @Synchronized
    fun addLog(category: ApiLogEntry.LogCategory, message: String, url: String) {
        val entry = ApiLogEntry(category = category, message = message, url = url)
        val current = _logs.value.toMutableList()
        current.add(0, entry)
        if (current.size > MAX_LOGS) {
            current.removeAt(current.size - 1)
        }
        _logs.value = current
    }

    @Synchronized
    fun clearLogs() {
        _logs.value = emptyList()
    }
}
