package com.listrovia.innertube.utils

import android.content.Context
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import timber.log.Timber
import java.io.IOException

/**
 * Network interceptor or utility function to check the user's IP location via an external API
 * and compare it against the configured restricted countries list to prevent playback and search access.
 *
 * Prevents playback (/player, /watch) and search access (/search, /get_search_suggestions, /next)
 * when the user's detected geolocation belongs to a restricted territory.
 */
object RegionalRestrictionInterceptor : Interceptor {
    private const val TAG = "RegionalRestrictionInterceptor"

    /**
     * Utility function to check the user's IP location via an external API and compare
     * it against the configured restricted countries list to prevent playback and search access.
     */
    fun checkUserIpLocationAndEnforce(context: Context, onResult: ((Boolean) -> Unit)? = null) {
        SongContentModerator.checkUserIpLocationAndEnforce(context, onResult)
    }

    /**
     * Utility function to evaluate whether playback and search access is currently restricted.
     */
    fun isAccessRestricted(): Boolean {
        return SongContentModerator.isAccessRestricted()
    }

    @Throws(IOException::class)
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val path = request.url.encodedPath

        val isPlaybackOrSearchEndpoint = path.contains("/player") ||
                path.contains("/watch") ||
                path.contains("/search") ||
                path.contains("/get_search_suggestions") ||
                path.contains("/next")

        if (isPlaybackOrSearchEndpoint && SongContentModerator.isAccessRestricted()) {
            val country = SongContentModerator.detectedRegion.value
            Timber.tag(TAG).w("Regional restriction enforced: Blocking $path for country '$country'")

            // Synthesize an HTTP 403 Forbidden Response to cleanly halt InnerTube network access
            val errorJson = """
                {
                    "error": {
                        "code": 403,
                        "message": "Access to playback and search is restricted in your region ($country) by compliance policy.",
                        "status": "PERMISSION_DENIED"
                    }
                }
            """.trimIndent()

            return Response.Builder()
                .request(request)
                .protocol(Protocol.HTTP_1_1)
                .code(403)
                .message("Forbidden: Regional Restriction Active ($country)")
                .body(errorJson.toResponseBody("application/json".toMediaType()))
                .build()
        }

        return chain.proceed(request)
    }
}
