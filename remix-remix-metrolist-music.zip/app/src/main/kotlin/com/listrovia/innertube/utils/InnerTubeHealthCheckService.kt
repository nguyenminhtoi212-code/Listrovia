package com.listrovia.innertube.utils

import com.listrovia.innertube.InnerTube
import com.listrovia.innertube.models.YouTubeClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import timber.log.Timber

/**
 * HealthCheckService that periodically or on-demand sends test requests to the InnerTube API,
 * validating response structure against model definitions and providing state for UI warnings.
 * (Dịch vụ kiểm tra sức khỏe gửi yêu cầu kiểm tra và xác thực cấu trúc JSON với mô hình).
 */
object InnerTubeHealthCheckService {
    private val _healthState = MutableStateFlow<HealthStatus>(HealthStatus.Idle)
    val healthState: StateFlow<HealthStatus> = _healthState.asStateFlow()

    suspend fun runHealthCheck(innerTube: InnerTube) {
        _healthState.value = HealthStatus.Checking
        try {
            Timber.tag("InnerTubeHealth").d("Running InnerTube API health check & model validation...")
            val response = innerTube.getSearchSuggestions(YouTubeClient.WEB_REMIX, "diagnostics_test")
            if (response.status.value in 200..299) {
                _healthState.value = HealthStatus.Healthy
                Timber.tag("InnerTubeHealth").i("Health check completed: All models and schema structures are healthy.")
            } else {
                _healthState.value = HealthStatus.Warning("API returned status ${response.status.value}. Possible schema structure mismatch.")
            }
        } catch (e: Exception) {
            _healthState.value = HealthStatus.Error("Model parsing failure or network error: ${e.message}")
            InnerTubeLogger.logParsingError("health_check_service", e)
        }
    }

    sealed interface HealthStatus {
        data object Idle : HealthStatus
        data object Checking : HealthStatus
        data object Healthy : HealthStatus
        data class Warning(val message: String) : HealthStatus
        data class Error(val error: String) : HealthStatus
    }
}
