package com.listrovia.innertube.utils

import com.listrovia.innertube.models.YTItem
import com.listrovia.innertube.models.response.BrowseResponse
import com.listrovia.innertube.models.response.GetSearchSuggestionsResponse
import com.listrovia.innertube.models.response.NextResponse
import com.listrovia.innertube.models.response.SearchResponse
import timber.log.Timber

/**
 * Filtering layer in the search and recommendation stream that intercepts raw InnerTube API
 * responses and prunes items flagged as sensitive, violent, or illegal based on updated
 * moderation guidelines.
 */
object InnerTubeStreamFilterLayer {
    private const val TAG = "InnerTubeFilterLayer"

    /**
     * Intercepts and prunes raw SearchResponse contents.
     */
    fun pruneSearchResponse(response: SearchResponse): SearchResponse {
        val tabbed = response.contents?.tabbedSearchResultsRenderer ?: return response
        val updatedTabs = tabbed.tabs?.mapNotNull { tab ->
            if (tab == null) return@mapNotNull null
            val sectionList = tab.tabRenderer?.content?.sectionListRenderer
            if (sectionList != null) {
                val updatedContents = sectionList.contents?.mapNotNull { section ->
                    when {
                        section.musicCardShelfRenderer != null -> {
                            val card = section.musicCardShelfRenderer
                            val title = card.header?.musicCardShelfHeaderBasicRenderer?.title?.runs?.firstOrNull()?.text ?: ""
                            val subtitle = card.subtitle?.runs?.firstOrNull()?.text ?: ""
                            if (!SongContentModerator.isAllowed(title, subtitle)) {
                                Timber.tag(TAG).w("Pruned musicCardShelfRenderer from search: '$title'")
                                null
                            } else {
                                section
                            }
                        }
                        section.musicShelfRenderer != null -> {
                            val shelf = section.musicShelfRenderer
                            val filteredContents = shelf.contents?.filter { content ->
                                val renderer = content.musicResponsiveListItemRenderer
                                if (renderer != null) {
                                    val title = renderer.flexColumns.firstOrNull()
                                        ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.text ?: ""
                                    val artist = renderer.flexColumns.getOrNull(1)
                                        ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.text ?: ""
                                    SongContentModerator.isAllowed(title, artist)
                                } else {
                                    true
                                }
                            }
                            section.copy(musicShelfRenderer = shelf.copy(contents = filteredContents))
                        }
                        section.itemSectionRenderer != null -> {
                            val itemSection = section.itemSectionRenderer
                            val filteredContents = itemSection.contents?.filter { content ->
                                val renderer = content.musicResponsiveListItemRenderer
                                if (renderer != null) {
                                    val title = renderer.flexColumns.firstOrNull()
                                        ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.text ?: ""
                                    val artist = renderer.flexColumns.getOrNull(1)
                                        ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.text ?: ""
                                    SongContentModerator.isAllowed(title, artist)
                                } else {
                                    true
                                }
                            }
                            section.copy(itemSectionRenderer = itemSection.copy(contents = filteredContents))
                        }
                        else -> section
                    }
                }
                tab.copy(
                    tabRenderer = tab.tabRenderer.copy(
                        content = tab.tabRenderer.content.copy(
                            sectionListRenderer = sectionList.copy(contents = updatedContents)
                        )
                    )
                )
            } else {
                tab
            }
        }.orEmpty()

        return response.copy(
            contents = response.contents.copy(
                tabbedSearchResultsRenderer = tabbed.copy(tabs = updatedTabs)
            )
        )
    }

    /**
     * Intercepts and prunes raw BrowseResponse (Home recommendation feed, Explore, Charts, New Releases).
     */
    fun pruneBrowseResponse(response: BrowseResponse): BrowseResponse {
        val singleColumn = response.contents?.singleColumnBrowseResultsRenderer ?: return response
        val tabs = singleColumn.tabs ?: return response

        val updatedTabs = tabs.mapNotNull { tab ->
            if (tab == null) return@mapNotNull null
            val sectionList = tab.tabRenderer?.content?.sectionListRenderer
            if (sectionList != null) {
                val updatedContents = sectionList.contents?.mapNotNull { content ->
                    val carousel = content.musicCarouselShelfRenderer
                    if (carousel != null) {
                        val filteredItems = carousel.contents.filter { item ->
                            val title = item.musicTwoRowItemRenderer?.title?.runs?.firstOrNull()?.text
                                ?: item.musicResponsiveListItemRenderer?.flexColumns?.firstOrNull()
                                    ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.text
                                ?: item.musicMultiRowListItemRenderer?.title?.runs?.firstOrNull()?.text
                                ?: ""
                            val subtitle = item.musicTwoRowItemRenderer?.subtitle?.runs?.firstOrNull()?.text
                                ?: item.musicResponsiveListItemRenderer?.flexColumns?.getOrNull(1)
                                    ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.text
                                ?: item.musicMultiRowListItemRenderer?.subtitle?.runs?.firstOrNull()?.text
                                ?: ""

                            if (title.isNotBlank() && !SongContentModerator.isAllowed(title, subtitle)) {
                                Timber.tag(TAG).w("Pruned recommendation item: '$title' / '$subtitle'")
                                false
                            } else {
                                true
                            }
                        }
                        content.copy(musicCarouselShelfRenderer = carousel.copy(contents = filteredItems))
                    } else {
                        content
                    }
                }
                tab.copy(
                    tabRenderer = tab.tabRenderer.copy(
                        content = tab.tabRenderer.content.copy(
                            sectionListRenderer = sectionList.copy(contents = updatedContents)
                        )
                    )
                )
            } else {
                tab
            }
        }.orEmpty()

        return response.copy(
            contents = response.contents.copy(
                singleColumnBrowseResultsRenderer = singleColumn.copy(tabs = updatedTabs)
            )
        )
    }

    /**
     * Intercepts and prunes raw NextResponse (Queue, Next, Up Next, Radio recommendations).
     */
    fun pruneNextResponse(response: NextResponse): NextResponse {
        val watchNext = response.contents.singleColumnMusicWatchNextResultsRenderer ?: return response
        val tabbed = watchNext.tabbedRenderer?.watchNextTabbedResultsRenderer ?: return response

        val updatedTabs = tabbed.tabs.map { tab ->
            val queue = tab.tabRenderer.content?.musicQueueRenderer
            val playlistPanel = queue?.content?.playlistPanelRenderer
            if (playlistPanel != null) {
                val filteredContents = playlistPanel.contents.filter { content ->
                    val panelVideo = content.playlistPanelVideoRenderer
                    if (panelVideo != null) {
                        val title = panelVideo.title?.runs?.firstOrNull()?.text ?: ""
                        val artist = panelVideo.longBylineText?.runs?.firstOrNull()?.text ?: ""
                        if (!SongContentModerator.isAllowed(title, artist)) {
                            Timber.tag(TAG).w("Pruned next recommendation: '$title' by '$artist'")
                            false
                        } else {
                            true
                        }
                    } else {
                        true
                    }
                }
                tab.copy(
                    tabRenderer = tab.tabRenderer.copy(
                        content = tab.tabRenderer.content.copy(
                            musicQueueRenderer = queue.copy(
                                content = queue.content.copy(
                                    playlistPanelRenderer = playlistPanel.copy(contents = filteredContents)
                                )
                            )
                        )
                    )
                )
            } else {
                tab
            }
        }

        return response.copy(
            contents = response.contents.copy(
                singleColumnMusicWatchNextResultsRenderer = watchNext.copy(
                    tabbedRenderer = watchNext.tabbedRenderer.copy(
                        watchNextTabbedResultsRenderer = tabbed.copy(tabs = updatedTabs)
                    )
                )
            )
        )
    }

    /**
     * Intercepts and prunes search suggestions and raw search suggestions response.
     */
    fun pruneSearchSuggestionsResponse(response: GetSearchSuggestionsResponse): GetSearchSuggestionsResponse {
        val updatedContents = response.contents?.map { section ->
            val ssSection = section.searchSuggestionsSectionRenderer
            if (ssSection != null) {
                val filteredSuggestions = ssSection.contents?.filter { item ->
                    val query = item.searchSuggestionRenderer?.suggestion?.runs?.joinToString("") { it.text } ?: ""
                    val title = item.musicResponsiveListItemRenderer?.flexColumns?.firstOrNull()
                        ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.text ?: ""
                    val subtitle = item.musicResponsiveListItemRenderer?.flexColumns?.getOrNull(1)
                        ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.text ?: ""

                    when {
                        query.isNotBlank() && !SongContentModerator.isSearchAllowed(query) -> {
                            Timber.tag(TAG).w("Pruned search suggestion query: '$query'")
                            false
                        }
                        title.isNotBlank() && !SongContentModerator.isAllowed(title, subtitle) -> {
                            Timber.tag(TAG).w("Pruned search suggestion item: '$title'")
                            false
                        }
                        else -> true
                    }
                }.orEmpty()
                section.copy(searchSuggestionsSectionRenderer = ssSection.copy(contents = filteredSuggestions))
            } else {
                section
            }
        }
        return response.copy(contents = updatedContents)
    }

    /**
     * Prunes a list of YTItem objects against updated moderation guidelines.
     */
    fun <T : YTItem> pruneItems(items: List<T>): List<T> {
        return items.filter { item ->
            SongContentModerator.isItemAllowed(item)
        }
    }
}
