package com.listrovia.innertube.utils

import timber.log.Timber

/**
 * Unified logging mechanism within the integrated InnerTube codebase
 * to track API request/response flows and parsing errors in real-time.
 */
object InnerTubeLogger {
    private const val TAG = "InnerTubeTrace"

    fun logRequest(endpoint: String, payloadSummary: String) {
        Timber.tag(TAG).d("API REQUEST -> [%s] Payload: %s", endpoint, payloadSummary)
    }

    fun logResponse(endpoint: String, statusCode: Int, bodySize: Int) {
        Timber.tag(TAG).d("API RESPONSE <- [%s] Status: %d, Size: %d bytes", endpoint, statusCode, bodySize)
    }

    fun logParsingError(endpoint: String, error: Throwable) {
        Timber.tag(TAG).e(error, "PARSING ERROR X [%s] Failed to parse response model structure.", endpoint)
    }
}
