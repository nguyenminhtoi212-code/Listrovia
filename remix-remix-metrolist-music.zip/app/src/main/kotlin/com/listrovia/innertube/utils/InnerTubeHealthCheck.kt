package com.listrovia.innertube.utils

import com.listrovia.innertube.InnerTube
import com.listrovia.innertube.models.YouTubeClient
import timber.log.Timber

/**
 * Health check service that verifies the integrity of integrated InnerTube response models,
 * alerting if structural changes or parsing failures occur.
 */
object InnerTubeHealthCheck {
    private const val TAG = "InnerTubeHealth"

    suspend fun checkModelIntegrity(innerTube: InnerTube): HealthStatus {
        return try {
            Timber.tag(TAG).d("Starting InnerTube response model integrity check...")
            val result = innerTube.getSearchSuggestions(YouTubeClient.WEB_REMIX, "health_test")
            if (result.status.value in 200..299) {
                Timber.tag(TAG).i("InnerTube model integrity health check passed successfully.")
                HealthStatus.Healthy
            } else {
                Timber.tag(TAG).w("InnerTube model integrity check returned non-success status: %d", result.status.value)
                HealthStatus.Degraded("Non-success HTTP status: ${result.status.value}")
            }
        } catch (e: Exception) {
            InnerTubeLogger.logParsingError("health_check", e)
            HealthStatus.Unhealthy(e.message ?: "Unknown parsing or network failure")
        }
    }

    sealed interface HealthStatus {
        data object Healthy : HealthStatus
        data class Degraded(val reason: String) : HealthStatus
        data class Unhealthy(val error: String) : HealthStatus
    }
}
