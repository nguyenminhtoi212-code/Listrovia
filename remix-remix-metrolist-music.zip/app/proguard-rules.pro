# Aggressive R8/ProGuard optimizations
-optimizationpasses 10
-allowaccessmodification
-overloadaggressively
-repackageclasses ''
-allowaccessmodification
-printmapping mapping.txt

# Room Database keep rules
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**
-keepclassmembers class * {
    @androidx.room.* <fields>;
    @androidx.room.* <methods>;
}

# Hilt & Dagger keep rules
-keep class * extends dagger.hilt.internal.UnsafeCasts
-keepclassmembers class * {
    @dagger.hilt.android.lifecycle.HiltViewModel <init>(...);
}
-keep class dagger.hilt.android.internal.lifecycle.HiltViewModelFactory
-keep interface dagger.hilt.internal.GeneratedComponent
-keep interface dagger.hilt.internal.ComponentEntryPoint
-keep interface dagger.hilt.internal.GeneratedComponentManager

# Media3 / ExoPlayer keep rules
-keep class androidx.media3.common.** { *; }
-keep class androidx.media3.exoplayer.** { *; }
-keep class androidx.media3.session.** { *; }
-keep class androidx.media3.datasource.** { *; }
-keep class androidx.media3.extractor.** { *; }
-dontwarn androidx.media3.**

# NewPipeExtractor & Kuromoji keep and dontwarn rules
-dontwarn org.schabi.newpipe.extractor.**
-keep class org.schabi.newpipe.extractor.** { *; }

-dontwarn com.atilika.kuromoji.**
-keep class com.atilika.kuromoji.** { *; }
-keepclassmembers class com.atilika.kuromoji.** { *; }

# Firebase Performance Monitoring
-keep class com.google.firebase.perf.** { *; }
-dontwarn com.google.firebase.perf.**

# Omnis Security Manager Aggressive Obfuscation & Shrinking
-keep class com.listrovia.music.security.OmnisSecurityManager {
    public static boolean checkThreatsAndEnforce(android.content.Context);
}
-renamesourcefileattribute ''

