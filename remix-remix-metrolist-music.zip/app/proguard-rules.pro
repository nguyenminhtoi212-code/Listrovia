# Keep Android Components and Application class
-keep public class com.listrovia.music.App { *; }
-keep public class com.listrovia.music.Hilt_App { *; }
-keep public class * extends android.app.Application
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.content.ContentProvider

# Hilt & Dagger keep rules
-keep class * extends dagger.hilt.internal.UnsafeCasts
-keep class dagger.hilt.android.internal.lifecycle.HiltViewModelFactory
-keep interface dagger.hilt.internal.GeneratedComponent
-keep interface dagger.hilt.internal.ComponentEntryPoint
-keep interface dagger.hilt.internal.GeneratedComponentManager
-keep class * implements dagger.hilt.internal.GeneratedComponent
-keep class * implements dagger.hilt.internal.ComponentEntryPoint
-keep class * implements dagger.hilt.internal.GeneratedComponentManager
-keepclassmembers class * {
    @dagger.hilt.android.lifecycle.HiltViewModel <init>(...);
    @javax.inject.Inject <init>(...);
}

# Room Database keep rules
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**
-keepclassmembers class * {
    @androidx.room.* <fields>;
    @androidx.room.* <methods>;
}

# Media3 / ExoPlayer keep rules
-keep class androidx.media3.common.** { *; }
-keep class androidx.media3.exoplayer.** { *; }
-keep class androidx.media3.session.** { *; }
-keep class androidx.media3.datasource.** { *; }
-keep class androidx.media3.extractor.** { *; }
-dontwarn androidx.media3.**

# NewPipeExtractor & Kuromoji keep and dontwarn rules
-dontwarn org.schabi.newpipe.extractor.**
-keep class org.schabi.newpipe.extractor.** { *; }

-dontwarn com.atilika.kuromoji.**
-keep class com.atilika.kuromoji.** { *; }
-keepclassmembers class com.atilika.kuromoji.** { *; }

# Firebase Performance Monitoring
-keep class com.google.firebase.perf.** { *; }
-dontwarn com.google.firebase.perf.**

# Security & Serialization
-keep class com.listrovia.music.security.OmnisSecurityManager {
    public static boolean checkThreatsAndEnforce(android.content.Context);
}
-keepclassmembers class * {
    @kotlinx.serialization.Serializable <fields>;
}
-keepclassmembers class * {
    @kotlinx.serialization.Serializable <methods>;
}
