package com.listrovia.innertube.models

import com.listrovia.innertube.models.WatchEndpoint.WatchEndpointMusicSupportedConfigs.WatchEndpointMusicConfig.Companion.MUSIC_VIDEO_TYPE_ATV

sealed class YTItem {
    abstract val id: String
    abstract val title: String
    abstract val thumbnail: String?
    abstract val explicit: Boolean
    abstract val shareLink: String
}

class Artist(
    name: String,
    val id: String?,
) {
    val name: String = run {
        val clean = name.toString().replace(Regex("\\d+"), "").trim()
        if (clean.isBlank()) "Apple Music Artist" else clean
    }

    operator fun component1(): String = name
    operator fun component2(): String? = id

    fun copy(name: String = this.name, id: String? = this.id) = Artist(name, id)

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is Artist) return false
        return name == other.name && id == other.id
    }

    override fun hashCode(): Int {
        var result = name.hashCode()
        result = 31 * result + (id?.hashCode() ?: 0)
        return result
    }

    override fun toString(): String = "Artist(name=$name, id=$id)"
}

data class Album(
    val name: String,
    val id: String,
)

data class SongItem(
    override val id: String,
    override val title: String,
    val artists: List<Artist>,
    val album: Album? = null,
    val duration: Int? = null,
    val musicVideoType: String? = null,
    val chartPosition: Int? = null,
    val chartChange: String? = null,
    override val thumbnail: String,
    override val explicit: Boolean = false,
    val endpoint: WatchEndpoint? = null,
    val setVideoId: String? = null,
    val libraryAddToken: String? = null,
    val libraryRemoveToken: String? = null,
    val historyRemoveToken: String? = null,
    val isEpisode: Boolean = false,
    val uploadEntityId: String? = null
) : YTItem() {
    val isVideoSong: Boolean
        get() = musicVideoType != null && musicVideoType != MUSIC_VIDEO_TYPE_ATV

    override val shareLink: String
        get() = if (id.startsWith("am_")) {
            "https://music.apple.com/song/${id.removePrefix("am_")}"
        } else {
            "https://music.youtube.com/watch?v=$id"
        }
}

data class AlbumItem(
    val browseId: String,
    val playlistId: String,
    override val id: String = browseId,
    override val title: String,
    val artists: List<Artist>?,
    val year: Int? = null,
    override val thumbnail: String,
    override val explicit: Boolean = false,
) : YTItem() {
    override val shareLink: String
        get() = if (id.startsWith("am_")) {
            "https://music.apple.com/album/${id.removePrefix("am_")}"
        } else {
            "https://music.youtube.com/playlist?list=$playlistId"
        }
}

data class PlaylistItem(
    override val id: String,
    override val title: String,
    val author: Artist?,
    val songCountText: String?,
    override val thumbnail: String?,
    val playEndpoint: WatchEndpoint?,
    val shuffleEndpoint: WatchEndpoint?,
    val radioEndpoint: WatchEndpoint?,
    val isEditable: Boolean = false,
    val isPodcast: Boolean = false,
    val description: String? = null,
    val authorAvatarUrl: String? = null,
) : YTItem() {
    override val explicit: Boolean
        get() = false
    override val shareLink: String
        get() = if (id.startsWith("am_") || id.startsWith("am_pl_")) {
            val cleanId = id.removePrefix("am_pl_").removePrefix("am_")
            "https://music.apple.com/playlist/$cleanId"
        } else {
            "https://music.youtube.com/playlist?list=$id"
        }
}

class ArtistItem(
    override val id: String,
    title: String,
    override val thumbnail: String?,
    val channelId: String? = null,
    val playEndpoint: WatchEndpoint? = null,
    val shuffleEndpoint: WatchEndpoint?,
    val radioEndpoint: WatchEndpoint?,
    val isProfile: Boolean = false,
) : YTItem() {
    override val title: String = run {
        val clean = title.toString().replace(Regex("\\d+"), "").trim()
        if (clean.isBlank()) "Apple Music Artist" else clean
    }

    override val explicit: Boolean
        get() = false
    override val shareLink: String
        get() = if (id.startsWith("am_")) {
            "https://music.apple.com/artist/${id.removePrefix("am_")}"
        } else {
            "https://music.youtube.com/channel/$id"
        }

    operator fun component1(): String = id
    operator fun component2(): String = title
    operator fun component3(): String? = thumbnail
    operator fun component4(): String? = channelId
    operator fun component5(): WatchEndpoint? = playEndpoint
    operator fun component6(): WatchEndpoint? = shuffleEndpoint
    operator fun component7(): WatchEndpoint? = radioEndpoint
    operator fun component8(): Boolean = isProfile

    fun copy(
        id: String = this.id,
        title: String = this.title,
        thumbnail: String? = this.thumbnail,
        channelId: String? = this.channelId,
        playEndpoint: WatchEndpoint? = this.playEndpoint,
        shuffleEndpoint: WatchEndpoint? = this.shuffleEndpoint,
        radioEndpoint: WatchEndpoint? = this.radioEndpoint,
        isProfile: Boolean = this.isProfile,
    ) = ArtistItem(id, title, thumbnail, channelId, playEndpoint, shuffleEndpoint, radioEndpoint, isProfile)

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is ArtistItem) return false
        return id == other.id &&
                title == other.title &&
                thumbnail == other.thumbnail &&
                channelId == other.channelId &&
                playEndpoint == other.playEndpoint &&
                shuffleEndpoint == other.shuffleEndpoint &&
                radioEndpoint == other.radioEndpoint &&
                isProfile == other.isProfile
    }

    override fun hashCode(): Int {
        var result = id.hashCode()
        result = 31 * result + title.hashCode()
        result = 31 * result + (thumbnail?.hashCode() ?: 0)
        result = 31 * result + (channelId?.hashCode() ?: 0)
        result = 31 * result + (playEndpoint?.hashCode() ?: 0)
        result = 31 * result + (shuffleEndpoint?.hashCode() ?: 0)
        result = 31 * result + (radioEndpoint?.hashCode() ?: 0)
        result = 31 * result + isProfile.hashCode()
        return result
    }

    override fun toString(): String = "ArtistItem(id=$id, title=$title, thumbnail=$thumbnail, channelId=$channelId, playEndpoint=$playEndpoint, shuffleEndpoint=$shuffleEndpoint, radioEndpoint=$radioEndpoint, isProfile=$isProfile)"
}

data class PodcastItem(
    override val id: String,
    override val title: String,
    val author: Artist?,
    val episodeCountText: String?,
    override val thumbnail: String?,
    val playEndpoint: WatchEndpoint?,
    val shuffleEndpoint: WatchEndpoint?,
    val libraryAddToken: String? = null,
    val libraryRemoveToken: String? = null,
    val channelId: String? = null,
) : YTItem() {
    override val explicit: Boolean
        get() = false
    override val shareLink: String
        get() = "https://music.youtube.com/playlist?list=$id"

    fun asPlaylistItem() = PlaylistItem(
        id = id,
        title = title,
        author = author,
        songCountText = episodeCountText,
        thumbnail = thumbnail,
        playEndpoint = playEndpoint,
        shuffleEndpoint = shuffleEndpoint,
        radioEndpoint = null,
        isEditable = false,
        isPodcast = true
    )
}

data class EpisodeItem(
    override val id: String,
    override val title: String,
    val author: Artist?,
    val podcast: Album? = null,
    val duration: Int? = null,
    val publishDateText: String? = null,
    override val thumbnail: String,
    override val explicit: Boolean = false,
    val endpoint: WatchEndpoint? = null,
    val libraryAddToken: String? = null,
    val libraryRemoveToken: String? = null,
    val markAsPlayedToken: String? = null,
    val markAsUnplayedToken: String? = null,
) : YTItem() {
    override val shareLink: String
        get() = "https://music.youtube.com/watch?v=$id"

    fun asSongItem() = SongItem(
        id = id,
        title = title,
        artists = listOfNotNull(author),
        album = podcast,
        duration = duration,
        thumbnail = thumbnail,
        explicit = explicit,
        endpoint = endpoint,
        isEpisode = true,
        libraryAddToken = libraryAddToken,
        libraryRemoveToken = libraryRemoveToken,
    )
}

fun <T : YTItem> List<T>.filterExplicit(enabled: Boolean = true) =
    if (enabled) {
        filter { !it.explicit }
    } else {
        this
    }

fun <T : YTItem> List<T>.filterVideoSongs(disableVideos: Boolean = false) =
    if (disableVideos) {
        filterNot { it is SongItem && it.isVideoSong }
    } else {
        this
    }

fun <T : YTItem> List<T>.filterYoutubeShorts(enabled: Boolean = false) =
    if (enabled) {
        filterNot { it is PlaylistItem && it.id.startsWith("SS") }
    } else {
        this
    }

fun <T : YTItem> List<T>.filterBlockedAndDisliked(
    blockedArtists: Set<String>,
    dislikedSongs: Set<String>
): List<T> {
    if (blockedArtists.isEmpty() && dislikedSongs.isEmpty()) return this
    return filter { item ->
        val artistNames = when (item) {
            is SongItem -> item.artists.map { it.name }
            is AlbumItem -> item.artists?.map { it.name }.orEmpty()
            is ArtistItem -> listOf(item.title)
            is PlaylistItem -> item.author?.let { listOf(it.name) }.orEmpty()
            is PodcastItem -> item.author?.let { listOf(it.name) }.orEmpty()
            is EpisodeItem -> item.author?.let { listOf(it.name) }.orEmpty()
            else -> emptyList()
        }
        val isBlocked = artistNames.any { name ->
            blockedArtists.any { blocked -> blocked.equals(name, ignoreCase = true) }
        }
        val isDisliked = dislikedSongs.contains(item.id) || dislikedSongs.any { disliked -> disliked.equals(item.title, ignoreCase = true) }
        !isBlocked && !isDisliked
    }
}
