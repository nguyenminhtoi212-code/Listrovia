package com.listrovia.innertube.models

import kotlinx.serialization.Serializable

@Serializable
data class YouTubeVideoItem(
    val videoId: String,
    val title: String,
    val channelName: String,
    val channelId: String? = null,
    val channelThumbnailUrl: String? = null,
    val description: String? = null,
    val viewCountText: String? = null,
    val publishedTimeText: String? = null,
    val durationText: String? = null,
    val thumbnails: List<Thumbnail> = emptyList(),
    val isLive: Boolean = false,
)

@Serializable
data class YouTubeChannelPage(
    val channelId: String,
    val title: String,
    val avatarUrl: String? = null,
    val bannerUrl: String? = null,
    val subscriberCountText: String? = null,
    val videosCountText: String? = null,
    val description: String? = null,
    val videos: List<YouTubeVideoItem> = emptyList(),
    val continuation: String? = null,
    val isSubscribed: Boolean? = null,
) {
    companion object {
        const val VIDEOS_PARAMS = "EgZ2aWRlb3PyBgQKAjoA"
        const val SHORTS_PARAMS = "EgZzaG9ydHPyBgQKAjoA"
        const val LIVE_PARAMS = "EgRsaXZleyBgQKAjoA"
    }
}

@Serializable
data class YouTubeChannelPost(
    val postId: String,
    val authorName: String,
    val authorThumbnail: String? = null,
    val publishedTimeText: String? = null,
    val contentText: String? = null,
    val imageUrls: List<String> = emptyList(),
    val voteCountText: String? = null,
    val commentCountText: String? = null,
)

@Serializable
sealed class YouTubeSearchResultItem {
    @Serializable
    data class Video(val item: YouTubeVideoItem) : YouTubeSearchResultItem()
    @Serializable
    data class Channel(
        val channelId: String,
        val title: String,
        val thumbnails: List<Thumbnail> = emptyList(),
        val subscriberCountText: String? = null,
        val videoCountText: String? = null,
        val description: String? = null,
    ) : YouTubeSearchResultItem()
    @Serializable
    data class Playlist(
        val playlistId: String,
        val title: String,
        val thumbnails: List<Thumbnail> = emptyList(),
        val channelName: String? = null,
        val itemCountText: String? = null,
    ) : YouTubeSearchResultItem()
}

@Serializable
data class VideoFeedResult(
    val items: List<YouTubeSearchResultItem>,
    val continuation: String?,
)
