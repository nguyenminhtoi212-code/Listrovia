package com.listrovia.innertube.pages

import com.listrovia.innertube.models.YouTubeVideoItem
import com.listrovia.innertube.models.Thumbnail
import com.listrovia.innertube.models.YouTubeSearchResultItem
import com.listrovia.innertube.models.YouTubeChannelPage
import com.listrovia.innertube.models.YouTubeChannelPost
import com.listrovia.innertube.models.VideoFeedResult
import kotlinx.serialization.json.*

import com.listrovia.innertube.models.response.WatchMetadataResponse
import com.listrovia.innertube.models.response.YoutubeComment
import com.listrovia.innertube.models.response.WatchLikeState

object VideoFeedPage {
    fun fromJson(json: JsonObject): VideoFeedResult {
        val items = mutableListOf<YouTubeSearchResultItem>()
        
        val contents = json["contents"]?.jsonObject
            ?.get("twoColumnBrowseResultsRenderer")?.jsonObject
            ?.get("tabs")?.jsonArray?.firstOrNull()?.jsonObject
            ?.get("tabRenderer")?.jsonObject
            ?.get("content")?.jsonObject
            ?.get("sectionListRenderer")?.jsonObject
            ?.get("contents")?.jsonArray
            ?: json["onResponseReceivedActions"]?.jsonArray?.firstOrNull()?.jsonObject
                ?.get("appendContinuationItemsAction")?.jsonObject
                ?.get("continuationItems")?.jsonArray
            ?: return VideoFeedResult(emptyList(), null)

        var continuation: String? = null

        contents.forEach { content ->
            val itemSection = content.jsonObject["itemSectionRenderer"]?.jsonObject
            val shelf = content.jsonObject["richShelfRenderer"]?.jsonObject
            val richGrid = content.jsonObject["richGridRenderer"]?.jsonObject
            
            val videoItems = mutableListOf<JsonObject>()
            
            if (itemSection != null) {
                itemSection["contents"]?.jsonArray?.forEach { videoItems.add(it.jsonObject) }
            } else if (shelf != null) {
                shelf["contents"]?.jsonArray?.forEach { videoItems.add(it.jsonObject["richItemRenderer"]?.jsonObject ?: it.jsonObject) }
            } else if (richGrid != null) {
                richGrid["contents"]?.jsonArray?.forEach { videoItems.add(it.jsonObject["richItemRenderer"]?.jsonObject ?: it.jsonObject) }
                continuation = richGrid["continuations"]?.jsonArray?.firstOrNull()?.jsonObject
                    ?.get("nextContinuationData")?.jsonObject?.get("continuation")?.jsonPrimitive?.content
            } else if (content.jsonObject.containsKey("richItemRenderer")) {
                videoItems.add(content.jsonObject["richItemRenderer"]!!.jsonObject)
            } else if (content.jsonObject.containsKey("continuationItemRenderer")) {
                 continuation = content.jsonObject["continuationItemRenderer"]?.jsonObject
                    ?.get("continuationEndpoint")?.jsonObject
                    ?.get("continuationCommand")?.jsonObject
                    ?.get("token")?.jsonPrimitive?.content
            }

            videoItems.forEach { videoJson ->
                val renderer = videoJson["videoRenderer"]?.jsonObject 
                    ?: videoJson["gridVideoRenderer"]?.jsonObject
                    ?: videoJson["content"]?.jsonObject?.get("videoRenderer")?.jsonObject
                
                if (renderer != null) {
                    val videoId = renderer["videoId"]?.jsonPrimitive?.content ?: return@forEach
                    val title = renderer["title"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content ?: ""
                    val channelName = renderer["shortBylineText"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content ?: ""
                    val channelId = renderer["shortBylineText"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject
                        ?.get("navigationEndpoint")?.jsonObject?.get("browseEndpoint")?.jsonObject?.get("browseId")?.jsonPrimitive?.content
                    val channelThumbnailUrl = renderer["channelThumbnailSupportedRenderers"]?.jsonObject
                        ?.get("channelThumbnailWithLinkRenderer")?.jsonObject
                        ?.get("thumbnail")?.jsonObject?.get("thumbnails")?.jsonArray?.maxByOrNull { it.jsonObject["width"]?.jsonPrimitive?.int ?: 0 }
                        ?.jsonObject?.get("url")?.jsonPrimitive?.content

                    val thumbnails = renderer["thumbnail"]?.jsonObject?.get("thumbnails")?.jsonArray?.map {
                        Thumbnail(
                            url = it.jsonObject["url"]!!.jsonPrimitive.content,
                            width = it.jsonObject["width"]?.jsonPrimitive?.intOrNull,
                            height = it.jsonObject["height"]?.jsonPrimitive?.intOrNull
                        )
                    } ?: emptyList()

                    val viewCountText = renderer["viewCountText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content
                        ?: renderer["viewCountText"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content
                    val publishedTimeText = renderer["publishedTimeText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content
                    val durationText = renderer["lengthText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content

                    items.add(YouTubeSearchResultItem.Video(YouTubeVideoItem(
                        videoId = videoId,
                        title = title,
                        channelName = channelName,
                        channelId = channelId,
                        channelThumbnailUrl = channelThumbnailUrl,
                        thumbnails = thumbnails,
                        viewCountText = viewCountText,
                        publishedTimeText = publishedTimeText,
                        durationText = durationText
                    )))
                }
            }
        }

        return VideoFeedResult(items, continuation)
    }

    fun parseSearch(json: JsonObject): VideoFeedResult {
        val items = mutableListOf<YouTubeSearchResultItem>()
        val contents = json["contents"]?.jsonObject
            ?.get("twoColumnSearchResultsRenderer")?.jsonObject
            ?.get("primaryContents")?.jsonObject
            ?.get("sectionListRenderer")?.jsonObject
            ?.get("contents")?.jsonArray
            ?: return VideoFeedResult(emptyList(), null)

        var continuation: String? = null

        contents.forEach { content ->
            val itemSection = content.jsonObject["itemSectionRenderer"]?.jsonObject ?: return@forEach
            itemSection["contents"]?.jsonArray?.forEach { videoJson ->
                val renderer = videoJson.jsonObject["videoRenderer"]?.jsonObject
                if (renderer != null) {
                    val videoId = renderer["videoId"]?.jsonPrimitive?.content ?: return@forEach
                    val title = renderer["title"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content ?: ""
                    val channelName = renderer["ownerText"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content ?: ""
                    val channelId = renderer["ownerText"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject
                        ?.get("navigationEndpoint")?.jsonObject?.get("browseEndpoint")?.jsonObject?.get("browseId")?.jsonPrimitive?.content
                    val channelThumbnailUrl = renderer["channelThumbnailSupportedRenderers"]?.jsonObject
                        ?.get("channelThumbnailWithLinkRenderer")?.jsonObject
                        ?.get("thumbnail")?.jsonObject?.get("thumbnails")?.jsonArray?.maxByOrNull { it.jsonObject["width"]?.jsonPrimitive?.int ?: 0 }
                        ?.jsonObject?.get("url")?.jsonPrimitive?.content

                    val thumbnails = renderer["thumbnail"]?.jsonObject?.get("thumbnails")?.jsonArray?.map {
                        Thumbnail(
                            url = it.jsonObject["url"]!!.jsonPrimitive.content,
                            width = it.jsonObject["width"]?.jsonPrimitive?.intOrNull,
                            height = it.jsonObject["height"]?.jsonPrimitive?.intOrNull
                        )
                    } ?: emptyList()

                    val viewCountText = renderer["viewCountText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content
                    val publishedTimeText = renderer["publishedTimeText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content
                    val durationText = renderer["lengthText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content

                    items.add(YouTubeSearchResultItem.Video(YouTubeVideoItem(
                        videoId = videoId,
                        title = title,
                        channelName = channelName,
                        channelId = channelId,
                        channelThumbnailUrl = channelThumbnailUrl,
                        thumbnails = thumbnails,
                        viewCountText = viewCountText,
                        publishedTimeText = publishedTimeText,
                        durationText = durationText
                    )))
                    return@forEach
                }

                val channelRenderer = videoJson.jsonObject["channelRenderer"]?.jsonObject
                if (channelRenderer != null) {
                    val channelId = channelRenderer["channelId"]?.jsonPrimitive?.content ?: return@forEach
                    val title = channelRenderer["title"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content ?: ""
                    val thumbnails = channelRenderer["thumbnail"]?.jsonObject?.get("thumbnails")?.jsonArray?.map {
                        Thumbnail(
                            url = it.jsonObject["url"]!!.jsonPrimitive.content,
                            width = it.jsonObject["width"]?.jsonPrimitive?.intOrNull,
                            height = it.jsonObject["height"]?.jsonPrimitive?.intOrNull
                        )
                    } ?: emptyList()
                    val subscriberCountText = channelRenderer["subscriberCountText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content
                    val videoCountText = channelRenderer["videoCountText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content
                    val description = channelRenderer["descriptionSnippet"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content

                    items.add(YouTubeSearchResultItem.Channel(
                        channelId = channelId,
                        title = title,
                        thumbnails = thumbnails,
                        subscriberCountText = subscriberCountText,
                        videoCountText = videoCountText,
                        description = description
                    ))
                    return@forEach
                }

                val playlistRenderer = videoJson.jsonObject["playlistRenderer"]?.jsonObject
                if (playlistRenderer != null) {
                    val playlistId = playlistRenderer["playlistId"]?.jsonPrimitive?.content ?: return@forEach
                    val title = playlistRenderer["title"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content ?: ""
                    val thumbnails = playlistRenderer["thumbnails"]?.jsonArray?.firstOrNull()?.jsonObject?.get("thumbnails")?.jsonArray?.map {
                        Thumbnail(
                            url = it.jsonObject["url"]!!.jsonPrimitive.content,
                            width = it.jsonObject["width"]?.jsonPrimitive?.intOrNull,
                            height = it.jsonObject["height"]?.jsonPrimitive?.intOrNull
                        )
                    } ?: emptyList()
                    val channelName = playlistRenderer["shortBylineText"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content
                    val itemCountText = playlistRenderer["videoCountText"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content

                    items.add(YouTubeSearchResultItem.Playlist(
                        playlistId = playlistId,
                        title = title,
                        thumbnails = thumbnails,
                        channelName = channelName,
                        itemCountText = itemCountText
                    ))
                    return@forEach
                }
            }
            
            if (continuation == null) {
                continuation = itemSection["continuations"]?.jsonArray?.firstOrNull()?.jsonObject
                    ?.get("nextContinuationData")?.jsonObject?.get("continuation")?.jsonPrimitive?.content
            }
        }

        return VideoFeedResult(items, continuation)
    }

    fun parseWatchMetadata(json: JsonObject): WatchMetadataResponse {
        // Simplified parsing for WatchMetadata
        return WatchMetadataResponse()
    }

    fun parseWatchNextContinuation(json: JsonObject): VideoFeedResult {
        // Simplified parsing for WatchNextContinuation
        return VideoFeedResult(emptyList(), null)
    }
}
