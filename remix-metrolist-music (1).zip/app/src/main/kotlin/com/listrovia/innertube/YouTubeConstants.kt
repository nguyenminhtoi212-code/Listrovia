package com.listrovia.innertube

object YouTubeConstants {
    const val DEFAULT_TOP_RESULT = "Top result"
    const val DEFAULT_OTHER_RESULTS = "Other"

    // Search filters
    const val SEARCH_FILTER_VIDEOS = "EgIQAQ%3D%3D"
    const val SEARCH_FILTER_CHANNELS = "EgIQAg%3D%3D"
    const val SEARCH_FILTER_PLAYLISTS = "EgIQAw%3D%3D"
    
    const val SEARCH_DURATION_UNDER_4_MINUTES = "EgYyAnAB"
    const val SEARCH_DURATION_4_TO_20_MINUTES = "EgYyAnAC"
    const val SEARCH_DURATION_OVER_20_MINUTES = "EgYyAnAD"
    
    const val SEARCH_TIME_TODAY = "EgQIAhAB"
    const val SEARCH_TIME_THIS_WEEK = "EgQIAxAB"
    const val SEARCH_TIME_THIS_MONTH = "EgQIBBAB"
    const val SEARCH_TIME_THIS_YEAR = "EgQIBRAB"
    
    const val SEARCH_SORT_BY_RATING = "CAE%3D"
    const val SEARCH_SORT_BY_DATE = "CAI%3D"
    const val SEARCH_SORT_BY_VIEW_COUNT = "CAM%3D"

    // Channel params
    const val CHANNEL_VIDEOS_PARAMS = "EgZ2aWRlb3PyBgQKAjoA"
    const val CHANNEL_SHORTS_PARAMS = "EgZzaG9ydHPyBgQKAjoA"
    const val CHANNEL_LIVE_PARAMS = "EgRsaXZleyBgQKAjoA"
}
