package com.listrovia.innertube.models.response

import kotlinx.serialization.Serializable
import com.listrovia.innertube.models.YouTubeVideoItem
import com.listrovia.innertube.models.Thumbnail

@Serializable
data class WatchMetadataResponse(
    val title: String? = null,
    val channelId: String? = null,
    val channelName: String? = null,
    val channelAvatarUrl: String? = null,
    val subscriberCountText: String? = null,
    val description: String? = null,
    val viewCountText: String? = null,
    val dateText: String? = null,
    val likeCountText: String? = null,
    val likeState: WatchLikeState = WatchLikeState.INDIFFERENT,
    val commentCountText: String? = null,
    val relatedVideos: List<YouTubeVideoItem> = emptyList(),
    val relatedContinuation: String? = null,
    val comments: List<YoutubeComment> = emptyList(),
    val commentsContinuation: String? = null,
)

@Serializable
enum class WatchLikeState {
    INDIFFERENT,
    LIKE,
    DISLIKE,
    NONE,
}

@Serializable
data class WatchCompactVideo(
    val videoId: String,
    val title: String,
    val channelName: String,
    val channelId: String,
    val thumbnailUrl: String,
    val durationText: String? = null,
    val viewCountText: String? = null,
    val publishedTimeText: String? = null,
)

@Serializable
data class YoutubeComment(
    val commentId: String,
    val authorName: String,
    val authorThumbnail: String? = null,
    val content: String,
    val publishedTime: String? = null,
    val likeCount: String? = null,
    val replyCount: String? = null,
    val isAuthorPinned: Boolean = false,
)

// Extension functions to match ported code usage and avoid property collision
fun WatchMetadataResponse.getChannelId(): String? = this.channelId
fun WatchMetadataResponse.getTitle(): String? = this.title
fun WatchMetadataResponse.getChannelName(): String? = this.channelName
fun WatchMetadataResponse.getChannelAvatarUrl(): String? = this.channelAvatarUrl
fun WatchMetadataResponse.getSubscriberCountText(): String? = this.subscriberCountText
fun WatchMetadataResponse.getDescription(): String? = this.description
fun WatchMetadataResponse.getViewCountText(): String? = this.viewCountText
fun WatchMetadataResponse.getDateText(): String? = this.dateText
fun WatchMetadataResponse.getLikeCountText(): String? = this.likeCountText
fun WatchMetadataResponse.getLikeState(): WatchLikeState = this.likeState
fun WatchMetadataResponse.getCommentCountText(): String? = this.commentCountText
fun WatchMetadataResponse.getRelatedVideos(): List<YouTubeVideoItem> = this.relatedVideos
fun WatchMetadataResponse.getRelatedContinuation(): String? = this.relatedContinuation
fun WatchMetadataResponse.getComments(): List<YoutubeComment> = this.comments
fun WatchMetadataResponse.getCommentsContinuation(): String? = this.commentsContinuation

// Backwards compatibility functions (some code might use them without 'get')
fun WatchMetadataResponse.title(): String? = this.title
fun WatchMetadataResponse.channelName(): String? = this.channelName
fun WatchMetadataResponse.channelId(): String? = this.channelId
fun WatchMetadataResponse.channelAvatarUrl(): String? = this.channelAvatarUrl
fun WatchMetadataResponse.description(): String? = this.description
fun WatchMetadataResponse.viewCountText(): String? = this.viewCountText
fun WatchMetadataResponse.dateText(): String? = this.dateText
fun WatchMetadataResponse.subscriberCountText(): String? = this.subscriberCountText
fun WatchMetadataResponse.commentCountText(): String? = this.commentCountText
fun WatchMetadataResponse.likeCountText(): String? = this.likeCountText
fun WatchMetadataResponse.likeState(): WatchLikeState = this.likeState
fun WatchMetadataResponse.relatedVideos(): List<YouTubeVideoItem> = this.relatedVideos
fun WatchMetadataResponse.relatedContinuation(): String? = this.relatedContinuation
fun WatchMetadataResponse.comments(): List<YoutubeComment> = this.comments
fun WatchMetadataResponse.commentsContinuation(): String? = this.commentsContinuation
