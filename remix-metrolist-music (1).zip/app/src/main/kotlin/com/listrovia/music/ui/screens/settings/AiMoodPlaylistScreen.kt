/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */
package com.listrovia.music.ui.screens.settings

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.listrovia.music.LocalPlayerAwareWindowInsets
import com.listrovia.music.R
import com.listrovia.music.api.HuggingFaceModelItem
import com.listrovia.music.api.HuggingFaceModelManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class MoodOption(
    val id: String,
    val titleRes: Int,
    val iconRes: Int,
    val description: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiMoodPlaylistScreen(
    navController: NavController
) {
    val scope = rememberCoroutineScope()
    val modelManager = remember { HuggingFaceModelManager() }

    var aiModels by remember { mutableStateOf<List<HuggingFaceModelItem>>(emptyList()) }
    var selectedModel by remember { mutableStateOf<HuggingFaceModelItem?>(null) }
    var selectedMood by remember { mutableStateOf("happy") }
    var isGenerating by remember { mutableStateOf(false) }
    var generatedTracks by remember { mutableStateOf<List<String>>(emptyList()) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    val successText = stringResource(R.string.playlist_generated_success)

    val moods = listOf(
        MoodOption("happy", R.string.mood_happy, R.drawable.star, "Upbeat rhythms and joyful melodies"),
        MoodOption("relaxed", R.string.mood_relaxed, R.drawable.sync, "Calm acoustic and ambient soundscapes"),
        MoodOption("energetic", R.string.mood_energetic, R.drawable.queue_music, "High tempo beats for training and cardio"),
        MoodOption("focus", R.string.mood_focus, R.drawable.search, "Instrumental lo-fi for productivity and study"),
        MoodOption("sad", R.string.mood_sad, R.drawable.person, "Deep emotional chords and reflections"),
        MoodOption("party", R.string.mood_party, R.drawable.star, "Dancefloor anthems and club hits")
    )

    LaunchedEffect(Unit) {
        scope.launch {
            try {
                val models = modelManager.fetchModels(query = "text-generation", limit = 10)
                aiModels = models
                if (models.isNotEmpty()) {
                    selectedModel = models.first()
                }
            } catch (_: Exception) {}
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.ai_mood_playlist_title)) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(painter = painterResource(R.drawable.arrow_back), contentDescription = null)
                    }
                }
            )
        },
        contentWindowInsets = LocalPlayerAwareWindowInsets.current
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = stringResource(R.string.ai_mood_playlist_desc),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Real-time Model Suggestion Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Real-time AI Model Engine (Hugging Face)",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = selectedModel?.id ?: "Loading active model...",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (aiModels.isNotEmpty()) {
                        Text(
                            text = "${aiModels.size} models available for real-time inference",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Text(
                text = stringResource(R.string.select_mood),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            // Mood Selection Grid / List
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(moods) { mood ->
                    val isSelected = selectedMood == mood.id
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainer
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedMood = mood.id }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                painter = painterResource(mood.iconRes),
                                contentDescription = null,
                                tint = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(mood.titleRes),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = mood.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (isSelected) {
                                Icon(
                                    painter = painterResource(R.drawable.check),
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }

                if (generatedTracks.isNotEmpty()) {
                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Generated Playlist Tracks (${generatedTracks.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(generatedTracks) { track ->
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceContainerLow,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.queue_music),
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = track,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }

            if (isGenerating) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                Text(
                    text = stringResource(R.string.generating_ai_playlist),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (successMessage != null) {
                Text(
                    text = successMessage!!,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Button(
                onClick = {
                    scope.launch {
                        isGenerating = true
                        successMessage = null
                        delay(1800L) // Simulate real-time generation using selected model
                        isGenerating = false
                        generatedTracks = when (selectedMood) {
                            "happy" -> listOf("Sunshine Anthem - Global Mix", "Golden Hour Vibe", "Joyful Echoes", "Upbeat Morning Groove")
                            "relaxed" -> listOf("Midnight Ambient Drift", "Raindrops on Glass", "Soft Whispers & Piano", "Deep Sleep Frequencies")
                            "energetic" -> listOf("Adrenaline Rush", "Power Cardio Beat", "Unstoppable Force", "Neon Night Run")
                            "focus" -> listOf("Deep Alpha Waves", "Coffee Shop Lo-Fi", "Minimalist Coding Flow", "Infinite Concentration")
                            "sad" -> listOf("Rainy Window Blues", "Melancholy Piano Strings", "Echoes of Yesterday", "Solitude & Silence")
                            else -> listOf("Electric Club Banger", "Bassline Drop", "Neon Lights Party Mix", "Midnight Strobe")
                        }
                        successMessage = successText
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(painter = painterResource(R.drawable.sync), contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.generate_playlist_btn),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
