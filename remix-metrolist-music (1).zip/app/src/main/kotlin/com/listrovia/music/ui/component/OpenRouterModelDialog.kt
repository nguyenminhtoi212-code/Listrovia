/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.component

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.listrovia.music.R
import com.listrovia.music.api.OpenRouterModelItem
import com.listrovia.music.constants.OpenRouterTierBeta
import com.listrovia.music.constants.OpenRouterTierDeveloper
import com.listrovia.music.constants.OpenRouterTierStable
import com.listrovia.music.utils.ModelFavoritesManager
import com.listrovia.music.utils.pulltorefresh.PullToRefreshBox
import com.listrovia.music.viewmodels.ModelViewModel
import com.valentinilk.shimmer.shimmer
import android.widget.Toast
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.rememberCoroutineScope
import com.listrovia.music.utils.ModelBenchmarkUtility
import com.listrovia.music.utils.TTFTBadge
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Hộp thoại chọn mô hình OpenRouter AI với giao diện dạng thẻ (Modern Card Architecture)
 * Được tối ưu hóa hoàn toàn: không bị méo lệch cột, hiển thị rõ ràng thông số và phân loại.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OpenRouterModelDialog(
    currentModel: String,
    initialTier: String = "Stable",
    onDismiss: () -> Unit,
    onSelectModel: (String) -> Unit,
    onCustomInput: () -> Unit,
    onSelectTier: ((String) -> Unit)? = null,
    viewModel: ModelViewModel = hiltViewModel(),
) {
    val context = LocalContext.current
    val classifiedModels by viewModel.classifiedModels.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()

    val initialTab = when (initialTier) {
        "Beta" -> 1
        "Developer" -> 2
        else -> 0
    }
    var selectedTab by remember { mutableIntStateOf(initialTab) } // 0: Official, 1: Beta, 2: Developer
    var selectedCategory by remember { mutableStateOf(ModelSourceCategory.ALL) }
    var searchQuery by remember { mutableStateOf("") }
    val favoritesManager = remember { ModelFavoritesManager.getInstance(context) }
    val benchmarkUtility = remember { ModelBenchmarkUtility.getInstance(context) }
    val coroutineScope = rememberCoroutineScope()
    var isBenchmarking by remember { mutableStateOf(false) }
    var activeDetailModel by remember { mutableStateOf<DetailedAiModelInfo?>(null) }
    var favoriteVersion by remember { mutableStateOf(0) }

    val allAvailableModels = remember(classifiedModels) {
        val m = classifiedModels
        if (m == null) emptyList() else (m.official + m.beta + m.developer).distinctBy { it.id }
    }
    val recentlyUsedModels: List<OpenRouterModelItem> = remember(allAvailableModels, favoriteVersion) {
        val recentIds = favoritesManager.getRecentlyUsedModelIds(limit = 6)
        recentIds.mapNotNull { rId ->
            allAvailableModels.firstOrNull { it.id == rId }
        }
    }

    val curatedRecommendedModelIds = remember {
        listOf(
            "google/gemini-2.0-flash-001",
            "anthropic/claude-3.5-sonnet",
            "deepseek/deepseek-r1",
            "meta-llama/llama-3.3-70b-instruct",
            "openai/gpt-4o-mini",
            "mistralai/mistral-small-24b-instruct-2501",
            "google/gemini-2.0-pro-exp-02-05:free",
        )
    }

    val recommendedModels: List<OpenRouterModelItem> = remember(allAvailableModels) {
        val matches = curatedRecommendedModelIds.mapNotNull { rId ->
            allAvailableModels.firstOrNull { it.id == rId || it.id.startsWith(rId) }
        }.distinctBy { it.id }
        if (matches.isNotEmpty()) matches else allAvailableModels.take(6)
    }

    val currentList: List<OpenRouterModelItem> =
        remember(classifiedModels, selectedTab, selectedCategory, searchQuery, favoriteVersion) {
            val models = classifiedModels ?: return@remember emptyList()
            val baseList =
                when (selectedTab) {
                    0 -> models.official
                    1 -> models.beta
                    2 -> models.developer
                    else -> models.official
                }.filter { favoritesManager.isModelSafeAndPublished(it.id, it.name, provider = "OpenRouter") }
                .filter {
                    when (selectedCategory) {
                        ModelSourceCategory.ALL -> true
                        ModelSourceCategory.VERIFIED -> getModelSourceCategory(it.id, it.providerName) == ModelSourceCategory.VERIFIED
                        ModelSourceCategory.COMMUNITY -> getModelSourceCategory(it.id, it.providerName) == ModelSourceCategory.COMMUNITY
                        ModelSourceCategory.DEVELOPER -> getModelSourceCategory(it.id, it.providerName) == ModelSourceCategory.DEVELOPER
                    }
                }

            if (searchQuery.isBlank()) {
                baseList
            } else {
                val q = searchQuery.trim().lowercase()
                baseList.filter {
                    it.id.lowercase().contains(q) ||
                    it.name.lowercase().contains(q) ||
                    it.description.lowercase().contains(q) ||
                    it.providerName.lowercase().contains(q) ||
                    getProviderVisualInfo(it.id, it.providerName).name.lowercase().contains(q)
                }
            }
        }

    AlertDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier
            .widthIn(min = 280.dp, max = 500.dp)
            .fillMaxWidth(0.92f)
            .heightIn(max = 640.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.ai_model),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        text = "OpenRouter Hub",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = {
                            coroutineScope.launch {
                                isBenchmarking = true
                                try {
                                    val targetId = currentModel.ifBlank { currentList.firstOrNull()?.id ?: "google/gemini-2.0-flash-001" }
                                    val ttft = benchmarkUtility.benchmarkModel(targetId)
                                    Toast.makeText(
                                        context,
                                        context.getString(R.string.ai_model_ttft_label, ttft),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    favoriteVersion++
                                } finally {
                                    isBenchmarking = false
                                }
                            }
                        },
                        enabled = !isLoading && !isBenchmarking,
                    ) {
                        if (isBenchmarking) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                            )
                        } else {
                            Icon(
                                painter = painterResource(R.drawable.speed),
                                contentDescription = stringResource(R.string.ai_model_ttft_benchmark),
                                tint = MaterialTheme.colorScheme.primary,
                            )
                        }
                    }

                    IconButton(
                        onClick = {
                            viewModel.recommendRandomModel(forceRefresh = false) { chosen ->
                                favoritesManager.recordModelUsage(chosen.id)
                                onSelectModel(chosen.id)
                                onDismiss()
                            }
                        },
                        enabled = !isLoading,
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.shuffle),
                            contentDescription = stringResource(R.string.ai_model_random_button),
                            tint = MaterialTheme.colorScheme.primary,
                        )
                    }

                    IconButton(
                        onClick = { viewModel.refresh(force = true) },
                        enabled = !isLoading,
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp,
                            )
                        } else {
                            Icon(
                                painter = painterResource(R.drawable.sync),
                                contentDescription = stringResource(R.string.ai_model_refresh),
                                tint = MaterialTheme.colorScheme.primary,
                            )
                        }
                    }
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Search bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text(stringResource(R.string.ai_model_search_placeholder)) },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.search),
                            contentDescription = null,
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    painter = painterResource(R.drawable.close),
                                    contentDescription = null,
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth(),
                )

                // Recently Used Section at the top
                if (recentlyUsedModels.isNotEmpty() && searchQuery.isBlank()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp, bottom = 2.dp),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 2.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(
                                text = stringResource(R.string.ai_model_recently_used),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                            )
                            val totalInteractions = recentlyUsedModels.sumOf { favoritesManager.getModelUsageCount(it.id) }
                            if (totalInteractions > 0) {
                                Text(
                                    text = stringResource(R.string.ai_model_interactions_count, totalInteractions),
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                )
                            }
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            recentlyUsedModels.forEach { rModel ->
                                val isRSelected = rModel.id == currentModel
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isRSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isRSelected) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                                    ),
                                    modifier = Modifier
                                        .width(168.dp)
                                        .clickable {
                                            activeDetailModel = rModel.toDetailedInfo()
                                        },
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    ) {
                                        ProviderAvatar(
                                            modelId = rModel.id,
                                            providerName = rModel.providerName,
                                            size = 22.dp,
                                        )
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = rModel.name,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                            )
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                            ) {
                                                val ttft = benchmarkUtility.getEstimatedOrMeasuredTtft(rModel.id, rModel.name, rModel.contextLength)
                                                Text(
                                                    text = "⚡ ${ttft}ms",
                                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                                    color = MaterialTheme.colorScheme.primary,
                                                    fontWeight = FontWeight.SemiBold,
                                                )
                                                val cnt = favoritesManager.getModelUsageCount(rModel.id)
                                                if (cnt > 0) {
                                                    Text(
                                                        text = "• ${cnt}x",
                                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Recommended Models Section (Đề xuất danh sách)
                if (recommendedModels.isNotEmpty() && searchQuery.isBlank()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp, bottom = 4.dp),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 2.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                            ) {
                                Text(text = "⭐", fontSize = 12.sp)
                                Text(
                                    text = stringResource(R.string.ai_model_recommended_title),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.tertiary,
                                )
                            }
                            Text(
                                text = stringResource(R.string.ai_model_details_tap_hint),
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            )
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            recommendedModels.forEach { recModel ->
                                val isRecSelected = recModel.id == currentModel
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isRecSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                    border = BorderStroke(
                                        if (isRecSelected) 1.5.dp else 1.dp,
                                        if (isRecSelected) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f),
                                    ),
                                    modifier = Modifier
                                        .width(185.dp)
                                        .height(58.dp)
                                        .clickable {
                                            favoritesManager.recordModelUsage(recModel.id)
                                            viewModel.selectModel(recModel.id)
                                            onSelectModel(recModel.id)
                                        },
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        ProviderAvatar(
                                            modelId = recModel.id,
                                            providerName = recModel.providerName,
                                            size = 28.dp,
                                        )
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = recModel.name,
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = if (isRecSelected) FontWeight.Bold else FontWeight.SemiBold,
                                                color = if (isRecSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                            )
                                            val ttft = benchmarkUtility.getEstimatedOrMeasuredTtft(recModel.id, recModel.name, recModel.contextLength)
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                            ) {
                                                Text(
                                                    text = "⚡ ${ttft}ms",
                                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                                    color = MaterialTheme.colorScheme.primary,
                                                    fontWeight = FontWeight.SemiBold,
                                                )
                                                if (recModel.contextLength > 0L) {
                                                    val ctxK = recModel.contextLength / 1024L
                                                    Text(
                                                        text = "• ${ctxK}k",
                                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.5.sp),
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    )
                                                }
                                            }
                                        }
                                        IconButton(
                                            onClick = {
                                                activeDetailModel = recModel.toDetailedInfo()
                                            },
                                            modifier = Modifier.size(24.dp),
                                        ) {
                                            Icon(
                                                painter = painterResource(R.drawable.info),
                                                contentDescription = stringResource(R.string.ai_model_view_description),
                                                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                                                modifier = Modifier.size(15.dp),
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                val officialCount = classifiedModels?.official?.size ?: 0
                val betaCount = classifiedModels?.beta?.size ?: 0
                val devCount = classifiedModels?.developer?.size ?: 0

                // Tier tabs: Stable, Beta, Developer
                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    edgePadding = 0.dp,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = {
                            selectedTab = 0
                            viewModel.selectTier(OpenRouterTierStable)
                            onSelectTier?.invoke(OpenRouterTierStable)
                        },
                        text = {
                            Text(
                                text = "${stringResource(R.string.ai_model_tab_official)} ($officialCount)",
                                style = MaterialTheme.typography.labelMedium,
                            )
                        },
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = {
                            selectedTab = 1
                            viewModel.selectTier(OpenRouterTierBeta)
                            onSelectTier?.invoke(OpenRouterTierBeta)
                        },
                        text = {
                            Text(
                                text = "${stringResource(R.string.ai_model_tab_beta)} ($betaCount)",
                                style = MaterialTheme.typography.labelMedium,
                            )
                        },
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = {
                            selectedTab = 2
                            viewModel.selectTier(OpenRouterTierDeveloper)
                            onSelectTier?.invoke(OpenRouterTierDeveloper)
                        },
                        text = {
                            Text(
                                text = "${stringResource(R.string.ai_model_tab_developer)} ($devCount)",
                                style = MaterialTheme.typography.labelMedium,
                            )
                        },
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Source Category Filter Chips
                ModelSourceCategoryChips(
                    selectedCategory = selectedCategory,
                    onSelectCategory = { selectedCategory = it },
                    modifier = Modifier.fillMaxWidth(),
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Models list Container with Pull-to-Refresh support
                PullToRefreshBox(
                    isRefreshing = isLoading,
                    onRefresh = { viewModel.refresh(force = true) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 380.dp),
                ) {
                    if (isLoading && classifiedModels == null) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .shimmer()
                                .padding(vertical = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            repeat(4) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)),
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth(0.6f)
                                                .height(14.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)),
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth(0.9f)
                                                .height(10.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)),
                                        )
                                    }
                                }
                            }
                        }
                    } else if (currentList.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = stringResource(R.string.ai_model_none_found),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    } else {
                        val isVietnamese = remember { Locale.getDefault().language == "vi" }
                        val favHeaderTitle = if (isVietnamese) "⭐ Mô hình yêu thích" else "⭐ Favorite Models"
                        val collapsedProviders = remember { mutableStateMapOf<String, Boolean>() }
                        val entries = remember(currentList, collapsedProviders, favoriteVersion, favHeaderTitle) {
                            val favIds = favoritesManager.getFavoriteIds()
                            val favoriteModels = currentList.filter { favIds.contains(it.id) }
                            val nonFavoriteModels = currentList.filter { !favIds.contains(it.id) }

                            val list = mutableListOf<ModelListEntry>()

                            if (favoriteModels.isNotEmpty()) {
                                list.add(ModelListEntry.Header(favHeaderTitle, favoriteModels.size, favoriteModels.firstOrNull()?.id ?: ""))
                                if (collapsedProviders[favHeaderTitle] != true) {
                                    favoriteModels.forEach { item ->
                                        list.add(ModelListEntry.OpenRouterModel(item))
                                    }
                                }
                            }

                            val grouped = nonFavoriteModels.groupBy { item ->
                                getProviderVisualInfo(item.id, item.providerName).name
                            }.toSortedMap()

                            grouped.forEach { (providerName, models) ->
                                list.add(ModelListEntry.Header(providerName, models.size, models.firstOrNull()?.id ?: ""))
                                if (collapsedProviders[providerName] != true) {
                                    models.forEach { item ->
                                        list.add(ModelListEntry.OpenRouterModel(item))
                                    }
                                }
                            }
                            list
                        }

                        AnimatedContent(
                            targetState = selectedCategory,
                            transitionSpec = {
                                fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(180))
                            },
                            label = "OpenRouterCategoryTransition",
                        ) { _ ->
                            LazyColumn(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                items(
                                    items = entries,
                                    key = { entry ->
                                        when (entry) {
                                            is ModelListEntry.Header -> "header_${entry.providerName}"
                                            is ModelListEntry.OpenRouterModel -> "model_${entry.item.id}"
                                            is ModelListEntry.DeepInfraModel -> "deepinfra_${entry.model.id}"
                                        }
                                    },
                                    contentType = { entry ->
                                        when (entry) {
                                            is ModelListEntry.Header -> "header"
                                            is ModelListEntry.OpenRouterModel -> "openrouter_model"
                                            is ModelListEntry.DeepInfraModel -> "deepinfra_model"
                                        }
                                    },
                                ) { entry ->
                                    when (entry) {
                                        is ModelListEntry.Header -> {
                                            val isCollapsed = collapsedProviders[entry.providerName] == true
                                            Surface(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 2.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .clickable {
                                                        collapsedProviders[entry.providerName] = !isCollapsed
                                                    },
                                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f),
                                            ) {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 10.dp, vertical = 6.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                ) {
                                                    ProviderAvatar(
                                                        modelId = entry.sampleModelId,
                                                        providerName = entry.providerName,
                                                        size = 22.dp,
                                                    )
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Text(
                                                        text = entry.providerName,
                                                        style = MaterialTheme.typography.titleSmall,
                                                        fontWeight = FontWeight.Bold,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        modifier = Modifier.weight(1f),
                                                    )
                                                    Surface(
                                                        shape = RoundedCornerShape(10.dp),
                                                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                                    ) {
                                                        Text(
                                                            text = "${entry.count}",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = MaterialTheme.colorScheme.primary,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                        )
                                                    }
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Icon(
                                                        painter = painterResource(
                                                            if (isCollapsed) R.drawable.expand_more else R.drawable.expand_less
                                                        ),
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        modifier = Modifier.size(18.dp),
                                                    )
                                                }
                                            }
                                        }
                                        is ModelListEntry.OpenRouterModel -> {
                                            val item = entry.item
                                            val isSelected = item.id == currentModel
                                            val isFav = favoritesManager.isFavorite(item.id)

                                            Card(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable {
                                                        activeDetailModel = item.toDetailedInfo()
                                                    },
                                                shape = RoundedCornerShape(12.dp),
                                                colors = CardDefaults.cardColors(
                                                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                                                    else MaterialTheme.colorScheme.surface,
                                                ),
                                                border = if (isSelected) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                                                else BorderStroke(0.7.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                                            ) {
                                                Column(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 10.dp, vertical = 8.dp)
                                                ) {
                                                    // Top Row: Avatar + Title & ID + Action Buttons (Never squished!)
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        verticalAlignment = Alignment.CenterVertically,
                                                    ) {
                                                        ProviderAvatar(
                                                            modelId = item.id,
                                                            providerName = item.providerName,
                                                            size = 32.dp,
                                                        )

                                                        Spacer(modifier = Modifier.width(10.dp))

                                                        Column(modifier = Modifier.weight(1f)) {
                                                            Text(
                                                                text = item.name,
                                                                style = MaterialTheme.typography.titleSmall,
                                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                                                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                                                maxLines = 1,
                                                                overflow = TextOverflow.Ellipsis,
                                                            )
                                                            Text(
                                                                text = item.id,
                                                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                                                maxLines = 1,
                                                                overflow = TextOverflow.Ellipsis,
                                                            )
                                                        }

                                                        IconButton(
                                                            onClick = {
                                                                activeDetailModel = item.toDetailedInfo()
                                                            },
                                                            modifier = Modifier.size(32.dp),
                                                        ) {
                                                            Icon(
                                                                painter = painterResource(R.drawable.info),
                                                                contentDescription = stringResource(R.string.ai_model_view_description),
                                                                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                                                                modifier = Modifier.size(18.dp),
                                                            )
                                                        }

                                                        IconButton(
                                                            onClick = {
                                                                favoritesManager.toggleFavorite(item.id)
                                                                favoriteVersion++
                                                            },
                                                            modifier = Modifier.size(32.dp)
                                                        ) {
                                                            Icon(
                                                                painter = painterResource(if (isFav) R.drawable.star else R.drawable.favorite_border),
                                                                contentDescription = null,
                                                                tint = if (isFav) Color(0xFFFFC107) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                                                modifier = Modifier.size(18.dp),
                                                            )
                                                        }

                                                        RadioButton(
                                                            selected = isSelected,
                                                            onClick = {
                                                                favoritesManager.recordModelUsage(item.id)
                                                                viewModel.selectModel(item.id)
                                                                onSelectModel(item.id)
                                                            },
                                                            modifier = Modifier.size(32.dp)
                                                        )
                                                    }

                                                    // Bottom Row: Clean Tags, Latency & TTFT Badges (Never squished)
                                                    FlowRow(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .padding(top = 6.dp),
                                                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                                                        verticalArrangement = Arrangement.spacedBy(4.dp),
                                                    ) {
                                                        ProviderBadge(
                                                            modelId = item.id,
                                                            providerName = item.providerName,
                                                        )

                                                        ModelServiceHealthBadge(
                                                            health = getModelServiceHealth(item.id, item.name, item.contextLength),
                                                        )

                                                        val ttftMs = benchmarkUtility.getEstimatedOrMeasuredTtft(item.id, item.name, item.contextLength)
                                                        val isMeasured = benchmarkUtility.getMeasuredTtft(item.id) != null
                                                        TTFTBadge(
                                                            ttftMs = ttftMs,
                                                            isMeasured = isMeasured,
                                                        )

                                                        ModelStatusBadge(
                                                            status = getModelHealthStatus(item.id, item.name),
                                                        )

                                                        if (item.contextLength > 0) {
                                                            val contextK = item.contextLength / 1000
                                                            Surface(
                                                                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f),
                                                                shape = RoundedCornerShape(4.dp),
                                                            ) {
                                                                Text(
                                                                    text = "${contextK}k ctx",
                                                                    style = MaterialTheme.typography.labelSmall.copy(
                                                                        fontSize = 9.sp,
                                                                        fontWeight = FontWeight.Medium,
                                                                    ),
                                                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.5.dp),
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        else -> {}
                                    }
                                }
                            }
                        }
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                // Custom model input trigger
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onCustomInput)
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        painter = painterResource(R.drawable.edit),
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.ai_model_custom),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.ai_model_select_model))
            }
        },
    )

    activeDetailModel?.let { detailModel ->
        ModelDetailExpandableModal(
            model = detailModel,
            isSelected = detailModel.id == currentModel,
            onSelect = {
                favoritesManager.recordModelUsage(detailModel.id)
                viewModel.selectModel(detailModel.id)
                onSelectModel(detailModel.id)
            },
            onDismiss = { activeDetailModel = null },
            benchmarkUtility = benchmarkUtility,
        )
    }
}

/**
 * Hộp thoại hiển thị chi tiết mô hình OpenRouter: xem mô tả đầy đủ, kiến trúc,
 * ngữ cảnh (context length), chi phí (pricing), và hỗ trợ đo TTFT benchmark trực tiếp.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OpenRouterModelDetailDialog(
    model: OpenRouterModelItem,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onDismiss: () -> Unit,
    benchmarkUtility: ModelBenchmarkUtility,
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isBenchmarkingThis by remember { mutableStateOf(false) }
    var currentTtft by remember {
        mutableStateOf(benchmarkUtility.getEstimatedOrMeasuredTtft(model.id, model.name, model.contextLength))
    }
    var isMeasured by remember {
        mutableStateOf(benchmarkUtility.getMeasuredTtft(model.id) != null)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                ProviderAvatar(
                    modelId = model.id,
                    providerName = model.providerName,
                    size = 36.dp,
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = model.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = model.id,
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                // Status badges FlowRow (never squished)
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    ProviderBadge(
                        modelId = model.id,
                        providerName = model.providerName,
                    )
                    ModelServiceHealthBadge(
                        health = getModelServiceHealth(model.id, model.name, model.contextLength),
                    )
                    TTFTBadge(
                        ttftMs = currentTtft,
                        isMeasured = isMeasured,
                    )
                    ModelStatusBadge(
                        status = getModelHealthStatus(model.id, model.name),
                    )
                }

                // TTFT Benchmark Test Section
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f),
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                Text(text = "⚡", fontSize = 14.sp)
                                Text(
                                    text = stringResource(R.string.ai_model_ttft_benchmark),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                )
                            }
                            Text(
                                text = "${currentTtft}ms",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }

                        Text(
                            text = stringResource(R.string.ai_model_details_benchmark_desc),
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )

                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    isBenchmarkingThis = true
                                    try {
                                        val measured = benchmarkUtility.benchmarkModel(model.id)
                                        currentTtft = measured
                                        isMeasured = true
                                        Toast.makeText(
                                            context,
                                            context.getString(R.string.ai_model_ttft_label, measured),
                                            Toast.LENGTH_SHORT,
                                        ).show()
                                    } finally {
                                        isBenchmarkingThis = false
                                    }
                                }
                            },
                            enabled = !isBenchmarkingThis,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                        ) {
                            if (isBenchmarkingThis) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.onPrimary,
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(stringResource(R.string.ai_model_ttft_benchmarking))
                            } else {
                                Icon(
                                    painter = painterResource(R.drawable.speed),
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(stringResource(R.string.ai_model_details_benchmark_now))
                            }
                        }
                    }
                }

                // Specification Grid: Context Window & Pricing
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        ),
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text(
                                text = stringResource(R.string.ai_model_details_context),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            val ctxText = if (model.contextLength > 0) {
                                val k = model.contextLength / 1000
                                "${k}k tokens"
                            } else {
                                "Standard"
                            }
                            Text(
                                text = ctxText,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }

                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        ),
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text(
                                text = stringResource(R.string.ai_model_details_pricing),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            val pricingText = if (model.pricing.isBlank() || model.pricing == "Free") {
                                "Free / Tier"
                            } else {
                                "Pay-per-token"
                            }
                            Text(
                                text = pricingText,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }

                // Model Description
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text(
                        text = stringResource(R.string.ai_model_description_title),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                    )
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        ),
                    ) {
                        val descText = if (model.description.isNotBlank()) {
                            model.description
                        } else {
                            val providerInfo = getProviderVisualInfo(model.id, model.providerName)
                            "${model.name} is an advanced AI language model hosted via ${providerInfo.name} on the OpenRouter network, providing high quality text processing, reasoning, and song lyrics translation capabilities."
                        }
                        Text(
                            text = descText,
                            style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp),
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(10.dp),
                        )
                    }
                }
            }
        },
        confirmButton = {
            if (!isSelected) {
                Button(
                    onClick = {
                        onSelect()
                        onDismiss()
                    },
                    shape = RoundedCornerShape(8.dp),
                ) {
                    Text(stringResource(R.string.ai_model_select_model))
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.close))
            }
        },
    )
}
