/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.component

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import com.listrovia.music.R
import com.listrovia.music.api.DeepInfraModelItem
import com.listrovia.music.api.OpenRouterModelItem
import com.listrovia.music.utils.ModelBenchmarkUtility
import com.listrovia.music.utils.TTFTBadge
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Cấu trúc dữ liệu chi tiết của mô hình AI cho hộp thoại mở rộng (Expandable Modal Dialog).
 */
data class DetailedAiModelInfo(
    val id: String,
    val name: String,
    val providerName: String,
    val description: String,
    val contextLength: Long = 0L,
    val inputCost: Double = 0.0,
    val outputCost: Double = 0.0,
    val pricingText: String = "",
    val isReasoning: Boolean = false,
    val rank: Int = 999,
    val rankTitle: String = "",
    val isChat: Boolean = true,
    val providerService: String = "OpenRouter",
)

fun OpenRouterModelItem.toDetailedInfo(): DetailedAiModelInfo {
    val idLower = id.lowercase()
    val isReasoningModel = idLower.contains("r1") || idLower.contains("reasoner") ||
            idLower.contains("thinking") || idLower.contains("o1") || idLower.contains("o3")
    return DetailedAiModelInfo(
        id = id,
        name = name,
        providerName = providerName,
        description = description,
        contextLength = contextLength,
        pricingText = pricing,
        isReasoning = isReasoningModel,
        providerService = "OpenRouter",
    )
}

fun DeepInfraModelItem.toDetailedInfo(isVietnamese: Boolean = false): DetailedAiModelInfo {
    return DetailedAiModelInfo(
        id = id,
        name = name,
        providerName = providerName,
        description = getDescriptionByLanguage(isVietnamese),
        contextLength = contextLength,
        inputCost = inputCost,
        outputCost = outputCost,
        pricingText = pricingBadge,
        isReasoning = isReasoning,
        rank = rank,
        rankTitle = getRankTitleByLanguage(isVietnamese),
        isChat = isChat,
        providerService = "DeepInfra",
    )
}

/**
 * Hộp thoại phương thức mở rộng (Expandable Modal Dialog) xuất hiện khi người dùng nhấn vào bất kỳ mô hình nào.
 * Cung cấp đầy đủ thông tin chi tiết về:
 * - Khả năng của mô hình (Capabilities: Suy luận, dịch lời bài hát, đa phương thức, tốc độ)
 * - Cửa sổ ngữ cảnh (Context Window)
 * - Chi phí sử dụng (Pricing & Cost)
 * - Tiện ích đo tốc độ TTFT trực tiếp và thông số kỹ thuật mở rộng
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ModelDetailExpandableModal(
    model: DetailedAiModelInfo,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onDismiss: () -> Unit,
    benchmarkUtility: ModelBenchmarkUtility,
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val isVietnamese = remember { Locale.getDefault().language == "vi" }

    var isTechnicalSpecsExpanded by remember { mutableStateOf(false) }
    var isBenchmarking by remember { mutableStateOf(false) }
    var currentTtft by remember {
        mutableStateOf(benchmarkUtility.getEstimatedOrMeasuredTtft(model.id, model.name, model.contextLength))
    }
    var isMeasured by remember {
        mutableStateOf(benchmarkUtility.getMeasuredTtft(model.id) != null)
    }

    val visualInfo = remember(model.id, model.providerName) {
        getProviderVisualInfo(model.id, model.providerName)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier
            .widthIn(min = 280.dp, max = 460.dp)
            .fillMaxWidth(0.92f)
            .heightIn(max = 620.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                ProviderAvatar(
                    modelId = model.id,
                    providerName = model.providerName,
                    size = 38.dp,
                )

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Text(
                            text = model.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false),
                        )
                        if (isSelected) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = MaterialTheme.colorScheme.primaryContainer,
                            ) {
                                Text(
                                    text = if (isVietnamese) "Đang chọn" else "Active",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                                )
                            }
                        }
                    }

                    Text(
                        text = model.id,
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.5.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )

                    Text(
                        text = "${visualInfo.name} • ${model.providerService}",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.5.sp),
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium,
                    )
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(32.dp),
                ) {
                    Icon(
                        painter = painterResource(R.drawable.close),
                        contentDescription = stringResource(R.string.close),
                        modifier = Modifier.size(18.dp),
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                // Status Badges Row (Never wrapped awkwardly)
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    ProviderBadge(
                        modelId = model.id,
                        providerName = model.providerName,
                    )

                    ModelServiceHealthBadge(
                        health = getModelServiceHealth(model.id, model.name, model.contextLength),
                    )

                    TTFTBadge(
                        ttftMs = currentTtft,
                        isMeasured = isMeasured,
                    )

                    ModelStatusBadge(
                        status = getModelHealthStatus(model.id, model.name),
                    )

                    if (model.rankTitle.isNotBlank()) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = MaterialTheme.colorScheme.tertiaryContainer,
                        ) {
                            Text(
                                text = model.rankTitle,
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onTertiaryContainer,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.5.dp),
                            )
                        }
                    }
                }

                // 1. Model Capabilities Section (Khả năng của mô hình)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    ),
                    border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Text(text = "✨", fontSize = 13.sp)
                            Text(
                                text = stringResource(R.string.ai_model_capabilities_title),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                        }

                        // Capability Items
                        if (model.isReasoning) {
                            CapabilityItemRow(
                                icon = "🧠",
                                title = stringResource(R.string.ai_model_cap_reasoning),
                                desc = stringResource(R.string.ai_model_cap_reasoning_desc),
                                highlightColor = MaterialTheme.colorScheme.error,
                            )
                        }

                        CapabilityItemRow(
                            icon = "🎵",
                            title = stringResource(R.string.ai_model_cap_lyrics),
                            desc = stringResource(R.string.ai_model_cap_lyrics_desc),
                            highlightColor = MaterialTheme.colorScheme.primary,
                        )

                        if (currentTtft <= 350L || model.id.contains("flash") || model.id.contains("mini") || model.id.contains("8b")) {
                            CapabilityItemRow(
                                icon = "⚡",
                                title = stringResource(R.string.ai_model_cap_speed),
                                desc = stringResource(R.string.ai_model_cap_speed_desc),
                                highlightColor = Color(0xFF2E7D32),
                            )
                        }

                        val idLower = model.id.lowercase()
                        if (idLower.contains("vision") || idLower.contains("4o") || idLower.contains("gemini") || idLower.contains("claude-3")) {
                            CapabilityItemRow(
                                icon = "👁️",
                                title = stringResource(R.string.ai_model_cap_vision),
                                desc = stringResource(R.string.ai_model_cap_vision_desc),
                                highlightColor = Color(0xFF0277BD),
                            )
                        }
                    }
                }

                // 2. Context Window & Pricing Grid (Cửa sổ ngữ cảnh & Chi phí)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    // Context Window Card
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f),
                        ),
                        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.25f)),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                            ) {
                                Text(text = "📏", fontSize = 11.sp)
                                Text(
                                    text = stringResource(R.string.ai_model_context_title),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                )
                            }

                            val ctxDisplay = when {
                                model.contextLength >= 1048576L -> "${model.contextLength / 1048576L}M tokens"
                                model.contextLength >= 1024L -> "${model.contextLength / 1024L}k tokens"
                                model.contextLength > 0L -> "${model.contextLength} tokens"
                                else -> "128k tokens"
                            }
                            Text(
                                text = ctxDisplay,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                            )
                            Text(
                                text = stringResource(R.string.ai_model_context_tokens, ctxDisplay),
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                                color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f),
                            )
                        }
                    }

                    // Pricing Card
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.45f),
                        ),
                        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.25f)),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                            ) {
                                Text(text = "🏷️", fontSize = 11.sp)
                                Text(
                                    text = stringResource(R.string.ai_model_pricing_title),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                                )
                            }

                            val isFree = model.pricingText == "Free" || (model.inputCost == 0.0 && model.outputCost == 0.0 && model.pricingText.isBlank())
                            if (isFree) {
                                Text(
                                    text = if (isVietnamese) "Miễn phí" else "Free Tier",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF2E7D32),
                                )
                                Text(
                                    text = stringResource(R.string.ai_model_pricing_free),
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                                    color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.8f),
                                )
                            } else {
                                val inputStr = if (model.inputCost > 0.0) String.format(Locale.US, "$%.2f", model.inputCost) else "$0.15"
                                val outputStr = if (model.outputCost > 0.0) String.format(Locale.US, "$%.2f", model.outputCost) else "$0.60"
                                Text(
                                    text = "$inputStr / $outputStr",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Text(
                                    text = stringResource(R.string.ai_model_pricing_input, inputStr),
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                                    color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.8f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                }

                // 3. TTFT Benchmark Interactive Card (Đo tốc độ phản hồi)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f),
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                Text(text = "⚡", fontSize = 13.sp)
                                Text(
                                    text = stringResource(R.string.ai_model_ttft_benchmark),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                )
                            }
                            Text(
                                text = "${currentTtft}ms",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }

                        Text(
                            text = stringResource(R.string.ai_model_details_benchmark_desc),
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.5.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )

                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    isBenchmarking = true
                                    try {
                                        val testUrl = if (model.providerService == "DeepInfra") "https://api.deepinfra.com/v1/openai/models"
                                        else "https://openrouter.ai/api/v1/models"
                                        val measured = benchmarkUtility.benchmarkModel(model.id, baseUrl = testUrl)
                                        currentTtft = measured
                                        isMeasured = true
                                        Toast.makeText(
                                            context,
                                            context.getString(R.string.ai_model_ttft_label, measured),
                                            Toast.LENGTH_SHORT,
                                        ).show()
                                    } finally {
                                        isBenchmarking = false
                                    }
                                }
                            },
                            enabled = !isBenchmarking,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 6.dp),
                        ) {
                            if (isBenchmarking) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.onPrimary,
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(stringResource(R.string.ai_model_ttft_benchmarking))
                            } else {
                                Icon(
                                    painter = painterResource(R.drawable.speed),
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(stringResource(R.string.ai_model_details_benchmark_now))
                            }
                        }
                    }
                }

                // 4. Model Overview & Description
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text(
                        text = stringResource(R.string.ai_model_description_title),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                    )
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                        ),
                    ) {
                        val descText = if (model.description.isNotBlank()) {
                            model.description
                        } else {
                            if (isVietnamese) {
                                "${model.name} là mô hình trí tuệ nhân tạo thế hệ mới được tối ưu hóa cho dịch thuật lời bài hát, thích ứng ngữ điệu âm nhạc và hỗ trợ xử lý ngôn ngữ tự nhiên độ chính xác cao."
                            } else {
                                "${model.name} is a next-generation AI model optimized for music lyrics translation, contextual poetic adaptation, and reliable high-precision language understanding."
                            }
                        }
                        Text(
                            text = descText,
                            style = MaterialTheme.typography.bodySmall.copy(lineHeight = 17.sp),
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(10.dp),
                        )
                    }
                }

                // 5. Expandable Technical Specs
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { isTechnicalSpecsExpanded = !isTechnicalSpecsExpanded }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            text = if (isTechnicalSpecsExpanded) stringResource(R.string.ai_model_details_collapse)
                            else stringResource(R.string.ai_model_details_expand),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                        )
                        Icon(
                            painter = painterResource(
                                if (isTechnicalSpecsExpanded) R.drawable.expand_less else R.drawable.expand_more
                            ),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp),
                        )
                    }

                    AnimatedVisibility(
                        visible = isTechnicalSpecsExpanded,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically(),
                    ) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                            border = BorderStroke(0.6.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                SpecItemRow(
                                    if (isVietnamese) "Nhà cung cấp dịch vụ" else "Service Provider",
                                    model.providerService,
                                )
                                SpecItemRow(
                                    if (isVietnamese) "Mã định danh" else "Model Identifier",
                                    model.id,
                                )
                                SpecItemRow(
                                    if (isVietnamese) "Thương hiệu phát hành" else "Brand / Publisher",
                                    visualInfo.name,
                                )
                                SpecItemRow(
                                    if (isVietnamese) "Dung lượng ngữ cảnh" else "Context Memory",
                                    "${model.contextLength} tokens",
                                )
                                SpecItemRow(
                                    if (isVietnamese) "Chế độ suy luận" else "Reasoning Mode",
                                    if (model.isReasoning) (if (isVietnamese) "Kích hoạt (Chuỗi tư duy)" else "Enabled (Chain-of-Thought)")
                                    else (if (isVietnamese) "Suy luận tốc độ cao" else "Standard Fast Inference"),
                                )
                                SpecItemRow(
                                    if (isVietnamese) "Đánh giá an toàn" else "Safety Rating",
                                    if (isVietnamese) "Đã kiểm chứng an toàn" else "Verified Safe & Production Ready",
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSelect()
                    onDismiss()
                },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                ),
            ) {
                Text(
                    text = stringResource(R.string.ai_model_action_select),
                    fontWeight = FontWeight.Bold,
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.close))
            }
        },
    )
}

@Composable
private fun CapabilityItemRow(
    icon: String,
    title: String,
    desc: String,
    highlightColor: Color,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(text = icon, fontSize = 13.sp, modifier = Modifier.padding(top = 1.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = highlightColor,
            )
            Text(
                text = desc,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp, lineHeight = 13.5.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f),
            )
        }
    }
}

@Composable
private fun SpecItemRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
