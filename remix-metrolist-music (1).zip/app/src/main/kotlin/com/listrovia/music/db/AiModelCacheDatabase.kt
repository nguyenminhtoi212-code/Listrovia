/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.listrovia.music.db.daos.AiModelCacheDao
import com.listrovia.music.db.entities.AiModelCacheEntity

@Database(
    entities = [AiModelCacheEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class AiModelCacheDatabase : RoomDatabase() {
    abstract fun aiModelCacheDao(): AiModelCacheDao

    companion object {
        @Volatile
        private var instance: AiModelCacheDatabase? = null

        fun getInstance(context: Context): AiModelCacheDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AiModelCacheDatabase::class.java,
                    "ai_models_cache.db",
                ).fallbackToDestructiveMigration().build().also { instance = it }
            }
        }
    }
}
