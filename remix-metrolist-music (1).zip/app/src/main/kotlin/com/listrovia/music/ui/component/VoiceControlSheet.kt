/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.component

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.listrovia.music.LocalPlayerConnection
import com.listrovia.music.R
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceControlBottomSheet(
    onDismiss: () -> Unit,
    navController: NavController,
) {
    val context = LocalContext.current
    val playerConnection = LocalPlayerConnection.current
    val voiceMode by com.listrovia.music.utils.rememberPreference(com.listrovia.music.constants.VoiceFeatureModeKey, "search")

    var isListening by remember { mutableStateOf(false) }
    var recognizedText by remember { mutableStateOf("") }
    var statusText by remember { mutableStateOf("") }
    
    val listeningStatus = stringResource(R.string.voice_listening)
    val promptStatus = stringResource(R.string.voice_control_prompt)
    
    LaunchedEffect(isListening) {
        statusText = if (isListening) listeningStatus else promptStatus
    }

    val speechRecognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            SpeechRecognizer.createSpeechRecognizer(context)
        } else {
            null
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            isListening = true
            startListening(speechRecognizer, context, { text ->
                recognizedText = text
                handleVoiceCommand(text, voiceMode, playerConnection, navController, context, onDismiss)
            }, {
                isListening = false
            })
        } else {
            Toast.makeText(context, context.getString(R.string.voice_permission_required), Toast.LENGTH_SHORT).show()
            onDismiss()
        }
    }

    LaunchedEffect(Unit) {
        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    DisposableEffect(Unit) {
        onDispose {
            try {
                speechRecognizer?.stopListening()
                speechRecognizer?.destroy()
            } catch (e: Exception) {
            }
        }
    }

    val pulseAnim = remember { Animatable(1f) }
    LaunchedEffect(isListening) {
        if (isListening) {
            pulseAnim.animateTo(
                targetValue = 1.3f,
                animationSpec = infiniteRepeatable(
                    animation = tween(800, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                )
            )
        } else {
            pulseAnim.animateTo(1f)
        }
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(),
                contentAlignment = Alignment.CenterEnd
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(
                        painter = painterResource(R.drawable.close),
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Text(
                text = stringResource(R.string.voice_control_title),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Pulsing Mic Icon
            Box(
                modifier = Modifier
                    .size(100.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size((80 * pulseAnim.value).dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f))
                )
                Surface(
                    onClick = {
                        if (!isListening) {
                            isListening = true
                            startListening(speechRecognizer, context, { text ->
                                recognizedText = text
                                handleVoiceCommand(text, voiceMode, playerConnection, navController, context, onDismiss)
                            }, {
                                isListening = false
                            })
                        }
                    },
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(64.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            painter = painterResource(R.drawable.mic),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }
            }

            Text(
                text = statusText,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            if (recognizedText.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = stringResource(R.string.voice_command_recognized, recognizedText),
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(16.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

private fun startListening(
    speechRecognizer: SpeechRecognizer?,
    context: android.content.Context,
    onResult: (String) -> Unit,
    onError: () -> Unit
) {
    if (speechRecognizer == null) {
        Toast.makeText(context, "Speech recognizer unavailable", Toast.LENGTH_SHORT).show()
        onError()
        return
    }
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        putExtra(RecognizerIntent.EXTRA_PROMPT, "Listening...")
    }
    speechRecognizer.setRecognitionListener(object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {
            onError()
        }
        override fun onError(error: Int) {
            val message = when (error) {
                SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                SpeechRecognizer.ERROR_CLIENT -> "Client side error"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Insufficient permissions"
                SpeechRecognizer.ERROR_NETWORK -> "Network error"
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
                SpeechRecognizer.ERROR_NO_MATCH -> "No match"
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "RecognitionService busy"
                SpeechRecognizer.ERROR_SERVER -> "Error from server"
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech input"
                else -> "Unknown error"
            }
            if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
            }
            onError()
        }
        override fun onResults(results: Bundle?) {
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (!matches.isNullOrEmpty()) {
                onResult(matches[0])
            }
            onError()
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    })
    try {
        speechRecognizer.startListening(intent)
    } catch (e: Exception) {
        onError()
    }
}

private fun handleVoiceCommand(
    command: String,
    voiceMode: String,
    playerConnection: com.listrovia.music.playback.PlayerConnection?,
    navController: NavController,
    context: android.content.Context,
    onDismiss: () -> Unit
) {
    val lower = command.lowercase(Locale.getDefault())

    when {
        voiceMode == "playback" && (lower.contains("play") || lower.contains("phát") || lower.contains("tiếp tục")) -> {
            playerConnection?.play()
            onDismiss()
        }
        voiceMode == "playback" && (lower.contains("pause") || lower.contains("dừng") || lower.contains("ngừng")) -> {
            playerConnection?.pause()
            onDismiss()
        }
        voiceMode == "playback" && (lower.contains("next") || lower.contains("tiếp")) -> {
            playerConnection?.seekToNext()
            onDismiss()
        }
        voiceMode == "playback" && (lower.contains("previous") || lower.contains("lùi") || lower.contains("trước")) -> {
            playerConnection?.seekToPrevious()
            onDismiss()
        }
        voiceMode == "search" && (lower.contains("search") || lower.contains("tìm kiếm") || lower.contains("tìm")) -> {
            val query = lower.replace("search", "").replace("tìm kiếm", "").replace("tìm", "").trim()
            if (query.isNotBlank()) {
                navController.navigate("search/${android.net.Uri.encode(query)}")
                onDismiss()
            }
        }
        voiceMode == "search" -> {
            // Default search mode: treat whole command as query
            navController.navigate("search/${android.net.Uri.encode(command)}")
            onDismiss()
        }
        voiceMode == "ai" -> {
            // AI / Translation mode - For now, let's just show the text and maybe a placeholder toast
            // or navigate to an AI screen if it exists.
            Toast.makeText(context, "AI Mode: $command", Toast.LENGTH_LONG).show()
            onDismiss()
        }
        else -> {
            // Fallback
            navController.navigate("search/${android.net.Uri.encode(command)}")
            onDismiss()
        }
    }
}
