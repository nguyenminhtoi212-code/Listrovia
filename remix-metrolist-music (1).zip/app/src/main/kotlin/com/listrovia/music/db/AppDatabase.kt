package com.listrovia.music.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.listrovia.music.db.daos.SetVideoIdDao
import com.listrovia.music.db.entities.SetVideoIdEntity

@Database(
    entities = [SetVideoIdEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun setVideoIdDao(): SetVideoIdDao
}
