/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.player

import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.viewinterop.AndroidView
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebChromeClient
import android.webkit.CookieManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.content.Context
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import com.bumptech.glide.Glide

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyHorizontalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import coil3.compose.AsyncImage
import coil3.request.CachePolicy
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.listrovia.music.LocalListenTogetherManager
import com.listrovia.music.LocalPlayerConnection
import com.listrovia.music.R
import com.listrovia.music.utils.AuraPlayerUtils
import com.listrovia.music.constants.CropAlbumArtKey
import com.listrovia.music.constants.HidePlayerThumbnailKey
import com.listrovia.music.constants.PlayerBackgroundStyle
import com.listrovia.music.constants.PlayerBackgroundStyleKey
import com.listrovia.music.constants.PlayerHorizontalPadding
import com.listrovia.music.constants.SeekExtraSeconds
import com.listrovia.music.constants.SwipeThumbnailKey
import com.listrovia.music.constants.ThumbnailCornerRadius
import com.listrovia.music.constants.ThumbnailCornerRadiusKey
import com.listrovia.music.constants.EnableRotatingThumbnailKey
import com.listrovia.music.listentogether.RoomRole
import com.listrovia.music.utils.rememberEnumPreference
import com.listrovia.music.utils.rememberPreference
import com.listrovia.music.LocalNavController
import com.listrovia.music.video.VideoPlaybackManager
import com.listrovia.music.video.AndroidVideoSurface
import kotlinx.coroutines.delay

private fun isNetworkConnected(context: Context): Boolean {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return true
    val network = cm.activeNetwork ?: return false
    val caps = cm.getNetworkCapabilities(network) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

/**
 * Pre-calculated thumbnail dimensions to avoid repeated calculations during recomposition.
 * All values are computed once and cached.
 */
@Immutable
data class ThumbnailDimensions(
    val itemWidth: Dp,
    val containerSize: Dp,
    val thumbnailSize: Dp,
    val cornerRadius: Dp
)

/**
 * Cached media items data to prevent recalculation on every recomposition.
 */
@Immutable
data class MediaItemsData(
    val items: List<MediaItem>,
    val currentIndex: Int
)

/**
 * Calculate thumbnail dimensions once based on container size.
 * This function is marked as @Stable to indicate it produces stable results.
 * In landscape mode, uses the smaller dimension (height) to ensure square thumbnail fits.
 */
@Stable
private fun calculateThumbnailDimensions(
    containerWidth: Dp,
    containerHeight: Dp = containerWidth,
    horizontalPadding: Dp = PlayerHorizontalPadding,
    cornerRadius: Dp = ThumbnailCornerRadius,
    isLandscape: Boolean = false
): ThumbnailDimensions {
    // Constrain the square thumbnail size to never exceed the container's height (leaving safe padding)
    val maxAllowedHeight = containerHeight - 24.dp
    val effectiveSize = if (isLandscape) {
        minOf(containerWidth, containerHeight) - (horizontalPadding * 2)
    } else {
        minOf(containerWidth, maxAllowedHeight) - (horizontalPadding * 2)
    }.coerceAtLeast(120.dp)

    return ThumbnailDimensions(
        itemWidth = containerWidth,
        containerSize = containerWidth,
        thumbnailSize = effectiveSize,
        cornerRadius = cornerRadius
    )
}

/**
 * Get media items for the thumbnail carousel.
 * Calculates previous, current, and next items based on shuffle mode.
 */
@Stable
private fun getMediaItems(
    player: Player,
    swipeThumbnail: Boolean
): MediaItemsData {
    val timeline = player.currentTimeline
    val currentIndex = player.currentMediaItemIndex
    val shuffleModeEnabled = player.shuffleModeEnabled
    
    val currentMediaItem = try {
        player.currentMediaItem
    } catch (e: Exception) { null }
    
    val previousMediaItem = if (swipeThumbnail && !timeline.isEmpty) {
        val previousIndex = timeline.getPreviousWindowIndex(
            currentIndex,
            Player.REPEAT_MODE_OFF,
            shuffleModeEnabled
        )
        if (previousIndex != C.INDEX_UNSET) {
            try { player.getMediaItemAt(previousIndex) } catch (e: Exception) { null }
        } else null
    } else null

    val nextMediaItem = if (swipeThumbnail && !timeline.isEmpty) {
        val nextIndex = timeline.getNextWindowIndex(
            currentIndex,
            Player.REPEAT_MODE_OFF,
            shuffleModeEnabled
        )
        if (nextIndex != C.INDEX_UNSET) {
            try { player.getMediaItemAt(nextIndex) } catch (e: Exception) { null }
        } else null
    } else null

    val items = listOfNotNull(previousMediaItem, currentMediaItem, nextMediaItem)
    val currentMediaIndex = items.indexOf(currentMediaItem)
    
    return MediaItemsData(items, currentMediaIndex)
}

/**
 * Get text color based on player background style.
 * Computed once per background style change.
 */
@Stable
@Composable
private fun getTextColor(playerBackground: PlayerBackgroundStyle): Color {
    return when (playerBackground) {
        PlayerBackgroundStyle.DEFAULT -> MaterialTheme.colorScheme.onBackground
        else -> Color.White
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Thumbnail(
    sliderPositionProvider: () -> Long?,
    modifier: Modifier = Modifier,
    isPlayerExpanded: () -> Boolean = { true },
    isLandscape: Boolean = false,
    isListenTogetherGuest: Boolean = false,
    isVideoMode: Boolean = false,
) {
    val playerConnection = LocalPlayerConnection.current ?: return
    val context = LocalContext.current
    val layoutDirection = LocalLayoutDirection.current

    // Collect states
    val mediaMetadata by playerConnection.mediaMetadata.collectAsState()
    val error by playerConnection.error.collectAsState()
    val queueTitle by playerConnection.queueTitle.collectAsStateWithLifecycle()
    val canSkipPrevious by playerConnection.canSkipPrevious.collectAsStateWithLifecycle()
    val canSkipNext by playerConnection.canSkipNext.collectAsStateWithLifecycle()

    // Preferences - computed once
    // Disable swipe for Listen Together guests
    val thumbnailCornerRadiusFloat by rememberPreference(ThumbnailCornerRadiusKey, 12f)
    val swipeThumbnailPref by rememberPreference(SwipeThumbnailKey, true)
    val swipeThumbnail = swipeThumbnailPref && !isListenTogetherGuest
    val hidePlayerThumbnail by rememberPreference(HidePlayerThumbnailKey, false)
    val cropAlbumArt by rememberPreference(CropAlbumArtKey, false)
    val isPlaying by playerConnection.isPlaying.collectAsState()
    val playerBackground by rememberEnumPreference(
        key = PlayerBackgroundStyleKey,
        defaultValue = PlayerBackgroundStyle.DEFAULT
    )
    
    // Pre-calculate text color based on background style
    val textBackgroundColor = getTextColor(playerBackground)
    
    // Grid state
    val thumbnailLazyGridState = rememberLazyGridState()
    
    // Calculate media items data - memoized
    val mediaItemsData by remember(
        playerConnection.player.currentMediaItemIndex,
        playerConnection.player.shuffleModeEnabled,
        swipeThumbnail,
        mediaMetadata
    ) {
        derivedStateOf {
            getMediaItems(playerConnection.player, swipeThumbnail)
        }
    }
    
    val mediaItems = mediaItemsData.items
    val currentMediaIndex = mediaItemsData.currentIndex

    // Snap behavior - created once per grid state
    val thumbnailSnapLayoutInfoProvider = remember(thumbnailLazyGridState) {
        ThumbnailSnapLayoutInfoProvider(
            lazyGridState = thumbnailLazyGridState,
            positionInLayout = { layoutSize, itemSize ->
                (layoutSize / 2f - itemSize / 2f)
            },
            velocityThreshold = 500f
        )
    }

    // Current item tracking - derived state for efficiency
    val currentItem by remember { derivedStateOf { thumbnailLazyGridState.firstVisibleItemIndex } }
    val itemScrollOffset by remember { derivedStateOf { thumbnailLazyGridState.firstVisibleItemScrollOffset } }

    // Handle swipe to change song
    LaunchedEffect(itemScrollOffset) {
        if (!thumbnailLazyGridState.isScrollInProgress || !swipeThumbnail || itemScrollOffset != 0 || currentMediaIndex < 0) return@LaunchedEffect

        if (currentItem > currentMediaIndex && canSkipNext) {
            playerConnection.player.seekToNext()
        } else if (currentItem < currentMediaIndex && canSkipPrevious) {
            playerConnection.player.seekToPreviousMediaItem()
        }
    }

    // Update position when song changes
    LaunchedEffect(mediaMetadata, canSkipPrevious, canSkipNext) {
        val index = maxOf(0, currentMediaIndex)
        if (index >= 0 && index < mediaItems.size) {
            try {
                thumbnailLazyGridState.animateScrollToItem(index)
            } catch (e: Exception) {
                thumbnailLazyGridState.scrollToItem(index)
            }
        }
    }

    LaunchedEffect(playerConnection.player.currentMediaItemIndex) {
        val index = mediaItemsData.currentIndex
        if (index >= 0 && index != currentItem) {
            thumbnailLazyGridState.scrollToItem(index)
        }
    }

    // Seek effect state
    var showSeekEffect by remember { mutableStateOf(false) }
    var seekDirection by remember { mutableStateOf("") }

    Box(
        modifier = modifier
            .graphicsLayer {
                compositingStrategy = CompositingStrategy.Auto
            }
    ) {
        // Error view
        AnimatedVisibility(
            visible = error != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .padding(32.dp)
                .align(Alignment.Center),
        ) {
            error?.let { playbackError ->
                PlaybackError(
                    error = playbackError,
                    retry = playerConnection::retry,
                )
            }
        }

        // Main thumbnail view
        AnimatedVisibility(
            visible = error == null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .fillMaxSize()
                .then(if (!isLandscape) Modifier.statusBarsPadding() else Modifier),
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = if (isLandscape) Arrangement.Center else Arrangement.Top
            ) {
                // Now Playing header - hide in landscape mode
                if (!isLandscape) {
                    ThumbnailHeader(
                        queueTitle = queueTitle,
                        albumTitle = mediaMetadata?.album?.title,
                        songTitle = mediaMetadata?.title,
                        textColor = textBackgroundColor
                    )
                }
                
                // Thumbnail content
                BoxWithConstraints(
                    contentAlignment = Alignment.Center,
                    modifier = if (isLandscape) {
                        Modifier.weight(1f, false)
                    } else {
                        Modifier.weight(1f)
                    }
                ) {
                    // Calculate dimensions once per size change, considering landscape mode
                    val dimensions = remember(maxWidth, maxHeight, isLandscape, thumbnailCornerRadiusFloat) {
                        calculateThumbnailDimensions(
                            containerWidth = maxWidth,
                            containerHeight = maxHeight,
                            cornerRadius = thumbnailCornerRadiusFloat.dp,
                            isLandscape = isLandscape
                        )
                    }

                    // Remember the onSeek callback to prevent recomposition
                    val onSeekCallback = remember {
                        { direction: String, showEffect: Boolean ->
                            seekDirection = direction
                            showSeekEffect = showEffect
                        }
                    }
                    
                    // Derive scroll enabled state to prevent unnecessary recomposition
                    val isScrollEnabled by remember(swipeThumbnail) {
                        derivedStateOf { swipeThumbnail && isPlayerExpanded() }
                    }
                    
                    LazyHorizontalGrid(
                        state = thumbnailLazyGridState,
                        rows = GridCells.Fixed(1),
                        flingBehavior = rememberSnapFlingBehavior(thumbnailSnapLayoutInfoProvider),
                        userScrollEnabled = isScrollEnabled,
                        modifier = if (isLandscape) {
                            Modifier.size(dimensions.thumbnailSize + (PlayerHorizontalPadding * 2))
                        } else {
                            Modifier.fillMaxSize()
                        }
                    ) {
                        items(
                            items = mediaItems,
                            key = { item -> 
                                item.mediaId.ifEmpty { "unknown_${item.hashCode()}" }
                            }
                        ) { item ->
                            ThumbnailItem(
                                item = item,
                                dimensions = dimensions,
                                hidePlayerThumbnail = hidePlayerThumbnail,
                                cropAlbumArt = cropAlbumArt,
                                textBackgroundColor = textBackgroundColor,
                                layoutDirection = layoutDirection,
                                onSeek = onSeekCallback,
                                playerConnection = playerConnection,
                                context = context,
                                isLandscape = isLandscape,
                                isListenTogetherGuest = isListenTogetherGuest,
                                currentMediaId = mediaMetadata?.id,
                                currentMediaThumbnail = mediaMetadata?.thumbnailUrl,
                                isVideoMode = isVideoMode
                            )
                        }
                    }
                }
            }
        }

        // Seek effect
        LaunchedEffect(showSeekEffect) {
            if (showSeekEffect) {
                delay(1000)
                showSeekEffect = false
            }
        }

        AnimatedVisibility(
            visible = showSeekEffect,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            SeekEffectOverlay(seekDirection = seekDirection)
        }
    }
}

/**
 * Header component showing "Now Playing" and queue/album title.
 */
@Composable
private fun ThumbnailHeader(
    queueTitle: String?,
    albumTitle: String?,
    songTitle: String? = null,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    val listenTogetherManager = LocalListenTogetherManager.current
    val listenTogetherRoleState = listenTogetherManager?.role?.collectAsStateWithLifecycle(initialValue = RoomRole.NONE)
    val isListenTogetherGuest = listenTogetherRoleState?.value == RoomRole.GUEST
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .align(Alignment.Center)
                .padding(horizontal = 48.dp)
        ) {
            // Listen Together indicator
            if (listenTogetherRoleState?.value != RoomRole.NONE) {
                Text(
                    text = if (listenTogetherRoleState?.value == RoomRole.HOST) "Hosting Listen Together" else "Listening Together",
                    style = MaterialTheme.typography.titleMedium,
                    color = textColor
                )
            } else {
                Text(
                    text = stringResource(R.string.now_playing),
                    style = MaterialTheme.typography.titleMedium,
                    color = textColor
                )
            }
            val playingFrom = when {
                !queueTitle.isNullOrBlank() && queueTitle != songTitle -> queueTitle
                !albumTitle.isNullOrBlank() && albumTitle != songTitle -> albumTitle
                else -> null
            }
            if (!playingFrom.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = playingFrom,
                    style = MaterialTheme.typography.titleSmall,
                    color = textColor.copy(alpha = 0.8f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.basicMarquee()
                )
            }
        }
    }
}

/**
 * Individual thumbnail item in the carousel.
 */
@Composable
private fun ThumbnailItem(
    item: MediaItem,
    dimensions: ThumbnailDimensions,
    hidePlayerThumbnail: Boolean,
    cropAlbumArt: Boolean,
    textBackgroundColor: Color,
    layoutDirection: LayoutDirection,
    onSeek: (String, Boolean) -> Unit,
    playerConnection: com.listrovia.music.playback.PlayerConnection,
    context: android.content.Context,
    isLandscape: Boolean = false,
    isListenTogetherGuest: Boolean = false,
    currentMediaId: String? = null,
    currentMediaThumbnail: String? = null,
    isVideoMode: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val enableRotatingThumbnail by rememberPreference(EnableRotatingThumbnailKey, false)
    val isPlayingState by playerConnection.isPlaying.collectAsState()

    val infiniteTransition = rememberInfiniteTransition(label = "thumbnailRotation")
    val angle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(15000, easing = androidx.compose.animation.core.LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "angle"
    )
    val rotationAngle = if (enableRotatingThumbnail && isPlayingState && !isVideoMode) angle else 0f

    val incrementalSeekSkipEnabled by rememberPreference(SeekExtraSeconds, defaultValue = false)
    val (doubleTapToSeek, _) = rememberPreference(
        key = androidx.datastore.preferences.core.stringPreferencesKey("doubleTapToSeek"),
        defaultValue = "10 giây"
    )
    var skipMultiplier by remember { mutableIntStateOf(1) }
    var lastTapTime by remember { mutableLongStateOf(0L) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    Box(
        modifier = modifier
            .then(
                if (isLandscape) {
                    if (isVideoMode) {
                        Modifier
                            .height(dimensions.thumbnailSize)
                            .aspectRatio(16f / 9f)
                    } else {
                        Modifier.size(dimensions.thumbnailSize + (PlayerHorizontalPadding * 2))
                    }
                } else {
                    Modifier
                        .width(dimensions.itemWidth)
                        .fillMaxSize()
                }
            )
            .padding(horizontal = PlayerHorizontalPadding)
            .graphicsLayer {
                compositingStrategy = CompositingStrategy.Auto
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = { offset ->
                        if (isListenTogetherGuest) return@detectTapGestures
                        if (doubleTapToSeek == "Tắt") return@detectTapGestures

                        val baseSeconds = when (doubleTapToSeek) {
                            "5 giây" -> 5
                            "10 giây" -> 10
                            "15 giây" -> 15
                            "20 giây" -> 20
                            else -> 10
                        }

                        val currentPosition = playerConnection.player.currentPosition
                        val duration = playerConnection.player.duration

                        val now = System.currentTimeMillis()
                        if (incrementalSeekSkipEnabled && now - lastTapTime < 1000) {
                            skipMultiplier++
                        } else {
                            skipMultiplier = 1
                        }
                        lastTapTime = now

                        val skipAmount = baseSeconds * 1000 * skipMultiplier

                        val isLeftSide = (layoutDirection == LayoutDirection.Ltr && offset.x < size.width / 2) ||
                                (layoutDirection == LayoutDirection.Rtl && offset.x > size.width / 2)

                        if (isLeftSide) {
                            val newPos = (currentPosition - skipAmount.toLong()).coerceAtLeast(0)
                            playerConnection.player.seekTo(newPos)
                            webViewRef?.evaluateJavascript("if(window.player && player.seekTo){player.seekTo(${newPos / 1000}, true);}", null)
                            onSeek(context.getString(R.string.seek_backward_dynamic, skipAmount / 1000), true)
                        } else {
                            val newPos = (currentPosition + skipAmount.toLong()).coerceAtMost(duration)
                            playerConnection.player.seekTo(newPos)
                            webViewRef?.evaluateJavascript("if(window.player && player.seekTo){player.seekTo(${newPos / 1000}, true);}", null)
                            onSeek(context.getString(R.string.seek_forward_dynamic, skipAmount / 1000), true)
                        }
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        val boxModifier = if (isVideoMode) {
            if (isLandscape) {
                Modifier
                    .fillMaxHeight(0.94f)
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(12.dp))
            } else {
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(12.dp))
            }
        } else {
            Modifier
                .size(dimensions.thumbnailSize)
                .graphicsLayer(rotationZ = rotationAngle)
                .clip(RoundedCornerShape(dimensions.cornerRadius))
        }

        Box(
            modifier = boxModifier,
            contentAlignment = Alignment.Center
        ) {
            AnimatedContent(
                targetState = isVideoMode,
                transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(300)) },
                contentAlignment = Alignment.Center,
                modifier = Modifier.fillMaxSize(),
                label = "PlayerViewSwitcher"
            ) { targetIsVideo ->
                if (targetIsVideo) {
                    // --- VIDEO VIEW CONTAINER ---
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        val videoState by VideoPlaybackManager.uiState.collectAsState()
                        val context = LocalContext.current
                        val navController = LocalNavController.current

                        val activeVideoId = videoState.session?.videoId
                            ?: item.mediaId.takeIf { it.isNotBlank() }
                            ?: currentMediaId.takeIf { !it.isNullOrBlank() }
                            ?: "X3_0_8dZ3xY"

                        var isOnline by remember { mutableStateOf(isNetworkConnected(context)) }
                        var isWebError by remember(activeVideoId) { mutableStateOf(false) }
                        var retryCount by remember { mutableIntStateOf(0) }
                        var showVideoSettings by remember { mutableStateOf(false) }
                        val isLoopVideoEnabled = videoState.isLoopVideoEnabled
                        var currentVideoQuality by remember { mutableStateOf("Tự động") }

                        val isDisconnected = !isOnline || isWebError || (videoState.error != null && !isOnline)
                        val currentPlaybackSpeed = videoState.playbackSpeed

                        // 1. Đồng bộ trạng thái Phát / Tạm dừng giữa trình phát nhạc và Video WebView
                        LaunchedEffect(isPlayingState, webViewRef) {
                            val wv = webViewRef ?: return@LaunchedEffect
                            if (isPlayingState) {
                                wv.evaluateJavascript("if(window.player && player.playVideo){player.playVideo();}", null)
                            } else {
                                wv.evaluateJavascript("if(window.player && player.pauseVideo){player.pauseVideo();}", null)
                            }
                        }

                        // Đồng bộ chế độ lặp lại video sang WebView
                        LaunchedEffect(isLoopVideoEnabled, webViewRef) {
                            val wv = webViewRef ?: return@LaunchedEffect
                            wv.evaluateJavascript("if(window.setLoopVideo){window.setLoopVideo($isLoopVideoEnabled);}else if(window.player && player.setLoop){player.setLoop($isLoopVideoEnabled);}", null)
                        }

                        // 2. Đồng bộ tốc độ phát video từ VideoPlaybackManager sang WebView
                        LaunchedEffect(currentPlaybackSpeed, webViewRef) {
                            val wv = webViewRef ?: return@LaunchedEffect
                            wv.evaluateJavascript("if(window.player && player.setPlaybackRate){player.setPlaybackRate($currentPlaybackSpeed);}", null)
                        }

                        // 3. Phối hợp âm thanh: tránh bị lặp tiếng (double audio) và dừng phát ngầm khi thoát chế độ video
                        DisposableEffect(targetIsVideo) {
                            val prevVolume = playerConnection.player.volume
                            playerConnection.player.volume = 0f
                            onDispose {
                                playerConnection.player.volume = prevVolume
                                webViewRef?.evaluateJavascript("if(window.player && player.pauseVideo){player.pauseVideo();}", null)
                            }
                        }

                        // Tầng phát Video: Phát bình thường, kích thước đầy đủ và KHÔNG BỊ CHE KHUẤT
                        AndroidView(
                            factory = { ctx ->
                                FrameLayout(ctx).apply {
                                    layoutParams = ViewGroup.LayoutParams(
                                        ViewGroup.LayoutParams.MATCH_PARENT,
                                        ViewGroup.LayoutParams.MATCH_PARENT
                                    )
                                    setBackgroundColor(android.graphics.Color.BLACK)

                                    val webView = WebView(ctx).apply {
                                        layoutParams = FrameLayout.LayoutParams(
                                            FrameLayout.LayoutParams.MATCH_PARENT,
                                            FrameLayout.LayoutParams.MATCH_PARENT,
                                            android.view.Gravity.CENTER
                                        )
                                        settings.javaScriptEnabled = true
                                        settings.domStorageEnabled = true
                                        settings.mediaPlaybackRequiresUserGesture = false
                                        settings.allowFileAccess = true
                                        settings.cacheMode = WebSettings.LOAD_DEFAULT
                                        settings.loadWithOverviewMode = true
                                        settings.useWideViewPort = true

                                        // GIẢI PHÁP 1: Đổi User-Agent sang Chrome Mobile chuẩn để VƯỢT LỖI 152-4 & Bot Check
                                        val customUserAgent = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 " +
                                                "(KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36"
                                        settings.userAgentString = customUserAgent

                                        // Đồng bộ hóa Cookie đăng nhập từ tài khoản YouTube của app để ngăn chặn bot check
                                        val cookieManager = CookieManager.getInstance()
                                        cookieManager.setAcceptCookie(true)
                                        cookieManager.setAcceptThirdPartyCookies(this, true)
                                        val musicCookie = cookieManager.getCookie("https://music.youtube.com").orEmpty()
                                        if (musicCookie.isNotBlank()) {
                                            cookieManager.setCookie("https://www.youtube.com", musicCookie)
                                            cookieManager.setCookie("https://www.youtube-nocookie.com", musicCookie)
                                            cookieManager.flush()
                                        }

                                        webChromeClient = WebChromeClient()
                                    }

                                    webViewRef = webView

                                    val albumArtImageView = ImageView(ctx).apply {
                                        layoutParams = FrameLayout.LayoutParams(
                                            FrameLayout.LayoutParams.MATCH_PARENT,
                                            FrameLayout.LayoutParams.MATCH_PARENT,
                                            android.view.Gravity.CENTER
                                        )
                                        scaleType = ImageView.ScaleType.CENTER_CROP
                                        visibility = View.GONE // Không che video khi bình thường
                                    }

                                    // GIẢI PHÁP 2: ÉP TẤT CẢ LIÊN KẾT PHÁT TRONG ỨNG DỤNG & CHẶN BỊ ĐÒI XÁC THỰC BOT NGOÀI
                                    webView.webViewClient = object : WebViewClient() {
                                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                            val url = request?.url?.toString() ?: return false
                                            if (url.contains("accounts.google.com") || url.contains("youtube.com/signin") ||
                                                url.contains("google.com/sorry") || url.contains("youtube.com/watch") ||
                                                url.contains("youtu.be") || url.contains("intent://")) {
                                                return true
                                            }
                                            return false
                                        }

                                        override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                                            if (url != null && (url.contains("accounts.google.com") || url.contains("youtube.com/signin") ||
                                                url.contains("google.com/sorry") || url.contains("youtube.com/watch") ||
                                                url.contains("youtu.be") || url.contains("intent://"))) {
                                                return true
                                            }
                                            return false
                                        }

                                        override fun onPageFinished(view: WebView?, url: String?) {
                                            isWebError = false
                                            albumArtImageView.visibility = View.GONE
                                        }

                                        override fun onReceivedError(view: WebView?, errorCode: Int, description: String?, failingUrl: String?) {
                                            super.onReceivedError(view, errorCode, description, failingUrl)
                                            isWebError = true
                                            val thumbUrl = "https://img.youtube.com/vi/$activeVideoId/hqdefault.jpg"
                                            Glide.with(ctx).load(thumbUrl).centerCrop().into(albumArtImageView)
                                            albumArtImageView.visibility = View.VISIBLE
                                            albumArtImageView.alpha = 1f
                                        }
                                    }

                                    addView(webView)
                                    addView(albumArtImageView)

                                    // GIẢI PHÁP 3: HTML Nhúng chuẩn có YouTube Iframe API, script anti-bot, vượt lỗi 152 & canh chuẩn không lệch
                                    val htmlContent = "<!DOCTYPE html><html><head>" +
                                        "<meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no'>" +
                                        "<script src='https://www.youtube.com/iframe_api'></script>" +
                                        "<script>" +
                                        "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});" +
                                        "window.chrome = { runtime: {} };" +
                                        "var player;" +
                                        "window._isLoop = $isLoopVideoEnabled;" +
                                        "window.setLoopVideo = function(v) { window._isLoop = v; if(player && player.setLoop) player.setLoop(v); };" +
                                        "function onYouTubeIframeAPIReady() {" +
                                        "  player = new YT.Player('player', {" +
                                        "    events: {" +
                                        "      'onReady': function(e) {" +
                                        "        if ($isPlayingState) { e.target.playVideo(); }" +
                                        "        e.target.setPlaybackRate($currentPlaybackSpeed);" +
                                        "        if(e.target.setLoop) { e.target.setLoop(window._isLoop); }" +
                                        "      }," +
                                        "      'onStateChange': function(e) {" +
                                        "        if (e.data === 0 && window._isLoop) {" +
                                        "          e.target.seekTo(0);" +
                                        "          e.target.playVideo();" +
                                        "        }" +
                                        "      }" +
                                        "    }" +
                                        "  });" +
                                        "}" +
                                        "</script>" +
                                        "<style>body,html{margin:0;padding:0;width:100%;height:100%;background:#000;overflow:hidden;display:flex;justify-content:center;align-items:center;}" +
                                        "iframe{position:absolute;top:0;left:0;width:100%;height:100%;border:none;}</style>" +
                                        "</head><body>" +
                                        "<iframe id='player' type='text/html' width='100%' height='100%' " +
                                        "src='https://www.youtube-nocookie.com/embed/$activeVideoId?enablejsapi=1&autoplay=1&controls=1&playsinline=1&widget_referrer=https://www.youtube.com' " +
                                        "frameborder='0' allow='autoplay; encrypted-media' allowfullscreen></iframe>" +
                                        "</body></html>"

                                    webView.loadDataWithBaseURL("https://www.youtube-nocookie.com", htmlContent, "text/html", "UTF-8", null)
                                    tag = webView
                                }
                            },
                            update = { frameLayout ->
                                val webView = frameLayout.tag as? WebView ?: return@AndroidView
                                webViewRef = webView
                                if (retryCount > 0) {
                                    isOnline = isNetworkConnected(context)
                                }
                                val currentUrl = webView.url
                                if (currentUrl == null || !currentUrl.contains(activeVideoId) || retryCount > 0) {
                                    val cookieManager = CookieManager.getInstance()
                                    val musicCookie = cookieManager.getCookie("https://music.youtube.com").orEmpty()
                                    if (musicCookie.isNotBlank()) {
                                        cookieManager.setCookie("https://www.youtube.com", musicCookie)
                                        cookieManager.setCookie("https://www.youtube-nocookie.com", musicCookie)
                                        cookieManager.flush()
                                    }

                                    val htmlContent = "<!DOCTYPE html><html><head>" +
                                        "<meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no'>" +
                                        "<script src='https://www.youtube.com/iframe_api'></script>" +
                                        "<script>" +
                                        "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});" +
                                        "window.chrome = { runtime: {} };" +
                                        "var player;" +
                                        "window._isLoop = $isLoopVideoEnabled;" +
                                        "window.setLoopVideo = function(v) { window._isLoop = v; if(player && player.setLoop) player.setLoop(v); };" +
                                        "function onYouTubeIframeAPIReady() {" +
                                        "  player = new YT.Player('player', {" +
                                        "    events: {" +
                                        "      'onReady': function(e) {" +
                                        "        if ($isPlayingState) { e.target.playVideo(); }" +
                                        "        e.target.setPlaybackRate($currentPlaybackSpeed);" +
                                        "        if(e.target.setLoop) { e.target.setLoop(window._isLoop); }" +
                                        "      }," +
                                        "      'onStateChange': function(e) {" +
                                        "        if (e.data === 0 && window._isLoop) {" +
                                        "          e.target.seekTo(0);" +
                                        "          e.target.playVideo();" +
                                        "        }" +
                                        "      }" +
                                        "    }" +
                                        "  });" +
                                        "}" +
                                        "</script>" +
                                        "<style>body,html{margin:0;padding:0;width:100%;height:100%;background:#000;overflow:hidden;display:flex;justify-content:center;align-items:center;}" +
                                        "iframe{position:absolute;top:0;left:0;width:100%;height:100%;border:none;}</style>" +
                                        "</head><body>" +
                                        "<iframe id='player' type='text/html' width='100%' height='100%' " +
                                        "src='https://www.youtube-nocookie.com/embed/$activeVideoId?enablejsapi=1&autoplay=1&controls=1&playsinline=1&widget_referrer=https://www.youtube.com' " +
                                        "frameborder='0' allow='autoplay; encrypted-media' allowfullscreen></iframe>" +
                                        "</body></html>"
                                    webView.loadDataWithBaseURL("https://www.youtube-nocookie.com", htmlContent, "text/html", "UTF-8", null)
                                }
                            },
                            onReset = { frameLayout ->
                                val webView = frameLayout.tag as? WebView
                                webViewRef = null
                                webView?.loadUrl("about:blank")
                            },
                            modifier = Modifier.fillMaxSize()
                        )

                        // Thanh tác vụ Video tinh gọn ở góc trên bên phải (dễ dàng kiểm soát các cài đặt video)
                        if (!isDisconnected) {
                            Row(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(8.dp)
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(Color.Black.copy(alpha = 0.65f))
                                    .padding(horizontal = 6.dp, vertical = 3.dp),
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Nút bật/tắt Lặp lại video nhanh (Quick Loop Toggle)
                                IconButton(
                                    onClick = {
                                        val newLoop = !isLoopVideoEnabled
                                        VideoPlaybackManager.setLoopVideoEnabled(newLoop)
                                        webViewRef?.evaluateJavascript("if(window.player && player.setLoop){player.setLoop($newLoop);}", null)
                                    },
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Icon(
                                        painter = painterResource(
                                            if (isLoopVideoEnabled) R.drawable.repeat_one else R.drawable.repeat
                                        ),
                                        contentDescription = "Loop Video / Lặp lại video",
                                        tint = if (isLoopVideoEnabled) MaterialTheme.colorScheme.primary else Color.White,
                                        modifier = Modifier.size(19.dp)
                                    )
                                }

                                // Huy hiệu tốc độ nếu khác 1.0x (nhấn vào để mở Cài đặt Video)
                                if (currentPlaybackSpeed != 1.0f) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.85f))
                                            .clickable { showVideoSettings = true }
                                            .padding(horizontal = 6.dp, vertical = 2.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${currentPlaybackSpeed}x",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            ),
                                            color = MaterialTheme.colorScheme.onPrimary
                                        )
                                    }
                                }

                                // Tìm kiếm video (VideoSearchScreen)
                                IconButton(
                                    onClick = {
                                        navController.navigate("video_search/")
                                    },
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Icon(
                                        painter = painterResource(R.drawable.search),
                                        contentDescription = "Search Videos / Tìm kiếm video",
                                        tint = Color.White,
                                        modifier = Modifier.size(19.dp)
                                    )
                                }

                                // Mở Toàn màn hình Video Player (VideoPlayerOverlay)
                                IconButton(
                                    onClick = {
                                        if (VideoPlaybackManager.uiState.value.session == null) {
                                            val curPos = runCatching { playerConnection.player.currentPosition }.getOrDefault(0L)
                                            VideoPlaybackManager.play(
                                                context = context,
                                                videoId = activeVideoId,
                                                title = item.mediaMetadata.title?.toString() ?: "",
                                                channelName = item.mediaMetadata.artist?.toString() ?: "",
                                                startPositionMs = curPos
                                            )
                                        }
                                        VideoPlaybackManager.expand()
                                    },
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Icon(
                                        painter = painterResource(R.drawable.fullscreen),
                                        contentDescription = "Fullscreen / Toàn màn hình",
                                        tint = Color.White,
                                        modifier = Modifier.size(19.dp)
                                    )
                                }

                                // Mở Menu Cài đặt Video (Gộp toàn bộ tính năng vào một nơi, song ngữ Anh - Việt)
                                IconButton(
                                    onClick = { showVideoSettings = true },
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Icon(
                                        painter = painterResource(R.drawable.settings),
                                        contentDescription = "Video Settings / Cài đặt Video",
                                        tint = Color.White,
                                        modifier = Modifier.size(19.dp)
                                    )
                                }
                            }
                        }

                        // 2. CHỈ KHI MẤT MẠNG HOẶC LỖI KẾT NỐI: MỚI CHE LẠI BẰNG ẢNH BÌA VÀ HIỆN THÔNG BÁO DỊCH SONG NGỮ ANH - VIỆT
                        if (isDisconnected) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.Black),
                                contentAlignment = Alignment.Center
                            ) {
                                // Ảnh bìa che lại khi mất kết nối
                                val artworkUriToUse = if (item.mediaId == currentMediaId && !currentMediaThumbnail.isNullOrBlank()) {
                                    currentMediaThumbnail
                                } else {
                                    item.mediaMetadata.artworkUri?.toString()
                                }
                                ThumbnailImage(
                                    artworkUri = artworkUriToUse,
                                    cropArtwork = cropAlbumArt
                                )

                                // Lớp phủ tối màu với thông báo song ngữ Anh - Việt
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = 0.82f))
                                        .padding(16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.94f),
                                                shape = RoundedCornerShape(18.dp)
                                            )
                                            .padding(20.dp)
                                    ) {
                                        Icon(
                                            painter = painterResource(R.drawable.offline),
                                            contentDescription = "Offline",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(44.dp)
                                        )

                                        Spacer(modifier = Modifier.height(12.dp))

                                        // Tiêu đề song ngữ Anh - Việt
                                        Text(
                                            text = "No Internet Connection\nKhông có kết nối mạng",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            textAlign = TextAlign.Center
                                        )

                                        Spacer(modifier = Modifier.height(8.dp))

                                        // Chi tiết hướng dẫn dịch sang tiếng Anh & tiếng Việt
                                        Text(
                                            text = "Video playback requires an active internet connection. Please check your network.\n(Phát video yêu cầu kết nối internet. Vui lòng kiểm tra lại mạng.)",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f),
                                            textAlign = TextAlign.Center
                                        )

                                        Spacer(modifier = Modifier.height(16.dp))

                                        // Nút Thử lại / Retry
                                        Button(
                                            onClick = {
                                                isOnline = isNetworkConnected(context)
                                                isWebError = false
                                                retryCount++
                                            },
                                            shape = RoundedCornerShape(24.dp),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = MaterialTheme.colorScheme.primary,
                                                contentColor = MaterialTheme.colorScheme.onPrimary
                                            )
                                        ) {
                                            Icon(
                                                painter = painterResource(R.drawable.refresh),
                                                contentDescription = "Retry",
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "Retry / Thử lại",
                                                style = MaterialTheme.typography.labelLarge
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // BottomSheet Cài đặt Video toàn diện, gom tất cả tính năng vào 1 menu chuyên nghiệp
                        if (showVideoSettings) {
                            VideoSettingsBottomSheet(
                                onDismissRequest = { showVideoSettings = false },
                                currentSpeed = currentPlaybackSpeed,
                                onSpeedSelected = { speed ->
                                    VideoPlaybackManager.setPlaybackSpeed(speed)
                                    webViewRef?.evaluateJavascript("if(window.player && player.setPlaybackRate){player.setPlaybackRate($speed);}", null)
                                },
                                currentQuality = currentVideoQuality,
                                onQualitySelected = { quality ->
                                    currentVideoQuality = quality
                                    val ytQuality = when (quality) {
                                        "1080p" -> "hd1080"
                                        "720p" -> "hd720"
                                        "480p" -> "large"
                                        "360p" -> "medium"
                                        else -> "auto"
                                    }
                                    webViewRef?.evaluateJavascript("if(window.player && player.setPlaybackQuality){player.setPlaybackQuality('$ytQuality');}", null)
                                    val videoQualityEnum = when (quality) {
                                        "1080p" -> AuraPlayerUtils.VideoQuality.QUALITY_1080P
                                        "720p" -> AuraPlayerUtils.VideoQuality.QUALITY_720P
                                        "480p" -> AuraPlayerUtils.VideoQuality.QUALITY_480P
                                        "360p" -> AuraPlayerUtils.VideoQuality.QUALITY_360P
                                        else -> AuraPlayerUtils.VideoQuality.QUALITY_720P
                                    }
                                    VideoPlaybackManager.setVideoQuality(videoQualityEnum)
                                },
                                isLoopEnabled = isLoopVideoEnabled,
                                onToggleLoop = { enabled ->
                                    VideoPlaybackManager.setLoopVideoEnabled(enabled)
                                    webViewRef?.evaluateJavascript("if(window.player && player.setLoop){player.setLoop($enabled);}", null)
                                },
                                onOpenSyncPlayer = {
                                    VideoPlaybackManager.launchYouTubeSyncPlayer(context, activeVideoId)
                                    showVideoSettings = false
                                },
                                onOpenFullscreen = {
                                    if (VideoPlaybackManager.uiState.value.session == null) {
                                        val curPos = runCatching { playerConnection.player.currentPosition }.getOrDefault(0L)
                                        VideoPlaybackManager.play(
                                            context = context,
                                            videoId = activeVideoId,
                                            title = item.mediaMetadata.title?.toString() ?: "",
                                            channelName = item.mediaMetadata.artist?.toString() ?: "",
                                            startPositionMs = curPos
                                        )
                                    }
                                    VideoPlaybackManager.expand()
                                    showVideoSettings = false
                                },
                                onReloadVideo = {
                                    webViewRef?.reload()
                                    showVideoSettings = false
                                },
                                activeVideoId = activeVideoId,
                                onNavigateToVideos = {
                                    navController.navigate("videos")
                                },
                                onNavigateToSearch = {
                                    navController.navigate("video_search/")
                                },
                                onNavigateToChannel = { channelKey ->
                                    navController.navigate("youtube_channel/$channelKey?ts=${System.currentTimeMillis()}")
                                },
                                channelName = item.mediaMetadata.artist?.toString(),
                                channelId = (item.mediaMetadata.extras?.get("channelId") as? String)
                            )
                        }
                    }
                } else {
                    // --- AUDIO VIEW CONTAINER ---
                    Box(modifier = Modifier.fillMaxSize()) {
                        if (hidePlayerThumbnail) {
                            HiddenThumbnailPlaceholder(textBackgroundColor = textBackgroundColor)
                        } else {
                            val artworkUriToUse = if (item.mediaId == currentMediaId && !currentMediaThumbnail.isNullOrBlank()) {
                                currentMediaThumbnail
                            } else {
                                item.mediaMetadata.artworkUri?.toString()
                            }

                            ThumbnailImage(
                                artworkUri = artworkUriToUse,
                                cropArtwork = cropAlbumArt
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Placeholder shown when thumbnail is hidden.
 */
@Composable
private fun HiddenThumbnailPlaceholder(
    textBackgroundColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(R.drawable.ic_launcher_logo),
            contentDescription = stringResource(R.string.hide_player_thumbnail),
            contentScale = ContentScale.Fit,
            modifier = Modifier.size(120.dp)
        )
    }
}

/**
 * Actual thumbnail image with caching and hardware layer rendering.
 * Implements an adaptive Coil image loading strategy that automatically detects
 * and scales aspect ratios, preventing layout shifts and distortion of album art.
 */
@Composable
private fun ThumbnailImage(
    artworkUri: String?,
    cropArtwork: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Box(
        modifier = modifier
            .fillMaxSize()
            .graphicsLayer {
                compositingStrategy = CompositingStrategy.Auto
            }
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        AnimatedContent(
            targetState = artworkUri,
            transitionSpec = {
                fadeIn(tween(400)).togetherWith(fadeOut(tween(400)))
            },
            contentAlignment = Alignment.Center,
            label = "thumbnailArtworkFade",
            modifier = Modifier.fillMaxSize(),
        ) { targetUri ->
            if (targetUri.isNullOrBlank()) {
                // Stable fallback placeholder to prevent layout shifts when no artwork is present
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = painterResource(R.drawable.music_note),
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                        modifier = Modifier.size(72.dp)
                    )
                }
            } else {
                var intrinsicAspectRatio by remember(targetUri) { mutableFloatStateOf(1f) }
                var isLoaded by remember(targetUri) { mutableStateOf(false) }

                val isWideOrNonSquare = intrinsicAspectRatio > 1.25f || intrinsicAspectRatio < 0.8f

                val imageRequest = remember(targetUri) {
                    ImageRequest.Builder(context)
                        .data(targetUri)
                        .crossfade(true)
                        .memoryCachePolicy(CachePolicy.ENABLED)
                        .diskCachePolicy(CachePolicy.ENABLED)
                        .networkCachePolicy(CachePolicy.ENABLED)
                        .build()
                }

                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    // 1. Placeholder underneath to guarantee zero layout shift while loading
                    if (!isLoaded) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.music_note),
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
                                modifier = Modifier.size(64.dp)
                            )
                        }
                    }

                    // 2. Ambient backdrop for non-square/widescreen album art when cropArtwork is false,
                    // preventing harsh empty bars or letterboxing while preserving artwork aesthetics
                    if (!cropArtwork && isWideOrNonSquare && isLoaded) {
                        AsyncImage(
                            model = imageRequest,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer {
                                    alpha = 0.30f
                                }
                        )
                    }

                    // 3. Primary image with automatic aspect ratio scaling to prevent distortion
                    // If cropArtwork is true: ContentScale.Crop fills bounds without distortion
                    // If cropArtwork is false: ContentScale.Fit fits within bounds without distortion
                    AsyncImage(
                        model = imageRequest,
                        contentDescription = null,
                        contentScale = if (cropArtwork) ContentScale.Crop else ContentScale.Fit,
                        onSuccess = { state ->
                            val size = state.painter.intrinsicSize
                            if (size.width > 0f && size.height > 0f) {
                                intrinsicAspectRatio = size.width / size.height
                            }
                            isLoaded = true
                        },
                        onError = {
                            isLoaded = false
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}

/**
 * Seek effect overlay showing seek direction.
 */
@Composable
private fun SeekEffectOverlay(
    seekDirection: String,
    modifier: Modifier = Modifier
) {
    Text(
        text = seekDirection,
        color = Color.White,
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center,
        modifier = modifier
            .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(8.dp))
            .padding(8.dp)
    )
}

