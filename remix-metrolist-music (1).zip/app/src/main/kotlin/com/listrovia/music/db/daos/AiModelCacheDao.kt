/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.db.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.listrovia.music.db.entities.AiModelCacheEntity

@Dao
interface AiModelCacheDao {
    @Query("SELECT * FROM ai_model_metadata_cache WHERE provider = :provider ORDER BY rank ASC, cachedAt DESC")
    suspend fun getModelsByProvider(provider: String): List<AiModelCacheEntity>

    @Query("SELECT * FROM ai_model_metadata_cache WHERE provider = :provider AND sourceCategory = :category ORDER BY rank ASC, cachedAt DESC")
    suspend fun getModelsByProviderAndCategory(provider: String, category: String): List<AiModelCacheEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertModels(models: List<AiModelCacheEntity>)

    @Query("DELETE FROM ai_model_metadata_cache WHERE provider = :provider")
    suspend fun clearProviderCache(provider: String)

    @Query("SELECT COUNT(*) FROM ai_model_metadata_cache WHERE provider = :provider")
    suspend fun getModelCount(provider: String): Int
}
