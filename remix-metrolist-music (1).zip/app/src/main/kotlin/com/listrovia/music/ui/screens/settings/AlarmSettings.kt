package com.listrovia.music.ui.screens.settings

import android.app.AlarmManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLocale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.net.toUri
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.listrovia.music.LocalDatabase
import com.listrovia.music.LocalNavController
import com.listrovia.music.R
import com.listrovia.music.constants.*
import com.listrovia.music.db.entities.Playlist
import com.listrovia.music.playback.alarm.MusicAlarmEntry
import com.listrovia.music.playback.alarm.MusicAlarmScheduler
import com.listrovia.music.playback.alarm.MusicAlarmStore
import com.listrovia.music.ui.component.DefaultDialog
import com.listrovia.music.ui.component.Material3SettingsGroup
import com.listrovia.music.ui.component.Material3SettingsItem
import com.listrovia.music.utils.rememberPreference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MusicAlarmScreen(
    navController: NavController = LocalNavController.current
) {
    val context = LocalContext.current
    val locale = LocalLocale.current.platformLocale
    val database = LocalDatabase.current
    val playlists by database.playlistsByNameAsc().collectAsStateWithLifecycle(initialValue = emptyList())

    var alarmEnabled by rememberPreference(AlarmEnabledKey, defaultValue = false)
    var alarmHour by rememberPreference(AlarmHourKey, defaultValue = 7)
    var alarmMinute by rememberPreference(AlarmMinuteKey, defaultValue = 0)

    var alarmWakeUpTo by rememberPreference(AlarmWakeUpToKey, defaultValue = "downloaded")
    var alarmRepeatDaily by rememberPreference(AlarmRepeatDailyKey, defaultValue = true)
    var alarmShuffleSongs by rememberPreference(AlarmShuffleSongsKey, defaultValue = false)
    var alarmVibrate by rememberPreference(AlarmVibrateKey, defaultValue = true)
    var alarmFadeIn by rememberPreference(AlarmFadeInVolumeKey, defaultValue = true)
    var alarmVolume by rememberPreference(AlarmVolumeKey, defaultValue = 0.85f)
    var alarmSnooze by rememberPreference(AlarmSnoozeDurationKey, defaultValue = 30)

    var showTimePicker by remember { mutableStateOf(false) }
    var showPlaylistPicker by remember { mutableStateOf(false) }

    androidx.compose.runtime.LaunchedEffect(
        alarmEnabled, alarmHour, alarmMinute, alarmWakeUpTo,
        alarmRepeatDaily, alarmShuffleSongs, alarmVibrate, alarmFadeIn, alarmVolume, alarmSnooze
    ) {
        MusicAlarmScheduler.scheduleFromPreferences(context)
    }

    if (showTimePicker) {
        AlarmTimePickerDialog(
            title = stringResource(R.string.alarm_time),
            initialHour = alarmHour,
            initialMinute = alarmMinute,
            onDismiss = { showTimePicker = false },
            onConfirm = { h, m ->
                alarmHour = h
                alarmMinute = m
                showTimePicker = false
            }
        )
    }

    if (showPlaylistPicker) {
        DefaultDialog(
            onDismiss = { showPlaylistPicker = false },
            title = { Text(stringResource(R.string.alarm_playlist)) },
            buttons = {
                TextButton(onClick = { showPlaylistPicker = false }) {
                    Text(stringResource(android.R.string.ok))
                }
            }
        ) {
            if (playlists.isEmpty()) {
                Text(stringResource(R.string.alarm_no_playlists))
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 380.dp)
                ) {
                    items(items = playlists, key = { it.id }) { playlist ->
                        Card(
                            onClick = {
                                showPlaylistPicker = false
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                            )
                        ) {
                            Text(
                                text = playlist.title,
                                modifier = Modifier.padding(16.dp),
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                    }
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.music_alarm_title)) },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(
                            painter = painterResource(R.drawable.arrow_back),
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Card 1: Main Clock & Enable Switch
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                ),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = String.format(locale, "%02d:%02d", alarmHour, alarmMinute),
                        fontSize = 68.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.clickable { showTimePicker = true }
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = stringResource(R.string.alarm_tap_to_edit_time),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.clickable { showTimePicker = true }
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = stringResource(R.string.alarm_enabled),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Medium),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        AlarmSwitch(
                            checked = alarmEnabled,
                            onCheckedChange = { alarmEnabled = it }
                        )
                    }
                }
            }

            // Card 2: Wake up to
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                ),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = stringResource(R.string.alarm_wake_up_to),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val options = listOf(
                            "downloaded" to stringResource(R.string.alarm_sound_downloaded),
                            "cached" to stringResource(R.string.alarm_sound_cached),
                            "playlist" to stringResource(R.string.alarm_sound_playlist)
                        )
                        options.forEach { (key, label) ->
                            val selected = alarmWakeUpTo == key
                            Surface(
                                onClick = { alarmWakeUpTo = key },
                                shape = RoundedCornerShape(12.dp),
                                color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.6f),
                                border = if (selected) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 12.dp, horizontal = 4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }

                    OutlinedButton(
                        onClick = { showPlaylistPicker = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.queue_music),
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(stringResource(R.string.alarm_choose_songs))
                        }
                    }
                }
            }

            // Card 3: Behaviour
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                ),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = stringResource(R.string.alarm_behaviour),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = stringResource(R.string.alarm_repeat_daily),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        AlarmSwitch(
                            checked = alarmRepeatDaily,
                            onCheckedChange = { alarmRepeatDaily = it }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = stringResource(R.string.alarm_shuffle_songs),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        AlarmSwitch(
                            checked = alarmShuffleSongs,
                            onCheckedChange = { alarmShuffleSongs = it }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = stringResource(R.string.alarm_vibrate),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        AlarmSwitch(
                            checked = alarmVibrate,
                            onCheckedChange = { alarmVibrate = it }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = stringResource(R.string.alarm_fade_in),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        AlarmSwitch(
                            checked = alarmFadeIn,
                            onCheckedChange = { alarmFadeIn = it }
                        )
                    }
                }
            }

            // Card 4: Volume
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                ),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = stringResource(R.string.alarm_volume_section),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Column {
                        Text(
                            text = stringResource(R.string.alarm_volume_format, (alarmVolume * 100).toInt()),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Slider(
                            value = alarmVolume,
                            onValueChange = { alarmVolume = it },
                            valueRange = 0f..1f,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Column {
                        Text(
                            text = stringResource(R.string.alarm_snooze_format, alarmSnooze),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Slider(
                            value = alarmSnooze.toFloat(),
                            onValueChange = { alarmSnooze = it.toInt() },
                            valueRange = 5f..60f,
                            steps = 10,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun AlarmSettingsSection(showTitle: Boolean = true) {
    val context = LocalContext.current
    val locale = LocalLocale.current.platformLocale
    val database = LocalDatabase.current
    val scope = rememberCoroutineScope()
    val playlists by database.playlistsByNameAsc().collectAsStateWithLifecycle(initialValue = emptyList())
    val persistMutex = remember { Mutex() }
    val selectPlaylistText = stringResource(R.string.alarm_select_playlist)
    val randomEnabledText = stringResource(R.string.alarm_random_enabled)
    val randomDisabledText = stringResource(R.string.alarm_random_disabled)
    val notScheduledText = stringResource(R.string.alarm_not_scheduled)

    var alarms by remember { mutableStateOf(emptyList<MusicAlarmEntry>()) }
    var showEditor by remember { mutableStateOf(false) }
    var editorTarget by remember { mutableStateOf<MusicAlarmEntry?>(null) }

    val (alarmWakeUpTo, onAlarmWakeUpToChange) = rememberPreference(AlarmWakeUpToKey, defaultValue = "playlist")
    val (alarmRepeatDaily, onAlarmRepeatDailyChange) = rememberPreference(AlarmRepeatDailyKey, defaultValue = true)
    val (alarmShuffleSongs, onAlarmShuffleSongsChange) = rememberPreference(AlarmShuffleSongsKey, defaultValue = false)
    val (alarmVibrate, onAlarmVibrateChange) = rememberPreference(AlarmVibrateKey, defaultValue = true)
    val (alarmFadeIn, onAlarmFadeInChange) = rememberPreference(AlarmFadeInVolumeKey, defaultValue = false)
    val (alarmVolume, onAlarmVolumeChange) = rememberPreference(AlarmVolumeKey, defaultValue = 0.8f)
    val (alarmSnooze, onAlarmSnoozeChange) = rememberPreference(AlarmSnoozeDurationKey, defaultValue = 5)

    var showWakeUpToDialog by remember { mutableStateOf(false) }
    var showSnoozeDialog by remember { mutableStateOf(false) }

    val alarmManager = context.getSystemService(AlarmManager::class.java)
    val canScheduleExact =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            alarmManager?.canScheduleExactAlarms() == true
        } else {
            true
        }
    val powerManager = context.getSystemService(PowerManager::class.java)
    val ignoringBatteryOptimization =
        powerManager?.isIgnoringBatteryOptimizations(context.packageName) == true
    val systemItems = buildList {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !canScheduleExact) {
            add(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.warning),
                    title = { Text(stringResource(R.string.alarm_exact_permission_title)) },
                    description = { Text(stringResource(R.string.alarm_exact_permission_desc)) },
                    onClick = {
                        try {
                            val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                                .setData("package:${context.packageName}".toUri())
                            context.startActivity(intent)
                        } catch (_: ActivityNotFoundException) {
                        }
                    }
                )
            )
        }
        if (!ignoringBatteryOptimization) {
            add(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.warning),
                    title = { Text(stringResource(R.string.alarm_battery_optimization_title)) },
                    description = { Text(stringResource(R.string.alarm_battery_optimization_desc)) },
                    onClick = {
                        try {
                            context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                        } catch (_: ActivityNotFoundException) {
                        }
                    }
                )
            )
        }
    }

    suspend fun loadAlarms(): List<MusicAlarmEntry> {
        return withContext(Dispatchers.IO) {
            MusicAlarmStore.load(context)
        }.sortedBy { it.hour * 60 + it.minute }
    }

    fun persistAndSchedule(transform: (List<MusicAlarmEntry>) -> List<MusicAlarmEntry>) {
        scope.launch {
            persistMutex.withLock {
                val latest = loadAlarms()
                val newList = transform(latest)
                withContext(Dispatchers.IO) {
                    MusicAlarmScheduler.scheduleAll(context, newList)
                }
                alarms = loadAlarms()
            }
        }
    }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        alarms = loadAlarms()
    }

    if (showEditor) {
        AlarmEditorDialog(
            existing = editorTarget,
            allAlarms = alarms,
            playlists = playlists,
            onDismiss = {
                showEditor = false
                editorTarget = null
            },
            onSave = { updated ->
                persistAndSchedule { current ->
                    current.filterNot { it.id == updated.id } + updated
                }
                showEditor = false
                editorTarget = null
            }
        )
    }

    Material3SettingsGroup(
        title = if (showTitle) stringResource(R.string.alarm) else null,
        items = buildList {
            add(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.add_circle),
                    title = { Text(stringResource(R.string.alarm_add)) },
                    onClick = {
                        editorTarget = null
                        showEditor = true
                    }
                )
            )

            if (alarms.isEmpty()) {
                add(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.bedtime),
                        title = { Text(stringResource(R.string.alarm_empty)) }
                    )
                )
            } else {
                addAll(
                    alarms.map { alarm ->
                        val playlistTitle =
                            playlists.firstOrNull { it.id == alarm.playlistId }?.title
                                ?: selectPlaylistText
                        val triggerText =
                            if (alarm.nextTriggerAt > 0L) {
                                DateTimeFormatter.ofPattern("EEE, HH:mm", locale)
                                    .format(
                                        Instant.ofEpochMilli(alarm.nextTriggerAt)
                                            .atZone(ZoneId.systemDefault())
                                    )
                            } else {
                                notScheduledText
                            }
                        val description = buildString {
                            append(playlistTitle)
                            append(" • ")
                            append(if (alarm.randomSong) randomEnabledText else randomDisabledText)
                            append("\n")
                            append(stringResource(R.string.alarm_next_prefix, triggerText))
                        }

                        Material3SettingsItem(
                            icon = painterResource(R.drawable.bedtime),
                            title = {
                                Text(
                                    String.format(locale, "%02d:%02d", alarm.hour, alarm.minute) +
                                        if (alarm.enabled) {
                                            ""
                                        } else {
                                            " (${stringResource(R.string.alarm_disabled)})"
                                        }
                                )
                            },
                            description = { Text(description) },
                            trailingContent = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    AlarmSwitch(
                                        checked = alarm.enabled,
                                        onCheckedChange = { enabled ->
                                            persistAndSchedule { current ->
                                                current.map {
                                                    if (it.id == alarm.id) it.copy(enabled = enabled) else it
                                                }
                                            }
                                        }
                                    )
                                    IconButton(
                                        onClick = {
                                            persistAndSchedule { current ->
                                                current.filterNot { it.id == alarm.id }
                                            }
                                        }
                                    ) {
                                        Icon(
                                            painter = painterResource(R.drawable.delete),
                                            contentDescription = stringResource(R.string.alarm_delete)
                                        )
                                    }
                                }
                            },
                            onClick = {
                                editorTarget = alarm
                                showEditor = true
                            }
                        )
                    }
                )
            }

            addAll(systemItems)
        }
    )

    if (showWakeUpToDialog) {
        val options = listOf(
            "downloaded" to stringResource(R.string.alarm_sound_downloaded),
            "cached" to stringResource(R.string.alarm_sound_cached),
            "playlist" to stringResource(R.string.alarm_sound_playlist),
            "songs" to stringResource(R.string.alarm_sound_songs)
        )
        DefaultDialog(
            onDismiss = { showWakeUpToDialog = false },
            title = { Text(stringResource(R.string.alarm_wake_up_to)) },
            buttons = {
                TextButton(onClick = { showWakeUpToDialog = false }) {
                    Text(stringResource(android.R.string.cancel))
                }
            }
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                options.forEach { (key, label) ->
                    Card(
                        onClick = {
                            onAlarmWakeUpToChange(key)
                            showWakeUpToDialog = false
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (alarmWakeUpTo == key) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                        )
                    ) {
                        Text(
                            text = label,
                            modifier = Modifier.padding(16.dp),
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }
        }
    }

    if (showSnoozeDialog) {
        val options = listOf(
            5 to stringResource(R.string.alarm_snooze_minutes, 5),
            10 to stringResource(R.string.alarm_snooze_minutes, 10),
            15 to stringResource(R.string.alarm_snooze_minutes, 15),
            20 to stringResource(R.string.alarm_snooze_minutes, 20),
            30 to stringResource(R.string.alarm_snooze_minutes, 30)
        )
        DefaultDialog(
            onDismiss = { showSnoozeDialog = false },
            title = { Text(stringResource(R.string.alarm_snooze_duration)) },
            buttons = {
                TextButton(onClick = { showSnoozeDialog = false }) {
                    Text(stringResource(android.R.string.cancel))
                }
            }
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                options.forEach { (key, label) ->
                    Card(
                        onClick = {
                            onAlarmSnoozeChange(key)
                            showSnoozeDialog = false
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (alarmSnooze == key) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                        )
                    ) {
                        Text(
                            text = label,
                            modifier = Modifier.padding(16.dp),
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }
        }
    }

    Spacer(modifier = Modifier.height(16.dp))

    Material3SettingsGroup(
        title = stringResource(R.string.music_alarm_group),
        items = buildList {
            add(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.library_music_filled),
                    title = { Text(stringResource(R.string.alarm_wake_up_to)) },
                    description = {
                        val label = when (alarmWakeUpTo) {
                            "downloaded" -> stringResource(R.string.alarm_sound_downloaded)
                            "cached" -> stringResource(R.string.alarm_sound_cached)
                            "songs" -> stringResource(R.string.alarm_sound_songs)
                            else -> stringResource(R.string.alarm_sound_playlist)
                        }
                        Text(label)
                    },
                    onClick = { showWakeUpToDialog = true }
                )
            )
            add(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.baseline_event_repeat_24),
                    title = { Text(stringResource(R.string.alarm_repeat_daily)) },
                    trailingContent = {
                        Switch(
                            checked = alarmRepeatDaily,
                            onCheckedChange = onAlarmRepeatDailyChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(if (alarmRepeatDaily) R.drawable.check else R.drawable.close),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAlarmRepeatDailyChange(!alarmRepeatDaily) }
                )
            )
            add(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.ic_compare_arrows),
                    title = { Text(stringResource(R.string.alarm_shuffle_songs)) },
                    trailingContent = {
                        Switch(
                            checked = alarmShuffleSongs,
                            onCheckedChange = onAlarmShuffleSongsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(if (alarmShuffleSongs) R.drawable.check else R.drawable.close),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAlarmShuffleSongsChange(!alarmShuffleSongs) }
                )
            )
            add(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.time_auto),
                    title = { Text(stringResource(R.string.alarm_vibrate)) },
                    trailingContent = {
                        Switch(
                            checked = alarmVibrate,
                            onCheckedChange = onAlarmVibrateChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(if (alarmVibrate) R.drawable.check else R.drawable.close),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAlarmVibrateChange(!alarmVibrate) }
                )
            )
            add(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.trending_up),
                    title = { Text(stringResource(R.string.alarm_fade_in)) },
                    trailingContent = {
                        Switch(
                            checked = alarmFadeIn,
                            onCheckedChange = onAlarmFadeInChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(if (alarmFadeIn) R.drawable.check else R.drawable.close),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAlarmFadeInChange(!alarmFadeIn) }
                )
            )
            add(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.volume_up),
                    title = { Text(stringResource(R.string.alarm_volume) + ": ${(alarmVolume * 100).toInt()}%") },
                    description = {
                        Slider(
                            value = alarmVolume,
                            onValueChange = onAlarmVolumeChange,
                            valueRange = 0f..1f,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                )
            )
            add(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.timer),
                    title = { Text(stringResource(R.string.alarm_snooze_duration)) },
                    description = { Text(stringResource(R.string.alarm_snooze_minutes, alarmSnooze)) },
                    onClick = { showSnoozeDialog = true }
                )
            )
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AlarmTimePickerDialog(
    title: String,
    initialHour: Int,
    initialMinute: Int,
    onDismiss: () -> Unit,
    onConfirm: (Int, Int) -> Unit
) {
    val timePickerState = rememberTimePickerState(
        initialHour = initialHour,
        initialMinute = initialMinute,
        is24Hour = true
    )

    DefaultDialog(
        title = { Text(title) },
        onDismiss = onDismiss,
        buttons = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(android.R.string.cancel))
            }
            TextButton(onClick = { onConfirm(timePickerState.hour, timePickerState.minute) }) {
                Text(stringResource(android.R.string.ok))
            }
        }
    ) {
        TimePicker(state = timePickerState)
    }
}

@Composable
private fun AlarmSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    enabled: Boolean = true
) {
    Switch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        enabled = enabled,
        thumbContent = {
            Icon(
                painter = painterResource(if (checked) R.drawable.check else R.drawable.close),
                contentDescription = null,
                modifier = Modifier.size(SwitchDefaults.IconSize)
            )
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun AlarmEditorDialog(
    existing: MusicAlarmEntry?,
    allAlarms: List<MusicAlarmEntry>,
    playlists: List<Playlist>,
    onDismiss: () -> Unit,
    onSave: (MusicAlarmEntry) -> Unit
) {
    val context = LocalContext.current
    val locale = LocalLocale.current.platformLocale
    val noPlaylistsText = stringResource(R.string.alarm_no_playlists)
    val selectPlaylistText = stringResource(R.string.alarm_select_playlist)

    var showPlaylistDialog by remember { mutableStateOf(false) }
    var showTimePickerDialog by remember { mutableStateOf(false) }
    var enabled by remember { mutableStateOf(existing?.enabled ?: true) }
    var hour by remember { mutableIntStateOf(existing?.hour ?: 7) }
    var minute by remember { mutableIntStateOf(existing?.minute ?: 0) }
    var playlistId by remember { mutableStateOf(existing?.playlistId.orEmpty()) }
    var randomSong by remember { mutableStateOf(existing?.randomSong ?: false) }

    val hasSameTimeAlarm = remember(hour, minute, existing, allAlarms) {
        allAlarms.any { it.id != existing?.id && it.hour == hour && it.minute == minute }
    }
    val selectedPlaylist = playlists.firstOrNull { it.id == playlistId }
    val hasValidPlaylist = selectedPlaylist != null

    if (showTimePickerDialog) {
        AlarmTimePickerDialog(
            title = stringResource(R.string.alarm_time),
            initialHour = hour,
            initialMinute = minute,
            onDismiss = { showTimePickerDialog = false },
            onConfirm = { selectedHour, selectedMinute ->
                hour = selectedHour
                minute = selectedMinute
                showTimePickerDialog = false
            }
        )
    }

    if (showPlaylistDialog) {
        DefaultDialog(
            onDismiss = { showPlaylistDialog = false },
            title = { Text(stringResource(R.string.alarm_playlist)) },
            buttons = {
                TextButton(onClick = { showPlaylistDialog = false }) {
                    Text(stringResource(android.R.string.ok))
                }
            }
        ) {
            if (playlists.isEmpty()) {
                Text(noPlaylistsText)
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 380.dp)
                ) {
                    items(items = playlists, key = { it.id }) { playlist ->
                        val selected = playlist.id == playlistId
                        Card(
                            onClick = {
                                playlistId = playlist.id
                                showPlaylistDialog = false
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (selected) {
                                    MaterialTheme.colorScheme.primaryContainer
                                } else {
                                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                                }
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = playlist.title,
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Text(
                                        text = pluralStringResource(
                                            R.plurals.alarm_playlist_song_count,
                                            playlist.songCount,
                                            playlist.songCount
                                        ),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (selected) {
                                    Icon(
                                        painter = painterResource(R.drawable.check),
                                        contentDescription = stringResource(R.string.alarm_selected),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    DefaultDialog(
        onDismiss = onDismiss,
        title = {
            Text(
                if (existing == null) {
                    stringResource(R.string.alarm_new)
                } else {
                    stringResource(R.string.alarm_edit)
                }
            )
        },
        buttons = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(android.R.string.cancel))
            }
            TextButton(
                enabled = !hasSameTimeAlarm && hasValidPlaylist,
                onClick = {
                    if (hasSameTimeAlarm) {
                        return@TextButton
                    }
                    if (!hasValidPlaylist) {
                        Toast.makeText(context, selectPlaylistText, Toast.LENGTH_SHORT).show()
                        return@TextButton
                    }
                    onSave(
                        (existing ?: MusicAlarmStore.createEmpty()).copy(
                            enabled = enabled,
                            hour = hour,
                            minute = minute,
                            playlistId = playlistId,
                            randomSong = randomSong
                        )
                    )
                }
            ) {
                Text(stringResource(R.string.alarm_save))
            }
        }
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.alarm_enabled),
                    modifier = Modifier.weight(1f)
                )
                AlarmSwitch(checked = enabled, onCheckedChange = { enabled = it })
            }

            FilledTonalButton(
                onClick = { showTimePickerDialog = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = stringResource(
                        R.string.alarm_time_picker_value,
                        String.format(locale, "%02d:%02d", hour, minute)
                    )
                )
            }

            HorizontalDivider()

            OutlinedButton(
                onClick = {
                    if (playlists.isEmpty()) {
                        Toast.makeText(context, noPlaylistsText, Toast.LENGTH_SHORT).show()
                    } else {
                        showPlaylistDialog = true
                    }
                },
                enabled = playlists.isNotEmpty(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = selectedPlaylist?.title ?: selectPlaylistText)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.alarm_random_song),
                    modifier = Modifier.weight(1f)
                )
                AlarmSwitch(checked = randomSong, onCheckedChange = { randomSong = it })
            }

            if (hasSameTimeAlarm) {
                Text(
                    text = stringResource(R.string.alarm_duplicate_time_warning),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}