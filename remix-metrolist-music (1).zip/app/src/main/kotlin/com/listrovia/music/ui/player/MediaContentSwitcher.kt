package com.listrovia.music.ui.player

import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.togetherWith
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.listrovia.music.models.MusicPlayerState

/**
 * MediaContentSwitcher uses AnimatedContent or Crossfade to monitor [MusicPlayerState]
 * and toggle between the standard [albumArtView] and the WebView container based on
 * [MusicPlayerState.isVideo].
 */
@Composable
fun MediaContentSwitcher(
    playerState: MusicPlayerState,
    modifier: Modifier = Modifier,
    albumArtView: @Composable () -> Unit,
) {
    MediaContentSwitcher(
        modifier = modifier,
        isVideoMode = playerState.isVideo,
        videoId = playerState.videoId,
        audioViewContent = albumArtView
    )
}

/**
 * Core MediaContentSwitcher implementation using [Crossfade] or [AnimatedContent].
 */
@Composable
fun MediaContentSwitcher(
    modifier: Modifier = Modifier,
    isVideoMode: Boolean = false,
    videoId: String? = null,
    audioViewContent: @Composable () -> Unit,
) {
    AnimatedContent(
        targetState = isVideoMode && !videoId.isNullOrBlank(),
        transitionSpec = {
            fadeIn(animationSpec = tween(350)) togetherWith fadeOut(animationSpec = tween(350))
        },
        modifier = modifier,
        label = "MediaContentSwitcherAnimatedContent"
    ) { showVideo ->
        if (showVideo && !videoId.isNullOrBlank()) {
            // WebView container for YouTube Video Stream
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.Black)
            ) {
                AndroidView(
                    factory = { context ->
                        WebView(context).apply {
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                mediaPlaybackRequiresUserGesture = false
                                allowFileAccess = true
                            }
                            webViewClient = WebViewClient()
                            webChromeClient = WebChromeClient()

                            val html = buildYouTubeHtml(videoId)
                            loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "UTF-8", null)
                        }
                    },
                    update = { webView ->
                        val html = buildYouTubeHtml(videoId)
                        webView.loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "UTF-8", null)
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        } else {
            // Standard AlbumArt / Audio View Content
            audioViewContent()
        }
    }
}

private fun buildYouTubeHtml(videoId: String): String {
    return """
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { margin: 0; padding: 0; background-color: #000; overflow: hidden; }
                .container { position: relative; width: 100%; height: 100vh; }
                iframe { width: 100%; height: 100%; border: none; }
            </style>
        </head>
        <body>
            <div class="container">
                <iframe id="ytplayer" type="text/html"
                    src="https://www.youtube.com/embed/$videoId?enablejsapi=1&autoplay=1&controls=1&rel=0&playsinline=1"
                    allow="autoplay; encrypted-media" allowfullscreen></iframe>
            </div>
        </body>
        </html>
    """.trimIndent()
}
