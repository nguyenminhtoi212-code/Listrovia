/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.component

import com.listrovia.music.api.DeepInfraModelItem
import com.listrovia.music.api.OpenRouterModelItem

/**
 * Mục phần tử trong danh sách chọn mô hình AI (Header nhóm nhà cung cấp hoặc từng mô hình cụ thể).
 */
sealed class ModelListEntry {
    data class Header(
        val providerName: String,
        val count: Int,
        val sampleModelId: String,
    ) : ModelListEntry()

    data class OpenRouterModel(
        val item: OpenRouterModelItem,
    ) : ModelListEntry()

    data class DeepInfraModel(
        val model: DeepInfraModelItem,
    ) : ModelListEntry()
}
