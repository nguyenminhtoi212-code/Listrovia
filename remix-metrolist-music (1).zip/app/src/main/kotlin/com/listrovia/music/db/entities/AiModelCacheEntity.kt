/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.db.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "ai_model_metadata_cache")
data class AiModelCacheEntity(
    @PrimaryKey val id: String,
    val provider: String, // "OpenRouter" or "DeepInfra"
    val name: String,
    val description: String = "",
    val descriptionVi: String = "",
    val providerName: String = "",
    val tier: String = "Official", // "Official", "Beta", "Developer", "Recommended", "Chat", "Reasoning", "All"
    val sourceCategory: String = "ALL", // "ALL", "VERIFIED", "COMMUNITY", "DEVELOPER"
    val healthStatus: String = "STABLE", // "STABLE", "BETA", "PENDING", "DEVELOPER"
    val contextLength: Long = 0L,
    val maxTokens: Long = 0L,
    val pricingPrompt: String = "",
    val pricingCompletion: String = "",
    val pricingBadge: String = "",
    val isChat: Boolean = true,
    val isReasoning: Boolean = false,
    val rank: Int = 999,
    val rankTitleEn: String = "",
    val rankTitleVi: String = "",
    val cachedAt: Long = System.currentTimeMillis(),
)
