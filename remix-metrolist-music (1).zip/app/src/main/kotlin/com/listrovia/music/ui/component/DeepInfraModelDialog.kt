/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.component

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import android.widget.Toast
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import com.listrovia.music.R
import com.listrovia.music.api.DeepInfraClassifiedModels
import com.listrovia.music.api.DeepInfraModelItem
import com.listrovia.music.api.DeepInfraModelManager
import com.listrovia.music.utils.ModelBenchmarkUtility
import com.listrovia.music.utils.ModelFavoritesManager
import com.listrovia.music.utils.TTFTBadge
import com.listrovia.music.utils.pulltorefresh.PullToRefreshBox
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Hộp thoại chọn mô hình DeepInfra AI với giao diện Bảng xếp hạng & Đo lường hiệu năng (Benchmark & Inference Hub)
 * Thiết kế hoàn toàn khác biệt so với OpenRouter: tập trung vào thứ hạng, suy luận (reasoning), tốc độ và chi phí trên 1M tokens.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DeepInfraModelDialog(
    currentModel: String,
    onDismiss: () -> Unit,
    onSelectModel: (String) -> Unit,
    onCustomInput: () -> Unit,
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val modelManager = remember { DeepInfraModelManager.getInstance(context) }

    var classifiedModels by remember { mutableStateOf<DeepInfraClassifiedModels?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var selectedTab by rememberSaveable { mutableIntStateOf(0) } // 0: Ranked, 1: Chat, 2: Reasoning, 3: All
    var selectedCategory by rememberSaveable { mutableStateOf(ModelSourceCategory.ALL) }
    var searchQuery by rememberSaveable { mutableStateOf("") }
    val favoritesManager = remember { ModelFavoritesManager.getInstance(context) }
    val benchmarkUtility = remember { ModelBenchmarkUtility.getInstance(context) }
    var favoriteVersion by remember { mutableStateOf(0) }
    var isBenchmarking by remember { mutableStateOf(false) }
    var activeDetailModel by remember { mutableStateOf<DetailedAiModelInfo?>(null) }

    val allAvailableModels = remember(classifiedModels) {
        val m = classifiedModels
        if (m == null) emptyList() else m.allModels.distinctBy { it.id }
    }
    val recentlyUsedModels: List<DeepInfraModelItem> = remember(allAvailableModels, favoriteVersion) {
        val recentIds = favoritesManager.getRecentlyUsedModelIds(limit = 6)
        recentIds.mapNotNull { rId ->
            allAvailableModels.firstOrNull { it.id == rId }
        }
    }
    val recommendedModels: List<DeepInfraModelItem> = remember(classifiedModels) {
        val m = classifiedModels ?: return@remember emptyList()
        m.recommended.ifEmpty { m.allModels.filter { it.rank <= 10 } }
    }

    val isVietnamese = remember { Locale.getDefault().language == "vi" }

    fun loadModels(forceRefresh: Boolean = false) {
        coroutineScope.launch {
            isLoading = true
            try {
                classifiedModels = modelManager.fetchModels(forceRefresh = forceRefresh)
            } finally {
                isLoading = false
            }
        }
    }

    LaunchedEffect(Unit) {
        loadModels(forceRefresh = false)
    }

    val currentList: List<DeepInfraModelItem> =
        remember(classifiedModels, selectedTab, selectedCategory, searchQuery, favoriteVersion) {
            val models = classifiedModels ?: return@remember emptyList()
            val baseList = when (selectedTab) {
                0 -> models.recommended
                1 -> models.chatModels
                2 -> models.reasoningModels
                else -> models.allModels
            }.filter { favoritesManager.isModelSafeAndPublished(it.id, it.name, it.description, provider = "DeepInfra") }
            .filter {
                when (selectedCategory) {
                    ModelSourceCategory.ALL -> true
                    ModelSourceCategory.VERIFIED -> getModelSourceCategory(it.id, it.providerName) == ModelSourceCategory.VERIFIED
                    ModelSourceCategory.COMMUNITY -> getModelSourceCategory(it.id, it.providerName) == ModelSourceCategory.COMMUNITY
                    ModelSourceCategory.DEVELOPER -> getModelSourceCategory(it.id, it.providerName) == ModelSourceCategory.DEVELOPER
                }
            }

            if (searchQuery.isBlank()) {
                baseList
            } else {
                val q = searchQuery.trim().lowercase()
                baseList.filter {
                    it.id.lowercase().contains(q) ||
                            it.name.lowercase().contains(q) ||
                            it.description.lowercase().contains(q) ||
                            it.descriptionVi.lowercase().contains(q) ||
                            it.providerName.lowercase().contains(q) ||
                            getProviderVisualInfo(it.id, it.providerName).name.lowercase().contains(q)
                }
            }
        }

    val rankedCount = classifiedModels?.recommended?.size ?: 0
    val chatCount = classifiedModels?.chatModels?.size ?: 0
    val reasonCount = classifiedModels?.reasoningModels?.size ?: 0
    val allCount = classifiedModels?.allModels?.size ?: 0

    AlertDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier
            .widthIn(min = 280.dp, max = 500.dp)
            .fillMaxWidth(0.92f)
            .heightIn(max = 640.dp),
        title = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.ai_deepinfra_dialog_title),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(top = 2.dp),
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF4CAF50)),
                            )
                            Text(
                                text = "DeepInfra Realtime Hub",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Medium,
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = {
                                coroutineScope.launch {
                                    isBenchmarking = true
                                    try {
                                        val targetId = currentModel.ifBlank { currentList.firstOrNull()?.id ?: "meta-llama/Meta-Llama-3.1-8B-Instruct" }
                                        val ttft = benchmarkUtility.benchmarkModel(targetId, baseUrl = "https://api.deepinfra.com/v1/openai/models")
                                        Toast.makeText(
                                            context,
                                            context.getString(R.string.ai_model_ttft_label, ttft),
                                            Toast.LENGTH_SHORT
                                        ).show()
                                        favoriteVersion++
                                    } finally {
                                        isBenchmarking = false
                                    }
                                }
                            },
                            enabled = !isLoading && !isBenchmarking,
                        ) {
                            if (isBenchmarking) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp,
                                )
                            } else {
                                Icon(
                                    painter = painterResource(R.drawable.speed),
                                    contentDescription = stringResource(R.string.ai_model_ttft_benchmark),
                                    tint = MaterialTheme.colorScheme.primary,
                                )
                            }
                        }

                        IconButton(
                            onClick = { loadModels(forceRefresh = true) },
                            enabled = !isLoading,
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp,
                                )
                            } else {
                                Icon(
                                    painter = painterResource(R.drawable.sync),
                                    contentDescription = stringResource(R.string.ai_deepinfra_refresh),
                                    tint = MaterialTheme.colorScheme.primary,
                                )
                            }
                        }
                    }
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Search bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(stringResource(R.string.ai_deepinfra_search_hint))
                    },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.search),
                            contentDescription = null,
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    painter = painterResource(R.drawable.close),
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth(),
                )

                // Recently Used Section at the top
                if (recentlyUsedModels.isNotEmpty() && searchQuery.isBlank()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp, bottom = 2.dp),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 2.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(
                                text = stringResource(R.string.ai_model_recently_used),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                            )
                            val totalInteractions = recentlyUsedModels.sumOf { favoritesManager.getModelUsageCount(it.id) }
                            if (totalInteractions > 0) {
                                Text(
                                    text = stringResource(R.string.ai_model_interactions_count, totalInteractions),
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                )
                            }
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            recentlyUsedModels.forEach { rModel ->
                                val isRSelected = rModel.id == currentModel
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isRSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isRSelected) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                                    ),
                                    modifier = Modifier
                                        .width(168.dp)
                                        .clickable {
                                            activeDetailModel = rModel.toDetailedInfo(isVietnamese)
                                        },
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    ) {
                                        ProviderAvatar(
                                            modelId = rModel.id,
                                            providerName = rModel.providerName,
                                            size = 22.dp,
                                        )
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = rModel.name,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                            )
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                            ) {
                                                val ttft = benchmarkUtility.getEstimatedOrMeasuredTtft(rModel.id, rModel.name, rModel.contextLength)
                                                Text(
                                                    text = "⚡ ${ttft}ms",
                                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                                    color = MaterialTheme.colorScheme.primary,
                                                    fontWeight = FontWeight.SemiBold,
                                                )
                                                val cnt = favoritesManager.getModelUsageCount(rModel.id)
                                                if (cnt > 0) {
                                                    Text(
                                                        text = "• ${cnt}x",
                                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Recommended Models Section (Đề xuất danh sách)
                if (recommendedModels.isNotEmpty() && searchQuery.isBlank()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp, bottom = 4.dp),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 2.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                            ) {
                                Text(text = "⭐", fontSize = 12.sp)
                                Text(
                                    text = stringResource(R.string.ai_model_recommended_title),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.tertiary,
                                )
                            }
                            Text(
                                text = stringResource(R.string.ai_model_details_tap_hint),
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            )
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            recommendedModels.take(8).forEach { recModel ->
                                val isRecSelected = recModel.id == currentModel
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isRecSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                    border = BorderStroke(
                                        if (isRecSelected) 1.5.dp else 1.dp,
                                        if (isRecSelected) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f),
                                    ),
                                    modifier = Modifier
                                        .width(185.dp)
                                        .height(58.dp)
                                        .clickable {
                                            favoritesManager.recordModelUsage(recModel.id)
                                            onSelectModel(recModel.id)
                                        },
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        ProviderAvatar(
                                            modelId = recModel.id,
                                            providerName = recModel.providerName,
                                            size = 28.dp,
                                        )
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = recModel.name,
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = if (isRecSelected) FontWeight.Bold else FontWeight.SemiBold,
                                                color = if (isRecSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                            )
                                            val ttft = benchmarkUtility.getEstimatedOrMeasuredTtft(recModel.id, recModel.name, recModel.contextLength)
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                            ) {
                                                Text(
                                                    text = "⚡ ${ttft}ms",
                                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                                    color = MaterialTheme.colorScheme.primary,
                                                    fontWeight = FontWeight.SemiBold,
                                                )
                                                if (recModel.rank < 999) {
                                                    Text(
                                                        text = "#${recModel.rank}",
                                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.5.sp, fontWeight = FontWeight.Bold),
                                                        color = MaterialTheme.colorScheme.tertiary,
                                                    )
                                                }
                                            }
                                        }
                                        IconButton(
                                            onClick = {
                                                activeDetailModel = recModel.toDetailedInfo(isVietnamese)
                                            },
                                            modifier = Modifier.size(24.dp),
                                        ) {
                                            Icon(
                                                painter = painterResource(R.drawable.info),
                                                contentDescription = stringResource(R.string.ai_model_view_description),
                                                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                                                modifier = Modifier.size(15.dp),
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Specialized Benchmark Tabs: Ranked, Chat, Reasoning, All
                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    edgePadding = 0.dp,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Text(
                                text = stringResource(R.string.ai_deepinfra_tab_rec_dialog, rankedCount),
                                style = MaterialTheme.typography.labelMedium,
                            )
                        },
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Text(
                                text = stringResource(R.string.ai_deepinfra_tab_chat_dialog, chatCount),
                                style = MaterialTheme.typography.labelMedium,
                            )
                        },
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = {
                            Text(
                                text = stringResource(R.string.ai_deepinfra_tab_reason_dialog, reasonCount),
                                style = MaterialTheme.typography.labelMedium,
                            )
                        },
                    )
                    Tab(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        text = {
                            Text(
                                text = stringResource(R.string.ai_deepinfra_tab_all_dialog, allCount),
                                style = MaterialTheme.typography.labelMedium,
                            )
                        },
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Source Category Filter Chips
                ModelSourceCategoryChips(
                    selectedCategory = selectedCategory,
                    onSelectCategory = { selectedCategory = it },
                    modifier = Modifier.fillMaxWidth(),
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Models list Container with Pull-to-Refresh support
                PullToRefreshBox(
                    isRefreshing = isLoading,
                    onRefresh = { loadModels(forceRefresh = true) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 380.dp),
                ) {
                    if (isLoading && classifiedModels == null) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(32.dp))
                            Text(
                                text = stringResource(R.string.ai_deepinfra_loading_dialog_status),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    } else if (currentList.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = stringResource(R.string.ai_deepinfra_no_match),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    } else {
                        val favHeaderTitle = if (isVietnamese) "⭐ Mô hình yêu thích" else "⭐ Favorite Models"
                        val collapsedProviders = remember { mutableStateMapOf<String, Boolean>() }
                        val entries = remember(currentList, collapsedProviders, favoriteVersion, favHeaderTitle) {
                            val favIds = favoritesManager.getFavoriteIds()
                            val favoriteModels = currentList.filter { favIds.contains(it.id) }
                            val nonFavoriteModels = currentList.filter { !favIds.contains(it.id) }

                            val list = mutableListOf<ModelListEntry>()

                            if (favoriteModels.isNotEmpty()) {
                                list.add(ModelListEntry.Header(favHeaderTitle, favoriteModels.size, favoriteModels.firstOrNull()?.id ?: ""))
                                if (collapsedProviders[favHeaderTitle] != true) {
                                    favoriteModels.forEach { model ->
                                        list.add(ModelListEntry.DeepInfraModel(model))
                                    }
                                }
                            }

                            val grouped = nonFavoriteModels.groupBy { model ->
                                getProviderVisualInfo(model.id, model.providerName).name
                            }.toSortedMap()

                            grouped.forEach { (providerName, models) ->
                                list.add(ModelListEntry.Header(providerName, models.size, models.firstOrNull()?.id ?: ""))
                                if (collapsedProviders[providerName] != true) {
                                    models.forEach { model ->
                                        list.add(ModelListEntry.DeepInfraModel(model))
                                    }
                                }
                            }
                            list
                        }

                        AnimatedContent(
                            targetState = selectedCategory,
                            transitionSpec = {
                                fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(180))
                            },
                            label = "DeepInfraCategoryTransition",
                        ) { _ ->
                            LazyColumn(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                items(
                                    items = entries,
                                    key = { entry ->
                                        when (entry) {
                                            is ModelListEntry.Header -> "header_${entry.providerName}"
                                            is ModelListEntry.OpenRouterModel -> "model_${entry.item.id}"
                                            is ModelListEntry.DeepInfraModel -> "deepinfra_${entry.model.id}"
                                        }
                                    },
                                    contentType = { entry ->
                                        when (entry) {
                                            is ModelListEntry.Header -> "header"
                                            is ModelListEntry.OpenRouterModel -> "openrouter_model"
                                            is ModelListEntry.DeepInfraModel -> "deepinfra_model"
                                        }
                                    },
                                ) { entry ->
                                    when (entry) {
                                        is ModelListEntry.Header -> {
                                            val isCollapsed = collapsedProviders[entry.providerName] == true
                                            Surface(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 2.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .clickable {
                                                        collapsedProviders[entry.providerName] = !isCollapsed
                                                    },
                                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f),
                                            ) {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 10.dp, vertical = 6.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                ) {
                                                    ProviderAvatar(
                                                        modelId = entry.sampleModelId,
                                                        providerName = entry.providerName,
                                                        size = 22.dp,
                                                    )
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Text(
                                                        text = entry.providerName,
                                                        style = MaterialTheme.typography.titleSmall,
                                                        fontWeight = FontWeight.Bold,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        modifier = Modifier.weight(1f),
                                                    )
                                                    Surface(
                                                        shape = RoundedCornerShape(10.dp),
                                                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                                    ) {
                                                        Text(
                                                            text = "${entry.count}",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = MaterialTheme.colorScheme.primary,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                        )
                                                    }
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Icon(
                                                        painter = painterResource(
                                                            if (isCollapsed) R.drawable.expand_more else R.drawable.expand_less
                                                        ),
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        modifier = Modifier.size(18.dp),
                                                    )
                                                }
                                            }
                                        }
                                        is ModelListEntry.DeepInfraModel -> {
                                            val model = entry.model
                                            val isSelected = model.id == currentModel
                                            val isFav = favoritesManager.isFavorite(model.id)
                                            val rankTitle = model.getRankTitleByLanguage(isVietnamese)
                                            val description = model.getDescriptionByLanguage(isVietnamese)

                                            Card(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable {
                                                        activeDetailModel = model.toDetailedInfo(isVietnamese)
                                                    },
                                                shape = RoundedCornerShape(12.dp),
                                                colors = CardDefaults.cardColors(
                                                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                                                    else MaterialTheme.colorScheme.surface,
                                                ),
                                                border = if (isSelected) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                                                else BorderStroke(0.7.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                                            ) {
                                                Column(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 10.dp, vertical = 8.dp)
                                                ) {
                                                    // Top Row: Rank Badge / Monogram + Title + Action Buttons
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        verticalAlignment = Alignment.CenterVertically,
                                                    ) {
                                                        ProviderAvatar(
                                                            modelId = model.id,
                                                            providerName = model.providerName,
                                                            size = 32.dp,
                                                        )

                                                        Spacer(modifier = Modifier.width(10.dp))

                                                        Column(modifier = Modifier.weight(1f)) {
                                                            if (rankTitle.isNotBlank()) {
                                                                Surface(
                                                                    shape = RoundedCornerShape(4.dp),
                                                                    color = MaterialTheme.colorScheme.primaryContainer,
                                                                    modifier = Modifier.padding(bottom = 2.dp),
                                                                ) {
                                                                    Text(
                                                                        text = rankTitle,
                                                                        style = MaterialTheme.typography.labelSmall.copy(
                                                                            fontSize = 9.sp,
                                                                            fontWeight = FontWeight.Bold,
                                                                        ),
                                                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp),
                                                                    )
                                                                }
                                                            }

                                                            Text(
                                                                text = model.name,
                                                                style = MaterialTheme.typography.titleSmall,
                                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                                                                maxLines = 1,
                                                                overflow = TextOverflow.Ellipsis,
                                                            )
                                                            Text(
                                                                text = model.id,
                                                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                                                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                                                maxLines = 1,
                                                                overflow = TextOverflow.Ellipsis,
                                                            )
                                                        }

                                                        IconButton(
                                                            onClick = {
                                                                activeDetailModel = model.toDetailedInfo(isVietnamese)
                                                            },
                                                            modifier = Modifier.size(32.dp),
                                                        ) {
                                                            Icon(
                                                                painter = painterResource(R.drawable.info),
                                                                contentDescription = stringResource(R.string.ai_model_view_description),
                                                                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                                                                modifier = Modifier.size(18.dp),
                                                            )
                                                        }

                                                        IconButton(
                                                            onClick = {
                                                                favoritesManager.toggleFavorite(model.id)
                                                                favoriteVersion++
                                                            },
                                                            modifier = Modifier.size(32.dp)
                                                        ) {
                                                            Icon(
                                                                painter = painterResource(if (isFav) R.drawable.star else R.drawable.favorite_border),
                                                                contentDescription = null,
                                                                tint = if (isFav) Color(0xFFFFC107) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                                                modifier = Modifier.size(18.dp),
                                                            )
                                                        }

                                                        RadioButton(
                                                            selected = isSelected,
                                                            onClick = {
                                                                favoritesManager.recordModelUsage(model.id)
                                                                onSelectModel(model.id)
                                                            },
                                                            modifier = Modifier.size(32.dp)
                                                        )
                                                    }

                                                    // Middle Description (if available)
                                                    if (description.isNotBlank()) {
                                                        Text(
                                                            text = description,
                                                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, lineHeight = 15.sp),
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                            maxLines = 2,
                                                            overflow = TextOverflow.Ellipsis,
                                                            modifier = Modifier.padding(vertical = 4.dp),
                                                        )
                                                    }

                                                    // Bottom Row: Telemetry & Status Badges
                                                    FlowRow(
                                                        modifier = Modifier.padding(top = 2.dp),
                                                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                                                        verticalArrangement = Arrangement.spacedBy(4.dp),
                                                    ) {
                                                        ProviderBadge(
                                                            modelId = model.id,
                                                            providerName = model.providerName,
                                                        )

                                                        ModelServiceHealthBadge(
                                                            health = getModelServiceHealth(model.id, model.name, model.contextLength),
                                                        )

                                                        val ttftMs = benchmarkUtility.getEstimatedOrMeasuredTtft(model.id, model.name, model.contextLength)
                                                        val isMeasured = benchmarkUtility.getMeasuredTtft(model.id) != null
                                                        TTFTBadge(
                                                            ttftMs = ttftMs,
                                                            isMeasured = isMeasured,
                                                        )

                                                        ModelStatusBadge(
                                                            status = getModelHealthStatus(model.id, model.name),
                                                        )

                                                        if (model.formattedContext.isNotBlank()) {
                                                            Surface(
                                                                shape = RoundedCornerShape(4.dp),
                                                                color = MaterialTheme.colorScheme.tertiaryContainer,
                                                            ) {
                                                                Text(
                                                                    text = "${model.formattedContext} ctx",
                                                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                                                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                                                                )
                                                            }
                                                        }

                                                        if (model.pricingBadge.isNotBlank()) {
                                                            Surface(
                                                                shape = RoundedCornerShape(4.dp),
                                                                color = if (model.pricingBadge == "Free") Color(0xFFE8F5E9) else MaterialTheme.colorScheme.surfaceVariant,
                                                            ) {
                                                                Text(
                                                                    text = if (model.pricingBadge == "Free") stringResource(R.string.ai_deepinfra_free_only) else model.pricingBadge,
                                                                    style = MaterialTheme.typography.labelSmall.copy(
                                                                        fontSize = 9.sp,
                                                                        fontWeight = FontWeight.Medium,
                                                                    ),
                                                                    color = if (model.pricingBadge == "Free") Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant,
                                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                                                                )
                                                            }
                                                        }

                                                        if (model.isReasoning) {
                                                            Surface(
                                                                shape = RoundedCornerShape(4.dp),
                                                                color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f),
                                                            ) {
                                                                Text(
                                                                    text = stringResource(R.string.ai_deepinfra_reasoning_badge),
                                                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        else -> {}
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onCustomInput) {
                Text(stringResource(R.string.ai_deepinfra_custom_id_btn))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.ai_deepinfra_button_close))
            }
        },
    )

    activeDetailModel?.let { detailModel ->
        ModelDetailExpandableModal(
            model = detailModel,
            isSelected = detailModel.id == currentModel,
            onSelect = {
                favoritesManager.recordModelUsage(detailModel.id)
                onSelectModel(detailModel.id)
            },
            onDismiss = { activeDetailModel = null },
            benchmarkUtility = benchmarkUtility,
        )
    }
}
