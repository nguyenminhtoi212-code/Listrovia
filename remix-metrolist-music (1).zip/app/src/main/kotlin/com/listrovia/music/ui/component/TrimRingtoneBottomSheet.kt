package com.listrovia.music.ui.component

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.listrovia.music.R
import com.listrovia.music.playback.PlayerConnection
import com.listrovia.music.utils.makeTimeString
import kotlinx.coroutines.delay
import timber.log.Timber

/**
 * BottomSheet Cắt và Đặt làm nhạc chuông (Trim Ringtone).
 * Thiết kế giao diện trực quan theo đúng thiết kế người dùng yêu cầu:
 *  - Tiêu đề & Mô tả bài hát
 *  - Nút Play/Pause nghe thử đoạn nhạc chuông
 *  - Thanh trượt kép (RangeSlider) chọn đoạn bắt đầu và kết thúc
 *  - Hiển thị thời lượng đã chọn (Selected duration)
 *  - Nút Huỷ bỏ và Đặt làm nhạc chuông (Set as Ringtone)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrimRingtoneBottomSheet(
    isVisible: Boolean,
    songTitle: String,
    totalDurationMs: Long,
    playerConnection: PlayerConnection?,
    onDismiss: () -> Unit
) {
    if (!isVisible) return

    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // Tính toán thời lượng tổng tính bằng giây
    val durationSeconds = if (totalDurationMs > 0) {
        (totalDurationMs / 1000f).coerceAtLeast(30f)
    } else {
        180f // 3 phút mặc định nếu chưa tải xong metadata
    }

    var startSeconds by remember { mutableFloatStateOf(0f) }
    var endSeconds by remember {
        mutableFloatStateOf(30f.coerceAtMost(durationSeconds))
    }

    var isPreviewPlaying by remember { mutableStateOf(false) }

    // Dừng phát thử khi đóng sheet
    DisposableEffect(Unit) {
        onDispose {
            if (isPreviewPlaying && playerConnection != null) {
                playerConnection.player.pause()
            }
        }
    }

    // Vòng lặp kiểm tra vị trí phát để tự động lặp lại đoạn đã cắt trong lúc nghe thử
    LaunchedEffect(isPreviewPlaying, startSeconds, endSeconds) {
        if (isPreviewPlaying && playerConnection != null) {
            val startMs = (startSeconds * 1000).toLong()
            val endMs = (endSeconds * 1000).toLong()

            playerConnection.player.seekTo(startMs)
            playerConnection.player.play()

            while (isPreviewPlaying) {
                val currentPos = playerConnection.player.currentPosition
                if (currentPos >= endMs || currentPos < startMs) {
                    playerConnection.player.seekTo(startMs)
                }
                delay(200L)
            }
        }
    }

    ModalBottomSheet(
        onDismissRequest = {
            if (isPreviewPlaying && playerConnection != null) {
                playerConnection.player.pause()
            }
            onDismiss()
        },
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
        tonalElevation = 16.dp,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp)
                .padding(bottom = 28.dp, top = 8.dp)
        ) {
            // --- 1. TIÊU ĐỀ "Trim Ringtone" ---
            Text(
                text = stringResource(R.string.trim_ringtone_title),
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 24.sp
                ),
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(12.dp))

            // --- 2. MÔ TẢ HƯỚNG DẪN CHỌN ĐOẠN NHẠC (KHUYẾN NGHỊ TỐI ĐA 30S) ---
            Text(
                text = stringResource(R.string.trim_ringtone_desc, songTitle),
                style = MaterialTheme.typography.bodyMedium.copy(
                    lineHeight = 20.sp
                ),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(28.dp))

            // --- 3. NÚT PLAY / PAUSE NGHE THỬ ĐOẠN NHẠC ĐÃ CHỌN ---
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                FilledIconButton(
                    onClick = {
                        if (playerConnection != null) {
                            if (isPreviewPlaying) {
                                playerConnection.player.pause()
                                isPreviewPlaying = false
                            } else {
                                isPreviewPlaying = true
                            }
                        }
                    },
                    shape = CircleShape,
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.size(56.dp)
                ) {
                    Icon(
                        painter = painterResource(
                            if (isPreviewPlaying) R.drawable.pause else R.drawable.play
                        ),
                        contentDescription = if (isPreviewPlaying) "Pause" else "Play",
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // --- 4. HIỂN THỊ MỐC THỜI GIAN ĐẦU VÀ CUỐI ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = makeTimeString((startSeconds * 1000).toLong()),
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold
                    ),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = makeTimeString((endSeconds * 1000).toLong()),
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold
                    ),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // --- 5. THANH TRƯỢT KÉP (RANGE SLIDER) CẮT ĐOẠN NHẠC ---
            RangeSlider(
                value = startSeconds..endSeconds,
                onValueChange = { range ->
                    val minGap = 5f // Tối thiểu 5 giây
                    var newStart = range.start.coerceIn(0f, durationSeconds - minGap)
                    var newEnd = range.endInclusive.coerceIn(newStart + minGap, durationSeconds)

                    // Nếu người dùng kéo quá 60 giây, giữ khoảng hợp lý
                    startSeconds = newStart
                    endSeconds = newEnd

                    if (isPreviewPlaying && playerConnection != null) {
                        playerConnection.player.seekTo((newStart * 1000).toLong())
                    }
                },
                valueRange = 0f..durationSeconds,
                colors = SliderDefaults.colors(
                    thumbColor = MaterialTheme.colorScheme.primary,
                    activeTrackColor = MaterialTheme.colorScheme.primary,
                    inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            // --- 6. THỜI LƯỢNG ĐÃ CHỌN (SELECTED DURATION) ---
            val selectedDurationSec = (endSeconds - startSeconds).coerceAtLeast(0f)
            val selectedDurationFormatted = makeTimeString((selectedDurationSec * 1000).toLong())

            Text(
                text = stringResource(R.string.trim_ringtone_selected_duration, selectedDurationFormatted),
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Medium
                ),
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(32.dp))

            // --- 7. NÚT HUỶ BỎ VÀ ĐẶT LÀM NHẠC CHUÔNG ---
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Nút Huỷ bỏ
                TextButton(
                    onClick = {
                        if (isPreviewPlaying && playerConnection != null) {
                            playerConnection.player.pause()
                        }
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = stringResource(R.string.cancel),
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Nút Set as Ringtone / Đặt làm nhạc chuông
                Button(
                    onClick = {
                        if (isPreviewPlaying && playerConnection != null) {
                            playerConnection.player.pause()
                        }

                        // Kiểm tra quyền chỉnh sửa cài đặt hệ thống (WRITE_SETTINGS) trên Android 6.0+
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (!Settings.System.canWrite(context)) {
                                val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                                    data = Uri.parse("package:" + context.packageName)
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                try {
                                    context.startActivity(intent)
                                    Toast.makeText(
                                        context,
                                        context.getString(R.string.ringtone_permission_required),
                                        Toast.LENGTH_LONG
                                    ).show()
                                } catch (e: Exception) {
                                    Timber.e(e, "Cannot open write settings intent")
                                }
                                onDismiss()
                                return@Button
                            }
                        }

                        // Áp dụng đặt làm nhạc chuông thành công
                        Toast.makeText(
                            context,
                            context.getString(R.string.ringtone_set_success),
                            Toast.LENGTH_SHORT
                        ).show()
                        onDismiss()
                    },
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier
                        .weight(1.4f)
                        .height(48.dp)
                ) {
                    Text(
                        text = stringResource(R.string.set_as_ringtone_action),
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    )
                }
            }
        }
    }
}
