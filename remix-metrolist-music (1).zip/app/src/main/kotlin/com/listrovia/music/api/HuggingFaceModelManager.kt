/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */
package com.listrovia.music.api

import android.content.Context
import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.request.get
import io.ktor.client.request.parameter
import io.ktor.client.statement.bodyAsText
import io.ktor.http.isSuccess
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import timber.log.Timber
import java.util.Locale

data class HuggingFaceModelItem(
    val id: String,
    val author: String,
    val likes: Int,
    val downloads: Int,
    val pipelineTag: String,
    val tags: List<String>,
    val private: Boolean,
) {
    val displayName: String
        get() = if (author.isNotBlank() && id.startsWith("$author/")) {
            id.removePrefix("$author/")
        } else {
            id
        }

    fun getDescriptionVi(): String {
        return when (pipelineTag.lowercase()) {
            "text-generation" -> "Mô hình sinh văn bản và trò chuyện AI thời gian thực."
            "automatic-speech-recognition" -> "Mô hình nhận diện giọng nói và chuyển đổi giọng nói thành văn bản."
            "audio-classification" -> "Mô hình phân loại và nhận diện âm thanh, bài hát."
            "translation" -> "Mô hình dịch thuật đa ngôn ngữ Anh-Việt và quốc tế."
            "feature-extraction" -> "Mô hình trích xuất đặc trưng nhúng (embeddings) cho văn bản/âm thanh."
            "image-classification" -> "Mô hình phân loại hình ảnh và bìa album."
            else -> "Mô hình trí tuệ nhân tạo tổng quát từ Hugging Face."
        }
    }

    fun getDescriptionEn(): String {
        return when (pipelineTag.lowercase()) {
            "text-generation" -> "Real-time text generation and conversational AI model."
            "automatic-speech-recognition" -> "Speech recognition and audio transcription model."
            "audio-classification" -> "Audio and music classification model."
            "translation" -> "Multilingual translation model."
            "feature-extraction" -> "Embedding feature extraction model for text/audio."
            "image-classification" -> "Image and album art classification model."
            else -> "General artificial intelligence model from Hugging Face."
        }
    }
}

class HuggingFaceModelManager(
    private val context: Context? = null,
) {
    private val apiUrl = "https://huggingface.co/api/models"
    private val mutex = Mutex()
    private var cachedModels: List<HuggingFaceModelItem>? = null
    private var lastFetchTime = 0L
    private val cacheTtl = 10 * 60 * 1000L // 10 minutes

    private val httpClient by lazy {
        HttpClient(OkHttp) {
            install(HttpTimeout) {
                requestTimeoutMillis = 15000L
                connectTimeoutMillis = 10000L
                socketTimeoutMillis = 15000L
            }
        }
    }

    suspend fun fetchModels(query: String = "", limit: Int = 50): List<HuggingFaceModelItem> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val now = System.currentTimeMillis()
            if (cachedModels != null && (now - lastFetchTime < cacheTtl) && query.isBlank()) {
                return@withContext cachedModels!!
            }

            try {
                val response = httpClient.get(apiUrl) {
                    parameter("limit", limit)
                    if (query.isNotBlank()) {
                        parameter("search", query)
                    }
                    parameter("sort", "likes")
                    parameter("direction", "-1")
                }

                if (response.status.isSuccess()) {
                    val jsonStr = response.bodyAsText()
                    val jsonArray = JSONArray(jsonStr)
                    val list = mutableListOf<HuggingFaceModelItem>()

                    for (i in 0 until jsonArray.length()) {
                        val obj = jsonArray.optJSONObject(i) ?: continue
                        val id = obj.optString("id", "")
                        if (id.isBlank()) continue

                        val author = obj.optString("author", "")
                        val likes = obj.optInt("likes", 0)
                        val downloads = obj.optInt("downloads", 0)
                        val pipelineTag = obj.optString("pipeline_tag", "general")
                        val private = obj.optBoolean("private", false)

                        val tagsJson = obj.optJSONArray("tags")
                        val tagsList = mutableListOf<String>()
                        if (tagsJson != null) {
                            for (t in 0 until tagsJson.length()) {
                                tagsJson.optString(t)?.let { tagsList.add(it) }
                            }
                        }

                        list.add(
                            HuggingFaceModelItem(
                                id = id,
                                author = author,
                                likes = likes,
                                downloads = downloads,
                                pipelineTag = pipelineTag,
                                tags = tagsList,
                                private = private
                            )
                        )
                    }

                    if (query.isBlank()) {
                        cachedModels = list
                        lastFetchTime = now
                    }
                    return@withContext list
                }
            } catch (e: Exception) {
                Timber.e(e, "Failed to fetch Hugging Face models")
            }

            return@withContext cachedModels ?: emptyList()
        }
    }
}
