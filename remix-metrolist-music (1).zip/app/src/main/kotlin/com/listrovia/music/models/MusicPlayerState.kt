package com.listrovia.music.models

import java.io.Serializable

/**
 * Data class representing the state of the music/video player, including
 * boolean [isVideo] flag and [videoId] string so components tracking the media
 * item can clearly distinguish between local audio files and YouTube video streams.
 */
data class MusicPlayerState(
    val mediaId: String = "",
    val title: String = "",
    val artist: String = "",
    val album: String? = null,
    val artworkUrl: String? = null,
    val isVideo: Boolean = false,
    val videoId: String? = null,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val timestamp: Long = System.currentTimeMillis()
) : Serializable
