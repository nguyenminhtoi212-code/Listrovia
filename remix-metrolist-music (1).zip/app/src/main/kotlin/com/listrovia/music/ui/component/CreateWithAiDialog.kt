/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.component

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.listrovia.innertube.YouTube
import com.listrovia.innertube.models.SongItem
import com.listrovia.music.LocalDatabase
import com.listrovia.music.R
import com.listrovia.music.db.entities.PlaylistEntity
import com.listrovia.music.db.entities.PlaylistSongMap
import com.listrovia.music.models.toMediaMetadata
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.time.LocalDateTime
import java.time.LocalTime

@Composable
fun CreateWithAiDialog(
    onDismiss: () -> Unit,
    onPlaylistCreated: ((String) -> Unit)? = null,
) {
    val context = LocalContext.current
    val database = LocalDatabase.current
    val coroutineScope = rememberCoroutineScope()

    var tuneIntoWeather by remember { mutableStateOf(false) }
    var prompt by remember { mutableStateOf("") }
    var songCount by remember { mutableStateOf(15) }
    var isGenerating by remember { mutableStateOf(false) }

    val emptyWarningStr = stringResource(R.string.ai_playlist_empty_warning)

    fun generatePlaylist() {
        if (prompt.isBlank() || isGenerating) return
        isGenerating = true

        coroutineScope.launch(Dispatchers.IO) {
            try {
                // Determine atmospheric context if weather / ambient tuning is enabled
                val weatherVibe = if (tuneIntoWeather) {
                    val hour = LocalTime.now().hour
                    when (hour) {
                        in 5..10 -> "morning energetic fresh"
                        in 11..16 -> "afternoon vibrant sunny"
                        in 17..20 -> "evening acoustic sunset chill"
                        else -> "late night lofi cozy ambient"
                    }
                } else ""

                val searchQuery = if (weatherVibe.isNotBlank()) {
                    "$prompt $weatherVibe"
                } else {
                    prompt.trim()
                }

                Timber.d("AI Playlist generation: searching with query '$searchQuery' for $songCount songs")

                val collectedSongs = mutableListOf<SongItem>()
                val seenIds = mutableSetOf<String>()

                // Primary search
                YouTube.search(searchQuery, YouTube.SearchFilter.FILTER_SONG).onSuccess { page ->
                    page.items.filterIsInstance<SongItem>().forEach { song ->
                        if (seenIds.add(song.id)) {
                            collectedSongs.add(song)
                        }
                    }
                }

                // Fallback / secondary search if more songs are needed
                if (collectedSongs.size < songCount && weatherVibe.isNotBlank()) {
                    YouTube.search(prompt.trim(), YouTube.SearchFilter.FILTER_SONG).onSuccess { page ->
                        page.items.filterIsInstance<SongItem>().forEach { song ->
                            if (seenIds.add(song.id)) {
                                collectedSongs.add(song)
                            }
                        }
                    }
                }

                val finalSongs = collectedSongs.take(songCount)

                if (finalSongs.isEmpty()) {
                    withContext(Dispatchers.Main) {
                        isGenerating = false
                        Toast.makeText(context, emptyWarningStr, Toast.LENGTH_SHORT).show()
                    }
                    return@launch
                }

                // Playlist Name
                val playlistTitle = prompt.trim().take(40).ifBlank { "AI Playlist" }

                val playlistEntity = PlaylistEntity(
                    name = playlistTitle,
                    bookmarkedAt = LocalDateTime.now(),
                    isEditable = true,
                )

                // Save playlist in database
                database.query {
                    insert(playlistEntity)
                }

                // Save songs and playlist song maps
                finalSongs.forEachIndexed { index, songItem ->
                    database.query {
                        insert(songItem.toMediaMetadata())
                        insert(
                            PlaylistSongMap(
                                playlistId = playlistEntity.id,
                                songId = songItem.id,
                                position = index
                            )
                        )
                    }
                }

                database.query {
                    updatePlaylistLastUpdated(playlistEntity.id)
                }

                withContext(Dispatchers.Main) {
                    isGenerating = false
                    onPlaylistCreated?.invoke(playlistEntity.id)
                    onDismiss()
                }
            } catch (e: Exception) {
                Timber.e(e, "Error generating AI playlist")
                withContext(Dispatchers.Main) {
                    isGenerating = false
                    Toast.makeText(context, emptyWarningStr, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    Dialog(
        onDismissRequest = {
            if (!isGenerating) onDismiss()
        }
    ) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
            ),
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("create_with_ai_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Title
                Text(
                    text = stringResource(R.string.create_with_ai),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                // 1. Tune into Weather Card
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                            Text(
                                text = stringResource(R.string.tune_into_weather),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = stringResource(R.string.tune_into_weather_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Switch(
                            checked = tuneIntoWeather,
                            onCheckedChange = { tuneIntoWeather = it },
                            enabled = !isGenerating,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                                checkedTrackColor = MaterialTheme.colorScheme.primary,
                                uncheckedThumbColor = MaterialTheme.colorScheme.outline,
                                uncheckedTrackColor = MaterialTheme.colorScheme.surfaceContainerHighest
                            )
                        )
                    }
                }

                // 2. Prompt Input Field
                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it },
                    placeholder = {
                        Text(
                            text = stringResource(R.string.ai_playlist_prompt_hint),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    },
                    enabled = !isGenerating,
                    minLines = 3,
                    maxLines = 5,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("ai_playlist_prompt_input")
                )

                // 3. Number of Songs & Slider
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = stringResource(R.string.number_of_songs, songCount),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Slider(
                        value = songCount.toFloat(),
                        onValueChange = { songCount = it.toInt() },
                        valueRange = 5f..50f,
                        steps = 8,
                        enabled = !isGenerating,
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.primary,
                            activeTrackColor = MaterialTheme.colorScheme.primary,
                            inactiveTrackColor = MaterialTheme.colorScheme.surfaceContainerHighest
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // 4. Action Buttons
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = onDismiss,
                        enabled = !isGenerating,
                        modifier = Modifier.height(44.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.cancel),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Button(
                        onClick = { generatePlaylist() },
                        enabled = prompt.isNotBlank() && !isGenerating,
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                            disabledContainerColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                            disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier
                            .height(44.dp)
                            .testTag("generate_ai_playlist_button")
                    ) {
                        if (isGenerating) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    strokeWidth = 2.dp,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = stringResource(R.string.generating_ai_playlist),
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        } else {
                            Text(
                                text = stringResource(R.string.generate),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
