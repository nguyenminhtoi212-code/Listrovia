/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.component

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.listrovia.music.R

enum class AppPlatform {
    YOUTUBE_MUSIC,
    YOUTUBE_VIDEO
}

@Composable
fun PlatformSwitcher(
    selectedPlatform: AppPlatform,
    onPlatformSelected: (AppPlatform) -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f),
        tonalElevation = 2.dp,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // YouTube Music Tab
            val isMusicSelected = selectedPlatform == AppPlatform.YOUTUBE_MUSIC
            val musicBgColor by animateColorAsState(
                targetValue = if (isMusicSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                animationSpec = tween(250),
                label = "musicBgColor"
            )
            val musicTextColor by animateColorAsState(
                targetValue = if (isMusicSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f),
                animationSpec = tween(250),
                label = "musicTextColor"
            )

            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(musicBgColor)
                    .clickable { onPlatformSelected(AppPlatform.YOUTUBE_MUSIC) },
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        painter = painterResource(R.drawable.music_note),
                        contentDescription = stringResource(R.string.platform_yt_music),
                        tint = musicTextColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.platform_yt_music),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = if (isMusicSelected) FontWeight.Bold else FontWeight.Medium,
                        color = musicTextColor,
                        maxLines = 1
                    )
                }
            }

            // YouTube Video Tab
            val isVideoSelected = selectedPlatform == AppPlatform.YOUTUBE_VIDEO
            val videoBgColor by animateColorAsState(
                targetValue = if (isVideoSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                animationSpec = tween(250),
                label = "videoBgColor"
            )
            val videoTextColor by animateColorAsState(
                targetValue = if (isVideoSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f),
                animationSpec = tween(250),
                label = "videoTextColor"
            )

            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(videoBgColor)
                    .clickable { onPlatformSelected(AppPlatform.YOUTUBE_VIDEO) },
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        painter = painterResource(R.drawable.video_mode),
                        contentDescription = stringResource(R.string.platform_yt_video),
                        tint = videoTextColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.platform_yt_video),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = if (isVideoSelected) FontWeight.Bold else FontWeight.Medium,
                        color = videoTextColor,
                        maxLines = 1
                    )
                }
            }
        }
    }
}
