package com.listrovia.music.db.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.listrovia.music.db.entities.SetVideoIdEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SetVideoIdDao {
    @Query("SELECT * FROM set_video_id WHERE videoId = :videoId")
    suspend fun getSetVideoId(videoId: String): SetVideoIdEntity?

    @Query("SELECT * FROM set_video_id WHERE videoId = :videoId")
    fun observeSetVideoId(videoId: String): Flow<SetVideoIdEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(setVideoIdEntity: SetVideoIdEntity)

    @Query("DELETE FROM set_video_id WHERE videoId = :videoId")
    suspend fun delete(videoId: String)
}
