/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.utils

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import androidx.datastore.preferences.core.booleanPreferencesKey
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.net.HttpURLConnection
import java.net.URL

/**
 * Detailed network state representation
 */
sealed interface NetworkStatus {
    data object Checking : NetworkStatus
    data class Connected(val isWifi: Boolean = true, val isMetered: Boolean = false) : NetworkStatus
    data class Disconnected(val reason: String? = null) : NetworkStatus
    data object CaptivePortal : NetworkStatus
}

/**
 * Modern Network Connectivity Observer with Active API reachability verification.
 * Replaces legacy offline detection with real-time HTTP 204 API endpoint verification
 * and reactive Coroutine StateFlow streaming.
 */
class NetworkConnectivityObserver(context: Context) {
    private val appContext = context.applicationContext
    private val connectivityManager =
        appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var pingJob: Job? = null

    private val _status = MutableStateFlow<NetworkStatus>(NetworkStatus.Checking)
    val status: StateFlow<NetworkStatus> = _status.asStateFlow()

    private val _isConnected = MutableStateFlow(true)
    val isConnectedFlow: StateFlow<Boolean> = _isConnected.asStateFlow()

    // Backwards compatibility for existing Flow<Boolean> consumers
    val networkStatus = _isConnected.asStateFlow()

    @Volatile
    private var isWifiOnlyEnabled = false

    @Volatile
    private var lastApiCheckTime = 0L

    @Volatile
    private var lastApiCheckResult = true

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            Timber.tag(TAG).d("Network available, verifying API connectivity...")
            scheduleApiCheck(immediate = true)
        }

        override fun onLost(network: Network) {
            Timber.tag(TAG).d("Network lost")
            _status.value = NetworkStatus.Disconnected("Network connection lost")
            _isConnected.value = false
        }

        override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
            val hasInternet = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            val isValidated = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            Timber.tag(TAG).d("Capabilities changed: hasInternet=$hasInternet, isValidated=$isValidated")
            scheduleApiCheck(immediate = false)
        }
    }

    init {
        // Observe Wi-Fi only preferences
        scope.launch {
            try {
                val wifiOnlyKey = booleanPreferencesKey("wifiOnlyStreaming")
                val onlyPlayWifiKey = booleanPreferencesKey("onlyPlayOverWifi")
                appContext.dataStore.data.collect { prefs ->
                    val wifiOnlyStreaming = prefs[wifiOnlyKey] ?: false
                    val onlyPlayOverWifi = prefs[onlyPlayWifiKey] ?: false
                    isWifiOnlyEnabled = wifiOnlyStreaming || onlyPlayOverWifi
                    scheduleApiCheck(immediate = true)
                }
            } catch (e: Exception) {
                Timber.tag(TAG).w(e, "Error observing Wi-Fi preferences")
            }
        }

        // Register system network callback
        try {
            connectivityManager.registerDefaultNetworkCallback(networkCallback)
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to register network callback")
            _isConnected.value = true
            _status.value = NetworkStatus.Connected(isWifi = true, isMetered = false)
        }

        // Initial check
        scheduleApiCheck(immediate = true)
    }

    fun refresh() {
        scheduleApiCheck(immediate = true)
    }

    private fun scheduleApiCheck(immediate: Boolean) {
        pingJob?.cancel()
        pingJob = scope.launch {
            if (!immediate) {
                delay(350) // Debounce rapid network state transitions
            }
            performApiReachabilityCheck()
        }
    }

    private suspend fun performApiReachabilityCheck() = withContext(Dispatchers.IO) {
        val activeNetwork = connectivityManager.activeNetwork
        if (activeNetwork == null) {
            _status.value = NetworkStatus.Disconnected("No active network interface")
            _isConnected.value = false
            return@withContext
        }

        val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork)
        if (capabilities == null || !capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
            _status.value = NetworkStatus.Disconnected("Network has no internet capability")
            _isConnected.value = false
            return@withContext
        }

        val isWifi = capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
        val isMetered = !capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)

        if (isWifiOnlyEnabled && !isWifi) {
            _status.value = NetworkStatus.Disconnected("Wi-Fi only mode active")
            _isConnected.value = false
            return@withContext
        }

        // Check if captive portal is detected
        if (capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL)) {
            _status.value = NetworkStatus.CaptivePortal
            _isConnected.value = false
            return@withContext
        }

        // Check active API reachability
        val apiReachable = checkApiConnectivity()
        if (apiReachable) {
            _status.value = NetworkStatus.Connected(isWifi = isWifi, isMetered = isMetered)
            _isConnected.value = true
        } else {
            _status.value = NetworkStatus.Disconnected("API server unreachable")
            _isConnected.value = false
        }
    }

    /**
     * Active API reachability ping via HTTP 204 endpoints.
     * Uses fast connection & read timeouts (2.5s) to detect true internet connectivity.
     */
    suspend fun checkApiConnectivity(): Boolean = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        if (now - lastApiCheckTime < 2500L) {
            return@withContext lastApiCheckResult
        }

        val endpoints = listOf(
            "https://clients3.google.com/generate_204",
            "https://www.gstatic.com/generate_204",
            "https://music.youtube.com/generate_204"
        )

        for (endpoint in endpoints) {
            if (!isActive) break
            try {
                val url = URL(endpoint)
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 2500
                    readTimeout = 2500
                    instanceFollowRedirects = false
                    useCaches = false
                    requestMethod = "HEAD"
                    setRequestProperty("User-Agent", "Mozilla/5.0 (Android; Metrolist)")
                }
                val responseCode = connection.responseCode
                connection.disconnect()
                if (responseCode in 200..399 || responseCode == 204) {
                    lastApiCheckTime = now
                    lastApiCheckResult = true
                    return@withContext true
                }
            } catch (e: Exception) {
                // Try next endpoint
            }
        }

        // Final fallback: check validated capability or general internet capability if API pings timed out
        val activeNetwork = connectivityManager.activeNetwork
        val capabilities = activeNetwork?.let { connectivityManager.getNetworkCapabilities(it) }
        val fallbackResult = capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true ||
            capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true

        lastApiCheckTime = now
        lastApiCheckResult = fallbackResult
        fallbackResult
    }

    /**
     * Synchronously checks whether the device currently has connectivity.
     */
    fun isCurrentlyConnected(): Boolean {
        return try {
            val activeNetwork = connectivityManager.activeNetwork ?: return false
            val networkCapabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false

            val hasInternet = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            if (!hasInternet) return false

            if (isWifiOnlyEnabled) {
                networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                        networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ||
                        networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
            } else {
                true
            }
        } catch (e: Exception) {
            true
        }
    }

    fun unregister() {
        try {
            connectivityManager.unregisterNetworkCallback(networkCallback)
        } catch (e: Exception) {
            // Ignored
        }
        try {
            scope.cancel()
        } catch (e: Exception) {
            // Ignored
        }
    }

    companion object {
        private const val TAG = "NetworkConnectivityObserver"
    }
}
