package com.listrovia.music.utils.pulltorefresh

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.IntOffset
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

interface PullToRefreshState {
    val isRefreshing: Boolean
}

class PullToRefreshStateImpl : PullToRefreshState {
    override val isRefreshing: Boolean = false
}

@Composable
fun rememberPullToRefreshState(): PullToRefreshState {
    return PullToRefreshStateImpl()
}

object PullToRefreshDefaults {
    @Composable
    fun Indicator(
        state: PullToRefreshState,
        isRefreshing: Boolean,
        modifier: Modifier = Modifier
    ) {
        if (isRefreshing) {
            CircularProgressIndicator(modifier = modifier)
        }
    }
}

fun Modifier.pullToRefresh(
    state: PullToRefreshState,
    isRefreshing: Boolean,
    onRefresh: () -> Unit
): Modifier = this

@Composable
fun PullToRefreshBox(
    isRefreshing: Boolean,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    state: PullToRefreshState = rememberPullToRefreshState(),
    indicator: @Composable BoxScope.() -> Unit = {
        PullToRefreshDefaults.Indicator(
            state = state,
            isRefreshing = isRefreshing,
            modifier = Modifier.align(Alignment.TopCenter)
        )
    },
    content: @Composable () -> Unit,
) {
    if (!enabled) {
        Box(modifier = modifier) {
            content()
        }
        return
    }

    val density = LocalDensity.current
    val thresholdPx = with(density) { 80.dp.toPx() }
    val maxPullPx = with(density) { 150.dp.toPx() }

    var pullOffsetPx by remember { mutableStateOf(0f) }

    val animatedPullOffsetPx by animateFloatAsState(
        targetValue = if (isRefreshing) thresholdPx else pullOffsetPx,
        label = "pullOffset"
    )

    val nestedScrollConnection = remember(isRefreshing) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (isRefreshing) return Offset.Zero
                // If scrolling up (available.y < 0) and we have some pull offset, consume it first
                if (available.y < 0 && pullOffsetPx > 0f) {
                    val newOffset = (pullOffsetPx + available.y).coerceAtLeast(0f)
                    val consumed = newOffset - pullOffsetPx
                    pullOffsetPx = newOffset
                    return Offset(0f, consumed)
                }
                return Offset.Zero
            }

            override fun onPostScroll(
                consumed: Offset,
                available: Offset,
                source: NestedScrollSource
            ): Offset {
                if (isRefreshing) return Offset.Zero
                // If there's unconsumed drag down (available.y > 0)
                if (available.y > 0) {
                    // Apply a resistance factor
                    val resistance = 0.5f
                    val newOffset = (pullOffsetPx + available.y * resistance).coerceAtMost(maxPullPx)
                    pullOffsetPx = newOffset
                    return Offset(0f, available.y)
                }
                return Offset.Zero
            }

            override suspend fun onPreFling(available: Velocity): Velocity {
                if (!isRefreshing && pullOffsetPx >= thresholdPx) {
                    onRefresh()
                }
                pullOffsetPx = 0f
                return Velocity.Zero
            }

            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                if (!isRefreshing && pullOffsetPx >= thresholdPx) {
                    onRefresh()
                }
                pullOffsetPx = 0f
                return Velocity.Zero
            }
        }
    }

    Box(
        modifier = modifier.nestedScroll(nestedScrollConnection)
    ) {
        Box(
            modifier = Modifier
                .offset { IntOffset(0, animatedPullOffsetPx.roundToInt()) }
        ) {
            content()
        }
        
        // Show indicator if we are pulling or refreshing
        if (animatedPullOffsetPx > 0f || isRefreshing) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = (animatedPullOffsetPx / 3f).coerceAtMost(30f).dp)
            ) {
                if (isRefreshing) {
                    CircularProgressIndicator()
                } else {
                    CircularProgressIndicator(
                        progress = { (pullOffsetPx / thresholdPx).coerceAtMost(1f) }
                    )
                }
            }
        }
    }
}
