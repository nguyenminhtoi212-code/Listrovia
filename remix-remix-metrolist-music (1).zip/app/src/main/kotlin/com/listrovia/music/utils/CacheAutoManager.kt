/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.utils

import android.content.Context
import coil3.SingletonImageLoader
import com.listrovia.music.constants.AutoClearCacheEnabledKey
import com.listrovia.music.constants.AutoClearCacheThresholdKey
import com.listrovia.music.constants.AutoClearImageCacheKey
import com.listrovia.music.constants.AutoClearNetworkCacheKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File

object CacheAutoManager {

    fun getFolderSize(file: File?): Long {
        if (file == null || !file.exists()) return 0L
        if (file.isFile) return file.length()
        var size = 0L
        file.listFiles()?.forEach { child ->
            size += getFolderSize(child)
        }
        return size
    }

    private fun clearFolder(file: File?) {
        if (file == null || !file.exists()) return
        if (file.isDirectory) {
            file.listFiles()?.forEach { child ->
                clearFolder(child)
            }
        } else if (file.isFile && !file.name.startsWith("journal")) {
            file.delete()
        }
    }

    fun getImageCacheSize(context: Context): Long {
        var size = 0L
        runCatching {
            val coilDir = File(context.cacheDir, "coil")
            size += getFolderSize(coilDir)
        }
        return size
    }

    fun getNetworkCacheSize(context: Context): Long {
        var size = 0L
        runCatching {
            val httpCacheDir = File(System.getProperty("java.io.tmpdir"), "http_cache")
            size += getFolderSize(httpCacheDir)
        }
        runCatching {
            val metrolistHttpCacheDir = File(System.getProperty("java.io.tmpdir"), "metrolist_http_cache")
            size += getFolderSize(metrolistHttpCacheDir)
        }
        runCatching {
            val appHttpCacheDir = File(context.cacheDir, "http_cache")
            size += getFolderSize(appHttpCacheDir)
        }
        runCatching {
            val appMetrolistHttpCacheDir = File(context.cacheDir, "metrolist_http_cache")
            size += getFolderSize(appMetrolistHttpCacheDir)
        }
        runCatching {
            val webViewHttpCacheDir = File(context.cacheDir, "WebView/Default/HTTP Cache")
            size += getFolderSize(webViewHttpCacheDir)
        }
        runCatching {
            val cipherCacheDir = File(context.cacheDir, "cipher")
            size += getFolderSize(cipherCacheDir)
        }
        return size
    }

    fun getTotalCacheSize(context: Context): Long {
        return getImageCacheSize(context) + getNetworkCacheSize(context)
    }

    /**
     * Checks total image & network cache against limit and automatically clears if exceeded.
     * Returns the total cleared bytes (0 if not cleared).
     */
    suspend fun checkAndAutoClearCache(context: Context, force: Boolean = false): Long = withContext(Dispatchers.IO) {
        val settings = runCatching { context.dataStore.data.first() }.getOrNull()
        val autoClearEnabled = settings?.get(AutoClearCacheEnabledKey) ?: true
        val thresholdMB = settings?.get(AutoClearCacheThresholdKey) ?: 512
        val autoClearImage = settings?.get(AutoClearImageCacheKey) ?: true
        val autoClearNetwork = settings?.get(AutoClearNetworkCacheKey) ?: true

        if (!autoClearEnabled && !force) {
            return@withContext 0L
        }

        val thresholdBytes = thresholdMB * 1024 * 1024L
        val imageSize = getImageCacheSize(context)
        val networkSize = getNetworkCacheSize(context)
        val totalCacheSize = imageSize + networkSize

        if (force || totalCacheSize > thresholdBytes) {
            Timber.d("Auto-clearing cache: total size ($totalCacheSize bytes) exceeds threshold ($thresholdBytes bytes)")
            var clearedBytes = 0L

            if (autoClearImage) {
                runCatching {
                    SingletonImageLoader.get(context).diskCache?.clear()
                }
                runCatching {
                    val coilDir = File(context.cacheDir, "coil")
                    clearFolder(coilDir)
                }
                clearedBytes += imageSize
            }

            if (autoClearNetwork) {
                val dirsToClear = listOf(
                    File(System.getProperty("java.io.tmpdir"), "http_cache"),
                    File(System.getProperty("java.io.tmpdir"), "metrolist_http_cache"),
                    File(context.cacheDir, "http_cache"),
                    File(context.cacheDir, "metrolist_http_cache"),
                    File(context.cacheDir, "WebView/Default/HTTP Cache"),
                    File(context.cacheDir, "cipher")
                )
                dirsToClear.forEach { dir ->
                    runCatching { clearFolder(dir) }
                }
                ensureWebViewCacheDirsExist(context)
                clearedBytes += networkSize
            }

            Timber.i("Cache auto-cleanup completed. Cleared estimated $clearedBytes bytes.")
            return@withContext clearedBytes
        }

        return@withContext 0L
    }
}
