/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.utils

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * Quản lý danh sách mô hình AI yêu thích (favorite/starred), kiểm duyệt an toàn (safety/moderation),
 * theo dõi mô hình đã dùng gần đây (recently used & interaction frequency),
 * và kiểm tra trạng thái phát hành (release/publication status) cho từng nhà cung cấp (OpenRouter & DeepInfra).
 */
class ModelFavoritesManager private constructor(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("model_favorites_prefs", Context.MODE_PRIVATE)

    fun getFavoriteIds(): Set<String> {
        return prefs.getStringSet(KEY_FAVS, emptySet()) ?: emptySet()
    }

    fun isFavorite(modelId: String): Boolean {
        return getFavoriteIds().contains(modelId)
    }

    fun toggleFavorite(modelId: String): Boolean {
        val current = getFavoriteIds().toMutableSet()
        val isFav = if (current.contains(modelId)) {
            current.remove(modelId)
            false
        } else {
            current.add(modelId)
            true
        }
        prefs.edit().putStringSet(KEY_FAVS, current).apply()
        return isFav
    }

    /**
     * Ghi nhận lịch sử tương tác và tần suất sử dụng của mô hình
     */
    fun recordModelUsage(modelId: String) {
        if (modelId.isBlank()) return
        val currentJson = prefs.getString(KEY_RECENTS, "[]") ?: "[]"
        try {
            val arr = JSONArray(currentJson)
            val list = mutableListOf<JSONObject>()
            var found = false
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                if (obj.getString("id") == modelId) {
                    val count = obj.optInt("count", 0) + 1
                    obj.put("count", count)
                    obj.put("timestamp", System.currentTimeMillis())
                    list.add(obj)
                    found = true
                } else {
                    list.add(obj)
                }
            }
            if (!found) {
                val newObj = JSONObject()
                newObj.put("id", modelId)
                newObj.put("count", 1)
                newObj.put("timestamp", System.currentTimeMillis())
                list.add(newObj)
            }
            list.sortWith(
                compareByDescending<JSONObject> { it.optLong("timestamp", 0L) }
                    .thenByDescending { it.optInt("count", 0) }
            )
            val newArr = JSONArray()
            list.take(15).forEach { newArr.put(it) }
            prefs.edit().putString(KEY_RECENTS, newArr.toString()).apply()
        } catch (e: Exception) {
            // Ignore format errors
        }
    }

    /**
     * Lấy danh sách ID các mô hình được tương tác gần đây nhất
     */
    fun getRecentlyUsedModelIds(limit: Int = 6): List<String> {
        val currentJson = prefs.getString(KEY_RECENTS, "[]") ?: "[]"
        return try {
            val arr = JSONArray(currentJson)
            val ids = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val id = obj.optString("id", "")
                if (id.isNotBlank()) ids.add(id)
            }
            ids.take(limit)
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * Lấy số lần tương tác của mô hình
     */
    fun getModelUsageCount(modelId: String): Int {
        val currentJson = prefs.getString(KEY_RECENTS, "[]") ?: "[]"
        return try {
            val arr = JSONArray(currentJson)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                if (obj.optString("id", "") == modelId) {
                    return obj.optInt("count", 0)
                }
            }
            0
        } catch (e: Exception) {
            0
        }
    }

    /**
     * Kiểm duyệt và nhận diện mô hình an toàn, đã phát hành chính thức.
     * Chặn toàn diện các mô hình:
     * 1. Chưa phát hành / Bản nháp (unreleased, draft, coming-soon, placeholder, internal-test).
     * 2. Đã ngừng cung cấp / Lỗi thời (deprecated, sunset, shutdown, decommissioned, discontinued).
     * 3. Bị gắn cờ vi phạm hoặc không an toàn (unsafe, harmful, jailbreak, exploit, banned, moderated).
     * 4. Phân biệt chính xác giữa các nhà cung cấp (OpenRouter vs DeepInfra).
     */
    fun isModelSafeAndPublished(
        modelId: String,
        name: String,
        description: String = "",
        provider: String = "All",
    ): Boolean {
        if (modelId.isBlank()) return false

        val lowerId = modelId.lowercase().trim()
        val lowerName = name.lowercase().trim()
        val lowerDesc = description.lowercase().trim()

        // 1. Kiểm tra từ khóa mô hình chưa phát hành / bản thử nghiệm nội bộ
        val unreleasedKeywords = listOf(
            "unreleased",
            "coming-soon",
            "coming_soon",
            "draft-model",
            "placeholder",
            "internal-test",
            "internal_test",
            "mock-model",
            "dummy-model",
            "pre-alpha",
        )
        if (unreleasedKeywords.any { lowerId.contains(it) || lowerName.contains(it) }) {
            return false
        }

        // 2. Kiểm tra từ khóa mô hình đã ngừng hỗ trợ hoặc đóng dịch vụ
        val deprecatedKeywords = listOf(
            "deprecated",
            "sunset",
            "shutdown",
            "decommissioned",
            "discontinued",
            "outdated-v0",
            "legacy-eol",
        )
        if (deprecatedKeywords.any { lowerId.contains(it) || lowerName.contains(it) }) {
            return false
        }

        // 3. Kiểm duyệt nội dung không an toàn, vi phạm hoặc độc hại
        val unsafeKeywords = listOf(
            "unsafe",
            "harmful",
            "jailbreak",
            "exploit",
            "malicious",
            "banned",
            "blacklisted",
            "flagged-abuse",
        )
        if (unsafeKeywords.any { lowerId.contains(it) || lowerName.contains(it) || lowerDesc.contains(it) }) {
            return false
        }

        // 4. Kiểm tra quy tắc định dạng theo từng nhà cung cấp
        when (provider.lowercase()) {
            "openrouter" -> {
                // OpenRouter models chuẩn thường có định dạng "vendor/model-name"
                if (!lowerId.contains("/")) return false
                if (lowerId.startsWith("openrouter/auto-test")) return false
            }
            "deepinfra" -> {
                // DeepInfra models chuẩn có cấu trúc "vendor/model-name"
                if (!lowerId.contains("/")) return false
            }
        }

        return true
    }

    companion object {
        private const val KEY_FAVS = "favorite_model_ids"
        private const val KEY_RECENTS = "recently_used_models_json"

        @Volatile
        private var instance: ModelFavoritesManager? = null

        fun getInstance(context: Context): ModelFavoritesManager {
            return instance ?: synchronized(this) {
                instance ?: ModelFavoritesManager(context).also { instance = it }
            }
        }
    }
}
