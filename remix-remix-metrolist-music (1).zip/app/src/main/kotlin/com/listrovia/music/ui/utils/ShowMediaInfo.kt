/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.utils

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.text.format.Formatter
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLocale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.listrovia.innertube.YouTube
import com.listrovia.innertube.MediaInfo
import com.listrovia.music.LocalDatabase
import com.listrovia.music.LocalPlayerConnection
import com.listrovia.music.R
import com.listrovia.music.constants.LoudnessLevel
import com.listrovia.music.constants.LoudnessLevelKey
import com.listrovia.music.db.entities.FormatEntity
import com.listrovia.music.db.entities.Song
import com.listrovia.music.lyrics.LyricsTranslationHelper
import com.listrovia.music.ui.component.Material3SettingsGroup
import com.listrovia.music.ui.component.Material3SettingsItem
import com.listrovia.music.ui.component.shimmer.ShimmerHost
import com.listrovia.music.ui.component.shimmer.TextPlaceholder
import com.listrovia.music.utils.cipher.CipherDeobfuscator
import com.listrovia.music.utils.cipher.PlayerDatesStore
import com.listrovia.music.utils.rememberEnumPreference
import kotlinx.coroutines.launch

@Composable
fun getLoudnessLevelLabel(loudnessLevel: LoudnessLevel): String {
    return when (loudnessLevel) {
        LoudnessLevel.AGGRESSIVE -> stringResource(R.string.loudness_level_aggressive)
        LoudnessLevel.LOUD -> stringResource(R.string.loudness_level_loud)
        LoudnessLevel.BALANCED -> stringResource(R.string.loudness_level_balanced)
        LoudnessLevel.QUIET -> stringResource(R.string.loudness_level_quiet)
    }
}

@Composable
private fun createSettingsItem(
    label: String,
    value: String?,
    iconRes: Int? = null
): Material3SettingsItem {
    val unknown = stringResource(R.string.unknown)
    val displayText = value?.ifBlank { null } ?: unknown
    return Material3SettingsItem(
        title = { Text(label) },
        description = { Text(displayText) },
        icon = iconRes?.let { painterResource(it) },
        onClick = null
    )
}

@Composable
private fun AudioTechnicalTile(
    label: String,
    value: String,
    iconRes: Int,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Icon(
                    painter = painterResource(iconRes),
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.5.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * Thẻ hiển thị mô tả bài hát với công cụ dịch song ngữ Tiếng Việt & Tiếng Anh.
 * Khôi phục khả năng xem mô tả bài hát chi tiết, chống vỡ giao diện và hỗ trợ dịch tức thì.
 */
@Composable
private fun SongDescriptionCard(
    description: String?,
    songTitle: String,
    artistName: String,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var selectedLang by remember { mutableStateOf("original") } // "original", "vi", "en"
    var translatedVi by remember { mutableStateOf<String?>(null) }
    var translatedEn by remember { mutableStateOf<String?>(null) }
    var isTranslating by remember { mutableStateOf(false) }
    var isExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainer
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        painter = painterResource(R.drawable.info),
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp),
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.media_info_song_desc_title),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        text = stringResource(R.string.media_info_song_desc_subtitle),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (description.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = stringResource(R.string.media_info_no_desc),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                        modifier = Modifier.padding(14.dp),
                        textAlign = TextAlign.Center,
                    )
                }
            } else {
                // Translation & Language Selection Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    FilterChip(
                        selected = selectedLang == "original",
                        onClick = { selectedLang = "original" },
                        label = { Text(stringResource(R.string.media_info_lang_original), style = MaterialTheme.typography.labelSmall) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        )
                    )

                    FilterChip(
                        selected = selectedLang == "vi",
                        onClick = {
                            selectedLang = "vi"
                            if (translatedVi == null && !isTranslating) {
                                coroutineScope.launch {
                                    isTranslating = true
                                    try {
                                        val res = LyricsTranslationHelper.translateWithGoogleFree(description, "vi")
                                        res.onSuccess { lines ->
                                            translatedVi = lines.joinToString("\n")
                                        }.onFailure { err ->
                                            Toast.makeText(context, err.message ?: "Translation error", Toast.LENGTH_SHORT).show()
                                        }
                                    } catch (e: Exception) {
                                        Toast.makeText(context, e.message ?: "Translation error", Toast.LENGTH_SHORT).show()
                                    } finally {
                                        isTranslating = false
                                    }
                                }
                            }
                        },
                        label = { Text(stringResource(R.string.media_info_lang_vi), style = MaterialTheme.typography.labelSmall) },
                        leadingIcon = if (isTranslating && selectedLang == "vi") {
                            {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(12.dp),
                                    strokeWidth = 1.5.dp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        } else null,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        )
                    )

                    FilterChip(
                        selected = selectedLang == "en",
                        onClick = {
                            selectedLang = "en"
                            if (translatedEn == null && !isTranslating) {
                                coroutineScope.launch {
                                    isTranslating = true
                                    try {
                                        val res = LyricsTranslationHelper.translateWithGoogleFree(description, "en")
                                        res.onSuccess { lines ->
                                            translatedEn = lines.joinToString("\n")
                                        }.onFailure { err ->
                                            Toast.makeText(context, err.message ?: "Translation error", Toast.LENGTH_SHORT).show()
                                        }
                                    } catch (e: Exception) {
                                        Toast.makeText(context, e.message ?: "Translation error", Toast.LENGTH_SHORT).show()
                                    } finally {
                                        isTranslating = false
                                    }
                                }
                            }
                        },
                        label = { Text(stringResource(R.string.media_info_lang_en), style = MaterialTheme.typography.labelSmall) },
                        leadingIcon = if (isTranslating && selectedLang == "en") {
                            {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(12.dp),
                                    strokeWidth = 1.5.dp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        } else null,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                val currentContent = when (selectedLang) {
                    "vi" -> translatedVi ?: if (isTranslating) stringResource(R.string.media_info_translating) else description
                    "en" -> translatedEn ?: if (isTranslating) stringResource(R.string.media_info_translating) else description
                    else -> description
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                    ) {
                        Text(
                            text = currentContent,
                            style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 20.sp),
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = if (isExpanded) Int.MAX_VALUE else 5,
                            overflow = TextOverflow.Ellipsis,
                        )

                        if (currentContent.lines().size > 5 || currentContent.length > 200) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable { isExpanded = !isExpanded }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                            ) {
                                Text(
                                    text = if (isExpanded) stringResource(R.string.media_info_show_less) else stringResource(R.string.media_info_show_more),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold,
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    painter = painterResource(if (isExpanded) R.drawable.expand_less else R.drawable.expand_more),
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp),
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Song Description", currentContent))
                        Toast.makeText(context, context.getString(R.string.media_info_desc_copied), Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        painter = painterResource(R.drawable.content_copy),
                        contentDescription = null,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.media_info_copy_desc),
                        style = MaterialTheme.typography.labelMedium,
                    )
                }
            }
        }
    }
}

@Composable
fun ShowMediaInfo(videoId: String) {
    if (videoId.isBlank()) return

    var info by remember { mutableStateOf<MediaInfo?>(null) }
    var isLoading by remember { mutableStateOf(true) }

    val database = LocalDatabase.current
    var song by remember { mutableStateOf<Song?>(null) }
    var currentFormat by remember { mutableStateOf<FormatEntity?>(null) }

    val playerConnection = LocalPlayerConnection.current
    val currentStreamClient by playerConnection?.currentStreamClient?.collectAsState() ?: remember { mutableStateOf(null) }
    val context = LocalContext.current

    val loudnessLevel by rememberEnumPreference(
        LoudnessLevelKey,
        defaultValue = LoudnessLevel.BALANCED
    )

    val targetLufs: Float = loudnessLevel.targetLufs

    LaunchedEffect(videoId) {
        isLoading = true
        info = YouTube.getMediaInfo(videoId).getOrNull()
        isLoading = false
    }

    LaunchedEffect(videoId) {
        database.song(videoId).collect {
            song = it
        }
    }

    LaunchedEffect(videoId) {
        database.format(videoId).collect {
            currentFormat = it
        }
    }

    val effectiveFormat = currentFormat ?: song?.format
    val hasData = info != null || song != null || effectiveFormat != null

    LazyColumn(
        state = rememberLazyListState(),
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding(),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        if (isLoading && !hasData) {
            item(contentType = "MediaInfoLoader") {
                ShimmerHost {
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(all = 16.dp)
                    ) {
                        TextPlaceholder()
                    }
                }
            }
        } else {
            item(contentType = "TechnicalAudioHero") {
                val title = info?.title ?: song?.title ?: stringResource(R.string.media_info_playing_track)
                val artist = info?.author ?: song?.artists?.joinToString { it.name }?.ifBlank { null } ?: stringResource(R.string.media_info_unknown_artist)
                val bitrateKbps = effectiveFormat?.bitrate?.let { it / 1000 }
                val sampleRateHz = effectiveFormat?.sampleRate
                val sampleRateKHz = sampleRateHz?.let { String.format(LocalLocale.current.platformLocale, "%.1f kHz", it / 1000f) }
                val mimeType = effectiveFormat?.mimeType
                val codecs = effectiveFormat?.codecs
                val fileSize = effectiveFormat?.contentLength?.let { Formatter.formatShortFileSize(context, it) }
                val measuredLufs: Double? = effectiveFormat?.perceptualLoudnessDb
                    ?: effectiveFormat?.loudnessDb?.let { it + LoudnessLevel.AGGRESSIVE.targetLufs }
                val loudnessStr = measuredLufs?.let { String.format(LocalLocale.current.platformLocale, "%.1f dB", it - targetLufs) }

                // Audio Format derived pill label
                val formatLabel = remember(mimeType, codecs) {
                    when {
                        codecs?.contains("flac", ignoreCase = true) == true || mimeType?.contains("flac", ignoreCase = true) == true -> "FLAC Lossless"
                        codecs?.contains("opus", ignoreCase = true) == true || mimeType?.contains("webm", ignoreCase = true) == true -> "WebM (Opus)"
                        codecs?.contains("mp4a", ignoreCase = true) == true || mimeType?.contains("mp4", ignoreCase = true) == true || mimeType?.contains("m4a", ignoreCase = true) == true -> "M4A (AAC)"
                        mimeType?.contains("mpeg", ignoreCase = true) == true -> "MP3"
                        !codecs.isNullOrBlank() -> codecs
                        !mimeType.isNullOrBlank() -> mimeType.removePrefix("audio/")
                        else -> "Audio Stream"
                    }
                }

                // Audio Quality Badge logic
                val isLossless = (bitrateKbps ?: 0) >= 900 || codecs?.contains("flac", ignoreCase = true) == true
                val isHighQuality = (bitrateKbps ?: 0) >= 250

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainer
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                    ) {
                        // Header row with Badge & Icon
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(
                                            Brush.linearGradient(
                                                colors = if (isLossless) listOf(Color(0xFFFFD700), Color(0xFFFFA000))
                                                else if (isHighQuality) listOf(Color(0xFF00E5FF), Color(0xFF0088FF))
                                                else listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.tertiary)
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        painter = painterResource(R.drawable.equalizer),
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Column {
                                    Text(
                                        text = stringResource(R.string.media_info_title),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = stringResource(R.string.media_info_subtitle),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            // Quality Badge Pill
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = if (isLossless) Color(0xFFFFD700).copy(alpha = 0.2f)
                                else if (isHighQuality) Color(0xFF00E5FF).copy(alpha = 0.2f)
                                else MaterialTheme.colorScheme.primaryContainer,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isLossless) Color(0xFFFFD700)
                                    else if (isHighQuality) Color(0xFF00E5FF)
                                    else MaterialTheme.colorScheme.primary
                                )
                            ) {
                                Text(
                                    text = if (isLossless) stringResource(R.string.media_info_quality_lossless)
                                    else if (isHighQuality) stringResource(R.string.media_info_quality_high)
                                    else stringResource(R.string.media_info_quality_standard),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (isLossless) Color(0xFFFFD700)
                                    else if (isHighQuality) Color(0xFF00E5FF)
                                    else MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Currently playing track title preview
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceContainerLow)
                                .padding(10.dp)
                        ) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = artist,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Technical Grid (2x3 tiles)
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                AudioTechnicalTile(
                                    label = stringResource(R.string.bitrate),
                                    value = bitrateKbps?.let { "$it Kbps" } ?: "N/A",
                                    iconRes = R.drawable.gradient,
                                    modifier = Modifier.weight(1f)
                                )
                                AudioTechnicalTile(
                                    label = stringResource(R.string.sample_rate),
                                    value = sampleRateKHz ?: sampleRateHz?.let { "$it Hz" } ?: "N/A",
                                    iconRes = R.drawable.contrast,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                AudioTechnicalTile(
                                    label = stringResource(R.string.media_info_audio_format),
                                    value = formatLabel,
                                    iconRes = R.drawable.radio,
                                    modifier = Modifier.weight(1f)
                                )
                                AudioTechnicalTile(
                                    label = stringResource(R.string.codecs),
                                    value = codecs ?: "Default",
                                    iconRes = R.drawable.info,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                AudioTechnicalTile(
                                    label = stringResource(R.string.loudness),
                                    value = loudnessStr ?: "N/A",
                                    iconRes = R.drawable.volume_up,
                                    modifier = Modifier.weight(1f)
                                )
                                AudioTechnicalTile(
                                    label = stringResource(R.string.file_size),
                                    value = fileSize ?: "N/A",
                                    iconRes = R.drawable.content_copy,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Copy Specs Button
                        OutlinedButton(
                            onClick = {
                                val specsText = buildString {
                                    appendLine("🎵 Track: $title - $artist")
                                    appendLine("🔊 Audio Quality: ${if (isLossless) "Lossless" else if (isHighQuality) "High Quality" else "Standard"}")
                                    appendLine("📻 Format: $formatLabel (${mimeType ?: "N/A"})")
                                    appendLine("⚙️ Codec: ${codecs ?: "N/A"}")
                                    appendLine("⚡ Bitrate: ${bitrateKbps?.let { "$it Kbps" } ?: "N/A"}")
                                    appendLine("🎚️ Sample Rate: ${sampleRateKHz ?: sampleRateHz?.let { "$it Hz" } ?: "N/A"}")
                                    appendLine("📊 Loudness: ${loudnessStr ?: "N/A"}")
                                    appendLine("📁 File Size: ${fileSize ?: "N/A"}")
                                    appendLine("🔑 Media ID: $videoId")
                                }
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Technical Audio Metadata", specsText))
                                Toast.makeText(context, context.getString(R.string.media_info_specs_copied), Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.content_copy),
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = stringResource(R.string.media_info_copy_specs))
                        }
                    }
                }
            }

            // Dedicated Song Description Card with Translation
            item(contentType = "SongDescription") {
                val currentTitle = info?.title ?: song?.title ?: ""
                val currentArtist = info?.author ?: song?.artists?.joinToString { it.name } ?: ""
                SongDescriptionCard(
                    description = info?.description,
                    songTitle = currentTitle,
                    artistName = currentArtist,
                )
            }

            item(contentType = "MediaDetails") {
                Column {
                    val notApplicable = stringResource(R.string.not_applicable)
                    val unknown = stringResource(R.string.unknown)

                    // Base list (General)
                    val baseItems = mutableListOf<Material3SettingsItem>()
                    baseItems += createSettingsItem(
                        stringResource(R.string.song_title),
                        info?.title ?: song?.title,
                        R.drawable.music_note
                    )
                    baseItems += createSettingsItem(
                        stringResource(R.string.song_artists),
                        info?.author ?: song?.artists?.joinToString { it.name }?.ifBlank { null },
                        R.drawable.person
                    )
                    val albumTitle = song?.album?.title ?: song?.song?.albumName
                    if (!albumTitle.isNullOrBlank()) {
                        baseItems += createSettingsItem(
                            stringResource(R.string.view_album),
                            albumTitle,
                            R.drawable.media3_icon_bookmark_filled
                        )
                    }
                    baseItems += createSettingsItem(
                        stringResource(R.string.media_id),
                        song?.id ?: info?.videoId ?: videoId,
                        R.drawable.key_vertical
                    )
                    val durationSec = song?.song?.duration ?: -1
                    if (durationSec > 0) {
                        baseItems += createSettingsItem(
                            stringResource(R.string.history_duration),
                            String.format("%d:%02d", durationSec / 60, durationSec % 60),
                            R.drawable.play
                        )
                    }

                    Material3SettingsGroup(
                        title = stringResource(R.string.general),
                        items = baseItems
                    )

                    Spacer(Modifier.height(8.dp))

                    // Extended list (Information)
                    val isWebStream = currentStreamClient in setOf("WEB_REMIX", "WEB_CREATOR", "TVHTML5", "WEB")
                    val playerHash = if (isWebStream) CipherDeobfuscator.lastUsedPlayerHash else null
                    val measuredLufs: Double? = effectiveFormat?.perceptualLoudnessDb
                        ?: effectiveFormat?.loudnessDb?.let { it + LoudnessLevel.AGGRESSIVE.targetLufs }

                    val extendedItems = mutableListOf<Material3SettingsItem>()

                    if (info?.viewCount != null) {
                        extendedItems += createSettingsItem(
                            stringResource(R.string.views),
                            numberFormatter(info!!.viewCount!!),
                            R.drawable.media3_icon_feed
                        )
                    }
                    if (info?.like != null) {
                        extendedItems += createSettingsItem(
                            stringResource(R.string.likes),
                            numberFormatter(info!!.like!!),
                            R.drawable.media3_icon_thumb_up_unfilled
                        )
                    }
                    if (info?.dislike != null) {
                        extendedItems += createSettingsItem(
                            stringResource(R.string.dislikes),
                            numberFormatter(info!!.dislike!!),
                            R.drawable.media3_icon_thumb_down_unfilled
                        )
                    }
                    if (!info?.uploadDate.isNullOrBlank()) {
                        extendedItems += createSettingsItem(
                            stringResource(R.string.sort_by_create_date),
                            info?.uploadDate,
                            R.drawable.info
                        )
                    }

                    if (effectiveFormat != null) {
                        if (effectiveFormat.itag != null) {
                            extendedItems += createSettingsItem("Itag", effectiveFormat.itag.toString(), R.drawable.key)
                        }
                    }

                    if (!currentStreamClient.isNullOrBlank()) {
                        extendedItems += createSettingsItem(
                            stringResource(R.string.stream_client),
                            currentStreamClient,
                            R.drawable.play
                        )
                    }

                    extendedItems += createSettingsItem(
                        stringResource(R.string.format_player_hash),
                        if (isWebStream) playerHash else notApplicable,
                        R.drawable.lock
                    )

                    extendedItems += createSettingsItem(
                        stringResource(R.string.format_cipher_support_added),
                        if (isWebStream) PlayerDatesStore.get(playerHash) else notApplicable,
                        R.drawable.key_vertical
                    )

                    if (effectiveFormat != null) {
                        if (!effectiveFormat.mimeType.isNullOrBlank()) {
                            extendedItems += createSettingsItem(
                                stringResource(R.string.mime_type),
                                effectiveFormat.mimeType,
                                R.drawable.info
                            )
                        }
                        if (!effectiveFormat.codecs.isNullOrBlank()) {
                            extendedItems += createSettingsItem(
                                stringResource(R.string.codecs),
                                effectiveFormat.codecs,
                                R.drawable.radio
                            )
                        }
                        if (effectiveFormat.bitrate != null) {
                            extendedItems += createSettingsItem(
                                stringResource(R.string.bitrate),
                                "${effectiveFormat.bitrate / 1000} Kbps",
                                R.drawable.gradient
                            )
                        }
                        if (effectiveFormat.sampleRate != null) {
                            extendedItems += createSettingsItem(
                                stringResource(R.string.sample_rate),
                                "${effectiveFormat.sampleRate} Hz",
                                R.drawable.contrast
                            )
                        }
                    }

                    if (measuredLufs != null) {
                        extendedItems += createSettingsItem(
                            stringResource(R.string.loudness),
                            String.format(LocalLocale.current.platformLocale, "%.2f dB", measuredLufs - targetLufs),
                            R.drawable.volume_up
                        )
                    }

                    extendedItems += createSettingsItem(
                        stringResource(R.string.loudness_level),
                        getLoudnessLevelLabel(loudnessLevel),
                        R.drawable.volume_up
                    )

                    if (playerConnection != null) {
                        val vol = playerConnection.getPlayerOrNull()?.volume ?: 1f
                        extendedItems += createSettingsItem(
                            stringResource(R.string.volume),
                            "${(vol * 100).toInt()}%",
                            R.drawable.volume_mute
                        )
                    }

                    if (effectiveFormat?.contentLength != null) {
                        extendedItems += createSettingsItem(
                            stringResource(R.string.file_size),
                            Formatter.formatShortFileSize(context, effectiveFormat.contentLength),
                            R.drawable.content_copy
                        )
                    }

                    if (extendedItems.isNotEmpty()) {
                        Material3SettingsGroup(
                            title = stringResource(R.string.information),
                            items = extendedItems
                        )
                    }
                }
            }
        }
    }
}
