/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.utils

import android.content.Context
import android.os.Bundle
import com.google.firebase.analytics.FirebaseAnalytics
import com.listrovia.music.BuildConfig
import timber.log.Timber

/**
 * Helper to log Firebase Analytics events for app update checks and new version detections.
 */
object UpdaterAnalytics {
    private const val EVENT_CHECK_UPDATE = "updater_check"
    private const val EVENT_NEW_VERSION_DETECTED = "updater_new_version_detected"
    private const val EVENT_UPDATE_DOWNLOAD_CLICK = "updater_download_click"

    private const val PARAM_SOURCE = "source"
    private const val PARAM_SUCCESS = "success"
    private const val PARAM_CURRENT_VERSION = "current_version"
    private const val PARAM_LATEST_VERSION = "latest_version"
    private const val PARAM_VERSION_TAG = "version_tag"
    private const val PARAM_IS_UPDATE_AVAILABLE = "is_update_available"
    private const val PARAM_ERROR_MESSAGE = "error_message"
    private const val PARAM_ARCHITECTURE = "architecture"
    private const val PARAM_VARIANT = "variant"
    private const val PARAM_DOWNLOAD_URL = "download_url"

    private fun getFirebaseAnalytics(context: Context?): FirebaseAnalytics? {
        if (context == null) return null
        return runCatching {
            FirebaseAnalytics.getInstance(context.applicationContext)
        }.getOrNull()
    }

    /**
     * Tracks when an update check is performed (success or failure).
     */
    fun logUpdateCheck(
        context: Context?,
        source: String,
        success: Boolean,
        hasUpdate: Boolean = false,
        latestVersion: String? = null,
        errorMessage: String? = null
    ) {
        if (context == null) return
        runCatching {
            val analytics = getFirebaseAnalytics(context) ?: return
            val bundle = Bundle().apply {
                putString(PARAM_SOURCE, source)
                putBoolean(PARAM_SUCCESS, success)
                putString(PARAM_CURRENT_VERSION, BuildConfig.VERSION_NAME)
                putBoolean(PARAM_IS_UPDATE_AVAILABLE, hasUpdate)
                if (!latestVersion.isNullOrBlank()) {
                    putString(PARAM_LATEST_VERSION, latestVersion)
                }
                if (!errorMessage.isNullOrBlank()) {
                    putString(PARAM_ERROR_MESSAGE, errorMessage.take(100))
                }
            }
            analytics.logEvent(EVENT_CHECK_UPDATE, bundle)
            Timber.d("UpdaterAnalytics: Logged $EVENT_CHECK_UPDATE (source=$source, success=$success, hasUpdate=$hasUpdate, latest=$latestVersion)")
        }.onFailure {
            Timber.w(it, "UpdaterAnalytics: Failed to log $EVENT_CHECK_UPDATE")
        }
    }

    /**
     * Tracks when a new app version is detected.
     */
    fun logNewVersionDetected(
        context: Context?,
        latestVersion: String,
        source: String,
        versionTag: String? = null
    ) {
        if (context == null) return
        runCatching {
            val analytics = getFirebaseAnalytics(context) ?: return
            val bundle = Bundle().apply {
                putString(PARAM_CURRENT_VERSION, BuildConfig.VERSION_NAME)
                putString(PARAM_LATEST_VERSION, latestVersion)
                if (!versionTag.isNullOrBlank()) {
                    putString(PARAM_VERSION_TAG, versionTag)
                }
                putString(PARAM_SOURCE, source)
                putString(PARAM_ARCHITECTURE, BuildConfig.ARCHITECTURE)
                putString(PARAM_VARIANT, if (BuildConfig.CAST_AVAILABLE) "gms" else "foss")
            }
            analytics.logEvent(EVENT_NEW_VERSION_DETECTED, bundle)
            Timber.d("UpdaterAnalytics: Logged $EVENT_NEW_VERSION_DETECTED (latest=$latestVersion, source=$source)")
        }.onFailure {
            Timber.w(it, "UpdaterAnalytics: Failed to log $EVENT_NEW_VERSION_DETECTED")
        }
    }

    /**
     * Tracks when a user clicks on an update download action or link.
     */
    fun logUpdateAction(
        context: Context?,
        version: String,
        downloadUrl: String? = null
    ) {
        if (context == null) return
        runCatching {
            val analytics = getFirebaseAnalytics(context) ?: return
            val bundle = Bundle().apply {
                putString(PARAM_LATEST_VERSION, version)
                if (!downloadUrl.isNullOrBlank()) {
                    putString(PARAM_DOWNLOAD_URL, downloadUrl)
                }
                putString(PARAM_VARIANT, if (BuildConfig.CAST_AVAILABLE) "gms" else "foss")
            }
            analytics.logEvent(EVENT_UPDATE_DOWNLOAD_CLICK, bundle)
            Timber.d("UpdaterAnalytics: Logged $EVENT_UPDATE_DOWNLOAD_CLICK (version=$version)")
        }.onFailure {
            Timber.w(it, "UpdaterAnalytics: Failed to log $EVENT_UPDATE_DOWNLOAD_CLICK")
        }
    }
}
