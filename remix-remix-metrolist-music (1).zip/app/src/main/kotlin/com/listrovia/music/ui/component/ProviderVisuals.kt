/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.component

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.listrovia.music.R

data class ProviderVisualInfo(
    val name: String,
    val brandColor: Color,
    val accentColor: Color,
    val iconRes: Int? = null,
    val shortTag: String,
    val monogram: String,
)

data class ProviderDetailedSpec(
    val visual: ProviderVisualInfo,
    val officialTitle: String,
    val categoryLabelVi: String,
    val categoryLabelEn: String,
    val specialtyVi: String,
    val specialtyEn: String,
    val protocolLabel: String,
    val authPolicyVi: String,
    val authPolicyEn: String,
    val portalUrl: String,
    val portalDomain: String,
    val supportedFeaturesVi: List<String>,
    val supportedFeaturesEn: List<String>,
)

enum class ModelSourceCategory(val labelRes: Int) {
    ALL(R.string.ai_source_filter_all),
    VERIFIED(R.string.ai_source_filter_verified),
    COMMUNITY(R.string.ai_source_filter_community),
    DEVELOPER(R.string.ai_source_filter_developer),
}

enum class ModelHealthStatus(
    val labelRes: Int,
    val textColor: Color,
    val backgroundColor: Color,
    val borderColor: Color,
) {
    STABLE(
        labelRes = R.string.ai_badge_stable,
        textColor = Color(0xFF2E7D32),
        backgroundColor = Color(0xFFE8F5E9),
        borderColor = Color(0xFF81C784),
    ),
    BETA(
        labelRes = R.string.ai_badge_beta,
        textColor = Color(0xFF1976D2),
        backgroundColor = Color(0xFFE3F2FD),
        borderColor = Color(0xFF90CAF9),
    ),
    PENDING(
        labelRes = R.string.ai_badge_pending,
        textColor = Color(0xFF7B1FA2),
        backgroundColor = Color(0xFFF3E5F5),
        borderColor = Color(0xFFCE93D8),
    ),
    DEVELOPER(
        labelRes = R.string.ai_badge_developer,
        textColor = Color(0xFFE65100),
        backgroundColor = Color(0xFFFFF3E0),
        borderColor = Color(0xFFFFB74D),
    ),
}

enum class ModelServiceHealth(
    val labelRes: Int,
    val indicatorColor: Color,
    val backgroundColor: Color,
    val borderColor: Color,
) {
    ONLINE(
        labelRes = R.string.ai_health_online,
        indicatorColor = Color(0xFF2E7D32),
        backgroundColor = Color(0xFFE8F5E9),
        borderColor = Color(0xFFA5D6A7),
    ),
    HIGH_LATENCY(
        labelRes = R.string.ai_health_high_latency,
        indicatorColor = Color(0xFFE65100),
        backgroundColor = Color(0xFFFFF3E0),
        borderColor = Color(0xFFFFCC80),
    ),
    FAST(
        labelRes = R.string.ai_health_fast,
        indicatorColor = Color(0xFF00838F),
        backgroundColor = Color(0xFFE0F7FA),
        borderColor = Color(0xFF80DEEA),
    ),
}

fun getModelServiceHealth(
    modelId: String,
    name: String = "",
    contextLength: Long = 0L,
): ModelServiceHealth {
    val idLower = modelId.lowercase().trim()
    val nameLower = name.lowercase().trim()

    // 1. Fast models
    if (idLower.contains("flash") || idLower.contains("turbo") ||
        idLower.contains("instant") || idLower.contains("speed") ||
        idLower.contains("mini") || idLower.contains("8b") ||
        idLower.contains("small")) {
        return ModelServiceHealth.FAST
    }

    // 2. High latency models: large context (>131k), reasoning models, deep thinking (>70B)
    if (contextLength >= 131072L || idLower.contains("r1") || idLower.contains("reasoner") ||
        idLower.contains("thinking") || idLower.contains("o1") || idLower.contains("o3") ||
        nameLower.contains("reasoning") || idLower.contains("70b") || idLower.contains("405b") ||
        idLower.contains("deepseek-r1")) {
        return ModelServiceHealth.HIGH_LATENCY
    }

    // 3. Default active online status
    return ModelServiceHealth.ONLINE
}

fun getModelSourceCategory(modelId: String, providerName: String = ""): ModelSourceCategory {
    val idLower = modelId.lowercase().trim()
    val pLower = providerName.lowercase().trim()

    // 1. Developer / Bleeding-edge models
    if (idLower.contains("dev") || idLower.contains("developer") ||
        idLower.contains("preview") || idLower.contains("alpha") ||
        idLower.contains("exp-") || idLower.contains("experimental") ||
        idLower.contains("test") || idLower.contains("instruct-dev")) {
        return ModelSourceCategory.DEVELOPER
    }

    // 2. Verified Major Providers
    val verifiedVendors = listOf(
        "google", "openai", "anthropic", "meta", "meta-llama", "deepseek",
        "mistral", "mistralai", "qwen", "alibaba", "nvidia", "microsoft",
        "x-ai", "xai", "cohere", "perplexity", "amazon", "openrouter", "deepinfra", "groq", "deepl", "huggingface"
    )
    val vendor = if (idLower.contains("/")) idLower.substringBefore("/") else pLower
    if (verifiedVendors.contains(vendor) || verifiedVendors.contains(pLower)) {
        return ModelSourceCategory.VERIFIED
    }

    // 3. Otherwise Community / Partner Models
    return ModelSourceCategory.COMMUNITY
}

fun getModelHealthStatus(modelId: String, name: String = ""): ModelHealthStatus {
    val idLower = modelId.lowercase().trim()
    val nameLower = name.lowercase().trim()

    return when {
        idLower.contains("dev") || idLower.contains("developer") || idLower.contains("preview") || idLower.contains("alpha") -> {
            ModelHealthStatus.DEVELOPER
        }
        idLower.contains("beta") || idLower.contains("free") || idLower.contains("exp") || nameLower.contains("beta") -> {
            ModelHealthStatus.BETA
        }
        idLower.contains("pending") || idLower.contains("rc") || idLower.contains("eval") -> {
            ModelHealthStatus.PENDING
        }
        else -> {
            ModelHealthStatus.STABLE
        }
    }
}

fun getProviderVisualInfo(modelId: String, providerName: String = ""): ProviderVisualInfo {
    val idLower = modelId.lowercase().trim()
    val pLower = providerName.lowercase().trim()

    return when {
        idLower == "openrouter" || pLower == "openrouter" -> {
            ProviderVisualInfo(
                name = "OpenRouter",
                brandColor = Color(0xFF6366F1),
                accentColor = Color(0xFF4F46E5),
                iconRes = R.drawable.cloud,
                shortTag = "OpenRouter",
                monogram = "OR",
            )
        }
        idLower == "deepinfra" || pLower == "deepinfra" -> {
            ProviderVisualInfo(
                name = "DeepInfra",
                brandColor = Color(0xFF0EA5E9),
                accentColor = Color(0xFF0284C7),
                iconRes = R.drawable.discover_tune,
                shortTag = "DeepInfra",
                monogram = "DI",
            )
        }
        idLower == "groq" || pLower == "groq" || idLower.startsWith("groq/") -> {
            ProviderVisualInfo(
                name = "Groq",
                brandColor = Color(0xFFF97316),
                accentColor = Color(0xFFEA580C),
                iconRes = R.drawable.sync,
                shortTag = "Groq",
                monogram = "GQ",
            )
        }
        idLower == "deepl" || pLower == "deepl" -> {
            ProviderVisualInfo(
                name = "DeepL",
                brandColor = Color(0xFF0F2B46),
                accentColor = Color(0xFF006494),
                iconRes = R.drawable.translate,
                shortTag = "DeepL",
                monogram = "DL",
            )
        }
        idLower.startsWith("google/") || idLower.contains("gemini") || idLower.contains("gemma") || pLower == "google" || pLower == "gemini" -> {
            ProviderVisualInfo(
                name = "Google",
                brandColor = Color(0xFF4285F4),
                accentColor = Color(0xFF34A853),
                iconRes = R.drawable.google,
                shortTag = "Google",
                monogram = "G",
            )
        }
        idLower.startsWith("openai/") || idLower.contains("gpt-") || idLower.contains("o1-") || idLower.contains("o3-") || idLower.contains("o4-") || pLower == "openai" -> {
            ProviderVisualInfo(
                name = "OpenAI",
                brandColor = Color(0xFF10A37F),
                accentColor = Color(0xFF007A5E),
                iconRes = R.drawable.discover_tune,
                shortTag = "OpenAI",
                monogram = "OA",
            )
        }
        idLower.startsWith("deepseek") || idLower.contains("deepseek") || pLower.contains("deepseek") -> {
            ProviderVisualInfo(
                name = "DeepSeek",
                brandColor = Color(0xFF1E88E5),
                accentColor = Color(0xFF0D47A1),
                iconRes = R.drawable.star,
                shortTag = "DeepSeek",
                monogram = "DS",
            )
        }
        idLower.startsWith("anthropic/") || idLower.contains("claude") || pLower == "anthropic" || pLower == "claude" -> {
            ProviderVisualInfo(
                name = "Anthropic",
                brandColor = Color(0xFFD97706),
                accentColor = Color(0xFFB45309),
                iconRes = R.drawable.token,
                shortTag = "Anthropic",
                monogram = "CL",
            )
        }
        idLower.startsWith("meta-llama/") || idLower.startsWith("meta/") || idLower.contains("llama") || pLower.contains("meta") -> {
            ProviderVisualInfo(
                name = "Meta",
                brandColor = Color(0xFF0668E1),
                accentColor = Color(0xFF04489B),
                iconRes = R.drawable.integration,
                shortTag = "Meta",
                monogram = "L",
            )
        }
        idLower.startsWith("mistralai/") || idLower.contains("mistral") || idLower.contains("codestral") || pLower.contains("mistral") -> {
            ProviderVisualInfo(
                name = "Mistral AI",
                brandColor = Color(0xFFFF5722),
                accentColor = Color(0xFFE64A19),
                iconRes = R.drawable.tune,
                shortTag = "Mistral",
                monogram = "M",
            )
        }
        idLower.startsWith("qwen/") || idLower.contains("qwen") || pLower.contains("qwen") || pLower.contains("alibaba") -> {
            ProviderVisualInfo(
                name = "Qwen",
                brandColor = Color(0xFF7C3AED),
                accentColor = Color(0xFF6D28D9),
                iconRes = R.drawable.cloud,
                shortTag = "Qwen",
                monogram = "Q",
            )
        }
        idLower.startsWith("nvidia/") || idLower.contains("nvidia") || idLower.contains("nemotron") || pLower == "nvidia" -> {
            ProviderVisualInfo(
                name = "NVIDIA",
                brandColor = Color(0xFF76B900),
                accentColor = Color(0xFF5C9100),
                iconRes = R.drawable.explore_outlined,
                shortTag = "NVIDIA",
                monogram = "NV",
            )
        }
        idLower.startsWith("microsoft/") || idLower.contains("phi-") || pLower == "microsoft" -> {
            ProviderVisualInfo(
                name = "Microsoft",
                brandColor = Color(0xFF00A4EF),
                accentColor = Color(0xFF0078D7),
                iconRes = R.drawable.grid_view,
                shortTag = "Microsoft",
                monogram = "MS",
            )
        }
        idLower.startsWith("x-ai/") || idLower.contains("grok") || pLower == "xai" || pLower == "x-ai" -> {
            ProviderVisualInfo(
                name = "xAI",
                brandColor = Color(0xFF27272A),
                accentColor = Color(0xFF18181B),
                iconRes = R.drawable.discover_tune,
                shortTag = "xAI",
                monogram = "X",
            )
        }
        idLower.startsWith("perplexity/") || idLower.contains("sonar") || pLower == "perplexity" -> {
            ProviderVisualInfo(
                name = "Perplexity",
                brandColor = Color(0xFF0D9488),
                accentColor = Color(0xFF0F766E),
                iconRes = R.drawable.search,
                shortTag = "Perplexity",
                monogram = "P",
            )
        }
        idLower.startsWith("cohere/") || idLower.contains("command-") || pLower == "cohere" -> {
            ProviderVisualInfo(
                name = "Cohere",
                brandColor = Color(0xFF39594D),
                accentColor = Color(0xFF2A443A),
                iconRes = R.drawable.token,
                shortTag = "Cohere",
                monogram = "CO",
            )
        }
        idLower.startsWith("aion-labs/") || idLower.startsWith("aion_") || idLower.contains("aion-") || pLower == "aionlabs" || pLower == "aion-labs" -> {
            ProviderVisualInfo(
                name = "AionLabs",
                brandColor = Color(0xFF00D2FF),
                accentColor = Color(0xFF7C4DFF),
                iconRes = R.drawable.discover_tune,
                shortTag = "AionLabs",
                monogram = "AΛ",
            )
        }
        idLower == "huggingface" || idLower.startsWith("huggingface/") || idLower.startsWith("huggingfaceh4/") || pLower == "huggingface" || pLower == "hugging face" -> {
            ProviderVisualInfo(
                name = "HuggingFace",
                brandColor = Color(0xFFFFB300),
                accentColor = Color(0xFFFF6F00),
                iconRes = R.drawable.discover_tune,
                shortTag = "HuggingFace",
                monogram = "HF",
            )
        }
        else -> {
            val fallbackName = when {
                providerName.isNotBlank() -> providerName.replaceFirstChar { it.uppercase() }
                modelId.contains("/") -> modelId.substringBefore("/").replaceFirstChar { it.uppercase() }
                modelId.isNotBlank() -> modelId.take(12).replaceFirstChar { it.uppercase() }
                else -> "AI"
            }
            val initial = fallbackName.take(2).uppercase()
            ProviderVisualInfo(
                name = fallbackName,
                brandColor = Color(0xFF6366F1),
                accentColor = Color(0xFF4F46E5),
                iconRes = R.drawable.explore_outlined,
                shortTag = fallbackName.take(12),
                monogram = initial,
            )
        }
    }
}

fun getProviderDetailedSpec(modelId: String, providerName: String = ""): ProviderDetailedSpec {
    val visual = getProviderVisualInfo(modelId, providerName)
    return when (visual.name) {
        "OpenRouter" -> ProviderDetailedSpec(
            visual = visual,
            officialTitle = "OpenRouter Unified AI Hub",
            categoryLabelVi = "Trung tâm hợp nhất đa mô hình",
            categoryLabelEn = "Multi-Provider Unified Hub",
            specialtyVi = "Cung cấp hơn 300+ mô hình miễn phí & trả phí qua một cổng kết nối chuẩn OpenAI duy nhất.",
            specialtyEn = "Provides 300+ free and commercial AI models through a single unified OpenAI-compatible gateway.",
            protocolLabel = "OpenAI REST v1 (SSE / JSON)",
            authPolicyVi = "Hỗ trợ khóa API miễn phí & trả phí (Bearer Token)",
            authPolicyEn = "Supports Free & Paid API Keys (Bearer Token)",
            portalUrl = "https://openrouter.ai/keys",
            portalDomain = "openrouter.ai",
            supportedFeaturesVi = listOf("Định tuyến dự phòng tự động", "Mô hình miễn phí (:free)", "Đo độ trễ TTFT thực tế"),
            supportedFeaturesEn = listOf("Automatic Fallback Routing", "Free Tier Models (:free)", "Real-time TTFT Benchmarking"),
        )
        "DeepInfra" -> ProviderDetailedSpec(
            visual = visual,
            officialTitle = "DeepInfra Cloud Inference",
            categoryLabelVi = "Hạ tầng suy luận nguồn mở",
            categoryLabelEn = "Open-Source Inference Cloud",
            specialtyVi = "Chuyên biệt cho các mô hình nguồn mở tốc độ cao (Llama, DeepSeek, Qwen) với chi phí thấp.",
            specialtyEn = "Specialized in fast, low-cost inference for open-weight models (Llama, DeepSeek, Qwen).",
            protocolLabel = "OpenAI-Compatible v1/openai",
            authPolicyVi = "Tùy chọn khóa API hoặc chế độ tích hợp sẵn",
            authPolicyEn = "Optional API Key or Built-in Serverless Mode",
            portalUrl = "https://deepinfra.com/dash/api_keys",
            portalDomain = "deepinfra.com",
            supportedFeaturesVi = listOf("Tốc độ phản hồi cực nhanh", "Hỗ trợ mô hình suy luận R1", "Đồng bộ danh sách Ktor thời gian thực"),
            supportedFeaturesEn = listOf("Ultra-fast Token Generation", "Reasoning R1 Support", "Real-time Ktor Model Sync"),
        )
        "AionLabs" -> ProviderDetailedSpec(
            visual = visual,
            officialTitle = "AionLabs Realtime Neural Studio",
            categoryLabelVi = "Đề xuất AI Thời gian thực & Dịch Ca từ",
            categoryLabelEn = "Real-Time AI Recommendation & Lyric Studio",
            specialtyVi = "Đồng bộ trực tiếp từ https://api.aionlabs.ai/v1/models với dòng mô hình Aion ngữ cảnh rộng 128K-256K tối ưu cho sắc thái lời bài hát và đề xuất theo thời gian thực.",
            specialtyEn = "Live-synced from https://api.aionlabs.ai/v1/models featuring 128K-256K context Aion models optimized for poetic lyric nuance and real-time recommendations.",
            protocolLabel = "AionLabs OpenAI REST v1",
            authPolicyVi = "Danh mục mô hình công khai thời gian thực & Khóa API Bearer",
            authPolicyEn = "Public Real-Time Model Catalog & Bearer API Key",
            portalUrl = "https://aionlabs.ai",
            portalDomain = "api.aionlabs.ai",
            supportedFeaturesVi = listOf("Đồng bộ https://api.aionlabs.ai/v1/models", "Chấm điểm tương thích thời gian thực", "Hỗ trợ bộ nhớ đệm ngữ cảnh (Cache Read)"),
            supportedFeaturesEn = listOf("Live https://api.aionlabs.ai/v1/models Sync", "Real-Time Match Telemetry Scoring", "Prompt Context Cache Read Support"),
        )
        "HuggingFace" -> ProviderDetailedSpec(
            visual = visual,
            officialTitle = "Hugging Face Hub & Inference Router",
            categoryLabelVi = "Kho Mô hình Nguồn mở Thời gian thực",
            categoryLabelEn = "Real-Time Open-Source Model Hub",
            specialtyVi = "Đồng bộ trực tiếp từ https://huggingface.co/api/models với hàng trăm mô hình nguồn mở thịnh hành (Qwen, Llama, DeepSeek, Mistral, Gemma) và gợi ý tự động theo thời gian thực.",
            specialtyEn = "Live-synced from https://huggingface.co/api/models featuring top trending open-weight models (Qwen, Llama, DeepSeek, Mistral, Gemma) and real-time recommendations.",
            protocolLabel = "Hugging Face Router v1 / Hub REST API",
            authPolicyVi = "Danh mục công khai https://huggingface.co/api/models & Khóa hf_…",
            authPolicyEn = "Public https://huggingface.co/api/models & hf_… Access Token",
            portalUrl = "https://huggingface.co/settings/tokens",
            portalDomain = "huggingface.co",
            supportedFeaturesVi = listOf("Đồng bộ https://huggingface.co/api/models", "Đo lường Lượt tải & Yêu thích trực tiếp", "Đề xuất mô hình đa ngôn ngữ tự động"),
            supportedFeaturesEn = listOf("Live https://huggingface.co/api/models Sync", "Real-Time Downloads & Likes Telemetry", "Smart Multilingual Lyric Recommendation"),
        )
        "Google" -> ProviderDetailedSpec(
            visual = visual,
            officialTitle = "Google DeepMind (Gemini & Gemma)",
            categoryLabelVi = "Nhà cung cấp mô hình nền tảng",
            categoryLabelEn = "Verified Frontier Model Provider",
            specialtyVi = "Nổi bật với cửa sổ ngữ cảnh cực lớn (lên tới 1M-2M tokens), đa phương thức và dịch đa ngôn ngữ tự nhiên.",
            specialtyEn = "Industry-leading long context windows (up to 1M-2M tokens), multimodal understanding, and natural translation.",
            protocolLabel = "Google AI Studio / OpenAI v1beta",
            authPolicyVi = "Khóa API từ Google AI Studio hoặc OpenRouter",
            authPolicyEn = "API Key via Google AI Studio or OpenRouter",
            portalUrl = "https://aistudio.google.com/apikey",
            portalDomain = "aistudio.google.com",
            supportedFeaturesVi = listOf("Cửa sổ ngữ cảnh 1M+ tokens", "Dịch lời bài hát giữ nhịp điệu", "Gemini Flash phản hồi tức thì"),
            supportedFeaturesEn = listOf("1M+ Token Context Window", "Rhythm-Preserving Lyrics Translation", "Instant Gemini Flash Inference"),
        )
        "OpenAI" -> ProviderDetailedSpec(
            visual = visual,
            officialTitle = "OpenAI (GPT-4o & o-Series)",
            categoryLabelVi = "Nhà cung cấp mô hình nền tảng",
            categoryLabelEn = "Verified Frontier Model Provider",
            specialtyVi = "Mô hình đa năng chuẩn mực cho dịch thuật ca từ chính xác, phân tích sắc thái văn hóa và suy luận logic.",
            specialtyEn = "Flagship multimodal and reasoning models for nuanced lyric translation and cultural context.",
            protocolLabel = "OpenAI Chat Completions v1",
            authPolicyVi = "Yêu cầu khóa API chính thức hoặc qua cổng trung gian",
            authPolicyEn = "Requires Official API Key or Unified Gateway",
            portalUrl = "https://platform.openai.com/api-keys",
            portalDomain = "platform.openai.com",
            supportedFeaturesVi = listOf("Hiểu sâu ẩn dụ âm nhạc", "Suy luận chuỗi (o1/o3)", "Độ ổn định định dạng cao"),
            supportedFeaturesEn = listOf("Deep Musical Metaphor Comprehension", "Chain-of-Thought (o1/o3)", "High Formatting Reliability"),
        )
        "DeepSeek" -> ProviderDetailedSpec(
            visual = visual,
            officialTitle = "DeepSeek AI (V3 & R1 Reasoning)",
            categoryLabelVi = "Nhà cung cấp suy luận chuyên sâu",
            categoryLabelEn = "Frontier Reasoning & MoE Provider",
            specialtyVi = "Kiến trúc Mixture-of-Experts (MoE) hiệu suất cao, xuất sắc trong dịch thuật ngôn ngữ Á Đông và suy luận chuỗi.",
            specialtyEn = "High-efficiency Mixture-of-Experts (MoE) architecture excelling in Asian languages and deep reasoning.",
            protocolLabel = "OpenAI-Compatible Chat v1",
            authPolicyVi = "Hỗ trợ qua OpenRouter, DeepInfra và NVIDIA NIM",
            authPolicyEn = "Available via OpenRouter, DeepInfra, and NVIDIA NIM",
            portalUrl = "https://openrouter.ai/models?q=deepseek",
            portalDomain = "deepseek.com",
            supportedFeaturesVi = listOf("Suy luận chuỗi DeepSeek-R1", "Tối ưu ngữ cảnh Việt - Trung - Nhật - Hàn", "Chi phí token siêu tiết kiệm"),
            supportedFeaturesEn = listOf("DeepSeek-R1 Chain-of-Thought", "Optimized CJK & Vietnamese Nuance", "Ultra Cost-Effective Tokens"),
        )
        "Anthropic" -> ProviderDetailedSpec(
            visual = visual,
            officialTitle = "Anthropic (Claude 3.5 / 3.7)",
            categoryLabelVi = "Nhà cung cấp mô hình nền tảng",
            categoryLabelEn = "Verified Frontier Model Provider",
            specialtyVi = "Khả năng văn phong tự nhiên, giàu cảm xúc nghệ thuật, rất phù hợp để dịch lời bài hát thơ mộng.",
            specialtyEn = "Exceptional literary tone and emotional nuance, ideal for poetic and expressive song lyrics.",
            protocolLabel = "Anthropic Messages v1 / OpenRouter",
            authPolicyVi = "Khóa API từ Anthropic Console hoặc OpenRouter",
            authPolicyEn = "API Key via Anthropic Console or OpenRouter",
            portalUrl = "https://console.anthropic.com/settings/keys",
            portalDomain = "console.anthropic.com",
            supportedFeaturesVi = listOf("Chuyển ngữ giàu chất thơ", "Ngữ cảnh 200K tokens ổn định", "An toàn chính sách nội dung"),
            supportedFeaturesEn = listOf("Poetic Literary Translation", "Stable 200K Context Window", "Strict Content Policy Compliance"),
        )
        "Meta" -> ProviderDetailedSpec(
            visual = visual,
            officialTitle = "Meta AI (Llama 3.1 / 3.3 / 4)",
            categoryLabelVi = "Hệ sinh thái mô hình mở chuẩn mực",
            categoryLabelEn = "Verified Open-Weight Ecosystem",
            specialtyVi = "Dòng mô hình Llama đa ngôn ngữ phổ biến nhất thế giới, tốc độ nhanh và tương thích mọi nền tảng.",
            specialtyEn = "World-leading open-weight multilingual Llama family with broad hosting support and low latency.",
            protocolLabel = "OpenAI-Compatible v1",
            authPolicyVi = "Cung cấp miễn phí & trả phí qua DeepInfra, Groq, OpenRouter",
            authPolicyEn = "Hosted on DeepInfra, Groq, and OpenRouter",
            portalUrl = "https://deepinfra.com/models",
            portalDomain = "llama.meta.com",
            supportedFeaturesVi = listOf("Đa ngôn ngữ 8B - 405B tham số", "Tốc độ sinh từ rất nhanh", "Hoạt động ổn định 24/7"),
            supportedFeaturesEn = listOf("Multilingual 8B - 405B Models", "High Throughput Generation", "Reliable 24/7 Availability"),
        )
        "Qwen" -> ProviderDetailedSpec(
            visual = visual,
            officialTitle = "Alibaba Cloud (Qwen 2.5 / QwQ)",
            categoryLabelVi = "Nhà cung cấp đa ngôn ngữ Á - Âu",
            categoryLabelEn = "Verified Multilingual AI Provider",
            specialtyVi = "Được huấn luyện chuyên sâu trên hơn 29 ngôn ngữ, đặc biệt mạnh về tiếng Việt, Anh, Nhật, Hàn, Trung.",
            specialtyEn = "Trained extensively across 29+ languages with top-tier fluency in Vietnamese, English, and East Asian lyrics.",
            protocolLabel = "OpenAI-Compatible v1",
            authPolicyVi = "Hỗ trợ qua DeepInfra và OpenRouter",
            authPolicyEn = "Supported via DeepInfra and OpenRouter",
            portalUrl = "https://openrouter.ai/models?q=qwen",
            portalDomain = "qwenlm.github.io",
            supportedFeaturesVi = listOf("Chuẩn xác ngữ pháp tiếng Việt", "Hỗ trợ suy luận QwQ", "Tốc độ phản hồi ổn định"),
            supportedFeaturesEn = listOf("High Vietnamese Grammatical Accuracy", "QwQ Reasoning Support", "Consistent Low Latency"),
        )
        "Mistral AI" -> ProviderDetailedSpec(
            visual = visual,
            officialTitle = "Mistral AI (Mistral Large & Small)",
            categoryLabelVi = "Nhà cung cấp AI Châu Âu chính thức",
            categoryLabelEn = "Verified European AI Provider",
            specialtyVi = "Tối ưu hóa cao cho các ngôn ngữ hệ Latinh, Châu Âu và dịch thuật tốc độ cao với kiến trúc gọn nhẹ.",
            specialtyEn = "Highly optimized for European and Latin-script languages with compact, fast inference.",
            protocolLabel = "Mistral / OpenAI Chat v1",
            authPolicyVi = "Khóa API từ Mistral La Plateforme hoặc OpenRouter",
            authPolicyEn = "API Key via Mistral Console or OpenRouter",
            portalUrl = "https://console.mistral.ai/api-keys",
            portalDomain = "console.mistral.ai",
            supportedFeaturesVi = listOf("Dịch nhanh ngôn ngữ Âu - Mỹ", "Độ trễ TTFT thấp", "Tuân thủ bảo mật dữ liệu"),
            supportedFeaturesEn = listOf("Fast Western Language Translation", "Low TTFT Latency", "Strict Data Privacy Standards"),
        )
        "NVIDIA" -> ProviderDetailedSpec(
            visual = visual,
            officialTitle = "NVIDIA NIM (Llama Nemotron)",
            categoryLabelVi = "Hạ tầng tăng tốc GPU doanh nghiệp",
            categoryLabelEn = "Enterprise GPU-Accelerated NIM",
            specialtyVi = "Các mô hình Nemotron được tinh chỉnh trên cụm GPU NVIDIA TensorRT-LLM cho độ chính xác và tốc độ cao.",
            specialtyEn = "Nemotron models optimized with NVIDIA TensorRT-LLM for enterprise instruction following and speed.",
            protocolLabel = "NVIDIA NIM OpenAI v1",
            authPolicyVi = "Khóa API miễn phí thử nghiệm từ build.nvidia.com",
            authPolicyEn = "Developer API Key via build.nvidia.com",
            portalUrl = "https://build.nvidia.com",
            portalDomain = "build.nvidia.com",
            supportedFeaturesVi = listOf("Tăng tốc phần cứng TensorRT-LLM", "Tinh chỉnh Nemotron Ultra/Super", "Độ chính xác tuân thủ lệnh cao"),
            supportedFeaturesEn = listOf("TensorRT-LLM Hardware Acceleration", "Nemotron Ultra/Super Tuning", "High Instruction Adherence"),
        )
        "Groq" -> ProviderDetailedSpec(
            visual = visual,
            officialTitle = "Groq LPU Inference Engine",
            categoryLabelVi = "Hạ tầng chip LPU siêu tốc",
            categoryLabelEn = "Ultra-Low Latency LPU Provider",
            specialtyVi = "Sử dụng bộ xử lý ngôn ngữ LPU chuyên dụng giúp dịch toàn bộ lời bài hát chỉ trong chưa đầy 1 giây.",
            specialtyEn = "Powered by custom Language Processing Units (LPUs) delivering sub-second full-song lyric translations.",
            protocolLabel = "Groq OpenAI-Compatible v1",
            authPolicyVi = "Cung cấp khóa API miễn phí tại console.groq.com",
            authPolicyEn = "Free-tier API Key available at console.groq.com",
            portalUrl = "https://console.groq.com/keys",
            portalDomain = "console.groq.com",
            supportedFeaturesVi = listOf("TTFT dưới 200ms", "Hỗ trợ gói miễn phí hào phóng", "Tương thích hoàn toàn chuẩn OpenAI"),
            supportedFeaturesEn = listOf("Sub-200ms TTFT", "Generous Free Tier Quota", "Full OpenAI API Compatibility"),
        )
        "Perplexity" -> ProviderDetailedSpec(
            visual = visual,
            officialTitle = "Perplexity AI (Sonar Models)",
            categoryLabelVi = "Công cụ AI kết hợp tri thức trực tuyến",
            categoryLabelEn = "Real-Time Grounded AI Provider",
            specialtyVi = "Dòng mô hình Sonar kết hợp bối cảnh bài hát và thông tin văn hóa theo thời gian thực.",
            specialtyEn = "Sonar models combine language generation with real-time cultural and musical context.",
            protocolLabel = "Perplexity Chat Completions",
            authPolicyVi = "Khóa API từ Perplexity Settings",
            authPolicyEn = "API Key via Perplexity Settings",
            portalUrl = "https://perplexity.ai/settings/api",
            portalDomain = "perplexity.ai",
            supportedFeaturesVi = listOf("Hiểu bối cảnh bài hát mới", "Tốc độ suy luận Sonar nhanh", "Độ chính xác thông tin cao"),
            supportedFeaturesEn = listOf("Up-to-date Song Context", "Fast Sonar Inference", "Grounded Factual Accuracy"),
        )
        "xAI" -> ProviderDetailedSpec(
            visual = visual,
            officialTitle = "xAI (Grok Intelligence)",
            categoryLabelVi = "Nhà cung cấp mô hình nền tảng",
            categoryLabelEn = "Verified Frontier AI Provider",
            specialtyVi = "Dòng mô hình Grok mạnh về ngôn ngữ đời thường, tiếng lóng (slang) và sắc thái ca từ hiện đại.",
            specialtyEn = "Grok models excel at modern idioms, slang, and contemporary lyric expressions.",
            protocolLabel = "xAI OpenAI-Compatible v1",
            authPolicyVi = "Khóa API từ console.x.ai hoặc OpenRouter",
            authPolicyEn = "API Key via console.x.ai or OpenRouter",
            portalUrl = "https://console.x.ai",
            portalDomain = "console.x.ai",
            supportedFeaturesVi = listOf("Hiểu tốt ngôn ngữ trẻ & Slang", "Ngữ cảnh rộng 128K+", "Phản hồi tự nhiên, linh hoạt"),
            supportedFeaturesEn = listOf("Strong Idiom & Slang Nuance", "128K+ Context Capacity", "Natural Expressive Output"),
        )
        "DeepL" -> ProviderDetailedSpec(
            visual = visual,
            officialTitle = "DeepL Neural Translation API",
            categoryLabelVi = "Dịch máy thần kinh chuyên biệt",
            categoryLabelEn = "Dedicated Neural Translation Provider",
            specialtyVi = "Công cụ dịch thuật chuyên dụng với tùy chọn mức độ trang trọng (Formality) và độ ổn định tuyệt đối.",
            specialtyEn = "Dedicated neural machine translation with formality control and rock-solid line consistency.",
            protocolLabel = "DeepL REST API v2",
            authPolicyVi = "Hỗ trợ khóa DeepL API Free (:fx) và Pro",
            authPolicyEn = "Supports DeepL API Free (:fx) and Pro Keys",
            portalUrl = "https://deepl.com/pro-api",
            portalDomain = "deepl.com",
            supportedFeaturesVi = listOf("Kiểm soát mức độ trang trọng", "Không bao giờ lệch số dòng", "Hỗ trợ gói Free 500.000 ký tự/tháng"),
            supportedFeaturesEn = listOf("Formality Tone Control", "Zero Line-Count Drift", "500,000 Chars/Month Free Tier"),
        )
        else -> ProviderDetailedSpec(
            visual = visual,
            officialTitle = "${visual.name} AI Provider",
            categoryLabelVi = "Nhà cung cấp mô hình AI tương thích",
            categoryLabelEn = "Compatible AI Model Provider",
            specialtyVi = "Cung cấp khả năng xử lý ngôn ngữ tự nhiên, dịch lời bài hát và phân tích ngữ cảnh theo chuẩn OpenAI.",
            specialtyEn = "Provides natural language processing, lyric translation, and context analysis via standard APIs.",
            protocolLabel = "OpenAI-Compatible REST API",
            authPolicyVi = "Tuân thủ chính sách bảo mật khóa API cục bộ",
            authPolicyEn = "Complies with encrypted local API key policy",
            portalUrl = "https://openrouter.ai/models",
            portalDomain = "openrouter.ai",
            supportedFeaturesVi = listOf("Tương thích chuẩn Chat Completions", "Hỗ trợ dịch lời bài hát đa ngữ", "Mã hóa khóa bảo mật trên thiết bị"),
            supportedFeaturesEn = listOf("Standard Chat Completions Support", "Multilingual Lyric Translation", "On-Device Encrypted Key Storage"),
        )
    }
}

@Composable
fun ProviderAvatar(
    modelId: String,
    providerName: String = "",
    modifier: Modifier = Modifier,
    size: Dp = 32.dp,
) {
    val info = remember(modelId, providerName) { getProviderVisualInfo(modelId, providerName) }

    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.28f))
            .background(
                Brush.linearGradient(
                    listOf(info.brandColor, info.accentColor)
                )
            )
            .border(
                width = 1.dp,
                color = Color.White.copy(alpha = 0.25f),
                shape = RoundedCornerShape(size * 0.28f)
            ),
        contentAlignment = Alignment.Center,
    ) {
        if (info.iconRes != null && (info.name == "Google" || info.name == "DeepSeek" || info.name == "Meta" || info.name == "OpenAI")) {
            Icon(
                painter = painterResource(info.iconRes),
                contentDescription = info.name,
                tint = Color.White,
                modifier = Modifier.size(size * 0.58f)
            )
        } else {
            Text(
                text = info.monogram,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = (size.value * 0.38f).sp,
                lineHeight = (size.value * 0.42f).sp,
                maxLines = 1,
                softWrap = false,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
fun ProviderBadge(
    modelId: String,
    providerName: String = "",
    modifier: Modifier = Modifier,
    showLabel: Boolean = true,
    onClick: (() -> Unit)? = null,
) {
    val info = remember(modelId, providerName) { getProviderVisualInfo(modelId, providerName) }

    Surface(
        modifier = if (onClick != null) {
            modifier.clip(RoundedCornerShape(6.dp)).clickable(onClick = onClick)
        } else {
            modifier
        },
        color = info.brandColor.copy(alpha = 0.12f),
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, info.brandColor.copy(alpha = 0.35f)),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(info.brandColor)
            )
            if (showLabel) {
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = info.shortTag,
                    style = MaterialTheme.typography.labelSmall,
                    color = info.brandColor,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.sp,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
fun ModelStatusBadge(
    status: ModelHealthStatus,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        color = status.backgroundColor,
        shape = RoundedCornerShape(4.dp),
        border = BorderStroke(0.7.dp, status.borderColor),
    ) {
        Text(
            text = stringResource(status.labelRes),
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
            ),
            color = status.textColor,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.5.dp),
        )
    }
}

@Composable
fun ModelServiceHealthBadge(
    health: ModelServiceHealth,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        color = health.backgroundColor,
        shape = RoundedCornerShape(4.dp),
        border = BorderStroke(0.7.dp, health.borderColor),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.5.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(5.dp)
                    .clip(CircleShape)
                    .background(health.indicatorColor)
            )
            Text(
                text = stringResource(health.labelRes),
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                ),
                color = health.indicatorColor,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
fun ModelSourceCategoryChips(
    selectedCategory: ModelSourceCategory,
    onSelectCategory: (ModelSourceCategory) -> Unit,
    modifier: Modifier = Modifier,
) {
    val scrollState = rememberScrollState()
    Row(
        modifier = modifier
            .horizontalScroll(scrollState)
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ModelSourceCategory.entries.forEach { cat ->
            val isSelected = cat == selectedCategory
            FilterChip(
                selected = isSelected,
                onClick = { onSelectCategory(cat) },
                label = {
                    Text(
                        text = stringResource(cat.labelRes),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1,
                        softWrap = false,
                    )
                },
                shape = RoundedCornerShape(8.dp),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = isSelected,
                    borderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                    selectedBorderColor = MaterialTheme.colorScheme.primary,
                ),
            )
        }
    }
}

@Composable
fun ProviderInfoModalDialog(
    modelIdOrProvider: String,
    providerName: String = "",
    modelCountInGroup: Int = 0,
    onDismiss: () -> Unit,
    onOpenPortal: ((String) -> Unit)? = null,
) {
    val isVi = androidx.compose.ui.platform.LocalConfiguration.current.locales[0]?.language == "vi"
    val spec = remember(modelIdOrProvider, providerName) {
        getProviderDetailedSpec(modelIdOrProvider, providerName)
    }
    val sourceCategory = remember(modelIdOrProvider, providerName) {
        getModelSourceCategory(modelIdOrProvider, providerName)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .padding(vertical = 24.dp),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            tonalElevation = 8.dp,
        ) {
            androidx.compose.foundation.layout.Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                // Balanced Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    ProviderAvatar(
                        modelId = modelIdOrProvider,
                        providerName = providerName,
                        size = 48.dp,
                    )
                    androidx.compose.foundation.layout.Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Text(
                            text = spec.officialTitle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            ProviderBadge(
                                modelId = modelIdOrProvider,
                                providerName = providerName,
                            )
                            Surface(
                                color = spec.visual.brandColor.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(6.dp),
                                border = BorderStroke(0.8.dp, spec.visual.brandColor.copy(alpha = 0.3f)),
                            ) {
                                Text(
                                    text = stringResource(sourceCategory.labelRes),
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                    fontWeight = FontWeight.Bold,
                                    color = spec.visual.brandColor,
                                    maxLines = 1,
                                    softWrap = false,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                )
                            }
                        }
                    }
                    androidx.compose.material3.IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(32.dp),
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.close),
                            contentDescription = stringResource(android.R.string.cancel),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                }

                // Overview Description Card
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                ) {
                    androidx.compose.foundation.layout.Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Text(
                            text = if (isVi) spec.categoryLabelVi else spec.categoryLabelEn,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = spec.visual.brandColor,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = if (isVi) spec.specialtyVi else spec.specialtyEn,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 18.sp,
                        )
                    }
                }

                // Technical & Policy Alignment Table
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                ) {
                    androidx.compose.foundation.layout.Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        ProviderAlignedSpecRow(
                            label = if (isVi) "Nhà cung cấp" else "Provider",
                            value = spec.visual.name,
                        )
                        ProviderAlignedSpecRow(
                            label = if (isVi) "Giao thức kết nối" else "API Protocol",
                            value = spec.protocolLabel,
                        )
                        ProviderAlignedSpecRow(
                            label = if (isVi) "Chính sách xác thực" else "Auth Policy",
                            value = if (isVi) spec.authPolicyVi else spec.authPolicyEn,
                        )
                        ProviderAlignedSpecRow(
                            label = if (isVi) "Cổng chính thức" else "Official Portal",
                            value = spec.portalDomain,
                        )
                        if (modelCountInGroup > 0) {
                            ProviderAlignedSpecRow(
                                label = if (isVi) "Số mô hình sẵn có" else "Available Models",
                                value = if (isVi) "$modelCountInGroup mô hình" else "$modelCountInGroup models",
                            )
                        }
                    }
                }

                // Supported Strengths List
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = spec.visual.brandColor.copy(alpha = 0.08f),
                    border = BorderStroke(1.dp, spec.visual.brandColor.copy(alpha = 0.22f)),
                ) {
                    androidx.compose.foundation.layout.Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Text(
                            text = if (isVi) "Điểm mạnh & Tương thích hệ thống" else "Provider Highlights & Compatibility",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = spec.visual.brandColor,
                        )
                        val highlights = if (isVi) spec.supportedFeaturesVi else spec.supportedFeaturesEn
                        highlights.forEach { feat ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.check),
                                    contentDescription = null,
                                    tint = spec.visual.brandColor,
                                    modifier = Modifier.size(14.dp),
                                )
                                Text(
                                    text = feat,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                }

                // Action Buttons Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (onOpenPortal != null) {
                        androidx.compose.material3.OutlinedButton(
                            onClick = { onOpenPortal(spec.portalUrl) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.key),
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isVi) "Cổng API" else "API Portal",
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                    androidx.compose.material3.Button(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                    ) {
                        Text(
                            text = stringResource(android.R.string.ok),
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false,
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ProviderAlignedSpecRow(
    label: String,
    value: String,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(0.42f),
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.End,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(0.58f),
        )
    }
}

