/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.security

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import com.listrovia.music.ui.screens.OmnisSecurityBlockActivity
import timber.log.Timber
import java.io.BufferedReader
import java.io.File
import java.io.IOException
import java.io.InputStreamReader
import java.security.MessageDigest
import java.util.Locale

/**
 * Omnis Security Engine - Advanced Tamper & Repackaging Detection.
 * Allows normal application usage under legitimate conditions, and strictly enforces
 * security blockades ONLY when actual APK tampering, repackaging (signature mismatch),
 * or active memory hooking/injection (Frida, Xposed, Cheat Engine) is detected.
 */
object OmnisSecurityManager {
    private const val TAG = "OmnisSecurity"
    private const val PREF_NAME = "omnis_security_prefs"
    private const val KEY_BASELINE_SIGNATURE = "baseline_apk_signature_hash"

    /**
     * Checks for actual APK modification, repackaging, or malicious tampering.
     * Returns true if tampering is detected and enforcement is triggered.
     */
    fun checkThreatsAndEnforce(context: Context): Boolean {
        try {
            // 1. Signature Verification / Repackaging Detection (Critical Tampering Check)
            if (!isSignatureValid(context)) {
                Timber.tag(TAG).w("Critical Security Alert: APK Signature mismatch / Repackaging detected!")
                triggerSecurityBlockade(context)
                return true
            }

            // 2. Memory Hooking / Frida / Injection Detection (Active Tampering Check)
            if (isMemoryHooked()) {
                Timber.tag(TAG).w("Critical Security Alert: Active memory hooking or injection tool detected!")
                triggerSecurityBlockade(context)
                return true
            }
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Error executing security tamper inspection")
        }
        return false
    }

    private fun triggerSecurityBlockade(context: Context) {
        try {
            val intent = Intent(context, OmnisSecurityBlockActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to launch OmnisSecurityBlockActivity")
        }
    }

    /**
     * Signature Verification: Compares app signing certificate SHA-256 against baseline.
     * If the APK was decompiled, modified, and re-signed with a different signature,
     * the hash will differ from the original legitimate creator signature.
     */
    private fun isSignatureValid(context: Context): Boolean {
        try {
            val packageName = context.packageName
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val currentSignatureHash = getApkSignatureHash(context, packageName) ?: return true

            val baselineHash = prefs.getString(KEY_BASELINE_SIGNATURE, null)
            if (baselineHash == null) {
                // First legitimate run: record current signature as the trusted creator baseline
                prefs.edit().putString(KEY_BASELINE_SIGNATURE, currentSignatureHash).apply()
                Timber.tag(TAG).d("Omnis Security: Baseline signature established successfully.")
                return true
            }

            if (baselineHash != currentSignatureHash) {
                Timber.tag(TAG).w("TAMPER DETECTED: Expected signature '$baselineHash' but found '$currentSignatureHash'")
                return false
            }
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Error validating APK signature")
        }
        return true
    }

    private fun getApkSignatureHash(context: Context, packageName: String): String? {
        try {
            val pm = context.packageManager
            val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val pkgInfo = pm.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                pkgInfo.signingInfo?.let { signingInfo ->
                    if (signingInfo.hasMultipleSigners()) {
                        signingInfo.apkContentsSigners
                    } else {
                        signingInfo.signingCertificateHistory
                    }
                }
            } else {
                @Suppress("DEPRECATION")
                val pkgInfo = pm.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
                pkgInfo.signatures
            }

            if (signatures != null && signatures.isNotEmpty()) {
                val cert = signatures[0].toByteArray()
                val md = MessageDigest.getInstance("SHA-256")
                val digest = md.digest(cert)
                return digest.joinToString("") { "%02x".format(it) }
            }
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to compute APK signature hash")
        }
        return null
    }

    /**
     * Memory Scan: Reads /proc/self/maps to detect active memory hooks or hooking frameworks (Frida, Xposed, Cheat Engine).
     */
    private fun isMemoryHooked(): Boolean {
        var reader: BufferedReader? = null
        try {
            val mapsFile = File("/proc/self/maps")
            if (!mapsFile.exists()) return false

            reader = BufferedReader(InputStreamReader(mapsFile.inputStream()))
            var line: String? = reader.readLine()
            val forbiddenKeywords = listOf(
                "frida", "gadget", "xposed", "cheatengine", "substrate",
                "shadowhook", "cydia", "libsubstrate", "libxposed", "libfrida"
            )

            while (line != null) {
                val lowerLine = line.lowercase(Locale.ROOT)
                for (keyword in forbiddenKeywords) {
                    if (lowerLine.contains(keyword)) {
                        Timber.tag(TAG).w("TAMPER DETECTED: Memory hook framework detected in /proc/self/maps: '$keyword'")
                        return true
                    }
                }
                line = reader.readLine()
            }
        } catch (e: Exception) {
            Timber.tag(TAG).d("Memory scan check note: ${e.message}")
        } finally {
            try {
                reader?.close()
            } catch (_: IOException) {}
        }
        return false
    }
}
