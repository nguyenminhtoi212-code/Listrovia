package com.listrovia.music.utils

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import androidx.core.graphics.createBitmap
import coil3.ImageLoader
import coil3.request.ImageRequest
import coil3.request.allowHardware
import coil3.toBitmap
import com.listrovia.music.db.entities.SongWithStats
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileWriter
import java.io.IOException
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

object StatsExporter {

    fun generateTextSummary(
        periodName: String,
        songs: List<SongWithStats>,
    ): String = buildString {
        appendLine("========================================")
        appendLine("       METROLIST TOP TRACKS STATS")
        appendLine("========================================")
        appendLine("Period: $periodName")
        appendLine("Exported on: ${LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))}")
        appendLine("Total Songs Listed: ${songs.size}")
        appendLine("----------------------------------------")
        appendLine()

        if (songs.isEmpty()) {
            appendLine("No top tracks available for this period.")
        } else {
            songs.forEachIndexed { index, song ->
                val rank = index + 1
                val artistStr = if (song.artists.isNotEmpty()) {
                    song.artists.joinToString(", ") { it.name }
                } else {
                    song.artistName ?: "Unknown Artist"
                }
                val timeStr = makeTimeString(song.timeListened)
                appendLine("$rank. ${song.title}")
                appendLine("   Artist: $artistStr")
                appendLine("   Plays: ${song.songCountListened} | Time Listened: $timeStr")
                appendLine()
            }
        }

        appendLine("========================================")
        appendLine("Exported from Metrolist Music")
    }

    fun exportStatsAsTextFile(
        context: Context,
        periodName: String,
        songs: List<SongWithStats>,
    ): Result<File> = try {
        val content = generateTextSummary(periodName, songs)
        val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(exportDir, "top_tracks_stats.txt")
        FileWriter(file).use { it.write(content) }
        Result.success(file)
    } catch (e: IOException) {
        Result.failure(e)
    }

    suspend fun createStatsSummaryImage(
        context: Context,
        periodName: String,
        songs: List<SongWithStats>,
        maxSongsToDisplay: Int = 8,
    ): Bitmap = withContext(Dispatchers.Default) {
        val displaySongs = songs.take(maxSongsToDisplay)

        val width = 1200
        val height = 1600
        val bitmap = createBitmap(width, height)
        val canvas = Canvas(bitmap)

        // Background Gradient
        val bgPaint = Paint().apply {
            shader = LinearGradient(
                0f, 0f, width.toFloat(), height.toFloat(),
                intArrayOf(0xFF0F0C20.toInt(), 0xFF1B1736.toInt(), 0xFF0D0B18.toInt()),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Decorative background glow
        val glowPaint = Paint().apply {
            shader = LinearGradient(
                200f, 100f, 1000f, 500f,
                intArrayOf(0x358252FE.toInt(), 0x10A855F7.toInt(), 0x00000000),
                null,
                Shader.TileMode.CLAMP
            )
            isAntiAlias = true
        }
        canvas.drawCircle(width / 2f, 250f, 600f, glowPaint)

        // Header Section
        var currentY = 90f

        // App Brand Name
        val brandPaint = TextPaint().apply {
            color = 0xFFA78BFA.toInt()
            textSize = 34f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
            letterSpacing = 0.2f
        }
        canvas.drawText("METROLIST MUSIC", 80f, currentY, brandPaint)
        currentY += 50f

        // Main Title
        val titlePaint = TextPaint().apply {
            color = 0xFFFFFFFF.toInt()
            textSize = 62f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText("Your Top Played Tracks", 80f, currentY, titlePaint)
        currentY += 45f

        // Period Badge
        val badgeBgPaint = Paint().apply {
            color = 0x2E8252FE.toInt()
            isAntiAlias = true
        }
        val badgeTextPaint = TextPaint().apply {
            color = 0xFFC4B5FD.toInt()
            textSize = 28f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }
        val badgeText = "PERIOD: ${periodName.uppercase()}"
        val badgeWidth = badgeTextPaint.measureText(badgeText) + 40f
        val badgeRect = RectF(80f, currentY, 80f + badgeWidth, currentY + 46f)
        canvas.drawRoundRect(badgeRect, 23f, 23f, badgeBgPaint)
        canvas.drawText(badgeText, 100f, currentY + 32f, badgeTextPaint)

        currentY += 80f

        // Song Items Cards
        val cardMarginX = 80f
        val cardWidth = width - (cardMarginX * 2)
        val cardHeight = if (displaySongs.size > 6) 120f else 135f
        val cardSpacing = 16f

        val imageLoader = ImageLoader(context)

        displaySongs.forEachIndexed { index, song ->
            val rank = index + 1
            val cardRect = RectF(cardMarginX, currentY, cardMarginX + cardWidth, currentY + cardHeight)

            // Card Background
            val cardBgPaint = Paint().apply {
                color = 0xCC1E1B38.toInt()
                isAntiAlias = true
            }
            canvas.drawRoundRect(cardRect, 20f, 20f, cardBgPaint)

            // Rank Badge Color
            val rankColor = when (rank) {
                1 -> 0xFFFFD700.toInt() // Gold
                2 -> 0xFFE0E0E0.toInt() // Silver
                3 -> 0xFFCD7F32.toInt() // Bronze
                else -> 0xFF8B8BAE.toInt()
            }

            val rankTextPaint = TextPaint().apply {
                color = rankColor
                textSize = 36f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }
            val rankStr = "#$rank"
            canvas.drawText(rankStr, cardMarginX + 30f, currentY + (cardHeight / 2f) + 12f, rankTextPaint)

            // Cover Thumbnail
            val thumbSize = cardHeight - 30f
            val thumbLeft = cardMarginX + 110f
            val thumbTop = currentY + 15f
            val thumbRect = RectF(thumbLeft, thumbTop, thumbLeft + thumbSize, thumbTop + thumbSize)

            var loadedBitmap: Bitmap? = null
            if (!song.thumbnailUrl.isNullOrEmpty()) {
                try {
                    val request = ImageRequest.Builder(context)
                        .data(song.thumbnailUrl)
                        .size(200)
                        .allowHardware(false)
                        .build()
                    val result = imageLoader.execute(request)
                    loadedBitmap = result.image?.toBitmap()
                } catch (_: Exception) {
                }
            }

            if (loadedBitmap != null) {
                val clipPath = Path().apply {
                    addRoundRect(thumbRect, 14f, 14f, Path.Direction.CW)
                }
                canvas.save()
                canvas.clipPath(clipPath)
                canvas.drawBitmap(loadedBitmap, null, thumbRect, Paint(Paint.FILTER_BITMAP_FLAG))
                canvas.restore()
            } else {
                val placeholderPaint = Paint().apply {
                    color = 0xFF2D2A4A.toInt()
                    isAntiAlias = true
                }
                canvas.drawRoundRect(thumbRect, 14f, 14f, placeholderPaint)
            }

            // Text Info Positions
            val textLeft = thumbLeft + thumbSize + 25f
            val textRightLimit = cardMarginX + cardWidth - 170f

            // Song Title
            val songTitlePaint = TextPaint().apply {
                color = 0xFFFFFFFF.toInt()
                textSize = 32f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }

            val artistNameStr = if (song.artists.isNotEmpty()) {
                song.artists.joinToString(", ") { it.name }
            } else {
                song.artistName ?: "Unknown Artist"
            }

            val artistPaint = TextPaint().apply {
                color = 0xFFA5A5C7.toInt()
                textSize = 24f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                isAntiAlias = true
            }

            // Truncate title
            val maxTextWidth = textRightLimit - textLeft
            var songTitle = song.title
            if (songTitlePaint.measureText(songTitle) > maxTextWidth) {
                while (songTitle.length > 3 && songTitlePaint.measureText("$songTitle…") > maxTextWidth) {
                    songTitle = songTitle.dropLast(1)
                }
                songTitle = "$songTitle…"
            }

            var artistText = artistNameStr
            if (artistPaint.measureText(artistText) > maxTextWidth) {
                while (artistText.length > 3 && artistPaint.measureText("$artistText…") > maxTextWidth) {
                    artistText = artistText.dropLast(1)
                }
                artistText = "$artistText…"
            }

            canvas.drawText(songTitle, textLeft, currentY + 52f, songTitlePaint)
            canvas.drawText(artistText, textLeft, currentY + 88f, artistPaint)

            // Plays & Duration Pill on the Right
            val playCountText = "${song.songCountListened} plays"
            val statTextPaint = TextPaint().apply {
                color = 0xFFDDDDF2.toInt()
                textSize = 24f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }

            val playCountWidth = statTextPaint.measureText(playCountText)
            val statX = cardMarginX + cardWidth - 30f - playCountWidth
            canvas.drawText(playCountText, statX, currentY + (cardHeight / 2f) + 8f, statTextPaint)

            currentY += cardHeight + cardSpacing
        }

        // Footer Section
        val footerY = height - 90f
        val footerDividerPaint = Paint().apply {
            color = 0x33FFFFFF.toInt()
            strokeWidth = 2f
        }
        canvas.drawLine(80f, footerY, width - 80f, footerY, footerDividerPaint)

        val footerTextPaint = TextPaint().apply {
            color = 0xFF8A8AAB.toInt()
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
        }
        canvas.drawText("Generated with Metrolist Music", 80f, footerY + 45f, footerTextPaint)

        bitmap
    }

    fun shareText(context: Context, text: String, title: String = "Share Statistics") {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
            putExtra(Intent.EXTRA_SUBJECT, title)
        }
        context.startActivity(Intent.createChooser(intent, title))
    }

    fun shareFile(context: Context, file: File, mimeType: String, title: String = "Share File") {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.FileProvider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, title))
    }

    fun shareBitmapImage(context: Context, bitmap: Bitmap, fileName: String, title: String = "Share Summary") {
        val uri = ComposeToImage.saveBitmapAsFile(context, bitmap, fileName)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, title))
    }
}
