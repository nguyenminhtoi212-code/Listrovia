package androidx.compose.material3

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.Indication
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.graphics.shapes.RoundedPolygon

@Target(AnnotationTarget.CLASS, AnnotationTarget.FUNCTION, AnnotationTarget.PROPERTY)
@Retention(AnnotationRetention.BINARY)
@RequiresOptIn(level = RequiresOptIn.Level.WARNING)
annotation class ExperimentalMaterial3ExpressiveApi

@Composable
fun CircularWavyProgressIndicator(
    progress: () -> Float,
    modifier: Modifier = Modifier,
    color: Color = ProgressIndicatorDefaults.circularColor,
    trackColor: Color = ProgressIndicatorDefaults.circularTrackColor,
) {
    CircularProgressIndicator(
        progress = progress(),
        modifier = modifier,
        color = color,
        trackColor = trackColor
    )
}

@Composable
fun LinearWavyProgressIndicator(
    progress: () -> Float,
    modifier: Modifier = Modifier,
    color: Color = ProgressIndicatorDefaults.linearColor,
    trackColor: Color = ProgressIndicatorDefaults.linearTrackColor,
    stroke: Any? = null,
    trackStroke: Any? = null,
    gapSize: Any? = null,
    stopSize: Any? = null,
    amplitude: Any? = null,
    wavelength: Any? = null,
    waveSpeed: Any? = null,
) {
    LinearProgressIndicator(
        progress = progress(),
        modifier = modifier,
        color = color,
        trackColor = trackColor
    )
}

object WavyProgressIndicatorDefaults {
    val LinearDeterminateWavelength = 20.dp
    val LinearContainerHeight = 10.dp
    val LinearTrackStopIndicatorSize = 4.dp
}

@Composable
fun ContainedLoadingIndicator(
    modifier: Modifier = Modifier,
) {
    CircularProgressIndicator(modifier = modifier)
}

@Composable
fun LoadingIndicator(
    modifier: Modifier = Modifier,
    color: Color = ProgressIndicatorDefaults.circularColor,
) {
    CircularProgressIndicator(modifier = modifier, color = color)
}

@Suppress("DEPRECATION_ERROR", "DEPRECATION")
@Composable
fun ripple(
    bounded: Boolean = true,
    radius: Dp = Dp.Unspecified,
    color: Color = Color.Unspecified,
): Indication {
    return rememberRipple(bounded = bounded, radius = radius, color = color)
}

object MaterialShapes {
    val Cookie9Sided = RoundedPolygon(numVertices = 9)
    val Cookie4Sided = RoundedPolygon(numVertices = 4)
    val Cookie12Sided = RoundedPolygon(numVertices = 12)
}

fun RoundedPolygon.toShape(): Shape {
    return RoundedCornerShape(12.dp)
}
