/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

@file:Suppress("LocalVariableName")

package com.listrovia.music.ui.utils

import com.listrovia.innertube.InnerTubeVisualNormalizer

fun String.resize(
    width: Int? = null,
    height: Int? = null,
): String {
    return InnerTubeVisualNormalizer.resizeAndNormalizeUrl(
        url = this,
        width = width,
        height = height,
        forceSquareCrop = (width != null && height != null && width == height)
    )
}

