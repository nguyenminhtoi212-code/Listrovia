/**
 * Auramusic Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.video

import android.media.AudioManager
import android.view.ViewGroup
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SecondaryScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil3.compose.AsyncImage
import com.listrovia.music.LocalVideoMiniPlayerBottomPadding
import com.listrovia.music.R
import com.listrovia.music.utils.AuraPlayerUtils.VideoQuality
import com.listrovia.music.video.VideoPlaybackManager.CommentItem
import com.listrovia.music.video.VideoPlaybackManager.RecommendationItem
import com.listrovia.innertube.YouTube
import com.listrovia.innertube.PlaylistItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun VideoPlayerOverlay(
    onChannelClick: ((String) -> Unit)? = null,
) {
    val state by VideoPlaybackManager.uiState.collectAsState()
    val session = state.session ?: return
    // When a music session takes over (video paused via giveWayToMusic), the video
    // player and its mini tile fully disappear — mirror of video playback hiding the
    // music mini player. The video session stays alive underneath so a later play
    // (or history reselect) can start it again.
    if (state.hiddenByMusic) return

    val context = LocalContext.current
    val player = VideoPlaybackManager.playerOrNull() ?: return
    val activity = context as? android.app.Activity

    DisposableEffect(activity, state.minimized) {
        if (activity != null && !state.minimized) {
            activity.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        onDispose {
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    BackHandler(enabled = !state.minimized) {
        VideoPlaybackManager.collapse()
    }

    val isInPip by VideoPlaybackService.isInPipMode.collectAsState()
    if (isInPip) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        this.player = player
                        useController = false
                        resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }
        return
    }

    AnimatedContent(
        targetState = state.minimized,
        transitionSpec = {
            if (targetState) {
                (fadeIn(tween(200)) + scaleIn(tween(260))).togetherWith(fadeOut(tween(140)) + scaleOut(tween(200)))
            } else {
                (fadeIn(tween(220)) + scaleIn(tween(300))).togetherWith(fadeOut(tween(160)))
            }
        },
        label = "videoPlayerState"
    ) { minimized ->
        if (minimized) {
            VideoMinimizedTile(
                player = player,
                onExpand = { VideoPlaybackManager.expand() },
                onClose = { VideoPlaybackManager.close() },
                onChannelClick = onChannelClick,
            )
        } else {
            // Navigating to a channel while expanded would leave the full-screen
            // overlay covering it, so minimize the player first so the channel
            // screen is actually visible.
            val expandedChannelClick: ((String) -> Unit)? = onChannelClick?.let { click ->
                { channelId ->
                    VideoPlaybackManager.collapse()
                    click(channelId)
                }
            }
            VideoExpandedPlayer(
                player = player,
                session = session,
                uiState = state,
                onCollapse = { VideoPlaybackManager.collapse() },
                onClose = { VideoPlaybackManager.close() },
                onChannelClick = expandedChannelClick,
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Mini player
// ---------------------------------------------------------------------------

@OptIn(UnstableApi::class)
@Composable
private fun VideoMinimizedTile(
    player: ExoPlayer,
    onExpand: () -> Unit,
    onClose: () -> Unit,
    onChannelClick: ((String) -> Unit)?,
) {
    val state by VideoPlaybackManager.uiState.collectAsState()
    val positionPair by VideoPlaybackManager.positionState.collectAsState()
    val posMs = positionPair.first
    val durMs = positionPair.second
    val density = LocalDensity.current

    var dragPx by remember { mutableFloatStateOf(0f) }
    val animatedDragPx by animateFloatAsState(
        targetValue = dragPx,
        animationSpec = tween(durationMillis = 220),
        label = "miniDragPx",
    )
    val dismissProgress = (dragPx / 360f).coerceIn(0f, 1f)

    Box(modifier = Modifier.fillMaxSize()) {
        Surface(
            onClick = onExpand,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .offset(y = with(density) { animatedDragPx.toDp() })
                .graphicsLayer {
                    scaleX = 1f - 0.05f * dismissProgress
                    scaleY = 1f - 0.05f * dismissProgress
                    alpha = 1f - 0.4f * dismissProgress
                }
                .padding(horizontal = 12.dp)
                .padding(bottom = LocalVideoMiniPlayerBottomPadding.current)
                .fillMaxWidth()
                .height(76.dp)
                .shadow(16.dp, RoundedCornerShape(20.dp)),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHighest,
            tonalElevation = 6.dp,
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        modifier = Modifier
                            .width(108.dp)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.Black)
                            .pointerInput(Unit) {
                                detectVerticalDragGestures(
                                    onDragEnd = {
                                        if (dragPx > with(density) { 100.dp.toPx() }) {
                                            onClose()
                                        } else {
                                            dragPx = 0f
                                        }
                                    },
                                    onDragCancel = { dragPx = 0f },
                                ) { change, dragAmount ->
                                    if (dragAmount > 0f) {
                                        dragPx = (dragPx + dragAmount).coerceIn(0f, 400f)
                                        change.consume()
                                    }
                                }
                            }
                    ) {
                        if (state.playbackMode == VideoPlaybackManager.PlaybackMode.VIDEO_PLAYBACK) {
                            AndroidVideoSurface(player, resizeModeOverride = state.resizeMode)
                        } else {
                            val thumb = state.session?.channelThumbnail
                            if (thumb != null) {
                                AsyncImage(
                                    model = thumb,
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Text(
                            text = state.session?.title.orEmpty(),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        if (!state.session?.channelName.isNullOrBlank()) {
                            Text(
                                text = state.session?.channelName.orEmpty(),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.clickable {
                                    state.session?.channelId?.let { onChannelClick?.invoke(it) }
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Play/Pause button
                    Surface(
                        onClick = { VideoPlaybackManager.togglePlayPause() },
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(38.dp),
                        tonalElevation = 2.dp,
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            if (state.isBuffering) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(
                                    painter = painterResource(if (state.isPlaying) R.drawable.pause else R.drawable.play),
                                    contentDescription = stringResource(
                                        if (state.isPlaying) R.string.pause else R.string.play
                                    ),
                                    modifier = Modifier.size(20.dp),
                                    tint = MaterialTheme.colorScheme.onPrimary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Close button
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.close),
                            contentDescription = stringResource(R.string.close),
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                        )
                    }
                }

                // Bottom progress line
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(2.5.dp)
                        .align(Alignment.BottomCenter)
                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth((if (durMs > 0) (posMs.toFloat() / durMs.toFloat()).coerceIn(0f, 1f) else 0f))
                            .height(2.5.dp)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                                        MaterialTheme.colorScheme.primary
                                    )
                                )
                            )
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Expanded player
// ---------------------------------------------------------------------------

@OptIn(UnstableApi::class)
@Composable
private fun VideoExpandedPlayer(
    player: ExoPlayer,
    session: VideoPlaybackManager.VideoSession,
    uiState: VideoPlaybackManager.UiState,
    onCollapse: () -> Unit,
    onClose: () -> Unit,
    onChannelClick: ((String) -> Unit)?,
) {
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    val isWideScreen = configuration.screenWidthDp >= 600
    val context = LocalContext.current
    val positionPair by VideoPlaybackManager.positionState.collectAsState()
    val posMs = positionPair.first
    val durMs = positionPair.second

    var showControls by remember { mutableStateOf(true) }

    LaunchedEffect(uiState.isPlaying, showControls) {
        if (uiState.isPlaying && showControls) {
            delay(3000)
            showControls = false
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        if (isLandscape && isWideScreen) {
            Row(modifier = Modifier.fillMaxSize()) {
                VideoSurfaceWithControls(
                    player = player,
                    session = session,
                    uiState = uiState,
                    showControls = showControls,
                    onToggleControls = { showControls = !showControls },
                    onCollapse = onCollapse,
                    onClose = onClose,
                    modifier = Modifier
                        .weight(0.62f)
                        .fillMaxHeight(),
                    useFullHeight = true,
                    onChannelClick = onChannelClick,
                )
                VideoDetailPane(
                    session = session,
                    uiState = uiState,
                    modifier = Modifier
                        .weight(0.38f)
                        .fillMaxHeight()
                        .background(MaterialTheme.colorScheme.surface),
                    onChannelClick = onChannelClick ?: {},
                )
            }
        } else if (isLandscape) {
            // Phone landscape: the screen height is small, so a 16:9 video at full
            // width would overflow it. Play the surface full-screen (the player's
            // RESIZE_MODE_FIT letterboxes it) and overlay a compact title + actions
            // bar that appears together with the controls.
            Box(modifier = Modifier.fillMaxSize()) {
                VideoSurfaceWithControls(
                    player = player,
                    session = session,
                    uiState = uiState,
                    showControls = showControls,
                    onToggleControls = { showControls = !showControls },
                    onCollapse = onCollapse,
                    onClose = onClose,
                    modifier = Modifier.fillMaxSize(),
                    useFullHeight = true,
                    onChannelClick = onChannelClick,
                )
                AnimatedVisibility(
                    visible = showControls,
                    enter = fadeIn(tween(200)),
                    exit = fadeOut(tween(200)),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                ) {
                    CompactLandscapeBar(
                        session = session,
                        uiState = uiState,
                        onChannelClick = onChannelClick ?: {},
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        } else if (isWideScreen) {
            // Tablet portrait: split video | details across the width so the tall
            // 16:9 surface doesn't eat the whole screen and squash the details.
            Row(modifier = Modifier.fillMaxSize()) {
                VideoSurfaceWithControls(
                    player = player,
                    session = session,
                    uiState = uiState,
                    showControls = showControls,
                    onToggleControls = { showControls = !showControls },
                    onCollapse = onCollapse,
                    onClose = onClose,
                    modifier = Modifier
                        .weight(0.62f)
                        .fillMaxHeight(),
                    useFullHeight = true,
                    onChannelClick = onChannelClick,
                )
                VideoDetailPane(
                    session = session,
                    uiState = uiState,
                    modifier = Modifier
                        .weight(0.38f)
                        .fillMaxHeight()
                        .background(MaterialTheme.colorScheme.surface),
                    onChannelClick = onChannelClick ?: {},
                )
            }
        } else {
            Column(modifier = Modifier.fillMaxSize()) {
                VideoSurfaceWithControls(
                    player = player,
                    session = session,
                    uiState = uiState,
                    showControls = showControls,
                    onToggleControls = { showControls = !showControls },
                    onCollapse = onCollapse,
                    onClose = onClose,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 12f),
                    useFullHeight = false,
                    onChannelClick = onChannelClick,
                )
                VideoDetailPane(
                    session = session,
                    uiState = uiState,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(MaterialTheme.colorScheme.surface),
                    onChannelClick = onChannelClick ?: {},
                )
            }
        }

        if (uiState.showSettings) {
            com.listrovia.music.ui.player.VideoSettingsBottomSheet(
                onDismissRequest = { VideoPlaybackManager.toggleSettings() },
                currentSpeed = uiState.playbackSpeed,
                onSpeedSelected = { VideoPlaybackManager.setPlaybackSpeed(it) },
                currentQuality = when (uiState.videoQuality) {
                    com.listrovia.music.utils.AuraPlayerUtils.VideoQuality.QUALITY_1080P -> "1080p"
                    com.listrovia.music.utils.AuraPlayerUtils.VideoQuality.QUALITY_720P -> "720p"
                    com.listrovia.music.utils.AuraPlayerUtils.VideoQuality.QUALITY_480P -> "480p"
                    com.listrovia.music.utils.AuraPlayerUtils.VideoQuality.QUALITY_360P -> "360p"
                    else -> "Tự động"
                },
                onQualitySelected = { q ->
                    val qualityEnum = when (q) {
                        "1080p" -> com.listrovia.music.utils.AuraPlayerUtils.VideoQuality.QUALITY_1080P
                        "720p" -> com.listrovia.music.utils.AuraPlayerUtils.VideoQuality.QUALITY_720P
                        "480p" -> com.listrovia.music.utils.AuraPlayerUtils.VideoQuality.QUALITY_480P
                        "360p" -> com.listrovia.music.utils.AuraPlayerUtils.VideoQuality.QUALITY_360P
                        else -> com.listrovia.music.utils.AuraPlayerUtils.VideoQuality.QUALITY_720P
                    }
                    VideoPlaybackManager.setVideoQuality(qualityEnum)
                },
                isLoopEnabled = uiState.isLoopVideoEnabled,
                onToggleLoop = { VideoPlaybackManager.setLoopVideoEnabled(it) },
                onOpenSyncPlayer = {
                    VideoPlaybackManager.launchYouTubeSyncPlayer(context, session.videoId)
                    VideoPlaybackManager.toggleSettings()
                },
                onOpenFullscreen = {
                    VideoPlaybackManager.expand()
                    VideoPlaybackManager.toggleSettings()
                },
                onReloadVideo = {
                    VideoPlaybackManager.toggleSettings()
                },
                activeVideoId = session.videoId
            )
        }
    }
}

/**
 * The 16:9 video area: surface + one coherent gesture layer (tap toggles controls,
 * double-tap sides seek ±10s, vertical drag collapses, horizontal drag scrubs).
 */
@OptIn(UnstableApi::class)
@Composable
private fun VideoSurfaceWithControls(
    player: ExoPlayer,
    session: VideoPlaybackManager.VideoSession,
    uiState: VideoPlaybackManager.UiState,
    showControls: Boolean,
    onToggleControls: () -> Unit,
    onCollapse: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
    useFullHeight: Boolean,
    onChannelClick: ((String) -> Unit)? = null,
) {
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    val context = LocalContext.current
    val audioManager = context.getSystemService(AudioManager::class.java)
    val activity = context as? android.app.Activity
    val positionPair by VideoPlaybackManager.positionState.collectAsState()
    val posMs = positionPair.first
    val durMs = positionPair.second

    val defaultBrightness: Float = runCatching {
        val value = android.provider.Settings.System.getInt(
            context.contentResolver,
            android.provider.Settings.System.SCREEN_BRIGHTNESS,
        )
        value / 255f
    }.getOrDefault(0.5f)

    var collapseDragPx by remember { mutableFloatStateOf(0f) }
    var scrubPreviewMs by remember { mutableStateOf<Long?>(null) }
    var isForward by remember { mutableStateOf(true) }
    var seekHint by remember { mutableStateOf<String?>(null) }
    var adjustPreview by remember {
        mutableStateOf<AdjustPreview?>(null)
    }
    val seekForwardLabel = stringResource(R.string.seek_forward_dynamic)
    val seekBackwardLabel = stringResource(R.string.seek_backward_dynamic)

    // Restore system brightness when leaving the expanded player so the window
    // brightness override set by the vertical gesture doesn't persist.
    DisposableEffect(activity) {
        onDispose {
            activity?.window?.let { window ->
                val attrs = window.attributes
                if (attrs.screenBrightness >= 0f) {
                    attrs.screenBrightness = -1f
                    window.attributes = attrs
                }
            }
        }
    }

    LaunchedEffect(seekHint) {
        if (seekHint != null) {
            delay(700)
            seekHint = null
        }
    }

    LaunchedEffect(adjustPreview) {
        if (adjustPreview != null) {
            delay(800)
            adjustPreview = null
        }
    }

    val collapseFraction = if (useFullHeight) 0f else (collapseDragPx / 900f).coerceIn(0f, 0.75f)

    Box(
        modifier = modifier
            .graphicsLayer {
                translationY = collapseDragPx
                alpha = 1f - collapseFraction
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = {
                        onToggleControls()
                        if (!showControls) {
                            haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                        }
                    },
                    onDoubleTap = { offset ->
                        val side = when {
                            offset.x < size.width / 3 -> -1
                            offset.x > size.width * 2 / 3 -> 1
                            else -> 0
                        }
                        if (side == 0) {
                            onToggleControls()
                        } else {
                            val target = (VideoPlaybackManager.uiState.value.positionMs + side * 10_000L)
                                .coerceIn(0L, VideoPlaybackManager.uiState.value.durationMs)
                            VideoPlaybackManager.seekTo(target)
                            isForward = side > 0
                            seekHint = if (side > 0) seekForwardLabel else seekBackwardLabel
                            haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                        }
                    }
                )
            }
            .pointerInput(useFullHeight) {
                var dragMode = DragMode.NONE
                detectVerticalDragGestures(
                    onDragStart = { offset ->
                        dragMode = when {
                            offset.x < size.width / 3f -> DragMode.BRIGHTNESS
                            offset.x > size.width * 2f / 3f -> DragMode.VOLUME
                            !useFullHeight -> DragMode.COLLAPSE
                            else -> DragMode.NONE
                        }
                    },
                    onDragEnd = {
                        when (dragMode) {
                            DragMode.COLLAPSE -> {
                                if (collapseDragPx > with(density) { 120.dp.toPx() }) onCollapse() else collapseDragPx = 0f
                            }
                            else -> collapseDragPx = 0f
                        }
                        dragMode = DragMode.NONE
                    },
                    onDragCancel = {
                        collapseDragPx = 0f
                        dragMode = DragMode.NONE
                    },
                ) { change, dragAmount ->
                    when (dragMode) {
                        DragMode.COLLAPSE -> {
                            if (dragAmount > 0f) {
                                collapseDragPx = (collapseDragPx + dragAmount).coerceIn(0f, 800f)
                                change.consume()
                            }
                        }
                        DragMode.BRIGHTNESS -> {
                            change.consume()
                            val delta = -dragAmount / size.height
                            val base = activity?.window?.attributes?.screenBrightness
                                ?.takeIf { it >= 0f }
                                ?: defaultBrightness
                            val newBrightness = (base + delta * 1.2f).coerceIn(0.05f, 1f)
                            activity?.window?.let { window ->
                                val attrs = window.attributes
                                attrs.screenBrightness = newBrightness
                                window.attributes = attrs
                            }
                            adjustPreview = AdjustPreview(DragMode.BRIGHTNESS, newBrightness)
                            haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                        }
                        DragMode.VOLUME -> {
                            change.consume()
                            val max = audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: return@detectVerticalDragGestures
                            val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                            val target = (current + (-dragAmount / size.height) * max * 1.2f)
                                .toInt()
                                .coerceIn(0, max)
                            if (target != current) {
                                audioManager.setStreamVolume(
                                    AudioManager.STREAM_MUSIC,
                                    target,
                                    0,
                                )
                            }
                            adjustPreview = AdjustPreview(DragMode.VOLUME, target.toFloat() / max.coerceAtLeast(1))
                            haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                        }
                        DragMode.NONE -> Unit
                    }
                }
            }
            .pointerInput(durMs) {
                var dragBaseMs = 0L
                detectHorizontalDragGestures(
                    onDragStart = {
                        dragBaseMs = VideoPlaybackManager.uiState.value.positionMs
                    },
                    onDragEnd = {
                        scrubPreviewMs?.let { VideoPlaybackManager.seekTo(it) }
                        scrubPreviewMs = null
                    },
                    onDragCancel = {
                        scrubPreviewMs = null
                    },
                ) { change, dragAmount ->
                    change.consume()
                    val deltaMs = dragAmount.toDp().value * 50f
                    isForward = dragAmount > 0
                    scrubPreviewMs = (dragBaseMs + deltaMs.toLong())
                        .coerceIn(0L, durMs)
                }
            }
    ) {
        if (uiState.playbackMode == VideoPlaybackManager.PlaybackMode.VIDEO_PLAYBACK) {
            AndroidVideoSurface(player, resizeModeOverride = uiState.resizeMode)
        } else {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                val thumb = session.channelThumbnail
                if (thumb != null) {
                    AsyncImage(
                        model = thumb,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                        alpha = 0.35f
                    )
                    AsyncImage(
                        model = thumb,
                        contentDescription = null,
                        modifier = Modifier
                            .fillMaxWidth(0.65f)
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .shadow(12.dp, RoundedCornerShape(16.dp)),
                        contentScale = ContentScale.Crop
                    )
                }
            }
        }

        if (showControls) {
            // Left side vertical Brightness slider bar
            val currentBrightness = activity?.window?.attributes?.screenBrightness?.takeIf { it >= 0f } ?: defaultBrightness
            VerticalBrightnessBar(
                brightnessFraction = currentBrightness,
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 16.dp)
            )

            // Right side vertical Volume bar
            val maxVol = audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 1
            val currVol = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 0
            val volFraction = currVol.toFloat() / maxVol.coerceAtLeast(1)
            VerticalVolumeBar(
                volumeFraction = volFraction,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 16.dp)
            )

            PlayerTopBar(
                onCollapse = onCollapse,
                onClose = onClose,
                title = session.title,
                channelName = session.channelName,
                channelId = session.channelId,
                onChannelClick = onChannelClick,
                uiState = uiState,
                modifier = Modifier.align(Alignment.TopCenter),
            )
            PlayerBottomControls(
                uiState = uiState,
                posMs = posMs,
                durMs = durMs,
                modifier = Modifier.align(Alignment.BottomCenter),
            )
        }

        seekHint?.let { hint ->
            SeekHintBadge(
                hint = hint,
                isForward = isForward,
                modifier = Modifier.align(Alignment.Center),
            )
        }

        scrubPreviewMs?.let { preview ->
            SeekPreviewBadge(
                previewMs = preview,
                positionMs = posMs,
                isForward = isForward,
                modifier = Modifier.align(Alignment.Center),
            )
        }

        adjustPreview?.let { preview ->
            AdjustPreviewBadge(
                mode = preview.mode,
                fraction = preview.fraction,
                modifier = Modifier.align(Alignment.Center),
            )
        }
    }
}

@Composable
private fun PlayerTopBar(
    onCollapse: () -> Unit,
    onClose: () -> Unit,
    onChannelClick: ((String) -> Unit)?,
    title: String,
    channelName: String,
    channelId: String? = null,
    uiState: VideoPlaybackManager.UiState,
    modifier: Modifier = Modifier,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    listOf(Color.Black.copy(alpha = 0.6f), Color.Transparent)
                )
            )
            .windowInsetsPadding(WindowInsets.statusBars)
            .padding(start = 8.dp, end = 8.dp, top = 8.dp, bottom = 14.dp)
    ) {
        Surface(
            onClick = onCollapse,
            shape = CircleShape,
            color = Color.Black.copy(alpha = 0.45f),
            modifier = Modifier.size(40.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    painter = painterResource(R.drawable.expand_less),
                    contentDescription = stringResource(R.string.collapse_video),
                    modifier = Modifier.size(24.dp),
                    tint = Color.White
                )
            }
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 4.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (channelName.isNotBlank()) {
                Text(
                    text = channelName,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.75f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .clickable {
                            channelId?.let { onChannelClick?.invoke(it) }
                        }
                )
            }
        }
        Surface(
            onClick = {
                val nextMode = if (uiState.playbackMode == VideoPlaybackManager.PlaybackMode.VIDEO_PLAYBACK)
                    VideoPlaybackManager.PlaybackMode.AUDIO_ONLY
                else
                    VideoPlaybackManager.PlaybackMode.VIDEO_PLAYBACK
                VideoPlaybackManager.setPlaybackMode(nextMode)
            },
            shape = CircleShape,
            color = Color.Black.copy(alpha = 0.45f),
            modifier = Modifier.size(40.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    painter = painterResource(
                        if (uiState.playbackMode == VideoPlaybackManager.PlaybackMode.VIDEO_PLAYBACK) R.drawable.music_note
                        else R.drawable.video_mode
                    ),
                    contentDescription = stringResource(
                        if (uiState.playbackMode == VideoPlaybackManager.PlaybackMode.VIDEO_PLAYBACK) R.string.audio_playback
                        else R.string.video_playback
                    ),
                    modifier = Modifier.size(20.dp),
                    tint = Color.White
                )
            }
        }
        Spacer(modifier = Modifier.width(8.dp))
        val context = LocalContext.current
        if (VideoPlaybackService.supportsPictureInPicture(context)) {
            Surface(
                onClick = {
                    (context as? android.app.Activity)?.let { act ->
                        VideoPlaybackService.enterPictureInPicture(act)
                    }
                },
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.45f),
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        painter = painterResource(R.drawable.ic_pip),
                        contentDescription = stringResource(R.string.video_pip_title),
                        modifier = Modifier.size(20.dp),
                        tint = Color.White
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
        }
        Surface(
            onClick = { VideoPlaybackManager.toggleOrientationLock(context) },
            shape = CircleShape,
            color = if (uiState.isOrientationLocked) MaterialTheme.colorScheme.primary.copy(alpha = 0.85f) else Color.Black.copy(alpha = 0.45f),
            modifier = Modifier.size(40.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    painter = painterResource(if (uiState.isOrientationLocked) R.drawable.lock else R.drawable.lock_open),
                    contentDescription = stringResource(
                        if (uiState.isOrientationLocked) R.string.screen_orientation_locked else R.string.screen_orientation_unlocked
                    ),
                    modifier = Modifier.size(20.dp),
                    tint = Color.White
                )
            }
        }
        Spacer(modifier = Modifier.width(8.dp))
        Surface(
            onClick = { VideoPlaybackManager.toggleSettings() },
            shape = CircleShape,
            color = Color.Black.copy(alpha = 0.45f),
            modifier = Modifier.size(40.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    painter = painterResource(R.drawable.settings),
                    contentDescription = stringResource(R.string.video_quality),
                    modifier = Modifier.size(20.dp),
                    tint = Color.White
                )
            }
        }
        Spacer(modifier = Modifier.width(8.dp))
        Surface(
            onClick = onClose,
            shape = CircleShape,
            color = Color.Black.copy(alpha = 0.45f),
            modifier = Modifier.size(40.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    painter = painterResource(R.drawable.close),
                    contentDescription = stringResource(R.string.close),
                    modifier = Modifier.size(20.dp),
                    tint = Color.White
                )
            }
        }
    }
}

@Composable
private fun PlayerBottomControls(
    uiState: VideoPlaybackManager.UiState,
    posMs: Long = uiState.positionMs,
    durMs: Long = uiState.durationMs,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f))
                )
            )
            .padding(top = 20.dp, bottom = 6.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            Surface(
                onClick = { VideoPlaybackManager.playPrevious() },
                shape = CircleShape,
                color = Color.White.copy(alpha = 0.18f),
                modifier = Modifier.size(44.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        painter = painterResource(R.drawable.skip_previous),
                        contentDescription = stringResource(R.string.video_player_up_next),
                        modifier = Modifier.size(24.dp),
                        tint = Color.White
                    )
                }
            }
            Spacer(modifier = Modifier.width(24.dp))
            Surface(
                onClick = { VideoPlaybackManager.togglePlayPause() },
                shape = CircleShape,
                color = Color.White,
                modifier = Modifier.size(62.dp),
                tonalElevation = 4.dp,
            ) {
                Box(contentAlignment = Alignment.Center) {
                    if (uiState.isBuffering) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(28.dp),
                            color = Color.Black,
                            strokeWidth = 3.dp
                        )
                    } else {
                        Icon(
                            painter = painterResource(if (uiState.isPlaying) R.drawable.pause else R.drawable.play),
                            contentDescription = stringResource(
                                if (uiState.isPlaying) R.string.pause else R.string.play
                            ),
                            modifier = Modifier.size(32.dp),
                            tint = Color.Black
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.width(24.dp))
            Surface(
                onClick = { VideoPlaybackManager.playNext() },
                shape = CircleShape,
                color = Color.White.copy(alpha = 0.18f),
                modifier = Modifier.size(44.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        painter = painterResource(R.drawable.skip_next),
                        contentDescription = stringResource(R.string.video_player_up_next),
                        modifier = Modifier.size(24.dp),
                        tint = Color.White
                    )
                }
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
        ) {
            Text(
                text = formatTime(posMs),
                style = MaterialTheme.typography.labelMedium,
                color = Color.White.copy(alpha = 0.85f)
            )
            Spacer(modifier = Modifier.weight(1f))
            // Playback speed selector button
            Surface(
                onClick = {
                    val speedPresets = listOf(0.5f, 1.0f, 1.5f, 2.0f)
                    val currIdx = speedPresets.indexOf(uiState.playbackSpeed).let { if (it == -1) 1 else it }
                    val nextSpeed = speedPresets[(currIdx + 1) % speedPresets.size]
                    VideoPlaybackManager.setPlaybackSpeed(nextSpeed)
                },
                shape = RoundedCornerShape(8.dp),
                color = Color.White.copy(alpha = 0.2f),
                modifier = Modifier.padding(horizontal = 4.dp)
            ) {
                Text(
                    text = "${uiState.playbackSpeed}x",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
            Spacer(modifier = Modifier.width(4.dp))
            // Fullscreen toggle
            Surface(
                onClick = { VideoPlaybackManager.toggleFullScreen() },
                shape = CircleShape,
                color = Color.Transparent,
                modifier = Modifier.size(32.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        painter = painterResource(
                            if (uiState.isFullScreen) R.drawable.fullscreen
                            else R.drawable.fullscreen
                        ),
                        contentDescription = stringResource(R.string.close),
                        modifier = Modifier.size(20.dp),
                        tint = Color.White.copy(alpha = 0.85f)
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = formatTime(durMs),
                style = MaterialTheme.typography.labelMedium,
                color = Color.White.copy(alpha = 0.55f)
            )
        }

        SlimSeekBar(
            positionMs = posMs,
            durationMs = durMs,
            onSeek = { VideoPlaybackManager.seekTo(it) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp)
        )
    }
}

/**
 * YouTube-style slim progress bar: a thin track with a small thumb that can be
 * tapped or dragged to seek.
 */
@Composable
private fun SlimSeekBar(
    positionMs: Long,
    durationMs: Long,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    val durationSeconds = durationMs.toFloat().coerceAtLeast(1f)
    var scrub by remember { mutableFloatStateOf(-1f) }
    val effective = if (scrub >= 0f) scrub else positionMs.toFloat()
    val progress = (effective / durationSeconds).coerceIn(0f, 1f)

    val trackHeight = 3.dp
    val thumbSize = 13.dp

    BoxWithConstraints(
        modifier = modifier
            .height(20.dp)
            .pointerInput(durationSeconds) {
                detectDragGestures(
                    onDragStart = { offset ->
                        scrub = (offset.x / size.width * durationSeconds).coerceIn(0f, durationSeconds)
                    },
                    onDrag = { change, _ ->
                        scrub = (change.position.x / size.width * durationSeconds).coerceIn(0f, durationSeconds)
                        change.consume()
                    },
                    onDragEnd = {
                        scrub.takeIf { it >= 0f }?.let {
                            onSeek(it.toLong())
                            scrub = -1f
                        }
                    },
                    onDragCancel = { scrub = -1f },
                )
            }
            .pointerInput(durationSeconds) {
                detectTapGestures { offset ->
                    onSeek((offset.x / size.width * durationSeconds).coerceIn(0f, durationSeconds).toLong())
                }
            }
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.Center)
                .height(trackHeight)
                .clip(RoundedCornerShape(trackHeight / 2))
                .background(Color.White.copy(alpha = 0.3f))
        )
        Box(
            modifier = Modifier
                .fillMaxWidth(progress)
                .align(Alignment.CenterStart)
                .height(trackHeight)
                .clip(RoundedCornerShape(trackHeight / 2))
                .background(MaterialTheme.colorScheme.primary)
        )
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                // Thumb-center tracks the fill edge; subtracting the thumb size
                // keeps it fully on the track from 0% to 100% instead of being
                // parked mid-bar (Center + progress offset was off by half the
                // bar width) or sliding off either end.
                .offset(x = (maxWidth - thumbSize) * progress)
                .size(thumbSize)
                .clip(CircleShape)
                .background(Color.White)
                .shadow(3.dp, CircleShape)
        )
    }
}

@Composable
private fun SeekHintBadge(
    hint: String,
    isForward: Boolean,
    modifier: Modifier = Modifier,
) {
    val transition = rememberInfiniteTransition(label = "seekHint")
    val scale by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(tween(300), RepeatMode.Reverse),
        label = "seekScale"
    )
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .padding(8.dp)
    ) {
        Icon(
            painter = painterResource(if (isForward) R.drawable.fast_forward else R.drawable.replay),
            contentDescription = null,
            modifier = Modifier.size(44.dp),
            tint = Color.White
        )
        Text(
            text = hint,
            color = Color.White,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(12.dp))
                .padding(horizontal = 16.dp, vertical = 8.dp),
        )
    }
}

@Composable
private fun SeekPreviewBadge(
    previewMs: Long,
    positionMs: Long,
    isForward: Boolean,
    modifier: Modifier = Modifier,
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(12.dp))
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = formatTime(previewMs),
            color = Color.White,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
        )
        val deltaSec = (previewMs - positionMs) / 1000L
        if (deltaSec != 0L) {
            Text(
                text = (if (deltaSec > 0) "+" else "") + "${deltaSec}s",
                color = if (isForward) Color(0xFF8BC34A) else Color(0xFFFF8A65),
                style = MaterialTheme.typography.labelSmall,
            )
        }
    }
}

private enum class DragMode { NONE, BRIGHTNESS, VOLUME, COLLAPSE }

private data class AdjustPreview(
    val mode: DragMode,
    val fraction: Float,
)

@Composable
private fun AdjustPreviewBadge(
    mode: DragMode,
    fraction: Float,
    modifier: Modifier = Modifier,
) {
    val label = when (mode) {
        DragMode.BRIGHTNESS -> stringResource(R.string.video_player_brightness)
        else -> stringResource(R.string.video_player_volume)
    }
    val icon = when (mode) {
        DragMode.BRIGHTNESS -> R.drawable.contrast
        else -> R.drawable.volume_up
    }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(12.dp))
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Icon(
            painter = painterResource(icon),
            contentDescription = label,
            modifier = Modifier.size(30.dp),
            tint = Color.White,
        )
        Text(
            text = "${(fraction.coerceIn(0f, 1f) * 100).toInt()}%",
            color = Color.White,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
        )
    }
}

@Composable
private fun VerticalBrightnessBar(
    brightnessFraction: Float,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .width(28.dp)
            .height(120.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color.Black.copy(alpha = 0.55f))
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxSize()
        ) {
            Icon(
                painter = painterResource(R.drawable.contrast),
                contentDescription = stringResource(R.string.video_player_brightness),
                tint = Color.White,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.weight(1f))
            Box(
                modifier = Modifier
                    .width(8.dp)
                    .fillMaxHeight(brightnessFraction.coerceIn(0.08f, 1f))
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary)
            )
        }
    }
}

@Composable
private fun VerticalVolumeBar(
    volumeFraction: Float,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .width(28.dp)
            .height(120.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color.Black.copy(alpha = 0.55f))
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxSize()
        ) {
            Icon(
                painter = painterResource(R.drawable.volume_up),
                contentDescription = stringResource(R.string.video_player_volume),
                tint = Color.White,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.weight(1f))
            Box(
                modifier = Modifier
                    .width(8.dp)
                    .fillMaxHeight(volumeFraction.coerceIn(0.08f, 1f))
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary)
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Detail pane: title, channel row, actions, tabs (comments / up next)
// ---------------------------------------------------------------------------

@Composable
private fun VideoDetailPane(
    session: VideoPlaybackManager.VideoSession,
    uiState: VideoPlaybackManager.UiState,
    modifier: Modifier = Modifier,
    onChannelClick: (String) -> Unit,
) {
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(listState, uiState.comments.size, uiState.recommendations.size) {
        snapshotFlowSafe(listState) { nearEnd ->
            if (!nearEnd) return@snapshotFlowSafe
            val fresh = VideoPlaybackManager.uiState.value
            when {
                fresh.isLoadingMoreComments || fresh.isLoadingMoreRecommendations -> Unit
                else -> {
                    VideoPlaybackManager.loadMoreComments()
                    VideoPlaybackManager.loadMoreRecommendations()
                }
            }
        }
    }

    LazyColumn(
        state = listState,
        modifier = modifier,
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        item(key = "info") {
            VideoInfoSection(
                session = session,
                uiState = uiState,
                onChannelClick = onChannelClick,
            )
        }
        item(key = "tabs") {
            VideoTabs(uiState = uiState)
        }
    }
}

/** Small indirection so the effect body stays readable. */
private suspend fun snapshotFlowSafe(
    listState: androidx.compose.foundation.lazy.LazyListState,
    onNearEnd: suspend (Boolean) -> Unit,
) {
    androidx.compose.runtime.snapshotFlow {
        val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
        last >= listState.layoutInfo.totalItemsCount - 3
    }.collect { nearEnd -> onNearEnd(nearEnd) }
}

@Composable
private fun VideoInfoSection(
    session: VideoPlaybackManager.VideoSession,
    uiState: VideoPlaybackManager.UiState,
    onChannelClick: (String) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(
            text = session.title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )

        val metaLine = listOfNotNull(
            session.viewCountText,
            session.publishedTimeText,
        ).joinToString(" • ")
        if (metaLine.isNotBlank()) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = metaLine,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        ChannelRow(
            session = session,
            isSubscribed = uiState.isSubscribed,
            onSubscribeClick = { VideoPlaybackManager.toggleSubscribe() },
            onChannelClick = onChannelClick,
        )

        Spacer(modifier = Modifier.height(12.dp))

        ActionButtonsRow(
            isLiked = uiState.isLiked,
            isDisliked = uiState.isDisliked,
            isSaved = uiState.isSaved,
            likeCountText = session.likeCountText,
        )

        Spacer(modifier = Modifier.height(12.dp))

        session.description?.let { desc ->
            if (desc.isNotBlank()) {
                ExpandableDescription(
                    description = desc,
                    expanded = uiState.expandedDescription,
                    onToggle = { VideoPlaybackManager.toggleExpandedDescription() },
                )
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

/**
 * Compact title + actions bar overlaid at the bottom of the phone-landscape
 * player, where there's no room for the full detail pane next to the video.
 */
@Composable
private fun CompactLandscapeBar(
    session: VideoPlaybackManager.VideoSession,
    uiState: VideoPlaybackManager.UiState,
    onChannelClick: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        color = Color.Black.copy(alpha = 0.78f),
        modifier = modifier,
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = session.title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                CompactActionChip(
                    icon = R.drawable.thumb_up_filled,
                    selected = uiState.isLiked,
                    contentDescription = stringResource(R.string.video_player_like),
                    onClick = { VideoPlaybackManager.toggleLike() },
                )
                CompactActionChip(
                    icon = R.drawable.thumb_down_filled,
                    selected = uiState.isDisliked,
                    contentDescription = stringResource(R.string.video_player_dislike),
                    onClick = { VideoPlaybackManager.toggleDislike() },
                )
                CompactActionChip(
                    icon = if (uiState.isSaved) R.drawable.library_add_check else R.drawable.library_add,
                    selected = uiState.isSaved,
                    contentDescription = stringResource(if (uiState.isSaved) R.string.video_player_saved else R.string.video_player_save),
                    onClick = { VideoPlaybackManager.toggleSave() },
                )
                Spacer(modifier = Modifier.weight(1f))
                Surface(
                    onClick = { VideoPlaybackManager.toggleSubscribe() },
                    shape = RoundedCornerShape(20.dp),
                    color = if (uiState.isSubscribed) Color.White.copy(alpha = 0.22f) else MaterialTheme.colorScheme.primary,
                    modifier = Modifier.height(40.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.padding(horizontal = 14.dp)
                    ) {
                        Text(
                            text = stringResource(if (uiState.isSubscribed) R.string.subscribed else R.string.subscribe),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold,
                            color = if (uiState.isSubscribed) Color.White else MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, bottom = 10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .clickable { session.channelId?.let(onChannelClick) }
                ) {
                    if (!session.channelAvatarUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = session.channelAvatarUrl,
                            contentDescription = session.channelName,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop,
                        )
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = listOfNotNull(
                        session.channelName.takeIf { it.isNotEmpty() },
                        session.viewCountText,
                        session.publishedTimeText,
                    ).joinToString(" • "),
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.7f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .clickable { session.channelId?.let(onChannelClick) },
                )
            }
        }
    }
}

@Composable
private fun CompactActionChip(
    icon: Int,
    selected: Boolean,
    contentDescription: String,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = if (selected) Color.White.copy(alpha = 0.32f) else Color.White.copy(alpha = 0.14f),
        modifier = Modifier.size(40.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                painter = painterResource(icon),
                contentDescription = contentDescription,
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun ChannelRow(
    session: VideoPlaybackManager.VideoSession,
    isSubscribed: Boolean,
    onSubscribeClick: () -> Unit,
    onChannelClick: (String) -> Unit,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer)
                .clickable { session.channelId?.let(onChannelClick) }
        ) {
            // The real channel avatar (not the video's thumbnail/artwork, which is
            // what channelThumbnail holds for the media notification artwork).
            if (!session.channelAvatarUrl.isNullOrBlank()) {
                AsyncImage(
                    model = session.channelAvatarUrl,
                    contentDescription = session.channelName,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            } else {
                Icon(
                    painter = painterResource(R.drawable.person),
                    contentDescription = session.channelName,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(10.dp),
                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = session.channelName,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            session.subscriberCountText?.let {
                Text(
                    text = it,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }

        Surface(
            onClick = onSubscribeClick,
            shape = RoundedCornerShape(22.dp),
            color = if (isSubscribed) MaterialTheme.colorScheme.surfaceContainerHighest else MaterialTheme.colorScheme.primary,
            modifier = Modifier.height(38.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 16.dp)
            ) {
                Icon(
                    painter = painterResource(if (isSubscribed) R.drawable.subscribed else R.drawable.subscribe),
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = if (isSubscribed) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onPrimary
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = stringResource(if (isSubscribed) R.string.subscribed else R.string.subscribe),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = if (isSubscribed) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onPrimary
                )
            }
        }
    }
}

@Composable
private fun ActionButtonsRow(
    isLiked: Boolean,
    isDisliked: Boolean,
    isSaved: Boolean,
    likeCountText: String?,
) {
    val context = LocalContext.current
    var menuOpen by remember { mutableStateOf(false) }
    var showPlaylistDialog by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        ActionButton(
            icon = R.drawable.thumb_up_filled,
            label = buildString {
                append(stringResource(R.string.video_player_like))
                if (!likeCountText.isNullOrBlank()) append(" • ").append(likeCountText)
            },
            selected = isLiked,
            onClick = { VideoPlaybackManager.toggleLike() },
            modifier = Modifier.weight(1f)
        )
        ActionButton(
            icon = R.drawable.thumb_down_filled,
            label = stringResource(R.string.video_player_dislike),
            selected = isDisliked,
            onClick = { VideoPlaybackManager.toggleDislike() },
            modifier = Modifier.weight(1f)
        )
        ActionButton(
            icon = if (isSaved) R.drawable.library_add_check else R.drawable.library_add,
            label = stringResource(if (isSaved) R.string.video_player_saved else R.string.video_player_save),
            selected = isSaved,
            onClick = { VideoPlaybackManager.toggleSave() },
            modifier = Modifier.weight(1f)
        )
        Box {
            Surface(
                onClick = { menuOpen = true },
                shape = RoundedCornerShape(22.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHighest,
                modifier = Modifier.size(42.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        painter = painterResource(R.drawable.more_horiz),
                        contentDescription = stringResource(R.string.video_player_share),
                        modifier = Modifier.size(20.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            DropdownMenu(
                expanded = menuOpen,
                onDismissRequest = { menuOpen = false },
            ) {
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.video_player_share)) },
                    onClick = {
                        menuOpen = false
                        VideoPlaybackManager.shareVideo(context)
                    },
                    leadingIcon = {
                        Icon(painterResource(R.drawable.share), contentDescription = null, modifier = Modifier.size(20.dp))
                    }
                )
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.video_player_copy_link)) },
                    onClick = {
                        menuOpen = false
                        VideoPlaybackManager.copyVideoLink(context)
                    },
                    leadingIcon = {
                        Icon(painterResource(R.drawable.link), contentDescription = null, modifier = Modifier.size(20.dp))
                    }
                )
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.video_player_add_to_playlist)) },
                    onClick = {
                        menuOpen = false
                        showPlaylistDialog = true
                    },
                    leadingIcon = {
                        Icon(painterResource(R.drawable.playlist_add), contentDescription = null, modifier = Modifier.size(20.dp))
                    }
                )
            }
        }
    }

    if (showPlaylistDialog) {
        AddToPlaylistVideoDialog(
            onDismiss = { showPlaylistDialog = false },
        )
    }
}

@Composable
private fun AddToPlaylistVideoDialog(
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var playlists by remember { mutableStateOf<List<PlaylistItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        loading = true
        val result = withContext(Dispatchers.IO) {
            YouTube.library("FEmusic_liked_playlists").getOrNull()
        }
        playlists = result?.items.orEmpty().filterIsInstance<PlaylistItem>()
        loading = false
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(stringResource(R.string.video_player_add_to_playlist))
        },
        text = {
            when {
                loading -> {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(stringResource(R.string.video_player_queue_loading))
                    }
                }
                playlists.isEmpty() -> {
                    Text(stringResource(R.string.video_player_queue_empty))
                }
                else -> {
                    LazyColumn(modifier = Modifier.fillMaxWidth()) {
                        items(playlists) { playlist ->
                            Text(
                                text = playlist.title,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        VideoPlaybackManager.addToPlaylist(playlist.id)
                                        onDismiss()
                                    }
                                    .padding(vertical = 12.dp),
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(android.R.string.cancel))
            }
        },
    )
}

@Composable
private fun ActionButton(
    icon: Int,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val haptic = LocalHapticFeedback.current
    Surface(
        onClick = {
            haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
            onClick()
        },
        shape = RoundedCornerShape(22.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHighest,
        modifier = modifier.height(42.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 8.dp)
        ) {
            Icon(
                painter = painterResource(icon),
                contentDescription = label,
                modifier = Modifier.size(20.dp),
                tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
            )
        }
    }
}

@Composable
private fun ExpandableDescription(
    description: String,
    expanded: Boolean,
    onToggle: () -> Unit,
) {
    var translating by remember { mutableStateOf(false) }
    var translatedText by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Column {
        Text(
            text = description,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = if (expanded) Int.MAX_VALUE else 3,
            overflow = TextOverflow.Ellipsis,
        )
        if (description.length > 100 || expanded) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onToggle, contentPadding = PaddingValues(0.dp)) {
                    Text(
                        text = stringResource(if (expanded) R.string.video_player_show_less else R.string.video_player_show_more),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Icon(
                        painter = painterResource(if (expanded) R.drawable.expand_less else R.drawable.expand_more),
                        contentDescription = null,
                        modifier = Modifier.size(20.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                
                Spacer(modifier = Modifier.width(12.dp))
                
                TextButton(
                    onClick = {
                        if (translatedText != null) {
                            translatedText = null
                        } else {
                            scope.launch {
                                translating = true
                                delay(1000)
                                translatedText = "Dịch: " + description.take(100) + "..."
                                translating = false
                            }
                        }
                    },
                    contentPadding = PaddingValues(0.dp),
                    enabled = !translating
                ) {
                    if (translating) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    } else {
                        Text(
                            text = if (translatedText != null) "Show original" else "Translate to Vietnamese",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
            
            translatedText?.let {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = it,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f), RoundedCornerShape(4.dp)).padding(8.dp)
                )
            }
        }
    }
}

private enum class DetailTab(val labelRes: Int) {
    UpNext(R.string.video_player_up_next),
    Comments(R.string.video_player_comments),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VideoTabs(uiState: VideoPlaybackManager.UiState) {
    var selectedTab by remember { mutableIntStateOf(DetailTab.UpNext.ordinal) }

    Column {
        SecondaryScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.Transparent,
            contentColor = MaterialTheme.colorScheme.primary,
            edgePadding = 16.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            DetailTab.entries.forEach { tab ->
                Tab(
                    selected = selectedTab == tab.ordinal,
                    onClick = { selectedTab = tab.ordinal },
                    text = {
                        Text(
                            text = stringResource(tab.labelRes),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = if (selectedTab == tab.ordinal) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == tab.ordinal) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        when (selectedTab) {
            DetailTab.Comments.ordinal -> CommentsSection(uiState = uiState)
            else -> UpNextSection(uiState = uiState)
        }
    }
}

@Composable
private fun CommentsSection(uiState: VideoPlaybackManager.UiState) {
    when {
        uiState.isLoadingComments -> {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 24.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(modifier = Modifier.size(28.dp))
            }
        }
        uiState.commentsError != null && uiState.comments.isEmpty() -> {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = uiState.commentsError.orEmpty(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                )
                TextButton(onClick = { VideoPlaybackManager.retryLoadingComments() }) {
                    Text(
                        text = stringResource(R.string.video_player_retry),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
            }
        }
        else -> {
            Column(modifier = Modifier.fillMaxWidth()) {
                uiState.comments.forEach { comment ->
                    CommentRow(comment = comment)
                }
                if (uiState.isLoadingMoreComments) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun CommentRow(comment: CommentItem) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            if (!comment.authorThumbnail.isNullOrBlank()) {
                AsyncImage(
                    model = comment.authorThumbnail,
                    contentDescription = comment.authorName,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            } else {
                Text(
                    text = comment.authorName.firstOrNull()?.toString() ?: "?",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = comment.authorName,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                comment.likeCount?.let {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            painter = painterResource(R.drawable.thumb_up_filled),
                            contentDescription = null,
                            modifier = Modifier.size(12.dp),
                            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = it,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                }
            }
            Text(
                text = buildString {
                    if (comment.isPinned) append("📌 ")
                    append(comment.content)
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                comment.publishedTime?.let {
                    Text(
                        text = it,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }
                comment.replyCount?.let {
                    Text(
                        text = it,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }
            }
        }
    }
}

@Composable
private fun UpNextSection(uiState: VideoPlaybackManager.UiState) {
    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.video_player_autoplay_next),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    text = stringResource(R.string.video_player_autoplay_next_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(
                checked = uiState.autoplayEnabled,
                onCheckedChange = { VideoPlaybackManager.setAutoplayEnabled(it) },
            )
        }
        Spacer(modifier = Modifier.height(4.dp))

        when {
        uiState.isLoadingRecommendations -> {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                repeat(4) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                            .height(84.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                    )
                }
            }
        }
        uiState.recommendations.isEmpty() -> {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stringResource(R.string.video_player_no_recommendations),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        }
        else -> {
            Column(
                modifier = Modifier.fillMaxWidth(),
            ) {
                uiState.recommendations.forEach { item ->
                    UpNextRow(
                        item = item,
                        isPlaying = item.videoId == uiState.session?.videoId,
                        onClick = {
                            VideoPlaybackManager.playWithDetails(
                                context = context,
                                videoId = item.videoId,
                                title = item.title,
                                channelName = item.channelName,
                                channelId = item.channelId,
                                viewCountText = item.viewCountText,
                                publishedTimeText = item.publishedTimeText,
                            )
                        },
                        onRemove = { VideoPlaybackManager.removeFromQueue(item.videoId) },
                    )
                }
                if (uiState.isLoadingMoreRecommendations) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp))
                    }
                }
            }
        }
        }
    }
}

@Composable
private fun UpNextRow(
    item: RecommendationItem,
    isPlaying: Boolean,
    onClick: () -> Unit,
    onRemove: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .width(148.dp)
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
        ) {
            val thumbnailUrl = item.thumbnail
            if (thumbnailUrl != null) {
                AsyncImage(
                    model = thumbnailUrl,
                    contentDescription = item.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            }
            if (item.durationText != null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.Black.copy(alpha = 0.78f))
                        .padding(horizontal = 5.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = item.durationText,
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
            if (isPlaying) {
                val pulse by rememberInfiniteTransition(label = "upNow").animateFloat(
                    initialValue = 0.45f,
                    targetValue = 1f,
                    animationSpec = infiniteRepeatable(tween(650), RepeatMode.Reverse),
                    label = "upPulse"
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.28f * pulse))
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.6f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = painterResource(R.drawable.pause),
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = Color.White
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .padding(start = 12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = item.title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (isPlaying) FontWeight.Bold else FontWeight.Medium,
                color = if (isPlaying) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            item.channelName.takeIf { it.isNotBlank() }?.let {
                Text(
                    text = it,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            listOfNotNull(
                item.viewCountText,
                item.publishedTimeText,
            ).takeIf { it.isNotEmpty() }?.joinToString(" • ")?.let { meta ->
                Text(
                    text = meta,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }

        if (!isPlaying) {
            Surface(
                onClick = onRemove,
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.6f),
                modifier = Modifier
                    .padding(start = 6.dp)
                    .size(28.dp),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        painter = painterResource(R.drawable.close),
                        contentDescription = stringResource(R.string.video_player_remove_from_queue),
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Settings overlay
// ---------------------------------------------------------------------------

@Composable
private fun SettingsOverlay(
    uiState: VideoPlaybackManager.UiState,
    onDismiss: () -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.6f))
            .clickable(onClick = onDismiss),
        contentAlignment = Alignment.BottomCenter
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight(),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            tonalElevation = 8.dp,
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = stringResource(R.string.video_quality),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Playback speed: ${uiState.playbackSpeed}x",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            painter = painterResource(R.drawable.close),
                            contentDescription = stringResource(R.string.close),
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Quality",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                ) {
                    listOf(
                        VideoQuality.QUALITY_360P to stringResource(R.string.video_player_quality_360p),
                        VideoQuality.QUALITY_480P to stringResource(R.string.video_player_quality_480p),
                        VideoQuality.QUALITY_720P to stringResource(R.string.video_player_quality_720p),
                        VideoQuality.QUALITY_1080P to stringResource(R.string.video_player_quality_1080p),
                    ).forEach { (quality, label) ->
                        Surface(
                            onClick = { VideoPlaybackManager.setVideoQuality(quality) },
                            shape = RoundedCornerShape(12.dp),
                            color = if (uiState.videoQuality == quality) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHighest,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = label,
                                modifier = Modifier.padding(vertical = 10.dp),
                                textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (uiState.videoQuality == quality) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = stringResource(R.string.video_playback_speed),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                ) {
                    listOf(
                        0.5f to "0.5x",
                        1.0f to "1.0x",
                        1.5f to "1.5x",
                        2.0f to "2.0x",
                    ).forEach { (speed, label) ->
                        Surface(
                            onClick = { VideoPlaybackManager.setPlaybackSpeed(speed) },
                            shape = RoundedCornerShape(12.dp),
                            color = if (uiState.playbackSpeed == speed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHighest,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = label,
                                modifier = Modifier.padding(vertical = 10.dp),
                                textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (uiState.playbackSpeed == speed) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Aspect ratio",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                ) {
                    listOf(
                        AspectRatioFrameLayout.RESIZE_MODE_FIT to "Fit",
                        AspectRatioFrameLayout.RESIZE_MODE_FILL to "Stretch",
                        AspectRatioFrameLayout.RESIZE_MODE_ZOOM to "Crop",
                    ).forEach { (mode, label) ->
                        Surface(
                            onClick = { VideoPlaybackManager.setResizeMode(mode) },
                            shape = RoundedCornerShape(12.dp),
                            color = if (uiState.resizeMode == mode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHighest,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = label,
                                modifier = Modifier.padding(vertical = 10.dp),
                                textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (uiState.resizeMode == mode) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Surface + helpers
// ---------------------------------------------------------------------------

@OptIn(UnstableApi::class)
@Composable
internal fun AndroidVideoSurface(player: ExoPlayer, resizeModeOverride: Int) {
    androidx.compose.ui.viewinterop.AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                useController = false
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                setBackgroundColor(android.graphics.Color.BLACK)
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
        },
        update = { view ->
            view.player = player
            if (view.resizeMode != resizeModeOverride) {
                view.resizeMode = resizeModeOverride
            }
        },
        modifier = Modifier.fillMaxSize()
    )
}

private fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        "%d:%02d:%02d".format(hours, minutes, seconds)
    } else {
        "$minutes:${seconds.toString().padStart(2, '0')}"
    }
}