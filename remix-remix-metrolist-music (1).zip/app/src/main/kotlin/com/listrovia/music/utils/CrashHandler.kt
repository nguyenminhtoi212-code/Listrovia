/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.utils

import android.content.Context
import android.content.Intent
import android.os.Build
import com.listrovia.music.BuildConfig
import com.listrovia.music.ui.screens.CrashActivity
import timber.log.Timber
import java.io.PrintWriter
import java.io.StringWriter
import kotlin.system.exitProcess

class CrashHandler private constructor(
    private val applicationContext: Context
) : Thread.UncaughtExceptionHandler {

    private val defaultHandler: Thread.UncaughtExceptionHandler? =
        Thread.getDefaultUncaughtExceptionHandler()

    override fun uncaughtException(thread: Thread, throwable: Throwable) {
        if (isCancellation(throwable)) {
            Timber.d("Ignoring cancellation exception on thread: ${thread.name}")
            return
        }

        try {
            val crashLog = buildCrashLog(throwable)
            Timber.e(throwable, "App crashed")

            runCatching {
                val crashlytics = com.google.firebase.crashlytics.FirebaseCrashlytics.getInstance()
                crashlytics.log("Uncaught exception on thread: ${thread.name}")
                crashlytics.recordException(throwable)
                crashlytics.sendUnsentReports()
            }
            
            // Launch crash activity
            val intent = Intent(applicationContext, CrashActivity::class.java).apply {
                putExtra(EXTRA_CRASH_LOG, crashLog)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            }
            applicationContext.startActivity(intent)
            
            // Kill the current process
            android.os.Process.killProcess(android.os.Process.myPid())
            exitProcess(1)
        } catch (e: Exception) {
            // If we fail to handle the crash, fall back to default handler
            Timber.e(e, "Error handling crash")
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }

    private fun buildCrashLog(throwable: Throwable): String {
        val stackTrace = StringWriter().apply {
            throwable.printStackTrace(PrintWriter(this))
        }.toString()

        return buildString {
            appendLine(applicationContext.getString(com.listrovia.music.R.string.crash_report_title))
            appendLine("=".repeat(50))
            appendLine()
            appendLine("${applicationContext.getString(com.listrovia.music.R.string.crash_report_manufacturer)}: ${Build.MANUFACTURER}")
            appendLine("${applicationContext.getString(com.listrovia.music.R.string.crash_report_device)}: ${Build.MODEL}")
            appendLine("${applicationContext.getString(com.listrovia.music.R.string.crash_report_android_version)}: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
            appendLine("${applicationContext.getString(com.listrovia.music.R.string.crash_report_app_version)}: ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
            appendLine()
            appendLine("=".repeat(50))
            appendLine(applicationContext.getString(com.listrovia.music.R.string.crash_report_stacktrace))
            appendLine("=".repeat(50))
            appendLine()
            append(stackTrace)
        }
    }

    companion object {
        const val EXTRA_CRASH_LOG = "crash_log"

        fun install(context: Context) {
            val handler = CrashHandler(context.applicationContext)
            Thread.setDefaultUncaughtExceptionHandler(handler)
            Timber.d("CrashHandler installed")
        }
    }
}

private fun isCancellation(throwable: Throwable?): Boolean {
    var current = throwable
    while (current != null) {
        if (current is java.util.concurrent.CancellationException ||
            current is kotlinx.coroutines.CancellationException
        ) {
            return true
        }
        current = current.cause
    }
    return false
}

fun reportException(throwable: Throwable) {
    if (isCancellation(throwable)) {
        return
    }
    Timber.e(throwable, "Reported exception")
    runCatching {
        com.google.firebase.crashlytics.FirebaseCrashlytics.getInstance().recordException(throwable)
    }
}
