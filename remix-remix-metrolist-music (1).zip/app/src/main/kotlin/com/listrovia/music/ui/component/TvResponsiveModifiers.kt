package com.listrovia.music.ui.component

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.listrovia.music.LocalIsTvMode

/**
 * Standard Android TV Overscan Safety Margin (5% horizontal, 5% vertical of 1080p screen).
 * Prevents content from getting clipped or distorted at television display boundaries.
 */
val TvOverscanHorizontalPadding: Dp = 24.dp
val TvOverscanVerticalPadding: Dp = 12.dp

@Composable
fun getTvOverscanPaddingValues(isTvMode: Boolean = LocalIsTvMode.current): PaddingValues {
    return if (isTvMode) {
        PaddingValues(
            start = TvOverscanHorizontalPadding,
            end = TvOverscanHorizontalPadding,
            top = TvOverscanVerticalPadding,
            bottom = TvOverscanVerticalPadding
        )
    } else {
        PaddingValues(0.dp)
    }
}

/**
 * Modifier that applies TV overscan padding to a container when in TV mode.
 */
fun Modifier.tvOverscanPadding(
    enabled: Boolean = true,
): Modifier = composed {
    val isTvMode = LocalIsTvMode.current
    if (enabled && isTvMode) {
        this.padding(
            start = TvOverscanHorizontalPadding,
            end = TvOverscanHorizontalPadding,
            top = TvOverscanVerticalPadding,
            bottom = TvOverscanVerticalPadding
        )
    } else {
        this
    }
}

/**
 * Visual focus animation & scale effect for Android TV D-pad / Keyboard navigation.
 * Smoothly scales focused items, applies a primary focus border, elevated zIndex,
 * and subtle background highlight for clear 10ft TV feedback without clipping or distorting layouts.
 */
fun Modifier.tvFocusHighlight(
    shape: Shape = RoundedCornerShape(16.dp),
    focusedScale: Float = 1.04f,
    focusBorderColor: Color? = null,
    borderWidth: Dp = 2.5.dp,
    interactionSource: MutableInteractionSource? = null,
    includeFocusable: Boolean = false,
): Modifier = composed {
    val isTvMode = LocalIsTvMode.current
    if (!isTvMode) return@composed this

    var isFocused by remember { mutableStateOf(false) }

    val scale by animateFloatAsState(
        targetValue = if (isFocused) focusedScale else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "tvFocusScale"
    )

    val borderColor = focusBorderColor ?: MaterialTheme.colorScheme.primary
    val focusedBgColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.18f)
    val animatedBgColor by animateColorAsState(
        targetValue = if (isFocused) focusedBgColor else Color.Transparent,
        animationSpec = tween(durationMillis = 180),
        label = "tvFocusBg"
    )

    this
        .onFocusChanged { isFocused = it.isFocused || it.hasFocus }
        .then(
            if (includeFocusable) {
                Modifier.focusable(interactionSource = interactionSource)
            } else {
                Modifier
            }
        )
        .zIndex(if (isFocused) 2f else 0f)
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .background(color = animatedBgColor, shape = shape)
        .then(
            if (isFocused) {
                Modifier.border(
                    width = borderWidth,
                    color = borderColor,
                    shape = shape
                )
            } else {
                Modifier
            }
        )
}

