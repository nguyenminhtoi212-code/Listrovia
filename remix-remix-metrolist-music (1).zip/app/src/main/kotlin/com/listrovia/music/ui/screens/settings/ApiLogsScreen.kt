package com.listrovia.music.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.listrovia.innertube.InnerTubeLogBuffer
import com.listrovia.innertube.ApiLogEntry
import com.listrovia.music.R
import com.listrovia.music.ui.component.IconButton

/**
 * 'API Health' screen in the Settings section displaying a list of recent API errors
 * categorized as 'Data Structure Mismatches' or 'Parsing Failures' logged by the Timber interceptor,
 * with a 'Clear Logs' button.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApiLogsScreen(navController: NavController) {
    val logs by InnerTubeLogBuffer.logs.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.api_health_screen_title)) },
                navigationIcon = {
                    IconButton(onClick = navController::navigateUp) {
                        Icon(painterResource(R.drawable.arrow_back), contentDescription = null)
                    }
                },
                actions = {
                    TextButton(onClick = { InnerTubeLogBuffer.clearLogs() }) {
                        Text(stringResource(R.string.clear_logs_btn))
                    }
                }
            )
        }
    ) { padding ->
        if (logs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(24.dp),
                contentAlignment = androidx.compose.ui.Alignment.Center
            ) {
                Text(
                    text = "No API mismatch or parsing logs recorded.\nChưa ghi nhận lỗi lệch cấu trúc dữ liệu hoặc phân tích mô hình.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item { Spacer(modifier = Modifier.height(8.dp)) }
                items(logs) { log ->
                    val categoryLabel = when (log.category) {
                        ApiLogEntry.LogCategory.PARSING_FAILURE -> stringResource(R.string.parsing_failures_label)
                        ApiLogEntry.LogCategory.DATA_STRUCTURE_MISMATCH -> stringResource(R.string.data_structure_mismatches_label)
                        ApiLogEntry.LogCategory.INFO -> "INFO / Thông tin"
                    }
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = when (log.category) {
                                ApiLogEntry.LogCategory.PARSING_FAILURE -> MaterialTheme.colorScheme.errorContainer
                                ApiLogEntry.LogCategory.DATA_STRUCTURE_MISMATCH -> MaterialTheme.colorScheme.tertiaryContainer
                                ApiLogEntry.LogCategory.INFO -> MaterialTheme.colorScheme.surfaceVariant
                            }
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "[$categoryLabel]",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = log.timestamp,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "URL: ${log.url}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = log.message,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
                item { Spacer(modifier = Modifier.height(16.dp)) }
            }
        }
    }
}
