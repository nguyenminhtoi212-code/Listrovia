/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.api

import android.content.Context
import com.listrovia.music.constants.AionLabsModelsUrl
import com.listrovia.music.db.AiModelCacheDatabase
import com.listrovia.music.db.entities.AiModelCacheEntity
import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.statement.bodyAsText
import io.ktor.http.isSuccess
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import timber.log.Timber
import java.io.File
import java.util.Locale
import java.util.concurrent.TimeUnit

data class AionLabsModelItem(
    val id: String,
    val name: String,
    val ownedBy: String = "aion-labs",
    val description: String = "",
    val contextLength: Long = 0L,
    val maxCompletionTokens: Long = 0L,
    val promptCostPerMillion: Double = 0.0,
    val completionCostPerMillion: Double = 0.0,
    val cacheReadCostPerMillion: Double = 0.0,
    val supportsReasoning: Boolean = false,
    val isCreativeRoleplay: Boolean = false,
    val isFastTier: Boolean = false,
    val matchScore: Int = 88,
    val contextScore: Float = 0.85f,
    val lyricNuanceScore: Float = 0.90f,
    val speedEfficiencyScore: Float = 0.85f,
    val recommendationBadgeEn: String = "",
    val recommendationBadgeVi: String = "",
    val createdTimestamp: Long = 0L,
) {
    val formattedContext: String
        get() = when {
            contextLength >= 1_048_576L -> "${contextLength / 1_048_576L}M"
            contextLength >= 1_000_000L -> "${contextLength / 1_000_000L}M"
            contextLength >= 1024L -> "${contextLength / 1024L}K"
            contextLength > 0L -> "$contextLength"
            else -> "128K"
        }

    val pricingSummary: String
        get() = when {
            promptCostPerMillion <= 0.0 && completionCostPerMillion <= 0.0 -> "Free"
            else -> String.format(Locale.US, "$%.2f / $%.2f / 1M", promptCostPerMillion, completionCostPerMillion)
        }

    val cachePricingBadge: String
        get() = if (cacheReadCostPerMillion > 0.0) {
            String.format(Locale.US, "Cache $%.2f", cacheReadCostPerMillion)
        } else {
            ""
        }

    fun getRecommendationBadge(isVietnamese: Boolean): String {
        return if (isVietnamese) recommendationBadgeVi else recommendationBadgeEn
    }
}

data class AionLabsClassifiedModels(
    val recommended: List<AionLabsModelItem> = emptyList(),
    val flagshipSeries: List<AionLabsModelItem> = emptyList(),
    val creativeLyric: List<AionLabsModelItem> = emptyList(),
    val fastRealtime: List<AionLabsModelItem> = emptyList(),
    val allModels: List<AionLabsModelItem> = emptyList(),
    val topSpotlightModel: AionLabsModelItem? = null,
    val fetchedAtMillis: Long = System.currentTimeMillis(),
)

/**
 * Real-time AI Model Discovery & Recommendation Engine for AionLabs
 * Endpoint: https://api.aionlabs.ai/v1/models
 */
class AionLabsModelManager(
    cacheTTLMinutes: Long = 15L,
    private val context: Context? = null,
) {
    private val apiUrl = "https://api.aionlabs.ai/v1/models"
    private val storageKey = "aionlabs_models_realtime_v1"
    private val cacheTTL = cacheTTLMinutes * 60 * 1000L

    private var memoryCache: Pair<Long, AionLabsClassifiedModels>? = null
    private val fetchMutex = Mutex()

    private val ktorClient: HttpClient by lazy {
        HttpClient(OkHttp) {
            install(HttpTimeout) {
                requestTimeoutMillis = 20_000L
                connectTimeoutMillis = 15_000L
                socketTimeoutMillis = 20_000L
            }
            expectSuccess = false
        }
    }

    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    suspend fun fetchModels(
        forceRefresh: Boolean = false,
        apiKey: String = "",
    ): AionLabsClassifiedModels = withContext(Dispatchers.IO) {
        fetchMutex.withLock {
            val now = System.currentTimeMillis()
            val cached = memoryCache
            if (!forceRefresh && cached != null && (now - cached.first < cacheTTL) && cached.second.allModels.isNotEmpty()) {
                return@withLock cached.second
            }

            try {
                val cleanKey = apiKey.trim()
                val responseBody = try {
                    val response = ktorClient.get(apiUrl) {
                        header("User-Agent", "Mozilla/5.0 (Android; Listrovia Music/1.0)")
                        header("Accept", "application/json")
                        if (cleanKey.isNotBlank()) {
                            header("Authorization", "Bearer $cleanKey")
                        }
                    }
                    if (!response.status.isSuccess()) {
                        throw Exception("Ktor HTTP ${response.status.value} from AionLabs")
                    }
                    val body = response.bodyAsText()
                    if (body.isBlank()) throw Exception("Empty response body from AionLabs")
                    body
                } catch (ktorErr: Exception) {
                    Timber.w(ktorErr, "Ktor request to AionLabs failed, trying OkHttp fallback")
                    val reqBuilder = Request.Builder()
                        .url(apiUrl)
                        .addHeader("User-Agent", "Mozilla/5.0 (Android; Listrovia Music/1.0)")
                        .addHeader("Accept", "application/json")
                        .get()
                    if (cleanKey.isNotBlank()) {
                        reqBuilder.addHeader("Authorization", "Bearer $cleanKey")
                    }
                    val response = okHttpClient.newCall(reqBuilder.build()).execute()
                    if (!response.isSuccessful) {
                        throw Exception("OkHttp HTTP ${response.code} from AionLabs")
                    }
                    response.body?.string() ?: throw Exception("Empty OkHttp body from AionLabs")
                }

                val rawArray = parseRawModelsArray(responseBody)
                val parsedItems = mutableListOf<AionLabsModelItem>()

                for (i in 0 until rawArray.length()) {
                    val obj = rawArray.optJSONObject(i) ?: continue
                    val id = obj.optString("id", "").trim()
                    if (id.isBlank()) continue
                    parsedItems.add(parseAionModelObject(obj, id, i))
                }

                if (parsedItems.isEmpty()) {
                    throw Exception("No valid models returned from https://api.aionlabs.ai/v1/models")
                }

                val classified = classifyAndRecommend(parsedItems, now)
                memoryCache = Pair(now, classified)
                saveToLocalCache(classified)
                Timber.i("Successfully loaded ${classified.allModels.size} real-time models from AionLabs API")
                classified
            } catch (e: Exception) {
                Timber.w(e, "Primary AionLabs endpoint failed, attempting public AionLabs catalog mirror")
                val mirrorItems = fetchPublicAionLabsMirror()
                if (mirrorItems.isNotEmpty()) {
                    val classified = classifyAndRecommend(mirrorItems, now)
                    memoryCache = Pair(now, classified)
                    saveToLocalCache(classified)
                    return@withLock classified
                }
                loadFromLocalCache() ?: AionLabsClassifiedModels(fetchedAtMillis = now)
            }
        }
    }

    private fun fetchPublicAionLabsMirror(): List<AionLabsModelItem> {
        return try {
            val req = Request.Builder()
                .url("https://openrouter.ai/api/v1/models")
                .addHeader("User-Agent", "Mozilla/5.0 (Android; Listrovia Music/1.0)")
                .addHeader("Accept", "application/json")
                .get()
                .build()
            val response = okHttpClient.newCall(req).execute()
            if (!response.isSuccessful) return emptyList()
            val body = response.body?.string().orEmpty()
            if (body.isBlank()) return emptyList()
            val arr = parseRawModelsArray(body)
            val aionModels = mutableListOf<AionLabsModelItem>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val id = obj.optString("id", "").trim()
                if (id.startsWith("aion-labs/", ignoreCase = true) || id.contains("aion", ignoreCase = true)) {
                    aionModels.add(parseAionModelObject(obj, id, aionModels.size))
                }
            }
            aionModels
        } catch (e: Exception) {
            Timber.w(e, "Public AionLabs mirror fallback failed")
            emptyList()
        }
    }

    private fun parseRawModelsArray(responseBody: String): JSONArray {
        val trimmed = responseBody.trim()
        return if (trimmed.startsWith("[")) {
            JSONArray(trimmed)
        } else {
            val root = JSONObject(trimmed)
            root.optJSONArray("data")
                ?: root.optJSONArray("models")
                ?: JSONArray()
        }
    }

    private fun parseAionModelObject(obj: JSONObject, id: String, index: Int): AionLabsModelItem {
        val rawName = obj.optString("name", "").trim()
        val displayName = if (rawName.isNotBlank()) {
            rawName
        } else {
            formatDisplayNameFromId(id)
        }

        val ownedBy = obj.optString("owned_by", "").trim().ifBlank {
            if (id.contains("/")) id.substringBefore("/") else "aion-labs"
        }

        val metadata = obj.optJSONObject("metadata")
        val description = obj.optString("description", "").ifBlank {
            metadata?.optString("description", "") ?: ""
        }

        val contextLength = obj.optLong("context_length", 0L).takeIf { it > 0L }
            ?: obj.optLong("max_model_len", 0L).takeIf { it > 0L }
            ?: obj.optLong("max_context_length", 0L).takeIf { it > 0L }
            ?: metadata?.optLong("context_length", 0L)?.takeIf { it > 0L }
            ?: 131072L

        val topProvider = obj.optJSONObject("top_provider")
        val maxCompletionTokens = obj.optLong("max_completion_tokens", 0L).takeIf { it > 0L }
            ?: obj.optLong("max_output_tokens", 0L).takeIf { it > 0L }
            ?: topProvider?.optLong("max_completion_tokens", 0L)?.takeIf { it > 0L }
            ?: 16384L

        val pricingObj = obj.optJSONObject("pricing") ?: metadata?.optJSONObject("pricing")
        val promptCostPerMillion = extractPerMillionCost(pricingObj, "prompt", "input", "input_tokens")
        val completionCostPerMillion = extractPerMillionCost(pricingObj, "completion", "output", "output_tokens")
        val cacheReadCostPerMillion = extractPerMillionCost(pricingObj, "input_cache_read", "cache_read", "cached_input")

        val idLower = id.lowercase()
        val nameLower = displayName.lowercase()
        val descLower = description.lowercase()

        val supportsReasoning = obj.optBoolean("supports_reasoning", false) ||
            obj.optBoolean("reasoning", false) ||
            idLower.contains("r1") ||
            idLower.contains("reason") ||
            idLower.contains("think") ||
            idLower.contains("aion-1.0") ||
            idLower.contains("aion-2") ||
            idLower.contains("aion-3") ||
            descLower.contains("reasoning")

        val isCreativeRoleplay = idLower.contains("rp") ||
            idLower.contains("roleplay") ||
            idLower.contains("story") ||
            idLower.contains("creative") ||
            idLower.contains("aion") ||
            descLower.contains("roleplay") ||
            descLower.contains("creative") ||
            descLower.contains("narrative")

        val isFastTier = idLower.contains("mini") ||
            idLower.contains("flash") ||
            idLower.contains("lite") ||
            idLower.contains("fast") ||
            idLower.contains("small") ||
            idLower.contains("8b") ||
            (promptCostPerMillion in 0.0..0.35)

        val contextScore = when {
            contextLength >= 256_000L -> 0.98f
            contextLength >= 128_000L -> 0.92f
            contextLength >= 64_000L -> 0.82f
            else -> 0.72f
        }

        val lyricNuanceScore = when {
            idLower.contains("aion-3.5") || idLower.contains("aion-3") -> 0.98f
            idLower.contains("aion-2") || idLower.contains("aion-1.0") -> 0.95f
            isCreativeRoleplay && supportsReasoning -> 0.94f
            isCreativeRoleplay -> 0.91f
            supportsReasoning -> 0.89f
            else -> 0.84f
        }

        val speedEfficiencyScore = when {
            isFastTier -> 0.96f
            promptCostPerMillion <= 0.8 -> 0.90f
            promptCostPerMillion <= 2.5 -> 0.84f
            else -> 0.78f
        }

        val rawMatch = ((contextScore * 32f) + (lyricNuanceScore * 42f) + (speedEfficiencyScore * 26f) - (index * 0.4f))
            .toInt()
            .coerceIn(76, 99)

        val (badgeEn, badgeVi) = when {
            idLower.contains("aion") && !isFastTier -> {
                "Flagship Narrative & Lyrics" to "Chuẩn Flagship Ca từ & Cảm xúc"
            }
            isFastTier && isCreativeRoleplay -> {
                "Instant Synced Lyrics Pick" to "Tối ưu Dịch lời Thời gian thực"
            }
            supportsReasoning -> {
                "Deep Poetic Reasoning" to "Suy luận Sắc thái Ca từ sâu"
            }
            isFastTier -> {
                "Ultra-Low Latency Stream" to "Phản hồi Tức thì Độ trễ thấp"
            }
            else -> {
                "Balanced Studio Model" to "Cân bằng Hiệu năng & Ngữ cảnh"
            }
        }

        val created = obj.optLong("created", 0L)

        return AionLabsModelItem(
            id = id,
            name = displayName,
            ownedBy = ownedBy,
            description = description,
            contextLength = contextLength,
            maxCompletionTokens = maxCompletionTokens,
            promptCostPerMillion = promptCostPerMillion,
            completionCostPerMillion = completionCostPerMillion,
            cacheReadCostPerMillion = cacheReadCostPerMillion,
            supportsReasoning = supportsReasoning,
            isCreativeRoleplay = isCreativeRoleplay,
            isFastTier = isFastTier,
            matchScore = rawMatch,
            contextScore = contextScore,
            lyricNuanceScore = lyricNuanceScore,
            speedEfficiencyScore = speedEfficiencyScore,
            recommendationBadgeEn = badgeEn,
            recommendationBadgeVi = badgeVi,
            createdTimestamp = created,
        )
    }

    private fun extractPerMillionCost(pricingObj: JSONObject?, vararg keys: String): Double {
        if (pricingObj == null) return 0.0
        for (key in keys) {
            if (!pricingObj.has(key) || pricingObj.isNull(key)) continue
            val rawVal = pricingObj.optString(key, "").toDoubleOrNull()
                ?: pricingObj.optDouble(key, Double.NaN).takeIf { !it.isNaN() }
                ?: continue
            if (rawVal <= 0.0) return 0.0
            // If API returns per-token cost (e.g. 0.0000008), convert to per-1M tokens
            return if (rawVal < 0.01) rawVal * 1_000_000.0 else rawVal
        }
        return 0.0
    }

    private fun formatDisplayNameFromId(id: String): String {
        val raw = if (id.contains("/")) id.substringAfter("/") else id
        return raw.split("-", "_")
            .filter { it.isNotBlank() }
            .joinToString(" ") { part ->
                when (part.lowercase()) {
                    "aion" -> "Aion"
                    "rp" -> "RP"
                    "llm" -> "LLM"
                    "ai" -> "AI"
                    else -> part.replaceFirstChar { it.uppercase() }
                }
            }
    }

    private fun classifyAndRecommend(
        items: List<AionLabsModelItem>,
        timestamp: Long,
    ): AionLabsClassifiedModels {
        val sortedByMatch = items.sortedByDescending { it.matchScore }

        val recommended = sortedByMatch.take(12)
        val flagship = sortedByMatch.filter {
            !it.isFastTier || it.contextLength >= 128_000L || it.id.contains("aion", ignoreCase = true)
        }
        val creative = sortedByMatch.filter { it.isCreativeRoleplay || it.supportsReasoning }
        val fast = sortedByMatch.filter { it.isFastTier }

        return AionLabsClassifiedModels(
            recommended = recommended.ifEmpty { sortedByMatch },
            flagshipSeries = flagship.ifEmpty { sortedByMatch },
            creativeLyric = creative.ifEmpty { sortedByMatch },
            fastRealtime = fast.ifEmpty { sortedByMatch },
            allModels = sortedByMatch,
            topSpotlightModel = sortedByMatch.firstOrNull(),
            fetchedAtMillis = timestamp,
        )
    }

    suspend fun getSmartRealtimeRecommendation(
        forceRefresh: Boolean = true,
        apiKey: String = "",
    ): AionLabsModelItem? {
        val classified = fetchModels(forceRefresh = forceRefresh, apiKey = apiKey)
        val topPool = classified.recommended.ifEmpty { classified.allModels }
        return topPool.randomOrNull()
    }

    private suspend fun saveToLocalCache(classified: AionLabsClassifiedModels) {
        try {
            val file = getCacheFile()
            if (file != null) {
                val root = JSONObject()
                root.put("timestamp", classified.fetchedAtMillis)
                val arr = JSONArray()
                classified.allModels.forEach { item ->
                    arr.put(
                        JSONObject().apply {
                            put("id", item.id)
                            put("name", item.name)
                            put("owned_by", item.ownedBy)
                            put("description", item.description)
                            put("context_length", item.contextLength)
                            put("max_completion_tokens", item.maxCompletionTokens)
                            put("prompt_cost", item.promptCostPerMillion)
                            put("completion_cost", item.completionCostPerMillion)
                            put("cache_cost", item.cacheReadCostPerMillion)
                            put("supports_reasoning", item.supportsReasoning)
                            put("is_creative", item.isCreativeRoleplay)
                            put("is_fast", item.isFastTier)
                            put("match_score", item.matchScore)
                            put("context_score", item.contextScore.toDouble())
                            put("lyric_score", item.lyricNuanceScore.toDouble())
                            put("speed_score", item.speedEfficiencyScore.toDouble())
                            put("badge_en", item.recommendationBadgeEn)
                            put("badge_vi", item.recommendationBadgeVi)
                            put("created", item.createdTimestamp)
                        }
                    )
                }
                root.put("models", arr)
                file.writeText(root.toString())
            }

            context?.let { ctx ->
                val entities = classified.allModels.map { item ->
                    AiModelCacheEntity(
                        id = item.id,
                        provider = "AionLabs",
                        name = item.name,
                        providerName = item.ownedBy,
                        tier = if (item.isFastTier) "Fast" else "Flagship",
                        sourceCategory = "VERIFIED",
                        healthStatus = "HEALTHY",
                        contextLength = item.contextLength,
                        pricingBadge = item.pricingSummary,
                        description = item.description,
                        cachedAt = classified.fetchedAtMillis,
                    )
                }
                AiModelCacheDatabase.getInstance(ctx).aiModelCacheDao().insertModels(entities)
            }
        } catch (e: Exception) {
            Timber.w(e, "Failed to persist AionLabs cache")
        }
    }

    private fun loadFromLocalCache(): AionLabsClassifiedModels? {
        try {
            val file = getCacheFile()
            if (file != null && file.exists()) {
                val content = file.readText()
                if (content.isNotBlank()) {
                    val root = JSONObject(content)
                    val timestamp = root.optLong("timestamp", System.currentTimeMillis())
                    val arr = root.optJSONArray("models") ?: return null
                    val items = mutableListOf<AionLabsModelItem>()
                    for (i in 0 until arr.length()) {
                        val obj = arr.optJSONObject(i) ?: continue
                        val id = obj.optString("id", "").trim()
                        if (id.isBlank()) continue
                        items.add(
                            AionLabsModelItem(
                                id = id,
                                name = obj.optString("name", id),
                                ownedBy = obj.optString("owned_by", "aion-labs"),
                                description = obj.optString("description", ""),
                                contextLength = obj.optLong("context_length", 131072L),
                                maxCompletionTokens = obj.optLong("max_completion_tokens", 16384L),
                                promptCostPerMillion = obj.optDouble("prompt_cost", 0.0),
                                completionCostPerMillion = obj.optDouble("completion_cost", 0.0),
                                cacheReadCostPerMillion = obj.optDouble("cache_cost", 0.0),
                                supportsReasoning = obj.optBoolean("supports_reasoning", false),
                                isCreativeRoleplay = obj.optBoolean("is_creative", true),
                                isFastTier = obj.optBoolean("is_fast", false),
                                matchScore = obj.optInt("match_score", 88),
                                contextScore = obj.optDouble("context_score", 0.85).toFloat(),
                                lyricNuanceScore = obj.optDouble("lyric_score", 0.90).toFloat(),
                                speedEfficiencyScore = obj.optDouble("speed_score", 0.85).toFloat(),
                                recommendationBadgeEn = obj.optString("badge_en", "Balanced Studio Model"),
                                recommendationBadgeVi = obj.optString("badge_vi", "Cân bằng Hiệu năng & Ngữ cảnh"),
                                createdTimestamp = obj.optLong("created", 0L),
                            )
                        )
                    }
                    if (items.isNotEmpty()) {
                        return classifyAndRecommend(items, timestamp)
                    }
                }
            }
        } catch (e: Exception) {
            Timber.w(e, "Failed to read AionLabs local cache")
        }
        return null
    }

    private fun getCacheFile(): File? {
        val dir = context?.cacheDir ?: File(System.getProperty("java.io.tmpdir") ?: ".")
        return File(dir, "$storageKey.json")
    }

    companion object {
        @Volatile
        private var instance: AionLabsModelManager? = null

        fun getInstance(context: Context? = null, cacheTTLMinutes: Long = 15L): AionLabsModelManager {
            return instance ?: synchronized(this) {
                instance ?: AionLabsModelManager(cacheTTLMinutes, context?.applicationContext).also {
                    instance = it
                }
            }
        }
    }
}
