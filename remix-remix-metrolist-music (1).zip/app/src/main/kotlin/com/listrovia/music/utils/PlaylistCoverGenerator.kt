/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.core.content.ContextCompat
import com.listrovia.music.R
import java.io.File
import java.io.FileOutputStream
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

enum class PaletteCategory {
    ALL,
    VIBRANT,
    WARM,
    CHILL,
    DARK,
    PASTEL,
}

data class CoverPalette(
    val id: String,
    val name: String,
    val colors: List<Color>,
    val category: PaletteCategory,
    val gradientAngle: Float = 45f, // degrees
    val isRadial: Boolean = false,
)

enum class CoverOverlayStyle {
    CLEAN,
    ICON,
    INITIALS,
    GEOMETRIC_WAVES,
}

data class CoverIconOption(
    val id: String,
    @DrawableRes val iconRes: Int,
    val label: String,
)

object PlaylistCoverGenerator {

    val AVAILABLE_ICONS = listOf(
        CoverIconOption("music_note", R.drawable.music_note, "Music Note"),
        CoverIconOption("queue_music", R.drawable.queue_music, "Playlist"),
        CoverIconOption("headphone", R.drawable.headphone, "Headphones"),
        CoverIconOption("album", R.drawable.album, "Vinyl Record"),
        CoverIconOption("graphic_eq", R.drawable.graphic_eq, "Equalizer"),
        CoverIconOption("favorite", R.drawable.favorite, "Heart"),
        CoverIconOption("star", R.drawable.star, "Star"),
        CoverIconOption("radio", R.drawable.radio, "Radio"),
        CoverIconOption("explore", R.drawable.explore_outlined, "Compass"),
        CoverIconOption("lyrics", R.drawable.lyrics, "Mic & Lyrics"),
    )

    val PRESET_PALETTES = listOf(
        // Vibrant
        CoverPalette(
            id = "sunset_glow",
            name = "Sunset Glow",
            colors = listOf(Color(0xFFFF512F), Color(0xFFDD2476), Color(0xFF8E2DE2)),
            category = PaletteCategory.VIBRANT,
            gradientAngle = 45f,
        ),
        CoverPalette(
            id = "neon_synth",
            name = "Neon Synth",
            colors = listOf(Color(0xFF00F2FE), Color(0xFF4FACFE), Color(0xFF6B11FF)),
            category = PaletteCategory.VIBRANT,
            gradientAngle = 135f,
        ),
        CoverPalette(
            id = "cyber_magenta",
            name = "Cyberpunk",
            colors = listOf(Color(0xFFFF007F), Color(0xFF7928CA), Color(0xFF2A5298)),
            category = PaletteCategory.VIBRANT,
            gradientAngle = 60f,
        ),
        CoverPalette(
            id = "solar_flare",
            name = "Solar Flare",
            colors = listOf(Color(0xFFFF8008), Color(0xFFFFC837), Color(0xFFFF416C)),
            category = PaletteCategory.VIBRANT,
            gradientAngle = 30f,
        ),

        // Warm
        CoverPalette(
            id = "golden_amber",
            name = "Golden Amber",
            colors = listOf(Color(0xFFF7971E), Color(0xFFFFD200), Color(0xFFE65C00)),
            category = PaletteCategory.WARM,
            gradientAngle = 45f,
        ),
        CoverPalette(
            id = "warm_tangerine",
            name = "Warm Tangerine",
            colors = listOf(Color(0xFFF85032), Color(0xFFE73827), Color(0xFFF16F5C)),
            category = PaletteCategory.WARM,
            gradientAngle = 90f,
        ),
        CoverPalette(
            id = "cherry_blossom",
            name = "Cherry Blossom",
            colors = listOf(Color(0xFFFFA8A8), Color(0xFFFC6767), Color(0xFFEC008C)),
            category = PaletteCategory.WARM,
            gradientAngle = 120f,
        ),

        // Chill & Oceanic
        CoverPalette(
            id = "ocean_breeze",
            name = "Ocean Breeze",
            colors = listOf(Color(0xFF2E3192), Color(0xFF1BFFFF), Color(0xFF009FFD)),
            category = PaletteCategory.CHILL,
            gradientAngle = 135f,
        ),
        CoverPalette(
            id = "deep_sea",
            name = "Deep Sea",
            colors = listOf(Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364)),
            category = PaletteCategory.CHILL,
            gradientAngle = 45f,
        ),
        CoverPalette(
            id = "emerald_forest",
            name = "Emerald Forest",
            colors = listOf(Color(0xFF0BA360), Color(0xFF3CBA92), Color(0xFF134E5E)),
            category = PaletteCategory.CHILL,
            gradientAngle = 60f,
        ),
        CoverPalette(
            id = "aurora_borealis",
            name = "Aurora Borealis",
            colors = listOf(Color(0xFF00C9FF), Color(0xFF92FE9D), Color(0xFF0083B0)),
            category = PaletteCategory.CHILL,
            gradientAngle = 75f,
        ),

        // Dark & Midnight
        CoverPalette(
            id = "midnight_purple",
            name = "Midnight Nebula",
            colors = listOf(Color(0xFF120E2E), Color(0xFF3A1C71), Color(0xFF6B11FF)),
            category = PaletteCategory.DARK,
            gradientAngle = 145f,
        ),
        CoverPalette(
            id = "obsidian_slate",
            name = "Obsidian Slate",
            colors = listOf(Color(0xFF0F0C29), Color(0xFF302B63), Color(0xFF24243E)),
            category = PaletteCategory.DARK,
            gradientAngle = 45f,
        ),
        CoverPalette(
            id = "dark_velvet",
            name = "Dark Velvet",
            colors = listOf(Color(0xFF1F1C18), Color(0xFF8E0E00), Color(0xFF1F1C18)),
            category = PaletteCategory.DARK,
            gradientAngle = 90f,
        ),

        // Pastel
        CoverPalette(
            id = "peach_cream",
            name = "Peach Pastel",
            colors = listOf(Color(0xFFFFECD2), Color(0xFFFCB69F), Color(0xFFFF9A8B)),
            category = PaletteCategory.PASTEL,
            gradientAngle = 45f,
        ),
        CoverPalette(
            id = "lavender_mist",
            name = "Lavender Mist",
            colors = listOf(Color(0xFFE0C3FC), Color(0xFF8EC5FC), Color(0xFFB993D6)),
            category = PaletteCategory.PASTEL,
            gradientAngle = 135f,
        ),
        CoverPalette(
            id = "mint_macaron",
            name = "Mint Macaron",
            colors = listOf(Color(0xFFD4FC79), Color(0xFF96E6A1), Color(0xFF84FAB0)),
            category = PaletteCategory.PASTEL,
            gradientAngle = 60f,
        ),
        CoverPalette(
            id = "cotton_candy",
            name = "Cotton Candy",
            colors = listOf(Color(0xFFA1C4FD), Color(0xFFC2E9FB), Color(0xFFFBC2EB)),
            category = PaletteCategory.PASTEL,
            gradientAngle = 120f,
        ),
    )

    fun getInitials(name: String): String {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return "PL"
        val words = trimmed.split("\\s+".toRegex()).filter { it.isNotBlank() }
        return when {
            words.size >= 2 -> {
                val first = words[0].take(1).uppercase()
                val second = words[1].take(1).uppercase()
                "$first$second"
            }
            trimmed.length >= 2 -> trimmed.take(2).uppercase()
            else -> trimmed.uppercase()
        }
    }

    fun generateCoverBitmap(
        context: Context,
        palette: CoverPalette,
        style: CoverOverlayStyle,
        playlistName: String,
        @DrawableRes selectedIconRes: Int = R.drawable.music_note,
        customInitials: String? = null,
        size: Int = 1080,
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val widthF = size.toFloat()
        val heightF = size.toFloat()

        // 1. Draw Gradient Background
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG)
        val argbColors = palette.colors.map { it.toArgb() }.toIntArray()

        if (palette.isRadial) {
            val radial = RadialGradient(
                widthF / 2f,
                heightF / 2f,
                widthF * 0.7f,
                argbColors,
                null,
                Shader.TileMode.CLAMP
            )
            paint.shader = radial
        } else {
            val angleRad = Math.toRadians(palette.gradientAngle.toDouble())
            val cosVal = cos(angleRad).toFloat()
            val sinVal = sin(angleRad).toFloat()

            val cx = widthF / 2f
            val cy = heightF / 2f
            val len = widthF * 0.85f

            val x0 = cx - cosVal * len
            val y0 = cy - sinVal * len
            val x1 = cx + cosVal * len
            val y1 = cy + sinVal * len

            val linear = LinearGradient(
                x0, y0, x1, y1,
                argbColors,
                null,
                Shader.TileMode.CLAMP
            )
            paint.shader = linear
        }

        canvas.drawRect(0f, 0f, widthF, heightF, paint)

        // 2. Draw Style Overlay
        when (style) {
            CoverOverlayStyle.CLEAN -> {
                // Subtle modern corner ambient ring
                drawAmbientRings(canvas, widthF, heightF)
            }

            CoverOverlayStyle.GEOMETRIC_WAVES -> {
                drawGeometricWaves(canvas, widthF, heightF)
            }

            CoverOverlayStyle.ICON -> {
                drawAmbientRings(canvas, widthF, heightF)
                drawCenterIcon(context, canvas, selectedIconRes, size)
            }

            CoverOverlayStyle.INITIALS -> {
                drawAmbientRings(canvas, widthF, heightF)
                val initials = customInitials?.takeIf { it.isNotBlank() } ?: getInitials(playlistName)
                drawCenterInitials(canvas, initials, size)
            }
        }

        return bitmap
    }

    private fun drawAmbientRings(canvas: Canvas, width: Float, height: Float) {
        val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 3f
            color = AndroidColor.WHITE
            alpha = 30
        }
        canvas.drawCircle(width * 0.85f, height * 0.15f, width * 0.4f, ringPaint)
        canvas.drawCircle(width * 0.85f, height * 0.15f, width * 0.6f, ringPaint)

        val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = AndroidColor.WHITE
            alpha = 15
        }
        canvas.drawCircle(width * 0.15f, height * 0.85f, width * 0.35f, glowPaint)
    }

    private fun drawGeometricWaves(canvas: Canvas, width: Float, height: Float) {
        val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 16f
            color = AndroidColor.WHITE
            alpha = 40
        }

        val path = Path()
        for (i in 0..4) {
            val offsetY = height * (0.25f + i * 0.15f)
            path.reset()
            path.moveTo(0f, offsetY)
            path.cubicTo(
                width * 0.3f, offsetY - 90f,
                width * 0.7f, offsetY + 90f,
                width, offsetY
            )
            canvas.drawPath(path, wavePaint)
        }

        // Add soft center badge backing
        val centerBadgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = AndroidColor.BLACK
            alpha = 35
        }
        canvas.drawCircle(width / 2f, height / 2f, width * 0.22f, centerBadgePaint)
    }

    private fun drawCenterIcon(
        context: Context,
        canvas: Canvas,
        @DrawableRes iconRes: Int,
        size: Int
    ) {
        val iconSize = (size * 0.36f).toInt()
        val drawable = ContextCompat.getDrawable(context, iconRes) ?: return

        val cx = size / 2
        val cy = size / 2
        val halfIcon = iconSize / 2

        // Draw soft circular background pill
        val pillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = AndroidColor.WHITE
            alpha = 45
        }
        canvas.drawCircle(cx.toFloat(), cy.toFloat(), iconSize * 0.85f, pillPaint)

        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 6f
            color = AndroidColor.WHITE
            alpha = 90
        }
        canvas.drawCircle(cx.toFloat(), cy.toFloat(), iconSize * 0.85f, borderPaint)

        // Draw Icon
        drawable.setBounds(cx - halfIcon, cy - halfIcon, cx + halfIcon, cy + halfIcon)
        drawable.setTint(AndroidColor.WHITE)
        drawable.draw(canvas)
    }

    private fun drawCenterInitials(
        canvas: Canvas,
        initials: String,
        size: Int
    ) {
        val cx = size / 2f
        val cy = size / 2f
        val badgeRadius = size * 0.30f

        // Center glass circle
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = AndroidColor.WHITE
            alpha = 50
        }
        canvas.drawCircle(cx, cy, badgeRadius, bgPaint)

        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 7f
            color = AndroidColor.WHITE
            alpha = 110
        }
        canvas.drawCircle(cx, cy, badgeRadius, borderPaint)

        // Draw Bold Initials Text
        val textSize = if (initials.length > 2) size * 0.18f else size * 0.24f
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = AndroidColor.WHITE
            this.textSize = textSize
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            setShadowLayer(16f, 0f, 6f, AndroidColor.argb(80, 0, 0, 0))
        }

        val bounds = Rect()
        textPaint.getTextBounds(initials, 0, initials.length, bounds)
        val textY = cy + (bounds.height() / 2f) - bounds.bottom

        canvas.drawText(initials, cx, textY, textPaint)
    }

    fun saveCoverBitmap(context: Context, playlistId: String, bitmap: Bitmap): Uri {
        val coversDir = File(context.filesDir, "playlist_covers").apply {
            if (!exists()) mkdirs()
        }
        val file = File(coversDir, "cover_${playlistId}_${System.currentTimeMillis()}.jpg")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
            out.flush()
        }
        return Uri.fromFile(file)
    }

    fun saveCustomImageFile(context: Context, playlistId: String, sourceUri: Uri): Uri {
        val coversDir = File(context.filesDir, "playlist_covers").apply {
            if (!exists()) mkdirs()
        }
        val file = File(coversDir, "cover_${playlistId}_${System.currentTimeMillis()}.jpg")

        context.contentResolver.openInputStream(sourceUri)?.use { input ->
            FileOutputStream(file).use { output ->
                input.copyTo(output)
                output.flush()
            }
        }
        return Uri.fromFile(file)
    }

    fun removeCustomCoverFiles(context: Context, playlistId: String) {
        try {
            val coversDir = File(context.filesDir, "playlist_covers")
            if (coversDir.exists()) {
                coversDir.listFiles { file ->
                    file.name.startsWith("cover_${playlistId}")
                }?.forEach { it.delete() }
            }
        } catch (_: Exception) {}
    }
}
