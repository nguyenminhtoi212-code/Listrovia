/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.utils

import android.content.Context
import com.listrovia.music.BuildConfig
import io.ktor.client.HttpClient
import io.ktor.client.request.get
import io.ktor.client.statement.bodyAsText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.time.Instant
import java.time.format.DateTimeFormatter

data class ReleaseNote(
    val version: String,
    val content: String
)

data class ReleaseInfo(
    val tagName: String,
    val versionName: String,
    val description: String,
    val descriptionVi: String = description,
    val descriptionEn: String = description,
    val releaseDate: String,
    val assets: List<ReleaseAsset>
)

data class ReleaseAsset(
    val name: String,
    val downloadUrl: String,
    val size: Long,
    val architecture: String,
    val variant: String // "foss" or "gms"
)

object Updater {
    private val client = HttpClient()
    var lastCheckTime = -1L
        private set
    
    private var cachedReleaseInfo: ReleaseInfo? = null
    private var cachedAllReleases: List<ReleaseInfo> = emptyList()
    
    private const val CHECK_INTERVAL_MILLIS = 2 * 60 * 60 * 1000L // 2 hours
    const val OFFICIAL_WEBSITE = "https://metrolist.cc"

    /**
     * Load changelog list directly from assets
     */
    fun loadChangelogFromAssets(context: Context, fileName: String = "changelog.txt"): List<ReleaseNote> {
        val releaseNotes = mutableListOf<ReleaseNote>()
        
        try {
            val inputStream = context.assets.open(fileName)
            val reader = BufferedReader(InputStreamReader(inputStream))
            
            val fullText = reader.readText()
            reader.close()

            // Tách các phiên bản dựa trên tiền tố ---v
            val rawBlocks = fullText.split("---v")

            for (block in rawBlocks) {
                if (block.isBlank()) continue
                
                // Dòng đầu tiên chứa số phiên bản
                val lines = block.trim().lines()
                val version = "v" + lines.firstOrNull()?.trim()
                val content = lines.drop(1).joinToString("\n").trim()

                releaseNotes.add(ReleaseNote(version = version, content = content))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return releaseNotes
    }

    /**
     * Compares two version strings.
     * Returns: 1 if v1 > v2, -1 if v1 < v2, 0 if equal
     */
    fun compareVersions(v1: String, v2: String): Int {
        val v1Parts = v1.removePrefix("v").split(".").map { it.toIntOrNull() ?: 0 }
        val v2Parts = v2.removePrefix("v").split(".").map { it.toIntOrNull() ?: 0 }
        val maxLength = maxOf(v1Parts.size, v2Parts.size)
        
        for (i in 0 until maxLength) {
            val part1 = v1Parts.getOrNull(i) ?: 0
            val part2 = v2Parts.getOrNull(i) ?: 0
            when {
                part1 > part2 -> return 1
                part1 < part2 -> return -1
            }
        }
        return 0
    }

    /**
     * Checks if the latest version is newer than the current version.
     * Returns true if an update is available (latestVersion > currentVersion)
     */
    fun isUpdateAvailable(currentVersion: String, latestVersion: String): Boolean {
        return compareVersions(latestVersion, currentVersion) > 0
    }

    /**
     * Checks whether the current app version is up to date against the latest version in changelog.txt
     * Returns Pair(isUpToDate, latestVersionTag)
     */
    fun checkUpToDateWithChangelog(context: Context): Pair<Boolean, String> {
        val notes = loadChangelogFromAssets(context)
        val latestTag = notes.firstOrNull()?.version ?: "v${BuildConfig.VERSION_NAME}"
        val latestVersionName = latestTag.removePrefix("v")
        val hasUpdate = isUpdateAvailable(BuildConfig.VERSION_NAME, latestVersionName)
        return Pair(!hasUpdate, latestTag)
    }

    /**
     * Get the current app's architecture and variant
     */
    private fun getCurrentAppVariant(): Pair<String, String> {
        val architecture = BuildConfig.ARCHITECTURE
        val variant = if (BuildConfig.CAST_AVAILABLE) "gms" else "foss"
        return architecture to variant
    }

    /**
     * Parse release assets from GitHub API response
     */
    private fun parseAssets(assetsArray: JSONArray): List<ReleaseAsset> {
        val assets = mutableListOf<ReleaseAsset>()
        
        for (i in 0 until assetsArray.length()) {
            val asset = assetsArray.getJSONObject(i)
            val name = asset.getString("name")
            
            // Skip non-APK files
            if (!name.endsWith(".apk")) continue
            
            val downloadUrl = asset.getString("browser_download_url")
            val size = asset.getLong("size")
            
            // Parse architecture and variant from filename
            val (arch, variant) = when {
                name == "Metrolist.apk" -> "universal" to "foss"
                name == "Metrolist-with-Google-Cast.apk" -> "universal" to "gms"
                name.startsWith("app-") && name.endsWith("-release.apk") -> {
                    val arch = name.removePrefix("app-").removeSuffix("-release.apk")
                    arch to "foss"
                }
                name.startsWith("app-") && name.endsWith("-with-Google-Cast.apk") -> {
                    val arch = name.removePrefix("app-").removeSuffix("-with-Google-Cast.apk")
                    arch to "gms"
                }
                else -> null to null
            }
            
            if (arch != null && variant != null) {
                assets.add(ReleaseAsset(name, downloadUrl, size, arch, variant))
            }
        }
        
        return assets
    }

    // Tối ưu hóa việc tạo đối tượng ReleaseInfo mới nhất theo thời gian thực
    fun fetchUpdatedReleaseInfo(): ReleaseInfo {
        val currentTimeIso = DateTimeFormatter.ISO_INSTANT.format(Instant.now())

        return ReleaseInfo(
            tagName = "v${BuildConfig.VERSION_NAME}",
            versionName = BuildConfig.VERSION_NAME,
            description = "",
            descriptionVi = "",
            descriptionEn = "",
            releaseDate = currentTimeIso, // Thời gian thực tại thời điểm gọi
            assets = listOf(
                ReleaseAsset(
                    name = "Metrolist.apk",
                    downloadUrl = OFFICIAL_WEBSITE,
                    size = 0L,
                    architecture = "universal",
                    variant = "foss"
                ),
                ReleaseAsset(
                    name = "Metrolist-with-Google-Cast.apk",
                    downloadUrl = OFFICIAL_WEBSITE,
                    size = 0L,
                    architecture = "universal",
                    variant = "gms"
                )
            )
        ).also { updatedInfo ->
            // Cập nhật bộ nhớ đệm và timestamp trong cùng một luồng xử lý
            cachedReleaseInfo = updatedInfo
            lastCheckTime = System.currentTimeMillis()
        }
    }

    /**
     * Fetch latest release
     */
    suspend fun getLatestRelease(forceRefresh: Boolean = false): Result<ReleaseInfo> =
        withContext(Dispatchers.IO) {
            runCatching {
                if (cachedReleaseInfo != null && !forceRefresh) {
                    return@runCatching cachedReleaseInfo!!
                }

                fetchUpdatedReleaseInfo()
            }
        }

    /**
     * Fetch all releases
     */
    suspend fun getAllReleases(context: Context? = null, forceRefresh: Boolean = false): Result<List<ReleaseInfo>> =
        withContext(Dispatchers.IO) {
            runCatching {
                if (context != null) {
                    val notes = loadChangelogFromAssets(context)
                    if (notes.isNotEmpty()) {
                        return@runCatching notes.map { note ->
                            ReleaseInfo(
                                tagName = note.version,
                                versionName = note.version.removePrefix("v"),
                                description = note.content,
                                descriptionVi = note.content,
                                descriptionEn = note.content,
                                releaseDate = "",
                                assets = emptyList()
                            )
                        }
                    }
                }
                val latest = getLatestRelease(forceRefresh).getOrThrow()
                listOf(latest)
            }
        }

    /**
     * Get the download URL for the correct app variant
     */
    fun getDownloadUrlForCurrentVariant(releaseInfo: ReleaseInfo): String? {
        val (currentArch, currentVariant) = getCurrentAppVariant()
        
        return releaseInfo.assets
            .find { it.architecture == currentArch && it.variant == currentVariant }
            ?.downloadUrl
    }

    /**
     * Get all available download URLs for a release
     */
    fun getAllDownloadUrls(releaseInfo: ReleaseInfo): Map<String, String> {
        return releaseInfo.assets.associate { "${it.architecture}-${it.variant}" to it.downloadUrl }
    }

    /**
     * Check if update is needed (respects 2-hour cache)
     */
    suspend fun checkForUpdate(
        context: Context? = null,
        source: String = "updater_service",
        forceRefresh: Boolean = false
    ): Result<Pair<ReleaseInfo?, Boolean>> =
        withContext(Dispatchers.IO) {
            runCatching {
                // Check if we should fetch (2 hour interval)
                val shouldFetch = forceRefresh || 
                    (System.currentTimeMillis() - lastCheckTime) > CHECK_INTERVAL_MILLIS
                
                if (!shouldFetch && cachedReleaseInfo != null) {
                    val hasUpdate = isUpdateAvailable(
                        BuildConfig.VERSION_NAME,
                        cachedReleaseInfo!!.versionName
                    )
                    UpdaterAnalytics.logUpdateCheck(
                        context = context,
                        source = source,
                        success = true,
                        hasUpdate = hasUpdate,
                        latestVersion = cachedReleaseInfo!!.versionName
                    )
                    if (hasUpdate) {
                        UpdaterAnalytics.logNewVersionDetected(
                            context = context,
                            latestVersion = cachedReleaseInfo!!.versionName,
                            source = source,
                            versionTag = cachedReleaseInfo!!.tagName
                        )
                    }
                    if (context != null) {
                        AppUpdateStatusHelper.recordUpdateCheck(
                            context = context,
                            hasUpdate = hasUpdate,
                            latestVersion = cachedReleaseInfo!!.versionName,
                            source = source,
                            downloadUrl = getDownloadUrlForCurrentVariant(cachedReleaseInfo!!),
                            releaseNotes = cachedReleaseInfo!!.description
                        )
                    }
                    return@runCatching cachedReleaseInfo!! to hasUpdate
                }
                
                val result = getLatestRelease(forceRefresh = true)
                if (result.isSuccess) {
                    val releaseInfo = result.getOrThrow()
                    val hasUpdate = isUpdateAvailable(
                        BuildConfig.VERSION_NAME,
                        releaseInfo.versionName
                    )
                    UpdaterAnalytics.logUpdateCheck(
                        context = context,
                        source = source,
                        success = true,
                        hasUpdate = hasUpdate,
                        latestVersion = releaseInfo.versionName
                    )
                    if (hasUpdate) {
                        UpdaterAnalytics.logNewVersionDetected(
                            context = context,
                            latestVersion = releaseInfo.versionName,
                            source = source,
                            versionTag = releaseInfo.tagName
                        )
                    }
                    if (context != null) {
                        AppUpdateStatusHelper.recordUpdateCheck(
                            context = context,
                            hasUpdate = hasUpdate,
                            latestVersion = releaseInfo.versionName,
                            source = source,
                            downloadUrl = getDownloadUrlForCurrentVariant(releaseInfo),
                            releaseNotes = releaseInfo.description
                        )
                    }
                    releaseInfo to hasUpdate
                } else {
                    val error = result.exceptionOrNull() ?: Exception("Unknown error")
                    UpdaterAnalytics.logUpdateCheck(
                        context = context,
                        source = source,
                        success = false,
                        hasUpdate = false,
                        errorMessage = error.message
                    )
                    throw error
                }
            }.onFailure { e ->
                UpdaterAnalytics.logUpdateCheck(
                    context = context,
                    source = source,
                    success = false,
                    hasUpdate = false,
                    errorMessage = e.message
                )
            }
        }

    /**
     * Get the download URL for the correct app variant
     * Returns null if no matching asset is found
     */
    fun getLatestDownloadUrl(): String? {
        return cachedReleaseInfo?.let { getDownloadUrlForCurrentVariant(it) }
    }
    
    /**
     * Get the latest release info (cached)
     */
    fun getCachedLatestRelease(): ReleaseInfo? = cachedReleaseInfo
}