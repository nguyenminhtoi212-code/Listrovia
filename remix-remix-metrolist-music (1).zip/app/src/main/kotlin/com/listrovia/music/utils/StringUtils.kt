/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.utils

import android.content.Context
import android.content.Intent
import com.listrovia.music.R

fun makeTimeString(duration: Long?): String {
    if (duration == null || duration < 0) return ""
    var sec = duration / 1000
    val day = sec / 86400
    sec %= 86400
    val hour = sec / 3600
    sec %= 3600
    val minute = sec / 60
    sec %= 60
    return when {
        day > 0 -> "%d:%02d:%02d:%02d".format(day, hour, minute, sec)
        hour > 0 -> "%d:%02d:%02d".format(hour, minute, sec)
        else -> "%d:%02d".format(minute, sec)
    }
}

fun joinByBullet(vararg str: String?) =
    str
        .filterNot {
            it.isNullOrEmpty()
        }.joinToString(separator = " • ")

fun <T> Iterable<T>.joinToArtistString(
    separator: CharSequence = ", ",
    transform: ((T) -> CharSequence)? = null,
): String {
    val list = this.toList()
    if (list.isEmpty()) return ""
    val stringList = list.map { transform?.invoke(it)?.toString() ?: it.toString() }
    return when (stringList.size) {
        1 -> stringList[0]
        2 -> "${stringList[0]}$separator${stringList[1]}"
        else -> {
            val allButLast = stringList.dropLast(1).joinToString(", ")
            "$allButLast$separator${stringList.last()}"
        }
    }
}

fun <T> Iterable<T>.joinToArtistString(
    transform: (T) -> CharSequence,
): String = joinToArtistString(separator = ", ", transform = transform)

fun getArtistSeparator(context: Context): String {
    return " ${context.getString(R.string.and)} "
}

fun shareSecureIntent(intent: Intent, context: Context, title: String? = null) {
    val chooser = Intent.createChooser(intent, title).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    context.startActivity(chooser)
}

fun compactViewCount(viewCountText: String): String {
    return viewCountText.lowercase()
        .replace("views", "")
        .replace("lượt xem", "")
        .trim()
}

