package com.listrovia.music.api

import kotlinx.coroutines.flow.StateFlow

interface UnifiedAiProvider {
    val providerName: String
    suspend fun fetchModels(forceRefresh: Boolean = false, apiKey: String = ""): Any
    // Other unified methods like chat(), etc.
}
