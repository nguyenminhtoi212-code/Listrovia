/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.screens.wrapped

import android.content.Context
import android.net.ConnectivityManager
import android.net.Uri
import androidx.core.net.toUri
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.listrovia.music.R
import com.listrovia.music.constants.AudioQuality
import com.listrovia.music.utils.YTPlayerUtils
import com.listrovia.music.utils.dataStore
import com.listrovia.music.utils.get
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber

class WrappedAudioService(
    private val context: Context,
) {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private var player: ExoPlayer? = null
    private var playbackJob: Job? = null

    private val _isMuted = MutableStateFlow(false)
    val isMuted = _isMuted.asStateFlow()

    private fun initPlayer() {
        if (player == null) {
            player = ExoPlayer.Builder(context).build().apply {
                addListener(object : Player.Listener {
                    override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                        Timber.tag("WrappedAudioService").e(error, "Player error")
                        playbackJob?.cancel()
                    }
                })
            }
        }
    }

    fun toggleMute() {
        _isMuted.value = !_isMuted.value
        player?.volume = if (_isMuted.value) 0f else 1f
    }

    suspend fun prepareTrack(songId: String?): Boolean {
        val songUri = getSongUri(songId)
        if (songUri == Uri.EMPTY) return false
        withContext(Dispatchers.Main) {
            initPlayer()
            val mediaItem = MediaItem.Builder()
                .setUri(songUri)
                .setMediaId(songId ?: "fallback")
                .build()
            player?.setMediaItem(mediaItem)
            player?.prepare()
        }
        return true
    }

    fun playTrack(songId: String?) {
        if (songId == null) return
        if (player?.currentMediaItem?.mediaId == songId) {
            Timber.tag("WrappedAudioService").d("Track $songId is already loaded or playing.")
            if (player?.isPlaying == false) player?.play()
            return
        }
        playbackJob?.cancel()

        playbackJob = scope.launch {
            try {
                val prepared = prepareTrack(songId)
                if (prepared) {
                    withContext(Dispatchers.Main) {
                        if (songId != "2-p9DM2Xvsc") {
                            player?.seekTo(30_000)
                        } else {
                            player?.seekTo(0)
                        }
                        player?.play()
                        player?.volume = if (_isMuted.value) 0f else 1f
                    }
                }
            } catch (e: Exception) {
                Timber.tag("WrappedAudioService").e(e, "Error during playback preparation")
            }
        }
    }

    private suspend fun getSongUri(songId: String?): Uri {
        val fallbackUri = Uri.EMPTY
        if (songId == null) {
            Timber.tag("WrappedAudio").i("No song ID provided, using fallback audio.")
            return fallbackUri
        }

        return try {
            val audioQuality = context.dataStore.get(com.listrovia.music.constants.AudioQualityKey).let { value ->
                if (value == "VERY_HIGH") AudioQuality.HIGH
                else AudioQuality.entries.find { it.name == value } ?: AudioQuality.AUTO
            }
            val playbackData = withContext(Dispatchers.IO) {
                YTPlayerUtils.playerResponseForPlayback(
                    videoId = songId,
                    audioQuality = audioQuality,
                    connectivityManager = connectivityManager,
                ).getOrNull()
            }
            val streamUrl = playbackData?.streamUrl
            if (streamUrl.isNullOrBlank()) {
                Timber.tag("WrappedAudio")
                    .w("Resolved URL for $songId is null or blank. Using fallback.")
                fallbackUri
            } else {
                streamUrl.toUri()
            }
        } catch (e: Exception) {
            Timber.tag("WrappedAudio").e(e, "Failed to resolve URL for $songId. Using fallback.")
            fallbackUri
        }
    }

    fun pause() {
        player?.pause()
    }

    fun resume() {
        player?.play()
    }

    fun release() {
        playbackJob?.cancel()
        player?.release()
        player = null
        Timber.tag("WrappedAudioService").d("Player released.")
    }
}
