package androidx.compose.ui

import androidx.compose.ui.graphics.Shape

fun Modifier.maskClip(shape: Shape): Modifier = this
