/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.screens.settings

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.navigation.NavController
import com.listrovia.music.LocalPlayerAwareWindowInsets
import com.listrovia.music.R
import com.listrovia.music.ui.component.AiTokenRedeemDialog
import com.listrovia.music.ui.component.AiTokenPurchaseModal
import com.listrovia.music.ui.component.AiAgeVerificationModal
import com.listrovia.music.api.*
import java.util.Locale
import com.listrovia.music.constants.AiProviderKey
import com.listrovia.music.constants.AiSystemPromptKey
import com.listrovia.music.constants.AutoTranslateKey
import com.listrovia.music.constants.AiRecommendationsKey
import com.listrovia.music.constants.DEFAULT_AI_SYSTEM_PROMPT
import com.listrovia.music.constants.AionLabsBaseUrl
import com.listrovia.music.constants.AionLabsDefaultModel
import com.listrovia.music.constants.DeepInfraBaseUrl
import com.listrovia.music.constants.DeepInfraDefaultModel
import com.listrovia.music.constants.DeeplApiKey
import com.listrovia.music.constants.DeeplFormalityKey
import com.listrovia.music.constants.GroqBaseUrl
import com.listrovia.music.constants.GroqDefaultModel
import com.listrovia.music.constants.HuggingFaceBaseUrl
import com.listrovia.music.constants.HuggingFaceDefaultModel
import com.listrovia.music.constants.LanguageCodeToName
import com.listrovia.music.constants.NvidiaBaseUrl
import com.listrovia.music.constants.NvidiaDefaultModel
import com.listrovia.music.constants.OpenRouterApiKey
import com.listrovia.music.constants.OpenRouterBaseUrlKey
import com.listrovia.music.constants.OpenRouterDefaultModel
import com.listrovia.music.constants.OpenRouterModelKey
import com.listrovia.music.constants.OpenRouterModelTierKey
import com.listrovia.music.constants.OpenRouterTierStable
import com.listrovia.music.constants.OpenRouterTierBeta
import com.listrovia.music.constants.OpenRouterTierDeveloper
import com.listrovia.music.constants.MiniAssistantEnabledKey
import com.listrovia.music.constants.TranslateLanguageKey
import com.listrovia.music.constants.TranslateModeKey
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import com.listrovia.music.ui.component.AionLabsModelExplorerDialog
import com.listrovia.music.ui.component.AionLabsRealtimeDeck
import com.listrovia.music.ui.component.HuggingFaceModelExplorerDialog
import com.listrovia.music.ui.component.HuggingFaceRealtimeDeck
import com.listrovia.music.ui.component.EnumDialog
import com.listrovia.music.ui.component.ApiKeyManagementDialog
import com.listrovia.music.ui.component.DeepInfraModelDialog
import androidx.compose.ui.graphics.Color
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.listrovia.music.LocalPlayerConnection
import com.listrovia.music.ui.component.LyricsTranslationDebugDialog
import com.listrovia.music.ui.component.Material3SettingsGroup
import com.listrovia.music.ui.component.Material3SettingsItem
import com.listrovia.music.ui.component.ModelSelector
import com.listrovia.music.ui.component.OpenRouterModelDialog
import com.listrovia.music.ui.component.ProviderAvatar
import com.listrovia.music.ui.component.ProviderBadge
import com.listrovia.music.ui.component.ProviderInfoModalDialog
import com.listrovia.music.ui.component.TextFieldDialog
import com.listrovia.music.ui.component.getProviderDetailedSpec
import com.listrovia.music.utils.rememberPreference
import com.listrovia.music.viewmodels.ModelViewModel
import com.listrovia.music.api.AiLimitManager
import com.listrovia.music.api.AiLimitState
import com.listrovia.music.ai.AiProviderRegistry

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiSettings(
    navController: NavController,
    modelViewModel: ModelViewModel = hiltViewModel(),
) {
    var aiProvider by rememberPreference(AiProviderKey, "OpenRouter")
    var openRouterApiKey by rememberPreference(OpenRouterApiKey, "")
    var openRouterBaseUrl by rememberPreference(OpenRouterBaseUrlKey, "https://openrouter.ai/api/v1/chat/completions")
    var openRouterModel by rememberPreference(OpenRouterModelKey, OpenRouterDefaultModel)
    var openRouterModelTier by rememberPreference(OpenRouterModelTierKey, OpenRouterTierStable)
    var translateLanguage by rememberPreference(TranslateLanguageKey, "en")
    var translateMode by rememberPreference(TranslateModeKey, "Literal")
    var deeplApiKey by rememberPreference(DeeplApiKey, "")
    var deeplFormality by rememberPreference(DeeplFormalityKey, "default")
    var aiSystemPrompt by rememberPreference(AiSystemPromptKey, "")
    var autoTranslate by rememberPreference(AutoTranslateKey, false)
    var aiRecommendations by rememberPreference(AiRecommendationsKey, true)
    var miniAssistantEnabled by rememberPreference(MiniAssistantEnabledKey, true)
    val apiKeyStatus by modelViewModel.apiKeyStatus.collectAsStateWithLifecycle()
    val isDark = isSystemInDarkTheme()
    val statusSuccessColor = if (isDark) Color(0xFF81C784) else Color(0xFF2E7D32)
    val statusWarningColor = if (isDark) Color(0xFFFFB74D) else Color(0xFFE65100)
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val isVietnamese = remember { java.util.Locale.getDefault().language == "vi" }
    val aiLimitState by AiLimitManager.getAiLimitState(context).collectAsStateWithLifecycle(initialValue = AiLimitState())

    val aiProviders = AiProviderRegistry.getAll().associate { it.id to it.detailedSpec.portalUrl }

    val providerHelpText =
        mapOf(
            "OpenRouter" to stringResource(R.string.ai_provider_openrouter_help),
            "HuggingFace" to stringResource(R.string.ai_provider_huggingface_help),
            "AionLabs" to stringResource(R.string.ai_provider_aionlabs_help),
            "DeepInfra" to stringResource(R.string.ai_provider_deepinfra_help),
            "Nvidia" to stringResource(R.string.ai_provider_nvidia_help),
            "Groq" to stringResource(R.string.ai_provider_groq_help),
            "OpenAI" to stringResource(R.string.ai_provider_openai_help),
            "Perplexity" to stringResource(R.string.ai_provider_perplexity_help),
            "Claude" to stringResource(R.string.ai_provider_claude_help),
            "Gemini" to stringResource(R.string.ai_provider_gemini_help),
            "XAi" to stringResource(R.string.ai_provider_xai_help),
            "Mistral" to stringResource(R.string.ai_provider_mistral_help),
            "Inception" to "Truy cập https://platform.inceptionlabs.ai để lấy khóa API / Visit https://platform.inceptionlabs.ai to get your API key",
            "OrcaRouter" to "Truy cập orcarouter.ai để sử dụng các mô hình mã nguồn mở và trả phí / Visit orcarouter.ai for open-source and paid models",
            "DeepL" to stringResource(R.string.ai_provider_deepl_help),
            "Custom" to "",
        )

    val huggingFaceRealtimeModels by modelViewModel.huggingFaceModels.collectAsStateWithLifecycle()

    var showProviderDialog by rememberSaveable { mutableStateOf(false) }
    var showProviderHelpDialog by rememberSaveable { mutableStateOf(false) }
    var selectedProviderForDetail by remember { mutableStateOf<String?>(null) }
    var showTranslateModeDialog by rememberSaveable { mutableStateOf(false) }
    var showTranslateModeHelpDialog by rememberSaveable { mutableStateOf(false) }
    var showLanguageDialog by rememberSaveable { mutableStateOf(false) }
    var showApiKeyDialog by rememberSaveable { mutableStateOf(false) }
    var showDeeplApiKeyDialog by rememberSaveable { mutableStateOf(false) }
    var showDeeplFormalityDialog by rememberSaveable { mutableStateOf(false) }
    var showBaseUrlDialog by rememberSaveable { mutableStateOf(false) }
    var showModelDialog by rememberSaveable { mutableStateOf(false) }
    var showTierDialog by rememberSaveable { mutableStateOf(false) }
    var showCustomModelInput by rememberSaveable { mutableStateOf(false) }
    var showSystemPromptDialog by rememberSaveable { mutableStateOf(false) }
    var showDebugDialog by rememberSaveable { mutableStateOf(false) }
    var showRedeemDialog by rememberSaveable { mutableStateOf(false) }
    var showPurchaseModal by rememberSaveable { mutableStateOf(false) }
    var showAgeVerificationModal by rememberSaveable { mutableStateOf(false) }

    val ageProtectionState by AiAgeProtectionManager.getAgeProtectionState(context).collectAsStateWithLifecycle(initialValue = AgeProtectionState())

    if (showRedeemDialog) {
        AiTokenRedeemDialog(onDismissRequest = { showRedeemDialog = false })
    }

    if (showPurchaseModal) {
        AiTokenPurchaseModal(onDismissRequest = { showPurchaseModal = false })
    }

    if (showAgeVerificationModal) {
        AiAgeVerificationModal(
            currentState = ageProtectionState,
            onDismissRequest = { showAgeVerificationModal = false }
        )
    }

    selectedProviderForDetail?.let { prov ->
        ProviderInfoModalDialog(
            modelIdOrProvider = prov,
            providerName = prov,
            onDismiss = { selectedProviderForDetail = null },
            onOpenPortal = { url ->
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    context.startActivity(intent)
                } catch (_: Exception) {}
            },
        )
    }

    if (showProviderHelpDialog) {
        Dialog(
            onDismissRequest = { showProviderHelpDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false),
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(26.dp)),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f),
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.info),
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(20.dp),
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(R.string.ai_provider_help),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Text(
                                    text = stringResource(R.string.ai_provider_help_list_title),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }

                        IconButton(
                            onClick = { showProviderHelpDialog = false },
                            modifier = Modifier.size(34.dp),
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.close),
                                contentDescription = stringResource(R.string.close),
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        // API key notice card
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f),
                            ),
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp),
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    Icon(
                                        painter = painterResource(R.drawable.security),
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp),
                                    )
                                    Text(
                                        text = stringResource(R.string.ai_api_key_note_title),
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                                Text(
                                    text = stringResource(R.string.ai_api_key_note_content),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }

                        // Uniform Provider Cards
                        providerHelpText.keys.filter { it != "Custom" }.forEach { provider ->
                            val spec = remember(provider) {
                                getProviderDetailedSpec(provider, provider)
                            }
                            val isCurrent = aiProvider == provider
                            val cleanDomain = spec.portalDomain

                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = if (isCurrent) {
                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                                } else {
                                    MaterialTheme.colorScheme.surfaceContainerLow
                                },
                                border = BorderStroke(
                                    width = 1.dp,
                                    color = if (isCurrent) {
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                                    } else {
                                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                    },
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { selectedProviderForDetail = provider },
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                ) {
                                    ProviderAvatar(
                                        modelId = provider,
                                        providerName = provider,
                                        size = 38.dp,
                                    )

                                    Column(
                                        modifier = Modifier.weight(1f),
                                        verticalArrangement = Arrangement.spacedBy(3.dp),
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            modifier = Modifier.fillMaxWidth(),
                                        ) {
                                            Text(
                                                text = spec.officialTitle,
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                modifier = Modifier.weight(1f, fill = false),
                                            )
                                            ProviderBadge(
                                                modelId = provider,
                                                providerName = provider,
                                                onClick = { selectedProviderForDetail = provider },
                                            )
                                        }

                                        Text(
                                            text = if (isVietnamese) spec.specialtyVi else spec.specialtyEn,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis,
                                        )

                                        Text(
                                            text = cleanDomain,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.primary,
                                            maxLines = 1,
                                            softWrap = false,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                    }

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(2.dp),
                                    ) {
                                        IconButton(
                                            onClick = { selectedProviderForDetail = provider },
                                            modifier = Modifier.size(32.dp),
                                        ) {
                                            Icon(
                                                painter = painterResource(R.drawable.info),
                                                contentDescription = stringResource(R.string.ai_provider_help),
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(18.dp),
                                            )
                                        }
                                        IconButton(
                                            onClick = {
                                                try {
                                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(spec.portalUrl))
                                                    context.startActivity(intent)
                                                } catch (_: Exception) {}
                                            },
                                            modifier = Modifier.size(32.dp),
                                        ) {
                                            Icon(
                                                painter = painterResource(R.drawable.link),
                                                contentDescription = cleanDomain,
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(18.dp),
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                    ) {
                        FilledTonalButton(
                            onClick = { showProviderHelpDialog = false },
                            shape = RoundedCornerShape(12.dp),
                        ) {
                            Text(text = stringResource(android.R.string.ok))
                        }
                    }
                }
            }
        }
    }

    if (showTranslateModeHelpDialog) {
        AlertDialog(
            onDismissRequest = { showTranslateModeHelpDialog = false },
            confirmButton = {
                TextButton(onClick = { showTranslateModeHelpDialog = false }) {
                    Text(stringResource(android.R.string.ok))
                }
            },
            icon = { Icon(painterResource(R.drawable.info), null) },
            title = { Text(stringResource(R.string.ai_translation_mode)) },
            text = {
                Column {
                    Text(
                        text = "${stringResource(R.string.ai_translation_literal)}:",
                        style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                    Text(
                        text = stringResource(R.string.ai_translation_literal_desc),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(bottom = 12.dp),
                    )

                    Text(
                        text = "${stringResource(R.string.ai_translation_transcribed)}:",
                        style = MaterialTheme.typography.titleSmall,
                    )
                    Text(
                        text = stringResource(R.string.ai_translation_transcribed_desc),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            },
        )
    }

    if (showProviderDialog) {
        Dialog(
            onDismissRequest = { showProviderDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false),
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .heightIn(max = 640.dp)
                    .clip(RoundedCornerShape(26.dp)),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f),
                        ) {
                            ProviderAvatar(
                                modelId = aiProvider,
                                providerName = aiProvider,
                                size = 38.dp,
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(R.string.ai_provider),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Text(
                                    text = if (isVietnamese) {
                                        "Chọn nhà cung cấp hoặc nhấn ⓘ để xem chi tiết"
                                    } else {
                                        "Select a provider or tap ⓘ for details"
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }

                        IconButton(
                            onClick = { showProviderDialog = false },
                            modifier = Modifier.size(34.dp),
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.close),
                                contentDescription = stringResource(R.string.close),
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 480.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        items(
                            items = aiProviders.keys.toList(),
                            key = { it },
                        ) { providerOption ->
                            val isSelected = aiProvider == providerOption
                            val spec = remember(providerOption) {
                                getProviderDetailedSpec(providerOption, providerOption)
                            }
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = if (isSelected) {
                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                                } else {
                                    MaterialTheme.colorScheme.surfaceContainerLow
                                },
                                border = BorderStroke(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
                                    },
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable {
                                        aiProvider = providerOption
                                        if (providerOption != "Custom" && providerOption != "DeepL") {
                                            openRouterBaseUrl = aiProviders[providerOption] ?: ""
                                        } else {
                                            openRouterBaseUrl = ""
                                        }
                                        val liveHfPick = huggingFaceRealtimeModels?.topSpotlightModel?.id
                                            ?: huggingFaceRealtimeModels?.recommended?.firstOrNull()?.id
                                            ?: HuggingFaceDefaultModel
                                        openRouterModel =
                                            if (providerOption == "OpenRouter") {
                                                if (openRouterModel.isBlank()) OpenRouterDefaultModel else openRouterModel
                                            } else if (providerOption == "HuggingFace") {
                                                modelViewModel.loadHuggingFaceModels(forceRefresh = true, apiKey = openRouterApiKey)
                                                liveHfPick
                                            } else if (providerOption == "AionLabs") {
                                                AionLabsDefaultModel
                                            } else if (providerOption == "DeepInfra") {
                                                if (openRouterModel.isBlank() || !openRouterModel.contains("/")) DeepInfraDefaultModel else openRouterModel
                                            } else if (providerOption == "Nvidia") {
                                                NvidiaDefaultModel
                                            } else if (providerOption == "Groq") {
                                                GroqDefaultModel
                                            } else if (providerOption == "DeepL" || providerOption == "Custom") {
                                                ""
                                            } else {
                                                liveHfPick
                                            }
                                        showProviderDialog = false
                                    },
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                ) {
                                    ProviderAvatar(
                                        modelId = providerOption,
                                        providerName = providerOption,
                                        size = 36.dp,
                                    )

                                    Column(
                                        modifier = Modifier.weight(1f),
                                        verticalArrangement = Arrangement.spacedBy(2.dp),
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            modifier = Modifier.fillMaxWidth(),
                                        ) {
                                            Text(
                                                text = providerOption,
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                modifier = Modifier.weight(1f, fill = false),
                                            )
                                            ProviderBadge(
                                                modelId = providerOption,
                                                providerName = providerOption,
                                                onClick = { selectedProviderForDetail = providerOption },
                                            )
                                        }
                                        Text(
                                            text = if (isVietnamese) spec.specialtyVi else spec.specialtyEn,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                    }

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(2.dp),
                                    ) {
                                        if (providerOption != "Custom") {
                                            IconButton(
                                                onClick = { selectedProviderForDetail = providerOption },
                                                modifier = Modifier.size(30.dp),
                                            ) {
                                                Icon(
                                                    painter = painterResource(R.drawable.info),
                                                    contentDescription = stringResource(R.string.ai_provider_help),
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(18.dp),
                                                )
                                            }
                                        }
                                        RadioButton(
                                            selected = isSelected,
                                            onClick = null,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showTranslateModeDialog) {
        EnumDialog(
            onDismiss = { showTranslateModeDialog = false },
            onSelect = {
                translateMode = it
                showTranslateModeDialog = false
            },
            title = stringResource(R.string.ai_translation_mode),
            current = translateMode,
            values = listOf("Literal", "Transcribed"),
            valueText = {
                when (it) {
                    "Literal" -> stringResource(R.string.ai_translation_literal)
                    "Transcribed" -> stringResource(R.string.ai_translation_transcribed)
                    else -> it
                }
            },
        )
    }

    if (showLanguageDialog) {
        EnumDialog(
            onDismiss = { showLanguageDialog = false },
            onSelect = {
                translateLanguage = it
                showLanguageDialog = false
            },
            title = stringResource(R.string.ai_target_language),
            current = translateLanguage,
            values = LanguageCodeToName.keys.sortedBy { LanguageCodeToName[it] },
            valueText = { LanguageCodeToName[it] ?: it },
        )
    }

    if (showApiKeyDialog) {
        ApiKeyManagementDialog(
            provider = aiProvider,
            initialApiKey = openRouterApiKey,
            initialStatus = apiKeyStatus,
            baseUrl = openRouterBaseUrl,
            onDismiss = { showApiKeyDialog = false },
            onSaveKey = { key, status ->
                openRouterApiKey = key
                if (status.isNotBlank()) {
                    modelViewModel.setApiKeyStatus(status)
                }
                showApiKeyDialog = false
            },
            viewModel = modelViewModel,
        )
    }

    if (showDeeplApiKeyDialog) {
        ApiKeyManagementDialog(
            provider = "DeepL",
            initialApiKey = deeplApiKey,
            initialStatus = "",
            baseUrl = "",
            onDismiss = { showDeeplApiKeyDialog = false },
            onSaveKey = { key, _ ->
                deeplApiKey = key
                showDeeplApiKeyDialog = false
            },
            viewModel = modelViewModel,
        )
    }

    if (showDeeplFormalityDialog) {
        EnumDialog(
            onDismiss = { showDeeplFormalityDialog = false },
            onSelect = {
                deeplFormality = it
                showDeeplFormalityDialog = false
            },
            title = stringResource(R.string.ai_deepl_formality),
            current = deeplFormality,
            values = listOf("default", "more", "less"),
            valueText = {
                when (it) {
                    "default" -> stringResource(R.string.ai_deepl_formality_default)
                    "more" -> stringResource(R.string.ai_deepl_formality_more)
                    "less" -> stringResource(R.string.ai_deepl_formality_less)
                    else -> it
                }
            },
        )
    }

    if (showBaseUrlDialog && aiProvider == "Custom") {
        TextFieldDialog(
            title = { Text(stringResource(R.string.ai_base_url)) },
            icon = { Icon(painterResource(R.drawable.link), null) },
            initialTextFieldValue = TextFieldValue(text = openRouterBaseUrl),
            onDone = {
                openRouterBaseUrl = it
                showBaseUrlDialog = false
            },
            onDismiss = { showBaseUrlDialog = false },
        )
    }

    if (showTierDialog) {
        EnumDialog(
            onDismiss = { showTierDialog = false },
            onSelect = {
                openRouterModelTier = it
                modelViewModel.selectTier(it)
                showTierDialog = false
            },
            title = stringResource(R.string.ai_model_select_tier),
            current = openRouterModelTier,
            values = listOf(OpenRouterTierStable, OpenRouterTierBeta, OpenRouterTierDeveloper),
            valueText = {
                when (it) {
                    OpenRouterTierBeta -> stringResource(R.string.ai_model_tier_beta) + " - " + stringResource(R.string.ai_model_tier_beta_desc)
                    OpenRouterTierDeveloper -> stringResource(R.string.ai_model_tier_dev) + " - " + stringResource(R.string.ai_model_tier_dev_desc)
                    else -> stringResource(R.string.ai_model_tier_stable) + " - " + stringResource(R.string.ai_model_tier_stable_desc)
                }
            },
        )
    }

    if (showModelDialog) {
        if (aiProvider == "OpenRouter") {
            OpenRouterModelDialog(
                currentModel = openRouterModel,
                initialTier = openRouterModelTier,
                viewModel = modelViewModel,
                onDismiss = { showModelDialog = false },
                onSelectModel = { selected ->
                    openRouterModel = selected
                    showModelDialog = false
                },
                onSelectTier = { selectedTier ->
                    openRouterModelTier = selectedTier
                },
                onCustomInput = {
                    showModelDialog = false
                    showCustomModelInput = true
                },
            )
        } else if (aiProvider == "HuggingFace") {
            HuggingFaceModelExplorerDialog(
                currentModel = openRouterModel,
                apiKey = openRouterApiKey,
                onDismiss = { showModelDialog = false },
                onSelectModel = { selected ->
                    openRouterModel = selected
                    showModelDialog = false
                },
                onCustomInput = {
                    showModelDialog = false
                    showCustomModelInput = true
                },
            )
        } else if (aiProvider == "AionLabs") {
            AionLabsModelExplorerDialog(
                currentModel = openRouterModel,
                apiKey = openRouterApiKey,
                onDismiss = { showModelDialog = false },
                onSelectModel = { selected ->
                    openRouterModel = selected
                    showModelDialog = false
                },
                onCustomInput = {
                    showModelDialog = false
                    showCustomModelInput = true
                },
            )
        } else if (aiProvider == "DeepInfra") {
            DeepInfraModelDialog(
                currentModel = openRouterModel,
                onDismiss = { showModelDialog = false },
                onSelectModel = { selected ->
                    openRouterModel = selected
                    showModelDialog = false
                },
                onCustomInput = {
                    showModelDialog = false
                    showCustomModelInput = true
                },
            )
        } else {
            HuggingFaceModelExplorerDialog(
                currentModel = openRouterModel,
                apiKey = openRouterApiKey,
                onDismiss = { showModelDialog = false },
                onSelectModel = { selected ->
                    openRouterModel = selected
                    showModelDialog = false
                },
                onCustomInput = {
                    showModelDialog = false
                    showCustomModelInput = true
                },
            )
        }
    }

    if (showCustomModelInput) {
        TextFieldDialog(
            title = { Text(stringResource(R.string.ai_model)) },
            icon = { Icon(painterResource(R.drawable.discover_tune), null) },
            initialTextFieldValue = TextFieldValue(text = openRouterModel),
            onDone = {
                openRouterModel = it
                showCustomModelInput = false
            },
            onDismiss = { showCustomModelInput = false },
        )
    }

    if (showSystemPromptDialog) {
        TextFieldDialog(
            title = { Text(stringResource(R.string.ai_system_prompt)) },
            icon = { Icon(painterResource(R.drawable.edit), null) },
            initialTextFieldValue = TextFieldValue(text = aiSystemPrompt.ifBlank { DEFAULT_AI_SYSTEM_PROMPT }),
            singleLine = false,
            maxLines = 12,
            isInputValid = { true },
            onDone = {
                // Treat saving the unmodified default (or blank) as "use default"
                aiSystemPrompt = if (it.isBlank() || it == DEFAULT_AI_SYSTEM_PROMPT) "" else it
                showSystemPromptDialog = false
            },
            onDismiss = { showSystemPromptDialog = false },
            extraContent = {
                if (aiSystemPrompt.isNotBlank()) {
                    Row(
                        modifier =
                            Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.End,
                    ) {
                        TextButton(
                            onClick = {
                                aiSystemPrompt = ""
                                showSystemPromptDialog = false
                            },
                        ) {
                            Text(stringResource(R.string.ai_system_prompt_reset))
                        }
                    }
                }
            },
        )
    }

    if (showDebugDialog) {
        val playerConnection = LocalPlayerConnection.current
        val lyricsEntity by playerConnection?.currentLyrics?.collectAsStateWithLifecycle(initialValue = null)
            ?: remember { mutableStateOf(null) }
        val mediaMetadata by playerConnection?.mediaMetadata?.collectAsStateWithLifecycle(initialValue = null)
            ?: remember { mutableStateOf(null) }

        LyricsTranslationDebugDialog(
            onDismiss = { showDebugDialog = false },
            currentSongLyrics = lyricsEntity?.lyrics,
            currentSongTitle = mediaMetadata?.title,
            currentSongArtist = mediaMetadata?.artists?.joinToString(", ") { it.name },
            modelViewModel = modelViewModel,
        )
    }

    Column(
        Modifier
            .windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom,
                ),
            ).verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
    ) {
        Spacer(
            Modifier.windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Top,
                ),
            ),
        )

        val isVietnamese = java.util.Locale.getDefault().language == "vi"
        val bannerText = if (isVietnamese) {
            "Tối ưu hóa trải nghiệm âm nhạc với dịch lời bài hát AI và Romanization thông minh."
        } else {
            "Optimize your music experience with AI lyrics translation and smart Romanization."
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .background(
                            MaterialTheme.colorScheme.primary,
                            shape = RoundedCornerShape(16.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = painterResource(R.drawable.translate),
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(32.dp)
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = stringResource(R.string.ai_lyrics_translation),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = bannerText,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        Material3SettingsGroup(
            title = stringResource(R.string.mini_assistant_title),
            items =
                listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.explore_outlined),
                        title = { Text(stringResource(R.string.mini_assistant_enabled_title)) },
                        description = { Text(stringResource(R.string.mini_assistant_desc)) },
                        onClick = { miniAssistantEnabled = !miniAssistantEnabled },
                        trailingContent = {
                            Switch(
                                checked = miniAssistantEnabled,
                                onCheckedChange = { miniAssistantEnabled = it },
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (miniAssistantEnabled) R.drawable.check else R.drawable.close
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize)
                                    )
                                }
                            )
                        },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.mic),
                        title = { Text(stringResource(R.string.mini_assistant_model_title)) },
                        description = { Text(if (aiProvider == "Custom") openRouterModel else "$aiProvider ($openRouterModel)") },
                        onClick = { showProviderDialog = true },
                    ),
                ),
        )

        Material3SettingsGroup(
            title = stringResource(R.string.ai_provider),
            items =
                listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.explore_outlined),
                        title = {
                            Text(
                                text = stringResource(R.string.ai_provider),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        },
                        description = {
                            val activeSpec = remember(aiProvider) {
                                getProviderDetailedSpec(aiProvider, aiProvider)
                            }
                            val catLabel = if (isVietnamese) activeSpec.categoryLabelVi else activeSpec.categoryLabelEn
                            Text(
                                text = "${activeSpec.visual.name} • $catLabel",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        },
                        onClick = { showProviderDialog = true },
                        trailingContent = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                            ) {
                                ProviderBadge(
                                    modelId = aiProvider,
                                    providerName = aiProvider,
                                    onClick = {
                                        if (aiProvider != "Custom") {
                                            selectedProviderForDetail = aiProvider
                                        } else {
                                            showProviderHelpDialog = true
                                        }
                                    },
                                )
                                IconButton(
                                    onClick = {
                                        if (aiProvider != "Custom") {
                                            selectedProviderForDetail = aiProvider
                                        } else {
                                            showProviderHelpDialog = true
                                        }
                                    },
                                    modifier = Modifier.size(34.dp),
                                ) {
                                    Icon(
                                        painterResource(R.drawable.info),
                                        contentDescription = stringResource(R.string.ai_provider_help),
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp),
                                    )
                                }
                            }
                        },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.info),
                        title = {
                            Text(
                                text = stringResource(R.string.ai_provider_help),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        },
                        description = {
                            Text(
                                text = stringResource(R.string.ai_provider_help_list_title),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        },
                        onClick = { showProviderHelpDialog = true },
                    ),
                    if (aiProvider == "Custom") {
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.link),
                            title = { Text(stringResource(R.string.ai_base_url)) },
                            description = { Text(openRouterBaseUrl.ifBlank { stringResource(R.string.not_set) }) },
                            onClick = { showBaseUrlDialog = true },
                        )
                    } else {
                        null
                    },
                ).filterNotNull(),
        )

        Spacer(modifier = Modifier.height(27.dp))

        // Security Warning Card for API Key Protection
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.errorContainer,
            ),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Icon(
                    painter = painterResource(R.drawable.security),
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(22.dp),
                )
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = stringResource(R.string.ai_api_key_security_warning_title),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.error,
                    )
                    Text(
                        text = stringResource(R.string.ai_api_key_security_warning_desc),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        text = stringResource(R.string.ai_api_key_security_censored_hint),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium,
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.ai_setup_guide),
            items =
                buildList {
                    if (aiProvider == "DeepL") {
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.key),
                                title = {
                                    Text(
                                        text = "DeepL ${stringResource(R.string.ai_api_key)}",
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                },
                                description = {
                                    Text(
                                        text = if (deeplApiKey.isNotEmpty()) {
                                            "•".repeat(minOf(deeplApiKey.length, 8))
                                        } else {
                                            stringResource(R.string.not_set)
                                        },
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                },
                                onClick = { showDeeplApiKeyDialog = true },
                            ),
                        )
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.tune),
                                title = {
                                    Text(
                                        text = stringResource(R.string.ai_deepl_formality),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                },
                                description = {
                                    Text(
                                        text = when (deeplFormality) {
                                            "default" -> stringResource(R.string.ai_deepl_formality_default)
                                            "more" -> stringResource(R.string.ai_deepl_formality_more)
                                            "less" -> stringResource(R.string.ai_deepl_formality_less)
                                            else -> deeplFormality
                                        },
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                },
                                onClick = { showDeeplFormalityDialog = true },
                            ),
                        )
                    } else if (aiProvider == "OpenRouter") {
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.key),
                                title = {
                                    Text(
                                        text = stringResource(R.string.ai_api_key),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                },
                                description = {
                                    val statusSuffix = when (apiKeyStatus) {
                                        "valid", "valid_active" -> " • " + stringResource(R.string.ai_api_key_status_valid)
                                        "valid_renewed", "renewed_extended" -> " • " + stringResource(R.string.ai_api_key_status_valid_renewed)
                                        "valid_free", "lifetime_free" -> " • " + stringResource(R.string.ai_api_key_status_valid_free)
                                        "invalid", "invalid_spoofed" -> " • " + stringResource(R.string.ai_api_key_status_invalid)
                                        "exhausted", "expired" -> " • " + stringResource(R.string.ai_api_key_status_exhausted)
                                        else -> ""
                                    }
                                    Text(
                                        text = if (openRouterApiKey.isNotEmpty()) {
                                            "•".repeat(minOf(openRouterApiKey.length, 8)) + statusSuffix
                                        } else {
                                            stringResource(R.string.not_set)
                                        },
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                },
                                trailingContent = {
                                    if (openRouterApiKey.isNotEmpty()) {
                                        when (apiKeyStatus) {
                                            "valid", "valid_active", "valid_renewed", "renewed_extended", "valid_free", "lifetime_free" -> Icon(
                                                painter = painterResource(R.drawable.check),
                                                contentDescription = stringResource(R.string.ai_api_key_status_valid),
                                                tint = statusSuccessColor,
                                                modifier = Modifier.size(20.dp),
                                            )
                                            "invalid", "invalid_spoofed" -> Icon(
                                                painter = painterResource(R.drawable.error),
                                                contentDescription = stringResource(R.string.ai_api_key_status_invalid),
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(20.dp),
                                            )
                                            "exhausted", "expired" -> Icon(
                                                painter = painterResource(R.drawable.warning),
                                                contentDescription = stringResource(R.string.ai_api_key_status_exhausted),
                                                tint = statusWarningColor,
                                                modifier = Modifier.size(20.dp),
                                            )
                                            else -> {}
                                        }
                                    }
                                },
                                onClick = { showApiKeyDialog = true },
                            ),
                        )
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.discover_tune),
                                title = { Text(stringResource(R.string.ai_model)) },
                                description = { Text(openRouterModel.ifBlank { stringResource(R.string.not_set) }) },
                                onClick = { showModelDialog = true },
                            ),
                        )
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.shuffle),
                                title = { Text(stringResource(R.string.ai_model_random_recommend)) },
                                description = { Text(stringResource(R.string.ai_model_random_recommend_desc)) },
                                onClick = {
                                    modelViewModel.recommendRandomModel(forceRefresh = true) { item ->
                                        openRouterModel = item.id
                                        Toast.makeText(
                                            context,
                                            context.getString(R.string.ai_model_random_recommended_toast, item.name.ifBlank { item.id }),
                                            Toast.LENGTH_LONG,
                                        ).show()
                                    }
                                },
                            ),
                        )
                    } else {
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.key),
                                title = {
                                    Text(
                                        text = stringResource(R.string.ai_api_key),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                },
                                description = {
                                    if (aiProvider == "DeepInfra" && openRouterApiKey.isEmpty()) {
                                        Text(
                                            text = stringResource(R.string.ai_deepinfra_key_desc),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                    } else {
                                        val statusSuffix = when (apiKeyStatus) {
                                            "valid", "valid_active" -> " • " + stringResource(R.string.ai_api_key_status_valid)
                                            "valid_renewed", "renewed_extended" -> " • " + stringResource(R.string.ai_api_key_status_valid_renewed)
                                            "valid_free", "lifetime_free" -> " • " + stringResource(R.string.ai_api_key_status_valid_free)
                                            "invalid", "invalid_spoofed" -> " • " + stringResource(R.string.ai_api_key_status_invalid)
                                            "exhausted", "expired" -> " • " + stringResource(R.string.ai_api_key_status_exhausted)
                                            else -> ""
                                        }
                                        Text(
                                            text = if (openRouterApiKey.isNotEmpty()) {
                                                "•".repeat(minOf(openRouterApiKey.length, 8)) + statusSuffix
                                            } else {
                                                stringResource(R.string.not_set)
                                            },
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                    }
                                },
                                trailingContent = {
                                    if (openRouterApiKey.isNotEmpty()) {
                                        when (apiKeyStatus) {
                                            "valid", "valid_active", "valid_renewed", "renewed_extended", "valid_free", "lifetime_free" -> Icon(
                                                painter = painterResource(R.drawable.check),
                                                contentDescription = stringResource(R.string.ai_api_key_status_valid),
                                                tint = statusSuccessColor,
                                                modifier = Modifier.size(20.dp),
                                            )
                                            "invalid", "invalid_spoofed" -> Icon(
                                                painter = painterResource(R.drawable.error),
                                                contentDescription = stringResource(R.string.ai_api_key_status_invalid),
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(20.dp),
                                            )
                                            "exhausted", "expired" -> Icon(
                                                painter = painterResource(R.drawable.warning),
                                                contentDescription = stringResource(R.string.ai_api_key_status_exhausted),
                                                tint = statusWarningColor,
                                                modifier = Modifier.size(20.dp),
                                            )
                                            else -> {}
                                        }
                                    }
                                },
                                onClick = { showApiKeyDialog = true },
                            ),
                        )
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.discover_tune),
                                title = { Text(stringResource(R.string.ai_model)) },
                                description = { Text(openRouterModel.ifBlank { stringResource(R.string.not_set) }) },
                                onClick = { showModelDialog = true },
                            ),
                        )
                        if (aiProvider == "OpenRouter") {
                            add(
                                Material3SettingsItem(
                                    icon = painterResource(R.drawable.tune),
                                    title = { Text(stringResource(R.string.ai_model_tier)) },
                                    description = {
                                        val tierLabel = when (openRouterModelTier) {
                                            OpenRouterTierBeta -> stringResource(R.string.ai_model_tier_beta)
                                            OpenRouterTierDeveloper -> stringResource(R.string.ai_model_tier_dev)
                                            else -> stringResource(R.string.ai_model_tier_stable)
                                        }
                                        Text(tierLabel)
                                    },
                                    onClick = { showTierDialog = true },
                                ),
                            )
                        }
                    }
                },
        )

        if (aiProvider == "HuggingFace") {
            Spacer(modifier = Modifier.height(14.dp))
            HuggingFaceRealtimeDeck(
                selectedModel = openRouterModel,
                apiKey = openRouterApiKey,
                onModelSelected = { openRouterModel = it },
                onOpenExplorerClick = { showModelDialog = true },
                onCustomModelClick = { showCustomModelInput = true },
                viewModel = modelViewModel,
            )
        } else if (aiProvider == "AionLabs") {
            Spacer(modifier = Modifier.height(14.dp))
            AionLabsRealtimeDeck(
                selectedModel = openRouterModel,
                apiKey = openRouterApiKey,
                onModelSelected = { openRouterModel = it },
                onOpenExplorerClick = { showModelDialog = true },
                onCustomModelClick = { showCustomModelInput = true },
                viewModel = modelViewModel,
            )
        } else if (aiProvider == "DeepInfra") {
            Spacer(modifier = Modifier.height(14.dp))
            ModelSelector(
                selectedModel = openRouterModel,
                onModelSelected = { openRouterModel = it },
                onCustomModelClick = { showCustomModelInput = true },
                onShowAllModelsClick = { showModelDialog = true },
                viewModel = modelViewModel,
            )
        }

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.ai_translation_mode),
            items =
                buildList {
                    if (aiProvider != "DeepL") {
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.translate),
                                title = { Text(stringResource(R.string.ai_translation_mode)) },
                                description = {
                                    Text(
                                        when (translateMode) {
                                            "Literal" -> stringResource(R.string.ai_translation_literal)
                                            "Transcribed" -> stringResource(R.string.ai_translation_transcribed)
                                            else -> translateMode
                                        },
                                    )
                                },
                                onClick = { showTranslateModeDialog = true },
                                trailingContent = {
                                    IconButton(onClick = { showTranslateModeHelpDialog = true }) {
                                        Icon(
                                            painterResource(R.drawable.info),
                                            contentDescription = null,
                                            modifier = Modifier.size(20.dp),
                                        )
                                    }
                                },
                            ),
                        )
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.edit),
                                title = { Text(stringResource(R.string.ai_system_prompt)) },
                                description = {
                                    Text(
                                        if (aiSystemPrompt.isNotBlank()) {
                                            aiSystemPrompt.take(60).let {
                                                if (aiSystemPrompt.length > 60) "$it…" else it
                                            }
                                        } else {
                                            stringResource(R.string.ai_system_prompt_default)
                                        },
                                    )
                                },
                                onClick = { showSystemPromptDialog = true },
                            ),
                        )
                    }
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.language),
                            title = { Text(stringResource(R.string.ai_target_language)) },
                            description = { Text(LanguageCodeToName[translateLanguage] ?: translateLanguage) },
                            onClick = { showLanguageDialog = true },
                        ),
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.translate),
                            title = { Text(stringResource(R.string.auto_translate)) },
                            description = { Text(stringResource(R.string.auto_translate_desc)) },
                            trailingContent = {
                                Switch(
                                    checked = autoTranslate,
                                    onCheckedChange = { autoTranslate = it },
                                    thumbContent = {
                                        Icon(
                                            painter = painterResource(id = if (autoTranslate) R.drawable.check else R.drawable.close),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize),
                                        )
                                    }
                                )
                            },
                            onClick = { autoTranslate = !autoTranslate }
                        ),
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.bug_report),
                            title = { Text(stringResource(R.string.ai_debug_title)) },
                            description = { Text(stringResource(R.string.ai_debug_desc)) },
                            onClick = { showDebugDialog = true },
                        ),
                    )
                },
        )

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.ai_limits_title),
            items =
                listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.security),
                        title = { Text(stringResource(R.string.ai_limit_enabled_title)) },
                        description = { Text(stringResource(R.string.ai_limit_enabled_desc)) },
                        trailingContent = {
                            Switch(
                                checked = aiLimitState.limitEnabled,
                                onCheckedChange = { enabled ->
                                    coroutineScope.launch {
                                        AiLimitManager.setLimitEnabled(context, enabled)
                                    }
                                },
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(id = if (aiLimitState.limitEnabled) R.drawable.check else R.drawable.close),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                }
                            )
                        },
                        onClick = {
                            coroutineScope.launch {
                                AiLimitManager.setLimitEnabled(context, !aiLimitState.limitEnabled)
                            }
                        }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.key),
                        title = { Text(stringResource(R.string.ai_unlimited_mode_title)) },
                        description = {
                            val statusStr = stringResource(
                                R.string.ai_tokens_used_label,
                                aiLimitState.tokensUsed,
                                aiLimitState.tokenQuota
                            )
                            Text("$statusStr • ${stringResource(R.string.ai_unlimited_mode_desc)}")
                        },
                        trailingContent = {
                            Switch(
                                checked = aiLimitState.unlimitedMode,
                                onCheckedChange = { enabled ->
                                    coroutineScope.launch {
                                        AiLimitManager.setUnlimitedMode(context, enabled)
                                    }
                                },
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(id = if (aiLimitState.unlimitedMode) R.drawable.check else R.drawable.close),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                }
                            )
                        },
                        onClick = {
                            coroutineScope.launch {
                                AiLimitManager.setUnlimitedMode(context, !aiLimitState.unlimitedMode)
                            }
                        }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.sync),
                        title = { Text(stringResource(R.string.ai_reset_tomorrow_title)) },
                        description = { Text(stringResource(R.string.ai_reset_tomorrow_desc)) },
                        onClick = {
                            coroutineScope.launch {
                                AiLimitManager.resetQuotaForTomorrow(context)
                                Toast.makeText(context, context.getString(R.string.ai_reset_tomorrow_title), Toast.LENGTH_SHORT).show()
                            }
                        }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.star),
                        title = { Text(if (isVietnamese) "Quy Đổi Mã Token AI" else "Redeem AI Token Code") },
                        description = { Text(if (isVietnamese) "Nhập mã quà tặng nhận thêm Token sử dụng" else "Redeem promo codes for extra AI tokens") },
                        onClick = { showRedeemDialog = true }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.key),
                        title = { Text(if (isVietnamese) "Nạp Token Trả Phí (Ngân Hàng / Tiền Mặt)" else "Purchase Paid Tokens (Bank / Cash)") },
                        description = { Text(if (isVietnamese) "Số dư Token trả phí: +${String.format(Locale.US, "%,d", aiLimitState.paidTokens)}" else "Paid Token Balance: +${String.format(Locale.US, "%,d", aiLimitState.paidTokens)}") },
                        onClick = { showPurchaseModal = true }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.security),
                        title = { Text(if (isVietnamese) "Kiểm Soát Trẻ Em & Xác Thực Tuổi" else "Child & Teen Protection & Verification Gate") },
                        description = { Text(if (isVietnamese) "${ageProtectionState.ageCategory.labelVi} • Quét Vân tay, CCCD & Mã PIN" else "${ageProtectionState.ageCategory.labelEn} • Biometrics, ID & PIN Gate") },
                        onClick = { navController.navigate("settings/ai/age_verification") }
                    )
                )
        )

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.ai_recommendations),
            items =
                listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.explore_outlined),
                        title = { Text(stringResource(R.string.ai_recommendations)) },
                        description = { Text(stringResource(R.string.ai_recommendations_desc)) },
                        trailingContent = {
                            Switch(
                                checked = aiRecommendations,
                                onCheckedChange = { aiRecommendations = it },
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(id = if (aiRecommendations) R.drawable.check else R.drawable.close),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                }
                            )
                        },
                        onClick = { aiRecommendations = !aiRecommendations }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.sync),
                        title = { Text(stringResource(R.string.refresh_recommendations)) },
                        onClick = {
                            coroutineScope.launch {
                                Toast.makeText(context, context.getString(R.string.refreshing_recommendations), Toast.LENGTH_SHORT).show()
                                delay(1200)
                                Toast.makeText(context, context.getString(R.string.recommendations_refreshed), Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                )
        )

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = if (isVietnamese) "Tính năng AI thông minh" else "AI Smart Features",
            items =
                listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.queue_music),
                        title = { Text(stringResource(R.string.ai_mood_playlist_title)) },
                        description = { Text(stringResource(R.string.ai_mood_playlist_desc)) },
                        onClick = { navController.navigate("settings/ai/mood_playlist") }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.speed),
                        title = { Text(stringResource(R.string.ai_telemetry_monitor_title)) },
                        description = { Text(if (isVietnamese) "Giám sát tiêu thụ token & lịch sử hạn mức" else "Monitor real-time token usage & reset countdowns") },
                        onClick = { navController.navigate("settings/ai/telemetry") }
                    )
                )
        )

        Spacer(modifier = Modifier.height(16.dp))
    }

    TopAppBar(
        title = { Text(stringResource(R.string.ai_hub)) },
        navigationIcon = {
            IconButton(onClick = { navController.navigateUp() }) {
                Icon(
                    painterResource(R.drawable.arrow_back),
                    contentDescription = null,
                )
            }
        },
    )
}
