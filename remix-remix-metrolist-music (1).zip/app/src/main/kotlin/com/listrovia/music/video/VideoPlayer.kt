package com.listrovia.music.video

import android.content.Context
import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.listrovia.music.R
import com.listrovia.music.utils.AuraPlayerUtils
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

/**
 * Media3-based VideoPlayer composable that accepts [AuraPlayerUtils.VideoStreamSource.Single]
 * or [AuraPlayerUtils.VideoStreamSource.Merged] to render and play video content smoothly in Jetpack Compose.
 */
@OptIn(UnstableApi::class)
@Composable
fun VideoPlayer(
    source: AuraPlayerUtils.VideoStreamSource?,
    modifier: Modifier = Modifier,
    autoPlay: Boolean = true,
    resizeMode: Int = AspectRatioFrameLayout.RESIZE_MODE_FIT,
    showCustomControls: Boolean = true,
    startPositionMs: Long = 0L,
    onPlaybackEnded: (() -> Unit)? = null,
    onError: ((String) -> Unit)? = null,
    onFullScreenToggle: (() -> Unit)? = null,
) {
    val context = LocalContext.current
    var isPlaying by remember { mutableStateOf(autoPlay) }
    var isBuffering by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var currentPosition by remember { mutableLongStateOf(startPositionMs) }
    var totalDuration by remember { mutableLongStateOf(0L) }
    var showControlsOverlay by remember { mutableStateOf(true) }
    var isDraggingSlider by remember { mutableStateOf(false) }
    var sliderPosition by remember { mutableFloatStateOf(0f) }
    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }
    var isOrientationLocked by remember { mutableStateOf(false) }

    // Create and remember ExoPlayer instance
    val exoPlayer = remember(context) {
        ExoPlayer.Builder(context).build().apply {
            playWhenReady = autoPlay
            videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT
        }
    }

    // Attach listeners and cleanup player on dispose
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                isBuffering = playbackState == Player.STATE_BUFFERING
                if (playbackState == Player.STATE_READY) {
                    totalDuration = exoPlayer.duration.coerceAtLeast(0L)
                    errorMessage = null
                } else if (playbackState == Player.STATE_ENDED) {
                    onPlaybackEnded?.invoke()
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                val desc = error.message ?: "Video playback error"
                errorMessage = desc
                isBuffering = false
                onError?.invoke(desc)
            }
        }
        exoPlayer.addListener(listener)

        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.stop()
            exoPlayer.release()
        }
    }

    // Auto-hide controls timer
    LaunchedEffect(showControlsOverlay, isPlaying) {
        if (showControlsOverlay && isPlaying && !isDraggingSlider) {
            delay(4000)
            showControlsOverlay = false
        }
    }

    // Periodic position updater
    LaunchedEffect(exoPlayer, isDraggingSlider) {
        while (isActive) {
            if (!isDraggingSlider && exoPlayer.isPlaying) {
                currentPosition = exoPlayer.currentPosition.coerceAtLeast(0L)
                if (totalDuration > 0) {
                    sliderPosition = (currentPosition.toFloat() / totalDuration.toFloat()).coerceIn(0f, 1f)
                }
            }
            delay(500)
        }
    }

    // Load media source when source changes
    LaunchedEffect(source) {
        if (source == null) {
            exoPlayer.stop()
            exoPlayer.clearMediaItems()
            return@LaunchedEffect
        }
        isBuffering = true
        errorMessage = null

        val mediaSource = buildMediaSource(source)
        exoPlayer.setMediaSource(mediaSource)
        exoPlayer.prepare()
        if (startPositionMs > 0) {
            exoPlayer.seekTo(startPositionMs)
        }
        if (autoPlay) {
            exoPlayer.play()
        }
    }

    Box(
        modifier = modifier
            .background(Color.Black)
            .clickable { showControlsOverlay = !showControlsOverlay },
        contentAlignment = Alignment.Center
    ) {
        // Media3 PlayerView surface
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false
                    this.resizeMode = resizeMode
                    player = exoPlayer
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { view ->
                view.player = exoPlayer
                if (view.resizeMode != resizeMode) {
                    view.resizeMode = resizeMode
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // Buffering spinner
        if (isBuffering && errorMessage == null) {
            CircularProgressIndicator(
                color = MaterialTheme.colorScheme.primary,
                strokeWidth = 3.dp,
                modifier = Modifier.size(48.dp)
            )
        }

        // Error message overlay
        errorMessage?.let { error ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.8f))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = error,
                    color = Color.White,
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center
                )
            }
        }

        // Controls Overlay
        if (showCustomControls && errorMessage == null) {
            AnimatedVisibility(
                visible = showControlsOverlay,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.45f))
                ) {
                    val audioManager = remember(context) { context.getSystemService(android.media.AudioManager::class.java) }
                    val activity = context as? android.app.Activity
                    val currentBrightness = activity?.window?.attributes?.screenBrightness?.takeIf { it >= 0f } ?: 0.5f
                    val maxVol = audioManager?.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC) ?: 1
                    val currVol = audioManager?.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) ?: 0
                    val volumeFraction = currVol.toFloat() / maxVol.coerceAtLeast(1)

                    // Vertical Brightness slider bar on the left
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .padding(start = 16.dp)
                            .width(28.dp)
                            .height(120.dp)
                            .background(Color.Black.copy(alpha = 0.55f), CircleShape)
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.contrast),
                                contentDescription = "Brightness",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Box(
                                modifier = Modifier
                                    .width(8.dp)
                                    .fillMaxHeight(currentBrightness.coerceIn(0.08f, 1f))
                                    .background(MaterialTheme.colorScheme.primary, CircleShape)
                            )
                        }
                    }

                    // Vertical Volume slider bar on the right
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .padding(end = 16.dp)
                            .width(28.dp)
                            .height(120.dp)
                            .background(Color.Black.copy(alpha = 0.55f), CircleShape)
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.volume_up),
                                contentDescription = "Volume",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Box(
                                modifier = Modifier
                                    .width(8.dp)
                                    .fillMaxHeight(volumeFraction.coerceIn(0.08f, 1f))
                                    .background(MaterialTheme.colorScheme.primary, CircleShape)
                            )
                        }
                    }
                    // Top actions bar (Orientation lock)
                    Row(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                val activity = context as? android.app.Activity
                                isOrientationLocked = !isOrientationLocked
                                activity?.requestedOrientation = if (isOrientationLocked) {
                                    android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                } else {
                                    android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR
                                }
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .background(if (isOrientationLocked) MaterialTheme.colorScheme.primary.copy(alpha = 0.85f) else Color.Black.copy(alpha = 0.5f), CircleShape)
                        ) {
                            Icon(
                                painter = painterResource(if (isOrientationLocked) R.drawable.lock else R.drawable.lock_open),
                                contentDescription = androidx.compose.ui.res.stringResource(
                                    if (isOrientationLocked) R.string.screen_orientation_locked else R.string.screen_orientation_unlocked
                                ),
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    // Center Play/Pause button
                    IconButton(
                        onClick = {
                            if (exoPlayer.isPlaying) {
                                exoPlayer.pause()
                            } else {
                                exoPlayer.play()
                            }
                        },
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(56.dp)
                            .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                    ) {
                        Icon(
                            painter = painterResource(if (isPlaying) R.drawable.pause else R.drawable.play),
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    // Bottom controls bar (seek bar + times + speed + fullscreen)
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = formatTime(if (isDraggingSlider) (sliderPosition * totalDuration).toLong() else currentPosition),
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Slider(
                            value = sliderPosition,
                            onValueChange = { pos ->
                                isDraggingSlider = true
                                sliderPosition = pos
                            },
                            onValueChangeFinished = {
                                val targetMs = (sliderPosition * totalDuration).toLong()
                                exoPlayer.seekTo(targetMs)
                                currentPosition = targetMs
                                isDraggingSlider = false
                            },
                            modifier = Modifier.weight(1f),
                            colors = SliderDefaults.colors(
                                thumbColor = MaterialTheme.colorScheme.primary,
                                activeTrackColor = MaterialTheme.colorScheme.primary,
                                inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                            )
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Text(
                            text = formatTime(totalDuration),
                            color = Color.White.copy(alpha = 0.75f),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )

                        Spacer(modifier = Modifier.width(6.dp))

                        // Playback Speed selector button
                        IconButton(
                            onClick = {
                                val speedPresets = listOf(0.5f, 1.0f, 1.5f, 2.0f)
                                val nextIdx = (speedPresets.indexOf(playbackSpeed).let { if (it == -1) 1 else it } + 1) % speedPresets.size
                                val newSpeed = speedPresets[nextIdx]
                                playbackSpeed = newSpeed
                                exoPlayer.setPlaybackSpeed(newSpeed)
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color.White.copy(alpha = 0.2f), CircleShape)
                        ) {
                            Text(
                                text = "${playbackSpeed}x",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (onFullScreenToggle != null) {
                            Spacer(modifier = Modifier.width(6.dp))
                            IconButton(
                                onClick = onFullScreenToggle,
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.fullscreen),
                                    contentDescription = "Full Screen",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Builds an appropriate MediaSource based on Single (muxed) or Merged (video-only + audio-only) streams.
 */
@OptIn(UnstableApi::class)
private fun buildMediaSource(
    source: AuraPlayerUtils.VideoStreamSource
): MediaSource {
    val httpDataSourceFactory = DefaultHttpDataSource.Factory()
        .setAllowCrossProtocolRedirects(true)
        .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36")
        .setConnectTimeoutMs(15000)
        .setReadTimeoutMs(15000)

    val progressiveFactory = ProgressiveMediaSource.Factory(httpDataSourceFactory)

    return when (source) {
        is AuraPlayerUtils.VideoStreamSource.Single -> {
            val mediaItem = MediaItem.Builder()
                .setUri(Uri.parse(source.url))
                .setMimeType(source.mimeType)
                .build()
            progressiveFactory.createMediaSource(mediaItem)
        }
        is AuraPlayerUtils.VideoStreamSource.Merged -> {
            val videoMediaItem = MediaItem.Builder()
                .setUri(Uri.parse(source.videoUrl))
                .setMimeType(source.videoMimeType)
                .build()
            val videoMediaSource = progressiveFactory.createMediaSource(videoMediaItem)

            val audioMediaItem = MediaItem.Builder()
                .setUri(Uri.parse(source.audioUrl))
                .setMimeType(source.audioMimeType)
                .build()
            val audioMediaSource = progressiveFactory.createMediaSource(audioMediaItem)

            MergingMediaSource(videoMediaSource, audioMediaSource)
        }
    }
}

private fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        "%d:%02d:%02d".format(hours, minutes, seconds)
    } else {
        "%d:%02d".format(minutes, seconds)
    }
}
