/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.utils

import android.net.ConnectivityManager
import android.net.Uri
import androidx.media3.common.PlaybackException
import com.listrovia.innertube.NewPipeExtractor
import com.listrovia.innertube.YouTube
import com.listrovia.innertube.YouTubeClient
import com.listrovia.innertube.YouTubeClient.Companion.ANDROID_CREATOR
import com.listrovia.innertube.YouTubeClient.Companion.ANDROID_NO_SDK
import com.listrovia.innertube.YouTubeClient.Companion.ANDROID_TESTSUITE
import com.listrovia.innertube.YouTubeClient.Companion.ANDROID_VR_1_43_32
import com.listrovia.innertube.YouTubeClient.Companion.ANDROID_VR_1_61_48
import com.listrovia.innertube.YouTubeClient.Companion.ANDROID_VR_NO_AUTH
import com.listrovia.innertube.YouTubeClient.Companion.IOS
import com.listrovia.innertube.YouTubeClient.Companion.IPADOS
import com.listrovia.innertube.YouTubeClient.Companion.MOBILE
import com.listrovia.innertube.YouTubeClient.Companion.TVHTML5
import com.listrovia.innertube.YouTubeClient.Companion.TVHTML5_SIMPLY_EMBEDDED_PLAYER
import com.listrovia.innertube.YouTubeClient.Companion.VISIONOS
import com.listrovia.innertube.YouTubeClient.Companion.WEB
import com.listrovia.innertube.YouTubeClient.Companion.WEB_CREATOR
import com.listrovia.innertube.YouTubeClient.Companion.WEB_REMIX
import com.listrovia.innertube.PlayerResponse
import com.listrovia.music.constants.AudioQuality
import com.listrovia.music.utils.YTPlayerUtils.MAIN_CLIENT
import com.listrovia.music.utils.YTPlayerUtils.STREAM_FALLBACK_CLIENTS
import com.listrovia.music.utils.YTPlayerUtils.validateStatus
import com.listrovia.music.utils.cipher.CipherDeobfuscator
import com.listrovia.music.utils.cipher.FunctionNameExtractor
import com.listrovia.music.utils.cipher.PlayerJsFetcher
import com.listrovia.music.utils.potoken.PoTokenGenerator
import com.listrovia.music.utils.potoken.PoTokenResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import timber.log.Timber

object YTPlayerUtils {
    private const val logTag = "YTPlayerUtils"
    private const val TAG = "YTPlayerUtils"

    private val httpClient = OkHttpClient.Builder()
        .proxy(YouTube.proxy)
        .build()

    private val poTokenGenerator = PoTokenGenerator()

    // Track videoIds whose WEB_REMIX stream URL 403'd on the ExoPlayer GET, so the next resolution
    // falls through to the fallback clients instead of skipping HEAD validation and looping.
    private val webRemixFailedIds = java.util.Collections.newSetFromMap(
        java.util.concurrent.ConcurrentHashMap<String, Boolean>(),
    )

    fun markWebRemixFailed(videoId: String) {
        webRemixFailedIds.add(videoId)
    }

    /**
     * Cleared when the cipher recovers (player config refreshed after a stream rejection): the
     * prior WEB_REMIX failures were caused by the stale cipher, so let resolution try WEB_REMIX
     * again instead of staying pinned to a lower fallback client for the rest of the process.
     */
    fun clearWebRemixFailures() {
        webRemixFailedIds.clear()
    }

    // Fire-and-forget scope for the cipher config self-heal triggered when a cipher client fails
    // stream validation during resolution. Only WEB_REMIX skips HEAD validation (so its bad URL
    // 403s on ExoPlayer and hits MusicService's handler); WEB_CREATOR / TVHTML5 / WEB are validated
    // here and never reach ExoPlayer, so without this trigger a WEB_REMIX-disabled user would never
    // self-heal a stale/wrong cipher config. Kept off the resolution coroutine so the (network)
    // refresh never blocks falling through to the next client.
    private val cipherRefreshScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val MAIN_CLIENT: YouTubeClient = WEB_REMIX

    // VISIONOS first (its CDN URL has no spc throttle gate, so it streams whole songs with no
    // poToken/cipher — the most reliable fallback), then WEB_CREATOR, TVHTML5, the ANDROID_VR
    // variants, then TVHTML5_SIMPLY_EMBEDDED_PLAYER (login-free, bypasses age-restriction for
    // logged-out users), then the spc-gated IOS/IPADOS as last-ditch attempts.
    private val STREAM_FALLBACK_CLIENTS: Array<YouTubeClient> = arrayOf(
        ANDROID_TESTSUITE,
        TVHTML5_SIMPLY_EMBEDDED_PLAYER,
        ANDROID_NO_SDK,
        ANDROID_VR_1_61_48,
        VISIONOS,
        IOS,
        ANDROID_VR_1_43_32,
        WEB_CREATOR,
        TVHTML5,
        IPADOS,
        ANDROID_CREATOR,
        ANDROID_VR_NO_AUTH,
        MOBILE,
        WEB,
    )

    /** Client names disabled by the user in Settings → Stream sources. Updated reactively by MusicService. */
    @Volatile
    var disabledStreamClients: Set<String> = emptySet()

    // A stable video id used only to warm the local BotGuard token generator; the token is
    // discarded. PoToken generation is a local WebView computation (no YouTube /player call), so
    // this triggers no network request to YouTube for the video itself.
    private const val POTOKEN_WARMUP_VIDEO_ID = "jNQXAC9IVRw"

    /**
     * Best-effort warm-up of the PoToken/BotGuard generator (BotGuard cold-start is ~2–5s) so the
     * first real playback skips it. Requires a session (visitorData); the caller should gate this on
     * visitorData being ready. The cipher WebView warm-up is separate (CipherDeobfuscator.prewarm)
     * since it needs no session. Failure is swallowed; playback falls back to lazy init unchanged.
     */
    suspend fun prewarmPoToken() {
        val sessionId = YouTube.visitorData ?: return
        if (!MAIN_CLIENT.useWebPoTokens) return
        runCatching {
            withContext(Dispatchers.IO) {
                poTokenGenerator.getWebClientPoToken(POTOKEN_WARMUP_VIDEO_ID, sessionId)
            }
        }.onFailure { Timber.tag(TAG).w(it, "PoToken prewarm skipped: ${it.message}") }
    }

    data class PlaybackData(
        val audioConfig: PlayerResponse.PlayerConfig.AudioConfig?,
        val videoDetails: PlayerResponse.VideoDetails?,
        val playbackTracking: PlayerResponse.PlaybackTracking?,
        val format: PlayerResponse.StreamingData.Format,
        val streamUrl: String,
        val streamExpiresInSeconds: Int,
        val streamClient: String = "unknown",
    )
    /**
     * Custom player response intended to use for playback.
     * Metadata like audioConfig and videoDetails are from [MAIN_CLIENT].
     * Format & stream can be from [MAIN_CLIENT] or [STREAM_FALLBACK_CLIENTS].
     */
    suspend fun playerResponseForPlayback(
        videoId: String,
        playlistId: String? = null,
        audioQuality: AudioQuality,
        connectivityManager: ConnectivityManager,
    ): Result<PlaybackData> = runCatching {
        Timber.tag(TAG).d("=== PLAYER RESPONSE FOR PLAYBACK ===")
        Timber.tag(TAG).d("videoId: $videoId")
        Timber.tag(TAG).d("playlistId: $playlistId")
        Timber.tag(TAG).d("audioQuality: $audioQuality")

        // Check if this is an uploaded/privately owned track
        val isUploadedTrack = playlistId == "MLPT" || playlistId?.contains("MLPT") == true
        Timber.tag(TAG).d("Content type detection (preliminary):")
        Timber.tag(TAG).d("  isUploadedTrack (from playlistId): $isUploadedTrack")

        val isLoggedIn = YouTube.cookie != null
        Timber.tag(TAG).d("Authentication status: ${if (isLoggedIn) "LOGGED_IN" else "ANONYMOUS"}")

        // Get signature timestamp (same as before for normal content)
        val signatureTimestamp = getSignatureTimestampOrNull(videoId)
        Timber.tag(logTag).d("Signature timestamp: ${signatureTimestamp.timestamp}")

        // Ensure visitorData is initialized if null
        if (YouTube.visitorData == null) {
            YouTube.visitorData = runCatching { YouTube.visitorData().getOrNull() }.getOrNull()
        }

        // Generate PoToken
        var poToken: PoTokenResult? = null
        val sessionId = YouTube.visitorData
        if (MAIN_CLIENT.useWebPoTokens && sessionId != null) {
            Timber.tag(logTag).d("Generating PoToken for WEB_REMIX with sessionId")
            try {
                poToken = poTokenGenerator.getWebClientPoToken(videoId, sessionId)
                if (poToken != null) {
                    Timber.tag(logTag).d("PoToken generated successfully")
                }
            } catch (e: Exception) {
                Timber.tag(logTag).e(e, "PoToken generation failed: ${e.message}")
            }
        }

        // Try WEB_REMIX with signature timestamp and poToken (same as before)
        Timber.tag(logTag).d("Attempting to get player response using MAIN_CLIENT: ${MAIN_CLIENT.clientName}")
        var mainPlayerResponse = YouTube.player(videoId, playlistId, MAIN_CLIENT, signatureTimestamp.timestamp, poToken?.playerRequestPoToken).getOrNull()

        // Bot Detection Handling: If MAIN_CLIENT playability is not OK, clear flagged visitorData and retry anonymously
        if (mainPlayerResponse?.playabilityStatus?.status != "OK") {
            YouTube.visitorData = null
            val anonResp = YouTube.player(videoId, playlistId, MAIN_CLIENT, signatureTimestamp.timestamp, null, useVisitorData = false).getOrNull()
            if (anonResp?.playabilityStatus?.status == "OK") {
                mainPlayerResponse = anonResp
            }
        }

        // Debug uploaded track response
        if (isUploadedTrack || playlistId?.contains("MLPT") == true) {
            println("[PLAYBACK_DEBUG] Main player response status: ${mainPlayerResponse?.playabilityStatus?.status}")
            println("[PLAYBACK_DEBUG] Playability reason: ${mainPlayerResponse?.playabilityStatus?.reason}")
            println("[PLAYBACK_DEBUG] Video details: title=${mainPlayerResponse?.videoDetails?.title}, videoId=${mainPlayerResponse?.videoDetails?.videoId}")
            println("[PLAYBACK_DEBUG] Streaming data null? ${mainPlayerResponse?.streamingData == null}")
            println("[PLAYBACK_DEBUG] Adaptive formats count: ${mainPlayerResponse?.streamingData?.adaptiveFormats?.size ?: 0}")
        }

        var usedAgeRestrictedClient: YouTubeClient? = null

        var audioConfig = mainPlayerResponse?.playerConfig?.audioConfig
        var videoDetails = mainPlayerResponse?.videoDetails
        var playbackTracking = mainPlayerResponse?.playbackTracking
        var format: PlayerResponse.StreamingData.Format? = null
        var streamUrl: String? = null
        var streamExpiresInSeconds: Int? = null
        var streamPlayerResponse: PlayerResponse? = null
        var successClient: String? = null

        var bestFallbackFormat: PlayerResponse.StreamingData.Format? = null
        var bestFallbackUrl: String? = null
        var bestFallbackExpiry: Int? = null
        var bestFallbackResponse: PlayerResponse? = null
        var bestFallbackClient: String? = null

        val hasHighQuality = mainPlayerResponse?.streamingData?.adaptiveFormats?.any { it.audioQuality == "AUDIO_QUALITY_HIGH" } == true

        // 2. Iterate through clients sequence (-1 is MAIN_CLIENT, 0..N are STREAM_FALLBACK_CLIENTS)
        for (clientIndex in -1 until STREAM_FALLBACK_CLIENTS.size) {
            format = null
            streamUrl = null
            streamExpiresInSeconds = null

            val client: YouTubeClient
            if (clientIndex == -1) {
                client = MAIN_CLIENT
                if (client.clientName in disabledStreamClients) continue
                streamPlayerResponse = mainPlayerResponse
            } else {
                client = STREAM_FALLBACK_CLIENTS[clientIndex]
                if (client.clientName in disabledStreamClients) continue
                if (client.loginRequired && !isLoggedIn && YouTube.cookie == null) continue

                val clientPoToken = if (client.useWebPoTokens) poToken?.playerRequestPoToken else null
                val clientSigTimestamp = signatureTimestamp.timestamp

                // Primary request with client parameters
                streamPlayerResponse = YouTube.player(videoId, playlistId, client, clientSigTimestamp, clientPoToken).getOrNull()
            }

            // Bot Logic: If playability is not OK, IMMEDIATELY reset visitorData and retry anonymously
            if (streamPlayerResponse?.playabilityStatus?.status != "OK") {
                YouTube.visitorData = null
                val clientSigTimestamp = signatureTimestamp.timestamp
                var anonResponse = YouTube.player(videoId, playlistId, client, clientSigTimestamp, null, useVisitorData = false).getOrNull()
                if (anonResponse?.playabilityStatus?.status != "OK" && client.clientName != "TVHTML5_SIMPLY_EMBEDDED_PLAYER") {
                    anonResponse = YouTube.player(videoId, playlistId, TVHTML5_SIMPLY_EMBEDDED_PLAYER, clientSigTimestamp, null, useVisitorData = false).getOrNull()
                }
                if (anonResponse?.playabilityStatus?.status == "OK") {
                    streamPlayerResponse = anonResponse
                }
            }

            // Process response if status is OK
            if (streamPlayerResponse?.playabilityStatus?.status == "OK") {
                val responseToUse = YouTube.newPipePlayer(videoId, streamPlayerResponse) ?: streamPlayerResponse

                if (audioConfig == null) {
                    audioConfig = responseToUse.playerConfig?.audioConfig
                }
                if (videoDetails == null) {
                    videoDetails = responseToUse.videoDetails
                }
                if (playbackTracking == null) {
                    playbackTracking = responseToUse.playbackTracking
                }

                format = findFormat(responseToUse, audioQuality, connectivityManager)
                if (format == null) continue

                streamUrl = findUrlOrNull(format, videoId, responseToUse)
                if (streamUrl == null) continue

                val currentClient = client
                val needsNTransform = currentClient.useWebPoTokens ||
                        currentClient.clientName in listOf("WEB", "WEB_REMIX", "WEB_CREATOR", "TVHTML5")

                if (needsNTransform) {
                    try {
                        streamUrl = CipherDeobfuscator.transformNParamInUrl(streamUrl)
                        if (currentClient.useWebPoTokens && poToken?.streamingDataPoToken != null) {
                            val separator = if ("?" in streamUrl) "&" else "?"
                            streamUrl = "${streamUrl}${separator}pot=${Uri.encode(poToken?.streamingDataPoToken ?: "")}"
                        }
                    } catch (e: Exception) {
                        Timber.tag(TAG).e(e, "N-transform failed: ${e.message}")
                    }
                }

                streamExpiresInSeconds = responseToUse.streamingData?.expiresInSeconds

                // Candidate tracking for quality/codec selection
                fun scoreFallbackQuality(quality: String?): Int = when (quality) {
                    "AUDIO_QUALITY_HIGH" -> 3
                    "AUDIO_QUALITY_MEDIUM" -> 2
                    "AUDIO_QUALITY_LOW" -> 1
                    else -> 0
                }

                fun scoreFallbackCodec(mimeType: String): Int = when {
                    mimeType.contains("opus", ignoreCase = true) -> 2
                    mimeType.contains("mp4a", ignoreCase = true) -> 1
                    else -> 0
                }

                if (audioQuality == AudioQuality.HIGH && format.audioQuality != "AUDIO_QUALITY_HIGH" && hasHighQuality) {
                    val isBetter = bestFallbackFormat == null ||
                        compareValuesBy(
                            format, bestFallbackFormat,
                            { scoreFallbackQuality(it.audioQuality) },
                            { it.audioChannels ?: 2 },
                            { scoreFallbackCodec(it.mimeType) },
                            { it.bitrate }
                        ) > 0
                    if (isBetter) {
                        bestFallbackFormat = format
                        bestFallbackUrl = streamUrl
                        bestFallbackExpiry = streamExpiresInSeconds
                        bestFallbackResponse = responseToUse
                        bestFallbackClient = currentClient.clientName
                    }
                    continue
                }

                if (streamUrl != null && validateStatus(streamUrl, currentClient.userAgent)) {
                    successClient = currentClient.clientName
                    break
                } else {
                    if (bestFallbackUrl == null && streamUrl != null && format != null) {
                        bestFallbackFormat = format
                        bestFallbackUrl = streamUrl
                        bestFallbackExpiry = streamExpiresInSeconds
                        bestFallbackResponse = responseToUse
                        bestFallbackClient = currentClient.clientName
                    }
                }
            }
        }

        if (successClient == null) {
            // 3. Extractor Fallbacks (NewPipe & Piped) if InnerTube clients failed or were unverified
            Timber.tag(logTag).w("InnerTube clients failed or bot check triggered for videoId=$videoId, attempting NewPipe extractor...")
            val newPipeStreams = runCatching { NewPipeExtractor.newPipePlayer(videoId) }.getOrDefault(emptyList())
            if (newPipeStreams.isNotEmpty()) {
                val preferredItags = listOf(251, 140, 250, 249, 171, 139)
                val fallbackStream = preferredItags.firstNotNullOfOrNull { targetItag ->
                    newPipeStreams.firstOrNull { it.first == targetItag }
                } ?: newPipeStreams.first()

                val fallbackUrl = fallbackStream.second
                Timber.tag(logTag).i("NewPipe bot bypass successful for videoId=$videoId, itag=${fallbackStream.first}")

                val dummyFormat = PlayerResponse.StreamingData.Format(
                    itag = fallbackStream.first,
                    url = fallbackUrl,
                    mimeType = if (fallbackStream.first == 140) "audio/mp4; codecs=\"mp4a.40.2\"" else "audio/webm; codecs=\"opus\"",
                    bitrate = 128000,
                    width = null, height = null, contentLength = null, quality = "medium", fps = null, qualityLabel = null, averageBitrate = 128000, audioQuality = "AUDIO_QUALITY_MEDIUM", approxDurationMs = null, audioSampleRate = 44100, audioChannels = 2, loudnessDb = null, lastModified = null, signatureCipher = null, cipher = null, audioTrack = null
                )

                format = dummyFormat
                streamUrl = fallbackUrl
                streamExpiresInSeconds = 21600
                successClient = "NewPipe"
            } else {
                Timber.tag(logTag).w("Attempting Piped/Invidious extractor fallback for videoId=$videoId...")
                val pipedResult = PipedExtractor.getAudioStreamUrl(videoId)
                if (pipedResult != null) {
                    val fallbackUrl = pipedResult.first
                    val mime = pipedResult.second
                    Timber.tag(logTag).i("Piped/Invidious bot bypass successful for videoId=$videoId")

                    val dummyFormat = PlayerResponse.StreamingData.Format(
                        itag = 251,
                        url = fallbackUrl,
                        mimeType = mime,
                        bitrate = 128000,
                        width = null, height = null, contentLength = null, quality = "medium", fps = null, qualityLabel = null, averageBitrate = 128000, audioQuality = "AUDIO_QUALITY_MEDIUM", approxDurationMs = null, audioSampleRate = 44100, audioChannels = 2, loudnessDb = null, lastModified = null, signatureCipher = null, cipher = null, audioTrack = null
                    )

                    format = dummyFormat
                    streamUrl = fallbackUrl
                    streamExpiresInSeconds = 21600
                    successClient = "Piped"
                } else if (bestFallbackFormat != null && bestFallbackUrl != null) {
                    format = bestFallbackFormat
                    streamUrl = bestFallbackUrl
                    streamExpiresInSeconds = bestFallbackExpiry
                    streamPlayerResponse = bestFallbackResponse ?: streamPlayerResponse
                    successClient = bestFallbackClient
                }
            }
        }

        if (streamExpiresInSeconds == null) {
            streamExpiresInSeconds = streamPlayerResponse?.streamingData?.expiresInSeconds ?: bestFallbackExpiry ?: 21600
        }

        if (format == null || streamUrl == null) {
            // Embedded/anonymous fallback attempt to bypass bot verification
            YouTube.visitorData = null
            val botBypassClients = listOf(
                YouTubeClient.TVHTML5_SIMPLY_EMBEDDED_PLAYER,
                YouTubeClient.ANDROID_TESTSUITE,
                YouTubeClient.ANDROID_VR_1_61_48,
                YouTubeClient.ANDROID_VR_1_43_32,
                YouTubeClient.VISIONOS,
                YouTubeClient.ANDROID_NO_SDK,
                YouTubeClient.MOBILE,
                YouTubeClient.WEB
            )
            for (embClient in botBypassClients) {
                val embResp = YouTube.player(videoId, playlistId, embClient, signatureTimestamp.timestamp, null, useVisitorData = false).getOrNull()
                if (embResp?.playabilityStatus?.status == "OK") {
                    val embFormat = findFormat(embResp, audioQuality, connectivityManager)
                    val embUrl = embFormat?.let { findUrlOrNull(it, videoId, embResp) }
                    if (embFormat != null && embUrl != null) {
                        format = embFormat
                        streamUrl = embUrl
                        streamExpiresInSeconds = embResp.streamingData?.expiresInSeconds ?: 21600
                        streamPlayerResponse = embResp
                        successClient = embClient.clientName
                        break
                    }
                }
            }
        }

        if ((format == null || streamUrl == null) && bestFallbackFormat != null && bestFallbackUrl != null) {
            format = bestFallbackFormat
            streamUrl = bestFallbackUrl
            streamExpiresInSeconds = bestFallbackExpiry ?: 21600
            streamPlayerResponse = bestFallbackResponse ?: streamPlayerResponse
            successClient = bestFallbackClient
        }

        if (format == null || streamUrl == null) {
            val errorReason = streamPlayerResponse?.playabilityStatus?.reason
                ?: mainPlayerResponse?.playabilityStatus?.reason
                ?: "Playability status not OK"
            Timber.tag(logTag).w("Playability status not OK: $errorReason. Invoking emergency stream fallback...")

            if (errorReason.contains("bot", ignoreCase = true) || errorReason.contains("sign in", ignoreCase = true)) {
                YouTube.visitorData = null
            }

            // Emergency Piped / Invidious stream extraction
            val fallbackPair = PipedExtractor.getAudioStreamUrl(videoId)
            if (fallbackPair != null) {
                val fallbackUrl = fallbackPair.first
                val mime = fallbackPair.second
                format = PlayerResponse.StreamingData.Format(
                    itag = 251,
                    url = fallbackUrl,
                    mimeType = mime,
                    bitrate = 128000,
                    width = null, height = null, contentLength = null, quality = "medium", fps = null, qualityLabel = null, averageBitrate = 128000, audioQuality = "AUDIO_QUALITY_MEDIUM", approxDurationMs = null, audioSampleRate = 44100, audioChannels = 2, loudnessDb = null, lastModified = null, signatureCipher = null, cipher = null, audioTrack = null
                )
                streamUrl = fallbackUrl
                streamExpiresInSeconds = 21600
                successClient = "EmergencyPiped"
            } else {
                // Invidious direct stream URL fallback
                val fallbackUrl = "https://inv.tux.rain3.fr/latest_version?id=$videoId&itag=140"
                format = PlayerResponse.StreamingData.Format(
                    itag = 140,
                    url = fallbackUrl,
                    mimeType = "audio/mp4",
                    bitrate = 128000,
                    width = null, height = null, contentLength = null, quality = "medium", fps = null, qualityLabel = null, averageBitrate = 128000, audioQuality = "AUDIO_QUALITY_MEDIUM", approxDurationMs = null, audioSampleRate = 44100, audioChannels = 2, loudnessDb = null, lastModified = null, signatureCipher = null, cipher = null, audioTrack = null
                )
                streamUrl = fallbackUrl
                streamExpiresInSeconds = 21600
                successClient = "EmergencyInvidious"
            }
        }

        Timber.tag(logTag).d("Successfully obtained playback data with format: ${format.mimeType}, bitrate: ${format.bitrate}, client: $successClient")
        if (isUploadedTrack) {
            println("[PLAYBACK_DEBUG] SUCCESS: Got playback data for uploaded track - format=${format.mimeType}, streamUrl=${streamUrl.take(100)}...")
        }
        return@runCatching PlaybackData(
            audioConfig = audioConfig ?: streamPlayerResponse?.playerConfig?.audioConfig,
            videoDetails = videoDetails ?: streamPlayerResponse?.videoDetails,
            playbackTracking = playbackTracking ?: streamPlayerResponse?.playbackTracking,
            format = format,
            streamUrl = streamUrl,
            streamExpiresInSeconds = streamExpiresInSeconds ?: 21600,
            streamClient = successClient ?: "unknown",
        )
    }.onFailure { e ->
        println("[PLAYBACK_DEBUG] EXCEPTION during playback for videoId=$videoId: ${e::class.simpleName}: ${e.message}")
        e.printStackTrace()
    }
    /**
     * Player response intended for metadata / playback-tracking retrieval.
     * Stream URLs of this response might not work so don't use them.
     */
    suspend fun playerResponseForMetadata(
        videoId: String,
        playlistId: String? = null,
    ): Result<PlayerResponse> {
        Timber.tag(logTag).d("Fetching metadata player response for videoId: $videoId using MAIN_CLIENT: ${MAIN_CLIENT.clientName}")
        val signatureTimestamp = getSignatureTimestampOrNull(videoId)
        val sessionId = YouTube.visitorData
        var poToken: PoTokenResult? = null
        if (MAIN_CLIENT.useWebPoTokens && sessionId != null) {
            try {
                poToken = poTokenGenerator.getWebClientPoToken(videoId, sessionId)
            } catch (_: Exception) { }
        }
        return YouTube.player(videoId, playlistId, WEB_REMIX, signatureTimestamp.timestamp, poToken?.playerRequestPoToken)
            .onSuccess { Timber.tag(logTag).d("Successfully fetched metadata player response") }
            .onFailure { Timber.tag(logTag).e(it, "Failed to fetch metadata player response") }
    }

    private fun findFormat(
        playerResponse: PlayerResponse,
        audioQuality: AudioQuality,
        connectivityManager: ConnectivityManager,
    ): PlayerResponse.StreamingData.Format? {
        Timber.tag(logTag).d("Finding format with audioQuality: $audioQuality, network metered: ${connectivityManager.isActiveNetworkMetered}")

        val adaptiveFormats = playerResponse.streamingData?.adaptiveFormats ?: emptyList()
        val formats = playerResponse.streamingData?.formats ?: emptyList()
        val allFormats = adaptiveFormats + formats
        if (allFormats.isEmpty()) return null

        val audioCapableFormats = allFormats.filter {
            it.isAudio || it.audioQuality != null || it.audioSampleRate != null || it.mimeType.startsWith("audio/")
        }.ifEmpty { allFormats }
        if (audioCapableFormats.isEmpty()) return null

        val forceOpus = runCatching {
            com.listrovia.music.App.instance.dataStore.get(com.listrovia.music.constants.ForceOpusAudioKey, false)
        }.getOrDefault(false)

        if (forceOpus) {
            val opusFormat = audioCapableFormats.find { it.itag == 251 }
                ?: audioCapableFormats.filter { it.mimeType.contains("opus", ignoreCase = true) }.maxByOrNull { it.bitrate }
            if (opusFormat != null) {
                Timber.tag(logTag).d("Forced selection of Opus format (itag=${opusFormat.itag}, bitrate=${opusFormat.bitrate})")
                return opusFormat
            }
        }

        val maxBitrate = audioCapableFormats.maxOfOrNull { it.bitrate } ?: return null

        fun scoreCodec(mimeType: String): Int = when {
            mimeType.contains("opus", ignoreCase = true) -> 2
            mimeType.contains("mp4a", ignoreCase = true) -> 1
            else -> 0
        }

        val format = when (audioQuality) {
            AudioQuality.HIGH -> {
                audioCapableFormats.maxWithOrNull(
                    compareBy<PlayerResponse.StreamingData.Format> { format ->
                        when (format.audioQuality) {
                            "AUDIO_QUALITY_HIGH" -> 3
                            "AUDIO_QUALITY_MEDIUM" -> 2
                            "AUDIO_QUALITY_LOW" -> 1
                            else -> 0
                        }
                    }.thenBy { it.audioChannels ?: 2 }
                        .thenBy { scoreCodec(it.mimeType) }
                        .thenBy { it.bitrate }
                )
            }

            AudioQuality.LOW -> {
                val cappedFormats = audioCapableFormats.filter { it.bitrate <= 128000 }
                val lowFormat = cappedFormats
                    .filter { it.isOriginal }
                    .maxByOrNull { it.bitrate }
                    ?: cappedFormats.maxByOrNull { it.bitrate }
                    ?: audioCapableFormats
                        .filter { it.isOriginal }
                        .minByOrNull { kotlin.math.abs(it.bitrate.toDouble() - 128000.0) }
                    ?: audioCapableFormats.maxByOrNull { it.bitrate }

                if (lowFormat != null) {
                    Timber.tag(logTag).d("Selected LOW format: itag=${lowFormat.itag}, bitrate: ${lowFormat.bitrate}")
                }

                lowFormat
            }

            AudioQuality.AUTO -> {
                val targetBitrate = if (connectivityManager.isActiveNetworkMetered) 128000.0 else maxBitrate.toDouble()
                val cappedFormats = audioCapableFormats.filter { it.bitrate <= targetBitrate }
                val autoFormat = cappedFormats
                    .filter { it.isOriginal }
                    .maxByOrNull { it.bitrate }
                    ?: cappedFormats.maxByOrNull { it.bitrate }
                    ?: audioCapableFormats
                        .filter { it.isOriginal }
                        .minByOrNull { kotlin.math.abs(it.bitrate - targetBitrate) }
                    ?: audioCapableFormats.maxByOrNull { it.bitrate }

                if (autoFormat != null) {
                    Timber.tag(logTag).d("Selected AUTO format: itag=${autoFormat.itag}, bitrate: ${autoFormat.bitrate}")
                }

                autoFormat
            }
        }

        if (format != null) {
            Timber.tag(logTag).d("Selected format: itag=${format.itag}, mimeType=${format.mimeType}, bitrate=${format.bitrate}, audioQuality label: ${format.audioQuality}")
        } else {
            Timber.tag(logTag).d("No suitable audio format found")
        }

        return format
    }
    /**
     * Checks if the stream url returns a successful status.
     * If this returns true the url is likely to work.
     * If this returns false the url might cause an error during playback.
     */
    private fun validateStatus(url: String, userAgent: String? = null): Boolean {
        Timber.tag(logTag).d("Validating stream URL status")
        try {
            val requestBuilder = okhttp3.Request.Builder()
                .head()
                .url(url)

            if (!userAgent.isNullOrEmpty()) {
                requestBuilder.header("User-Agent", userAgent)
            }

            // Add authentication cookie for privately owned tracks
            YouTube.cookie?.let { cookie ->
                requestBuilder.addHeader("Cookie", cookie)
                println("[PLAYBACK_DEBUG] Added cookie to validation request")
            }

            var response = httpClient.newCall(requestBuilder.build()).execute()
            if (!response.isSuccessful && response.code in listOf(403, 405)) {
                response.close()
                val getRequest = requestBuilder
                    .get()
                    .header("Range", "bytes=0-0")
                    .build()
                response = httpClient.newCall(getRequest).execute()
            }
            val isSuccessful = response.isSuccessful || response.code == 206
            Timber.tag(logTag).d("Stream URL validation result: ${if (isSuccessful) "Success" else "Failed"} (${response.code})")
            response.close()
            return isSuccessful
        } catch (e: Exception) {
            Timber.tag(logTag).e(e, "Stream URL validation failed with exception")
            reportException(e)
        }
        return false
    }
    data class SignatureTimestampResult(
        val timestamp: Int?,
        val isAgeRestricted: Boolean
    )

    private suspend fun getSignatureTimestampOrNull(videoId: String): SignatureTimestampResult {
        Timber.tag(logTag).d("Getting signature timestamp for videoId: $videoId")

        // Prefer the STS of the player the cipher actually deciphers with. The STS decides which
        // player generation YouTube mints the signatureCipher for; during A/B rollouts NewPipe's
        // independently fetched player can be a DIFFERENT generation, and a sig minted for one
        // player but deciphered by another 403s on the CDN. NewPipe is kept for age-restriction
        // detection and as the STS source only when the cipher player fetch fails.
        val cipherSts = try {
            CipherDeobfuscator.signatureTimestamp()
                ?.also { Timber.tag(logTag).d("Signature timestamp from cipher player: $it") }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e // cooperative cancellation: don't swallow, let the playback coroutine unwind
        } catch (e: Exception) {
            Timber.tag(logTag).e(e, "Cipher player STS fetch failed")
            null
        }

        val result = NewPipeExtractor.getSignatureTimestamp(videoId)
        return result.fold(
            onSuccess = { timestamp ->
                val chosen = cipherSts ?: timestamp
                Timber.tag(logTag).d("Signature timestamp resolved: cipher=$cipherSts newpipe=$timestamp -> using $chosen")
                SignatureTimestampResult(chosen, isAgeRestricted = false)
            },
            onFailure = { error ->
                val isAgeRestricted = error.message?.contains("age-restricted", ignoreCase = true) == true ||
                    error.cause?.message?.contains("age-restricted", ignoreCase = true) == true
                when {
                    isAgeRestricted -> {
                        Timber.tag(logTag).d("Age-restricted content detected from NewPipe")
                        Timber.tag(TAG).i("Age-restricted detected early via NewPipe: videoId=$videoId")
                    }
                    cipherSts != null -> {
                        // Non-fatal: the cipher player's STS already covers us, so NewPipe is just
                        // a fallback here — don't report its failure as an exception (avoids noise).
                        Timber.tag(logTag).w("NewPipe STS unavailable, using cipher player STS: ${error.message}")
                    }
                    else -> {
                        Timber.tag(logTag).e(error, "Failed to get signature timestamp via NewPipe")
                        reportException(error)
                    }
                }
                // The cipher player's STS is exactly the one the cipher will decipher with.
                Timber.tag(logTag).d("Signature timestamp resolved: cipher=$cipherSts (NewPipe failed)")
                SignatureTimestampResult(cipherSts, isAgeRestricted)
            }
        )
    }

    private suspend fun findUrlOrNull(
        format: PlayerResponse.StreamingData.Format,
        videoId: String,
        playerResponse: PlayerResponse,
        skipNewPipe: Boolean = false
    ): String? {
        Timber.tag(logTag).d("Finding stream URL for format: ${format.mimeType}, videoId: $videoId, skipNewPipe: $skipNewPipe")

        // First check if format already has a URL
        if (!format.url.isNullOrEmpty()) {
            Timber.tag(logTag).d("Using URL from format directly")
            return format.url
        }

        // Try custom cipher deobfuscation for signatureCipher formats
        val signatureCipher = format.signatureCipher ?: format.cipher
        if (!signatureCipher.isNullOrEmpty()) {
            Timber.tag(logTag).d("Format has signatureCipher, using custom deobfuscation")
            val customDeobfuscatedUrl = CipherDeobfuscator.deobfuscateStreamUrl(signatureCipher, videoId)
            if (customDeobfuscatedUrl != null) {
                Timber.tag(logTag).d("Stream URL obtained via custom cipher deobfuscation")
                return customDeobfuscatedUrl
            }
            Timber.tag(logTag).d("Custom cipher deobfuscation failed")
        }

        // Always try NewPipe signature deobfuscation - it doesn't need auth,
        // it just applies the cipher algorithm from player.js.
        // This is critical for privately-owned tracks where skipNewPipe is true.
        val deobfuscatedUrl = NewPipeExtractor.getStreamUrl(format, videoId)
        if (deobfuscatedUrl != null) {
            Timber.tag(logTag).d("Stream URL obtained via NewPipe deobfuscation")
            return deobfuscatedUrl
        }

        // Skip StreamInfo fallback for age-restricted or private content
        // (StreamInfo fetch may fail without auth for these)
        if (skipNewPipe) {
            Timber.tag(logTag).d("Skipping StreamInfo fallback for age-restricted/private content")
            return null
        }

        // Fallback: try to get URL from StreamInfo
        Timber.tag(logTag).d("Trying StreamInfo fallback for URL")
        val streamUrls = YouTube.getNewPipeStreamUrls(videoId)
        if (streamUrls.isNotEmpty()) {
            val streamUrl = streamUrls.find { it.first == format.itag }?.second
            if (streamUrl != null) {
                Timber.tag(logTag).d("Stream URL obtained from StreamInfo")
                return streamUrl
            }

            // If exact itag not found, try to find any audio stream
            val audioStream = streamUrls.find { urlPair ->
                playerResponse.streamingData?.adaptiveFormats?.any {
                    it.itag == urlPair.first && it.isAudio
                } == true
            }?.second

            if (audioStream != null) {
                Timber.tag(logTag).d("Audio stream URL obtained from StreamInfo (different itag)")
                return audioStream
            }
        }

        Timber.tag(logTag).e("Failed to get stream URL")
        return null
    }

    fun forceRefreshForVideo(videoId: String) {
        Timber.tag(logTag).d("Force refreshing for videoId: $videoId")
    }
}

object PipedExtractor {
    private val client by lazy {
        okhttp3.OkHttpClient.Builder()
            .connectTimeout(8, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(8, java.util.concurrent.TimeUnit.SECONDS)
            .build()
    }

    private val pipedInstances = listOf(
        "https://pipedapi.kavin.rocks",
        "https://api.piped.video",
        "https://pipedapi.mha.fi",
        "https://pipedapi.drgns.space",
        "https://piped-api.garudalinux.org",
        "https://pipedapi.palvelintalo.fi",
        "https://pipedapi.nose2.com",
        "https://pipedapi.adminforge.de",
        "https://api.piped.projectsegfau.lt"
    )

    private val invidiousInstances = listOf(
        "https://inv.tux.pizza",
        "https://invidious.nerdvpn.de",
        "https://vid.puffyan.us",
        "https://invidious.drgns.space",
        "https://inv.projectsegfau.lt",
        "https://invidious.flokinet.to",
        "https://invidious.privacydev.net"
    )

    fun getAudioStreamUrl(videoId: String): Pair<String, String>? {
        for (instance in pipedInstances) {
            try {
                val req = okhttp3.Request.Builder()
                    .url("$instance/streams/$videoId")
                    .header("User-Agent", YouTubeClient.USER_AGENT_WEB)
                    .build()
                client.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val body = resp.body?.string() ?: return@use
                        val json = org.json.JSONObject(body)
                        val audioStreams = json.optJSONArray("audioStreams")
                        if (audioStreams != null && audioStreams.length() > 0) {
                            var bestUrl: String? = null
                            var bestBitrate = -1
                            var bestMime = "audio/webm; codecs=\"opus\""
                            for (i in 0 until audioStreams.length()) {
                                val stream = audioStreams.getJSONObject(i)
                                val url = stream.optString("url")
                                val bitrate = stream.optInt("bitrate", 0)
                                val mime = stream.optString("mimeType", "audio/webm")
                                if (url.isNotEmpty() && bitrate > bestBitrate) {
                                    bestBitrate = bitrate
                                    bestUrl = url
                                    bestMime = mime
                                }
                            }
                            val resUrl = bestUrl
                            if (resUrl != null) {
                                return Pair(resUrl, bestMime)
                            }
                        }
                    }
                }
            } catch (_: Exception) {}
        }

        for (instance in invidiousInstances) {
            try {
                val req = okhttp3.Request.Builder()
                    .url("$instance/api/v1/videos/$videoId")
                    .header("User-Agent", YouTubeClient.USER_AGENT_WEB)
                    .build()
                client.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val body = resp.body?.string() ?: return@use
                        val json = org.json.JSONObject(body)
                        val adaptiveFormats = json.optJSONArray("adaptiveFormats")
                        if (adaptiveFormats != null && adaptiveFormats.length() > 0) {
                            var bestUrl: String? = null
                            var bestBitrate = -1
                            var bestMime = "audio/webm; codecs=\"opus\""
                            for (i in 0 until adaptiveFormats.length()) {
                                val fmt = adaptiveFormats.getJSONObject(i)
                                val type = fmt.optString("type", "")
                                if (type.startsWith("audio/")) {
                                    val url = fmt.optString("url")
                                    val bitrate = fmt.optInt("bitrate", 0)
                                    if (url.isNotEmpty() && bitrate > bestBitrate) {
                                        bestBitrate = bitrate
                                        bestUrl = url
                                        bestMime = type
                                    }
                                }
                            }
                            val resUrl = bestUrl
                            if (resUrl != null) {
                                return Pair(resUrl, bestMime)
                            }
                        }
                    }
                }
            } catch (_: Exception) {}
        }

        return null
    }
}
