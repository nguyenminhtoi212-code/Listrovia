/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.screens.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import coil3.imageLoader
import com.listrovia.music.constants.EnableHighRefreshRateKey
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.listrovia.music.LocalPlayerAwareWindowInsets
import com.listrovia.music.R
import com.listrovia.music.ui.component.IconButton
import com.listrovia.music.ui.component.Material3SettingsGroup
import com.listrovia.music.ui.component.Material3SettingsItem
import com.listrovia.music.ui.utils.backToMain
import com.listrovia.music.utils.rememberPreference
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

val DevModeKey = booleanPreferencesKey("devMode")
val AdvancedSecurityProtocolKey = booleanPreferencesKey("advancedSecurityProtocol")
val AutoSendErrorReportKey = booleanPreferencesKey("autoSendErrorReport")
val AutoOptimizePerformanceKey = booleanPreferencesKey("autoOptimizePerformance")
val UnlimitedBackgroundRunKey = booleanPreferencesKey("unlimitedBackgroundRun")
val OfflineStorageCacheKey = booleanPreferencesKey("offlineStorageCache")

val ShowMostPlayedSongsKey = booleanPreferencesKey("showMostPlayedSongs")
val ShowMostPlayedArtistsKey = booleanPreferencesKey("showMostPlayedArtists")
val ShowMostPlayedMusicVideosKey = booleanPreferencesKey("showMostPlayedMusicVideos")
val ShowMostPlayedPlaylistsKey = booleanPreferencesKey("showMostPlayedPlaylists")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdvancedSettings(
    navController: NavController
) {
    val (devMode, onDevModeChange) = rememberPreference(key = DevModeKey, defaultValue = false)
    val (advSecurity, onAdvSecurityChange) = rememberPreference(key = AdvancedSecurityProtocolKey, defaultValue = true)
    val (sendErrors, onSendErrorsChange) = rememberPreference(key = AutoSendErrorReportKey, defaultValue = true)
    val (optimizePerf, onOptimizePerfChange) = rememberPreference(key = AutoOptimizePerformanceKey, defaultValue = true)
    val (unlimitBg, onUnlimitBgChange) = rememberPreference(key = UnlimitedBackgroundRunKey, defaultValue = false)
    val context = LocalContext.current
    val (enableHighRefreshRate, onEnableHighRefreshRateChange) = rememberPreference(key = EnableHighRefreshRateKey, defaultValue = true)

    val (showMostPlayedSongs, onShowMostPlayedSongsChange) = rememberPreference(key = ShowMostPlayedSongsKey, defaultValue = false)
    val (showMostPlayedArtists, onShowMostPlayedArtistsChange) = rememberPreference(key = ShowMostPlayedArtistsKey, defaultValue = false)
    val (showMostPlayedMusicVideos, onShowMostPlayedMusicVideosChange) = rememberPreference(key = ShowMostPlayedMusicVideosKey, defaultValue = false)
    val (showMostPlayedPlaylists, onShowMostPlayedPlaylistsChange) = rememberPreference(key = ShowMostPlayedPlaylistsKey, defaultValue = false)
    val (offlineStorageCache, onOfflineStorageCacheChange) = rememberPreference(key = OfflineStorageCacheKey, defaultValue = true)

    Column(
        Modifier
            .windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom
                )
            )
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Spacer(
            Modifier.windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Top
                )
            )
        )

        Material3SettingsGroup(
            title = stringResource(R.string.advanced_options_title),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.settings),
                    title = { Text(stringResource(R.string.dev_mode_title)) },
                    trailingContent = {
                        Switch(
                            checked = devMode,
                            onCheckedChange = onDevModeChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (devMode) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onDevModeChange(!devMode) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.security),
                    title = { Text(stringResource(R.string.adv_security_title)) },
                    trailingContent = {
                        Switch(
                            checked = advSecurity,
                            onCheckedChange = onAdvSecurityChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (advSecurity) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAdvSecurityChange(!advSecurity) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.info),
                    title = { Text(stringResource(R.string.auto_send_error_report_title)) },
                    trailingContent = {
                        Switch(
                            checked = sendErrors,
                            onCheckedChange = onSendErrorsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (sendErrors) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onSendErrorsChange(!sendErrors) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.sliders),
                    title = { Text(stringResource(R.string.auto_optimize_performance_title)) },
                    trailingContent = {
                        Switch(
                            checked = optimizePerf,
                            onCheckedChange = onOptimizePerfChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (optimizePerf) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onOptimizePerfChange(!optimizePerf) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.restore),
                    title = { Text(stringResource(R.string.unlimited_background_run_title)) },
                    trailingContent = {
                        Switch(
                            checked = unlimitBg,
                            onCheckedChange = onUnlimitBgChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (unlimitBg) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onUnlimitBgChange(!unlimitBg) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.cached),
                    title = { Text(stringResource(R.string.instant_optimize_title)) },
                    description = { Text(stringResource(R.string.instant_optimize_desc)) },
                    onClick = {
                        try {
                            // 1. Clear Coil memory & disk cache
                            context.imageLoader.memoryCache?.clear()
                            context.imageLoader.diskCache?.clear()
                            // 2. Turn on high refresh rate
                            onEnableHighRefreshRateChange(true)
                            // 3. Turn on auto optimize performance
                            onOptimizePerfChange(true)
                            // 4. Force JVM GC
                            System.gc()
                            Toast.makeText(context, context.getString(R.string.instant_optimize_success), Toast.LENGTH_LONG).show()
                        } catch (e: Exception) {
                            Toast.makeText(context, context.getString(R.string.instant_optimize_error, e.message ?: ""), Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

                Material3SettingsGroup(
            title = stringResource(R.string.offline_storage_group_title),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.storage),
                    title = { Text(stringResource(R.string.offline_storage_cache_title)) },
                    description = { Text(stringResource(R.string.offline_storage_cache_desc)) },
                    trailingContent = {
                        Switch(
                            checked = offlineStorageCache,
                            onCheckedChange = onOfflineStorageCacheChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (offlineStorageCache) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onOfflineStorageCacheChange(!offlineStorageCache) }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.show_most_played_group_title),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.music_note),
                    title = { Text(stringResource(R.string.show_most_played_songs_title)) },
                    trailingContent = {
                        Switch(
                            checked = showMostPlayedSongs,
                            onCheckedChange = onShowMostPlayedSongsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (showMostPlayedSongs) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onShowMostPlayedSongsChange(!showMostPlayedSongs) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.person),
                    title = { Text(stringResource(R.string.show_most_played_artists_title)) },
                    trailingContent = {
                        Switch(
                            checked = showMostPlayedArtists,
                            onCheckedChange = onShowMostPlayedArtistsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (showMostPlayedArtists) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onShowMostPlayedArtistsChange(!showMostPlayedArtists) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.play),
                    title = { Text(stringResource(R.string.show_most_played_music_videos_title)) },
                    description = { Text(stringResource(R.string.show_most_played_music_videos_desc)) },
                    trailingContent = {
                        Switch(
                            checked = showMostPlayedMusicVideos,
                            onCheckedChange = onShowMostPlayedMusicVideosChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (showMostPlayedMusicVideos) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onShowMostPlayedMusicVideosChange(!showMostPlayedMusicVideos) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.queue_music),
                    title = { Text(stringResource(R.string.show_most_played_playlists_title)) },
                    description = { Text(stringResource(R.string.show_most_played_playlists_desc)) },
                    trailingContent = {
                        Switch(
                            checked = showMostPlayedPlaylists,
                            onCheckedChange = onShowMostPlayedPlaylistsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (showMostPlayedPlaylists) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onShowMostPlayedPlaylistsChange(!showMostPlayedPlaylists) }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        val healthState by com.listrovia.innertube.InnerTubeHealthCheckService.healthState.collectAsStateWithLifecycle()
        val coroutineScope = rememberCoroutineScope()

        Material3SettingsGroup(
            title = stringResource(R.string.innertube_diagnostics_group_title),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.security),
                    title = { Text(stringResource(R.string.innertube_model_integrity_title)) },
                    description = {
                        val statusText = when (val state = healthState) {
                            is com.listrovia.innertube.InnerTubeHealthCheckService.HealthStatus.Idle -> stringResource(R.string.innertube_status_idle)
                            is com.listrovia.innertube.InnerTubeHealthCheckService.HealthStatus.Checking -> stringResource(R.string.innertube_status_checking)
                            is com.listrovia.innertube.InnerTubeHealthCheckService.HealthStatus.Healthy -> stringResource(R.string.innertube_status_healthy)
                            is com.listrovia.innertube.InnerTubeHealthCheckService.HealthStatus.Warning -> stringResource(R.string.innertube_status_warning, state.message)
                            is com.listrovia.innertube.InnerTubeHealthCheckService.HealthStatus.Error -> stringResource(R.string.innertube_status_error, state.error)
                        }
                        Text(statusText)
                    },
                    onClick = {}
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.refresh),
                    title = { Text(stringResource(R.string.run_manual_check)) },
                    description = { Text(stringResource(R.string.run_manual_check_desc)) },
                    onClick = {
                        coroutineScope.launch(Dispatchers.IO) {
                            com.listrovia.innertube.InnerTubeHealthCheckService.runHealthCheck(com.listrovia.innertube.InnerTube())
                        }
                    }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.bug_report),
                    title = { Text(stringResource(R.string.innertube_realtime_logs_title)) },
                    description = { Text(stringResource(R.string.innertube_realtime_logs_desc)) },
                    onClick = {
                        navController.navigate("api_logs")
                    }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        val detectedFormFactor by com.listrovia.innertube.SongContentModerator.detectedFormFactor.collectAsStateWithLifecycle()
        val detectedRegion by com.listrovia.innertube.SongContentModerator.detectedRegion.collectAsStateWithLifecycle()
        val detectedCountryName by com.listrovia.innertube.SongContentModerator.detectedCountryName.collectAsStateWithLifecycle()
        val detectedIp by com.listrovia.innertube.SongContentModerator.detectedIp.collectAsStateWithLifecycle()
        val householdStatus by com.listrovia.innertube.SongContentModerator.detectedHouseholdStatus.collectAsStateWithLifecycle()
        val blockedScams by com.listrovia.innertube.SongContentModerator.blockedScamCount.collectAsStateWithLifecycle()
        val blockedViolations by com.listrovia.innertube.SongContentModerator.blockedViolationsCount.collectAsStateWithLifecycle()
        val outsideSearchCensorship by com.listrovia.innertube.SongContentModerator.outsideSearchCensorshipActive.collectAsStateWithLifecycle()
        val isRegionRestricted by com.listrovia.innertube.SongContentModerator.isRegionRestricted.collectAsStateWithLifecycle()

        Material3SettingsGroup(
            title = stringResource(R.string.regional_compliance_title),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.security),
                    title = { Text(stringResource(R.string.regional_compliance_title)) },
                    description = {
                        val statusDesc = if (isRegionRestricted) {
                            stringResource(R.string.playback_restricted_region_notice)
                        } else {
                            stringResource(R.string.legal_compliance_status_ok)
                        }
                        Text("$statusDesc\n${stringResource(R.string.detected_device_label)} $detectedFormFactor\n${stringResource(R.string.detected_country_label)} $detectedCountryName ($detectedRegion)\n${stringResource(R.string.detected_ip_label)} $detectedIp\n${stringResource(R.string.household_status_label)} $householdStatus\n${stringResource(R.string.blocked_threats_label)} ${blockedScams + blockedViolations}")
                    },
                    onClick = {
                        Toast.makeText(context, context.getString(R.string.regional_service_notice), Toast.LENGTH_SHORT).show()
                    }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.search),
                    title = { Text(stringResource(R.string.outside_search_censorship_title)) },
                    description = { Text(stringResource(R.string.outside_search_censorship_desc)) },
                    trailingContent = {
                        Switch(
                            checked = outsideSearchCensorship,
                            onCheckedChange = {
                                com.listrovia.innertube.SongContentModerator.setOutsideSearchCensorship(it)
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = MaterialTheme.colorScheme.primary)
                        )
                    },
                    onClick = {
                        com.listrovia.innertube.SongContentModerator.setOutsideSearchCensorship(!outsideSearchCensorship)
                    }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))
    }

    TopAppBar(
        title = { Text(stringResource(R.string.advanced_settings_title)) },
        navigationIcon = {
            IconButton(
                onClick = navController::navigateUp,
                onLongClick = navController::backToMain,
            ) {
                Icon(
                    painterResource(R.drawable.arrow_back),
                    contentDescription = null,
                )
            }
        }
    )
}
