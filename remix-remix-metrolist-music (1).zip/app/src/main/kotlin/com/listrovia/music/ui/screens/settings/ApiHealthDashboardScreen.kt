package com.listrovia.music.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.listrovia.innertube.InnerTubeLogBuffer
import com.listrovia.innertube.ApiLogEntry
import com.listrovia.music.R
import com.listrovia.music.ui.component.IconButton

/**
 * Dedicated 'API Health Dashboard' screen using Jetpack Compose that visualizes
 * 'Data Structure Mismatches' and 'Parsing Failures' logs with filtering options by severity.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApiHealthDashboardScreen(navController: NavController) {
    val logs by InnerTubeLogBuffer.logs.collectAsStateWithLifecycle()

    var selectedSeverity by remember { mutableStateOf<ApiLogEntry.LogCategory?>(null) }

    val filteredLogs = remember(logs, selectedSeverity) {
        logs.filter { log ->
            selectedSeverity == null || log.category == selectedSeverity
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.api_health_dashboard_title)) },
                navigationIcon = {
                    IconButton(onClick = navController::navigateUp) {
                        Icon(painterResource(R.drawable.arrow_back), contentDescription = null)
                    }
                },
                actions = {
                    TextButton(onClick = { InnerTubeLogBuffer.clearLogs() }) {
                        Text(stringResource(R.string.clear_logs_action))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Filtering Options Row
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = stringResource(R.string.filter_by_severity),
                        style = MaterialTheme.typography.labelMedium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = selectedSeverity == null,
                            onClick = { selectedSeverity = null },
                            label = { Text(stringResource(R.string.severity_all)) }
                        )
                        FilterChip(
                            selected = selectedSeverity == ApiLogEntry.LogCategory.DATA_STRUCTURE_MISMATCH,
                            onClick = { selectedSeverity = ApiLogEntry.LogCategory.DATA_STRUCTURE_MISMATCH },
                            label = { Text(stringResource(R.string.severity_mismatch)) }
                        )
                        FilterChip(
                            selected = selectedSeverity == ApiLogEntry.LogCategory.PARSING_FAILURE,
                            onClick = { selectedSeverity = ApiLogEntry.LogCategory.PARSING_FAILURE },
                            label = { Text(stringResource(R.string.severity_parsing)) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (filteredLogs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = stringResource(R.string.no_api_logs),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredLogs) { log ->
                        val categoryLabel = when (log.category) {
                            ApiLogEntry.LogCategory.PARSING_FAILURE -> stringResource(R.string.severity_parsing)
                            ApiLogEntry.LogCategory.DATA_STRUCTURE_MISMATCH -> stringResource(R.string.severity_mismatch)
                            ApiLogEntry.LogCategory.INFO -> "INFO"
                        }
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = when (log.category) {
                                    ApiLogEntry.LogCategory.PARSING_FAILURE -> MaterialTheme.colorScheme.errorContainer
                                    ApiLogEntry.LogCategory.DATA_STRUCTURE_MISMATCH -> MaterialTheme.colorScheme.tertiaryContainer
                                    ApiLogEntry.LogCategory.INFO -> MaterialTheme.colorScheme.surfaceVariant
                                }
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "[$categoryLabel]",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = log.timestamp,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "URL: ${log.url}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = log.message,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }
                    item { Spacer(modifier = Modifier.height(16.dp)) }
                }
            }
        }
    }
}
