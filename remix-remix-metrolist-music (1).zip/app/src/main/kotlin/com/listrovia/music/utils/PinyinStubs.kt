package com.github.promeg.pinyinhelper

object Pinyin {
    fun toPinyin(ch: Char): String {
        return ch.toString()
    }
}
