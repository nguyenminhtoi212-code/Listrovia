package androidx.compose.ui.platform

import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.IntSize

/**
 * Extension property to calculate the container size in DP for older Compose versions.
 */
val WindowInfo.containerDpSize: DpSize
    @Composable
    get() {
        val config = LocalConfiguration.current
        return DpSize(config.screenWidthDp.dp, config.screenHeightDp.dp)
    }

/**
 * Extension property to get the screen size in pixels.
 */
val WindowInfo.containerSize: IntSize
    get() {
        val dm = android.content.res.Resources.getSystem().displayMetrics
        return IntSize(dm.widthPixels, dm.heightPixels)
    }
