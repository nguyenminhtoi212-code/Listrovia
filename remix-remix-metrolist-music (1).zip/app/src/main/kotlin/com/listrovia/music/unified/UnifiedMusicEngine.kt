/**
 * Listrovia / Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 *
 * UnifiedMusicEngine.kt
 * Consolidated single-file engine containing all Unified Models, Unified Music Interface,
 * Apple Music Adapter, and Unified Music Repository. Do not split into separate files.
 */

package com.listrovia.music.unified

import com.listrovia.innertube.YouTube
import com.listrovia.innertube.Album
import com.listrovia.innertube.Artist
import com.listrovia.innertube.SongItem
import com.listrovia.music.api.ExternalArtist
import com.listrovia.music.api.ExternalPlaylist
import com.listrovia.music.api.ExternalTrack
import com.listrovia.music.api.MusicCategory
import com.listrovia.music.api.MusicCountry
import com.listrovia.music.api.MusicSourceProvider
import com.listrovia.music.api.UserComment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import timber.log.Timber
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

// ============================================================================
// 1. SHARED NETWORK & SERIALIZATION INFRASTRUCTURE
// ============================================================================

internal object UnifiedNetworkCore {
    private const val DEFAULT_USER_AGENT =
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"

    val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    val json: Json by lazy {
        Json {
            ignoreUnknownKeys = true
            isLenient = true
            coerceInputValues = true
        }
    }

    fun buildGetRequest(url: String, userAgent: String = DEFAULT_USER_AGENT): Request {
        return Request.Builder()
            .url(url)
            .header("User-Agent", userAgent)
            .header("Accept", "application/json")
            .build()
    }

    fun parseJsonObjectSafely(rawBody: String?): JsonObject? {
        if (rawBody.isNullOrBlank()) return null
        return runCatching {
            json.parseToJsonElement(rawBody) as? JsonObject
        }.getOrNull()
    }
}

private fun JsonObject.stringOrNull(key: String): String? {
    val element = this[key] as? JsonPrimitive ?: return null
    if (element is JsonNull) return null
    return element.contentOrNull?.takeIf { it.isNotBlank() && it != "null" }
}

private fun JsonObject.stringOrEmpty(key: String): String = stringOrNull(key) ?: ""

private fun JsonObject.intOrNull(key: String): Int? = stringOrNull(key)?.toIntOrNull()

private fun String.upscaleArtwork(): String {
    if (isBlank()) return ""
    return replace("100x100bb.jpg", "600x600bb.jpg")
        .replace("100x100bb.png", "600x600bb.png")
}

// ============================================================================
// 2. UNIFIED DATA MODELS
// ============================================================================

/**
 * Standardized Unified Track representation across all music providers (Spotify, Apple Music, YouTube).
 */
@Serializable
data class UnifiedTrack(
    val id: String,
    val title: String,
    val artist: String,
    val artists: List<String> = emptyList(),
    val album: String = "",
    val thumbnailUrl: String = "",
    val durationSeconds: Int? = null,
    val provider: MusicSourceProvider,
    val previewUrl: String? = null,
    val externalUrl: String? = null,
    val isExplicit: Boolean = false,
    val isrc: String? = null,
    val popularity: Int? = null,
    val releaseDate: String? = null,
    val countryCode: String = "vn",
    val categoryId: String = "all",
    val resolvedVideoId: String? = null,
) {
    val uniqueId: String
        get() {
            val prefix = when (provider) {
                MusicSourceProvider.APPLE_MUSIC -> "am_"
                MusicSourceProvider.YOUTUBE -> "yt_"
                else -> "ext_"
            }
            val cleanId = id.replace(Regex("[^a-zA-Z0-9_-]"), "")
            return if (cleanId.startsWith("am_") || cleanId.startsWith("yt_")) {
                cleanId
            } else {
                "$prefix$cleanId"
            }
        }

    fun toSongItem(resolvedId: String? = null): SongItem {
        val targetId = resolvedId?.takeIf { it.isNotBlank() }
            ?: resolvedVideoId?.takeIf { it.isNotBlank() }
            ?: uniqueId
        val artistList = if (artists.isNotEmpty()) {
            artists.filter { it.isNotBlank() }.map { Artist(name = it, id = null) }
        } else {
            listOf(Artist(name = artist.ifBlank { "Unknown Artist" }, id = null))
        }
        return SongItem(
            id = targetId,
            title = title.ifBlank { "Unknown Track" },
            artists = artistList.ifEmpty { listOf(Artist(name = "Unknown Artist", id = null)) },
            album = if (album.isNotBlank()) Album(name = album, id = "") else null,
            duration = durationSeconds,
            thumbnail = thumbnailUrl,
            explicit = isExplicit
        )
    }

    fun toExternalTrack(): ExternalTrack {
        return ExternalTrack(
            id = id,
            title = title,
            artist = artist,
            album = album,
            thumbnailUrl = thumbnailUrl,
            durationSeconds = durationSeconds,
            provider = provider,
            previewUrl = previewUrl,
            externalUrl = externalUrl,
            isExplicit = isExplicit,
            resolvedVideoId = resolvedVideoId,
            countryCode = countryCode,
            categoryId = categoryId
        )
    }

    companion object {
        fun fromExternalTrack(track: ExternalTrack): UnifiedTrack {
            return UnifiedTrack(
                id = track.id,
                title = track.title,
                artist = track.artist,
                artists = if (track.artist.isNotBlank()) listOf(track.artist) else emptyList(),
                album = track.album,
                thumbnailUrl = track.thumbnailUrl,
                durationSeconds = track.durationSeconds,
                provider = track.provider,
                previewUrl = track.previewUrl,
                externalUrl = track.externalUrl,
                isExplicit = track.isExplicit,
                resolvedVideoId = track.resolvedVideoId,
                countryCode = track.countryCode,
                categoryId = track.categoryId
            )
        }
    }
}

/**
 * Standardized Unified Artist representation across all music providers.
 */
@Serializable
data class UnifiedArtist(
    val id: String,
    val name: String,
    val thumbnailUrl: String = "",
    val followers: String? = null,
    val genres: List<String> = emptyList(),
    val provider: MusicSourceProvider,
    val externalUrl: String? = null,
    val popularity: Int? = null,
) {
    fun toExternalArtist(): ExternalArtist {
        return ExternalArtist(
            id = id,
            name = name,
            thumbnailUrl = thumbnailUrl,
            followers = followers,
            genres = genres,
            provider = provider,
            externalUrl = externalUrl
        )
    }

    companion object {
        fun fromExternalArtist(artist: ExternalArtist): UnifiedArtist {
            return UnifiedArtist(
                id = artist.id,
                name = artist.name,
                thumbnailUrl = artist.thumbnailUrl,
                followers = artist.followers,
                genres = artist.genres,
                provider = artist.provider,
                externalUrl = artist.externalUrl
            )
        }
    }
}

/**
 * Standardized Unified Playlist representation across all music providers.
 */
@Serializable
data class UnifiedPlaylist(
    val id: String,
    val title: String,
    val description: String = "",
    val thumbnailUrl: String = "",
    val trackCount: Int? = null,
    val provider: MusicSourceProvider,
    val externalUrl: String? = null,
    val curator: String? = null,
) {
    fun toExternalPlaylist(): ExternalPlaylist {
        return ExternalPlaylist(
            id = id,
            title = title,
            description = description,
            thumbnailUrl = thumbnailUrl,
            trackCount = trackCount,
            provider = provider,
            externalUrl = externalUrl
        )
    }

    companion object {
        fun fromExternalPlaylist(playlist: ExternalPlaylist): UnifiedPlaylist {
            return UnifiedPlaylist(
                id = playlist.id,
                title = playlist.title,
                description = playlist.description,
                thumbnailUrl = playlist.thumbnailUrl,
                trackCount = playlist.trackCount,
                provider = playlist.provider,
                externalUrl = playlist.externalUrl
            )
        }
    }
}

/**
 * Aggregated search result container across unified sources.
 */
data class UnifiedSearchResult(
    val tracks: List<UnifiedTrack> = emptyList(),
    val artists: List<UnifiedArtist> = emptyList(),
    val playlists: List<UnifiedPlaylist> = emptyList(),
    val provider: MusicSourceProvider = MusicSourceProvider.ALL
)

// ============================================================================
// 3. UNIFIED MUSIC INTERFACE
// ============================================================================

/**
 * Unified Music Interface (Tệp chuẩn hóa dữ liệu & giao thức dịch vụ âm nhạc).
 *
 * Defines the contract implemented by music streaming adapters (e.g. Apple Music Adapter).
 */
interface UnifiedMusicInterface {
    /**
     * Provider identifier (e.g. APPLE_MUSIC)
     */
    val provider: MusicSourceProvider

    /**
     * Check if this adapter is available / enabled.
     */
    val isAvailable: Boolean
        get() = true

    /**
     * Searches tracks from the provider and returns normalized [UnifiedTrack]s.
     */
    suspend fun searchTracks(query: String, limit: Int = 25): List<UnifiedTrack>

    /**
     * Searches artists from the provider and returns normalized [UnifiedArtist]s.
     */
    suspend fun searchArtists(query: String, limit: Int = 15): List<UnifiedArtist>

    /**
     * Searches playlists from the provider and returns normalized [UnifiedPlaylist]s.
     */
    suspend fun searchPlaylists(query: String, limit: Int = 15): List<UnifiedPlaylist>

    /**
     * Fetches recommended tracks based on country and music genre/category.
     */
    suspend fun getRecommendations(
        country: MusicCountry = MusicCountry.VIETNAM,
        category: MusicCategory = MusicCategory.ALL,
        limit: Int = 30
    ): List<UnifiedTrack>

    /**
     * Fetches featured or top playlists based on country and category.
     */
    suspend fun getFeaturedPlaylists(
        country: MusicCountry = MusicCountry.VIETNAM,
        category: MusicCategory = MusicCategory.ALL,
        limit: Int = 15
    ): List<UnifiedPlaylist>

    /**
     * Fetches top artists based on country and category.
     */
    suspend fun getTopArtists(
        country: MusicCountry = MusicCountry.VIETNAM,
        category: MusicCategory = MusicCategory.ALL,
        limit: Int = 15
    ): List<UnifiedArtist>

    /**
     * Fetches single track details by provider ID.
     */
    suspend fun getTrackById(id: String): UnifiedTrack? = null

    /**
     * Fetches tracks contained in a playlist by provider ID.
     */
    suspend fun getPlaylistTracks(playlistId: String, limit: Int = 50): List<UnifiedTrack> = emptyList()
}

// ============================================================================
// 4. APPLE MUSIC ADAPTER IMPLEMENTATION
// ============================================================================

/**
 * Apple Music Adapter - Connects to the Apple Music / MusicKit RSS & iTunes Web API
 * and normalizes raw JSON responses into the [UnifiedMusicInterface] standard data structure.
 */
@Singleton
class AppleMusicAdapter @Inject constructor() : UnifiedMusicInterface {

    override val provider: MusicSourceProvider = MusicSourceProvider.APPLE_MUSIC

    private val client: OkHttpClient
        get() = UnifiedNetworkCore.httpClient

    override suspend fun searchTracks(query: String, limit: Int): List<UnifiedTrack> = withContext(Dispatchers.IO) {
        val cleanQuery = query.trim()
        if (cleanQuery.isBlank() || limit <= 0) return@withContext emptyList()

        val list = mutableListOf<UnifiedTrack>()
        try {
            val encodedQuery = URLEncoder.encode(cleanQuery, "UTF-8")
            val safeLimit = limit.coerceIn(1, 200)
            val url = "https://itunes.apple.com/search?term=$encodedQuery&entity=song&limit=$safeLimit"
            val request = UnifiedNetworkCore.buildGetRequest(url)

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val root = UnifiedNetworkCore.parseJsonObjectSafely(response.body?.string())
                    val results = root?.get("results") as? JsonArray
                    results?.forEach { item ->
                        val obj = item as? JsonObject ?: return@forEach
                        val rawId = obj.stringOrEmpty("trackId")
                        val title = obj.stringOrEmpty("trackName")
                        val artist = obj.stringOrEmpty("artistName").ifBlank { "Apple Music" }
                        val album = obj.stringOrEmpty("collectionName")
                        val art = obj.stringOrEmpty("artworkUrl100").upscaleArtwork()
                        val durationMs = obj.intOrNull("trackTimeMillis")
                        val previewUrl = obj.stringOrNull("previewUrl")
                        val trackViewUrl = obj.stringOrNull("trackViewUrl")
                        val isExplicit = obj.stringOrEmpty("trackExplicitness").equals("explicit", ignoreCase = true)

                        if (title.isNotBlank() && rawId.isNotBlank()) {
                            list.add(
                                UnifiedTrack(
                                    id = "am_$rawId",
                                    title = title,
                                    artist = artist,
                                    artists = listOf(artist),
                                    album = album,
                                    thumbnailUrl = art,
                                    durationSeconds = durationMs?.let { (it / 1000).coerceAtLeast(1) },
                                    provider = MusicSourceProvider.APPLE_MUSIC,
                                    previewUrl = previewUrl,
                                    externalUrl = trackViewUrl,
                                    isExplicit = isExplicit
                                )
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Apple Music searchTracks error for query: $cleanQuery")
        }
        return@withContext list.distinctBy { it.id }
    }

    override suspend fun searchArtists(query: String, limit: Int): List<UnifiedArtist> = withContext(Dispatchers.IO) {
        val cleanQuery = query.trim()
        if (cleanQuery.isBlank() || limit <= 0) return@withContext emptyList()

        val artists = mutableListOf<UnifiedArtist>()
        try {
            val encoded = URLEncoder.encode(cleanQuery, "UTF-8")
            val safeLimit = limit.coerceIn(1, 50)
            val url = "https://itunes.apple.com/search?term=$encoded&entity=musicArtist&limit=$safeLimit"
            val request = UnifiedNetworkCore.buildGetRequest(url)

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val root = UnifiedNetworkCore.parseJsonObjectSafely(response.body?.string())
                    val results = root?.get("results") as? JsonArray
                    coroutineScope {
                        val deferreds = results?.map { item ->
                            async {
                                val obj = item as? JsonObject ?: return@async null
                                val rawId = obj.stringOrEmpty("artistId")
                                val name = obj.stringOrEmpty("artistName")
                                val genre = obj.stringOrEmpty("primaryGenreName")
                                val artistLinkUrl = obj.stringOrNull("artistLinkUrl")

                                if (name.isNotBlank() && rawId.isNotBlank()) {
                                    var thumbnail = ""
                                    try {
                                        val lookupUrl = "https://itunes.apple.com/lookup?id=$rawId&entity=album&limit=1"
                                        val lookupRequest = UnifiedNetworkCore.buildGetRequest(lookupUrl)
                                        client.newCall(lookupRequest).execute().use { lookupResp ->
                                            if (lookupResp.isSuccessful) {
                                                val lookupRoot = UnifiedNetworkCore.parseJsonObjectSafely(lookupResp.body?.string())
                                                val lookupResults = lookupRoot?.get("results") as? JsonArray
                                                lookupResults?.forEach { resItem ->
                                                    val resObj = resItem as? JsonObject ?: return@forEach
                                                    val wrapperType = resObj.stringOrNull("wrapperType")
                                                    if (wrapperType == "collection" || wrapperType == "track") {
                                                        val art = resObj.stringOrEmpty("artworkUrl100").upscaleArtwork()
                                                        if (art.isNotBlank()) {
                                                            thumbnail = art
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    } catch (e: Exception) {
                                        Timber.w(e, "Error fetching thumbnail for artist $name")
                                    }

                                    UnifiedArtist(
                                        id = "am_art_$rawId",
                                        name = name,
                                        thumbnailUrl = thumbnail,
                                        genres = if (genre.isNotBlank()) listOf(genre) else emptyList(),
                                        provider = MusicSourceProvider.APPLE_MUSIC,
                                        externalUrl = artistLinkUrl
                                    )
                                } else {
                                    null
                                }
                            }
                        }
                        val resolved = deferreds?.awaitAll()?.filterNotNull()
                        if (resolved != null) {
                            artists.addAll(resolved)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Timber.w(e, "Apple Music searchArtists error for query: $cleanQuery")
        }
        return@withContext artists.distinctBy { it.id }
    }

    override suspend fun searchPlaylists(query: String, limit: Int): List<UnifiedPlaylist> = withContext(Dispatchers.IO) {
        val cleanQuery = query.trim()
        if (cleanQuery.isBlank() || limit <= 0) return@withContext emptyList()

        val playlists = mutableListOf<UnifiedPlaylist>()
        try {
            val encoded = URLEncoder.encode(cleanQuery, "UTF-8")
            val safeLimit = limit.coerceIn(1, 50)
            val url = "https://itunes.apple.com/search?term=$encoded&entity=album&limit=$safeLimit"
            val request = UnifiedNetworkCore.buildGetRequest(url)

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val root = UnifiedNetworkCore.parseJsonObjectSafely(response.body?.string())
                    val results = root?.get("results") as? JsonArray
                    results?.forEach { item ->
                        val obj = item as? JsonObject ?: return@forEach
                        val rawId = obj.stringOrEmpty("collectionId")
                        val name = obj.stringOrEmpty("collectionName")
                        val artist = obj.stringOrEmpty("artistName").ifBlank { "Apple Music" }
                        val art = obj.stringOrEmpty("artworkUrl100").upscaleArtwork()
                        val trackCount = obj.intOrNull("trackCount")
                        val viewUrl = obj.stringOrNull("collectionViewUrl")

                        if (name.isNotBlank() && rawId.isNotBlank()) {
                            playlists.add(
                                UnifiedPlaylist(
                                    id = "am_pl_$rawId",
                                    title = name,
                                    description = artist,
                                    thumbnailUrl = art,
                                    trackCount = trackCount,
                                    provider = MusicSourceProvider.APPLE_MUSIC,
                                    externalUrl = viewUrl
                                )
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Timber.w(e, "Apple Music searchPlaylists error for query: $cleanQuery")
        }
        return@withContext playlists.distinctBy { it.id }
    }

    override suspend fun getRecommendations(
        country: MusicCountry,
        category: MusicCategory,
        limit: Int
    ): List<UnifiedTrack> = withContext(Dispatchers.IO) {
        val safeLimit = limit.coerceIn(1, 100)
        val tracks = mutableListOf<UnifiedTrack>()

        // 1. Try Apple Music RSS most-played API for country when category is ALL
        if (category == MusicCategory.ALL) {
            try {
                val url = "https://rss.applemarketingtools.com/api/v2/${country.code}/music/most-played/$safeLimit/songs.json"
                val request = UnifiedNetworkCore.buildGetRequest(url)

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val root = UnifiedNetworkCore.parseJsonObjectSafely(response.body?.string())
                        val feed = root?.get("feed") as? JsonObject
                        val results = feed?.get("results") as? JsonArray
                        results?.forEach { item ->
                            val obj = item as? JsonObject ?: return@forEach
                            val rawId = obj.stringOrEmpty("id")
                            val title = obj.stringOrEmpty("name")
                            val artist = obj.stringOrEmpty("artistName").ifBlank { "Apple Music" }
                            val art = obj.stringOrEmpty("artworkUrl100").upscaleArtwork()
                            val externalUrl = obj.stringOrNull("url")

                            if (title.isNotBlank() && rawId.isNotBlank()) {
                                tracks.add(
                                    UnifiedTrack(
                                        id = "am_$rawId",
                                        title = title,
                                        artist = artist,
                                        artists = listOf(artist),
                                        thumbnailUrl = art,
                                        provider = MusicSourceProvider.APPLE_MUSIC,
                                        externalUrl = externalUrl,
                                        countryCode = country.code,
                                        categoryId = category.id
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.w(e, "Apple Music RSS fetch failed for ${country.code}")
            }
        }

        // 2. Category-specific search or Fallback
        if (tracks.isEmpty() || category != MusicCategory.ALL) {
            try {
                val queryStr = getCategoryAppleSearchQuery(country, category)
                val searchTerm = URLEncoder.encode(queryStr, "UTF-8")
                val url = "https://itunes.apple.com/search?term=$searchTerm&country=${country.code}&entity=song&limit=$safeLimit"
                val request = UnifiedNetworkCore.buildGetRequest(url)
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val root = UnifiedNetworkCore.parseJsonObjectSafely(response.body?.string())
                        val results = root?.get("results") as? JsonArray
                        results?.forEach { item ->
                            val obj = item as? JsonObject ?: return@forEach
                            val rawId = obj.stringOrEmpty("trackId")
                            val title = obj.stringOrEmpty("trackName")
                            val artist = obj.stringOrEmpty("artistName").ifBlank { "Apple Music" }
                            val album = obj.stringOrEmpty("collectionName")
                            val art = obj.stringOrEmpty("artworkUrl100").upscaleArtwork()
                            val durationMs = obj.intOrNull("trackTimeMillis")
                            val preview = obj.stringOrNull("previewUrl")
                            val extUrl = obj.stringOrNull("trackViewUrl")
                            val isExplicit = obj.stringOrEmpty("trackExplicitness").equals("explicit", ignoreCase = true)

                            if (title.isNotBlank() && rawId.isNotBlank() && (!category.isKidsFamily || !isExplicit)) {
                                tracks.add(
                                    UnifiedTrack(
                                        id = "am_$rawId",
                                        title = title,
                                        artist = artist,
                                        artists = listOf(artist),
                                        album = album,
                                        thumbnailUrl = art,
                                        durationSeconds = durationMs?.let { (it / 1000).coerceAtLeast(1) },
                                        previewUrl = preview,
                                        provider = MusicSourceProvider.APPLE_MUSIC,
                                        externalUrl = extUrl,
                                        isExplicit = isExplicit,
                                        countryCode = country.code,
                                        categoryId = category.id
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.w(e, "Apple Music category search failed for ${country.code} ${category.id}")
            }
        }

        return@withContext tracks.distinctBy { "${it.title.lowercase()}_${it.artist.lowercase()}" }
    }

    override suspend fun getFeaturedPlaylists(
        country: MusicCountry,
        category: MusicCategory,
        limit: Int
    ): List<UnifiedPlaylist> = withContext(Dispatchers.IO) {
        val safeLimit = limit.coerceIn(1, 50)
        val playlists = mutableListOf<UnifiedPlaylist>()
        if (category == MusicCategory.ALL) {
            try {
                val url = "https://rss.applemarketingtools.com/api/v2/${country.code}/music/most-played/$safeLimit/playlists.json"
                val request = UnifiedNetworkCore.buildGetRequest(url)
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val root = UnifiedNetworkCore.parseJsonObjectSafely(response.body?.string())
                        val feed = root?.get("feed") as? JsonObject
                        val results = feed?.get("results") as? JsonArray
                        results?.forEach { item ->
                            val obj = item as? JsonObject ?: return@forEach
                            val rawId = obj.stringOrEmpty("id")
                            val name = obj.stringOrEmpty("name")
                            val artist = obj.stringOrEmpty("artistName").ifBlank { "Apple Music" }
                            val art = obj.stringOrEmpty("artworkUrl100").upscaleArtwork()
                            val externalUrl = obj.stringOrNull("url")

                            if (name.isNotBlank() && rawId.isNotBlank()) {
                                playlists.add(
                                    UnifiedPlaylist(
                                        id = "am_pl_$rawId",
                                        title = name,
                                        description = artist,
                                        thumbnailUrl = art,
                                        provider = MusicSourceProvider.APPLE_MUSIC,
                                        externalUrl = externalUrl
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.w(e, "Apple Music featured playlists error for ${country.code}")
            }
        }

        if (playlists.isEmpty() || category != MusicCategory.ALL) {
            try {
                val queryStr = getCategoryAppleSearchQuery(country, category) + " playlist"
                val searchTerm = URLEncoder.encode(queryStr, "UTF-8")
                val url = "https://itunes.apple.com/search?term=$searchTerm&country=${country.code}&entity=album&limit=$safeLimit"
                val request = UnifiedNetworkCore.buildGetRequest(url)
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val root = UnifiedNetworkCore.parseJsonObjectSafely(response.body?.string())
                        val results = root?.get("results") as? JsonArray
                        results?.forEach { item ->
                            val obj = item as? JsonObject ?: return@forEach
                            val rawId = obj.stringOrEmpty("collectionId")
                            val name = obj.stringOrEmpty("collectionName")
                            val artist = obj.stringOrEmpty("artistName").ifBlank { "Apple Music" }
                            val art = obj.stringOrEmpty("artworkUrl100").upscaleArtwork()
                            val trackCount = obj.intOrNull("trackCount")
                            val viewUrl = obj.stringOrNull("collectionViewUrl")

                            if (name.isNotBlank() && rawId.isNotBlank()) {
                                playlists.add(
                                    UnifiedPlaylist(
                                        id = "am_pl_$rawId",
                                        title = name,
                                        description = artist,
                                        thumbnailUrl = art,
                                        trackCount = trackCount,
                                        provider = MusicSourceProvider.APPLE_MUSIC,
                                        externalUrl = viewUrl
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.w(e, "Apple Music curated search fallback error for category ${category.id}")
            }
        }
        return@withContext playlists.distinctBy { it.title.lowercase() }
    }

    override suspend fun getTopArtists(
        country: MusicCountry,
        category: MusicCategory,
        limit: Int
    ): List<UnifiedArtist> = withContext(Dispatchers.IO) {
        val query = getCategoryAppleSearchQuery(country, category)
        return@withContext searchArtists(query, limit)
    }

    override suspend fun getTrackById(id: String): UnifiedTrack? = withContext(Dispatchers.IO) {
        val cleanId = id.removePrefix("am_").removePrefix("apple:").trim()
        if (cleanId.isBlank()) return@withContext null
        try {
            val url = "https://itunes.apple.com/lookup?id=$cleanId&entity=song"
            val request = UnifiedNetworkCore.buildGetRequest(url)
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val root = UnifiedNetworkCore.parseJsonObjectSafely(response.body?.string()) ?: return@withContext null
                    val results = root["results"] as? JsonArray ?: return@withContext null
                    val item = results.firstOrNull {
                        val obj = it as? JsonObject
                        obj?.stringOrNull("wrapperType") == "track" || obj?.stringOrNull("trackId") != null
                    } as? JsonObject ?: (results.firstOrNull() as? JsonObject) ?: return@withContext null

                    val rawId = item.stringOrEmpty("trackId").ifBlank { cleanId }
                    val title = item.stringOrEmpty("trackName")
                    if (title.isBlank()) return@withContext null
                    val artist = item.stringOrEmpty("artistName").ifBlank { "Apple Music" }
                    val album = item.stringOrEmpty("collectionName")
                    val art = item.stringOrEmpty("artworkUrl100").upscaleArtwork()
                    val durationMs = item.intOrNull("trackTimeMillis")
                    val previewUrl = item.stringOrNull("previewUrl")
                    val externalUrl = item.stringOrNull("trackViewUrl")
                    val isExplicit = item.stringOrEmpty("trackExplicitness").equals("explicit", ignoreCase = true)

                    return@withContext UnifiedTrack(
                        id = "am_$rawId",
                        title = title,
                        artist = artist,
                        artists = listOf(artist),
                        album = album,
                        thumbnailUrl = art,
                        durationSeconds = durationMs?.let { (it / 1000).coerceAtLeast(1) },
                        provider = MusicSourceProvider.APPLE_MUSIC,
                        previewUrl = previewUrl,
                        externalUrl = externalUrl,
                        isExplicit = isExplicit
                    )
                }
            }
        } catch (e: Exception) {
            Timber.w(e, "Apple Music getTrackById error: $id")
        }
        return@withContext null
    }

    override suspend fun getPlaylistTracks(playlistId: String, limit: Int): List<UnifiedTrack> = withContext(Dispatchers.IO) {
        val cleanId = playlistId.removePrefix("am_pl_").removePrefix("am_").trim()
        val tracks = mutableListOf<UnifiedTrack>()

        if (cleanId.isNotBlank() && cleanId.all { it.isDigit() }) {
            try {
                val url = "https://itunes.apple.com/lookup?id=$cleanId&entity=song&country=vn"
                val request = UnifiedNetworkCore.buildGetRequest(url)
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val root = UnifiedNetworkCore.parseJsonObjectSafely(response.body?.string())
                        val results = root?.get("results") as? JsonArray
                        results?.forEach { item ->
                            val obj = item as? JsonObject ?: return@forEach
                            if (obj.stringOrEmpty("wrapperType") == "track") {
                                val trackId = obj.stringOrEmpty("trackId")
                                val trackName = obj.stringOrEmpty("trackName")
                                val artistName = obj.stringOrEmpty("artistName").ifBlank { "Apple Music" }
                                val albumName = obj.stringOrEmpty("collectionName")
                                val art = obj.stringOrEmpty("artworkUrl100").upscaleArtwork()
                                val durationSec = obj.intOrNull("trackTimeMillis")?.let { (it / 1000).coerceAtLeast(1) }
                                val previewUrl = obj.stringOrNull("previewUrl")
                                val externalUrl = obj.stringOrNull("trackViewUrl")
                                val isExplicit = obj.stringOrEmpty("trackExplicitness").equals("explicit", ignoreCase = true)

                                if (trackName.isNotBlank() && trackId.isNotBlank()) {
                                    tracks.add(
                                        UnifiedTrack(
                                            id = "am_$trackId",
                                            title = trackName,
                                            artist = artistName,
                                            artists = listOf(artistName),
                                            album = albumName,
                                            thumbnailUrl = art,
                                            durationSeconds = durationSec,
                                            provider = MusicSourceProvider.APPLE_MUSIC,
                                            previewUrl = previewUrl,
                                            externalUrl = externalUrl,
                                            isExplicit = isExplicit
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.w(e, "Apple Music getPlaylistTracks lookup error for $playlistId")
            }
        }

        if (tracks.isEmpty()) {
            val fallbackQuery = if (cleanId.isBlank() || cleanId.all { it.isDigit() }) {
                "Apple Music Top Hits"
            } else {
                cleanId
            }
            val searched = searchTracks(fallbackQuery, limit.coerceAtLeast(25))
            if (searched.isNotEmpty()) {
                tracks.addAll(searched)
            } else {
                tracks.addAll(getRecommendations(MusicCountry.VIETNAM, MusicCategory.ALL, limit.coerceAtLeast(25)))
            }
        }

        return@withContext tracks.take(limit.coerceAtLeast(1))
    }

    private fun getCategoryAppleSearchQuery(country: MusicCountry, category: MusicCategory): String {
        return when (category) {
            MusicCategory.ALL -> when (country) {
                MusicCountry.VIETNAM -> "vietnam top hits"
                MusicCountry.US -> "top hits billboard"
                MusicCountry.UK -> "uk top 40"
                MusicCountry.JAPAN -> "j-pop top hits"
                MusicCountry.KOREA -> "k-pop top hits"
                MusicCountry.FRANCE -> "france top hits"
            }
            MusicCategory.KIDS_FAMILY -> when (country) {
                MusicCountry.VIETNAM -> "nhạc thiếu nhi bé yêu"
                MusicCountry.JAPAN -> "nhạc thiếu nhi nhật bản"
                MusicCountry.KOREA -> "nhạc thiếu nhi hàn quốc"
                MusicCountry.FRANCE -> "comptines enfants français"
                else -> "kids songs disney nursery rhymes"
            }
            MusicCategory.VPOP -> when (country) {
                MusicCountry.VIETNAM -> "nhạc vpop trẻ"
                MusicCountry.US -> "v-pop hot hits us"
                else -> "vietnamese v-pop"
            }
            MusicCategory.POP_GLOBAL -> when (country) {
                MusicCountry.VIETNAM -> "nhạc pop hot"
                MusicCountry.US -> "top billboard hot pop"
                MusicCountry.UK -> "uk pop hits billboard"
                MusicCountry.JAPAN -> "japanese pop hits j-pop"
                MusicCountry.KOREA -> "korean pop hits k-pop"
                MusicCountry.FRANCE -> "variété française pop"
            }
            MusicCategory.KPOP_JPOP -> when (country) {
                MusicCountry.VIETNAM -> "kpop jpop hot hits việt nam"
                MusicCountry.JAPAN -> "j-pop hot hits top"
                MusicCountry.KOREA -> "k-pop hot hits top"
                else -> "k-pop and j-pop hits"
            }
            MusicCategory.CHILL_ACOUSTIC -> when (country) {
                MusicCountry.VIETNAM -> "acoustic lofi chill buồn tâm trạng việt nam"
                MusicCountry.JAPAN -> "acoustic lofi chill japan"
                MusicCountry.KOREA -> "acoustic lofi chill korea"
                MusicCountry.FRANCE -> "acoustic lofi chill france"
                else -> "us-uk chill acoustic lofi coffee"
            }
            MusicCategory.EDM_DANCE -> when (country) {
                MusicCountry.VIETNAM -> "nhạc edm remix vinahouse cực mạnh việt nam"
                MusicCountry.JAPAN -> "electronic dance edm japan"
                MusicCountry.KOREA -> "electronic dance edm korea"
                MusicCountry.FRANCE -> "club french touch dance house"
                else -> "dance edm club hits ultra remix"
            }
        }
    }
}

// ============================================================================
// 5. UNIFIED MUSIC REPOSITORY
// ============================================================================

/**
 * Unified Music Repository - The central coordinator bridging the App Core / UI Layer
 * and the specific streaming Adapters (Apple Music Adapter & YouTube Music resolution).
 */
@Singleton
class UnifiedMusicRepository @Inject constructor(
    val appleMusicAdapter: AppleMusicAdapter,
) {
    private val client: OkHttpClient
        get() = UnifiedNetworkCore.httpClient

    companion object {
        private const val MAX_RESOLVED_CACHE_SIZE = 500
        private val resolvedIdCache = ConcurrentHashMap<String, String>()
    }

    /**
     * Map of available adapters keyed by [MusicSourceProvider].
     */
    val adapters: Map<MusicSourceProvider, UnifiedMusicInterface> = mapOf(
        MusicSourceProvider.APPLE_MUSIC to appleMusicAdapter
    )

    /**
     * Search tracks across Apple Music adapter.
     */
    suspend fun searchTracks(
        query: String,
        provider: MusicSourceProvider = MusicSourceProvider.ALL,
        limit: Int = 25
    ): List<UnifiedTrack> = coroutineScope {
        if (query.isBlank()) return@coroutineScope emptyList()
        val adapter = adapters[provider] ?: appleMusicAdapter
        adapter.searchTracks(query, limit)
    }

    /**
     * Search artists across Apple Music adapter.
     */
    suspend fun searchArtists(
        query: String,
        provider: MusicSourceProvider = MusicSourceProvider.ALL,
        limit: Int = 15
    ): List<UnifiedArtist> = coroutineScope {
        if (query.isBlank()) return@coroutineScope emptyList()
        val adapter = adapters[provider] ?: appleMusicAdapter
        adapter.searchArtists(query, limit)
    }

    /**
     * Search playlists across Apple Music adapter.
     */
    suspend fun searchPlaylists(
        query: String,
        provider: MusicSourceProvider = MusicSourceProvider.ALL,
        limit: Int = 15
    ): List<UnifiedPlaylist> = coroutineScope {
        if (query.isBlank()) return@coroutineScope emptyList()
        val adapter = adapters[provider] ?: appleMusicAdapter
        adapter.searchPlaylists(query, limit)
    }

    /**
     * Fetches track recommendations for country & category from Apple Music adapter.
     */
    suspend fun getRecommendations(
        country: MusicCountry = MusicCountry.VIETNAM,
        category: MusicCategory = MusicCategory.ALL,
        provider: MusicSourceProvider = MusicSourceProvider.APPLE_MUSIC,
        limit: Int = 30
    ): List<UnifiedTrack> {
        val adapter = adapters[provider] ?: appleMusicAdapter
        return adapter.getRecommendations(country, category, limit)
    }

    /**
     * Fetches featured playlists for country & category.
     */
    suspend fun getFeaturedPlaylists(
        country: MusicCountry = MusicCountry.VIETNAM,
        category: MusicCategory = MusicCategory.ALL,
        provider: MusicSourceProvider = MusicSourceProvider.APPLE_MUSIC,
        limit: Int = 15
    ): List<UnifiedPlaylist> {
        val adapter = adapters[provider] ?: appleMusicAdapter
        return adapter.getFeaturedPlaylists(country, category, limit)
    }

    /**
     * Fetches top artists for country & category.
     */
    suspend fun getTopArtists(
        country: MusicCountry = MusicCountry.VIETNAM,
        category: MusicCategory = MusicCategory.ALL,
        provider: MusicSourceProvider = MusicSourceProvider.APPLE_MUSIC,
        limit: Int = 15
    ): List<UnifiedArtist> {
        val adapter = adapters[provider] ?: appleMusicAdapter
        return adapter.getTopArtists(country, category, limit)
    }

    /**
     * Resolves an external Unified Track to a playable YouTube videoId with concurrent thread-safe cache.
     */
    suspend fun resolveToPlayableVideoId(title: String, artist: String): String? = withContext(Dispatchers.IO) {
        val cleanTitle = title.trim()
        val cleanArtist = artist.trim()
        if (cleanTitle.isBlank()) return@withContext null

        val cacheKey = "${cleanTitle.lowercase()}###${cleanArtist.lowercase()}"
        resolvedIdCache[cacheKey]?.let { return@withContext it }

        try {
            val query = if (cleanArtist.isNotBlank()) "$cleanTitle $cleanArtist" else cleanTitle
            val result = YouTube.search(query, YouTube.SearchFilter.FILTER_SONG).getOrNull()
            val song = result?.items?.filterIsInstance<SongItem>()?.firstOrNull()
            if (song != null && song.id.isNotBlank()) {
                cacheResolvedId(cacheKey, song.id)
                return@withContext song.id
            }

            val fallbackResult = YouTube.searchSummary(query).getOrNull()
            val fallbackSong = fallbackResult?.summaries
                ?.flatMap { it.items }
                ?.filterIsInstance<SongItem>()
                ?.firstOrNull()
            if (fallbackSong != null && fallbackSong.id.isNotBlank()) {
                cacheResolvedId(cacheKey, fallbackSong.id)
                return@withContext fallbackSong.id
            }
            return@withContext null
        } catch (e: Exception) {
            Timber.e(e, "Error resolving track: $cleanTitle - $cleanArtist")
            return@withContext null
        }
    }

    private fun cacheResolvedId(key: String, videoId: String) {
        if (resolvedIdCache.size >= MAX_RESOLVED_CACHE_SIZE) {
            resolvedIdCache.keys.firstOrNull()?.let { resolvedIdCache.remove(it) }
        }
        resolvedIdCache[key] = videoId
    }

    /**
     * Fetches real user comments for a song/video.
     */
    suspend fun fetchCommentsForVideo(videoId: String): List<UserComment> = withContext(Dispatchers.IO) {
        val cleanVideoId = videoId.trim()
        if (cleanVideoId.isBlank() || cleanVideoId.startsWith("am_")) {
            return@withContext emptyList()
        }

        val comments = mutableListOf<UserComment>()
        try {
            val requestBody = buildJsonObject {
                putJsonObject("context") {
                    putJsonObject("client") {
                        put("clientName", "WEB")
                        put("clientVersion", "2.20240101.00.00")
                        put("hl", "vi")
                        put("gl", "VN")
                    }
                }
                put("videoId", cleanVideoId)
            }.toString().toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url("https://www.youtube.com/youtubei/v1/next")
                .post(requestBody)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val root = UnifiedNetworkCore.parseJsonObjectSafely(response.body?.string()) ?: return@use

                    fun extractComments(element: JsonElement) {
                        when (element) {
                            is JsonObject -> {
                                val renderer = element["commentRenderer"] as? JsonObject
                                if (renderer != null) {
                                    val id = renderer.stringOrEmpty("commentId")
                                    val authorObj = renderer["authorText"] as? JsonObject
                                    val authorText = authorObj?.stringOrNull("simpleText")
                                        ?: (authorObj?.get("runs") as? JsonArray)
                                            ?.firstOrNull()
                                            ?.let { (it as? JsonObject)?.stringOrNull("text") }
                                        ?: "User"

                                    val contentObj = renderer["contentText"] as? JsonObject
                                    val contentText = (contentObj?.get("runs") as? JsonArray)
                                        ?.joinToString("") { (it as? JsonObject)?.stringOrEmpty("text") ?: "" }
                                        ?: contentObj?.stringOrEmpty("simpleText")
                                        ?: ""

                                    val publishedObj = renderer["publishedTimeText"] as? JsonObject
                                    val timeText = (publishedObj?.get("runs") as? JsonArray)
                                        ?.firstOrNull()
                                        ?.let { (it as? JsonObject)?.stringOrEmpty("text") }
                                        ?: publishedObj?.stringOrEmpty("simpleText")
                                        ?: ""

                                    val voteObj = renderer["voteCount"] as? JsonObject
                                    val voteCount = voteObj?.stringOrEmpty("simpleText")
                                        ?: (voteObj?.get("runs") as? JsonArray)
                                            ?.firstOrNull()
                                            ?.let { (it as? JsonObject)?.stringOrEmpty("text") }
                                        ?: ""

                                    val thumbObj = renderer["authorThumbnail"] as? JsonObject
                                    val avatar = (thumbObj?.get("thumbnails") as? JsonArray)
                                        ?.lastOrNull()
                                        ?.let { (it as? JsonObject)?.stringOrEmpty("url") }
                                        ?: ""

                                    if (contentText.isNotBlank()) {
                                        comments.add(
                                            UserComment(
                                                id = id.ifBlank { "${authorText}_${contentText.hashCode()}" },
                                                authorName = authorText,
                                                authorAvatarUrl = avatar,
                                                content = contentText,
                                                publishedTime = timeText,
                                                likeCount = voteCount
                                            )
                                        )
                                    }
                                }
                                element.values.forEach { extractComments(it) }
                            }
                            is JsonArray -> {
                                element.forEach { extractComments(it) }
                            }
                            else -> {}
                        }
                    }
                    extractComments(root)
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to fetch comments for video $cleanVideoId")
        }

        return@withContext comments.distinctBy { it.id }
    }
}
