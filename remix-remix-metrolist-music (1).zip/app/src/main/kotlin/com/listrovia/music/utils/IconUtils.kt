package com.listrovia.music.utils

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log

object IconUtils {
    fun setIcon(context: Context, enabled: Boolean) {
        try {
            val pm = context.packageManager
            val dynamic = ComponentName(context, "com.listrovia.music.MainActivityAlias")
            val static = ComponentName(context, "com.listrovia.music.MainActivityStatic")

            pm.setComponentEnabledSetting(
                dynamic,
                if (enabled) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
            pm.setComponentEnabledSetting(
                static,
                if (enabled) PackageManager.COMPONENT_ENABLED_STATE_DISABLED else PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
            )
        } catch (e: Exception) {
            Log.e("IconUtils", "Failed to update icon component setting: ${e.message}")
        }
    }
}

