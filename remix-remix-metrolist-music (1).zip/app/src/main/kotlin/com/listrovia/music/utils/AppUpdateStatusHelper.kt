/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.utils

import android.content.Context
import androidx.datastore.preferences.core.edit
import com.listrovia.music.BuildConfig
import com.listrovia.music.R
import com.listrovia.music.constants.HasDetectedUpdateKey
import com.listrovia.music.constants.LastDetectedDownloadUrlKey
import com.listrovia.music.constants.LastDetectedReleaseNotesKey
import com.listrovia.music.constants.LastUpdateCheckSourceKey
import com.listrovia.music.constants.LastUpdateCheckTimeKey
import com.listrovia.music.constants.LatestDetectedVersionKey
import com.listrovia.music.utils.dataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

data class AppUpdateStatus(
    val isUpToDate: Boolean,
    val hasDetectedUpdate: Boolean,
    val latestVersion: String,
    val lastCheckedTimeMs: Long,
    val source: String,
    val downloadUrl: String?,
    val releaseNotes: String?,
)

object AppUpdateStatusHelper {

    const val SOURCE_BACKGROUND_WORKER = "background_worker"
    const val SOURCE_APP_LAUNCH = "app_launch"
    const val SOURCE_MANUAL = "manual"
    const val SOURCE_SETTINGS = "updater_service"

    /**
     * Observe the latest reactive update status from persistent DataStore.
     */
    fun observeUpdateStatus(context: Context): Flow<AppUpdateStatus> {
        return context.dataStore.data.map { prefs ->
            val hasDetectedUpdate = prefs[HasDetectedUpdateKey] ?: false
            val latestVersion = prefs[LatestDetectedVersionKey] ?: BuildConfig.VERSION_NAME
            val lastCheckedTimeMs = prefs[LastUpdateCheckTimeKey] ?: 0L
            val source = prefs[LastUpdateCheckSourceKey] ?: SOURCE_BACKGROUND_WORKER
            val downloadUrl = prefs[LastDetectedDownloadUrlKey]
            val releaseNotes = prefs[LastDetectedReleaseNotesKey]

            // If latest version is <= current version, it is up to date
            val isNewer = Updater.isUpdateAvailable(BuildConfig.VERSION_NAME, latestVersion)
            val effectiveHasUpdate = hasDetectedUpdate && isNewer

            AppUpdateStatus(
                isUpToDate = !effectiveHasUpdate,
                hasDetectedUpdate = effectiveHasUpdate,
                latestVersion = latestVersion,
                lastCheckedTimeMs = lastCheckedTimeMs,
                source = source,
                downloadUrl = downloadUrl,
                releaseNotes = releaseNotes
            )
        }
    }

    /**
     * Persist the update check result from background worker, manual check, or app launch.
     */
    suspend fun recordUpdateCheck(
        context: Context,
        hasUpdate: Boolean,
        latestVersion: String,
        source: String,
        downloadUrl: String? = null,
        releaseNotes: String? = null,
        checkTimeMs: Long = System.currentTimeMillis()
    ) = withContext(Dispatchers.IO) {
        try {
            context.dataStore.edit { prefs ->
                val isNewer = Updater.isUpdateAvailable(BuildConfig.VERSION_NAME, latestVersion)
                val effectiveHasUpdate = hasUpdate && isNewer

                prefs[HasDetectedUpdateKey] = effectiveHasUpdate
                prefs[LatestDetectedVersionKey] = latestVersion
                prefs[LastUpdateCheckTimeKey] = checkTimeMs
                prefs[LastUpdateCheckSourceKey] = source
                if (downloadUrl != null) {
                    prefs[LastDetectedDownloadUrlKey] = downloadUrl
                }
                if (releaseNotes != null) {
                    prefs[LastDetectedReleaseNotesKey] = releaseNotes
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Formats the last checked relative timestamp.
     */
    fun formatLastCheckedRelative(context: Context, timeMs: Long): String {
        if (timeMs <= 0L) return context.getString(R.string.updater_status_never_checked)

        val diffMs = System.currentTimeMillis() - timeMs
        if (diffMs < 60_000L) {
            return context.getString(R.string.updater_status_checked_just_now)
        }

        val minutes = TimeUnit.MILLISECONDS.toMinutes(diffMs)
        if (minutes < 60) {
            return context.getString(R.string.updater_status_checked_ago, "${minutes}m")
        }

        val hours = TimeUnit.MILLISECONDS.toHours(diffMs)
        if (hours < 24) {
            return context.getString(R.string.updater_status_checked_ago, "${hours}h")
        }

        val days = TimeUnit.MILLISECONDS.toDays(diffMs)
        return context.getString(R.string.updater_status_checked_ago, "${days}d")
    }

    /**
     * Formats the human-readable source of the update check.
     */
    fun getSourceLabel(context: Context, source: String): String {
        return when (source) {
            SOURCE_BACKGROUND_WORKER -> context.getString(R.string.updater_status_by_background_worker)
            SOURCE_APP_LAUNCH -> context.getString(R.string.updater_status_by_app_launch)
            SOURCE_MANUAL, SOURCE_SETTINGS -> context.getString(R.string.updater_status_by_manual)
            else -> source
        }
    }
}
