package com.listrovia.music.utils

import android.content.ContentValues
import android.content.Context
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import com.listrovia.innertube.YouTube
import com.listrovia.music.R
import com.listrovia.music.constants.AudioQuality
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import timber.log.Timber
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

object AudioExporter {
    private const val TAG = "AudioExporter"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val client = OkHttpClient.Builder()
        .proxy(YouTube.proxy)
        .build()

    fun sanitizeFilename(name: String): String {
        return name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
    }

    /**
     * Export a song directly as MP3/Audio file into public device storage (Music/Metrolist).
     */
    fun exportSong(
        context: Context,
        songId: String,
        title: String,
        artist: String,
        album: String? = null,
        duration: Long? = null,
        artworkUrl: String? = null,
        onComplete: ((Boolean, String?) -> Unit)? = null,
    ) {
        val appContext = context.applicationContext
        Toast.makeText(appContext, R.string.exporting_audio, Toast.LENGTH_SHORT).show()

        scope.launch {
            try {
                val cleanTitle = sanitizeFilename(title.ifEmpty { "Song_$songId" })
                val cleanArtist = sanitizeFilename(artist.ifEmpty { "Unknown Artist" })
                val filename = "$cleanArtist - $cleanTitle.mp3"

                val connectivityManager =
                    appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

                val playbackResult = YTPlayerUtils.playerResponseForPlayback(
                    videoId = songId,
                    playlistId = null,
                    audioQuality = AudioQuality.HIGH,
                    connectivityManager = connectivityManager,
                )

                val playbackData = playbackResult.getOrNull()
                    ?: throw IOException("Could not resolve stream URL for $songId")

                val streamUrl = playbackData.streamUrl
                if (streamUrl.isBlank()) {
                    throw IOException("Resolved stream URL is empty")
                }

                val request = Request.Builder()
                    .url(streamUrl)
                    .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                    .build()

                val response = client.newCall(request).execute()
                if (!response.isSuccessful || response.body == null) {
                    throw IOException("Failed to download audio stream: HTTP ${response.code}")
                }

                val body = response.body!!
                val success = saveAudioToMediaStore(
                    context = appContext,
                    filename = filename,
                    title = cleanTitle,
                    artist = cleanArtist,
                    album = album,
                    duration = duration,
                    inputStream = body.byteStream(),
                )

                if (success) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            appContext,
                            appContext.getString(R.string.exported_audio_success, title),
                            Toast.LENGTH_LONG,
                        ).show()
                        onComplete?.invoke(true, filename)
                    }
                } else {
                    throw IOException("Failed to save audio file to MediaStore")
                }
            } catch (e: Exception) {
                Timber.tag(TAG).e(e, "Audio export failed for $songId")
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        appContext,
                        R.string.exported_audio_failed,
                        Toast.LENGTH_SHORT,
                    ).show()
                    onComplete?.invoke(false, e.message)
                }
            }
        }
    }

    private fun saveAudioToMediaStore(
        context: Context,
        filename: String,
        title: String,
        artist: String,
        album: String?,
        duration: Long?,
        inputStream: java.io.InputStream,
    ): Boolean {
        return try {
            val resolver = context.contentResolver
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val relativePath = "${Environment.DIRECTORY_MUSIC}/Metrolist"
                val values = ContentValues().apply {
                    put(MediaStore.Audio.Media.DISPLAY_NAME, filename)
                    put(MediaStore.Audio.Media.TITLE, title)
                    put(MediaStore.Audio.Media.ARTIST, artist)
                    if (!album.isNullOrBlank()) {
                        put(MediaStore.Audio.Media.ALBUM, album)
                    }
                    if (duration != null && duration > 0) {
                        put(MediaStore.Audio.Media.DURATION, duration * 1000L)
                    }
                    put(MediaStore.Audio.Media.MIME_TYPE, "audio/mpeg")
                    put(MediaStore.Audio.Media.RELATIVE_PATH, relativePath)
                    put(MediaStore.Audio.Media.IS_PENDING, 1)
                }

                val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                val uri: Uri = resolver.insert(collection, values) ?: return false

                resolver.openOutputStream(uri)?.use { outStream ->
                    inputStream.use { inStream ->
                        inStream.copyTo(outStream)
                    }
                } ?: return false

                val completeValues = ContentValues().apply {
                    put(MediaStore.Audio.Media.IS_PENDING, 0)
                }
                resolver.update(uri, completeValues, null, null)
                true
            } else {
                val musicDir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC),
                    "Metrolist",
                )
                if (!musicDir.exists()) {
                    musicDir.mkdirs()
                }
                val destFile = File(musicDir, filename)
                FileOutputStream(destFile).use { outStream ->
                    inputStream.use { inStream ->
                        inStream.copyTo(outStream)
                    }
                }
                true
            }
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Error saving audio to MediaStore")
            false
        }
    }
}
