/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.net.toUri
import androidx.datastore.preferences.core.edit
import com.listrovia.music.BuildConfig
import com.listrovia.music.MainActivity
import com.listrovia.music.R
import com.listrovia.music.constants.LastKnownInstalledVersionKey
import com.listrovia.music.constants.UpdateInstalledNotificationEnabledKey
import com.listrovia.music.constants.UpdateNotificationSoundEnabledKey
import com.listrovia.music.constants.UpdateNotificationSoundTypeKey
import com.listrovia.music.constants.UpdateNotificationsEnabledKey
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import timber.log.Timber

enum class UpdateSoundType(val key: String, val titleRes: Int, val descRes: Int) {
    DEFAULT("DEFAULT", R.string.updater_sound_type_default, R.string.updater_sound_type_default_desc),
    CHIME("CHIME", R.string.updater_sound_type_chime, R.string.updater_sound_type_chime_desc),
    SUBTLE("SUBTLE", R.string.updater_sound_type_subtle, R.string.updater_sound_type_subtle_desc),
    SILENT("SILENT", R.string.updater_sound_type_silent, R.string.updater_sound_type_silent_desc)
}

object UpdateNotificationHelper {
    const val CHANNEL_UPDATES = "updates"
    const val CHANNEL_INSTALL_ALERTS = "update_install_alerts"

    const val NOTIFICATION_ID_UPDATE_AVAILABLE = 1001
    const val NOTIFICATION_ID_UPDATE_INSTALLED = 1002
    const val NOTIFICATION_ID_TEST_ALERT = 1003

    /**
     * Create and configure notification channels for app updates and install alerts.
     */
    fun createNotificationChannels(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java) ?: return

        val audioAttributes = AudioAttributes.Builder()
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .build()

        val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        // 1. General Update Notifications Channel
        val updatesChannel = NotificationChannel(
            CHANNEL_UPDATES,
            context.getString(R.string.update_channel_name),
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = context.getString(R.string.update_channel_desc)
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 200, 100, 200)
            setSound(defaultSoundUri, audioAttributes)
        }
        nm.createNotificationChannel(updatesChannel)

        // 2. High-priority Update Detection & Installation Alerts Channel
        val installAlertsChannel = NotificationChannel(
            CHANNEL_INSTALL_ALERTS,
            context.getString(R.string.update_install_alerts_channel_name),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = context.getString(R.string.update_install_alerts_channel_desc)
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 250, 150, 250)
            setSound(defaultSoundUri, audioAttributes)
            setShowBadge(true)
        }
        nm.createNotificationChannel(installAlertsChannel)
    }

    /**
     * Play a quick audible preview of the selected sound preference.
     */
    fun playSoundPreview(context: Context, soundType: UpdateSoundType) {
        try {
            when (soundType) {
                UpdateSoundType.DEFAULT -> {
                    val defaultUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                    val ringtone = RingtoneManager.getRingtone(context, defaultUri)
                    ringtone?.play()
                }
                UpdateSoundType.CHIME -> {
                    val toneGen = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90)
                    toneGen.startTone(ToneGenerator.TONE_PROP_BEEP2, 350)
                }
                UpdateSoundType.SUBTLE -> {
                    val toneGen = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 65)
                    toneGen.startTone(ToneGenerator.TONE_PROP_BEEP, 160)
                    triggerVibration(context, 100)
                }
                UpdateSoundType.SILENT -> {
                    triggerVibration(context, 80)
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Error playing sound preview: ${soundType.name}")
        }
    }

    private fun triggerVibration(context: Context, millis: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(millis, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                vibrator?.vibrate(
                    VibrationEffect.createOneShot(millis, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            }
        } catch (e: Exception) {
            Timber.w(e, "Vibration failed")
        }
    }

    /**
     * Open the system notification channel settings directly.
     */
    fun openNotificationChannelSettings(context: Context, channelId: String = CHANNEL_INSTALL_ALERTS) {
        try {
            val intent = Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                putExtra(Settings.EXTRA_CHANNEL_ID, channelId)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // Fallback to app notification settings
            try {
                val appIntent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                    putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(appIntent)
            } catch (ex: Exception) {
                Timber.e(ex, "Failed to open notification settings")
            }
        }
    }

    /**
     * Post a notification when a new update is detected by the background worker.
     */
    fun notifyUpdateAvailable(
        context: Context,
        releaseInfo: ReleaseInfo,
        soundEnabled: Boolean = true,
        soundType: UpdateSoundType = UpdateSoundType.DEFAULT
    ) {
        try {
            val downloadUrl = Updater.getDownloadUrlForCurrentVariant(releaseInfo)
            val intent = if (!downloadUrl.isNullOrBlank()) {
                Intent(Intent.ACTION_VIEW, downloadUrl.toUri())
            } else {
                Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                }
            }

            val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            val pendingIntent = PendingIntent.getActivity(context, NOTIFICATION_ID_UPDATE_AVAILABLE, intent, flags)

            val builder = NotificationCompat.Builder(context, CHANNEL_INSTALL_ALERTS)
                .setSmallIcon(R.drawable.update)
                .setContentTitle(context.getString(R.string.update_available_title))
                .setContentText(releaseInfo.versionName)
                .setStyle(
                    NotificationCompat.BigTextStyle()
                        .setBigContentTitle(context.getString(R.string.update_detected_background_title, releaseInfo.versionName))
                        .bigText(
                            if (releaseInfo.description.isNotBlank()) {
                                releaseInfo.description.lines().take(4).joinToString("\n")
                            } else {
                                context.getString(R.string.update_detected_background_desc, releaseInfo.versionName)
                            }
                        )
                )
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)

            applySoundAndVibration(builder, soundEnabled, soundType)

            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID_UPDATE_AVAILABLE, builder.build())
            Timber.d("UpdateNotificationHelper: Posted update available alert for ${releaseInfo.versionName}")
        } catch (e: SecurityException) {
            Timber.w(e, "UpdateNotificationHelper: Missing POST_NOTIFICATIONS permission")
        } catch (e: Exception) {
            Timber.e(e, "UpdateNotificationHelper: Error showing update available notification")
        }
    }

    /**
     * Post a notification when a new update has been successfully installed.
     */
    fun notifyUpdateInstalled(
        context: Context,
        newVersion: String,
        soundEnabled: Boolean = true,
        soundType: UpdateSoundType = UpdateSoundType.DEFAULT
    ) {
        try {
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            val pendingIntent = PendingIntent.getActivity(context, NOTIFICATION_ID_UPDATE_INSTALLED, intent, flags)

            val builder = NotificationCompat.Builder(context, CHANNEL_INSTALL_ALERTS)
                .setSmallIcon(R.drawable.check)
                .setContentTitle(context.getString(R.string.update_installed_title))
                .setContentText(context.getString(R.string.update_installed_desc, newVersion))
                .setStyle(
                    NotificationCompat.BigTextStyle()
                        .setBigContentTitle(context.getString(R.string.update_installed_title))
                        .bigText(context.getString(R.string.update_installed_desc, newVersion))
                )
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)

            applySoundAndVibration(builder, soundEnabled, soundType)

            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID_UPDATE_INSTALLED, builder.build())
            Timber.d("UpdateNotificationHelper: Posted update installed alert for $newVersion")
        } catch (e: SecurityException) {
            Timber.w(e, "UpdateNotificationHelper: Missing POST_NOTIFICATIONS permission")
        } catch (e: Exception) {
            Timber.e(e, "UpdateNotificationHelper: Error showing update installed notification")
        }
    }

    /**
     * Trigger a test notification with current sound settings to verify channel configuration.
     */
    fun sendTestNotification(
        context: Context,
        isInstalledTest: Boolean = false,
        soundEnabled: Boolean = true,
        soundType: UpdateSoundType = UpdateSoundType.DEFAULT
    ) {
        try {
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            val pendingIntent = PendingIntent.getActivity(context, NOTIFICATION_ID_TEST_ALERT, intent, flags)

            val title = if (isInstalledTest) {
                context.getString(R.string.update_installed_title)
            } else {
                context.getString(R.string.update_detected_background_title, "v${BuildConfig.VERSION_NAME}")
            }

            val text = if (isInstalledTest) {
                context.getString(R.string.update_installed_desc, BuildConfig.VERSION_NAME)
            } else {
                context.getString(R.string.update_detected_background_desc, "v${BuildConfig.VERSION_NAME}")
            }

            val builder = NotificationCompat.Builder(context, CHANNEL_INSTALL_ALERTS)
                .setSmallIcon(if (isInstalledTest) R.drawable.check else R.drawable.update)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)

            applySoundAndVibration(builder, soundEnabled, soundType)

            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID_TEST_ALERT, builder.build())
            playSoundPreview(context, soundType)
        } catch (e: Exception) {
            Timber.e(e, "Failed to send test notification")
        }
    }

    private fun applySoundAndVibration(
        builder: NotificationCompat.Builder,
        soundEnabled: Boolean,
        soundType: UpdateSoundType
    ) {
        if (!soundEnabled || soundType == UpdateSoundType.SILENT) {
            builder.setSilent(true)
        } else {
            builder.setSilent(false)
            val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            builder.setSound(defaultSoundUri)
            builder.setDefaults(NotificationCompat.DEFAULT_VIBRATE or NotificationCompat.DEFAULT_LIGHTS)
        }
    }

    /**
     * Checks if the app was updated from a previous version, and alerts the user if enabled.
     */
    suspend fun checkAndNotifyAppUpdated(context: Context) {
        try {
            val prefs = context.dataStore.data.first()
            val lastVersion = prefs[LastKnownInstalledVersionKey]
            val currentVersion = BuildConfig.VERSION_NAME

            if (lastVersion == null || lastVersion.isBlank()) {
                // First run on this installation: record version
                context.dataStore.edit { settings ->
                    settings[LastKnownInstalledVersionKey] = currentVersion
                }
                return
            }

            if (lastVersion != currentVersion) {
                // Version changed! User successfully installed a new update
                val isInstalledNotifEnabled = prefs[UpdateInstalledNotificationEnabledKey] ?: true
                val isSoundEnabled = prefs[UpdateNotificationSoundEnabledKey] ?: true
                val soundTypeKey = prefs[UpdateNotificationSoundTypeKey] ?: UpdateSoundType.DEFAULT.key
                val soundType = UpdateSoundType.values().firstOrNull { it.key == soundTypeKey } ?: UpdateSoundType.DEFAULT

                if (isInstalledNotifEnabled) {
                    notifyUpdateInstalled(
                        context = context,
                        newVersion = currentVersion,
                        soundEnabled = isSoundEnabled,
                        soundType = soundType
                    )
                }

                // Update stored version
                context.dataStore.edit { settings ->
                    settings[LastKnownInstalledVersionKey] = currentVersion
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Error checking installed version change")
        }
    }
}
