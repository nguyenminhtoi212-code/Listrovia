package androidx.compose.ui.platform

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import java.util.Locale
import android.content.res.Resources

object LocalLocale {
    val current: PlatformLocale
        @Composable
        @ReadOnlyComposable
        get() = PlatformLocale()
}

class PlatformLocale {
    val platformLocale: Locale
        get() = Locale.getDefault()
}

object LocalResources {
    val current: Resources
        @Composable
        @ReadOnlyComposable
        get() = androidx.compose.ui.platform.LocalContext.current.resources
}

object LocalClipboard {
    val current: ClipboardManager
        @Composable
        @ReadOnlyComposable
        get() = androidx.compose.ui.platform.LocalClipboardManager.current
}
