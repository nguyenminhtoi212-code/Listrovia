/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 * 
 * Nickname validation and security filter to ensure users use aliases/nicknames
 * and block sensitive/offensive or real-name identifiers.
 */

package com.listrovia.music.utils

object NicknameValidator {
    private val sensitiveKeywords = listOf(
        "admin", "administrator", "root", "system", "moderator",
        "realname", "tênthật", "hoten", "hovaten", "fuck", "shit",
        "sex", "porn", "hack", "scam", "spam", "support", "official"
    )

    fun isValidNickname(rawName: String): Boolean {
        val name = rawName.trim().lowercase()
        if (name.length < 2 || name.length > 30) return false
        
        val allowed = name.all { it.isLetterOrDigit() || it == ' ' || it == '_' || it == '-' }
        if (!allowed) return false

        for (keyword in sensitiveKeywords) {
            if (name.contains(keyword)) return false
        }
        return true
    }
}
