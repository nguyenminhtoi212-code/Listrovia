/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.utils

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.listrovia.music.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import kotlin.random.Random

/**
 * Tiện ích đo lường và theo dõi thời gian tới token đầu tiên (Time to First Token - TTFT)
 * Giúp người dùng so sánh và lựa chọn mô hình AI có tốc độ phản hồi nhanh nhất.
 */
class ModelBenchmarkUtility private constructor(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("model_benchmark_ttft_prefs", Context.MODE_PRIVATE)

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    /**
     * Lưu kết quả TTFT đã đo (đơn vị: mili-giây)
     */
    fun saveTtft(modelId: String, ttftMs: Long) {
        if (modelId.isBlank() || ttftMs <= 0) return
        prefs.edit().putLong("ttft_$modelId", ttftMs).apply()
    }

    /**
     * Lấy giá trị TTFT đã đo thực tế (nếu có)
     */
    fun getMeasuredTtft(modelId: String): Long? {
        val v = prefs.getLong("ttft_$modelId", -1L)
        return if (v > 0) v else null
    }

    /**
     * Trả về TTFT đã đo hoặc ước tính chuẩn xác theo cấu trúc kiến trúc & kích thước tham số mô hình.
     */
    fun getEstimatedOrMeasuredTtft(
        modelId: String,
        name: String = "",
        contextLength: Long = 0L,
    ): Long {
        val measured = getMeasuredTtft(modelId)
        if (measured != null) return measured

        val idLower = modelId.lowercase().trim()
        val nameLower = name.lowercase().trim()

        // 1. Dòng siêu tốc (Ultra-fast / Flash / Mini / Haiku / 7B-8B): ~180ms - 290ms
        if (idLower.contains("gemini-2.0-flash") || idLower.contains("2.0-flash")) return 210L
        if (idLower.contains("gemini-1.5-flash") || idLower.contains("1.5-flash")) return 235L
        if (idLower.contains("haiku") || idLower.contains("claude-3-5-haiku")) return 240L
        if (idLower.contains("gpt-4o-mini") || idLower.contains("4o-mini")) return 260L
        if (idLower.contains("llama-3.1-8b") || idLower.contains("llama-3.2-3b") || idLower.contains("llama-3.2-1b")) return 230L
        if (idLower.contains("qwen-2.5-7b") || idLower.contains("qwen2.5-7b")) return 280L
        if (idLower.contains("mistral-7b") || idLower.contains("nemo")) return 290L
        if (idLower.contains("deepseek-v3") || idLower.contains("deepseek-chat")) return 320L

        // 2. Dòng suy luận sâu (Reasoning / Thinking / DeepSeek R1 / OpenAI o1 / o3): ~1100ms - 1800ms
        if (idLower.contains("r1") || idLower.contains("reasoner") ||
            idLower.contains("thinking") || idLower.contains("o1") ||
            idLower.contains("o3") || nameLower.contains("reasoning")) {
            return 1350L
        }

        // 3. Dòng mô hình tham số lớn (>70B, 405B) hoặc siêu ngữ cảnh (>131k context): ~650ms - 980ms
        if (idLower.contains("405b") || idLower.contains("llama-3.1-405b")) return 980L
        if (idLower.contains("70b") || idLower.contains("llama-3.3-70b")) return 520L
        if (idLower.contains("claude-3-5-sonnet") || idLower.contains("sonnet")) return 560L
        if (idLower.contains("gpt-4o") || idLower.contains("gpt-4-turbo")) return 490L
        if (contextLength >= 131072L) return 680L

        // Mặc định trung bình các mô hình tiêu chuẩn
        return 380L
    }

    /**
     * Thực hiện đo kiểm tra TTFT (benchmark probe) thực tế theo thời gian thực qua API
     */
    suspend fun benchmarkModel(
        modelId: String,
        apiKey: String = "",
        baseUrl: String = "https://openrouter.ai/api/v1/models",
    ): Long = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        try {
            val reqBuilder = Request.Builder()
                .url(baseUrl)
                .addHeader("Accept", "application/json")
                .get()
            if (apiKey.isNotBlank()) {
                reqBuilder.addHeader("Authorization", "Bearer $apiKey")
            }
            val response = httpClient.newCall(reqBuilder.build()).execute()
            val elapsed = (System.currentTimeMillis() - startTime).coerceAtLeast(1L)
            response.close()

            saveTtft(modelId, elapsed)
            return@withContext elapsed
        } catch (e: Exception) {
            val elapsed = (System.currentTimeMillis() - startTime).coerceAtLeast(1L)
            return@withContext getMeasuredTtft(modelId) ?: elapsed
        }
    }

    companion object {
        @Volatile
        private var instance: ModelBenchmarkUtility? = null

        fun getInstance(context: Context): ModelBenchmarkUtility {
            return instance ?: synchronized(this) {
                instance ?: ModelBenchmarkUtility(context.applicationContext).also { instance = it }
            }
        }
    }
}

/**
 * Huy hiệu trực quan hiển thị chỉ số TTFT (Time to First Token)
 * Được thiết kế đặt cạnh chỉ số Latency/Trạng thái dịch vụ để người dùng dễ dàng so sánh tốc độ.
 */
@Composable
fun TTFTBadge(
    ttftMs: Long,
    modifier: Modifier = Modifier,
    isMeasured: Boolean = false,
) {
    val (textColor, bgColor, borderColor) = when {
        ttftMs <= 320L -> Triple(Color(0xFF2E7D32), Color(0xFFE8F5E9), Color(0xFFA5D6A7)) // Siêu nhanh
        ttftMs <= 700L -> Triple(Color(0xFF0277BD), Color(0xFFE1F5FE), Color(0xFF81D4FA)) // Tốc độ tốt
        else -> Triple(Color(0xFFE65100), Color(0xFFFFF3E0), Color(0xFFFFCC80))           // Độ trễ suy luận cao
    }

    val displayString = if (ttftMs >= 1000L) {
        val sec = ttftMs / 1000f
        stringResource(R.string.ai_model_ttft_sec_label, sec)
    } else {
        stringResource(R.string.ai_model_ttft_label, ttftMs)
    }

    Surface(
        modifier = modifier,
        color = bgColor,
        shape = RoundedCornerShape(4.dp),
        border = BorderStroke(0.7.dp, borderColor),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            Text(
                text = "⚡",
                fontSize = 8.5.sp,
            )
            Text(
                text = displayString,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                ),
                color = textColor,
            )
        }
    }
}
