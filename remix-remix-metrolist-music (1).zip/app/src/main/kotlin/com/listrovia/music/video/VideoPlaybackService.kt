/**
 * Auramusic Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.video

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.ForegroundServiceStartNotAllowedException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.annotation.OptIn
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaController
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import androidx.media3.session.SessionToken
import com.listrovia.music.MainActivity
import com.listrovia.music.R
import com.listrovia.music.constants.MediaSessionConstants
import com.listrovia.music.constants.MediaSessionConstants.CommandToggleLike
import com.listrovia.music.utils.CoilBitmapLoader
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import android.app.Activity
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.content.BroadcastReceiver
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.util.Rational
import timber.log.Timber

/**
 * Foreground media service that surfaces a MediaSession + notification for the
 * in-app video player, mirroring the music player's notification behavior so
 * videos keep showing playback controls in the notification panel.
 */
class VideoPlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private var notificationProvider: DefaultMediaNotificationProvider? = null
    private var latestMediaNotification: Notification? = null
    private var scope = CoroutineScope(Dispatchers.Main + Job())
    private val mainHandler = Handler(Looper.getMainLooper())

    /**
     * Periodic re-pin of the foreground media notification while a video session
     * exists. Media3 rebuilds the notification on its own schedule, but various
     * lifecycle quirks (session active/inactive flaps, FGS restart restrictions,
     * OEM killers) can drop or freeze the shade entry. Re-posting from inside the
     * already-foreground service is cheap and makes the video notification stay
     * put for the whole watch session, exactly like the music player does.
     */
    private var keepAliveJob: Job? = null

    /** Whether the service has successfully reached the foreground state. */
    private var enteredForeground = false

    /**
     * Listener attached to the underlying ExoPlayer that explicitly triggers
     * notification rebuilds whenever the media item changes or playback state
     * shifts. Without this, MediaSessionService's auto-update path can miss
     * state transitions through the ForwardingPlayer wrapper, leaving the
     * notification stuck on the initial placeholder (title/artist only, no
     * artwork or transport controls).
     */
    private val playerNotificationListener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            rebuildMediaNotification()
            updateMediaButtonPreferences()
            updateCurrentPipActions()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_READY || playbackState == Player.STATE_ENDED) {
                rebuildMediaNotification()
                updateCurrentPipActions()
            }
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            rebuildMediaNotification()
            updateCurrentPipActions()
        }

        override fun onPlayerError(error: PlaybackException) {
            rebuildMediaNotification()
        }
    }

    override fun onCreate() {
        super.onCreate()
        try {
            configureService()
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "VideoPlaybackService.onCreate failed")
            // If the service was started via startForegroundService(), it must reach
            // the foreground state before stopping, otherwise the system (notably
            // Android 14+ / MIUI) throws ForegroundServiceDidNotStartInTime.
            promoteToForegroundWithLatestNotification()
            stopSelf()
        }
    }

    private fun configureService() {
        val exo = VideoPlaybackManager.playerOrNull()
        if (exo == null) {
            // Happens when the system restarts the service in a fresh process
            // (e.g. media button delivery after process death): the player is
            // owned by VideoPlaybackManager, which is empty here. Satisfy the
            // startForegroundService() contract before stopping, otherwise the
            // ForegroundServiceDidNotStartInTime watchdog crashes the app.
            promoteToForegroundWithLatestNotification()
            stopSelf()
            return
        }

        // Attach a listener that forces notification rebuilds on every meaningful
        // player state change. This is the critical link that makes the media
        // notification show artwork + transport controls instead of just text.
        exo.addListener(playerNotificationListener)

        setListener(
            object : MediaSessionService.Listener {
                override fun onForegroundServiceStartNotAllowedException() {
                    Timber.w("VideoPlaybackService: FGS start not allowed, re-promoting")
                    promoteToForegroundWithLatestNotification()
                }
            },
        )

        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    getString(R.string.video_player),
                    NotificationManager.IMPORTANCE_LOW,
                )
            )
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to create notification channel")
        }

        // Media title/artist/artwork live on each MediaItem's MediaMetadata (set when the
        // media source is built), so the session can render the full media notification.
        // The session ID must be unique per process; without an explicit ID the default
        // collides with another live session (e.g. after an abnormal teardown), crashing
        // onCreate with "Session ID must be unique". If a stale session still lingers,
        // retry with a per-instance unique ID so the service always comes up.
        mediaSession = try {
            buildSession(exo, SESSION_ID)
        } catch (e: IllegalStateException) {
            Timber.tag(TAG).w(e, "MediaSession ID collision, retrying with unique ID")
            buildSession(exo, "$SESSION_ID-${System.nanoTime()}")
        }

        // Keep a connected controller so the media notification with transport
        // controls and artwork is rendered and updated, mirroring MusicService.
        // The connection also makes the session "active" (the trigger Media3 uses
        // to render the full MediaStyle notification), so once it lands we force a
        // rebuild: this closes the race where the shade is stuck on the text-only
        // placeholder because the styled render was skipped through the
        // ForwardingPlayer wrapper.
        try {
            val sessionToken = SessionToken(this, ComponentName(this, VideoPlaybackService::class.java))
            val controllerFuture = MediaController.Builder(this, sessionToken).buildAsync()
            controllerFuture.addListener(
                {
                    try {
                        controllerFuture.get()
                        runOnMain { rebuildMediaNotification() }
                    } catch (e: Exception) {
                        Timber.tag(TAG).w(e, "Failed to connect MediaController")
                    }
                },
                MoreExecutors.directExecutor(),
            )
        } catch (e: Exception) {
            Timber.tag(TAG).w(e, "Failed to connect MediaController")
        }

        notificationProvider = DefaultMediaNotificationProvider(
            this,
            { NOTIFICATION_ID },
            CHANNEL_ID,
            R.string.video_player,
        ).apply {
            setSmallIcon(R.drawable.skip_next)
        }

        setMediaNotificationProvider(
            object : MediaNotification.Provider {
                override fun createNotification(
                    mediaSession: MediaSession,
                    mediaButtonPreferences: ImmutableList<CommandButton>,
                    actionFactory: MediaNotification.ActionFactory,
                    onNotificationChangedCallback: MediaNotification.Provider.Callback,
                ): MediaNotification {
                    val trackingCallback = MediaNotification.Provider.Callback { notification ->
                        latestMediaNotification = notification.notification
                        onNotificationChangedCallback.onNotificationChanged(notification)
                    }
                    val mediaNotification = notificationProvider!!.createNotification(
                        mediaSession,
                        mediaButtonPreferences,
                        actionFactory,
                        trackingCallback,
                    )
                    latestMediaNotification = mediaNotification.notification
                    return mediaNotification
                }

                override fun handleCustomCommand(
                    session: MediaSession,
                    action: String,
                    extras: Bundle,
                ): Boolean = notificationProvider?.handleCustomCommand(session, action, extras) == true
            },
        )

        // Surface a notification immediately (even before media3 renders the media
        // controls on the first playable frame) so the video always appears in the
        // notification panel, exactly like the music player does. The notification is
        // rendered through the styled provider up front (rather than posting the
        // text-only placeholder first), and the controller-connect rebuild above
        // re-renders it with artwork + transport controls as soon as the session is
        // active, so the shade never rests on a bare title/artist card.
        rebuildMediaNotification()
        promoteToForegroundWithLatestNotification()

        // Seed the notification buttons (transport + like) so the notification
        // renders custom action buttons from the very first frame.
        updateMediaButtonPreferences()

        // Keep the like button in sync: when like state changes, swap its
        // label/icon and rebuild the notification so the shade reflects it.
        scope.launch {
            var lastLiked: Boolean? = VideoPlaybackManager.uiState.value.isLiked
            VideoPlaybackManager.uiState.collect { state ->
                if (state.isLiked != lastLiked) {
                    lastLiked = state.isLiked
                    updateMediaButtonPreferences()
                    rebuildMediaNotification()
                }
            }
        }

        // Persistence: while a video is loaded, periodically re-pin the foreground
        // state and re-render the notification so it can never silently vanish or
        // stay stale mid-playback (media3's auto-update path can briefly drop the
        // shade entry during buffering/transition/restart edge cases).
        keepAliveJob = scope.launch {
            while (isActive) {
                delay(NOTIFICATION_KEEP_ALIVE_MS)
                if (mediaSession != null &&
                    VideoPlaybackManager.uiState.value.session != null
                ) {
                    rebuildMediaNotification()
                    promoteToForegroundWithLatestNotification()
                }
            }
        }
    }

    private fun buildSession(exo: ExoPlayer, sessionId: String): MediaSession {
        return MediaSession.Builder(this, MediaControlsPlayer(exo))
            .setId(sessionId)
            .setCallback(VideoSessionCallback())
            .setBitmapLoader(CoilBitmapLoader(this, scope))
            .setSessionActivity(
                PendingIntent.getActivity(
                    this,
                    0,
                    Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
                )
            )
            .build()
    }

    /**
     * Handles the notification's custom like button (the same CommandToggleLike
     * the music player exposes). Without a callback the button would render but
     * do nothing, and without onConnect advertising the command media3 drops
     * the button from the notification entirely.
     */
    private inner class VideoSessionCallback : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
        ): MediaSession.ConnectionResult {
            val connectionResult = super.onConnect(session, controller)
            return MediaSession.ConnectionResult.accept(
                connectionResult.availableSessionCommands
                    .buildUpon()
                    .add(CommandToggleLike)
                    .build(),
                connectionResult.availablePlayerCommands,
            )
        }

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle,
        ): ListenableFuture<SessionResult> {
            if (customCommand.customAction == MediaSessionConstants.ACTION_TOGGLE_LIKE) {
                VideoPlaybackManager.toggleLike()
            }
            return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
        }
    }

    /**
     * Exposes seek-to-next/previous in the MediaSession so the media notification
     * always shows skip buttons for the up-next queue (a fresh video plays on a
     * single-item timeline, which by itself gives the notification no skip button).
     */
    @OptIn(UnstableApi::class)
    private inner class MediaControlsPlayer(delegate: ExoPlayer) : ForwardingPlayer(delegate) {
        private val queueCommands: Player.Commands =
            super.getAvailableCommands()
                .buildUpon()
                .add(Player.COMMAND_SEEK_TO_NEXT)
                .add(Player.COMMAND_SEEK_TO_PREVIOUS)
                .add(Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM)
                .add(Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM)
                .build()

        override fun getAvailableCommands(): Player.Commands = queueCommands

        override fun isCommandAvailable(command: Int): Boolean = queueCommands.contains(command)

        /**
         * Surface the current video's title/artist/artwork on the MediaSession even
         * before the underlying player has loaded a MediaItem (and its metadata), so
         * the media notification always renders the video details + transport
         * controls instead of falling back to a plain placeholder.
         */
        override fun getMediaMetadata(): MediaMetadata {
            val session = VideoPlaybackManager.uiState.value.session
                ?: return super.getMediaMetadata()
            val thumbnailUrl = session.channelThumbnail?.takeIf { it.isNotBlank() }
            return super.getMediaMetadata()
                .buildUpon()
                .setTitle(session.title)
                .setArtist(session.channelName.ifBlank { null })
                .setArtworkUri(thumbnailUrl?.let { Uri.parse(it) })
                .build()
        }

        override fun seekToNext() = VideoPlaybackManager.playNext()

        override fun seekToNextMediaItem() = VideoPlaybackManager.playNext()

        override fun seekToPrevious() = VideoPlaybackManager.playPrevious()

        override fun seekToPreviousMediaItem() = VideoPlaybackManager.playPrevious()

        override fun hasNextMediaItem(): Boolean =
            VideoPlaybackManager.uiState.value.queue.any {
                it.videoId != VideoPlaybackManager.uiState.value.session?.videoId
            }

        override fun hasPreviousMediaItem(): Boolean = false
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Notification action buttons (and media3's media-button delivery path)
        // come here as explicit action intents. Perform the transport operation
        // first so the rebuild below renders the button's new state (play/pause
        // icon, liked heart) immediately.
        when (intent?.action) {
            ACTION_COMMAND_TOGGLE_PLAY_PAUSE -> VideoPlaybackManager.togglePlayPause()
            ACTION_COMMAND_PLAY_PREVIOUS -> VideoPlaybackManager.playPrevious()
            ACTION_COMMAND_PLAY_NEXT -> VideoPlaybackManager.playNext()
            ACTION_COMMAND_TOGGLE_LIKE -> VideoPlaybackManager.toggleLike()
        }
        // Always re-promote to the foreground AND rebuild the notification from the
        // session's CURRENT metadata (never the cached one). Every start path — a
        // fresh video (VideoPlaybackManager.playWithDetails), resume, media-button
        // delivery, or the explicit refresh action after metadata enrichment — must
        // re-seed the shade from live state, otherwise the notification can linger
        // on the previous video's title/artwork or fail to (re)appear at all.
        promoteToForegroundWithLatestNotification()
        rebuildMediaNotification()
        updateMediaButtonPreferences()
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onUpdateNotification(session: MediaSession, startInForegroundRequired: Boolean) {
        try {
            super.onUpdateNotification(session, startInForegroundRequired)
        } catch (e: ForegroundServiceStartNotAllowedException) {
            handleForegroundServiceStartNotAllowed(e)
        } catch (e: IllegalStateException) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                e.javaClass.name == ForegroundServiceStartNotAllowedException::class.java.name
            ) {
                handleForegroundServiceStartNotAllowed(e)
            } else {
                throw e
            }
        } catch (e: SecurityException) {
            Timber.tag(TAG).w(e, "onUpdateNotification: suppressed SecurityException from FGS path")
        }
    }

    override fun onDestroy() {
        // Stop state collectors before tearing down the session so they can't race it.
        scope.cancel()
        keepAliveJob?.cancel()
        keepAliveJob = null
        // Detach the player listener to prevent leaked callbacks after teardown.
        VideoPlaybackManager.playerOrNull()?.removeListener(playerNotificationListener)
        // Explicitly remove the foreground notification before releasing the session.
        // This ensures the notification disappears promptly when the service is destroyed
        // (e.g. when the video mini player is closed).
        try {
            stopForeground(android.app.Service.STOP_FOREGROUND_REMOVE)
        } catch (_: Exception) { /* ignore if not in foreground */ }
        try {
            mediaSession?.release()
        } catch (e: Exception) {
            Timber.tag(TAG).w(e, "onDestroy: session release failed")
        }
        mediaSession = null
        super.onDestroy()
    }

    /**
     * Explicitly triggers a notification rebuild via the MediaSessionService.
     * The DefaultMediaNotificationProvider reads the session's current
     * MediaMetadata (title, artist, artwork) and renders a full MediaStyle
     * notification with artwork, transport controls, and custom buttons.
     *
     * Named differently from MediaSessionService#triggerNotificationUpdate
     * to avoid hiding the framework member (which would otherwise require
     * an override and replace the service's internal update path).
     */
    private fun rebuildMediaNotification() {
        val session = mediaSession ?: return
        try {
            onUpdateNotification(session, true)
        } catch (e: Exception) {
            Timber.tag(TAG).w(e, "rebuildMediaNotification failed")
        }
    }

    private fun runOnMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else mainHandler.post(block)
    }

    /**
     * Declares which buttons the media notification displays: the transport
     * controls plus the like/unlike toggle, mirroring how MusicService
     * decorates its media notification. Media button preferences take
     * precedence over the deprecated custom layout in media3, so all buttons
     * are set in one place here; the like button's label/icon is recomputed
     * from the current like state on every call.
     */
    private fun updateMediaButtonPreferences() {
        // No-op
    }

    private fun handleForegroundServiceStartNotAllowed(error: Throwable?) {
        Timber.tag(TAG).w(error, "Foreground service start denied during notification update")
        promoteToForegroundWithLatestNotification()
    }

    private fun promoteToForegroundWithLatestNotification() {
        val notification = latestMediaNotification ?: buildPlaceholderNotification()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK,
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            enteredForeground = true
        } catch (e: ForegroundServiceStartNotAllowedException) {
            Timber.tag(TAG).w(e, "startForeground: FGS start not allowed, retrying without type")
            promoteForegroundFallback()
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "startForeground: failed, retrying without type")
            promoteForegroundFallback()
        }
    }

    /**
     * Fallback foreground promotion without an explicit FGS type (the system
     * then uses the manifest-declared types). If even this fails and the
     * service never reached the foreground, it stops itself: the
     * startForegroundService() watchdog would crash the app otherwise.
     */
    private fun promoteForegroundFallback() {
        try {
            startForeground(NOTIFICATION_ID, buildPlaceholderNotification())
            enteredForeground = true
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "startForeground fallback failed")
            if (!enteredForeground) stopSelf()
        }
    }

    private fun buildPlaceholderNotification(): Notification {
        val session = VideoPlaybackManager.uiState.value.session
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(session?.title?.ifBlank { null } ?: getString(R.string.video_player))
            .setContentText(session?.channelName.orEmpty())
            .setSmallIcon(R.drawable.notification)
            .setContentIntent(
                PendingIntent.getActivity(
                    this,
                    1,
                    Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
                )
            )
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .build()
    }

    companion object {
        /**
         * Force a full notification rebuild from outside the service (e.g. after
         * VideoPlaybackManager enriches session metadata with artwork URL).
         */
        fun notifySessionChanged(context: Context) {
            // An explicit action is required: a bare startForegroundService intent
            // only re-promotes the service with the CACHED notification, it does
            // not rebuild it from the session's latest MediaMetadata.
            try {
                ContextCompat.startForegroundService(
                    context.applicationContext,
                    Intent(context.applicationContext, VideoPlaybackService::class.java)
                        .setAction(ACTION_REFRESH_NOTIFICATION),
                )
            } catch (_: Exception) { /* service may not be started */ }
        }
        private const val TAG = "VideoPlaybackService"
        const val ACTION_REFRESH_NOTIFICATION = "com.listrovia.music.video.REFRESH_NOTIFICATION"
        const val ACTION_COMMAND_TOGGLE_PLAY_PAUSE = "com.listrovia.music.video.CMD_TOGGLE_PLAY_PAUSE"
        const val ACTION_COMMAND_PLAY_PREVIOUS = "com.listrovia.music.video.CMD_PLAY_PREVIOUS"
        const val ACTION_COMMAND_PLAY_NEXT = "com.listrovia.music.video.CMD_PLAY_NEXT"
        const val ACTION_COMMAND_TOGGLE_LIKE = "com.listrovia.music.video.CMD_TOGGLE_LIKE"

        // --- PICTURE-IN-PICTURE (PiP) ACTIONS & CONSTANTS ---
        const val ACTION_PIP_PLAY_PAUSE = "com.listrovia.music.video.PIP_PLAY_PAUSE"
        const val ACTION_PIP_NEXT = "com.listrovia.music.video.PIP_NEXT"
        const val ACTION_PIP_PREV = "com.listrovia.music.video.PIP_PREV"
        const val ACTION_ENTER_PIP = "com.listrovia.music.video.ENTER_PIP"

        private val _isInPipMode = MutableStateFlow(false)
        val isInPipMode: StateFlow<Boolean> = _isInPipMode.asStateFlow()

        fun setInPipMode(inPip: Boolean) {
            _isInPipMode.value = inPip
        }

        fun supportsPictureInPicture(context: Context): Boolean {
            return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                context.packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        }

        fun shouldEnterPipOnLeave(): Boolean {
            val uiState = VideoPlaybackManager.uiState.value
            val hasVideo = uiState.session != null && !uiState.hiddenByMusic
            val isPlaying = uiState.isPlaying || VideoPlaybackManager.playerOrNull()?.isPlaying == true
            return hasVideo && isPlaying
        }

        fun buildPipParams(
            context: Context,
            isPlaying: Boolean = VideoPlaybackManager.uiState.value.isPlaying || VideoPlaybackManager.playerOrNull()?.isPlaying == true,
            aspectRatio: Rational = Rational(16, 9)
        ): PictureInPictureParams? {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return null

            val actions = mutableListOf<RemoteAction>()

            // Previous Action
            val prevIntent = PendingIntent.getBroadcast(
                context,
                101,
                Intent(ACTION_PIP_PREV).setPackage(context.packageName),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            actions.add(
                RemoteAction(
                    Icon.createWithResource(context, R.drawable.skip_previous),
                    context.getString(R.string.previous),
                    context.getString(R.string.previous),
                    prevIntent
                )
            )

            // Play/Pause Action
            val playPauseIcon = if (isPlaying) R.drawable.pause else R.drawable.play
            val playPauseLabel = if (isPlaying) context.getString(R.string.pause) else context.getString(R.string.play)
            val playPauseIntent = PendingIntent.getBroadcast(
                context,
                102,
                Intent(ACTION_PIP_PLAY_PAUSE).setPackage(context.packageName),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            actions.add(
                RemoteAction(
                    Icon.createWithResource(context, playPauseIcon),
                    playPauseLabel,
                    playPauseLabel,
                    playPauseIntent
                )
            )

            // Next Action
            val nextIntent = PendingIntent.getBroadcast(
                context,
                103,
                Intent(ACTION_PIP_NEXT).setPackage(context.packageName),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            actions.add(
                RemoteAction(
                    Icon.createWithResource(context, R.drawable.skip_next),
                    context.getString(R.string.next),
                    context.getString(R.string.next),
                    nextIntent
                )
            )

            val builder = PictureInPictureParams.Builder()
                .setAspectRatio(aspectRatio)
                .setActions(actions)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                builder.setAutoEnterEnabled(true)
                builder.setSeamlessResizeEnabled(true)
            }

            return builder.build()
        }

        private var activeActivity: java.lang.ref.WeakReference<Activity>? = null

        fun registerActivity(activity: Activity) {
            activeActivity = java.lang.ref.WeakReference(activity)
        }

        fun unregisterActivity(activity: Activity) {
            if (activeActivity?.get() == activity) {
                activeActivity = null
            }
        }

        fun enterPictureInPicture(activity: Activity): Boolean {
            if (!supportsPictureInPicture(activity)) return false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                return try {
                    registerActivity(activity)
                    val params = buildPipParams(activity) ?: return false
                    val success = activity.enterPictureInPictureMode(params)
                    if (success) {
                        setInPipMode(true)
                    }
                    success
                } catch (e: Exception) {
                    Timber.tag(TAG).e(e, "enterPictureInPicture failed")
                    false
                }
            }
            return false
        }

        fun updatePipActions(activity: Activity) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && activity.isInPictureInPictureMode) {
                val params = buildPipParams(activity) ?: return
                try {
                    activity.setPictureInPictureParams(params)
                } catch (e: Exception) {
                    Timber.tag(TAG).w(e, "updatePipActions failed")
                }
            }
        }

        fun updateCurrentPipActions() {
            activeActivity?.get()?.let { updatePipActions(it) }
        }

        const val SESSION_ID = "aura_video_playback"
        const val CHANNEL_ID = "video_channel_01"
        const val NOTIFICATION_ID = 889

        /** How often the service re-pins the foreground notification while a video session exists. */
        private const val NOTIFICATION_KEEP_ALIVE_MS = 10_000L

        fun start(context: Context) {
            ContextCompat.startForegroundService(
                context.applicationContext,
                Intent(context.applicationContext, VideoPlaybackService::class.java),
            )
        }

        fun stop(context: Context) {
            val appContext = context.applicationContext
            // Explicitly cancel the foreground notification before stopping the
            // service. stopService() alone may not remove the notification promptly,
            // leaving a stale video notification in the shade after the mini player
            // is dismissed.
            try {
                val nm = appContext.getSystemService(NotificationManager::class.java)
                nm?.cancel(NOTIFICATION_ID)
            } catch (_: Exception) { /* service may not be started */ }
            appContext.stopService(
                Intent(appContext, VideoPlaybackService::class.java),
            )
        }
    }
}

/**
 * BroadcastReceiver for handling Picture-in-Picture remote action buttons.
 */
class PipActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        when (intent?.action) {
            VideoPlaybackService.ACTION_PIP_PLAY_PAUSE -> {
                VideoPlaybackManager.togglePlayPause()
                VideoPlaybackService.updateCurrentPipActions()
            }
            VideoPlaybackService.ACTION_PIP_NEXT -> {
                VideoPlaybackManager.playNext()
                VideoPlaybackService.updateCurrentPipActions()
            }
            VideoPlaybackService.ACTION_PIP_PREV -> {
                VideoPlaybackManager.playPrevious()
                VideoPlaybackService.updateCurrentPipActions()
            }
        }
    }
}