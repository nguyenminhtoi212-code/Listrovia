package com.listrovia.music.video

import android.content.Context
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * VideoModeHandler dynamically manages and swaps playback between the
 * audio-focused player and the YouTube WebView component while maintaining
 * seamless synchronization of playback state (position, playing status, and video ID).
 */
object VideoModeHandler {

    private const val TAG = "VideoModeHandler"

    enum class Mode {
        AUDIO_ONLY,
        YOUTUBE_WEBVIEW
    }

    data class State(
        val mode: Mode = Mode.AUDIO_ONLY,
        val videoId: String? = null,
        val title: String? = null,
        val channelName: String? = null,
        val currentPositionMs: Long = 0L,
        val isPlaying: Boolean = false,
        val isBuffering: Boolean = false,
    )

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    /**
     * Swaps to YouTube WebView video mode while preserving playback position.
     */
    fun switchToVideoMode(
        context: Context,
        videoId: String,
        title: String? = null,
        channelName: String? = null,
        currentPositionMs: Long = 0L,
    ) {
        Log.d(TAG, "Swapping to YOUTUBE_WEBVIEW mode for video: $videoId at ${currentPositionMs}ms")
        _state.update {
            it.copy(
                mode = Mode.YOUTUBE_WEBVIEW,
                videoId = videoId,
                title = title,
                channelName = channelName,
                currentPositionMs = currentPositionMs,
                isPlaying = true,
                isBuffering = false,
            )
        }
    }

    /**
     * Swaps back to Audio-focused player mode while preserving playback position.
     */
    fun switchToAudioMode(context: Context, currentPositionMs: Long = 0L) {
        Log.d(TAG, "Swapping to AUDIO_ONLY mode at ${currentPositionMs}ms")
        _state.update {
            it.copy(
                mode = Mode.AUDIO_ONLY,
                currentPositionMs = currentPositionMs,
            )
        }
        VideoPlaybackManager.giveWayToMusic(context)
    }

    /**
     * Updates synchronized position during playback.
     */
    fun updatePosition(positionMs: Long) {
        _state.update { it.copy(currentPositionMs = positionMs) }
    }

    /**
     * Updates playing state.
     */
    fun setPlaying(playing: Boolean) {
        _state.update { it.copy(isPlaying = playing) }
    }
}
