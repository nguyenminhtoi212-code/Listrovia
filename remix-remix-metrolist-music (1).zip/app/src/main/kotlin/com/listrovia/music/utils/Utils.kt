/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.utils

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import android.widget.Toast
import androidx.annotation.ChecksSdkIntAtLeast
import timber.log.Timber
import java.io.Closeable
import java.io.File
import java.net.MalformedURLException
import java.net.URL
import java.security.MessageDigest
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Ensures WebView and Chromium cache directories exist safely and cleans corrupted SimpleCache index files.
 * Note: Chromium's Simple Cache expects 'HTTP Cache' to be a flat cache repository without foreign subdirectories
 * like 'Code Cache'. Pre-creating directories inside 'HTTP Cache' causes SimpleCache format errors and crash.
 */
fun ensureWebViewCacheDirsExist(context: Context) {
    try {
        val cacheDir = context.cacheDir
        if (cacheDir != null) {
            // Ensure parent container directories exist
            val parentDirs = listOf(
                "WebView",
                "WebView/Default",
                "WebView/Crash Reports",
            )
            for (sub in parentDirs) {
                val dir = File(cacheDir, sub)
                if (dir.exists() && dir.isFile) {
                    dir.delete()
                }
                if (!dir.exists()) {
                    dir.mkdirs()
                }
            }

            // Clean up any corrupted structure inside HTTP Cache
            val httpCacheDir = File(cacheDir, "WebView/Default/HTTP Cache")
            if (httpCacheDir.exists()) {
                // If the invalid 'Code Cache' subdirectory exists inside HTTP Cache, delete it recursively
                val badCodeCache = File(httpCacheDir, "Code Cache")
                if (badCodeCache.exists()) {
                    badCodeCache.deleteRecursively()
                }
                // If any foreign subdirectories exist inside HTTP Cache (violating Simple Cache format), purge them
                httpCacheDir.listFiles()?.filter { it.isDirectory && it.name != "index-dir" }?.forEach { sub ->
                    sub.deleteRecursively()
                }
                // Clean stale or zero-byte index or fake index files that cause "Could not reconstruct index from disk"
                val indexFile = File(httpCacheDir, "index")
                if (indexFile.exists() && indexFile.length() == 0L) {
                    indexFile.delete()
                }
                val fakeIndex = File(httpCacheDir, "the-fake-index")
                if (fakeIndex.exists() && fakeIndex.length() == 0L) {
                    fakeIndex.delete()
                }
            }
        }

        val dataDir = context.filesDir?.parentFile
        if (dataDir != null) {
            val appParentDirs = listOf(
                "app_webview",
                "app_webview/Default",
            )
            for (sub in appParentDirs) {
                val dir = File(dataDir, sub)
                if (dir.exists() && dir.isFile) {
                    dir.delete()
                }
                if (!dir.exists()) {
                    dir.mkdirs()
                }
            }

            val appHttpCacheDir = File(dataDir, "app_webview/Default/HTTP Cache")
            if (appHttpCacheDir.exists()) {
                val badCodeCache = File(appHttpCacheDir, "Code Cache")
                if (badCodeCache.exists()) {
                    badCodeCache.deleteRecursively()
                }
                appHttpCacheDir.listFiles()?.filter { it.isDirectory && it.name != "index-dir" }?.forEach { sub ->
                    sub.deleteRecursively()
                }
                val indexFile = File(appHttpCacheDir, "index")
                if (indexFile.exists() && indexFile.length() == 0L) {
                    indexFile.delete()
                }
                val fakeIndex = File(appHttpCacheDir, "the-fake-index")
                if (fakeIndex.exists() && fakeIndex.length() == 0L) {
                    fakeIndex.delete()
                }
            }
        }
    } catch (e: Throwable) {
        Timber.tag("Utils").w(e, "Non-fatal error checking WebView cache directory")
    }
}

/**
 * Computes a SHA-1 hash for the given input string safely.
 */
fun makeSha1Hash(input: String): String {
    return try {
        val md = MessageDigest.getInstance("SHA-1")
        val bytes = md.digest(input.toByteArray(Charsets.UTF_8))
        bytes.joinToString("") { "%02x".format(it) }
    } catch (e: Throwable) {
        Timber.tag("Utils").w(e, "Error computing SHA-1 hash")
        input.hashCode().toString()
    }
}

/**
 * Computes a SHA-256 hash for the given input string safely.
 */
fun makeSha256Hash(input: String): String {
    return try {
        val md = MessageDigest.getInstance("SHA-256")
        val bytes = md.digest(input.toByteArray(Charsets.UTF_8))
        bytes.joinToString("") { "%02x".format(it) }
    } catch (e: Throwable) {
        Timber.tag("Utils").w(e, "Error computing SHA-256 hash")
        input.hashCode().toString()
    }
}

/**
 * Formats a duration in milliseconds to "mm:ss" or "hh:mm:ss".
 */
fun formatDuration(durationMs: Long): String {
    if (durationMs < 0) return "0:00"
    val totalSeconds = durationMs / 1000
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60

    return if (hours > 0) {
        String.format(Locale.getDefault(), "%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format(Locale.getDefault(), "%d:%02d", minutes, seconds)
    }
}

/**
 * Formats duration given in seconds to "mm:ss" or "hh:mm:ss".
 */
fun formatDurationSeconds(seconds: Long): String {
    return formatDuration(seconds * 1000)
}

/**
 * Formats a file size in bytes to human-readable units (B, KB, MB, GB).
 */
fun formatFileSize(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt().coerceIn(0, units.size - 1)
    val size = bytes / Math.pow(1024.0, digitGroups.toDouble())
    return String.format(Locale.getDefault(), "%.1f %s", size, units[digitGroups])
}

/**
 * Validates whether a given string is a valid web URL.
 */
fun isValidUrl(url: String?): Boolean {
    if (url.isNullOrBlank()) return false
    return try {
        val parsed = URL(url)
        parsed.protocol == "http" || parsed.protocol == "https"
    } catch (e: MalformedURLException) {
        false
    }
}

/**
 * Sanitizes a filename by replacing illegal filesystem characters with underscores.
 */
fun sanitizeFilename(filename: String): String {
    return filename.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
}

/**
 * Safely closes any Closeable instance without throwing unchecked exceptions.
 */
fun safeClose(closeable: Closeable?) {
    try {
        closeable?.close()
    } catch (e: Throwable) {
        Timber.tag("Utils").d(e, "safeClose suppressed exception")
    }
}

/**
 * Resolves the underlying Activity from a Context hierarchy safely.
 */
fun Context.findActivity(): Activity? {
    var currentContext = this
    while (currentContext is ContextWrapper) {
        if (currentContext is Activity) return currentContext
        currentContext = currentContext.baseContext ?: return null
    }
    return null
}

/**
 * Displays a short Toast message safely on the UI thread.
 */
fun Context.showToast(message: String, duration: Int = Toast.LENGTH_SHORT) {
    try {
        Toast.makeText(this.applicationContext, message, duration).show()
    } catch (e: Throwable) {
        Timber.tag("Utils").w(e, "Error showing toast")
    }
}

/**
 * SDK Version Checkers
 */
@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.S)
fun isAtLeastAndroid12(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.TIRAMISU)
fun isAtLeastAndroid13(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
fun isAtLeastAndroid14(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE

@ChecksSdkIntAtLeast(api = 35)
fun isAtLeastAndroid15(): Boolean = Build.VERSION.SDK_INT >= 35

fun setAppLocale(context: Context, locale: java.util.Locale) {
    java.util.Locale.setDefault(locale)
    val resources = context.resources
    val config = resources.configuration
    config.setLocale(locale)
    @Suppress("DEPRECATION")
    resources.updateConfiguration(config, resources.displayMetrics)
}
