@file:Suppress("unused", "MemberVisibilityCanBePrivate")
@file:OptIn(
    kotlinx.serialization.ExperimentalSerializationApi::class,
    kotlin.io.encoding.ExperimentalEncodingApi::class,
)

/**
 * Listrovia Music Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 *
 * ListroviaUnifiedInnerTubeHub.kt
 * Unified, self-contained InnerTube & YouTube Music engine consolidating all InnerTube client
 * endpoints, YouTube facade parsers, network configurations, data models, request bodies,
 * response schemas, page extractors, URL parsers, health diagnostics, and content moderation
 * into a single non-fragmented module.
 */

package com.listrovia.innertube

import android.content.res.Configuration
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.listrovia.innertube.BrowseEndpoint.BrowseEndpointContextSupportedConfigs.BrowseEndpointContextMusicConfig.Companion.MUSIC_PAGE_TYPE_ALBUM
import com.listrovia.innertube.BrowseEndpoint.BrowseEndpointContextSupportedConfigs.BrowseEndpointContextMusicConfig.Companion.MUSIC_PAGE_TYPE_ARTIST
import com.listrovia.innertube.BrowseEndpoint.BrowseEndpointContextSupportedConfigs.BrowseEndpointContextMusicConfig.Companion.MUSIC_PAGE_TYPE_AUDIOBOOK
import com.listrovia.innertube.BrowseEndpoint.BrowseEndpointContextSupportedConfigs.BrowseEndpointContextMusicConfig.Companion.MUSIC_PAGE_TYPE_LIBRARY_ARTIST
import com.listrovia.innertube.BrowseEndpoint.BrowseEndpointContextSupportedConfigs.BrowseEndpointContextMusicConfig.Companion.MUSIC_PAGE_TYPE_NON_MUSIC_AUDIO_TRACK_PAGE
import com.listrovia.innertube.BrowseEndpoint.BrowseEndpointContextSupportedConfigs.BrowseEndpointContextMusicConfig.Companion.MUSIC_PAGE_TYPE_PLAYLIST
import com.listrovia.innertube.BrowseEndpoint.BrowseEndpointContextSupportedConfigs.BrowseEndpointContextMusicConfig.Companion.MUSIC_PAGE_TYPE_PODCAST_SHOW_DETAIL_PAGE
import com.listrovia.innertube.BrowseEndpoint.BrowseEndpointContextSupportedConfigs.BrowseEndpointContextMusicConfig.Companion.MUSIC_PAGE_TYPE_USER_CHANNEL
import com.listrovia.innertube.MusicResponsiveListItemRenderer.FlexColumn
import com.listrovia.innertube.WatchEndpoint.WatchEndpointMusicSupportedConfigs.WatchEndpointMusicConfig.Companion.MUSIC_VIDEO_TYPE_ATV
import com.listrovia.innertube.YouTubeClient.Companion.WEB
import com.listrovia.innertube.YouTubeClient.Companion.WEB_REMIX
import com.listrovia.music.utils.cipher.CipherDeobfuscator
import io.ktor.client.*
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.engine.okhttp.*
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.*
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.compression.*
import io.ktor.client.plugins.compression.ContentEncoding
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.request.*
import io.ktor.client.statement.bodyAsText
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.serialization.kotlinx.json.json
import java.io.File
import java.io.IOException
import java.net.Proxy
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi
import kotlin.random.Random
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.SerializationException
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.*
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonNames
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.json.JSONObject
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.exceptions.ParsingException
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.stream.StreamInfo
import timber.log.Timber

// ----------------------------------------------------------------------------
// [CORE CONFIG & CONSTANTS] Source: YouTubeConstants.kt
// ----------------------------------------------------------------------------

object YouTubeConstants {
    const val DEFAULT_TOP_RESULT = "Top result"
    const val DEFAULT_OTHER_RESULTS = "Other"

    // Search filters
    const val SEARCH_FILTER_VIDEOS = "EgIQAQ%3D%3D"
    const val SEARCH_FILTER_CHANNELS = "EgIQAg%3D%3D"
    const val SEARCH_FILTER_PLAYLISTS = "EgIQAw%3D%3D"
    
    const val SEARCH_DURATION_UNDER_4_MINUTES = "EgYyAnAB"
    const val SEARCH_DURATION_4_TO_20_MINUTES = "EgYyAnAC"
    const val SEARCH_DURATION_OVER_20_MINUTES = "EgYyAnAD"
    
    const val SEARCH_TIME_TODAY = "EgQIAhAB"
    const val SEARCH_TIME_THIS_WEEK = "EgQIAxAB"
    const val SEARCH_TIME_THIS_MONTH = "EgQIBBAB"
    const val SEARCH_TIME_THIS_YEAR = "EgQIBRAB"
    
    const val SEARCH_SORT_BY_RATING = "CAE%3D"
    const val SEARCH_SORT_BY_DATE = "CAI%3D"
    const val SEARCH_SORT_BY_VIEW_COUNT = "CAM%3D"

    // Channel params
    const val CHANNEL_VIDEOS_PARAMS = "EgZ2aWRlb3PyBgQKAjoA"
    const val CHANNEL_SHORTS_PARAMS = "EgZzaG9ydHPyBgQKAjoA"
    const val CHANNEL_LIVE_PARAMS = "EgRsaXZleyBgQKAjoA"
}

// ----------------------------------------------------------------------------
// [CORE CONFIG & CONSTANTS] Source: NetworkConfig.kt
// ----------------------------------------------------------------------------

/**
 * Enhanced network configuration for better performance and reliability
 * Inspired by ArchiveTune optimizations
 */
object NetworkConfig {
    
    // Timeout settings
    private const val CONNECT_TIMEOUT_SECONDS = 30L
    private const val READ_TIMEOUT_SECONDS = 60L
    private const val WRITE_TIMEOUT_SECONDS = 60L
    private const val REQUEST_TIMEOUT_MILLIS = 60000L
    
    // Cache settings
    private const val CACHE_SIZE_MB = 128L * 1024L * 1024L // 128 MB
    
    @OptIn(ExperimentalSerializationApi::class)
    fun createOptimizedHttpClient(
        cacheDir: File? = null,
        enableCache: Boolean = true
    ): HttpClient = HttpClient(OkHttp) {
        expectSuccess = true

        install(ContentNegotiation) {
            json(Json {
                ignoreUnknownKeys = true
                explicitNulls = false
                encodeDefaults = true
                isLenient = true
            })
        }

        install(ContentEncoding) {
            gzip(0.9F)
            deflate(0.8F)
        }

        install(HttpTimeout) {
            requestTimeoutMillis = REQUEST_TIMEOUT_MILLIS
            connectTimeoutMillis = CONNECT_TIMEOUT_SECONDS * 1000
            socketTimeoutMillis = READ_TIMEOUT_SECONDS * 1000
        }

        engine {
            config {
                // Timeout configurations
                connectTimeout(CONNECT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                readTimeout(READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                writeTimeout(WRITE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                
                // Retry configuration
                retryOnConnectionFailure(true)
                
                // Cache configuration
                if (enableCache) {
                    val cacheDirectory = cacheDir ?: File(System.getProperty("java.io.tmpdir"), "listrovia_http_cache")
                    cache(okhttp3.Cache(cacheDirectory, CACHE_SIZE_MB))
                }
            }
        }
    }
    
    /**
     * Create a client specifically optimized for YouTube Music API
     */
    @OptIn(ExperimentalSerializationApi::class)
    fun createYouTubeMusicClient(
        cacheDir: File? = null
    ): HttpClient {
        val baseClient = createOptimizedHttpClient(cacheDir)
        return baseClient.config {
            // Additional configuration can be added here if needed
        }
    }
    
    /**
     * Network quality detection and adaptive configuration
     */
    fun getAdaptiveTimeouts(networkQuality: NetworkQuality): TimeoutConfig {
        return when (networkQuality) {
            NetworkQuality.EXCELLENT -> TimeoutConfig(
                connectTimeout = 10000L,
                readTimeout = 30000L,
                requestTimeout = 45000L
            )
            NetworkQuality.GOOD -> TimeoutConfig(
                connectTimeout = 20000L,
                readTimeout = 45000L,
                requestTimeout = 60000L
            )
            NetworkQuality.POOR -> TimeoutConfig(
                connectTimeout = 30000L,
                readTimeout = 60000L,
                requestTimeout = 90000L
            )
            NetworkQuality.UNKNOWN -> TimeoutConfig(
                connectTimeout = CONNECT_TIMEOUT_SECONDS * 1000,
                readTimeout = READ_TIMEOUT_SECONDS * 1000,
                requestTimeout = REQUEST_TIMEOUT_MILLIS
            )
        }
    }
    
    enum class NetworkQuality {
        EXCELLENT, GOOD, POOR, UNKNOWN
    }
    
    data class TimeoutConfig(
        val connectTimeout: Long,
        val readTimeout: Long,
        val requestTimeout: Long
    )
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/AccountInfo.kt
// ----------------------------------------------------------------------------

data class AccountInfo(
    val name: String,
    val email: String?,
    val channelHandle: String?,
    val thumbnailUrl: String?,
)

// ----------------------------------------------------------------------------
// [MODELS] Source: models/AutomixPreviewVideoRenderer.kt
// ----------------------------------------------------------------------------

@Serializable
data class AutomixPreviewVideoRenderer(
    val content: Content,
) {
    @Serializable
    data class Content(
        val automixPlaylistVideoRenderer: AutomixPlaylistVideoRenderer,
    ) {
        @Serializable
        data class AutomixPlaylistVideoRenderer(
            val navigationEndpoint: NavigationEndpoint,
        )
    }
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/Badges.kt
// ----------------------------------------------------------------------------

@Serializable
data class Badges(
    val musicInlineBadgeRenderer: MusicInlineBadgeRenderer?,
) {
    @Serializable
    data class MusicInlineBadgeRenderer(
        val icon: Icon,
    )
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/Button.kt
// ----------------------------------------------------------------------------

@Serializable
data class Button(
    val buttonRenderer: ButtonRenderer,
) {
    @Serializable
    data class ButtonRenderer(
        val text: Runs,
        val navigationEndpoint: NavigationEndpoint?,
        val command: NavigationEndpoint?,
        val icon: Icon?,
    )
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/Context.kt
// ----------------------------------------------------------------------------

@Serializable
data class Context(
    val client: Client,
    val thirdParty: ThirdParty? = null,
    val request: Request = Request(),
    val user: User = User()
) {
    @Serializable
    data class Client(
        val clientName: String,
        val clientVersion: String,
        val osName: String? = null,
        val osVersion: String? = null,
        val deviceMake: String? = null,
        val deviceModel: String? = null,
        val androidSdkVersion: String? = null,
        val gl: String,
        val hl: String,
        val visitorData: String?,
    )

    @Serializable
    data class ThirdParty(
        val embedUrl: String,
    )

    @Serializable
    data class Request(
        val internalExperimentFlags: Array<String> = emptyArray(),
        val useSsl: Boolean = true,
    )

    @Serializable
    data class User(
        val lockedSafetyMode: Boolean = false,
        val onBehalfOfUser: String? = null,
    )
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/Continuation.kt
// ----------------------------------------------------------------------------

@OptIn(ExperimentalSerializationApi::class)
@Serializable
data class Continuation(
    @JsonNames("nextContinuationData", "nextRadioContinuationData")
    val nextContinuationData: NextContinuationData?,
) {
    @Serializable
    data class NextContinuationData(
        val continuation: String,
    )
}

@JvmName("getContinuationFromContinuations")
fun List<Continuation>.getContinuation() =
    firstOrNull()?.nextContinuationData?.continuation

// ----------------------------------------------------------------------------
// [MODELS] Source: models/ContinuationItemRenderer.kt
// ----------------------------------------------------------------------------

@Serializable
data class ContinuationItemRenderer(
    val continuationEndpoint: ContinuationEndpoint?,
) {
    @Serializable
    data class ContinuationEndpoint(
        val continuationCommand: ContinuationCommand?,
    ) {
        @Serializable
        data class ContinuationCommand(
            val token: String?,
        )
    }
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/Endpoint.kt
// ----------------------------------------------------------------------------

@Serializable
sealed class Endpoint

@Serializable
data class WatchEndpoint(
    val videoId: String? = null,
    val playlistId: String? = null,
    val playlistSetVideoId: String? = null,
    val params: String? = null,
    val index: Int? = null,
    val watchEndpointMusicSupportedConfigs: WatchEndpointMusicSupportedConfigs? = null,
) : Endpoint() {

    @Serializable
    data class WatchEndpointMusicSupportedConfigs(
        val watchEndpointMusicConfig: WatchEndpointMusicConfig,
    ) {
        @Serializable
        data class WatchEndpointMusicConfig(
            val musicVideoType: String,
        ) {
            companion object {
                const val MUSIC_VIDEO_TYPE_OMV = "MUSIC_VIDEO_TYPE_OMV"
                const val MUSIC_VIDEO_TYPE_UGC = "MUSIC_VIDEO_TYPE_UGC"
                const val MUSIC_VIDEO_TYPE_ATV = "MUSIC_VIDEO_TYPE_ATV"
            }
        }
    }
}

@Serializable
data class BrowseEndpoint(
    val browseId: String,
    val params: String? = null,
    val browseEndpointContextSupportedConfigs: BrowseEndpointContextSupportedConfigs? = null,
) : Endpoint() {
    val isArtistEndpoint: Boolean
        get() = browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType == MUSIC_PAGE_TYPE_ARTIST
    val isAlbumEndpoint: Boolean
        get() = browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType == MUSIC_PAGE_TYPE_ALBUM ||
                browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType == MUSIC_PAGE_TYPE_AUDIOBOOK
    val isPlaylistEndpoint: Boolean
        get() = browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType == MUSIC_PAGE_TYPE_PLAYLIST
    val isPodcastEndpoint: Boolean
        get() = browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType == MUSIC_PAGE_TYPE_PODCAST_SHOW_DETAIL_PAGE

    @Serializable
    data class BrowseEndpointContextSupportedConfigs(
        val browseEndpointContextMusicConfig: BrowseEndpointContextMusicConfig,
    ) {
        @Serializable
        data class BrowseEndpointContextMusicConfig(
            val pageType: String,
        ) {
            companion object {
                const val MUSIC_PAGE_TYPE_ALBUM = "MUSIC_PAGE_TYPE_ALBUM"
                const val MUSIC_PAGE_TYPE_AUDIOBOOK = "MUSIC_PAGE_TYPE_AUDIOBOOK"
                const val MUSIC_PAGE_TYPE_PLAYLIST = "MUSIC_PAGE_TYPE_PLAYLIST"
                const val MUSIC_PAGE_TYPE_ARTIST = "MUSIC_PAGE_TYPE_ARTIST"
                const val MUSIC_PAGE_TYPE_LIBRARY_ARTIST = "MUSIC_PAGE_TYPE_LIBRARY_ARTIST"
                const val MUSIC_PAGE_TYPE_USER_CHANNEL = "MUSIC_PAGE_TYPE_USER_CHANNEL"
                const val MUSIC_PAGE_TYPE_TRACK_LYRICS = "MUSIC_PAGE_TYPE_TRACK_LYRICS"
                const val MUSIC_PAGE_TYPE_TRACK_RELATED = "MUSIC_PAGE_TYPE_TRACK_RELATED"
                const val MUSIC_PAGE_TYPE_PODCAST_SHOW_DETAIL_PAGE = "MUSIC_PAGE_TYPE_PODCAST_SHOW_DETAIL_PAGE"
                const val MUSIC_PAGE_TYPE_NON_MUSIC_AUDIO_TRACK_PAGE = "MUSIC_PAGE_TYPE_NON_MUSIC_AUDIO_TRACK_PAGE"
            }
        }
    }
}

@Serializable
data class SearchEndpoint(
    val params: String?,
    val query: String,
) : Endpoint()

@Serializable
data class FeedbackEndpoint(
    val feedbackToken: String
) : Endpoint()

@Serializable
data class QueueAddEndpoint(
    val queueInsertPosition: String,
    val queueTarget: QueueTarget,
) : Endpoint() {
    @Serializable
    data class QueueTarget(
        val videoId: String? = null,
        val playlistId: String? = null,
    )
}

@Serializable
data class ShareEntityEndpoint(
    val serializedShareEntity: String,
) : Endpoint()

@Serializable
data class DefaultServiceEndpoint(
    var subscribeEndpoint: SubscribeEndpoint?,
    var feedbackEndpoint: FeedbackEndpoint?
) : Endpoint() {
    @Serializable
    data class SubscribeEndpoint(
        val channelIds: List<String>,
        val params: String? = null,
    ) : Endpoint()
}

@Serializable
data class ToggledServiceEndpoint(
    var feedbackEndpoint: FeedbackEndpoint?
) : Endpoint()

// ----------------------------------------------------------------------------
// [MODELS] Source: models/GridRenderer.kt
// ----------------------------------------------------------------------------

@Serializable
data class GridRenderer(
    val header: Header?,
    val items: List<Item>,
    val continuations: List<Continuation>?,
) {
    @Serializable
    data class Header(
        val gridHeaderRenderer: GridHeaderRenderer,
    ) {
        @Serializable
        data class GridHeaderRenderer(
            val title: Runs,
        )
    }

    @Serializable
    data class Item(
        val musicNavigationButtonRenderer: MusicNavigationButtonRenderer?,
        val musicTwoRowItemRenderer: MusicTwoRowItemRenderer?,
    )
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/Icon.kt
// ----------------------------------------------------------------------------

@Serializable
data class Icon(
    val iconType: String,
)

// ----------------------------------------------------------------------------
// [MODELS] Source: models/MediaInfo.kt
// ----------------------------------------------------------------------------

data class MediaInfo(
    val videoId: String,
    val title: String? = null,
    val author: String? = null,
    val authorId: String? = null,
    val authorThumbnail: String? = null,
    val description: String? = null,
    val uploadDate: String? = null,
    val subscribers: String? = null,
    val viewCount: Int? = null,
    val like: Int? = null,
    val dislike: Int? = null,
)

// ----------------------------------------------------------------------------
// [MODELS] Source: models/Menu.kt
// ----------------------------------------------------------------------------

@Serializable
data class Menu(
    val menuRenderer: MenuRenderer,
) {
    @Serializable
    data class MenuRenderer(
        val items: List<Item>?,
        val topLevelButtons: List<TopLevelButton>?,
    ) {
        @Serializable
        data class Item(
            val menuNavigationItemRenderer: MenuNavigationItemRenderer?,
            val menuServiceItemRenderer: MenuServiceItemRenderer?,
            val toggleMenuServiceItemRenderer: ToggleMenuServiceRenderer?,
        ) {
            @Serializable
            data class MenuNavigationItemRenderer(
                val text: Runs,
                val icon: Icon,
                val navigationEndpoint: NavigationEndpoint,
            )

            @Serializable
            data class MenuServiceItemRenderer(
                val text: Runs,
                val icon: Icon,
                val serviceEndpoint: NavigationEndpoint,
            )
            @Serializable
            data class ToggleMenuServiceRenderer(
                val defaultIcon: Icon,
                val defaultServiceEndpoint: DefaultServiceEndpoint,
                val toggledServiceEndpoint: ToggledServiceEndpoint?,
                val isSelected: Boolean = false,
            )
        }

        @Serializable
        data class TopLevelButton(
            val buttonRenderer: ButtonRenderer?,
        ) {
            @Serializable
            data class ButtonRenderer(
                val icon: Icon,
                val navigationEndpoint: NavigationEndpoint,
            )
        }
    }
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/MusicCardShelfRenderer.kt
// ----------------------------------------------------------------------------

@Serializable
data class MusicCardShelfRenderer(
    val title: Runs,
    val subtitle: Runs,
    val thumbnail: ThumbnailRenderer,
    val header: Header?,
    val contents: List<Content>?,
    val buttons: List<Button>,
    val onTap: NavigationEndpoint,
    val subtitleBadges: List<Badges>?,
) {
    @Serializable
    data class Header(
        val musicCardShelfHeaderBasicRenderer: MusicCardShelfHeaderBasicRenderer,
    ) {
        @Serializable
        data class MusicCardShelfHeaderBasicRenderer(
            val title: Runs,
        )
    }

    @Serializable
    data class Content(
        val musicResponsiveListItemRenderer: MusicResponsiveListItemRenderer?,
    )
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/MusicCarouselShelfRenderer.kt
// ----------------------------------------------------------------------------

@Serializable
data class MusicCarouselShelfRenderer(
    val header: Header?,
    val contents: List<Content>,
    val itemSize: String,
    val numItemsPerColumn: Int?,
) {
    @Serializable
    data class Header(
        val musicCarouselShelfBasicHeaderRenderer: MusicCarouselShelfBasicHeaderRenderer,
    ) {
        @Serializable
        data class MusicCarouselShelfBasicHeaderRenderer(
            val strapline: Runs?,
            val title: Runs,
            val thumbnail: ThumbnailRenderer?,
            val moreContentButton: Button?,
        )
    }

    @Serializable
    data class Content(
        val musicTwoRowItemRenderer: MusicTwoRowItemRenderer?,
        val musicResponsiveListItemRenderer: MusicResponsiveListItemRenderer?,
        val musicMultiRowListItemRenderer: MusicMultiRowListItemRenderer?,
        val musicNavigationButtonRenderer: MusicNavigationButtonRenderer?, // navigation button in explore tab
    )
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/MusicDescriptionShelfRenderer.kt
// ----------------------------------------------------------------------------

@Serializable
data class MusicDescriptionShelfRenderer(
    val header: Runs?,
    val subheader: Runs?,
    val description: Runs?,
    val footer: Runs?,
)

// ----------------------------------------------------------------------------
// [MODELS] Source: models/MusicEditablePlaylistDetailHeaderRenderer.kt
// ----------------------------------------------------------------------------

@Serializable
data class MusicEditablePlaylistDetailHeaderRenderer(
    val header: Header,
    val editHeader: EditHeader
) {
    @Serializable
    data class Header(
        val musicDetailHeaderRenderer: MusicDetailHeaderRenderer?,
        val musicResponsiveHeaderRenderer: MusicResponsiveHeaderRenderer?
    )

    @Serializable
    data class EditHeader(
        val musicPlaylistEditHeaderRenderer: MusicPlaylistEditHeaderRenderer?
    )
}

@Serializable
data class MusicDetailHeaderRenderer(
    val title: Runs,
    val subtitle: Runs,
    val secondSubtitle: Runs,
    val description: Runs?,
    val thumbnail: ThumbnailRenderer,
    val menu: Menu,
)

@Serializable
data class MusicPlaylistEditHeaderRenderer(
    val editTitle: Runs?
)

// ----------------------------------------------------------------------------
// [MODELS] Source: models/MusicMultiRowImageItemRenderer.kt
// ----------------------------------------------------------------------------

@Serializable
data class MusicMultiRowImageItemRenderer(
    val title: Runs,
    val subtitle: Runs,
    val thumbnail: ThumbnailRenderer,
    val onTap: NavigationEndpoint,
)

// ----------------------------------------------------------------------------
// [MODELS] Source: models/MusicMultiRowListItemRenderer.kt
// ----------------------------------------------------------------------------

@Serializable
data class MusicMultiRowListItemRenderer(
    val title: Runs?,
    val subtitle: Runs?,
    @SerialName("secondSubtitle")
    val secondSubtitle: Runs? = null,
    @SerialName("secondarySubtitle")
    val secondarySubtitle: Runs? = null,
    val thumbnail: ThumbnailRenderer?,
    val onTap: NavigationEndpoint?,
    val playbackProgress: PlaybackProgress?,
    val displayStyle: String?,
    val menu: Menu?,
) {
    @Serializable
    data class PlaybackProgress(
        val value: Float? = null,
    )
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/MusicNavigationButtonRenderer.kt
// ----------------------------------------------------------------------------

@Serializable
data class MusicNavigationButtonRenderer(
    val buttonText: Runs,
    val solid: Solid?,
    val iconStyle: IconStyle?,
    val clickCommand: NavigationEndpoint,
) {
    @Serializable
    data class Solid(
        val leftStripeColor: Long,
    )

    @Serializable
    data class IconStyle(
        val icon: Icon,
    )
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/MusicPlaylistShelfRenderer.kt
// ----------------------------------------------------------------------------

@Serializable
data class MusicPlaylistShelfRenderer(
    val playlistId: String?,
    val contents: List<MusicShelfRenderer.Content> = emptyList(),
    val collapsedItemCount: Int? = null,
    val continuations: List<Continuation>? = null,
)

// ----------------------------------------------------------------------------
// [MODELS] Source: models/MusicQueueRenderer.kt
// ----------------------------------------------------------------------------

@Serializable
data class MusicQueueRenderer(
    val content: Content?,
    val header: Header?,
) {
    @Serializable
    data class Content(
        val playlistPanelRenderer: PlaylistPanelRenderer,
    )

    @Serializable
    data class Header(
        val musicQueueHeaderRenderer: MusicQueueHeaderRenderer?,
    ) {
        @Serializable
        data class MusicQueueHeaderRenderer(
            val title: Runs?,
            val subtitle: Runs?,
        )
    }
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/MusicResponsiveHeaderRenderer.kt
// ----------------------------------------------------------------------------

@Serializable
data class MusicResponsiveHeaderRenderer(
    val thumbnail: ThumbnailRenderer?,
    val buttons: List<Button>,
    val title: Runs,
    val subtitle: Runs,
    val secondSubtitle: Runs?,
    val straplineTextOne: Runs?,
    val description: DescriptionWrapper? = null,
    val facepile: FacepileWrapper? = null,
) {
    @Serializable
    data class Button(
        val musicPlayButtonRenderer: MusicPlayButtonRenderer?,
        val menuRenderer: Menu.MenuRenderer?,
        val toggleButtonRenderer: ToggleButtonRenderer?,
    ) {
        @Serializable
        data class MusicPlayButtonRenderer(
            val playNavigationEndpoint: NavigationEndpoint?,
        )

        @Serializable
        data class ToggleButtonRenderer(
            val defaultIcon: Icon?,
            val defaultServiceEndpoint: DefaultServiceEndpoint?,
            val toggledServiceEndpoint: ToggledServiceEndpoint?,
        )
    }
}

@Serializable
data class AvatarStackViewModel(
    val avatars: List<Avatar>?,
    val text: AvatarText?,
    val rendererContext: RendererContext?,
) {
    @Serializable
    data class Avatar(
        val avatarViewModel: AvatarViewModel?,
    )

    @Serializable
    data class AvatarViewModel(
        val image: AvatarImage?,
    )

    @Serializable
    data class AvatarImage(
        val sources: List<ImageSource>?,
    )

    @Serializable
    data class ImageSource(
        val url: String?,
    )

    @Serializable
    data class AvatarText(
        val content: String?,
    )

    @Serializable
    data class RendererContext(
        val commandContext: CommandContext?,
    )

    @Serializable
    data class CommandContext(
        val onTap: OnTap?,
    )

    @Serializable
    data class OnTap(
        val innertubeCommand: InnerTubeBrowseCommand?,
    )

    @Serializable
    data class InnerTubeBrowseCommand(
        val browseEndpoint: BrowseEndpoint?,
    )

    @Serializable
    data class BrowseEndpoint(
        val browseId: String?,
    )
}

@Serializable
data class DescriptionWrapper(
    val musicDescriptionShelfRenderer: MusicDescriptionShelfRenderer?,
)

@Serializable
data class FacepileWrapper(
    val avatarStackViewModel: AvatarStackViewModel?,
)

// ----------------------------------------------------------------------------
// [MODELS] Source: models/MusicResponsiveListItemRenderer.kt
// ----------------------------------------------------------------------------



/**
 * Typical list item
 * Used in [MusicCarouselShelfRenderer], [MusicShelfRenderer]
 * Appears in quick picks, search results, table items, etc.
 */
@Serializable
data class MusicResponsiveListItemRenderer(
    val badges: List<Badges>?,
    val fixedColumns: List<FlexColumn>?,
    val flexColumns: List<FlexColumn>,
    val thumbnail: ThumbnailRenderer?,
    val menu: Menu?,
    val playlistItemData: PlaylistItemData?,
    val overlay: Overlay?,
    val navigationEndpoint: NavigationEndpoint?,
) {
    val isSong: Boolean
        get() = navigationEndpoint == null
            || navigationEndpoint.watchEndpoint != null
            || navigationEndpoint.watchPlaylistEndpoint != null
            || overlay?.musicItemThumbnailOverlayRenderer
                ?.content?.musicPlayButtonRenderer
                ?.playNavigationEndpoint?.watchEndpoint != null
    val isPlaylist: Boolean
        get() = navigationEndpoint?.browseEndpoint?.browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType == MUSIC_PAGE_TYPE_PLAYLIST
    val isAlbum: Boolean
        get() = navigationEndpoint?.browseEndpoint?.browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType == MUSIC_PAGE_TYPE_ALBUM ||
                navigationEndpoint?.browseEndpoint?.browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType == MUSIC_PAGE_TYPE_AUDIOBOOK
    val isArtist: Boolean
        get() = navigationEndpoint?.browseEndpoint?.browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType == MUSIC_PAGE_TYPE_ARTIST
                || navigationEndpoint?.browseEndpoint?.browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType == MUSIC_PAGE_TYPE_LIBRARY_ARTIST
    val isPodcast: Boolean
        get() = navigationEndpoint?.browseEndpoint?.browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType == MUSIC_PAGE_TYPE_PODCAST_SHOW_DETAIL_PAGE
    val isUserChannel: Boolean
        get() = navigationEndpoint?.browseEndpoint?.browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType == MUSIC_PAGE_TYPE_USER_CHANNEL
    val isEpisode: Boolean
        get() {
            // Method 1: Check browse endpoint (for episode detail pages)
            if (navigationEndpoint?.browseEndpoint?.browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType == MUSIC_PAGE_TYPE_NON_MUSIC_AUDIO_TRACK_PAGE) {
                return true
            }
            // Method 2: Check if first subtitle text is "Episode" (for search results)
            val firstSubtitleText = flexColumns.getOrNull(1)
                ?.musicResponsiveListItemFlexColumnRenderer
                ?.text?.runs?.firstOrNull()?.text
            if (firstSubtitleText == "Episode") {
                return true
            }
            // Method 3: Check for podcast link in subtitle (backup detection).
            //
            // Episode items that appear in filtered search results may have:
            //   - navigationEndpoint.watchEndpoint  (playable) → isSong=true would wrongly match
            //   - playlistItemData = null            (not in a playlist context)
            //   - subtitle: [date · podcast-name]   (podcast-name links to PODCAST_SHOW_DETAIL_PAGE)
            //
            // The presence of a PODCAST_SHOW_DETAIL_PAGE browse link in the subtitle is unique to
            // episodes — regular songs never carry such a link.  We accept either a playlistItemData
            // videoId OR a direct watchEndpoint videoId to handle both playlist and standalone contexts.
            val hasPodcastLink = flexColumns.getOrNull(1)
                ?.musicResponsiveListItemFlexColumnRenderer
                ?.text?.runs?.any { run ->
                    run.navigationEndpoint?.browseEndpoint
                        ?.browseEndpointContextSupportedConfigs
                        ?.browseEndpointContextMusicConfig
                        ?.pageType == MUSIC_PAGE_TYPE_PODCAST_SHOW_DETAIL_PAGE
                } == true
            val hasVideoId = videoId != null
            return hasPodcastLink && hasVideoId
        }

    val musicVideoType: String?
        get() =
            overlay
                ?.musicItemThumbnailOverlayRenderer
                ?.content
                ?.musicPlayButtonRenderer
                ?.playNavigationEndpoint
                ?.musicVideoType
                ?: navigationEndpoint?.musicVideoType

    val videoId: String?
        get() = playlistItemData?.videoId
            ?: flexColumns.firstOrNull()
                ?.musicResponsiveListItemFlexColumnRenderer
                ?.text?.runs?.firstOrNull()
                ?.navigationEndpoint?.watchEndpoint?.videoId
            ?: overlay?.musicItemThumbnailOverlayRenderer
                ?.content?.musicPlayButtonRenderer
                ?.playNavigationEndpoint?.watchEndpoint?.videoId

    val playlistSetVideoId: String?
        get() = playlistItemData?.playlistSetVideoId
            ?: overlay?.musicItemThumbnailOverlayRenderer
                ?.content?.musicPlayButtonRenderer
                ?.playNavigationEndpoint?.watchEndpoint?.playlistSetVideoId

    @Serializable
    data class FlexColumn(
        @JsonNames("musicResponsiveListItemFixedColumnRenderer")
        val musicResponsiveListItemFlexColumnRenderer: MusicResponsiveListItemFlexColumnRenderer,
    ) {
        @Serializable
        data class MusicResponsiveListItemFlexColumnRenderer(
            val text: Runs?,
        )
    }

    @Serializable
    data class PlaylistItemData(
        val playlistSetVideoId: String?,
        val videoId: String,
    )

    @Serializable
    data class Overlay(
        val musicItemThumbnailOverlayRenderer: MusicItemThumbnailOverlayRenderer,
    ) {
        @Serializable
        data class MusicItemThumbnailOverlayRenderer(
            val content: Content,
        ) {
            @Serializable
            data class Content(
                val musicPlayButtonRenderer: MusicPlayButtonRenderer,
            ) {
                @Serializable
                data class MusicPlayButtonRenderer(
                    val playNavigationEndpoint: NavigationEndpoint?,
                )
            }
        }
    }
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/MusicShelfRenderer.kt
// ----------------------------------------------------------------------------

@Serializable
data class MusicShelfRenderer(
    val title: Runs?,
    val contents: List<Content>?,
    val continuations: List<Continuation>?,
    val bottomEndpoint: NavigationEndpoint?,
    val moreContentButton: Button?,
) {
    @Serializable
    data class Content(
        val musicResponsiveListItemRenderer: MusicResponsiveListItemRenderer?,
        val musicMultiRowListItemRenderer: MusicMultiRowListItemRenderer?,
        val continuationItemRenderer: ContinuationItemRenderer?,
    )
}

fun List<MusicShelfRenderer.Content>.getItems(): List<MusicResponsiveListItemRenderer> =
    mapNotNull { it.musicResponsiveListItemRenderer }

@JvmName("getContinuationFromShelfContents")
fun List<MusicShelfRenderer.Content>.getContinuation(): String? =
    firstOrNull { it.continuationItemRenderer != null }
        ?.continuationItemRenderer
        ?.continuationEndpoint
        ?.continuationCommand
        ?.token

// ----------------------------------------------------------------------------
// [MODELS] Source: models/MusicTwoRowItemRenderer.kt
// ----------------------------------------------------------------------------

/**
 * Two row: a big thumbnail, a title, and a subtitle
 * Used in [GridRenderer] and [MusicCarouselShelfRenderer]
 * Item type: song, video, album, playlist, artist
 */
@Serializable
data class MusicTwoRowItemRenderer(
    val title: Runs,
    val subtitle: Runs?,
    val subtitleBadges: List<Badges>?,
    val menu: Menu?,
    val thumbnailRenderer: ThumbnailRenderer,
    val navigationEndpoint: NavigationEndpoint,
    val thumbnailOverlay: MusicResponsiveListItemRenderer.Overlay?,
) {
    val isSong: Boolean
        get() = navigationEndpoint.endpoint is WatchEndpoint
    val isPlaylist: Boolean
        get() =
            navigationEndpoint.browseEndpoint
                ?.browseEndpointContextSupportedConfigs
                ?.browseEndpointContextMusicConfig
                ?.pageType ==
                MUSIC_PAGE_TYPE_PLAYLIST
    val isAlbum: Boolean
        get() =
            navigationEndpoint.browseEndpoint
                ?.browseEndpointContextSupportedConfigs
                ?.browseEndpointContextMusicConfig
                ?.pageType ==
                MUSIC_PAGE_TYPE_ALBUM ||
                navigationEndpoint.browseEndpoint
                    ?.browseEndpointContextSupportedConfigs
                    ?.browseEndpointContextMusicConfig
                    ?.pageType ==
                MUSIC_PAGE_TYPE_AUDIOBOOK
    val isArtist: Boolean
        get() =
            navigationEndpoint.browseEndpoint
                ?.browseEndpointContextSupportedConfigs
                ?.browseEndpointContextMusicConfig
                ?.pageType ==
                MUSIC_PAGE_TYPE_ARTIST
    val isPodcast: Boolean
        get() =
            navigationEndpoint.browseEndpoint
                ?.browseEndpointContextSupportedConfigs
                ?.browseEndpointContextMusicConfig
                ?.pageType ==
                MUSIC_PAGE_TYPE_PODCAST_SHOW_DETAIL_PAGE
    val isUserChannel: Boolean
        get() =
            navigationEndpoint.browseEndpoint
                ?.browseEndpointContextSupportedConfigs
                ?.browseEndpointContextMusicConfig
                ?.pageType ==
                MUSIC_PAGE_TYPE_USER_CHANNEL
    val isEpisode: Boolean
        get() =
            navigationEndpoint.browseEndpoint
                ?.browseEndpointContextSupportedConfigs
                ?.browseEndpointContextMusicConfig
                ?.pageType ==
                MUSIC_PAGE_TYPE_NON_MUSIC_AUDIO_TRACK_PAGE

    val musicVideoType: String?
        get() =
            thumbnailOverlay
                ?.musicItemThumbnailOverlayRenderer
                ?.content
                ?.musicPlayButtonRenderer
                ?.playNavigationEndpoint
                ?.musicVideoType
                ?: navigationEndpoint.musicVideoType
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/NavigationEndpoint.kt
// ----------------------------------------------------------------------------

@Serializable
data class NavigationEndpoint(
    val watchEndpoint: WatchEndpoint? = null,
    val watchPlaylistEndpoint: WatchEndpoint? = null,
    val browseEndpoint: BrowseEndpoint? = null,
    val searchEndpoint: SearchEndpoint? = null,
    val queueAddEndpoint: QueueAddEndpoint? = null,
    val shareEntityEndpoint: ShareEntityEndpoint? = null,
    val feedbackEndpoint: FeedbackEndpoint? = null,
    val urlEndpoint: UrlEndpoint? = null,
    val deletePrivatelyOwnedEntityCommand: DeletePrivatelyOwnedEntityCommand? = null,
    val confirmDialogEndpoint: ConfirmDialogEndpoint? = null,
) {
    @Serializable
    data class DeletePrivatelyOwnedEntityCommand(
        val entityId: String,
    )

    @Serializable
    data class ConfirmDialogEndpoint(
        val content: ConfirmDialogContent? = null,
    ) {
        @Serializable
        data class ConfirmDialogContent(
            val confirmDialogRenderer: ConfirmDialogRenderer? = null,
        )

        @Serializable
        data class ConfirmDialogRenderer(
            val confirmButton: ConfirmButton? = null,
        )

        @Serializable
        data class ConfirmButton(
            val buttonRenderer: ConfirmButtonRenderer? = null,
        )

        @Serializable
        data class ConfirmButtonRenderer(
            val command: ConfirmCommand? = null,
        )

        @Serializable
        data class ConfirmCommand(
            val musicDeletePrivatelyOwnedEntityCommand: DeletePrivatelyOwnedEntityCommand? = null,
        )
    }
    val endpoint: Endpoint?
        get() =
            watchEndpoint
                ?: watchPlaylistEndpoint
                ?: browseEndpoint
                ?: searchEndpoint
                ?: queueAddEndpoint
                ?: shareEntityEndpoint

    val anyWatchEndpoint: WatchEndpoint?
        get() = watchEndpoint
            ?: watchPlaylistEndpoint

    val musicVideoType: String?
        get() = anyWatchEndpoint
            ?.watchEndpointMusicSupportedConfigs
            ?.watchEndpointMusicConfig
            ?.musicVideoType
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/PlaylistDeleteBody.kt
// ----------------------------------------------------------------------------

@Serializable
data class PlaylistDeleteBody(
    val context: Context,
    val playlistId: String
)

// ----------------------------------------------------------------------------
// [MODELS] Source: models/PlaylistPanelRenderer.kt
// ----------------------------------------------------------------------------

@Serializable
data class PlaylistPanelRenderer(
    val title: String?,
    val titleText: Runs?,
    val shortBylineText: Runs?,
    val contents: List<Content>,
    val isInfinite: Boolean?,
    val numItemsToShow: Int?,
    val playlistId: String?,
    val continuations: List<Continuation>?,
) {
    @Serializable
    data class Content(
        val playlistPanelVideoRenderer: PlaylistPanelVideoRenderer?,
        val automixPreviewVideoRenderer: AutomixPreviewVideoRenderer?,
    )
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/PlaylistPanelVideoRenderer.kt
// ----------------------------------------------------------------------------

@Serializable
data class PlaylistPanelVideoRenderer(
    val title: Runs?,
    val lengthText: Runs?,
    val longBylineText: Runs?,
    val shortBylineText: Runs?,
    val badges: List<Badges>?,
    val videoId: String?,
    val playlistSetVideoId: String?,
    val selected: Boolean,
    val thumbnail: Thumbnails,
    val unplayableText: Runs?,
    val menu: Menu?,
    val navigationEndpoint: NavigationEndpoint,
)

// ----------------------------------------------------------------------------
// [MODELS] Source: models/ResponseContext.kt
// ----------------------------------------------------------------------------

@Serializable
data class ResponseContext(
    val visitorData: String?,
    val serviceTrackingParams: List<ServiceTrackingParam>?,
) {
    @Serializable
    data class ServiceTrackingParam(
        val params: List<Param>,
        val service: String,
    ) {
        @Serializable
        data class Param(
            val key: String,
            val value: String,
        )
    }
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/ReturnYouTubeDislikeResponse.kt
// ----------------------------------------------------------------------------

@Serializable
data class ReturnYouTubeDislikeResponse(
    val id: String? = null,
    val dateCreated: String? = null,
    val likes: Int? = null,
    val dislikes: Int? = null,
    val rating: Double? = null,
    val viewCount: Int? = null,
    val deleted: Boolean? = null,
)

// ----------------------------------------------------------------------------
// [MODELS] Source: models/Runs.kt
// ----------------------------------------------------------------------------

@Serializable
data class Runs(
    val runs: List<Run>?,
)

@Serializable
data class Run(
    val text: String,
    val navigationEndpoint: NavigationEndpoint?,
)

fun List<Run>.splitBySeparator(): List<List<Run>> {
    val res = mutableListOf<List<Run>>()
    var tmp = mutableListOf<Run>()
    forEach { run ->
        if (run.text.trim() == "•") {
            res.add(tmp)
            tmp = mutableListOf()
        } else {
            tmp.add(run)
        }
    }
    res.add(tmp)
    return res
}

fun List<Run>.splitArtistsByConjunction(): List<Run> {
    val result = mutableListOf<Run>()
    val words = ArtistConjunctions.conjunctions
    val conjunctionPattern = Regex(
        if (words.isNotEmpty()) " (${words.joinToString("|") { Regex.escape(it) }}) | & "
        else " & ",
        RegexOption.IGNORE_CASE
    )
    forEach { run ->
        val text = run.text
        if (text.contains(conjunctionPattern)) {
            val parts = text.split(conjunctionPattern)
            parts.forEachIndexed { index, part ->
                if (part.isNotBlank()) {
                    result.add(Run(part.trim(), if (index == 0) run.navigationEndpoint else null))
                }
            }
        } else if (text.trim().equals("&", ignoreCase = true) ||
                text.trim().equals("•") ||
                words.any { text.trim().equals(it, ignoreCase = true) }
        ) {
        } else {
            result.add(run)
        }
    }
    return result
}

object ArtistConjunctions {
    var conjunctions: List<String> = listOf("and")
}

fun List<List<Run>>.clean(): List<List<Run>> {
    val firstGroup = getOrNull(0) ?: return this
    val hasArtistSignals = firstGroup.any { it.navigationEndpoint != null } ||
        firstGroup.any { it.text.contains(" & ") } ||
        ArtistConjunctions.conjunctions.any { conj ->
            firstGroup.any { it.text.trim().equals(conj, ignoreCase = true) }
        }
    return if (hasArtistSignals) this else drop(1)
}

fun List<Run>.oddElements() =
    filterIndexed { index, _ ->
        index % 2 == 0
    }

// ----------------------------------------------------------------------------
// [MODELS] Source: models/SearchSuggestions.kt
// ----------------------------------------------------------------------------

data class SearchSuggestions(
    val queries: List<String>,
    val recommendedItems: List<YTItem>,
)

// ----------------------------------------------------------------------------
// [MODELS] Source: models/SearchSuggestionsSectionRenderer.kt
// ----------------------------------------------------------------------------

@Serializable
data class SearchSuggestionsSectionRenderer(
    val contents: List<Content>,
) {
    @Serializable
    data class Content(
        val searchSuggestionRenderer: SearchSuggestionRenderer?,
        val musicResponsiveListItemRenderer: MusicResponsiveListItemRenderer?,
    ) {
        @Serializable
        data class SearchSuggestionRenderer(
            val suggestion: Runs,
            val navigationEndpoint: NavigationEndpoint,
        )
    }
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/SectionListRenderer.kt
// ----------------------------------------------------------------------------

@Serializable
data class SectionListRenderer(
    val header: Header?,
    val contents: List<Content>?,
    val continuations: List<Continuation>?,
) {
    @Serializable
    data class Header(
        val chipCloudRenderer: ChipCloudRenderer?,
    ) {
        @Serializable
        data class ChipCloudRenderer(
            val chips: List<Chip>,
        ) {
            @Serializable
            data class Chip(
                val chipCloudChipRenderer: ChipCloudChipRenderer,
            ) {
                @Serializable
                data class ChipCloudChipRenderer(
                    val isSelected: Boolean = false,
                    val navigationEndpoint: NavigationEndpoint? = null,
                    val onDeselectedCommand: NavigationEndpoint? = null,
                    // The close button doesn't have the following two fields
                    val text: Runs?,
                    val uniqueId: String?,
                )
            }
        }
    }

    @OptIn(ExperimentalSerializationApi::class)
    @Serializable
    data class Content(
        @JsonNames("musicImmersiveCarouselShelfRenderer")
        val musicCarouselShelfRenderer: MusicCarouselShelfRenderer?,
        val musicShelfRenderer: MusicShelfRenderer?,
        val musicCardShelfRenderer: MusicCardShelfRenderer?,
        val musicPlaylistShelfRenderer: MusicPlaylistShelfRenderer?,
        val musicDescriptionShelfRenderer: MusicDescriptionShelfRenderer?,
        val musicResponsiveHeaderRenderer: MusicResponsiveHeaderRenderer?,
        val musicEditablePlaylistDetailHeaderRenderer: MusicEditablePlaylistDetailHeaderRenderer?,
        val gridRenderer: GridRenderer?,
        val itemSectionRenderer: ItemSectionRenderer?,
    )
}

@Serializable
data class ItemSectionRenderer(
    val contents: List<Content>?,
    val header: Header? = null,
) {
    @Serializable
    data class Content(
        val musicResponsiveListItemRenderer: MusicResponsiveListItemRenderer?,
    )

    @Serializable
    data class Header(
        val itemSectionTabbedHeaderRenderer: ItemSectionTabbedHeaderRenderer?,
    )

    @Serializable
    data class ItemSectionTabbedHeaderRenderer(
        val title: Runs?,
    )
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/SubscriptionButton.kt
// ----------------------------------------------------------------------------

@Serializable
data class SubscriptionButton(
    val subscribeButtonRenderer: SubscribeButtonRenderer,
) {
    @Serializable
    data class SubscribeButtonRenderer(
        val subscribed: Boolean,
        val channelId: String,
        val longSubscriberCountText: Runs? = null,
        val shortSubscriberCountText: Runs? = null,
    )
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/Tabs.kt
// ----------------------------------------------------------------------------

@Serializable
data class Tabs(
    val tabs: List<Tab>,
) {
    @Serializable
    data class Tab(
        val tabRenderer: TabRenderer,
    ) {
        @Serializable
        data class TabRenderer(
            val title: String?,
            val content: Content?,
            val endpoint: NavigationEndpoint?,
        ) {
            @Serializable
            data class Content(
                val sectionListRenderer: SectionListRenderer?,
                val musicQueueRenderer: MusicQueueRenderer?,
            )
        }
    }
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/TasteProfile.kt
// ----------------------------------------------------------------------------

data class TasteArtist(
    val name: String,
    val selectionValue: String,
    val impressionValue: String,
)

data class TasteProfile(
    val artists: Map<String, TasteArtist>,
)

// ----------------------------------------------------------------------------
// [MODELS] Source: models/ThumbnailRenderer.kt
// ----------------------------------------------------------------------------

@OptIn(ExperimentalSerializationApi::class)
@Serializable
data class ThumbnailRenderer(
    @JsonNames("croppedSquareThumbnailRenderer")
    val musicThumbnailRenderer: MusicThumbnailRenderer?,
    val musicAnimatedThumbnailRenderer: MusicAnimatedThumbnailRenderer?,
    val croppedSquareThumbnailRenderer: MusicThumbnailRenderer?,
) {
    @Serializable
    data class MusicThumbnailRenderer(
        val thumbnail: Thumbnails,
        val thumbnailCrop: String?,
        val thumbnailScale: String?,
    ) {
        fun getThumbnailUrl() = thumbnail.thumbnails.lastOrNull()?.url
    }

    @Serializable
    data class MusicAnimatedThumbnailRenderer(
        val animatedThumbnail: Thumbnails,
        val backupRenderer: MusicThumbnailRenderer,
    )
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/Thumbnails.kt
// ----------------------------------------------------------------------------

@Serializable
data class Thumbnails(
    val thumbnails: List<Thumbnail>,
)

@Serializable
data class Thumbnail(
    val url: String,
    val width: Int?,
    val height: Int?,
)

// ----------------------------------------------------------------------------
// [MODELS] Source: models/TwoColumnBrowseResultsRenderer.kt
// ----------------------------------------------------------------------------

@Serializable
data class TwoColumnBrowseResultsRenderer(
    val secondaryContents: SecondaryContents?,
    val tabs: List<Tabs.Tab>?
) {
    @Serializable
    data class SecondaryContents(
        val sectionListRenderer: SectionListRenderer?
    )

    @Serializable
    data class SectionListRenderer(
        val contents: List<Content>?,
        val continuations: List<Continuation>?,
    ) {
        @Serializable
        data class Content(
            val musicPlaylistShelfRenderer: MusicPlaylistShelfRenderer?,
            val musicShelfRenderer: MusicShelfRenderer?
        )
    }
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/UrlEndpoint.kt
// ----------------------------------------------------------------------------

@Serializable
data class UrlEndpoint(
    val url: String? = null,
    val target: String? = null,
)

// ----------------------------------------------------------------------------
// [MODELS] Source: models/YTItem.kt
// ----------------------------------------------------------------------------

sealed class YTItem {
    abstract val id: String
    abstract val title: String
    abstract val thumbnail: String?
    abstract val explicit: Boolean
    abstract val shareLink: String
}

class Artist(
    name: String,
    val id: String?,
) {
    val name: String = run {
        val clean = name.toString().replace(Regex("\\d+"), "").trim()
        if (clean.isBlank()) "Apple Music Artist" else clean
    }

    operator fun component1(): String = name
    operator fun component2(): String? = id

    fun copy(name: String = this.name, id: String? = this.id) = Artist(name, id)

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is Artist) return false
        return name == other.name && id == other.id
    }

    override fun hashCode(): Int {
        var result = name.hashCode()
        result = 31 * result + (id?.hashCode() ?: 0)
        return result
    }

    override fun toString(): String = "Artist(name=$name, id=$id)"
}

data class Album(
    val name: String,
    val id: String,
)

data class SongItem(
    override val id: String,
    override val title: String,
    val artists: List<Artist>,
    val album: Album? = null,
    val duration: Int? = null,
    val musicVideoType: String? = null,
    val chartPosition: Int? = null,
    val chartChange: String? = null,
    override val thumbnail: String,
    override val explicit: Boolean = false,
    val endpoint: WatchEndpoint? = null,
    val setVideoId: String? = null,
    val libraryAddToken: String? = null,
    val libraryRemoveToken: String? = null,
    val historyRemoveToken: String? = null,
    val isEpisode: Boolean = false,
    val uploadEntityId: String? = null
) : YTItem() {
    val isVideoSong: Boolean
        get() = musicVideoType != null && musicVideoType != MUSIC_VIDEO_TYPE_ATV

    override val shareLink: String
        get() = if (id.startsWith("am_")) {
            "https://music.apple.com/song/${id.removePrefix("am_")}"
        } else {
            "https://music.youtube.com/watch?v=$id"
        }
}

data class AlbumItem(
    val browseId: String,
    val playlistId: String,
    override val id: String = browseId,
    override val title: String,
    val artists: List<Artist>?,
    val year: Int? = null,
    override val thumbnail: String,
    override val explicit: Boolean = false,
) : YTItem() {
    override val shareLink: String
        get() = if (id.startsWith("am_")) {
            "https://music.apple.com/album/${id.removePrefix("am_")}"
        } else {
            "https://music.youtube.com/playlist?list=$playlistId"
        }
}

data class PlaylistItem(
    override val id: String,
    override val title: String,
    val author: Artist?,
    val songCountText: String?,
    override val thumbnail: String?,
    val playEndpoint: WatchEndpoint?,
    val shuffleEndpoint: WatchEndpoint?,
    val radioEndpoint: WatchEndpoint?,
    val isEditable: Boolean = false,
    val isPodcast: Boolean = false,
    val description: String? = null,
    val authorAvatarUrl: String? = null,
) : YTItem() {
    override val explicit: Boolean
        get() = false
    override val shareLink: String
        get() = if (id.startsWith("am_") || id.startsWith("am_pl_")) {
            val cleanId = id.removePrefix("am_pl_").removePrefix("am_")
            "https://music.apple.com/playlist/$cleanId"
        } else {
            "https://music.youtube.com/playlist?list=$id"
        }
}

class ArtistItem(
    override val id: String,
    title: String,
    override val thumbnail: String?,
    val channelId: String? = null,
    val playEndpoint: WatchEndpoint? = null,
    val shuffleEndpoint: WatchEndpoint?,
    val radioEndpoint: WatchEndpoint?,
    val isProfile: Boolean = false,
) : YTItem() {
    override val title: String = run {
        val clean = title.toString().replace(Regex("\\d+"), "").trim()
        if (clean.isBlank()) "Apple Music Artist" else clean
    }

    override val explicit: Boolean
        get() = false
    override val shareLink: String
        get() = if (id.startsWith("am_")) {
            "https://music.apple.com/artist/${id.removePrefix("am_")}"
        } else {
            "https://music.youtube.com/channel/$id"
        }

    operator fun component1(): String = id
    operator fun component2(): String = title
    operator fun component3(): String? = thumbnail
    operator fun component4(): String? = channelId
    operator fun component5(): WatchEndpoint? = playEndpoint
    operator fun component6(): WatchEndpoint? = shuffleEndpoint
    operator fun component7(): WatchEndpoint? = radioEndpoint
    operator fun component8(): Boolean = isProfile

    fun copy(
        id: String = this.id,
        title: String = this.title,
        thumbnail: String? = this.thumbnail,
        channelId: String? = this.channelId,
        playEndpoint: WatchEndpoint? = this.playEndpoint,
        shuffleEndpoint: WatchEndpoint? = this.shuffleEndpoint,
        radioEndpoint: WatchEndpoint? = this.radioEndpoint,
        isProfile: Boolean = this.isProfile,
    ) = ArtistItem(id, title, thumbnail, channelId, playEndpoint, shuffleEndpoint, radioEndpoint, isProfile)

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is ArtistItem) return false
        return id == other.id &&
                title == other.title &&
                thumbnail == other.thumbnail &&
                channelId == other.channelId &&
                playEndpoint == other.playEndpoint &&
                shuffleEndpoint == other.shuffleEndpoint &&
                radioEndpoint == other.radioEndpoint &&
                isProfile == other.isProfile
    }

    override fun hashCode(): Int {
        var result = id.hashCode()
        result = 31 * result + title.hashCode()
        result = 31 * result + (thumbnail?.hashCode() ?: 0)
        result = 31 * result + (channelId?.hashCode() ?: 0)
        result = 31 * result + (playEndpoint?.hashCode() ?: 0)
        result = 31 * result + (shuffleEndpoint?.hashCode() ?: 0)
        result = 31 * result + (radioEndpoint?.hashCode() ?: 0)
        result = 31 * result + isProfile.hashCode()
        return result
    }

    override fun toString(): String = "ArtistItem(id=$id, title=$title, thumbnail=$thumbnail, channelId=$channelId, playEndpoint=$playEndpoint, shuffleEndpoint=$shuffleEndpoint, radioEndpoint=$radioEndpoint, isProfile=$isProfile)"
}

data class PodcastItem(
    override val id: String,
    override val title: String,
    val author: Artist?,
    val episodeCountText: String?,
    override val thumbnail: String?,
    val playEndpoint: WatchEndpoint?,
    val shuffleEndpoint: WatchEndpoint?,
    val libraryAddToken: String? = null,
    val libraryRemoveToken: String? = null,
    val channelId: String? = null,
) : YTItem() {
    override val explicit: Boolean
        get() = false
    override val shareLink: String
        get() = "https://music.youtube.com/playlist?list=$id"

    fun asPlaylistItem() = PlaylistItem(
        id = id,
        title = title,
        author = author,
        songCountText = episodeCountText,
        thumbnail = thumbnail,
        playEndpoint = playEndpoint,
        shuffleEndpoint = shuffleEndpoint,
        radioEndpoint = null,
        isEditable = false,
        isPodcast = true
    )
}

data class EpisodeItem(
    override val id: String,
    override val title: String,
    val author: Artist?,
    val podcast: Album? = null,
    val duration: Int? = null,
    val publishDateText: String? = null,
    override val thumbnail: String,
    override val explicit: Boolean = false,
    val endpoint: WatchEndpoint? = null,
    val libraryAddToken: String? = null,
    val libraryRemoveToken: String? = null,
    val markAsPlayedToken: String? = null,
    val markAsUnplayedToken: String? = null,
) : YTItem() {
    override val shareLink: String
        get() = "https://music.youtube.com/watch?v=$id"

    fun asSongItem() = SongItem(
        id = id,
        title = title,
        artists = listOfNotNull(author),
        album = podcast,
        duration = duration,
        thumbnail = thumbnail,
        explicit = explicit,
        endpoint = endpoint,
        isEpisode = true,
        libraryAddToken = libraryAddToken,
        libraryRemoveToken = libraryRemoveToken,
    )
}

fun <T : YTItem> List<T>.filterExplicit(enabled: Boolean = true) =
    if (enabled) {
        filter { !it.explicit }
    } else {
        this
    }

fun <T : YTItem> List<T>.filterVideoSongs(disableVideos: Boolean = false) =
    if (disableVideos) {
        filterNot { it is SongItem && it.isVideoSong }
    } else {
        this
    }

fun <T : YTItem> List<T>.filterYoutubeShorts(enabled: Boolean = false) =
    if (enabled) {
        filterNot { it is PlaylistItem && it.id.startsWith("SS") }
    } else {
        this
    }

fun <T : YTItem> List<T>.filterBlockedAndDisliked(
    blockedArtists: Set<String>,
    dislikedSongs: Set<String>
): List<T> {
    if (blockedArtists.isEmpty() && dislikedSongs.isEmpty()) return this
    return filter { item ->
        val artistNames = when (item) {
            is SongItem -> item.artists.map { it.name }
            is AlbumItem -> item.artists?.map { it.name }.orEmpty()
            is ArtistItem -> listOf(item.title)
            is PlaylistItem -> item.author?.let { listOf(it.name) }.orEmpty()
            is PodcastItem -> item.author?.let { listOf(it.name) }.orEmpty()
            is EpisodeItem -> item.author?.let { listOf(it.name) }.orEmpty()
            else -> emptyList()
        }
        val isBlocked = artistNames.any { name ->
            blockedArtists.any { blocked -> blocked.equals(name, ignoreCase = true) }
        }
        val isDisliked = dislikedSongs.contains(item.id) || dislikedSongs.any { disliked -> disliked.equals(item.title, ignoreCase = true) }
        !isBlocked && !isDisliked
    }
}

fun <T : YTItem> List<T>.filterContentModeration(enabled: Boolean = true): List<T> =
    if (enabled) {
        filter { com.listrovia.innertube.SongContentModerator.isItemAllowed(it) }
    } else {
        this
    }

// ----------------------------------------------------------------------------
// [MODELS] Source: models/YouTubeClient.kt
// ----------------------------------------------------------------------------

@Serializable
data class YouTubeClient(
    val clientName: String,
    val clientVersion: String,
    val clientId: String,
    val userAgent: String,
    val osName: String? = null,
    val osVersion: String? = null,
    val deviceMake: String? = null,
    val deviceModel: String? = null,
    val androidSdkVersion: String? = null,
    val buildId: String? = null,
    val cronetVersion: String? = null,
    val packageName: String? = null,
    val friendlyName: String? = null,
    val loginSupported: Boolean = false,
    val loginRequired: Boolean = false,
    val useSignatureTimestamp: Boolean = false,
    val isEmbedded: Boolean = false,
    val useWebPoTokens: Boolean = false,
) {
    fun toContext(locale: YouTubeLocale, visitorData: String?, dataSyncId: String?) = Context(
        client = Context.Client(
            clientName = clientName,
            clientVersion = clientVersion,
            osName = osName,
            osVersion = osVersion,
            deviceMake = deviceMake,
            deviceModel = deviceModel,
            androidSdkVersion = androidSdkVersion,
            gl = locale.gl,
            hl = locale.hl,
            visitorData = visitorData
        ),
        user = Context.User(
            onBehalfOfUser = if (loginSupported) dataSyncId else null
        ),
    )

    companion object {
        const val USER_AGENT_WEB = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0"

        const val ORIGIN_YOUTUBE_MUSIC = "https://music.youtube.com"
        const val REFERER_YOUTUBE_MUSIC = "$ORIGIN_YOUTUBE_MUSIC/"
        const val API_URL_YOUTUBE_MUSIC = "$ORIGIN_YOUTUBE_MUSIC/youtubei/v1/"

        val WEB = YouTubeClient(
            clientName = "WEB",
            clientVersion = "2.20260213.00.00",
            clientId = "1",
            userAgent = USER_AGENT_WEB,
        )

        val WEB_REMIX = YouTubeClient(
            clientName = "WEB_REMIX",
            clientVersion = "1.20260213.01.00",
            clientId = "67",
            userAgent = USER_AGENT_WEB,
            loginSupported = true,
            useSignatureTimestamp = true,
            useWebPoTokens = true,
        )

        val WEB_CREATOR = YouTubeClient(
            clientName = "WEB_CREATOR",
            clientVersion = "1.20260213.00.00",
            clientId = "62",
            userAgent = USER_AGENT_WEB,
            loginSupported = true,
            loginRequired = true,
            useSignatureTimestamp = true,
            useWebPoTokens = true,
        )

        val TVHTML5 = YouTubeClient(
            clientName = "TVHTML5",
            clientVersion = "7.20260213.00.00",
            clientId = "7",
            userAgent = "Mozilla/5.0(SMART-TV; Linux; Tizen 4.0.0.2) AppleWebkit/605.1.15 (KHTML, like Gecko) SamsungBrowser/9.2 TV Safari/605.1.15",
            loginSupported = true,
            loginRequired = true,
            useSignatureTimestamp = true,
            useWebPoTokens = true,
        )

        /**
         * Embedded player that can bypass age-restriction.
         * Does not require login for age-restricted content.
         */
        val TVHTML5_SIMPLY_EMBEDDED_PLAYER = YouTubeClient(
            clientName = "TVHTML5_SIMPLY_EMBEDDED_PLAYER",
            clientVersion = "2.0",
            clientId = "85",
            userAgent = "Mozilla/5.0 (PlayStation; PlayStation 4/12.02) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Safari/605.1.15",
            loginSupported = true,
            loginRequired = false,
            useSignatureTimestamp = true,
            isEmbedded = true,
        )

        val IOS = YouTubeClient(
            clientName = "IOS",
            clientVersion = "21.03.1",
            clientId = "5",
            userAgent = "com.google.ios.youtube/21.03.1 (iPhone16,2; U; CPU iOS 18_2 like Mac OS X;)",
            osVersion = "18.2.22C152",
        )

        val MOBILE = YouTubeClient(
            clientName = "ANDROID",
            clientVersion = "21.03.38",
            clientId = "3",
            userAgent = "com.google.android.youtube/21.03.38 (Linux; U; Android 14) gzip",
            loginSupported = true,
            useSignatureTimestamp = true
        )

        /**
         * Video not playable: Paid / Movie / Private / Age-restricted.
         * Note: The 'Authorization' key must be excluded from the header.
         * For some reason, PoToken is not required.
         */
        val ANDROID_NO_SDK = YouTubeClient(
            clientName = "ANDROID",
            clientVersion = "21.03.38",
            clientId = "3",
            userAgent = "com.google.android.youtube/21.03.38 (Linux; U; Android 14) gzip",
            friendlyName = "Android No SDK",
            loginSupported = false,
            useSignatureTimestamp = false
        )

        val ANDROID_VR_NO_AUTH = YouTubeClient(
            clientName = "ANDROID_VR",
            clientVersion = "1.61.48",
            clientId = "28",
            userAgent = "com.google.android.apps.youtube.vr.oculus/1.61.48 (Linux; U; Android 12; en_US; Oculus Quest 3; Build/SQ3A.220605.009.A1; Cronet/132.0.6808.3)",
            loginSupported = false,
            useSignatureTimestamp = false
        )

        /**
         * Video not playable: Kids / Paid / Movie / Private / Age-restricted.
         * This client can only be used when logged out.
         */
        val ANDROID_VR_1_61_48 = YouTubeClient(
            clientName = "ANDROID_VR",
            clientVersion = "1.61.48",
            clientId = "28",
            userAgent = "com.google.android.apps.youtube.vr.oculus/1.61.48 (Linux; U; Android 12; en_US; Quest 3; Build/SQ3A.220605.009.A1; Cronet/132.0.6808.3)",
            osName = "Android",
            osVersion = "12",
            deviceMake = "Oculus",
            deviceModel = "Quest 3",
            androidSdkVersion = "32",
            buildId = "SQ3A.220605.009.A1",
            cronetVersion = "132.0.6808.3",
            packageName = "com.google.android.apps.youtube.vr.oculus",
            friendlyName = "Android VR 1.61",
            loginSupported = false,
            useSignatureTimestamp = false
        )

        /**
         * Uses non adaptive bitrate, which fixes audio stuttering with YT Music.
         * Does not use AV1.
         */
        val ANDROID_VR_1_43_32 = YouTubeClient(
            clientName = "ANDROID_VR",
            clientVersion = "1.43.32",
            clientId = "28",
            userAgent = "com.google.android.apps.youtube.vr.oculus/1.43.32 (Linux; U; Android 12; en_US; Quest 3; Build/SQ3A.220605.009.A1; Cronet/107.0.5284.2)",
            osName = "Android",
            osVersion = "12",
            deviceMake = "Oculus",
            deviceModel = "Quest 3",
            androidSdkVersion = "32",
            buildId = "SQ3A.220605.009.A1",
            cronetVersion = "107.0.5284.2",
            packageName = "com.google.android.apps.youtube.vr.oculus",
            friendlyName = "Android VR 1.43",
            loginSupported = false,
            useSignatureTimestamp = false
        )

        /**
         * Cannot play livestreams and lacks HDR, but can play videos with music and labeled "for children".
         */
        val ANDROID_CREATOR = YouTubeClient(
            clientName = "ANDROID_CREATOR",
            clientVersion = "25.03.101",
            clientId = "14",
            userAgent = "com.google.android.apps.youtube.creator/25.03.101 (Linux; U; Android 15; en_US; Pixel 9 Pro Fold; Build/AP3A.241005.015.A2; Cronet/132.0.6779.0)",
            osName = "Android",
            osVersion = "15",
            deviceMake = "Google",
            deviceModel = "Pixel 9 Pro Fold",
            androidSdkVersion = "35",
            buildId = "AP3A.241005.015.A2",
            cronetVersion = "132.0.6779.0",
            packageName = "com.google.android.apps.youtube.creator",
            friendlyName = "Android Studio",
            loginSupported = true,
            useSignatureTimestamp = true
        )

        /**
         * Internal YT client for an unreleased YT client. May stop working at any time.
         */
        val VISIONOS = YouTubeClient(
            clientName = "VISIONOS",
            clientVersion = "0.1",
            clientId = "101",
            userAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15",
            osName = "visionOS",
            osVersion = "1.3.21O771",
            deviceMake = "Apple",
            deviceModel = "RealityDevice14,1",
            friendlyName = "visionOS",
            loginSupported = false,
            useSignatureTimestamp = false
        )

        /**
         * The device machine id for the iPad 6th Gen (iPad7,6).
         * AV1 hardware decoding is not supported.
         */
        val IPADOS = YouTubeClient(
            clientName = "IOS",
            clientVersion = "21.03.3",
            clientId = "5",
            userAgent = "com.google.ios.youtube/21.03.3 (iPad7,6; U; CPU iPadOS 17_7_10 like Mac OS X; en-US)",
            osName = "iPadOS",
            osVersion = "17.7.10.21H450",
            deviceMake = "Apple",
            deviceModel = "iPad7,6",
            friendlyName = "iPadOS",
            loginSupported = false,
            useSignatureTimestamp = false,
            packageName = "com.google.ios.youtube"
        )

        val ANDROID_TESTSUITE = YouTubeClient(
            clientName = "ANDROID_TESTSUITE",
            clientVersion = "1.9",
            clientId = "30",
            userAgent = "com.google.android.apps.youtube.tests/1.9 (Linux; U; Android 12) gzip",
            friendlyName = "Android TestSuite",
            loginSupported = false,
            useSignatureTimestamp = false
        )
    }
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/YouTubeDataPage.kt
// ----------------------------------------------------------------------------

@Serializable
data class YouTubeDataPage(
    @SerialName("contents")
    val contents: Contents? = null,
) {
    @Serializable
    data class Contents(
        @SerialName("twoColumnWatchNextResults")
        val twoColumnWatchNextResults: TwoColumnWatchNextResults? = null,
    ) {
        @Serializable
        data class TwoColumnWatchNextResults(
            @SerialName("results")
            val results: Results? = null,
        ) {
            @Serializable
            data class Results(
                @SerialName("results")
                val results: Results? = null,
            ) {
                @Serializable
                data class Results(
                    @SerialName("contents")
                    val content: List<Content?>? = null,
                ) {
                    @Serializable
                    data class Content(
                        @SerialName("videoPrimaryInfoRenderer")
                        val videoPrimaryInfoRenderer: VideoPrimaryInfoRenderer? = null,
                        @SerialName("videoSecondaryInfoRenderer")
                        val videoSecondaryInfoRenderer: VideoSecondaryInfoRenderer? = null,
                        @SerialName("itemSectionRenderer")
                        val itemSectionRenderer: ItemSectionRenderer? = null,
                    ) {
                        @Serializable
                        data class ItemSectionRenderer(
                            @SerialName("contents")
                            val contents: List<Content?>? = null,
                        ) {
                            @Serializable
                            data class Content(
                                @SerialName("continuationItemRenderer")
                                val continuationItemRenderer: ContinuationItemRenderer? = null,
                            ) {
                                @Serializable
                                data class ContinuationItemRenderer(
                                    @SerialName("trigger")
                                    val trigger: String? = null,
                                    @SerialName("continuationEndpoint")
                                    val continuationEndpoint: ContinuationEndpoint? = null,
                                ) {
                                    @Serializable
                                    data class ContinuationEndpoint(
                                        @SerialName("clickTrackingParams")
                                        val clickTrackingParams: String? = null,
                                        @SerialName("continuationCommand")
                                        val continuationCommand: ContinuationCommand? = null,
                                    ) {
                                        @Serializable
                                        data class ContinuationCommand(
                                            @SerialName("token")
                                            val token: String? = null,
                                            @SerialName("request")
                                            val request: String? = null,
                                        )
                                    }
                                }
                            }
                        }

                        @Serializable
                        data class VideoPrimaryInfoRenderer(
                            @SerialName("title")
                            val title: Title? = null,
                            @SerialName("viewCount")
                            val viewCount: ViewCount? = null,
                            @SerialName("dateText")
                            val dateText: DateText? = null,
                        ) {
                            @Serializable
                            data class Title(
                                @SerialName("runs")
                                val runs: List<Run>? = null,
                            ) {
                                @Serializable
                                data class Run(
                                    @SerialName("text")
                                    val text: String? = null,
                                )
                            }

                            @Serializable
                            data class ViewCount(
                                @SerialName("videoViewCountRenderer")
                                val videoViewCountRenderer: VideoViewCountRenderer? = null,
                            ) {
                                @Serializable
                                data class VideoViewCountRenderer(
                                    @SerialName("viewCount")
                                    val viewCount: VideoViewCountRenderer.ViewCount? = null,
                                ) {
                                    @Serializable
                                    data class ViewCount(
                                        @SerialName("simpleText")
                                        val simpleText: String? = null,
                                    )
                                }
                            }

                            @Serializable
                            data class DateText(
                                @SerialName("simpleText")
                                val simpleText: String? = null,
                            )
                        }

                        @Serializable
                        data class VideoSecondaryInfoRenderer(
                            @SerialName("owner")
                            val owner: Owner? = null,
                            @SerialName("attributedDescription")
                            val attributedDescription: AttributedDescription? = null,
                        ) {
                            @Serializable
                            data class AttributedDescription(
                                @SerialName("content")
                                val content: String? = null,
                            )

                            @Serializable
                            data class Owner(
                                @SerialName("videoOwnerRenderer")
                                val videoOwnerRenderer: VideoOwnerRenderer? = null,
                            ) {
                                @Serializable
                                data class VideoOwnerRenderer(
                                    @SerialName("thumbnail")
                                    val thumbnail: Thumbnail? = null,
                                    @SerialName("subscriberCountText")
                                    val subscriberCountText: SubscriberCountText? = null,
                                    @SerialName("title")
                                    val title: Title? = null,
                                    @SerialName("navigationEndpoint")
                                    val navigationEndpoint: NavigationEndpoint? = null,
                                ) {
                                    @Serializable
                                    data class Thumbnail(
                                        @SerialName("thumbnails")
                                        val thumbnails: List<com.listrovia.innertube.Thumbnail>? = null,
                                    )

                                    @Serializable
                                    data class SubscriberCountText(
                                        @SerialName("simpleText")
                                        val simpleText: String? = null,
                                    )

                                    @Serializable
                                    data class Title(
                                        @SerialName("runs")
                                        val runs: List<Run>? = null,
                                    ) {
                                        @Serializable
                                        data class Run(
                                            @SerialName("text")
                                            val text: String? = null,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// [MODELS] Source: models/YouTubeLocale.kt
// ----------------------------------------------------------------------------

@Serializable
data class YouTubeLocale(
    val gl: String, // geolocation
    val hl: String, // host language
)

// ----------------------------------------------------------------------------
// [MODELS] Source: models/YouTubeModels.kt
// ----------------------------------------------------------------------------

@Serializable
data class YouTubeVideoItem(
    val videoId: String,
    val title: String,
    val channelName: String,
    val channelId: String? = null,
    val channelThumbnailUrl: String? = null,
    val description: String? = null,
    val viewCountText: String? = null,
    val publishedTimeText: String? = null,
    val durationText: String? = null,
    val thumbnails: List<Thumbnail> = emptyList(),
    val isLive: Boolean = false,
)

@Serializable
data class YouTubeChannelPage(
    val channelId: String,
    val title: String,
    val avatarUrl: String? = null,
    val bannerUrl: String? = null,
    val subscriberCountText: String? = null,
    val videosCountText: String? = null,
    val description: String? = null,
    val videos: List<YouTubeVideoItem> = emptyList(),
    val continuation: String? = null,
    val isSubscribed: Boolean? = null,
) {
    companion object {
        const val VIDEOS_PARAMS = "EgZ2aWRlb3PyBgQKAjoA"
        const val SHORTS_PARAMS = "EgZzaG9ydHPyBgQKAjoA"
        const val LIVE_PARAMS = "EgRsaXZleyBgQKAjoA"
    }
}

@Serializable
data class YouTubeChannelPost(
    val postId: String,
    val authorName: String,
    val authorThumbnail: String? = null,
    val publishedTimeText: String? = null,
    val contentText: String? = null,
    val imageUrls: List<String> = emptyList(),
    val voteCountText: String? = null,
    val commentCountText: String? = null,
)

@Serializable
sealed class YouTubeSearchResultItem {
    @Serializable
    data class Video(val item: YouTubeVideoItem) : YouTubeSearchResultItem()
    @Serializable
    data class Channel(
        val channelId: String,
        val title: String,
        val thumbnails: List<Thumbnail> = emptyList(),
        val subscriberCountText: String? = null,
        val videoCountText: String? = null,
        val description: String? = null,
    ) : YouTubeSearchResultItem()
    @Serializable
    data class Playlist(
        val playlistId: String,
        val title: String,
        val thumbnails: List<Thumbnail> = emptyList(),
        val channelName: String? = null,
        val itemCountText: String? = null,
    ) : YouTubeSearchResultItem()
}

@Serializable
data class VideoFeedResult(
    val items: List<YouTubeSearchResultItem>,
    val continuation: String?,
)

// ----------------------------------------------------------------------------
// [REQUEST BODIES] Source: models/body/AccountMenuBody.kt
// ----------------------------------------------------------------------------

@Serializable
data class AccountMenuBody(
    val context: Context,
    val deviceTheme: String = "DEVICE_THEME_SELECTED",
    val userInterfaceTheme: String = "USER_INTERFACE_THEME_DARK",
)

// ----------------------------------------------------------------------------
// [REQUEST BODIES] Source: models/body/BrowseBody.kt
// ----------------------------------------------------------------------------

@Serializable
data class BrowseBody(
    val context: Context,
    val browseId: String?,
    val params: String?,
    val continuation: String?
)

// ----------------------------------------------------------------------------
// [REQUEST BODIES] Source: models/body/CreatePlaylistBody.kt
// ----------------------------------------------------------------------------

@Serializable
data class CreatePlaylistBody(
    val context: Context,
    val title: String,
    val privacyStatus: String = PrivacyStatus.PRIVATE,
    val videoIds: List<String>? = null
) {
    object PrivacyStatus {
        const val PRIVATE = "PRIVATE"
        const val PUBLIC = "PUBLIC"
        const val UNLISTED = "UNLISTED"
    }
}

// ----------------------------------------------------------------------------
// [REQUEST BODIES] Source: models/body/EditPlaylistBody.kt
// ----------------------------------------------------------------------------

@Serializable
data class EditPlaylistBody(
    val context: Context,
    val playlistId: String,
    val actions: List<Action>
)

@Serializable
sealed class Action {
    @Serializable
    data class AddVideoAction(
        val action: String = "ACTION_ADD_VIDEO",
        val addedVideoId: String
    ) : Action()

    @Serializable
    data class AddPlaylistAction(
        val action: String = "ACTION_ADD_PLAYLIST",
        val addedFullListId: String
    ) : Action()

    @Serializable
    data class MoveVideoAction(
        val action: String = "ACTION_MOVE_VIDEO_BEFORE",
        val setVideoId: String,
        val movedSetVideoIdSuccessor: String?
    ) : Action()

    @Serializable
    data class RemoveVideoAction(
        val action: String = "ACTION_REMOVE_VIDEO",
        val setVideoId: String,
        val removedVideoId: String
    ) : Action()

    @Serializable
    data class RenamePlaylistAction(
        val action: String = "ACTION_SET_PLAYLIST_NAME",
        val playlistName: String
    ) : Action()

    @Serializable
    data class SetCustomThumbnailAction(
        val action: String = "ACTION_SET_CUSTOM_THUMBNAIL",
        val addedCustomThumbnail: AddedCustomThumbnail
    ) : Action() {
        @Serializable
        data class AddedCustomThumbnail(
            val imageKey: ImageKey = ImageKey(
                name = "studio_square_thumbnail",
                type = "PLAYLIST_IMAGE_TYPE_CUSTOM_THUMBNAIL"
            ),
            val playlistScottyEncryptedBlobId: String
        ) {
            @Serializable
            data class ImageKey(
                val name: String,
                val type: String
            )
        }
    }

    @Serializable
    data class RemoveCustomThumbnailAction(
        val action: String = "ACTION_REMOVE_CUSTOM_THUMBNAIL",
        val deletedCustomThumbnail: DeletedCustomThumbnail = DeletedCustomThumbnail()
    ) : Action() {
        @Serializable
        data class DeletedCustomThumbnail(
            val name: String = "studio_square_thumbnail",
            val type: String = "PLAYLIST_IMAGE_TYPE_CUSTOM_THUMBNAIL"
        )
    }
}

// ----------------------------------------------------------------------------
// [REQUEST BODIES] Source: models/body/FeedbackBody.kt
// ----------------------------------------------------------------------------

@Serializable
data class FeedbackBody(
    val context: Context,
    val feedbackTokens: List<String>,
    val isFeedbackTokenUnencrypted: Boolean = false,
    val shouldMerge: Boolean = false,
)

// ----------------------------------------------------------------------------
// [REQUEST BODIES] Source: models/body/GetQueueBody.kt
// ----------------------------------------------------------------------------

@Serializable
data class GetQueueBody(
    val context: Context,
    val videoIds: List<String>?,
    val playlistId: String?,
)

// ----------------------------------------------------------------------------
// [REQUEST BODIES] Source: models/body/GetSearchSuggestionsBody.kt
// ----------------------------------------------------------------------------

@Serializable
data class GetSearchSuggestionsBody(
    val context: Context,
    val input: String,
)

// ----------------------------------------------------------------------------
// [REQUEST BODIES] Source: models/body/GetTranscriptBody.kt
// ----------------------------------------------------------------------------

@Serializable
data class GetTranscriptBody(
    val context: Context,
    val params: String,
)

// ----------------------------------------------------------------------------
// [REQUEST BODIES] Source: models/body/LikeBody.kt
// ----------------------------------------------------------------------------

@Serializable
data class LikeBody(
    val context: Context,
    val target: Target,
) {
    /**
     * Target for like/unlike operations.
     * Note: Only one of videoId or playlistId should be set.
     * Using a flat structure instead of sealed class to avoid type discriminator in serialization.
     */
    @Serializable
    data class Target(
        val videoId: String? = null,
        val playlistId: String? = null,
    ) {
        companion object {
            fun video(id: String) = Target(videoId = id)
            fun playlist(id: String) = Target(playlistId = id)
        }
    }
}

// ----------------------------------------------------------------------------
// [REQUEST BODIES] Source: models/body/NextBody.kt
// ----------------------------------------------------------------------------

@Serializable
data class NextBody(
    val context: Context,
    val videoId: String?,
    val playlistId: String?,
    val playlistSetVideoId: String?,
    val index: Int?,
    val params: String?,
    val continuation: String?,
)

// ----------------------------------------------------------------------------
// [REQUEST BODIES] Source: models/body/PlayerBody.kt
// ----------------------------------------------------------------------------

@Serializable
data class PlayerBody(
    val context: Context,
    val videoId: String,
    val playlistId: String?,
    val playbackContext: PlaybackContext? = null,
    val serviceIntegrityDimensions: ServiceIntegrityDimensions? = null,
    val contentCheckOk: Boolean = true,
    val racyCheckOk: Boolean = true,
) {
    @Serializable
    data class PlaybackContext(
        val contentPlaybackContext: ContentPlaybackContext
    ) {
        @Serializable
        data class ContentPlaybackContext(
            val signatureTimestamp: Int
        )
    }

    @Serializable
    data class ServiceIntegrityDimensions(
        val poToken: String
    )
}

// ----------------------------------------------------------------------------
// [REQUEST BODIES] Source: models/body/SearchBody.kt
// ----------------------------------------------------------------------------

@Serializable
data class SearchBody(
    val context: Context,
    val query: String?,
    val params: String?,
)

// ----------------------------------------------------------------------------
// [REQUEST BODIES] Source: models/body/SubscribeBody.kt
// ----------------------------------------------------------------------------

@Serializable
data class SubscribeBody(
    val channelIds: List<String>,
    val context: Context,
    val params: String? = null,
)

// ----------------------------------------------------------------------------
// [RESPONSE MODELS] Source: models/response/AccountMenuResponse.kt
// ----------------------------------------------------------------------------

@Serializable
data class AccountMenuResponse(
    val actions: List<Action>,
) {
    @Serializable
    data class Action(
        val openPopupAction: OpenPopupAction,
    ) {
        @Serializable
        data class OpenPopupAction(
            val popup: Popup,
        ) {
            @Serializable
            data class Popup(
                val multiPageMenuRenderer: MultiPageMenuRenderer,
            ) {
                @Serializable
                data class MultiPageMenuRenderer(
                    val header: Header?,
                ) {
                    @Serializable
                    data class Header(
                        val activeAccountHeaderRenderer: ActiveAccountHeaderRenderer,
                    ) {
                        @Serializable
                        data class ActiveAccountHeaderRenderer(
                            val accountName: Runs,
                            val email: Runs?,
                            val channelHandle: Runs?,
                            val accountPhoto: Thumbnails,
                        ) {
                            fun toAccountInfo() =
                                AccountInfo(
                                    name = accountName.runs!!.first().text,
                                    email = email?.runs?.first()?.text,
                                    channelHandle = channelHandle?.runs?.first()?.text,
                                    thumbnailUrl = accountPhoto.thumbnails.lastOrNull()?.url,
                                )
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// [RESPONSE MODELS] Source: models/response/AddItemYouTubePlaylistResponse.kt
// ----------------------------------------------------------------------------

@Serializable
data class AddItemYouTubePlaylistResponse(
    val status: String,
    val playlistEditResults: List<PlaylistEditResult>
) {
    @Serializable
    data class PlaylistEditResult(
        val playlistEditVideoAddedResultData: PlaylistEditVideoAddedResultData,
    ) {
        @Serializable
        data class PlaylistEditVideoAddedResultData(
            val setVideoId: String,
            val videoId: String
        )
    }
}

// ----------------------------------------------------------------------------
// [RESPONSE MODELS] Source: models/response/BrowseResponse.kt
// ----------------------------------------------------------------------------

@Serializable
data class BrowseResponse(
    val contents: Contents?,
    val continuationContents: ContinuationContents?,
    val onResponseReceivedActions: List<ResponseAction>?,
    val header: Header?,
    val microformat: Microformat?,
    val responseContext: ResponseContext,
    val background: ThumbnailRenderer?
) {
    @Serializable
    data class Contents(
        val singleColumnBrowseResultsRenderer: Tabs?,
        val sectionListRenderer: SectionListRenderer?,
        val twoColumnBrowseResultsRenderer: TwoColumnBrowseResultsRenderer?,
    )

    @Serializable
    data class TwoColumnBrowseResultsRenderer(
        val tabs: List<Tabs.Tab?>?,
        val secondaryContents: SecondaryContents?,
    )
    @Serializable
    data class SecondaryContents(
        val sectionListRenderer: SectionListRenderer?,
    )

    @Serializable
    data class ContinuationContents(
        val sectionListContinuation: SectionListContinuation?,
        val musicPlaylistShelfContinuation: MusicPlaylistShelfContinuation?,
        val gridContinuation: GridContinuation?,
        val musicShelfContinuation: MusicShelfRenderer?
    ) {
        @Serializable
        data class SectionListContinuation(
            val contents: List<SectionListRenderer.Content> = emptyList(),
            val continuations: List<Continuation>?,
        )

        @Serializable
        data class MusicPlaylistShelfContinuation(
            val contents: List<MusicShelfRenderer.Content> = emptyList(),
            val continuations: List<Continuation>?,
        )

        @Serializable
        data class GridContinuation(
            val items: List<GridRenderer.Item> = emptyList(),
            val continuations: List<Continuation>?,
        )
    }

    @Serializable
    data class ResponseAction(
        val appendContinuationItemsAction: ContinuationItems?,
    ) {
        @Serializable
        data class ContinuationItems(
            val continuationItems: List<MusicShelfRenderer.Content>?,
        )
    }

    @Serializable
    data class Header(
        val musicImmersiveHeaderRenderer: MusicImmersiveHeaderRenderer?,
        val musicDetailHeaderRenderer: MusicDetailHeaderRenderer?,
        val musicEditablePlaylistDetailHeaderRenderer: MusicEditablePlaylistDetailHeaderRenderer?,
        val musicVisualHeaderRenderer: MusicVisualHeaderRenderer?,
        val musicHeaderRenderer: MusicHeaderRenderer?,
    ) {
        @Serializable
        data class MusicImmersiveHeaderRenderer(
            val title: Runs,
            val description: Runs?,
            val thumbnail: ThumbnailRenderer?,
            val playButton: Button?,
            val startRadioButton: Button?,
            val subscriptionButton: SubscriptionButton?,
            val menu: Menu,
            val subscriptionButton2: SubscriptionButton2?,
            val monthlyListenerCount: Runs? = null,
        ) {
            @Serializable
            data class SubscriptionButton2(
                val subscribeButtonRenderer: SubscribeButtonRenderer?,
            ) {
                @Serializable
                data class SubscribeButtonRenderer(
                    val subscriberCountWithSubscribeText: Runs?,
                )
            }
        }

        @Serializable
        data class MusicVisualHeaderRenderer(
            val title: Runs,
            val foregroundThumbnail: ThumbnailRenderer,
            val thumbnail: ThumbnailRenderer?,
            val subscriptionButton: SubscriptionButton?,
        )

        @Serializable
        data class Buttons(
            val menuRenderer: Menu.MenuRenderer?,
        )

        @Serializable
        data class MusicHeaderRenderer(
            val buttons: List<Buttons>?,
            val title: Runs?,
            val thumbnail: MusicThumbnailRenderer?,
            val subtitle: Runs?,
            val secondSubtitle: Runs?,
            val straplineTextOne: Runs?,
            val straplineThumbnail: MusicThumbnailRenderer?,
        )
        @Serializable
        data class MusicThumbnail(
            val url: String?,
        )
        @Serializable
        data class MusicThumbnailRenderer(
            val musicThumbnailRenderer: MusicThumbnailRenderer,
            val thumbnails: List<MusicThumbnail>?,
        )
    }

    @Serializable
    data class Microformat(
        val microformatDataRenderer: MicroformatDataRenderer?,
    ) {
        @Serializable
        data class MicroformatDataRenderer(
            val urlCanonical: String?,
        )
    }
}

// ----------------------------------------------------------------------------
// [RESPONSE MODELS] Source: models/response/ContinuationResponse.kt
// ----------------------------------------------------------------------------

@Serializable
 data class ContinuationResponse(
     val onResponseReceivedActions: List<ResponseAction>?,
 ) {
 
     @Serializable
     data class ResponseAction(
         val appendContinuationItemsAction: ContinuationItems?,
     )
 
     @Serializable
     data class ContinuationItems(
         val continuationItems: List<MusicShelfRenderer.Content>?,
     )
 }

// ----------------------------------------------------------------------------
// [RESPONSE MODELS] Source: models/response/CreatePlaylistResponse.kt
// ----------------------------------------------------------------------------

@Serializable
data class CreatePlaylistResponse(
    val playlistId: String
)

// ----------------------------------------------------------------------------
// [RESPONSE MODELS] Source: models/response/EditPlaylistResponse.kt
// ----------------------------------------------------------------------------

@Serializable
data class EditPlaylistResponse(
    val newHeader: BrowseResponse.Header?,
)

// ----------------------------------------------------------------------------
// [RESPONSE MODELS] Source: models/response/FeedbackResponse.kt
// ----------------------------------------------------------------------------

@Serializable
data class FeedbackResponse(
    val feedbackResponses: List<Status>,
) {
    @Serializable
    data class Status(
        val isProcessed: Boolean,
    )
}

// ----------------------------------------------------------------------------
// [RESPONSE MODELS] Source: models/response/GetQueueResponse.kt
// ----------------------------------------------------------------------------

@Serializable
data class GetQueueResponse(
    val queueDatas: List<QueueData>,
) {
    @Serializable
    data class QueueData(
        val content: PlaylistPanelRenderer.Content,
    )
}

// ----------------------------------------------------------------------------
// [RESPONSE MODELS] Source: models/response/GetSearchSuggestionsResponse.kt
// ----------------------------------------------------------------------------

@Serializable
data class GetSearchSuggestionsResponse(
    val contents: List<Content>?,
) {
    @Serializable
    data class Content(
        val searchSuggestionsSectionRenderer: SearchSuggestionsSectionRenderer,
    )
}

// ----------------------------------------------------------------------------
// [RESPONSE MODELS] Source: models/response/GetTranscriptResponse.kt
// ----------------------------------------------------------------------------

@Serializable
data class GetTranscriptResponse(
    val actions: List<Action>?,
) {
    @Serializable
    data class Action(
        val updateEngagementPanelAction: UpdateEngagementPanelAction,
    ) {
        @Serializable
        data class UpdateEngagementPanelAction(
            val content: Content,
        ) {
            @Serializable
            data class Content(
                val transcriptRenderer: TranscriptRenderer,
            ) {
                @Serializable
                data class TranscriptRenderer(
                    val body: Body,
                ) {
                    @Serializable
                    data class Body(
                        val transcriptBodyRenderer: TranscriptBodyRenderer,
                    ) {
                        @Serializable
                        data class TranscriptBodyRenderer(
                            val cueGroups: List<CueGroup>,
                        ) {
                            @Serializable
                            data class CueGroup(
                                val transcriptCueGroupRenderer: TranscriptCueGroupRenderer,
                            ) {
                                @Serializable
                                data class TranscriptCueGroupRenderer(
                                    val cues: List<Cue>,
                                ) {
                                    @Serializable
                                    data class Cue(
                                        val transcriptCueRenderer: TranscriptCueRenderer,
                                    ) {
                                        @Serializable
                                        data class TranscriptCueRenderer(
                                            val cue: SimpleText,
                                            val startOffsetMs: Long,
                                            val durationMs: Long,
                                        ) {
                                            @Serializable
                                            data class SimpleText(
                                                val simpleText: String,
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// [RESPONSE MODELS] Source: models/response/ImageUploadResponse.kt
// ----------------------------------------------------------------------------

@Serializable
data class ImageUploadResponse(
    val encryptedBlobId: String
)

// ----------------------------------------------------------------------------
// [RESPONSE MODELS] Source: models/response/NextResponse.kt
// ----------------------------------------------------------------------------

@Serializable
data class NextResponse(
    val contents: Contents,
    val continuationContents: ContinuationContents?,
    val currentVideoEndpoint: NavigationEndpoint?,
) {
    @Serializable
    data class Contents(
        val singleColumnMusicWatchNextResultsRenderer: SingleColumnMusicWatchNextResultsRenderer?,
        val twoColumnWatchNextResults: YouTubeDataPage.Contents.TwoColumnWatchNextResults?,
    ) {
        @Serializable
        data class SingleColumnMusicWatchNextResultsRenderer(
            val tabbedRenderer: TabbedRenderer?,
        ) {
            @Serializable
            data class TabbedRenderer(
                val watchNextTabbedResultsRenderer: WatchNextTabbedResultsRenderer?,
            ) {
                @Serializable
                data class WatchNextTabbedResultsRenderer(
                    val tabs: List<Tabs.Tab>,
                )
            }
        }
    }

    @Serializable
    data class ContinuationContents(
        val playlistPanelContinuation: PlaylistPanelRenderer,
    )
}

// ----------------------------------------------------------------------------
// [RESPONSE MODELS] Source: models/response/PlayerResponse.kt
// ----------------------------------------------------------------------------

/**
 * PlayerResponse with [com.listrovia.innertube.YouTubeClient.WEB_REMIX] client
 */
@Serializable
data class PlayerResponse(
    val responseContext: ResponseContext,
    val playabilityStatus: PlayabilityStatus,
    val playerConfig: PlayerConfig?,
    val streamingData: StreamingData?,
    val videoDetails: VideoDetails?,
    @SerialName("playbackTracking")
    val playbackTracking: PlaybackTracking?,
) {
    @Serializable
    data class PlayabilityStatus(
        val status: String,
        val reason: String?,
    )

    @Serializable
    data class PlayerConfig(
        val audioConfig: AudioConfig,
    ) {
        @Serializable
        data class AudioConfig(
            val loudnessDb: Double?,
            val perceptualLoudnessDb: Double?,
        )
    }

    @Serializable
    data class StreamingData(
        val formats: List<Format>?,
        val adaptiveFormats: List<Format>,
        val expiresInSeconds: Int,
    ) {
        @Serializable
        data class Format(
            val itag: Int,
            val url: String?,
            val mimeType: String,
            val bitrate: Int,
            val width: Int?,
            val height: Int?,
            val contentLength: Long?,
            val quality: String,
            val fps: Int?,
            val qualityLabel: String?,
            val averageBitrate: Int?,
            val audioQuality: String?,
            val approxDurationMs: String?,
            val audioSampleRate: Int?,
            val audioChannels: Int?,
            val loudnessDb: Double?,
            val lastModified: Long?,
            val signatureCipher: String?,
            val cipher: String?,
            val audioTrack: AudioTrack?
        ) {
            val isAudio: Boolean
                get() = width == null
            val isVideo: Boolean
                get() = width != null
            val isOriginal: Boolean
                get() = audioTrack?.isAutoDubbed == null

            @Serializable
            data class AudioTrack(
                val displayName: String?,
                val id: String?,
                val isAutoDubbed: Boolean?,
            )
        }
    }

    @Serializable
    data class VideoDetails(
        val videoId: String,
        val title: String?,
        val author: String?,
        val channelId: String,
        val lengthSeconds: String,
        val musicVideoType: String?,
        val viewCount: String?,
        val thumbnail: Thumbnails,
    )

    @Serializable
    data class PlaybackTracking(
        @SerialName("videostatsPlaybackUrl")
        val videostatsPlaybackUrl: VideostatsPlaybackUrl?,
        @SerialName("videostatsWatchtimeUrl")
        val videostatsWatchtimeUrl: VideostatsWatchtimeUrl?,
        @SerialName("atrUrl")
        val atrUrl: AtrUrl?,
    ) {
        @Serializable
        data class VideostatsPlaybackUrl(
            @SerialName("baseUrl")
            val baseUrl: String?,
        )
        @Serializable
        data class VideostatsWatchtimeUrl(
            @SerialName("baseUrl")
            val baseUrl: String?,
        )
        @Serializable
        data class AtrUrl(
            @SerialName("baseUrl")
            val baseUrl: String?,
        )
    }
}

// ----------------------------------------------------------------------------
// [RESPONSE MODELS] Source: models/response/SearchResponse.kt
// ----------------------------------------------------------------------------

@Serializable
data class SearchResponse(
    val contents: Contents?,
    val continuationContents: ContinuationContents?,
) {
    @Serializable
    data class Contents(
        val tabbedSearchResultsRenderer: Tabs?,
    )

    @Serializable
    data class ContinuationContents(
        val musicShelfContinuation: MusicShelfContinuation,
    ) {
        @Serializable
        data class MusicShelfContinuation(
            val contents: List<Content>,
            val continuations: List<Continuation>?,
        ) {
            @Serializable
            data class Content(
                val musicResponsiveListItemRenderer: MusicResponsiveListItemRenderer,
            )
        }
    }
}

// ----------------------------------------------------------------------------
// [RESPONSE MODELS] Source: models/response/VideoModels.kt
// ----------------------------------------------------------------------------

@Serializable
data class WatchMetadataResponse(
    val title: String? = null,
    val channelId: String? = null,
    val channelName: String? = null,
    val channelAvatarUrl: String? = null,
    val subscriberCountText: String? = null,
    val description: String? = null,
    val viewCountText: String? = null,
    val dateText: String? = null,
    val likeCountText: String? = null,
    val likeState: WatchLikeState = WatchLikeState.INDIFFERENT,
    val commentCountText: String? = null,
    val relatedVideos: List<YouTubeVideoItem> = emptyList(),
    val relatedContinuation: String? = null,
    val comments: List<YoutubeComment> = emptyList(),
    val commentsContinuation: String? = null,
)

@Serializable
enum class WatchLikeState {
    INDIFFERENT,
    LIKE,
    DISLIKE,
    NONE,
}

@Serializable
data class WatchCompactVideo(
    val videoId: String,
    val title: String,
    val channelName: String,
    val channelId: String,
    val thumbnailUrl: String,
    val durationText: String? = null,
    val viewCountText: String? = null,
    val publishedTimeText: String? = null,
)

@Serializable
data class YoutubeComment(
    val commentId: String,
    val authorName: String,
    val authorThumbnail: String? = null,
    val content: String,
    val publishedTime: String? = null,
    val likeCount: String? = null,
    val replyCount: String? = null,
    val isAuthorPinned: Boolean = false,
)

// Extension functions to match ported code usage and avoid property collision
fun WatchMetadataResponse.getChannelId(): String? = this.channelId
fun WatchMetadataResponse.getTitle(): String? = this.title
fun WatchMetadataResponse.getChannelName(): String? = this.channelName
fun WatchMetadataResponse.getChannelAvatarUrl(): String? = this.channelAvatarUrl
fun WatchMetadataResponse.getSubscriberCountText(): String? = this.subscriberCountText
fun WatchMetadataResponse.getDescription(): String? = this.description
fun WatchMetadataResponse.getViewCountText(): String? = this.viewCountText
fun WatchMetadataResponse.getDateText(): String? = this.dateText
fun WatchMetadataResponse.getLikeCountText(): String? = this.likeCountText
fun WatchMetadataResponse.getLikeState(): WatchLikeState = this.likeState
fun WatchMetadataResponse.getCommentCountText(): String? = this.commentCountText
fun WatchMetadataResponse.getRelatedVideos(): List<YouTubeVideoItem> = this.relatedVideos
fun WatchMetadataResponse.getRelatedContinuation(): String? = this.relatedContinuation
fun WatchMetadataResponse.getComments(): List<YoutubeComment> = this.comments
fun WatchMetadataResponse.getCommentsContinuation(): String? = this.commentsContinuation

// Backwards compatibility functions (some code might use them without 'get')
fun WatchMetadataResponse.title(): String? = this.title
fun WatchMetadataResponse.channelName(): String? = this.channelName
fun WatchMetadataResponse.channelId(): String? = this.channelId
fun WatchMetadataResponse.channelAvatarUrl(): String? = this.channelAvatarUrl
fun WatchMetadataResponse.description(): String? = this.description
fun WatchMetadataResponse.viewCountText(): String? = this.viewCountText
fun WatchMetadataResponse.dateText(): String? = this.dateText
fun WatchMetadataResponse.subscriberCountText(): String? = this.subscriberCountText
fun WatchMetadataResponse.commentCountText(): String? = this.commentCountText
fun WatchMetadataResponse.likeCountText(): String? = this.likeCountText
fun WatchMetadataResponse.likeState(): WatchLikeState = this.likeState
fun WatchMetadataResponse.relatedVideos(): List<YouTubeVideoItem> = this.relatedVideos
fun WatchMetadataResponse.relatedContinuation(): String? = this.relatedContinuation
fun WatchMetadataResponse.comments(): List<YoutubeComment> = this.comments
fun WatchMetadataResponse.commentsContinuation(): String? = this.commentsContinuation

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/AlbumPage.kt
// ----------------------------------------------------------------------------

data class AlbumPage(
    val album: AlbumItem,
    val songs: List<SongItem>,
    val otherVersions: List<AlbumItem>,
    val description: String? = null,
) {
    companion object {
        fun getPlaylistId(response: BrowseResponse): String? {
            var playlistId = response.microformat?.microformatDataRenderer?.urlCanonical?.substringAfterLast('=')
            if (playlistId == null)
            {
                playlistId = response.header?.musicDetailHeaderRenderer?.menu?.menuRenderer?.topLevelButtons?.firstOrNull()
                    ?.buttonRenderer?.navigationEndpoint?.watchPlaylistEndpoint?.playlistId
            }
            return playlistId
        }

        fun getTitle(response: BrowseResponse): String? {
            val title = getHeader(response)?.title ?: response.header?.musicDetailHeaderRenderer?.title
            return title?.runs?.firstOrNull()?.text
        }

        fun getYear(response: BrowseResponse): Int? {
            val title = getHeader(response)?.subtitle ?: response.header?.musicDetailHeaderRenderer?.subtitle
            return title?.runs?.lastOrNull()?.text?.toIntOrNull()
        }

        fun getThumbnail(response: BrowseResponse): String? {
            return response.background?.musicThumbnailRenderer?.getThumbnailUrl() ?: response.header?.musicDetailHeaderRenderer?.thumbnail
                ?.croppedSquareThumbnailRenderer?.getThumbnailUrl()
        }

        fun getArtists(response: BrowseResponse): List<Artist> {
            val artists = getHeader(response)?.straplineTextOne?.runs?.oddElements()?.map {
                Artist(
                    name = it.text,
                    id = it.navigationEndpoint?.browseEndpoint?.browseId
                )
            } ?: response.header?.musicDetailHeaderRenderer?.subtitle?.runs?.splitBySeparator()?.getOrNull(1)?.oddElements()?.map {
                Artist(
                    name = it.text,
                    id = it.navigationEndpoint?.browseEndpoint?.browseId
                )
            } ?: emptyList()

            return artists
        }

        private fun getHeader(response: BrowseResponse): MusicResponsiveHeaderRenderer? {
            val tabs = response.contents?.singleColumnBrowseResultsRenderer?.tabs
                ?: response.contents?.twoColumnBrowseResultsRenderer?.tabs
            val section =
                tabs?.firstOrNull()?.tabRenderer?.content?.sectionListRenderer?.contents?.firstOrNull()
            val header = section?.musicResponsiveHeaderRenderer
            return header
        }

        fun getSongs(response: BrowseResponse, album: AlbumItem): List<SongItem> {
            val tabs = response.contents?.singleColumnBrowseResultsRenderer?.tabs ?: response.contents?.twoColumnBrowseResultsRenderer?.tabs
            val shelfRenderer = tabs?.firstOrNull()?.tabRenderer?.content?.sectionListRenderer?.contents?.firstOrNull()?.musicShelfRenderer ?:
                response.contents?.twoColumnBrowseResultsRenderer?.secondaryContents?.sectionListRenderer?.contents?.firstOrNull()?.musicShelfRenderer

            val songs = shelfRenderer?.contents?.getItems()?.mapNotNull {
                getSong(it, album)
            }
            return songs ?: emptyList()
        }

        fun getSong(renderer: MusicResponsiveListItemRenderer, album: AlbumItem? = null): SongItem? {
            // Extract library tokens using the new method that properly handles multiple toggle items
            val libraryTokens = PageHelper.extractLibraryTokensFromMenuItems(renderer.menu?.menuRenderer?.items)

            return SongItem(
                id = renderer.playlistItemData?.videoId
                    ?: renderer.navigationEndpoint?.watchEndpoint?.videoId
                    ?: renderer.overlay?.musicItemThumbnailOverlayRenderer
                        ?.content?.musicPlayButtonRenderer
                        ?.playNavigationEndpoint?.watchEndpoint?.videoId
                    ?: renderer.flexColumns.firstOrNull()
                        ?.musicResponsiveListItemFlexColumnRenderer
                        ?.text?.runs?.firstOrNull()
                        ?.navigationEndpoint?.watchEndpoint?.videoId
                    ?: return null,
                title = PageHelper.extractRuns(renderer.flexColumns, "MUSIC_VIDEO").firstOrNull()?.text ?: return null,
                artists = PageHelper.extractRuns(renderer.flexColumns, "MUSIC_PAGE_TYPE_ARTIST").map{
                    Artist(
                        name = it.text,
                        id = it.navigationEndpoint?.browseEndpoint?.browseId
                    )
                }.ifEmpty {
                    // Label-uploaded albums (e.g. "OLAK5uy_…" art tracks) name the performing
                    // artist as a plain-text run with no artist link, while the album header
                    // strapline is the record label / distributor channel. Prefer that
                    // plain-text artist over inheriting the label as the track artist.
                    renderer.flexColumns.getOrNull(1)
                        ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs
                        ?.splitBySeparator()?.firstOrNull()?.oddElements()
                        ?.map { Artist(name = it.text, id = it.navigationEndpoint?.browseEndpoint?.browseId) }
                        ?.filter { it.name.isNotBlank() }
                        ?.takeIf { it.isNotEmpty() }
                    // Final fallback: inherit the album artist when the row has no artist at all.
                        ?: album?.artists ?: emptyList()
                },
                album = album?.let {
                    Album(it.title, it.browseId)
                } ?: renderer.flexColumns.getOrNull(2)?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.let {
                    Album(
                        name = it.text,
                        id = it.navigationEndpoint?.browseEndpoint?.browseId!!
                    )
                }!!,
                duration = renderer.fixedColumns?.firstOrNull()
                    ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()
                    ?.text?.parseTime() ?: return null,
                musicVideoType = renderer.musicVideoType,
                thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: album?.thumbnail!!,
                explicit = renderer.badges?.find {
                    it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                } != null,
                libraryAddToken = libraryTokens.addToken,
                libraryRemoveToken = libraryTokens.removeToken
            )
        }
    }
}

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/ArtistItemsContinuationPage.kt
// ----------------------------------------------------------------------------

data class ArtistItemsContinuationPage(
    val items: List<YTItem>,
    val continuation: String?,
)

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/ArtistItemsPage.kt
// ----------------------------------------------------------------------------

data class ArtistItemsPage(
    val title: String,
    val items: List<YTItem>,
    val continuation: String?,
) {
    companion object {
        fun fromMusicResponsiveListItemRenderer(renderer: MusicResponsiveListItemRenderer): SongItem? {
            val artistRuns = renderer.flexColumns
                .getOrNull(1)
                ?.musicResponsiveListItemFlexColumnRenderer
                ?.text
                ?.runs
                ?.splitBySeparator()
                ?.getOrNull(0)
                ?.splitArtistsByConjunction()
                ?.filter { it.text.isNotBlank() && it.text != "&" && it.text != "," }
                ?.map { run ->
                    Artist(
                        name = run.text.trim(),
                        id = run.navigationEndpoint?.browseEndpoint?.browseId
                    )
                }

            // Extract album from last flexColumn (like SimpMusic does)
            val album = renderer.flexColumns.lastOrNull()
                ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs
                ?.firstOrNull()?.let {
                    if (it.navigationEndpoint?.browseEndpoint?.browseId != null) {
                        Album(
                            name = it.text,
                            id = it.navigationEndpoint.browseEndpoint.browseId
                        )
                    } else null
                }

            // Extract library tokens using the new method that properly handles multiple toggle items
            val libraryTokens = PageHelper.extractLibraryTokensFromMenuItems(renderer.menu?.menuRenderer?.items)

            return SongItem(
                id = renderer.playlistItemData?.videoId
                    ?: renderer.navigationEndpoint?.watchEndpoint?.videoId
                    ?: renderer.overlay?.musicItemThumbnailOverlayRenderer
                        ?.content?.musicPlayButtonRenderer
                        ?.playNavigationEndpoint?.watchEndpoint?.videoId
                    ?: renderer.flexColumns.firstOrNull()
                        ?.musicResponsiveListItemFlexColumnRenderer
                        ?.text?.runs?.firstOrNull()
                        ?.navigationEndpoint?.watchEndpoint?.videoId
                    ?: return null,
                title = renderer.flexColumns.firstOrNull()
                    ?.musicResponsiveListItemFlexColumnRenderer?.text
                    ?.runs?.firstOrNull()?.text ?: return null,
                artists = artistRuns ?: return null,
                album = album,
                duration = renderer.fixedColumns?.firstOrNull()
                    ?.musicResponsiveListItemFlexColumnRenderer?.text
                    ?.runs?.firstOrNull()
                    ?.text?.parseTime(),
                musicVideoType = renderer.musicVideoType,
                thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                explicit = renderer.badges?.find {
                    it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                } != null,
                endpoint = renderer.overlay?.musicItemThumbnailOverlayRenderer?.content?.musicPlayButtonRenderer?.playNavigationEndpoint?.watchEndpoint,
                libraryAddToken = libraryTokens.addToken,
                libraryRemoveToken = libraryTokens.removeToken,
                isEpisode = renderer.isEpisode
            )
        }

        fun fromMusicTwoRowItemRenderer(renderer: MusicTwoRowItemRenderer): YTItem? {
            return when {
                renderer.isAlbum -> AlbumItem(
                    browseId = renderer.navigationEndpoint.browseEndpoint?.browseId ?: return null,
                    playlistId = renderer.thumbnailOverlay?.musicItemThumbnailOverlayRenderer
                        ?.content?.musicPlayButtonRenderer?.playNavigationEndpoint
                        ?.anyWatchEndpoint?.playlistId ?: return null,
                    title = renderer.title.runs?.firstOrNull()?.text ?: return null,
                    artists = null,
                    year = renderer.subtitle?.runs?.lastOrNull()?.text?.toIntOrNull(),
                    thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                    explicit = renderer.subtitleBadges?.find {
                        it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                    } != null
                )
                // Video
                renderer.isSong -> {
                    val title = renderer.title.runs?.firstOrNull()?.text ?: return null
                    val videoId = renderer.navigationEndpoint.watchEndpoint?.videoId ?: return null
                    val subtitleRuns = renderer.subtitle?.runs ?: return null
                    val expandedRuns = subtitleRuns.splitArtistsByConjunction()
                    val artistRuns = expandedRuns.filter { run ->
                        run.text.isNotBlank() && run.text != "&" && run.text != "," &&
                        run.navigationEndpoint?.browseEndpoint?.browseId?.startsWith("UC") == true
                    }
                    val artists = artistRuns.map { run ->
                        Artist(
                            name = run.text.trim(),
                            id = run.navigationEndpoint?.browseEndpoint?.browseId
                        )
                    }
                    
                    if (artists.isEmpty() && renderer.subtitle?.runs != null) {
                        Timber.w("ArtistItemsPage.fromMusicTwoRowItemRenderer: Song '$title' (id=$videoId) - SUBTITLE RUNS EXIST but parsing returned EMPTY")
                    }

                    SongItem(
                        id = videoId,
                        title = title,
                        artists = artists.ifEmpty { null } ?: return null,
                        album = null,
                        duration = null,
                        musicVideoType = renderer.musicVideoType,
                        thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        endpoint = renderer.navigationEndpoint.watchEndpoint
                    )
                }
                renderer.isPlaylist -> PlaylistItem(
                    id = renderer.navigationEndpoint.browseEndpoint?.browseId?.removePrefix("VL") ?: return null,
                    title = renderer.title.runs?.firstOrNull()?.text ?: return null,
                    author = renderer.subtitle?.runs?.firstOrNull()?.let {
                        Artist(
                            name = it.text,
                            id = it.navigationEndpoint?.browseEndpoint?.browseId
                        )
                    },
                    songCountText = renderer.subtitle?.runs?.getOrNull(4)?.text,
                    thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                    playEndpoint = renderer.thumbnailOverlay
                        ?.musicItemThumbnailOverlayRenderer?.content
                        ?.musicPlayButtonRenderer?.playNavigationEndpoint
                        ?.watchPlaylistEndpoint ?: return null,
                    shuffleEndpoint = renderer.menu?.menuRenderer?.items?.find {
                        it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE"
                    }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint ?: return null,
                    radioEndpoint = renderer.menu.menuRenderer.items.find {
                        it.menuNavigationItemRenderer?.icon?.iconType == "MIX"
                    }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint ?: return null
                )
                else -> null
            }
        }
    }
}

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/ArtistPage.kt
// ----------------------------------------------------------------------------

data class ArtistSection(
    val title: String,
    val items: List<YTItem>,
    val moreEndpoint: BrowseEndpoint?,
)

data class ArtistPage(
    val artist: ArtistItem,
    val sections: List<ArtistSection>,
    val description: String?,
    val subscriberCountText: String?,
    val monthlyListenerCount: String? = null,
    val descriptionRuns: List<Run>? = null,
    val isSubscribed: Boolean = false,
) {
    companion object {
        fun fromSectionListRendererContent(content: SectionListRenderer.Content): ArtistSection? {
            return when {
                content.musicShelfRenderer != null -> fromMusicShelfRenderer(content.musicShelfRenderer)
                content.musicCarouselShelfRenderer != null -> fromMusicCarouselShelfRenderer(content.musicCarouselShelfRenderer)
                else -> null
            }
        }

        private fun fromMusicShelfRenderer(renderer: MusicShelfRenderer): ArtistSection? {
            return ArtistSection(
                title = renderer.title?.runs?.firstOrNull()?.text ?: "",
                items = renderer.contents?.getItems()?.mapNotNull {
                    fromMusicResponsiveListItemRenderer(it)
                }?.ifEmpty { null } ?: return null,
                moreEndpoint = renderer.title?.runs?.firstOrNull()?.navigationEndpoint?.browseEndpoint
            )
        }

        private fun fromMusicCarouselShelfRenderer(renderer: MusicCarouselShelfRenderer): ArtistSection? {
            return ArtistSection(
                title = renderer.header?.musicCarouselShelfBasicHeaderRenderer?.title?.runs?.firstOrNull()?.text ?: return null,
                items = renderer.contents.mapNotNull { content ->
                    content.musicTwoRowItemRenderer?.let { twoRowRenderer ->
                        fromMusicTwoRowItemRenderer(twoRowRenderer)
                    } ?: content.musicResponsiveListItemRenderer?.let { listItemRenderer ->
                        fromMusicResponsiveListItemRenderer(listItemRenderer)
                    }
                }.ifEmpty { null } ?: return null,
                moreEndpoint = renderer.header.musicCarouselShelfBasicHeaderRenderer.moreContentButton?.buttonRenderer?.navigationEndpoint?.browseEndpoint
            )
        }

        private fun fromMusicResponsiveListItemRenderer(renderer: MusicResponsiveListItemRenderer): SongItem? {
            val subtitleLine = renderer.flexColumns
                .getOrNull(1)
                ?.musicResponsiveListItemFlexColumnRenderer
                ?.text
                ?.runs

            val subtitleGroups = subtitleLine?.splitBySeparator()

            val artistRuns = subtitleGroups
                ?.getOrNull(0)
                ?.splitArtistsByConjunction()
                ?.filter { it.text.isNotBlank() && it.text != "&" && it.text != "," }
                ?.map { run ->
                    Artist(
                        name = run.text.trim(),
                        id = run.navigationEndpoint?.browseEndpoint?.browseId
                    )
                }

            val album = renderer.flexColumns.lastOrNull()
                ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs
                ?.firstOrNull()?.let {
                    if (it.navigationEndpoint?.browseEndpoint?.browseId != null) {
                        Album(
                            name = it.text,
                            id = it.navigationEndpoint.browseEndpoint.browseId
                        )
                    } else null
                }

            // Duration is in the last group after "•" separator in the subtitle line
            val durationFromSubtitle = subtitleGroups
                ?.drop(1)
                ?.firstOrNull { group ->
                    group.firstOrNull()?.text?.parseTime() != null
                }
                ?.firstOrNull()
                ?.text
                ?.parseTime()

            val libraryTokens = PageHelper.extractLibraryTokensFromMenuItems(renderer.menu?.menuRenderer?.items)

            return SongItem(
                id = renderer.playlistItemData?.videoId
                    ?: renderer.navigationEndpoint?.watchEndpoint?.videoId
                    ?: renderer.overlay?.musicItemThumbnailOverlayRenderer
                        ?.content?.musicPlayButtonRenderer
                        ?.playNavigationEndpoint?.watchEndpoint?.videoId
                    ?: renderer.flexColumns.firstOrNull()
                        ?.musicResponsiveListItemFlexColumnRenderer
                        ?.text?.runs?.firstOrNull()
                        ?.navigationEndpoint?.watchEndpoint?.videoId
                    ?: return null,
                title = renderer.flexColumns.firstOrNull()
                    ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()
                    ?.text ?: return null,
                artists = artistRuns ?: return null,
                album = album,
                duration = durationFromSubtitle
                    ?: renderer.fixedColumns?.firstOrNull()
                        ?.musicResponsiveListItemFlexColumnRenderer?.text
                        ?.runs?.firstOrNull()
                        ?.text?.parseTime(),
                musicVideoType = renderer.musicVideoType,
                thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                explicit = renderer.badges?.find {
                    it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                } != null,
                endpoint = renderer.overlay?.musicItemThumbnailOverlayRenderer?.content
                    ?.musicPlayButtonRenderer?.playNavigationEndpoint?.watchEndpoint,
                libraryAddToken = libraryTokens.addToken,
                libraryRemoveToken = libraryTokens.removeToken
            )
        }

        private fun fromMusicTwoRowItemRenderer(renderer: MusicTwoRowItemRenderer): YTItem? {
            return when {
                renderer.isSong -> {
                    val subtitleRuns = renderer.subtitle?.runs ?: return null
                    val expandedRuns = subtitleRuns.splitArtistsByConjunction()
                    val artistRuns = expandedRuns.filter { run ->
                        run.text.isNotBlank() && run.text != "&" && run.text != "," &&
                        run.navigationEndpoint?.browseEndpoint?.browseId?.startsWith("UC") == true
                    }
                    val subtitleGroups = subtitleRuns.splitBySeparator()
                    SongItem(
                        id = renderer.navigationEndpoint.watchEndpoint?.videoId ?: return null,
                        title = renderer.title.runs?.firstOrNull()?.text ?: return null,
                        artists = artistRuns.map { run ->
                            Artist(
                                name = run.text.trim(),
                                id = run.navigationEndpoint?.browseEndpoint?.browseId
                            )
                        }.ifEmpty { null } ?: return null,
                        album = null,
                        duration = subtitleGroups.lastOrNull()
                            ?.firstOrNull()
                            ?.takeIf { it.navigationEndpoint == null }
                            ?.text?.parseTime(),
                        musicVideoType = renderer.musicVideoType,
                        thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        explicit = renderer.subtitleBadges?.find {
                            it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                        } != null
                    )
                }

                renderer.isAlbum -> {
                    AlbumItem(
                        browseId = renderer.navigationEndpoint.browseEndpoint?.browseId ?: return null,
                        playlistId = renderer.thumbnailOverlay?.musicItemThumbnailOverlayRenderer?.content
                            ?.musicPlayButtonRenderer?.playNavigationEndpoint
                            ?.anyWatchEndpoint?.playlistId ?: return null,
                        title = renderer.title.runs?.firstOrNull()?.text ?: return null,
                        artists = null,
                        year = renderer.subtitle?.runs?.lastOrNull()?.text?.toIntOrNull(),
                        thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        explicit = renderer.subtitleBadges?.find {
                            it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                        } != null
                    )
                }

                renderer.isPlaylist -> {
                    // Playlist from YouTube Music
                    PlaylistItem(
                        id = renderer.navigationEndpoint.browseEndpoint?.browseId?.removePrefix("VL") ?: return null,
                        title = renderer.title.runs?.firstOrNull()?.text ?: return null,
                        author = Artist(
                            name = renderer.subtitle?.runs?.firstOrNull()?.text ?: return null,
                            id = null
                        ),
                        songCountText = null,
                        thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        playEndpoint = renderer.thumbnailOverlay
                            ?.musicItemThumbnailOverlayRenderer?.content
                            ?.musicPlayButtonRenderer?.playNavigationEndpoint
                            ?.watchPlaylistEndpoint ?: return null,
                        shuffleEndpoint = renderer.menu?.menuRenderer?.items?.find {
                            it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE"
                        }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint ?: return null,
                        radioEndpoint = renderer.menu.menuRenderer.items.find {
                            it.menuNavigationItemRenderer?.icon?.iconType == "MIX"
                        }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint ?: return null
                    )
                }

                renderer.isArtist -> {
                    ArtistItem(
                        id = renderer.navigationEndpoint.browseEndpoint?.browseId ?: return null,
                        title = renderer.title.runs?.lastOrNull()?.text ?: return null,
                        thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        channelId = renderer.menu?.menuRenderer?.items?.find {
                            it.toggleMenuServiceItemRenderer?.defaultIcon?.iconType == "SUBSCRIBE"
                        }?.toggleMenuServiceItemRenderer?.defaultServiceEndpoint?.subscribeEndpoint?.channelIds?.firstOrNull(),
                        shuffleEndpoint = renderer.menu?.menuRenderer?.items?.find {
                            it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE"
                        }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint ?: return null,
                        radioEndpoint = renderer.menu.menuRenderer.items.find {
                            it.menuNavigationItemRenderer?.icon?.iconType == "MIX"
                        }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint ?: return null,
                    )
                }

                renderer.isEpisode -> {
                    val videoId = renderer.thumbnailOverlay
                        ?.musicItemThumbnailOverlayRenderer?.content
                        ?.musicPlayButtonRenderer?.playNavigationEndpoint
                        ?.watchEndpoint?.videoId ?: return null
                    EpisodeItem(
                        id = videoId,
                        title = renderer.title.runs?.firstOrNull()?.text ?: return null,
                        author = renderer.subtitle?.runs?.firstOrNull()?.let {
                            Artist(name = it.text, id = it.navigationEndpoint?.browseEndpoint?.browseId)
                        },
                        thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        endpoint = WatchEndpoint(videoId = videoId),
                        publishDateText = renderer.subtitle?.runs?.lastOrNull()?.text,
                    )
                }

                renderer.isPodcast -> {
                    PodcastItem(
                        id = renderer.navigationEndpoint.browseEndpoint?.browseId ?: return null,
                        title = renderer.title.runs?.firstOrNull()?.text ?: return null,
                        author = renderer.subtitle?.runs?.firstOrNull()?.let {
                            Artist(name = it.text, id = it.navigationEndpoint?.browseEndpoint?.browseId)
                        },
                        episodeCountText = renderer.subtitle?.runs?.lastOrNull()?.text,
                        thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl(),
                        playEndpoint = renderer.thumbnailOverlay
                            ?.musicItemThumbnailOverlayRenderer?.content
                            ?.musicPlayButtonRenderer?.playNavigationEndpoint
                            ?.watchPlaylistEndpoint,
                        shuffleEndpoint = renderer.menu?.menuRenderer?.items?.find {
                            it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE"
                        }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint,
                    )
                }

                else -> null
            }
        }
    }
}

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/BrowseResult.kt
// ----------------------------------------------------------------------------

data class BrowseResult(
    val title: String?,
    val items: List<Item>,
) {
    data class Item(
        val title: String?,
        val items: List<YTItem>,
    )

    fun filterExplicit(enabled: Boolean = true) =
        if (enabled) {
            copy(
                items =
                    items.mapNotNull {
                        it.copy(
                            items =
                                it.items
                                    .filterExplicit()
                                    .ifEmpty { return@mapNotNull null },
                        )
                    },
            )
        } else {
            this
        }

    fun filterVideoSongs(disableVideos: Boolean = false) =
        if (disableVideos) {
            copy(
                items =
                    items.mapNotNull {
                        it.copy(
                            items =
                                it.items
                                    .filterVideoSongs(true)
                                    .ifEmpty { return@mapNotNull null },
                        )
                    },
            )
        } else {
            this
        }

    fun filterYoutubeShorts(enabled: Boolean = false) =
        if (enabled) {
            copy(
                items =
                    items.mapNotNull {
                        it.copy(
                            items =
                                it.items
                                    .filterYoutubeShorts(true)
                                    .ifEmpty { return@mapNotNull null },
                        )
                    },
            )
        } else {
            this
        }
}

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/ChartsPage.kt
// ----------------------------------------------------------------------------

data class ChartsPage(
    val sections: List<ChartSection>,
    val continuation: String?
) {
    data class ChartSection(
        val title: String,
        val items: List<YTItem>,
        val chartType: ChartType
    )

    enum class ChartType {
        TRENDING, TOP, GENRE, NEW_RELEASES
    }
}

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/ExplorePage.kt
// ----------------------------------------------------------------------------

data class ExplorePage(
    val newReleaseAlbums: List<AlbumItem>,
    val moodAndGenres: List<MoodAndGenres.Item>,
)

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/HistoryPage.kt
// ----------------------------------------------------------------------------

data class HistoryPage(
    val sections: List<HistorySection>?,
) {
    data class HistorySection(
        val title: String,
        val songs: List<SongItem>
    )

    companion object {
        fun fromMusicShelfRenderer(renderer: MusicShelfRenderer): HistorySection {
            return HistorySection(
                title = renderer.title?.runs?.firstOrNull()?.text!!,
                songs = renderer.contents?.getItems()?.mapNotNull {
                    fromMusicResponsiveListItemRenderer(it)
                }!!
            )
        }

        private fun fromMusicResponsiveListItemRenderer(renderer: MusicResponsiveListItemRenderer): SongItem? {
            // Extract library tokens using the new method that properly handles multiple toggle items
            val libraryTokens = PageHelper.extractLibraryTokensFromMenuItems(renderer.menu?.menuRenderer?.items)

            // Split the secondary line by bullet separator to separate artists from other metadata (like views)
            val secondaryLineRuns = renderer.flexColumns
                .getOrNull(1)
                ?.musicResponsiveListItemFlexColumnRenderer
                ?.text
                ?.runs
                ?.splitBySeparator()

            return SongItem(
                id = renderer.videoId ?: return null,
                title = renderer.flexColumns.firstOrNull()
                    ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()
                    ?.text ?: return null,
                artists = secondaryLineRuns?.firstOrNull()?.oddElements()?.map {
                    Artist(
                        name = it.text,
                        id = it.navigationEndpoint?.browseEndpoint?.browseId
                    )
                } ?: emptyList(),
                album = renderer.flexColumns.getOrNull(3)?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.let {
                    Album(
                        name = it.text,
                        id = it.navigationEndpoint?.browseEndpoint?.browseId ?: return@let null
                    )
                },
                duration = renderer.fixedColumns?.firstOrNull()?.musicResponsiveListItemFlexColumnRenderer
                    ?.text?.runs?.firstOrNull()?.text?.parseTime(),
                musicVideoType = renderer.musicVideoType,
                thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                explicit = renderer.badges?.find {
                    it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                } != null,
                endpoint = renderer.overlay?.musicItemThumbnailOverlayRenderer?.content
                    ?.musicPlayButtonRenderer?.playNavigationEndpoint?.watchEndpoint,
                libraryAddToken = libraryTokens.addToken,
                libraryRemoveToken = libraryTokens.removeToken,
                historyRemoveToken = renderer.menu?.menuRenderer?.items?.find {
                    it.menuServiceItemRenderer?.icon?.iconType == "REMOVE_FROM_HISTORY"
                }?.menuServiceItemRenderer?.serviceEndpoint?.feedbackEndpoint?.feedbackToken,
                isEpisode = renderer.isEpisode
            )
        }
    }
}

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/HomePage.kt
// ----------------------------------------------------------------------------

data class HomePage(
    val chips: List<Chip>?,
    val sections: List<Section>,
    val continuation: String? = null,
) {
    data class Chip(
        val title: String,
        val endpoint: BrowseEndpoint?,
        val deselectEndPoint: BrowseEndpoint?,
    ) {
        companion object {
            fun fromChipCloudChipRenderer(renderer: SectionListRenderer.Header.ChipCloudRenderer.Chip): Chip? {
                return Chip(
                    title = renderer.chipCloudChipRenderer.text?.runs?.firstOrNull()?.text ?: return null,
                    endpoint = renderer.chipCloudChipRenderer.navigationEndpoint?.browseEndpoint,
                    deselectEndPoint = renderer.chipCloudChipRenderer.onDeselectedCommand?.browseEndpoint,
                )
            }
        }
    }

    data class Section(
        val title: String,
        val label: String?,
        val thumbnail: String?,
        val endpoint: BrowseEndpoint?,
        val items: List<YTItem>,
    ) {
        companion object {
            fun fromMusicCarouselShelfRenderer(renderer: MusicCarouselShelfRenderer): Section? {
                val title = renderer.header?.musicCarouselShelfBasicHeaderRenderer?.title?.runs?.firstOrNull()?.text
                Timber.d("HomePage section title: $title, contents: ${renderer.contents.size}")

                if (title == null) {
                    Timber.d("HomePage section skipped: no title")
                    return null
                }

                val twoRowCount = renderer.contents.count { it.musicTwoRowItemRenderer != null }
                val multiRowCount = renderer.contents.count { it.musicMultiRowListItemRenderer != null }
                val responsiveCount = renderer.contents.count { it.musicResponsiveListItemRenderer != null }
                Timber.d("HomePage section '$title': twoRow=$twoRowCount, multiRow=$multiRowCount, responsive=$responsiveCount")

                val items = mutableListOf<YTItem>()

                // Parse musicTwoRowItemRenderer items (songs, albums, playlists, artists, podcasts)
                renderer.contents.mapNotNull { it.musicTwoRowItemRenderer }
                    .mapNotNull { fromMusicTwoRowItemRenderer(it) }
                    .let { items.addAll(it) }

                // Parse musicMultiRowListItemRenderer items (podcast episodes)
                renderer.contents.mapNotNull { it.musicMultiRowListItemRenderer }
                    .mapNotNull { fromMusicMultiRowListItemRenderer(it) }
                    .let { items.addAll(it) }

                // Parse musicResponsiveListItemRenderer items (quick picks songs)
                renderer.contents.mapNotNull { it.musicResponsiveListItemRenderer }
                    .mapNotNull { fromMusicResponsiveListItemRenderer(it) }
                    .let { items.addAll(it) }

                val moderatedItems = items.filter { com.listrovia.innertube.SongContentModerator.isItemAllowed(it) }
                val podcastCount = moderatedItems.count { it is PodcastItem }
                val episodeCount = moderatedItems.count { it is EpisodeItem }
                val songCount = moderatedItems.count { it is SongItem }
                Timber.d("HomePage section '$title': parsed ${moderatedItems.size} items (podcasts=$podcastCount, episodes=$episodeCount, songs=$songCount)")

                if (moderatedItems.isEmpty()) {
                    Timber.d("HomePage section '$title' skipped: no items after moderation")
                    return null
                }

                return Section(
                    title = title,
                    label = renderer.header.musicCarouselShelfBasicHeaderRenderer.strapline?.runs?.firstOrNull()?.text,
                    thumbnail = renderer.header.musicCarouselShelfBasicHeaderRenderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl(),
                    endpoint = renderer.header.musicCarouselShelfBasicHeaderRenderer.moreContentButton?.buttonRenderer?.navigationEndpoint?.browseEndpoint,
                    items = moderatedItems
                )
            }

            private fun fromMusicMultiRowListItemRenderer(renderer: MusicMultiRowListItemRenderer): EpisodeItem? {
                val subtitleRuns = renderer.subtitle?.runs?.splitBySeparator()
                val libraryTokens = PageHelper.extractLibraryTokensFromMenuItems(renderer.menu?.menuRenderer?.items)

                return EpisodeItem(
                    id = renderer.onTap?.watchEndpoint?.videoId ?: return null,
                    title = renderer.title?.runs?.firstOrNull()?.text ?: return null,
                    author = null,
                    podcast = null,
                    duration = subtitleRuns?.lastOrNull()?.firstOrNull()?.text?.parseTime(),
                    publishDateText = subtitleRuns?.firstOrNull()?.firstOrNull()?.text,
                    thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                    explicit = false,
                    endpoint = renderer.onTap.watchEndpoint,
                    libraryAddToken = libraryTokens.addToken,
                    libraryRemoveToken = libraryTokens.removeToken,
                )
            }

            private fun fromMusicResponsiveListItemRenderer(renderer: MusicResponsiveListItemRenderer): SongItem? {
                // Quick picks uses musicResponsiveListItemRenderer for songs
                if (!renderer.isSong) return null

                val secondaryLine = renderer.flexColumns
                    .getOrNull(1)
                    ?.musicResponsiveListItemFlexColumnRenderer
                    ?.text
                    ?.runs
                    ?.splitBySeparator()
                    ?: return null

                return SongItem(
                    id = renderer.videoId ?: return null,
                    title = renderer.flexColumns
                        .firstOrNull()
                        ?.musicResponsiveListItemFlexColumnRenderer
                        ?.text
                        ?.runs
                        ?.firstOrNull()
                        ?.text ?: return null,
                    artists = secondaryLine.getOrNull(0)?.oddElements()?.map {
                        Artist(
                            name = it.text,
                            id = it.navigationEndpoint?.browseEndpoint?.browseId
                        )
                    } ?: return null,
                    album = secondaryLine.getOrNull(1)?.firstOrNull()
                        ?.takeIf { it.navigationEndpoint?.browseEndpoint != null }
                        ?.let {
                            Album(
                                name = it.text,
                                id = it.navigationEndpoint?.browseEndpoint?.browseId!!
                            )
                        },
                    duration = secondaryLine.lastOrNull()?.firstOrNull()?.text?.parseTime(),
                    thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                    explicit = renderer.badges?.find {
                        it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                    } != null,
                    isEpisode = renderer.isEpisode
                )
            }

            private fun fromMusicTwoRowItemRenderer(renderer: MusicTwoRowItemRenderer): YTItem? {
                // Debug logging for type detection
                val title = renderer.title.runs?.firstOrNull()?.text ?: "unknown"
                val pageType = renderer.navigationEndpoint.browseEndpoint
                    ?.browseEndpointContextSupportedConfigs
                    ?.browseEndpointContextMusicConfig
                    ?.pageType
                val hasWatchEndpoint = renderer.navigationEndpoint.watchEndpoint != null

                if (!renderer.isSong && !renderer.isAlbum && !renderer.isPlaylist && !renderer.isArtist && !renderer.isPodcast && !renderer.isEpisode) {
                    Timber.d("HomePage twoRow '$title': no type matched - pageType=$pageType, hasWatchEndpoint=$hasWatchEndpoint")
                }

                // Debug for episodes
                if (renderer.isEpisode) {
                    val overlayVideoId = renderer.thumbnailOverlay
                        ?.musicItemThumbnailOverlayRenderer?.content
                        ?.musicPlayButtonRenderer?.playNavigationEndpoint
                        ?.watchEndpoint?.videoId
                    val browseId = renderer.navigationEndpoint.browseEndpoint?.browseId
                    Timber.d("HomePage episode '$title': overlayVideoId=$overlayVideoId, browseId=$browseId")
                }

                return when {
                    renderer.isSong -> {
                        val subtitleRuns = renderer.subtitle?.runs ?: return null
                        val artistRuns = subtitleRuns.filter {
                            it.navigationEndpoint?.browseEndpoint?.browseId?.startsWith("MPREb_") != true
                        }
                        val title = renderer.title.runs?.firstOrNull()?.text ?: return null
                        val videoId = renderer.navigationEndpoint.watchEndpoint?.videoId ?: return null
                        val artists = PageHelper.extractArtists(artistRuns).ifEmpty {
                            subtitleRuns.firstOrNull()?.let { run ->
                                listOf(Artist(name = run.text, id = null))
                            } ?: emptyList()
                        }

                        SongItem(
                            id = videoId,
                            title = title,
                            artists = artists,
                            album = subtitleRuns.firstOrNull {
                                it.navigationEndpoint?.browseEndpoint?.browseId?.startsWith("MPREb_") == true
                            }?.let {
                                Album(
                                    name = it.text,
                                    id = it.navigationEndpoint?.browseEndpoint?.browseId ?: return@let null
                                )
                            },
                            duration = null,
                            thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl()
                                ?: return null,
                            explicit = renderer.subtitleBadges?.any {
                                it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                            } == true
                        )
                    }
                    renderer.isAlbum -> {
                        AlbumItem(
                            browseId = renderer.navigationEndpoint.browseEndpoint?.browseId ?: return null,
                            playlistId = renderer.thumbnailOverlay?.musicItemThumbnailOverlayRenderer?.content
                                ?.musicPlayButtonRenderer?.playNavigationEndpoint
                                ?.watchPlaylistEndpoint?.playlistId ?: return null,
                            title = renderer.title.runs?.firstOrNull()?.text ?: return null,
                            artists = renderer.subtitle?.runs?.oddElements()?.drop(1)?.map {
                                Artist(
                                    name = it.text,
                                    id = it.navigationEndpoint?.browseEndpoint?.browseId
                                )
                            },
                            year = null,
                            thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                            explicit = renderer.subtitleBadges?.find {
                                it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                            } != null
                        )
                    }

                    renderer.isPlaylist -> {
                        PlaylistItem(
                            id = renderer.navigationEndpoint.browseEndpoint?.browseId?.removePrefix("VL") ?: return null,
                            title = renderer.title.runs?.firstOrNull()?.text ?: return null,
                            author = Artist(
                                name = renderer.subtitle?.runs?.firstOrNull()?.text ?: return null,
                                id = null
                            ),
                            songCountText = null,
                            thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                            playEndpoint = renderer.thumbnailOverlay
                                ?.musicItemThumbnailOverlayRenderer?.content
                                ?.musicPlayButtonRenderer?.playNavigationEndpoint
                                ?.watchPlaylistEndpoint ?: return null,
                            shuffleEndpoint = renderer.menu?.menuRenderer?.items?.find {
                                it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE"
                            }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint ?: return null,
                            radioEndpoint = renderer.menu.menuRenderer.items.find {
                                it.menuNavigationItemRenderer?.icon?.iconType == "MIX"
                            }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint
                        )
                    }

                    renderer.isArtist -> {
                        ArtistItem(
                            id = renderer.navigationEndpoint.browseEndpoint?.browseId ?: return null,
                            title = renderer.title.runs?.lastOrNull()?.text ?: return null,
                            thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                            shuffleEndpoint = renderer.menu?.menuRenderer?.items?.find {
                                it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE"
                            }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint ?: return null,
                            radioEndpoint = renderer.menu.menuRenderer.items.find {
                                it.menuNavigationItemRenderer?.icon?.iconType == "MIX"
                            }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint ?: return null,
                        )
                    }

                    renderer.isPodcast -> {
                        PodcastItem(
                            id = renderer.navigationEndpoint.browseEndpoint?.browseId ?: return null,
                            title = renderer.title.runs?.firstOrNull()?.text ?: return null,
                            author = renderer.subtitle?.runs?.firstOrNull()?.let {
                                Artist(
                                    name = it.text,
                                    id = it.navigationEndpoint?.browseEndpoint?.browseId
                                )
                            },
                            episodeCountText = null,
                            thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl(),
                            playEndpoint = renderer.thumbnailOverlay
                                ?.musicItemThumbnailOverlayRenderer?.content
                                ?.musicPlayButtonRenderer?.playNavigationEndpoint
                                ?.watchPlaylistEndpoint,
                            shuffleEndpoint = renderer.menu?.menuRenderer?.items?.find {
                                it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE"
                            }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint,
                        )
                    }

                    renderer.isEpisode -> {
                        val videoId = renderer.thumbnailOverlay
                            ?.musicItemThumbnailOverlayRenderer?.content
                            ?.musicPlayButtonRenderer?.playNavigationEndpoint
                            ?.watchEndpoint?.videoId
                        val titleText = renderer.title.runs?.firstOrNull()?.text
                        val thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl()

                        if (videoId == null || titleText == null || thumbnail == null) {
                            Timber.d("HomePage episode FAILED: videoId=$videoId, title=$titleText, thumbnail=$thumbnail")
                            return null
                        }

                        val subtitleRuns = renderer.subtitle?.runs?.splitBySeparator()
                        val libraryTokens = PageHelper.extractLibraryTokensFromMenuItems(renderer.menu?.menuRenderer?.items)

                        // Find podcast link in subtitle (has isPodcastEndpoint)
                        val podcastRun = renderer.subtitle?.runs?.find {
                            it.navigationEndpoint?.browseEndpoint?.isPodcastEndpoint == true
                        }
                        val podcastAlbum = podcastRun?.let {
                            Album(
                                name = it.text,
                                id = it.navigationEndpoint?.browseEndpoint?.browseId ?: return@let null
                            )
                        }

                        Timber.d("HomePage episode SUCCESS: '$titleText', podcast: ${podcastAlbum?.name}")
                        EpisodeItem(
                            id = videoId,
                            title = titleText,
                            author = subtitleRuns?.firstOrNull()?.firstOrNull()?.let {
                                Artist(
                                    name = it.text,
                                    id = it.navigationEndpoint?.browseEndpoint?.browseId
                                )
                            },
                            podcast = podcastAlbum,
                            duration = subtitleRuns?.lastOrNull()?.firstOrNull()?.text?.parseTime(),
                            publishDateText = subtitleRuns?.getOrNull(1)?.firstOrNull()?.text,
                            thumbnail = thumbnail,
                            explicit = renderer.subtitleBadges?.any {
                                it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                            } == true,
                            endpoint = renderer.thumbnailOverlay
                                .musicItemThumbnailOverlayRenderer.content
                                .musicPlayButtonRenderer.playNavigationEndpoint
                                .watchEndpoint,
                            libraryAddToken = libraryTokens.addToken,
                            libraryRemoveToken = libraryTokens.removeToken,
                        )
                    }

                    else -> null
                }
            }
        }
    }

    fun filterExplicit(enabled: Boolean = true) =
        if (enabled) {
            copy(sections = sections.map {
                it.copy(items = it.items.filterExplicit())
            })
        } else this

    fun filterVideoSongs(disableVideos: Boolean = false) =
        if (disableVideos) {
            copy(sections = sections.map { section ->
                section.copy(items = section.items.filterVideoSongs(true))
            })
        } else this
}

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/LibraryAlbumsPage.kt
// ----------------------------------------------------------------------------

data class LibraryAlbumsPage(
    val albums: List<AlbumItem>,
    val continuation: String?,
) {
    companion object {
        fun fromMusicTwoRowItemRenderer(renderer: MusicTwoRowItemRenderer): AlbumItem? {
            return AlbumItem(
                        browseId = renderer.navigationEndpoint.browseEndpoint?.browseId ?: return null,
                        playlistId = renderer.thumbnailOverlay?.musicItemThumbnailOverlayRenderer?.content
                            ?.musicPlayButtonRenderer?.playNavigationEndpoint
                            ?.watchPlaylistEndpoint?.playlistId ?: return null,
                        title = renderer.title.runs?.firstOrNull()?.text ?: return null,
                        artists = null,
                        year = renderer.subtitle?.runs?.lastOrNull()?.text?.toIntOrNull(),
                        thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        explicit = renderer.subtitleBadges?.find {
                            it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                        } != null
                    )
        }
    }
}

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/LibraryContinuationPage.kt
// ----------------------------------------------------------------------------

data class LibraryContinuationPage(
    val items: List<YTItem>,
    val continuation: String?,
)

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/LibraryPage.kt
// ----------------------------------------------------------------------------

data class LibraryPage(
    val items: List<YTItem>,
    val continuation: String?,
) {
    companion object {
        fun fromMusicTwoRowItemRenderer(renderer: MusicTwoRowItemRenderer): YTItem? {
            return when {
                renderer.isAlbum -> AlbumItem(
                    browseId = renderer.navigationEndpoint.browseEndpoint?.browseId ?: return null,
                    playlistId = renderer.thumbnailOverlay?.musicItemThumbnailOverlayRenderer?.content
                        ?.musicPlayButtonRenderer?.playNavigationEndpoint
                        ?.watchPlaylistEndpoint?.playlistId ?: return null,
                    title = renderer.title.runs?.firstOrNull()?.text ?: return null,
                    artists = parseArtists(renderer.subtitle?.runs),
                    year = renderer.subtitle?.runs?.lastOrNull()?.text?.toIntOrNull(),
                    thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl()
                        ?: return null,
                    explicit = renderer.subtitleBadges?.find {
                        it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                    } != null
                )

                renderer.isPlaylist -> PlaylistItem(
                    id = renderer.navigationEndpoint.browseEndpoint?.browseId?.removePrefix("VL") ?: return null,
                    title = renderer.title.runs?.firstOrNull()?.text ?: return null,
                    author = renderer.subtitle?.runs?.firstOrNull()?.let {
                        Artist(
                            name = it.text,
                            id = it.navigationEndpoint?.browseEndpoint?.browseId
                        )
                    },
                    songCountText = renderer.subtitle?.runs?.lastOrNull()?.text,
                    thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                    playEndpoint = renderer.thumbnailOverlay
                        ?.musicItemThumbnailOverlayRenderer?.content
                        ?.musicPlayButtonRenderer?.playNavigationEndpoint
                        ?.watchPlaylistEndpoint,
                    shuffleEndpoint = renderer.menu?.menuRenderer?.items?.find {
                        it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE"
                    }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint,
                    radioEndpoint = renderer.menu?.menuRenderer?.items?.find {
                        it.menuNavigationItemRenderer?.icon?.iconType == "MIX"
                    }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint,
                    isEditable = renderer.menu?.menuRenderer?.items?.find {
                        it.menuNavigationItemRenderer?.icon?.iconType == "EDIT"
                    } != null
                )

                renderer.isArtist -> ArtistItem(
                    id = renderer.navigationEndpoint.browseEndpoint?.browseId ?: return null,
                    title = renderer.title.runs?.lastOrNull()?.text ?: return null,
                    thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                    shuffleEndpoint = renderer.menu?.menuRenderer?.items?.find {
                        it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE"
                    }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint ?: return null,
                    radioEndpoint = renderer.menu.menuRenderer.items.find {
                        it.menuNavigationItemRenderer?.icon?.iconType == "MIX"
                    }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint ?: return null,
                )

                // Podcast host channels use MUSIC_PAGE_TYPE_USER_CHANNEL (not ARTIST)
                renderer.isUserChannel -> ArtistItem(
                    id = renderer.navigationEndpoint.browseEndpoint?.browseId ?: return null,
                    title = renderer.title.runs?.firstOrNull()?.text ?: return null,
                    thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl(),
                    shuffleEndpoint = renderer.menu?.menuRenderer?.items?.find {
                        it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE"
                    }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint,
                    radioEndpoint = renderer.menu?.menuRenderer?.items?.find {
                        it.menuNavigationItemRenderer?.icon?.iconType == "MIX"
                    }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint,
                )

                renderer.isPodcast -> {
                    val libraryTokens = PageHelper.extractLibraryTokensFromMenuItems(renderer.menu?.menuRenderer?.items)
                    PodcastItem(
                        id = renderer.navigationEndpoint.browseEndpoint?.browseId ?: return null,
                        title = renderer.title.runs?.firstOrNull()?.text ?: return null,
                        author = renderer.subtitle?.runs?.firstOrNull()?.let {
                            Artist(
                                name = it.text,
                                id = it.navigationEndpoint?.browseEndpoint?.browseId
                            )
                        },
                        episodeCountText = renderer.subtitle?.runs?.lastOrNull()?.text,
                        thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl(),
                        playEndpoint = renderer.thumbnailOverlay
                            ?.musicItemThumbnailOverlayRenderer?.content
                            ?.musicPlayButtonRenderer?.playNavigationEndpoint
                            ?.watchPlaylistEndpoint,
                        shuffleEndpoint = renderer.menu?.menuRenderer?.items?.find {
                            it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE"
                        }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint,
                        libraryAddToken = libraryTokens.addToken,
                        libraryRemoveToken = libraryTokens.removeToken,
                    )
                }

                renderer.isEpisode || renderer.isSong -> {
                    val libraryTokens = PageHelper.extractLibraryTokensFromMenuItems(renderer.menu?.menuRenderer?.items)
                    val videoId = renderer.thumbnailOverlay
                        ?.musicItemThumbnailOverlayRenderer?.content
                        ?.musicPlayButtonRenderer?.playNavigationEndpoint
                        ?.watchEndpoint?.videoId ?: return null
                    val title = renderer.title.runs?.firstOrNull()?.text ?: return null
                    val subtitleRuns = renderer.subtitle?.runs?.splitBySeparator()
                    val artists = PageHelper.extractArtists(subtitleRuns?.firstOrNull())
                    
                    if (artists.isEmpty() && (subtitleRuns?.firstOrNull()?.size ?: 0) > 0) {
                        Timber.w("LibraryPage: Song '$title' (id=$videoId) - ARTIST RUNS EXIST but extractArtists returned EMPTY")
                    }
                    
                    SongItem(
                        id = videoId,
                        title = title,
                        artists = artists,
                        album = subtitleRuns?.getOrNull(1)?.firstOrNull()?.let {
                            Album(
                                name = it.text,
                                id = it.navigationEndpoint?.browseEndpoint?.browseId ?: ""
                            )
                        },
                        duration = subtitleRuns?.lastOrNull()?.firstOrNull()?.text?.parseTime(),
                        thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        explicit = renderer.subtitleBadges?.any {
                            it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                        } == true,
                        endpoint = renderer.thumbnailOverlay
                            .musicItemThumbnailOverlayRenderer.content
                            .musicPlayButtonRenderer.playNavigationEndpoint
                            .watchEndpoint,
                        libraryAddToken = libraryTokens.addToken,
                        libraryRemoveToken = libraryTokens.removeToken,
                        isEpisode = renderer.isEpisode,
                    )
                }

                else -> null
            }
        }

        fun fromMusicResponsiveListItemRenderer(renderer: MusicResponsiveListItemRenderer): YTItem? {
            // Extract library tokens using the new method that properly handles multiple toggle items
            val libraryTokens = PageHelper.extractLibraryTokensFromMenuItems(renderer.menu?.menuRenderer?.items)

            return when {
                renderer.isSong -> {
                    val videoId = renderer.videoId ?: return null
                    val title = renderer.flexColumns.firstOrNull()
                        ?.musicResponsiveListItemFlexColumnRenderer?.text
                        ?.runs?.firstOrNull()?.text ?: return null

                    val artistRuns = renderer.flexColumns.getOrNull(1)?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.oddElements()

                    // For uploaded songs, artists may not have browseEndpoint - make it optional
                    val artists = artistRuns?.mapNotNull {
                        val browseId = it.navigationEndpoint?.browseEndpoint?.browseId
                        // For uploaded songs, use empty string for artist ID if not available
                        Artist(name = it.text, id = browseId ?: "")
                    } ?: emptyList()

                    val albumRun = renderer.flexColumns.getOrNull(2)?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()

                    // For uploaded songs, album may not have browseEndpoint - make it optional
                    val album = albumRun?.let {
                        val albumBrowseId = it.navigationEndpoint?.browseEndpoint?.browseId
                        Album(name = it.text, id = albumBrowseId ?: "")
                    }

                    val thumbnailUrl = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null

                    // Extract uploadEntityId from delete menu item (for uploaded songs)
                    // The entityId is nested in confirmDialogEndpoint -> content -> confirmDialogRenderer ->
                    // confirmButton -> buttonRenderer -> command -> musicDeletePrivatelyOwnedEntityCommand -> entityId
                    val uploadEntityId = renderer.menu?.menuRenderer?.items?.firstNotNullOfOrNull { item ->
                        item.menuNavigationItemRenderer?.navigationEndpoint?.confirmDialogEndpoint
                            ?.content?.confirmDialogRenderer?.confirmButton?.buttonRenderer
                            ?.command?.musicDeletePrivatelyOwnedEntityCommand?.entityId
                    }
                    timber.log.Timber.d("Parsed uploaded song: id=$videoId, entityId=$uploadEntityId")

                    SongItem(
                        id = videoId,
                        title = title,
                        artists = artists,
                        album = album,
                        duration = renderer.fixedColumns?.firstOrNull()?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.text?.parseTime(),
                        musicVideoType = renderer.musicVideoType,
                        thumbnail = thumbnailUrl,
                        explicit = renderer.badges?.find {
                            it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                        } != null,
                        endpoint = renderer.overlay?.musicItemThumbnailOverlayRenderer?.content?.musicPlayButtonRenderer?.playNavigationEndpoint?.watchEndpoint,
                        libraryAddToken = libraryTokens.addToken,
                        libraryRemoveToken = libraryTokens.removeToken,
                        isEpisode = renderer.isEpisode,
                        uploadEntityId = uploadEntityId
                    )
                }

                renderer.isArtist -> ArtistItem(
                    id = renderer.navigationEndpoint?.browseEndpoint?.browseId ?: return null,
                    title = renderer.flexColumns.firstOrNull()?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.text
                        ?: return null,
                    thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl()
                        ?: return null,
                    shuffleEndpoint = renderer.menu?.menuRenderer?.items
                        ?.find { it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE" }
                        ?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint,
                    radioEndpoint = renderer.menu?.menuRenderer?.items
                        ?.find { it.menuNavigationItemRenderer?.icon?.iconType == "MIX" }
                        ?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint
                )

                // Podcast host channels use MUSIC_PAGE_TYPE_USER_CHANNEL (not ARTIST)
                renderer.isUserChannel -> ArtistItem(
                    id = renderer.navigationEndpoint?.browseEndpoint?.browseId ?: return null,
                    title = renderer.flexColumns.firstOrNull()?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.text
                        ?: return null,
                    thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl(),
                    shuffleEndpoint = renderer.menu?.menuRenderer?.items
                        ?.find { it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE" }
                        ?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint,
                    radioEndpoint = renderer.menu?.menuRenderer?.items
                        ?.find { it.menuNavigationItemRenderer?.icon?.iconType == "MIX" }
                        ?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint
                )

                renderer.isPodcast -> {
                    val podcastLibraryTokens = PageHelper.extractLibraryTokensFromMenuItems(renderer.menu?.menuRenderer?.items)
                    PodcastItem(
                        id = renderer.navigationEndpoint?.browseEndpoint?.browseId ?: return null,
                        title = renderer.flexColumns.firstOrNull()?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.text
                            ?: return null,
                        author = renderer.flexColumns.getOrNull(1)?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.let {
                            Artist(
                                name = it.text,
                                id = it.navigationEndpoint?.browseEndpoint?.browseId
                            )
                        },
                        episodeCountText = renderer.flexColumns.getOrNull(1)?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.lastOrNull()?.text,
                        thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl(),
                        playEndpoint = renderer.overlay?.musicItemThumbnailOverlayRenderer?.content?.musicPlayButtonRenderer?.playNavigationEndpoint?.watchPlaylistEndpoint,
                        shuffleEndpoint = renderer.menu?.menuRenderer?.items
                            ?.find { it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE" }
                            ?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint,
                        libraryAddToken = podcastLibraryTokens.addToken,
                        libraryRemoveToken = podcastLibraryTokens.removeToken,
                    )
                }

                else -> null
            }
        }

        private fun parseArtists(runs: List<Run>?): List<Artist> {
            val artists = mutableListOf<Artist>()

            if (runs != null) {
                for (run in runs) {
                    if (run.navigationEndpoint != null) {
                        artists.add(
                            Artist(
                                id = run.navigationEndpoint.browseEndpoint?.browseId!!,
                                name = run.text
                            )
                        )
                    }
                }
            }
            return artists
        }
    }
}

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/MoodAndGenres.kt
// ----------------------------------------------------------------------------

data class MoodAndGenres(
    val title: String,
    val items: List<Item>,
) {
    data class Item(
        val title: String,
        val stripeColor: Long,
        val endpoint: BrowseEndpoint,
    )

    companion object {
        fun fromSectionListRendererContent(content: SectionListRenderer.Content): MoodAndGenres? {
            return MoodAndGenres(
                title =
                    content.gridRenderer
                        ?.header
                        ?.gridHeaderRenderer
                        ?.title
                        ?.runs
                        ?.firstOrNull()
                        ?.text ?: return null,
                items =
                    content.gridRenderer.items
                        .mapNotNull(GridRenderer.Item::musicNavigationButtonRenderer)
                        .mapNotNull(::fromMusicNavigationButtonRenderer),
            )
        }

        fun fromMusicNavigationButtonRenderer(renderer: MusicNavigationButtonRenderer): Item? {
            return Item(
                title =
                    renderer.buttonText.runs
                        ?.firstOrNull()
                        ?.text ?: return null,
                stripeColor = renderer.solid?.leftStripeColor ?: return null,
                endpoint = renderer.clickCommand.browseEndpoint ?: return null,
            )
        }
    }
}

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/NewPipe.kt
// ----------------------------------------------------------------------------

private class NewPipeDownloaderImpl(
    proxy: Proxy?,
    proxyAuth: String?,
) : Downloader() {
    private fun normalizeResponseBody(
        url: String,
        body: String?,
    ): String? {
        if (!url.contains("returnyoutubedislikeapi.com", ignoreCase = true)) {
            return body
        }

        val trimmed = body?.trimStart().orEmpty()
        if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
            return body
        }

        return "{\"likes\":0,\"dislikes\":0,\"viewCount\":0}"
    }

    private val client =
        OkHttpClient
            .Builder()
            .proxy(proxy)
            .proxyAuthenticator { _, response ->
                proxyAuth?.let { auth ->
                    response.request
                        .newBuilder()
                        .header("Proxy-Authorization", auth)
                        .build()
                } ?: response.request
            }.build()

    @Throws(IOException::class, ReCaptchaException::class)
    override fun execute(request: org.schabi.newpipe.extractor.downloader.Request): org.schabi.newpipe.extractor.downloader.Response {
        val httpMethod = request.httpMethod()
        val url = request.url()
        val headers = request.headers()
        val dataToSend = request.dataToSend()

        val requestBuilder =
            okhttp3.Request
                .Builder()
                .method(httpMethod, dataToSend?.toRequestBody())
                .url(url)
                .addHeader("User-Agent", YouTubeClient.USER_AGENT_WEB)

        headers.forEach { (headerName, headerValueList) ->
            if (headerValueList.size > 1) {
                requestBuilder.removeHeader(headerName)
                headerValueList.forEach { headerValue ->
                    requestBuilder.addHeader(headerName, headerValue)
                }
            } else if (headerValueList.size == 1) {
                requestBuilder.header(headerName, headerValueList[0])
            }
        }

        val response = client.newCall(requestBuilder.build()).execute()

        if (response.code == 429) {
            response.close()

            throw ReCaptchaException("reCaptcha Challenge requested", url)
        }

        val latestUrl = response.request.url.toString()
        val responseBodyToReturn = normalizeResponseBody(latestUrl, response.body?.string() ?: "")
        return org.schabi.newpipe.extractor.downloader.Response(
            response.code,
            response.message,
            response.headers.toMultimap(),
            responseBodyToReturn,
            latestUrl,
        )
    }
}

object NewPipeUtils {
    init {
        NewPipe.init(NewPipeDownloaderImpl(YouTube.proxy, YouTube.proxyAuth))
    }

    fun getSignatureTimestamp(videoId: String): Result<Int> = Result.failure(Exception("NewPipe STS not available"))

    fun getStreamUrl(format: PlayerResponse.StreamingData.Format, videoId: String): Result<String> =
        runCatching {
            format.url ?: format.signatureCipher?.let { signatureCipher ->
                runBlocking { CipherDeobfuscator.deobfuscateStreamUrl(signatureCipher, videoId) }
            } ?: throw ParsingException("Could not find format url")
        }
}

object NewPipeExtractor {
    init {
        NewPipeUtils
    }

    fun getStreamInfo(videoId: String): StreamInfo {
        return StreamInfo.getInfo(
            NewPipe.getService(0),
            "https://www.youtube.com/watch?v=$videoId"
        )
    }

    fun newPipePlayer(videoId: String): List<Pair<Int, String>> {
        return try {
            val streamInfo =
                StreamInfo.getInfo(
                    NewPipe.getService(0),
                    "https://www.youtube.com/watch?v=$videoId",
                )
            val streamsList = streamInfo.audioStreams + streamInfo.videoStreams + streamInfo.videoOnlyStreams
            streamsList.mapNotNull {
                (it.itagItem?.id ?: return@mapNotNull null) to it.content
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun getSignatureTimestamp(videoId: String): Result<Int> = Result.failure(Exception("NewPipe STS not available"))

    fun getStreamUrl(format: PlayerResponse.StreamingData.Format, videoId: String): String? {
        return format.url ?: format.signatureCipher?.let { signatureCipher ->
            runBlocking { CipherDeobfuscator.deobfuscateStreamUrl(signatureCipher, videoId) }
        }
    }
}

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/NewReleaseAlbumPage.kt
// ----------------------------------------------------------------------------

object NewReleaseAlbumPage {
    fun fromMusicTwoRowItemRenderer(renderer: MusicTwoRowItemRenderer): AlbumItem? {
        return AlbumItem(
            browseId = renderer.navigationEndpoint.browseEndpoint?.browseId ?: return null,
            playlistId =
                renderer.thumbnailOverlay
                    ?.musicItemThumbnailOverlayRenderer
                    ?.content
                    ?.musicPlayButtonRenderer
                    ?.playNavigationEndpoint
                    ?.watchPlaylistEndpoint
                    ?.playlistId ?: return null,
            title =
                renderer.title.runs
                    ?.firstOrNull()
                    ?.text ?: return null,
            artists =
                renderer.subtitle?.runs?.splitBySeparator()?.getOrNull(1)?.oddElements()?.map {
                    Artist(
                        name = it.text,
                        id = it.navigationEndpoint?.browseEndpoint?.browseId,
                    )
                } ?: return null,
            year =
                renderer.subtitle.runs
                    .lastOrNull()
                    ?.text
                    ?.toIntOrNull(),
            thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
            explicit =
                renderer.subtitleBadges?.find {
                    it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                } != null,
        )
    }
}

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/NextPage.kt
// ----------------------------------------------------------------------------

data class NextResult(
    val title: String? = null,
    val items: List<SongItem>,
    val currentIndex: Int? = null,
    val lyricsEndpoint: BrowseEndpoint? = null,
    val relatedEndpoint: BrowseEndpoint? = null,
    val continuation: String?,
    val endpoint: WatchEndpoint, // current or continuation next endpoint
)

object NextPage {
    fun fromPlaylistPanelVideoRenderer(renderer: PlaylistPanelVideoRenderer): SongItem? {
        val longByLineRuns = renderer.longBylineText?.runs?.splitBySeparator() ?: return null

        // Extract library tokens using the new method that properly handles multiple toggle items
        val libraryTokens = PageHelper.extractLibraryTokensFromMenuItems(renderer.menu?.menuRenderer?.items)

        val title = renderer.title
            ?.runs
            ?.firstOrNull()
            ?.text ?: return null

        val artists = longByLineRuns.firstOrNull()?.oddElements()?.map {
            Artist(
                name = it.text,
                id = it.navigationEndpoint?.browseEndpoint?.browseId,
            )
        } ?: return null

        if (!com.listrovia.innertube.SongContentModerator.isAllowed(title, artists.firstOrNull()?.name)) {
            return null
        }

        return SongItem(
            id = renderer.videoId
                ?: renderer.navigationEndpoint.watchEndpoint?.videoId
                ?: return null,
            title = title,
            artists = artists,
            album =
                longByLineRuns
                    .getOrNull(1)
                    ?.firstOrNull()
                    ?.takeIf {
                        it.navigationEndpoint?.browseEndpoint != null
                    }?.let {
                        Album(
                            name = it.text,
                            id = it.navigationEndpoint?.browseEndpoint?.browseId!!,
                        )
                    },
            duration =
                renderer.lengthText
                    ?.runs
                    ?.firstOrNull()
                    ?.text
                    ?.parseTime() ?: return null,
            musicVideoType = renderer.navigationEndpoint.musicVideoType,
            thumbnail =
                renderer.thumbnail.thumbnails
                    .lastOrNull()
                    ?.url ?: return null,
            explicit =
                renderer.badges?.find {
                    it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                } != null,
            libraryAddToken = libraryTokens.addToken,
            libraryRemoveToken = libraryTokens.removeToken
        )
    }
}

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/PageHelper.kt
// ----------------------------------------------------------------------------

object PageHelper {
    // Icon types for library management (YouTube changed these in Feb 2026)
    // Old icons: LIBRARY_ADD (not in library), LIBRARY_SAVED/LIBRARY_REMOVE (in library)
    // New icons: BOOKMARK_BORDER (not in library), BOOKMARK (in library)
    // Note: KEEP/KEEP_OFF are for "Pin to Listen Again" - different from library!
    private val LIBRARY_ADD_ICONS = setOf("LIBRARY_ADD", "BOOKMARK_BORDER")
    private val LIBRARY_SAVED_ICONS = setOf("LIBRARY_SAVED", "BOOKMARK", "LIBRARY_REMOVE")
    private val ALL_LIBRARY_ICONS = LIBRARY_ADD_ICONS + LIBRARY_SAVED_ICONS

    /**
     * Data class to hold both library feedback tokens extracted from a menu
     */
    data class LibraryFeedbackTokens(
        val addToken: String?,      // Token to add song to library (from BOOKMARK_BORDER)
        val removeToken: String?    // Token to remove song from library (from BOOKMARK)
    )

    /**
     * Check if an icon type is a library-related icon (for filtering menu items)
     * Excludes KEEP/KEEP_OFF which are for "Pin to Listen Again"
     */
    fun isLibraryIcon(iconType: String?): Boolean {
        if (iconType == null) return false
        // Exclude KEEP/KEEP_OFF (Listen Again pins)
        if (iconType == "KEEP" || iconType == "KEEP_OFF") return false
        return iconType in ALL_LIBRARY_ICONS || iconType.startsWith("LIBRARY_")
    }

    /**
     * Check if an icon type indicates the song is NOT in library (add state)
     */
    fun isAddLibraryIcon(iconType: String?): Boolean {
        return iconType in LIBRARY_ADD_ICONS
    }

    /**
     * Check if an icon type indicates the song IS in library (saved/remove state)
     */
    fun isSavedLibraryIcon(iconType: String?): Boolean {
        return iconType in LIBRARY_SAVED_ICONS
    }

    fun extractRuns(columns: List<FlexColumn>, typeLike: String): List<Run> {
        val filteredRuns = mutableListOf<Run>()
        for (column in columns) {
            val runs = column.musicResponsiveListItemFlexColumnRenderer.text?.runs
                ?: continue

            for (run in runs) {
                val typeStr = run.navigationEndpoint?.watchEndpoint?.watchEndpointMusicSupportedConfigs?.watchEndpointMusicConfig?.musicVideoType
                    ?: run.navigationEndpoint?.browseEndpoint?.browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType
                    ?: continue

                if (typeLike in typeStr) {
                    filteredRuns.add(run)
                }
            }
        }
        return filteredRuns
    }

    /**
     * Extract library feedback tokens from a list of menu items.
     *
     * This function iterates through ALL toggle menu items and extracts tokens
     * based on their icon types, ensuring we don't confuse library tokens with
     * "Pin to Listen Again" tokens (KEEP/KEEP_OFF).
     *
     * YouTube's icon system (Feb 2026):
     * - BOOKMARK_BORDER: Song NOT in library -> defaultToken = ADD, toggledToken = REMOVE
     * - BOOKMARK: Song IS in library -> defaultToken = REMOVE, toggledToken = ADD
     * - KEEP/KEEP_OFF: "Pin to Listen Again" - COMPLETELY DIFFERENT, must be ignored!
     *
     * @param menuItems The list of menu items to search through
     * @return LibraryFeedbackTokens containing both add and remove tokens
     */
    fun extractLibraryTokensFromMenuItems(
        menuItems: List<Menu.MenuRenderer.Item>?
    ): LibraryFeedbackTokens {
        if (menuItems == null) return LibraryFeedbackTokens(null, null)

        var addToken: String? = null
        var removeToken: String? = null

        for (item in menuItems) {
            val toggleRenderer = item.toggleMenuServiceItemRenderer ?: continue
            val iconType = toggleRenderer.defaultIcon.iconType

            // Skip KEEP/KEEP_OFF icons (Pin to Listen Again) - these are NOT library actions
            if (iconType == "KEEP" || iconType == "KEEP_OFF") continue

            // Only process library-related icons
            if (!isLibraryIcon(iconType)) continue

            val defaultToken = toggleRenderer.defaultServiceEndpoint.feedbackEndpoint?.feedbackToken
            val toggledToken = toggleRenderer.toggledServiceEndpoint?.feedbackEndpoint?.feedbackToken

            // Determine which token is which based on icon type
            when {
                isAddLibraryIcon(iconType) -> {
                    // BOOKMARK_BORDER or LIBRARY_ADD: default=add, toggled=remove
                    if (addToken == null) addToken = defaultToken
                    if (removeToken == null) removeToken = toggledToken
                }
                isSavedLibraryIcon(iconType) -> {
                    // BOOKMARK or LIBRARY_SAVED/REMOVE: default=remove, toggled=add
                    if (removeToken == null) removeToken = defaultToken
                    if (addToken == null) addToken = toggledToken
                }
            }
        }

        return LibraryFeedbackTokens(addToken, removeToken)
    }

    /**
     * Extract feedback token for library operations.
     *
     * YouTube's new icon system (Feb 2026):
     * - BOOKMARK_BORDER: Song NOT in library -> defaultToken = ADD, toggledToken = REMOVE
     * - BOOKMARK: Song IS in library -> defaultToken = REMOVE, toggledToken = ADD
     *
     * @param menu The toggle menu renderer containing the feedback tokens
     * @param type "LIBRARY_ADD" to get the add token, "LIBRARY_REMOVE" to get the remove token
     * @return The appropriate feedback token, or null if not found
     */
    fun extractFeedbackToken(menu: Menu.MenuRenderer.Item.ToggleMenuServiceRenderer?, type: String): String? {
        if (menu == null) return null
        val defaultToken = menu.defaultServiceEndpoint.feedbackEndpoint?.feedbackToken
        val toggledToken = menu.toggledServiceEndpoint?.feedbackEndpoint?.feedbackToken
        val iconType = menu.defaultIcon.iconType

        // Determine if the current icon indicates song is NOT in library
        // BOOKMARK_BORDER or LIBRARY_ADD = song is NOT in library (default action is ADD)
        val songNotInLibrary = iconType in LIBRARY_ADD_ICONS

        return when (type) {
            "LIBRARY_ADD" -> {
                // We want the ADD token
                if (songNotInLibrary) {
                    // Icon shows "add" state, default action adds to library
                    defaultToken
                } else {
                    // Icon shows "saved" state, toggled action would add back
                    toggledToken
                }
            }
            "LIBRARY_REMOVE", "LIBRARY_SAVED" -> {
                // We want the REMOVE token
                if (songNotInLibrary) {
                    // Icon shows "add" state, toggled action would remove
                    toggledToken
                } else {
                    // Icon shows "saved" state, default action removes from library
                    defaultToken
                }
            }
            else -> if (iconType == type) defaultToken else toggledToken
        }
    }

    fun extractArtists(runs: List<Run>?): List<Artist> {
        if (runs == null) {
            Timber.d("extractArtists: runs is null")
            return emptyList()
        }
        
        Timber.d("extractArtists: input runs count=${runs.size}")
        runs.forEachIndexed { idx, run ->
            Timber.v("  run[$idx]: text='${run.text}', hasEndpoint=${run.navigationEndpoint != null}, browseId=${run.navigationEndpoint?.browseEndpoint?.browseId}")
        }
        
        val filtered = runs.filter { run ->
            run.text.trim().isNotBlank() && run.text != " • "
        }
        Timber.d("extractArtists: after separator filter count=${filtered.size}")
        
        val result = filtered.map { run ->
            Artist(
                name = run.text,
                id = run.navigationEndpoint?.browseEndpoint?.browseId
            )
        }
        
        if (result.isEmpty()) {
            Timber.w("extractArtists: EMPTY RESULT from ${runs.size} runs")
        } else {
            Timber.d("extractArtists: result count=${result.size}")
            result.forEach { artist ->
                Timber.v("  artist: name='${artist.name}', id=${artist.id}")
            }
        }
        
        return result
    }
}

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/PlaylistContinuationPage.kt
// ----------------------------------------------------------------------------

data class PlaylistContinuationPage(
    val songs: List<SongItem>,
    val continuation: String?,
)

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/PlaylistPage.kt
// ----------------------------------------------------------------------------

data class PlaylistPage(
    val playlist: PlaylistItem,
    val songs: List<SongItem>,
    val songsContinuation: String?,
    val continuation: String?,
) {
    companion object {
        fun fromMusicResponsiveListItemRenderer(renderer: MusicResponsiveListItemRenderer): SongItem? {
            val libraryTokens = PageHelper.extractLibraryTokensFromMenuItems(renderer.menu?.menuRenderer?.items)

            val secondaryLineRuns = renderer.flexColumns
                .getOrNull(1)
                ?.musicResponsiveListItemFlexColumnRenderer
                ?.text
                ?.runs

            val title = renderer.flexColumns.firstOrNull()
                ?.musicResponsiveListItemFlexColumnRenderer?.text
                ?.runs?.firstOrNull()?.text ?: return null

            if (secondaryLineRuns == null) {
                Timber.w("PlaylistPage.fromMusicResponsiveListItemRenderer: Song '$title' - NO SECONDARY LINE (flexColumns[1] is null)")
            }

            val artists = PageHelper.extractArtists(secondaryLineRuns)

            return SongItem(
                id = renderer.videoId ?: return null,
                title = title,
                artists = artists,
                album = renderer.flexColumns.getOrNull(2)?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.let {
                    Album(
                        name = it.text,
                        id = it.navigationEndpoint?.browseEndpoint?.browseId ?: return@let null
                    )
                },
                duration = renderer.fixedColumns?.firstOrNull()?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.text?.parseTime(),
                musicVideoType = renderer.musicVideoType,
                thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                explicit = renderer.badges?.find {
                    it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                } != null,
                endpoint = renderer.overlay?.musicItemThumbnailOverlayRenderer?.content?.musicPlayButtonRenderer?.playNavigationEndpoint?.watchEndpoint,
                setVideoId = renderer.playlistSetVideoId ?: return null,
                libraryAddToken = libraryTokens.addToken,
                libraryRemoveToken = libraryTokens.removeToken,
                isEpisode = renderer.isEpisode
            )
        }
    }
}

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/PodcastPage.kt
// ----------------------------------------------------------------------------

data class PodcastPage(
    val podcast: PodcastItem,
    val episodes: List<EpisodeItem>,
    val continuation: String?,
    val isChannelSubscribed: Boolean = false,
) {
    companion object {
        fun fromMusicMultiRowListItemRenderer(
            renderer: MusicMultiRowListItemRenderer,
            podcast: PodcastItem? = null
        ): EpisodeItem? {
            val subtitleRuns = renderer.subtitle?.runs?.splitBySeparator()
            val libraryTokens = PageHelper.extractLibraryTokensFromMenuItems(renderer.menu?.menuRenderer?.items)

            return EpisodeItem(
                id = renderer.onTap?.watchEndpoint?.videoId ?: return null,
                title = renderer.title?.runs?.firstOrNull()?.text ?: return null,
                author = podcast?.author,
                podcast = podcast?.let {
                    Album(name = it.title, id = it.id)
                },
                duration = subtitleRuns?.lastOrNull()?.firstOrNull()?.text?.parseTime(),
                publishDateText = subtitleRuns?.firstOrNull()?.firstOrNull()?.text,
                thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                explicit = false,
                endpoint = renderer.onTap.watchEndpoint,
                libraryAddToken = libraryTokens.addToken,
                libraryRemoveToken = libraryTokens.removeToken,
            )
        }

        fun fromMusicResponsiveListItemRenderer(
            renderer: MusicResponsiveListItemRenderer,
            podcast: PodcastItem? = null
        ): EpisodeItem? {
            val secondaryLineRuns = renderer.flexColumns
                .getOrNull(1)
                ?.musicResponsiveListItemFlexColumnRenderer
                ?.text
                ?.runs
                ?.splitBySeparator()
            val libraryTokens = PageHelper.extractLibraryTokensFromMenuItems(renderer.menu?.menuRenderer?.items)

            return EpisodeItem(
                id = renderer.videoId ?: return null,
                title = renderer.flexColumns.firstOrNull()
                    ?.musicResponsiveListItemFlexColumnRenderer?.text
                    ?.runs?.firstOrNull()?.text ?: return null,
                author = podcast?.author ?: secondaryLineRuns?.firstOrNull()?.firstOrNull()?.let {
                    Artist(
                        name = it.text,
                        id = it.navigationEndpoint?.browseEndpoint?.browseId,
                    )
                },
                podcast = podcast?.let {
                    Album(name = it.title, id = it.id)
                },
                duration = secondaryLineRuns?.lastOrNull()?.firstOrNull()?.text?.parseTime(),
                publishDateText = secondaryLineRuns?.getOrNull(1)?.firstOrNull()?.text,
                thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                explicit = renderer.badges?.find {
                    it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                } != null,
                endpoint = renderer.overlay?.musicItemThumbnailOverlayRenderer?.content?.musicPlayButtonRenderer?.playNavigationEndpoint?.watchEndpoint,
                libraryAddToken = libraryTokens.addToken,
                libraryRemoveToken = libraryTokens.removeToken,
            )
        }
    }
}

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/RelatedPage.kt
// ----------------------------------------------------------------------------

data class RelatedPage(
    val songs: List<SongItem>,
    val albums: List<AlbumItem>,
    val artists: List<ArtistItem>,
    val playlists: List<PlaylistItem>,
) {
    companion object {
        fun fromMusicResponsiveListItemRenderer(renderer: MusicResponsiveListItemRenderer): SongItem? {
            // Extract library tokens using the new method that properly handles multiple toggle items
            val libraryTokens = PageHelper.extractLibraryTokensFromMenuItems(renderer.menu?.menuRenderer?.items)

            // Split the secondary line by bullet separator to separate artists from other metadata (like views)
            val secondaryLineRuns = renderer.flexColumns
                .getOrNull(1)
                ?.musicResponsiveListItemFlexColumnRenderer
                ?.text
                ?.runs
                ?.splitBySeparator()

            return SongItem(
                id = renderer.videoId ?: return null,
                title =
                    renderer.flexColumns
                        .firstOrNull()
                        ?.musicResponsiveListItemFlexColumnRenderer
                        ?.text
                        ?.runs
                        ?.firstOrNull()
                        ?.text ?: return null,
                artists =
                    secondaryLineRuns?.firstOrNull()?.oddElements()?.map {
                        Artist(
                            name = it.text,
                            id = it.navigationEndpoint?.browseEndpoint?.browseId,
                        )
                    } ?: return null,
                album =
                    renderer.flexColumns.getOrNull(2)?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.let {
                        Album(
                            name = it.text,
                            id = it.navigationEndpoint?.browseEndpoint?.browseId ?: return null,
                        )
                    },
                duration = renderer.fixedColumns?.firstOrNull()
                    ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()
                    ?.text?.parseTime(),
                musicVideoType = renderer.musicVideoType,
                thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                explicit =
                    renderer.badges?.find {
                        it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                    } != null,
                libraryAddToken = libraryTokens.addToken,
                libraryRemoveToken = libraryTokens.removeToken,
                isEpisode = renderer.isEpisode
            )
        }

        fun fromMusicTwoRowItemRenderer(renderer: MusicTwoRowItemRenderer): YTItem? {
            return when {
                renderer.isAlbum ->
                    AlbumItem(
                        browseId = renderer.navigationEndpoint.browseEndpoint?.browseId ?: return null,
                        playlistId =
                            renderer.thumbnailOverlay
                                ?.musicItemThumbnailOverlayRenderer
                                ?.content
                                ?.musicPlayButtonRenderer
                                ?.playNavigationEndpoint
                                ?.watchPlaylistEndpoint
                                ?.playlistId ?: return null,
                        title =
                            renderer.title.runs
                                ?.firstOrNull()
                                ?.text ?: return null,
                        artists = listOfNotNull(Artist(
                                name = "",
                                id = renderer.menu?.menuRenderer?.items?.find {
                                    it.menuNavigationItemRenderer?.icon?.iconType == "ARTIST"
                                }?.menuNavigationItemRenderer?.navigationEndpoint?.browseEndpoint?.browseId,
                            )),
                        year =
                            renderer.subtitle
                                ?.runs
                                ?.lastOrNull()
                                ?.text
                                ?.toIntOrNull(),
                        thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        explicit =
                            renderer.subtitleBadges?.find {
                                it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                            } != null,
                    )
                renderer.isPlaylist ->
                    PlaylistItem(
                        id =
                            renderer.navigationEndpoint.browseEndpoint
                                ?.browseId
                                ?.removePrefix("VL") ?: return null,
                        title =
                            renderer.title.runs
                                ?.firstOrNull()
                                ?.text ?: return null,
                        author = Artist(
                            name = renderer.subtitle?.runs?.lastOrNull()?.text ?: return null,
                            id = null
                        ),
                        songCountText = renderer.subtitle.runs.findLast {
                            it.text.any { c -> c.isDigit() } && !it.text.contains("view", ignoreCase = true)
                        }?.text,
                        thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        playEndpoint =
                            renderer.thumbnailOverlay
                                ?.musicItemThumbnailOverlayRenderer
                                ?.content
                                ?.musicPlayButtonRenderer
                                ?.playNavigationEndpoint
                                ?.watchPlaylistEndpoint ?: return null,
                        shuffleEndpoint =
                            renderer.menu
                                ?.menuRenderer
                                ?.items
                                ?.find {
                                    it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE"
                                }?.menuNavigationItemRenderer
                                ?.navigationEndpoint
                                ?.watchPlaylistEndpoint ?: return null,
                        radioEndpoint =
                            renderer.menu.menuRenderer.items
                                .find {
                                    it.menuNavigationItemRenderer?.icon?.iconType == "MIX"
                                }?.menuNavigationItemRenderer
                                ?.navigationEndpoint
                                ?.watchPlaylistEndpoint
                    )
                renderer.isArtist -> {
                    ArtistItem(
                        id = renderer.navigationEndpoint.browseEndpoint?.browseId ?: return null,
                        title =
                            renderer.title.runs
                                ?.firstOrNull()
                                ?.text ?: return null,
                        thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        shuffleEndpoint =
                            renderer.menu
                                ?.menuRenderer
                                ?.items
                                ?.find {
                                    it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE"
                                }?.menuNavigationItemRenderer
                                ?.navigationEndpoint
                                ?.watchPlaylistEndpoint ?: return null,
                        radioEndpoint =
                            renderer.menu.menuRenderer.items
                                .find {
                                    it.menuNavigationItemRenderer?.icon?.iconType == "MIX"
                                }?.menuNavigationItemRenderer
                                ?.navigationEndpoint
                                ?.watchPlaylistEndpoint ?: return null,
                    )
                }
                renderer.isPodcast -> {
                    PodcastItem(
                        id = renderer.navigationEndpoint.browseEndpoint?.browseId ?: return null,
                        title = renderer.title.runs?.firstOrNull()?.text ?: return null,
                        author = renderer.subtitle?.runs?.firstOrNull()?.let {
                            Artist(
                                name = it.text,
                                id = it.navigationEndpoint?.browseEndpoint?.browseId
                            )
                        },
                        episodeCountText = renderer.subtitle?.runs?.lastOrNull()?.text,
                        thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl(),
                        playEndpoint = renderer.thumbnailOverlay
                            ?.musicItemThumbnailOverlayRenderer?.content
                            ?.musicPlayButtonRenderer?.playNavigationEndpoint
                            ?.watchPlaylistEndpoint,
                        shuffleEndpoint = renderer.menu?.menuRenderer?.items?.find {
                            it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE"
                        }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint,
                    )
                }
                else -> null
            }
        }
    }
}

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/SearchPage.kt
// ----------------------------------------------------------------------------

data class SearchResult(
    val items: List<YTItem>,
    val continuation: String? = null,
)

object SearchPage {
    fun toYTItem(renderer: MusicResponsiveListItemRenderer): YTItem? {
        val secondaryLine =
            renderer.flexColumns
                .getOrNull(1)
                ?.musicResponsiveListItemFlexColumnRenderer
                ?.text
                ?.runs
                ?.splitBySeparator()
                ?: return null
        return when {
            // CRITICAL: Check isEpisode BEFORE isSong — both can match isSong (watchEndpoint or
            // null navigationEndpoint), so episodes must be identified first.
            renderer.isEpisode -> {
                val libraryTokens = PageHelper.extractLibraryTokensFromMenuItems(renderer.menu?.menuRenderer?.items)

                // The subtitle line structure differs between filtered and unfiltered search:
                //   Unfiltered: ["Episode", "·", "Jan 2025", "·", "Podcast Name", "·", "1:00:00"]
                //     → secondaryLine = [["Episode"], ["Jan 2025"], ["Podcast Name"], ["1:00:00"]]
                //   Filtered:   ["Jan 2025", "·", "Podcast Name"]
                //     → secondaryLine = [["Jan 2025"], ["Podcast Name"]]
                //
                // Strategy: locate the podcast section by its PODCAST_SHOW_DETAIL_PAGE link;
                // the date is in the section immediately before it.
                val podcastSectionIndex = secondaryLine.indexOfFirst { section ->
                    section.any { run ->
                        run.navigationEndpoint?.browseEndpoint
                            ?.browseEndpointContextSupportedConfigs
                            ?.browseEndpointContextMusicConfig
                            ?.pageType == MUSIC_PAGE_TYPE_PODCAST_SHOW_DETAIL_PAGE
                    }
                }

                val podcast = if (podcastSectionIndex >= 0) {
                    secondaryLine[podcastSectionIndex].firstOrNull()?.let { run ->
                        Album(
                            name = run.text,
                            id = run.navigationEndpoint?.browseEndpoint?.browseId ?: return null,
                        )
                    }
                } else null

                val publishDateText = if (podcastSectionIndex > 0)
                    secondaryLine.getOrNull(podcastSectionIndex - 1)?.firstOrNull()?.text
                else null

                EpisodeItem(
                    id = renderer.playlistItemData?.videoId
                        ?: renderer.navigationEndpoint?.watchEndpoint?.videoId
                        ?: renderer.overlay?.musicItemThumbnailOverlayRenderer
                            ?.content?.musicPlayButtonRenderer
                            ?.playNavigationEndpoint?.watchEndpoint?.videoId
                        ?: renderer.flexColumns.firstOrNull()
                            ?.musicResponsiveListItemFlexColumnRenderer
                            ?.text?.runs?.firstOrNull()
                            ?.navigationEndpoint?.watchEndpoint?.videoId
                        ?: return null,
                    title =
                        renderer.flexColumns
                            .firstOrNull()
                            ?.musicResponsiveListItemFlexColumnRenderer
                            ?.text
                            ?.runs
                            ?.firstOrNull()
                            ?.text ?: return null,
                    author = null,
                    podcast = podcast,
                    duration =
                        secondaryLine
                            .lastOrNull()
                            ?.firstOrNull()
                            ?.text
                            ?.parseTime(),
                    publishDateText = publishDateText,
                    thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                    explicit =
                        renderer.badges?.find {
                            it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                        } != null,
                    // In filtered search the overlay play button may be absent; fall back to the
                    // item's own watchEndpoint so the episode is always playable.
                    endpoint = renderer.overlay
                        ?.musicItemThumbnailOverlayRenderer
                        ?.content
                        ?.musicPlayButtonRenderer
                        ?.playNavigationEndpoint
                        ?.watchEndpoint
                        ?: renderer.navigationEndpoint?.watchEndpoint,
                    libraryAddToken = libraryTokens.addToken,
                    libraryRemoveToken = libraryTokens.removeToken,
                )
            }
            renderer.isSong -> {
                val libraryTokens = PageHelper.extractLibraryTokensFromMenuItems(renderer.menu?.menuRenderer?.items)

                val title = renderer.flexColumns
                    .firstOrNull()
                    ?.musicResponsiveListItemFlexColumnRenderer
                    ?.text
                    ?.runs
                    ?.firstOrNull()
                    ?.text ?: return null

                val artists =
                    secondaryLine.firstOrNull()?.oddElements()?.map {
                        Artist(
                            name = it.text,
                            id = it.navigationEndpoint?.browseEndpoint?.browseId,
                        )
                    } ?: return null

                if (!com.listrovia.innertube.SongContentModerator.isAllowed(title, artists.firstOrNull()?.name)) {
                    return null
                }

                SongItem(
                    id = renderer.playlistItemData?.videoId
                        ?: renderer.navigationEndpoint?.watchEndpoint?.videoId
                        ?: renderer.overlay?.musicItemThumbnailOverlayRenderer
                            ?.content?.musicPlayButtonRenderer
                            ?.playNavigationEndpoint?.watchEndpoint?.videoId
                        ?: renderer.flexColumns.firstOrNull()
                            ?.musicResponsiveListItemFlexColumnRenderer
                            ?.text?.runs?.firstOrNull()
                            ?.navigationEndpoint?.watchEndpoint?.videoId
                        ?: return null,
                    title = title,
                    artists = artists,
                    album =
                        secondaryLine.getOrNull(1)?.firstOrNull()?.takeIf { it.navigationEndpoint?.browseEndpoint != null }?.let {
                            Album(
                                name = it.text,
                                id = it.navigationEndpoint?.browseEndpoint?.browseId!!,
                            )
                        },
                    duration =
                        secondaryLine
                            .lastOrNull()
                            ?.firstOrNull()
                            ?.text
                            ?.parseTime(),
                    musicVideoType = renderer.musicVideoType,
                    thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                    explicit =
                        renderer.badges?.find {
                            it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                        } != null,
                    libraryAddToken = libraryTokens.addToken,
                    libraryRemoveToken = libraryTokens.removeToken,
                    isEpisode = renderer.isEpisode
                )
            }
            renderer.isArtist -> {
                ArtistItem(
                    id = renderer.navigationEndpoint?.browseEndpoint?.browseId ?: return null,
                    title =
                        renderer.flexColumns
                            .firstOrNull()
                            ?.musicResponsiveListItemFlexColumnRenderer
                            ?.text
                            ?.runs
                            ?.firstOrNull()
                            ?.text
                            ?: return null,
                    thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                    shuffleEndpoint =
                        renderer.menu
                            ?.menuRenderer
                            ?.items
                            ?.find { it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE" }
                            ?.menuNavigationItemRenderer
                            ?.navigationEndpoint
                            ?.watchPlaylistEndpoint ?: return null,
                    radioEndpoint =
                        renderer.menu.menuRenderer.items
                            .find { it.menuNavigationItemRenderer?.icon?.iconType == "MIX" }
                            ?.menuNavigationItemRenderer
                            ?.navigationEndpoint
                            ?.watchPlaylistEndpoint ?: return null,
                )
            }
            renderer.isUserChannel -> {
                ArtistItem(
                    id = renderer.navigationEndpoint?.browseEndpoint?.browseId ?: return null,
                    title =
                        renderer.flexColumns
                            .firstOrNull()
                            ?.musicResponsiveListItemFlexColumnRenderer
                            ?.text
                            ?.runs
                            ?.firstOrNull()
                            ?.text
                            ?: return null,
                    thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                    shuffleEndpoint = renderer.menu
                        ?.menuRenderer
                        ?.items
                        ?.find { it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE" }
                        ?.menuNavigationItemRenderer
                        ?.navigationEndpoint
                        ?.watchPlaylistEndpoint,
                    radioEndpoint = renderer.menu
                        ?.menuRenderer
                        ?.items
                        ?.find { it.menuNavigationItemRenderer?.icon?.iconType == "MIX" }
                        ?.menuNavigationItemRenderer
                        ?.navigationEndpoint
                        ?.watchPlaylistEndpoint,
                    isProfile = true,
                )
            }
            renderer.isAlbum -> {
                AlbumItem(
                    browseId = renderer.navigationEndpoint?.browseEndpoint?.browseId ?: return null,
                    playlistId =
                        renderer.overlay
                            ?.musicItemThumbnailOverlayRenderer
                            ?.content
                            ?.musicPlayButtonRenderer
                            ?.playNavigationEndpoint
                            ?.anyWatchEndpoint
                            ?.playlistId
                            ?: return null,
                    title =
                        renderer.flexColumns
                            .firstOrNull()
                            ?.musicResponsiveListItemFlexColumnRenderer
                            ?.text
                            ?.runs
                            ?.firstOrNull()
                            ?.text ?: return null,
                    artists =
                        secondaryLine.getOrNull(1)?.oddElements()?.map {
                            Artist(
                                name = it.text,
                                id = it.navigationEndpoint?.browseEndpoint?.browseId,
                            )
                        } ?: return null,
                    year =
                        secondaryLine
                            .getOrNull(2)
                            ?.firstOrNull()
                            ?.text
                            ?.toIntOrNull(),
                    thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                    explicit =
                        renderer.badges?.find {
                            it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                        } != null,
                )
            }
            renderer.isPlaylist -> {
                PlaylistItem(
                    id =
                        renderer.navigationEndpoint
                            ?.browseEndpoint
                            ?.browseId
                            ?.removePrefix("VL") ?: return null,
                    title =
                        renderer.flexColumns
                            .firstOrNull()
                            ?.musicResponsiveListItemFlexColumnRenderer
                            ?.text
                            ?.runs
                            ?.firstOrNull()
                            ?.text ?: return null,
                    author =
                        secondaryLine.firstOrNull()?.firstOrNull()?.let {
                            Artist(
                                name = it.text,
                                id = it.navigationEndpoint?.browseEndpoint?.browseId,
                            )
                        } ?: return null,
                    songCountText =
                        renderer.flexColumns
                            .getOrNull(1)
                            ?.musicResponsiveListItemFlexColumnRenderer
                            ?.text
                            ?.runs
                            ?.lastOrNull()
                            ?.text ?: return null,
                    thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                    playEndpoint =
                        renderer.overlay
                            ?.musicItemThumbnailOverlayRenderer
                            ?.content
                            ?.musicPlayButtonRenderer
                            ?.playNavigationEndpoint
                            ?.watchPlaylistEndpoint ?: return null,
                    shuffleEndpoint =
                        renderer.menu
                            ?.menuRenderer
                            ?.items
                            ?.find { it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE" }
                            ?.menuNavigationItemRenderer
                            ?.navigationEndpoint
                            ?.watchPlaylistEndpoint ?: return null,
                    radioEndpoint =
                        renderer.menu.menuRenderer.items
                            .find { it.menuNavigationItemRenderer?.icon?.iconType == "MIX" }
                            ?.menuNavigationItemRenderer
                            ?.navigationEndpoint
                            ?.watchPlaylistEndpoint ?: return null,
                )
            }
            renderer.isPodcast -> {
                PodcastItem(
                    id =
                        renderer.navigationEndpoint
                            ?.browseEndpoint
                            ?.browseId
                            ?: return null,
                    title =
                        renderer.flexColumns
                            .firstOrNull()
                            ?.musicResponsiveListItemFlexColumnRenderer
                            ?.text
                            ?.runs
                            ?.firstOrNull()
                            ?.text ?: return null,
                    author =
                        secondaryLine.firstOrNull()?.firstOrNull()?.let {
                            Artist(
                                name = it.text,
                                id = it.navigationEndpoint?.browseEndpoint?.browseId,
                            )
                        },
                    episodeCountText =
                        renderer.flexColumns
                            .getOrNull(1)
                            ?.musicResponsiveListItemFlexColumnRenderer
                            ?.text
                            ?.runs
                            ?.lastOrNull()
                            ?.text,
                    thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                    playEndpoint =
                        renderer.overlay
                            ?.musicItemThumbnailOverlayRenderer
                            ?.content
                            ?.musicPlayButtonRenderer
                            ?.playNavigationEndpoint
                            ?.watchPlaylistEndpoint,
                    shuffleEndpoint =
                        renderer.menu
                            ?.menuRenderer
                            ?.items
                            ?.find { it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE" }
                            ?.menuNavigationItemRenderer
                            ?.navigationEndpoint
                            ?.watchPlaylistEndpoint,
                )
            }
            else -> null
        }
    }
}

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/SearchSuggestionPage.kt
// ----------------------------------------------------------------------------

object SearchSuggestionPage {
    fun fromMusicResponsiveListItemRenderer(renderer: MusicResponsiveListItemRenderer): YTItem? {
        return when {
            renderer.isPodcast -> {
                val secondaryLine =
                    renderer.flexColumns
                        .getOrNull(1)
                        ?.musicResponsiveListItemFlexColumnRenderer
                        ?.text
                        ?.runs
                        ?.splitBySeparator()
                PodcastItem(
                    id = renderer.navigationEndpoint?.browseEndpoint?.browseId ?: return null,
                    title =
                        renderer.flexColumns
                            .firstOrNull()
                            ?.musicResponsiveListItemFlexColumnRenderer
                            ?.text
                            ?.runs
                            ?.firstOrNull()
                            ?.text ?: return null,
                    author = secondaryLine?.getOrNull(0)?.firstOrNull()?.let {
                        Artist(
                            name = it.text,
                            id = it.navigationEndpoint?.browseEndpoint?.browseId,
                        )
                    },
                    episodeCountText = secondaryLine?.lastOrNull()?.firstOrNull()?.text,
                    thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                    playEndpoint = renderer.overlay
                        ?.musicItemThumbnailOverlayRenderer
                        ?.content
                        ?.musicPlayButtonRenderer
                        ?.playNavigationEndpoint
                        ?.watchPlaylistEndpoint,
                    shuffleEndpoint = renderer.menu
                        ?.menuRenderer
                        ?.items
                        ?.find { it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE" }
                        ?.menuNavigationItemRenderer
                        ?.navigationEndpoint
                        ?.watchPlaylistEndpoint,
                )
            }
            renderer.isEpisode -> {
                val secondaryLine =
                    renderer.flexColumns
                        .getOrNull(1)
                        ?.musicResponsiveListItemFlexColumnRenderer
                        ?.text
                        ?.runs
                        ?.splitBySeparator()
                val firstSubtitle = secondaryLine?.getOrNull(0)?.firstOrNull()?.text
                val isUnfilteredSearch = firstSubtitle == "Episode"
                val dateIndex = if (isUnfilteredSearch) 1 else 0
                val podcastIndex = if (isUnfilteredSearch) 2 else 1
                EpisodeItem(
                    id = renderer.videoId ?: return null,
                    title =
                        renderer.flexColumns
                            .firstOrNull()
                            ?.musicResponsiveListItemFlexColumnRenderer
                            ?.text
                            ?.runs
                            ?.firstOrNull()
                            ?.text ?: return null,
                    author = null,
                    podcast = secondaryLine?.getOrNull(podcastIndex)?.firstOrNull()?.takeIf {
                        it.navigationEndpoint?.browseEndpoint != null
                    }?.let {
                        Album(
                            name = it.text,
                            id = it.navigationEndpoint?.browseEndpoint?.browseId!!,
                        )
                    },
                    duration = secondaryLine?.lastOrNull()?.firstOrNull()?.text?.parseTime(),
                    publishDateText = secondaryLine?.getOrNull(dateIndex)?.firstOrNull()?.text,
                    thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                    endpoint = renderer.overlay
                        ?.musicItemThumbnailOverlayRenderer
                        ?.content
                        ?.musicPlayButtonRenderer
                        ?.playNavigationEndpoint
                        ?.watchEndpoint,
                    libraryAddToken = null,
                    libraryRemoveToken = null,
                )
            }
            renderer.isPlaylist -> {
                val secondaryLine =
                    renderer.flexColumns
                        .getOrNull(1)
                        ?.musicResponsiveListItemFlexColumnRenderer
                        ?.text
                        ?.runs
                        ?.splitBySeparator()
                PlaylistItem(
                    id = renderer.navigationEndpoint?.browseEndpoint?.browseId
                        ?.removePrefix("VL") ?: return null,
                    title =
                        renderer.flexColumns
                            .firstOrNull()
                            ?.musicResponsiveListItemFlexColumnRenderer
                            ?.text
                            ?.runs
                            ?.firstOrNull()
                            ?.text ?: return null,
                    author = secondaryLine?.firstOrNull()?.firstOrNull()?.let {
                        Artist(
                            name = it.text,
                            id = it.navigationEndpoint?.browseEndpoint?.browseId,
                        )
                    } ?: return null,
                    songCountText = secondaryLine.lastOrNull()?.firstOrNull()?.text,
                    thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                    playEndpoint = renderer.overlay
                        ?.musicItemThumbnailOverlayRenderer
                        ?.content
                        ?.musicPlayButtonRenderer
                        ?.playNavigationEndpoint
                        ?.watchPlaylistEndpoint ?: return null,
                    shuffleEndpoint = renderer.menu
                        ?.menuRenderer
                        ?.items
                        ?.find { it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE" }
                        ?.menuNavigationItemRenderer
                        ?.navigationEndpoint
                        ?.watchPlaylistEndpoint ?: return null,
                    radioEndpoint = renderer.menu.menuRenderer.items
                        .find { it.menuNavigationItemRenderer?.icon?.iconType == "MIX" }
                        ?.menuNavigationItemRenderer
                        ?.navigationEndpoint
                        ?.watchPlaylistEndpoint ?: return null,
                )
            }
            renderer.isSong -> {
                val secondaryLine =
                    renderer.flexColumns
                        .getOrNull(1)
                        ?.musicResponsiveListItemFlexColumnRenderer
                        ?.text
                        ?.runs
                        ?.splitBySeparator()
                        ?.clean()
                // Split artist runs by conjunction to handle "Artist1 & Artist2" cases
                val artistRuns = secondaryLine
                    ?.firstOrNull()
                    ?.splitArtistsByConjunction()
                    ?.filter { it.text.isNotBlank() && it.text != "&" && it.text != "," }
                SongItem(
                    id = renderer.videoId ?: return null,
                    title =
                        renderer.flexColumns
                            .firstOrNull()
                            ?.musicResponsiveListItemFlexColumnRenderer
                            ?.text
                            ?.runs
                            ?.firstOrNull()
                            ?.text ?: return null,
                    artists =
                        artistRuns?.map { run ->
                            Artist(
                                name = run.text.trim(),
                                id = run.navigationEndpoint?.browseEndpoint?.browseId,
                            )
                        } ?: return null,
                    album =
                        renderer.flexColumns
                            .getOrNull(
                                2,
                            )?.musicResponsiveListItemFlexColumnRenderer
                            ?.text
                            ?.runs
                            ?.firstOrNull()
                            ?.let {
                                Album(
                                    name = it.text,
                                    id = it.navigationEndpoint?.browseEndpoint?.browseId ?: return null,
                                )
                            },
                    duration = null,
                    musicVideoType = renderer.musicVideoType,
                    thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                    explicit =
                        renderer.badges?.find {
                            it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                        } != null,
                )
            }
            renderer.isArtist -> {
                ArtistItem(
                    id = renderer.navigationEndpoint?.browseEndpoint?.browseId ?: return null,
                    title =
                        renderer.flexColumns
                            .firstOrNull()
                            ?.musicResponsiveListItemFlexColumnRenderer
                            ?.text
                            ?.runs
                            ?.firstOrNull()
                            ?.text
                            ?: return null,
                    thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                    shuffleEndpoint =
                        renderer.menu
                            ?.menuRenderer
                            ?.items
                            ?.find { it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE" }
                            ?.menuNavigationItemRenderer
                            ?.navigationEndpoint
                            ?.watchPlaylistEndpoint,
                    radioEndpoint =
                        renderer.menu
                            ?.menuRenderer
                            ?.items
                            ?.find { it.menuNavigationItemRenderer?.icon?.iconType == "MIX" }
                            ?.menuNavigationItemRenderer
                            ?.navigationEndpoint
                            ?.watchPlaylistEndpoint,
                )
            }
            renderer.isUserChannel -> {
                ArtistItem(
                    id = renderer.navigationEndpoint?.browseEndpoint?.browseId ?: return null,
                    title =
                        renderer.flexColumns
                            .firstOrNull()
                            ?.musicResponsiveListItemFlexColumnRenderer
                            ?.text
                            ?.runs
                            ?.firstOrNull()
                            ?.text
                            ?: return null,
                    thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                    shuffleEndpoint = renderer.menu
                        ?.menuRenderer
                        ?.items
                        ?.find { it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE" }
                        ?.menuNavigationItemRenderer
                        ?.navigationEndpoint
                        ?.watchPlaylistEndpoint,
                    radioEndpoint = renderer.menu
                        ?.menuRenderer
                        ?.items
                        ?.find { it.menuNavigationItemRenderer?.icon?.iconType == "MIX" }
                        ?.menuNavigationItemRenderer
                        ?.navigationEndpoint
                        ?.watchPlaylistEndpoint,
                )
            }
            renderer.isAlbum -> {
                val secondaryLine =
                    renderer.flexColumns
                        .getOrNull(1)
                        ?.musicResponsiveListItemFlexColumnRenderer
                        ?.text
                        ?.runs
                        ?.splitBySeparator() ?: return null
                AlbumItem(
                    browseId = renderer.navigationEndpoint?.browseEndpoint?.browseId ?: return null,
                    playlistId =
                        renderer.menu
                            ?.menuRenderer
                            ?.items
                            ?.find {
                                it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE"
                            }?.menuNavigationItemRenderer
                            ?.navigationEndpoint
                            ?.watchPlaylistEndpoint
                            ?.playlistId ?: return null,
                    title =
                        renderer.flexColumns
                            .firstOrNull()
                            ?.musicResponsiveListItemFlexColumnRenderer
                            ?.text
                            ?.runs
                            ?.firstOrNull()
                            ?.text ?: return null,
                    artists =
                        secondaryLine.getOrNull(1)?.oddElements()?.map {
                            Artist(
                                name = it.text,
                                id = it.navigationEndpoint?.browseEndpoint?.browseId,
                            )
                        } ?: return null,
                    year =
                        secondaryLine
                            .lastOrNull()
                            ?.firstOrNull()
                            ?.text
                            ?.toIntOrNull(),
                    thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                    explicit =
                        renderer.badges?.find {
                            it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                        } != null,
                )
            }
            else -> null
        }
    }
}

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/SearchSummaryPage.kt
// ----------------------------------------------------------------------------

data class SearchSummary(
    val title: String,
    val items: List<YTItem>,
)

data class SearchSummaryPage(
    val summaries: List<SearchSummary>,
) {
    fun filterExplicit(enabled: Boolean) =
        if (enabled) {
            SearchSummaryPage(
                summaries.mapNotNull { s ->
                    SearchSummary(
                        title = s.title,
                        items =
                            s.items.filterExplicit().ifEmpty {
                                return@mapNotNull null
                            },
                    )
                },
            )
        } else {
            this
        }

    fun filterVideoSongs(disableVideos: Boolean) =
        if (disableVideos) {
            SearchSummaryPage(
                summaries.mapNotNull { s ->
                    SearchSummary(
                        title = s.title,
                        items =
                            s.items.filterVideoSongs(true).ifEmpty {
                                return@mapNotNull null
                            },
                    )
                },
            )
        } else {
            this
        }

    fun filterYoutubeShorts(enabled: Boolean = false) =
        if (enabled) {
            SearchSummaryPage(
                summaries.mapNotNull { s ->
                    SearchSummary(
                        title = s.title,
                        items =
                            s.items.filterYoutubeShorts(true).ifEmpty {
                                return@mapNotNull null
                            },
                    )
                },
            )
        } else {
            this
        }

    companion object {
        fun fromMusicCardShelfRenderer(renderer: MusicCardShelfRenderer): YTItem? {
            val subtitle = renderer.subtitle.runs?.splitBySeparator()
            return when {
                renderer.onTap.watchEndpoint != null -> {
                    SongItem(
                        id = renderer.onTap.watchEndpoint.videoId ?: return null,
                        title =
                            renderer.title.runs
                                ?.firstOrNull()
                                ?.text ?: return null,
                        artists =
                            subtitle?.getOrNull(1)?.oddElements()?.map {
                                Artist(
                                    name = it.text,
                                    id = it.navigationEndpoint?.browseEndpoint?.browseId,
                                )
                            } ?: return null,
                        album =
                            subtitle.getOrNull(2)?.firstOrNull()?.takeIf { it.navigationEndpoint?.browseEndpoint != null }?.let {
                                Album(
                                    name = it.text,
                                    id = it.navigationEndpoint?.browseEndpoint?.browseId!!,
                                )
                            },
                        duration =
                            subtitle
                                .lastOrNull()
                                ?.firstOrNull()
                                ?.text
                                ?.parseTime(),
                        musicVideoType = renderer.onTap.musicVideoType,
                        thumbnail = renderer.thumbnail.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        explicit =
                            renderer.subtitleBadges?.find {
                                it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                            } != null,
                    )
                }

                renderer.onTap.browseEndpoint?.isArtistEndpoint == true -> {
                    ArtistItem(
                        id = renderer.onTap.browseEndpoint.browseId,
                        title =
                            renderer.title.runs
                                ?.firstOrNull()
                                ?.text ?: return null,
                        thumbnail = renderer.thumbnail.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        shuffleEndpoint =
                            renderer.buttons
                                .find { it.buttonRenderer.icon?.iconType == "MUSIC_SHUFFLE" }
                                ?.buttonRenderer
                                ?.command
                                ?.watchPlaylistEndpoint ?: return null,
                        radioEndpoint =
                            renderer.buttons
                                .find { it.buttonRenderer.icon?.iconType == "MIX" }
                                ?.buttonRenderer
                                ?.command
                                ?.watchPlaylistEndpoint ?: return null,
                    )
                }

                renderer.onTap.browseEndpoint?.isAlbumEndpoint == true -> {
                    AlbumItem(
                        browseId = renderer.onTap.browseEndpoint.browseId,
                        playlistId =
                            renderer.buttons
                                .firstOrNull()
                                ?.buttonRenderer
                                ?.command
                                ?.anyWatchEndpoint
                                ?.playlistId ?: return null,
                        title =
                            renderer.title.runs
                                ?.firstOrNull()
                                ?.text ?: return null,
                        artists =
                            subtitle?.getOrNull(1)?.oddElements()?.map {
                                Artist(
                                    name = it.text,
                                    id = it.navigationEndpoint?.browseEndpoint?.browseId,
                                )
                            } ?: return null,
                        year = null,
                        thumbnail = renderer.thumbnail.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        explicit =
                            renderer.subtitleBadges?.find {
                                it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                            } != null,
                    )
                }

                renderer.onTap.browseEndpoint?.isPlaylistEndpoint == true -> {
                    PlaylistItem(
                        id =
                            renderer.onTap.browseEndpoint.browseId
                                .removePrefix("VL"),
                        title =
                            renderer.header?.musicCardShelfHeaderBasicRenderer?.title?.runs
                                ?.joinToString(separator = "") { it.text }
                                ?: return null,
                        author =
                            Artist(
                                id = null,
                                name = renderer.subtitle.runs?.joinToString { it.text } ?: return null,
                            ),
                        songCountText = null,
                        thumbnail = renderer.thumbnail.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        playEndpoint =
                            renderer.buttons
                                .find { it.buttonRenderer.icon?.iconType == "PLAY_ARROW" }
                                ?.buttonRenderer
                                ?.command
                                ?.watchPlaylistEndpoint
                                ?: return null,
                        shuffleEndpoint =
                            renderer.buttons
                                .find { it.buttonRenderer.icon?.iconType == "MUSIC_SHUFFLE" }
                                ?.buttonRenderer
                                ?.command
                                ?.watchPlaylistEndpoint
                                ?: return null,
                        radioEndpoint = null,
                    )
                }

                renderer.onTap.browseEndpoint?.isPodcastEndpoint == true -> {
                    PodcastItem(
                        id = renderer.onTap.browseEndpoint.browseId,
                        title =
                            renderer.header?.musicCardShelfHeaderBasicRenderer?.title?.runs
                                ?.joinToString(separator = "") { it.text }
                                ?: return null,
                        author =
                            Artist(
                                id = null,
                                name = renderer.subtitle.runs?.joinToString { it.text } ?: return null,
                            ),
                        episodeCountText = null,
                        thumbnail = renderer.thumbnail.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        playEndpoint =
                            renderer.buttons
                                .find { it.buttonRenderer.icon?.iconType == "PLAY_ARROW" }
                                ?.buttonRenderer
                                ?.command
                                ?.watchPlaylistEndpoint,
                        shuffleEndpoint =
                            renderer.buttons
                                .find { it.buttonRenderer.icon?.iconType == "MUSIC_SHUFFLE" }
                                ?.buttonRenderer
                                ?.command
                                ?.watchPlaylistEndpoint,
                    )
                }

                else -> null
            }
        }

        fun fromMusicResponsiveListItemRenderer(renderer: MusicResponsiveListItemRenderer): YTItem? {
            val secondaryLine =
                renderer.flexColumns
                    .getOrNull(1)
                    ?.musicResponsiveListItemFlexColumnRenderer
                    ?.text
                    ?.runs
                    ?.splitBySeparator()
                    ?: return null
            return when {
                // CRITICAL: Check isEpisode BEFORE isSong because both have videoId and no browseEndpoint
                // Episodes are identified by firstSubtitle == "Episode" in unfiltered search
                renderer.isEpisode -> {
                    val libraryTokens = PageHelper.extractLibraryTokensFromMenuItems(renderer.menu?.menuRenderer?.items)

                    // Check if firstSubtitle is "Episode" (unfiltered) or something else (filtered)
                    // Unfiltered: [Episode][date][podcast]  -> date at index 1, podcast at index 2
                    // Filtered:   [date][podcast]           -> date at index 0, podcast at index 1
                    val firstSubtitle = secondaryLine.getOrNull(0)?.firstOrNull()?.text
                    val isUnfilteredSearch = firstSubtitle == "Episode"
                    val dateIndex = if (isUnfilteredSearch) 1 else 0
                    val podcastIndex = if (isUnfilteredSearch) 2 else 1

                    EpisodeItem(
                        id = renderer.playlistItemData?.videoId
                            ?: renderer.navigationEndpoint?.watchEndpoint?.videoId
                            ?: renderer.overlay?.musicItemThumbnailOverlayRenderer
                                ?.content?.musicPlayButtonRenderer
                                ?.playNavigationEndpoint?.watchEndpoint?.videoId
                            ?: renderer.flexColumns.firstOrNull()
                                ?.musicResponsiveListItemFlexColumnRenderer
                                ?.text?.runs?.firstOrNull()
                                ?.navigationEndpoint?.watchEndpoint?.videoId
                            ?: return null,
                        title =
                            renderer.flexColumns
                                .firstOrNull()
                                ?.musicResponsiveListItemFlexColumnRenderer
                                ?.text
                                ?.runs
                                ?.firstOrNull()
                                ?.text ?: return null,
                        author = null,  // Episodes don't have a separate author - the podcast is the source
                        podcast =
                            secondaryLine.getOrNull(podcastIndex)?.firstOrNull()?.takeIf {
                                it.navigationEndpoint?.browseEndpoint != null
                            }?.let {
                                Album(
                                    name = it.text,
                                    id = it.navigationEndpoint?.browseEndpoint?.browseId!!,
                                )
                            },
                        duration =
                            secondaryLine
                                .lastOrNull()
                                ?.firstOrNull()
                                ?.text
                                ?.parseTime(),
                        publishDateText =
                            secondaryLine
                                .getOrNull(dateIndex)
                                ?.firstOrNull()
                                ?.text,
                        thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        explicit =
                            renderer.badges?.find {
                                it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                            } != null,
                        endpoint = renderer.overlay
                            ?.musicItemThumbnailOverlayRenderer
                            ?.content
                            ?.musicPlayButtonRenderer
                            ?.playNavigationEndpoint
                            ?.watchEndpoint,
                        libraryAddToken = libraryTokens.addToken,
                        libraryRemoveToken = libraryTokens.removeToken,
                    )
                }

                renderer.isSong -> {
                    // Extract library tokens using the new method that properly handles multiple toggle items
                    val libraryTokens = PageHelper.extractLibraryTokensFromMenuItems(renderer.menu?.menuRenderer?.items)
                    val thirdLine =
                        renderer.flexColumns
                            .getOrNull(2)
                            ?.musicResponsiveListItemFlexColumnRenderer
                            ?.text
                            ?.runs
                            ?.splitBySeparator()
                            ?: emptyList()
                    val listRun = (secondaryLine + thirdLine).clean()

                    // Split artist runs by conjunction to handle "Artist1 & Artist2" cases
                    val artistRuns = listRun.getOrNull(0)?.splitArtistsByConjunction()
                        ?.filter { it.text.isNotBlank() && it.text != "&" && it.text != "," }

                    SongItem(
                        id = renderer.playlistItemData?.videoId
                            ?: renderer.navigationEndpoint?.watchEndpoint?.videoId
                            ?: renderer.overlay?.musicItemThumbnailOverlayRenderer
                                ?.content?.musicPlayButtonRenderer
                                ?.playNavigationEndpoint?.watchEndpoint?.videoId
                            ?: renderer.flexColumns.firstOrNull()
                                ?.musicResponsiveListItemFlexColumnRenderer
                                ?.text?.runs?.firstOrNull()
                                ?.navigationEndpoint?.watchEndpoint?.videoId
                            ?: return null,
                        title =
                            renderer.flexColumns
                                .firstOrNull()
                                ?.musicResponsiveListItemFlexColumnRenderer
                                ?.text
                                ?.runs
                                ?.firstOrNull()
                                ?.text ?: return null,
                        artists = artistRuns?.map { run ->
                            Artist(
                                name = run.text.trim(),
                                id = run.navigationEndpoint?.browseEndpoint?.browseId
                            )
                        } ?: return null,
                        album = listRun.getOrNull(1)?.firstOrNull()?.takeIf { it.navigationEndpoint?.browseEndpoint != null }?.let {
                            Album(
                                name = it.text,
                                id = it.navigationEndpoint?.browseEndpoint?.browseId!!
                            )
                        },
                        duration =
                            secondaryLine
                                .lastOrNull()
                                ?.firstOrNull()
                                ?.text
                                ?.parseTime(),
                        musicVideoType = renderer.musicVideoType,
                        thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        explicit =
                            renderer.badges?.find {
                                it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                            } != null,
                        libraryAddToken = libraryTokens.addToken,
                        libraryRemoveToken = libraryTokens.removeToken,
                        isEpisode = renderer.isEpisode
                    )
                }

                renderer.isArtist -> {
                    ArtistItem(
                        id = renderer.navigationEndpoint?.browseEndpoint?.browseId ?: return null,
                        title =
                            renderer.flexColumns
                                .firstOrNull()
                                ?.musicResponsiveListItemFlexColumnRenderer
                                ?.text
                                ?.runs
                                ?.firstOrNull()
                                ?.text
                                ?: return null,
                        thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        shuffleEndpoint =
                            renderer.menu
                                ?.menuRenderer
                                ?.items
                                ?.find { it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE" }
                                ?.menuNavigationItemRenderer
                                ?.navigationEndpoint
                                ?.watchPlaylistEndpoint ?: return null,
                        radioEndpoint =
                            renderer.menu.menuRenderer.items
                                .find { it.menuNavigationItemRenderer?.icon?.iconType == "MIX" }
                                ?.menuNavigationItemRenderer
                                ?.navigationEndpoint
                                ?.watchPlaylistEndpoint ?: return null,
                    )
                }

                renderer.isUserChannel -> {
                    ArtistItem(
                        id = renderer.navigationEndpoint?.browseEndpoint?.browseId ?: return null,
                        title =
                            renderer.flexColumns
                                .firstOrNull()
                                ?.musicResponsiveListItemFlexColumnRenderer
                                ?.text
                                ?.runs
                                ?.firstOrNull()
                                ?.text
                                ?: return null,
                        thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        shuffleEndpoint = renderer.menu
                            ?.menuRenderer
                            ?.items
                            ?.find { it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE" }
                            ?.menuNavigationItemRenderer
                            ?.navigationEndpoint
                            ?.watchPlaylistEndpoint,
                        radioEndpoint = renderer.menu
                            ?.menuRenderer
                            ?.items
                            ?.find { it.menuNavigationItemRenderer?.icon?.iconType == "MIX" }
                            ?.menuNavigationItemRenderer
                            ?.navigationEndpoint
                            ?.watchPlaylistEndpoint,
                        isProfile = true,
                    )
                }

                renderer.isAlbum -> {
                    AlbumItem(
                        browseId = renderer.navigationEndpoint?.browseEndpoint?.browseId ?: return null,
                        playlistId =
                            renderer.overlay
                                ?.musicItemThumbnailOverlayRenderer
                                ?.content
                                ?.musicPlayButtonRenderer
                                ?.playNavigationEndpoint
                                ?.watchPlaylistEndpoint
                                ?.playlistId
                                ?: return null,
                        title =
                            renderer.flexColumns
                                .firstOrNull()
                                ?.musicResponsiveListItemFlexColumnRenderer
                                ?.text
                                ?.runs
                                ?.firstOrNull()
                                ?.text ?: return null,
                        artists =
                            secondaryLine.getOrNull(1)?.oddElements()?.map {
                                Artist(
                                    name = it.text,
                                    id = it.navigationEndpoint?.browseEndpoint?.browseId,
                                )
                            } ?: return null,
                        year =
                            secondaryLine
                                .getOrNull(2)
                                ?.firstOrNull()
                                ?.text
                                ?.toIntOrNull(),
                        thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        explicit =
                            renderer.badges?.find {
                                it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                            } != null,
                    )
                }

                renderer.isPlaylist -> {
                    PlaylistItem(
                        id =
                            renderer.navigationEndpoint
                                ?.browseEndpoint
                                ?.browseId
                                ?.removePrefix("VL") ?: return null,
                        title =
                            renderer.flexColumns
                                .firstOrNull()
                                ?.musicResponsiveListItemFlexColumnRenderer
                                ?.text
                                ?.runs
                                ?.firstOrNull()
                                ?.text ?: return null,
                        author =
                            secondaryLine.getOrNull(1)?.firstOrNull()?.let {
                                Artist(
                                    name = it.text,
                                    id = it.navigationEndpoint?.browseEndpoint?.browseId,
                                )
                            } ?: return null,
                        songCountText =
                            renderer.flexColumns
                                .getOrNull(1)
                                ?.musicResponsiveListItemFlexColumnRenderer
                                ?.text
                                ?.runs
                                ?.lastOrNull()
                                ?.text ?: return null,
                        thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        playEndpoint =
                            renderer.overlay
                                ?.musicItemThumbnailOverlayRenderer
                                ?.content
                                ?.musicPlayButtonRenderer
                                ?.playNavigationEndpoint
                                ?.watchPlaylistEndpoint ?: return null,
                        shuffleEndpoint =
                            renderer.menu
                                ?.menuRenderer
                                ?.items
                                ?.find { it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE" }
                                ?.menuNavigationItemRenderer
                                ?.navigationEndpoint
                                ?.watchPlaylistEndpoint ?: return null,
                        radioEndpoint =
                            renderer.menu.menuRenderer.items
                                .find { it.menuNavigationItemRenderer?.icon?.iconType == "MIX" }
                                ?.menuNavigationItemRenderer
                                ?.navigationEndpoint
                                ?.watchPlaylistEndpoint ?: return null,
                    )
                }

                renderer.isPodcast -> {
                    PodcastItem(
                        id =
                            renderer.navigationEndpoint
                                ?.browseEndpoint
                                ?.browseId
                                ?: return null,
                        title =
                            renderer.flexColumns
                                .firstOrNull()
                                ?.musicResponsiveListItemFlexColumnRenderer
                                ?.text
                                ?.runs
                                ?.firstOrNull()
                                ?.text ?: return null,
                        author =
                            secondaryLine.getOrNull(0)?.firstOrNull()?.let {
                                Artist(
                                    name = it.text,
                                    id = it.navigationEndpoint?.browseEndpoint?.browseId,
                                )
                            },
                        episodeCountText =
                            renderer.flexColumns
                                .getOrNull(1)
                                ?.musicResponsiveListItemFlexColumnRenderer
                                ?.text
                                ?.runs
                                ?.lastOrNull()
                                ?.text,
                        thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        playEndpoint =
                            renderer.overlay
                                ?.musicItemThumbnailOverlayRenderer
                                ?.content
                                ?.musicPlayButtonRenderer
                                ?.playNavigationEndpoint
                                ?.watchPlaylistEndpoint,
                        shuffleEndpoint =
                            renderer.menu
                                ?.menuRenderer
                                ?.items
                                ?.find { it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE" }
                                ?.menuNavigationItemRenderer
                                ?.navigationEndpoint
                                ?.watchPlaylistEndpoint,
                    )
                }

                else -> null
            }
        }
    }
}

// ----------------------------------------------------------------------------
// [PAGE PARSERS & EXTRACTORS] Source: pages/VideoFeedPage.kt
// ----------------------------------------------------------------------------

object VideoFeedPage {
    fun fromJson(json: JsonObject): VideoFeedResult {
        val items = mutableListOf<YouTubeSearchResultItem>()
        
        val contents = json["contents"]?.jsonObject
            ?.get("twoColumnBrowseResultsRenderer")?.jsonObject
            ?.get("tabs")?.jsonArray?.firstOrNull()?.jsonObject
            ?.get("tabRenderer")?.jsonObject
            ?.get("content")?.jsonObject
            ?.get("sectionListRenderer")?.jsonObject
            ?.get("contents")?.jsonArray
            ?: json["onResponseReceivedActions"]?.jsonArray?.firstOrNull()?.jsonObject
                ?.get("appendContinuationItemsAction")?.jsonObject
                ?.get("continuationItems")?.jsonArray
            ?: return VideoFeedResult(emptyList(), null)

        var continuation: String? = null

        contents.forEach { content ->
            val itemSection = content.jsonObject["itemSectionRenderer"]?.jsonObject
            val shelf = content.jsonObject["richShelfRenderer"]?.jsonObject
            val richGrid = content.jsonObject["richGridRenderer"]?.jsonObject
            
            val videoItems = mutableListOf<JsonObject>()
            
            if (itemSection != null) {
                itemSection["contents"]?.jsonArray?.forEach { videoItems.add(it.jsonObject) }
            } else if (shelf != null) {
                shelf["contents"]?.jsonArray?.forEach { videoItems.add(it.jsonObject["richItemRenderer"]?.jsonObject ?: it.jsonObject) }
            } else if (richGrid != null) {
                richGrid["contents"]?.jsonArray?.forEach { videoItems.add(it.jsonObject["richItemRenderer"]?.jsonObject ?: it.jsonObject) }
                continuation = richGrid["continuations"]?.jsonArray?.firstOrNull()?.jsonObject
                    ?.get("nextContinuationData")?.jsonObject?.get("continuation")?.jsonPrimitive?.content
            } else if (content.jsonObject.containsKey("richItemRenderer")) {
                videoItems.add(content.jsonObject["richItemRenderer"]!!.jsonObject)
            } else if (content.jsonObject.containsKey("continuationItemRenderer")) {
                 continuation = content.jsonObject["continuationItemRenderer"]?.jsonObject
                    ?.get("continuationEndpoint")?.jsonObject
                    ?.get("continuationCommand")?.jsonObject
                    ?.get("token")?.jsonPrimitive?.content
            }

            videoItems.forEach { videoJson ->
                val renderer = videoJson["videoRenderer"]?.jsonObject 
                    ?: videoJson["gridVideoRenderer"]?.jsonObject
                    ?: videoJson["content"]?.jsonObject?.get("videoRenderer")?.jsonObject
                
                if (renderer != null) {
                    val videoId = renderer["videoId"]?.jsonPrimitive?.content ?: return@forEach
                    val title = renderer["title"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content ?: ""
                    val channelName = renderer["shortBylineText"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content ?: ""
                    val channelId = renderer["shortBylineText"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject
                        ?.get("navigationEndpoint")?.jsonObject?.get("browseEndpoint")?.jsonObject?.get("browseId")?.jsonPrimitive?.content
                    val channelThumbnailUrl = renderer["channelThumbnailSupportedRenderers"]?.jsonObject
                        ?.get("channelThumbnailWithLinkRenderer")?.jsonObject
                        ?.get("thumbnail")?.jsonObject?.get("thumbnails")?.jsonArray?.maxByOrNull { it.jsonObject["width"]?.jsonPrimitive?.int ?: 0 }
                        ?.jsonObject?.get("url")?.jsonPrimitive?.content

                    val thumbnails = renderer["thumbnail"]?.jsonObject?.get("thumbnails")?.jsonArray?.map {
                        Thumbnail(
                            url = it.jsonObject["url"]!!.jsonPrimitive.content,
                            width = it.jsonObject["width"]?.jsonPrimitive?.intOrNull,
                            height = it.jsonObject["height"]?.jsonPrimitive?.intOrNull
                        )
                    } ?: emptyList()

                    val viewCountText = renderer["viewCountText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content
                        ?: renderer["viewCountText"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content
                    val publishedTimeText = renderer["publishedTimeText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content
                    val durationText = renderer["lengthText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content
                    if (!com.listrovia.innertube.SongContentModerator.isAllowed(title, channelName)) {
                        return@forEach
                    }

                    items.add(YouTubeSearchResultItem.Video(YouTubeVideoItem(
                        videoId = videoId,
                        title = title,
                        channelName = channelName,
                        channelId = channelId,
                        channelThumbnailUrl = channelThumbnailUrl,
                        thumbnails = thumbnails,
                        viewCountText = viewCountText,
                        publishedTimeText = publishedTimeText,
                        durationText = durationText
                    )))
                }
            }
        }

        return VideoFeedResult(items, continuation)
    }

    fun parseSearch(json: JsonObject): VideoFeedResult {
        val items = mutableListOf<YouTubeSearchResultItem>()
        val contents = json["contents"]?.jsonObject
            ?.get("twoColumnSearchResultsRenderer")?.jsonObject
            ?.get("primaryContents")?.jsonObject
            ?.get("sectionListRenderer")?.jsonObject
            ?.get("contents")?.jsonArray
            ?: return VideoFeedResult(emptyList(), null)

        var continuation: String? = null

        contents.forEach { content ->
            val itemSection = content.jsonObject["itemSectionRenderer"]?.jsonObject ?: return@forEach
            itemSection["contents"]?.jsonArray?.forEach { videoJson ->
                val renderer = videoJson.jsonObject["videoRenderer"]?.jsonObject
                if (renderer != null) {
                    val videoId = renderer["videoId"]?.jsonPrimitive?.content ?: return@forEach
                    val title = renderer["title"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content ?: ""
                    val channelName = renderer["ownerText"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content ?: ""
                    val channelId = renderer["ownerText"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject
                        ?.get("navigationEndpoint")?.jsonObject?.get("browseEndpoint")?.jsonObject?.get("browseId")?.jsonPrimitive?.content
                    val channelThumbnailUrl = renderer["channelThumbnailSupportedRenderers"]?.jsonObject
                        ?.get("channelThumbnailWithLinkRenderer")?.jsonObject
                        ?.get("thumbnail")?.jsonObject?.get("thumbnails")?.jsonArray?.maxByOrNull { it.jsonObject["width"]?.jsonPrimitive?.int ?: 0 }
                        ?.jsonObject?.get("url")?.jsonPrimitive?.content

                    val thumbnails = renderer["thumbnail"]?.jsonObject?.get("thumbnails")?.jsonArray?.map {
                        Thumbnail(
                            url = it.jsonObject["url"]!!.jsonPrimitive.content,
                            width = it.jsonObject["width"]?.jsonPrimitive?.intOrNull,
                            height = it.jsonObject["height"]?.jsonPrimitive?.intOrNull
                        )
                    } ?: emptyList()

                    val viewCountText = renderer["viewCountText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content
                    val publishedTimeText = renderer["publishedTimeText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content
                    val durationText = renderer["lengthText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content

                    if (!com.listrovia.innertube.SongContentModerator.isAllowed(title, channelName)) {
                        return@forEach
                    }

                    items.add(YouTubeSearchResultItem.Video(YouTubeVideoItem(
                        videoId = videoId,
                        title = title,
                        channelName = channelName,
                        channelId = channelId,
                        channelThumbnailUrl = channelThumbnailUrl,
                        thumbnails = thumbnails,
                        viewCountText = viewCountText,
                        publishedTimeText = publishedTimeText,
                        durationText = durationText
                    )))
                    return@forEach
                }

                val channelRenderer = videoJson.jsonObject["channelRenderer"]?.jsonObject
                if (channelRenderer != null) {
                    val channelId = channelRenderer["channelId"]?.jsonPrimitive?.content ?: return@forEach
                    val title = channelRenderer["title"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content ?: ""
                    if (!com.listrovia.innertube.SongContentModerator.isAllowed(title)) {
                        return@forEach
                    }
                    val thumbnails = channelRenderer["thumbnail"]?.jsonObject?.get("thumbnails")?.jsonArray?.map {
                        Thumbnail(
                            url = it.jsonObject["url"]!!.jsonPrimitive.content,
                            width = it.jsonObject["width"]?.jsonPrimitive?.intOrNull,
                            height = it.jsonObject["height"]?.jsonPrimitive?.intOrNull
                        )
                    } ?: emptyList()
                    val subscriberCountText = channelRenderer["subscriberCountText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content
                    val videoCountText = channelRenderer["videoCountText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content
                    val description = channelRenderer["descriptionSnippet"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content

                    items.add(YouTubeSearchResultItem.Channel(
                        channelId = channelId,
                        title = title,
                        thumbnails = thumbnails,
                        subscriberCountText = subscriberCountText,
                        videoCountText = videoCountText,
                        description = description
                    ))
                    return@forEach
                }

                val playlistRenderer = videoJson.jsonObject["playlistRenderer"]?.jsonObject
                if (playlistRenderer != null) {
                    val playlistId = playlistRenderer["playlistId"]?.jsonPrimitive?.content ?: return@forEach
                    val title = playlistRenderer["title"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content ?: ""
                    val thumbnails = playlistRenderer["thumbnails"]?.jsonArray?.firstOrNull()?.jsonObject?.get("thumbnails")?.jsonArray?.map {
                        Thumbnail(
                            url = it.jsonObject["url"]!!.jsonPrimitive.content,
                            width = it.jsonObject["width"]?.jsonPrimitive?.intOrNull,
                            height = it.jsonObject["height"]?.jsonPrimitive?.intOrNull
                        )
                    } ?: emptyList()
                    val channelName = playlistRenderer["shortBylineText"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content
                    val itemCountText = playlistRenderer["videoCountText"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content

                    items.add(YouTubeSearchResultItem.Playlist(
                        playlistId = playlistId,
                        title = title,
                        thumbnails = thumbnails,
                        channelName = channelName,
                        itemCountText = itemCountText
                    ))
                    return@forEach
                }
            }
            
            if (continuation == null) {
                continuation = itemSection["continuations"]?.jsonArray?.firstOrNull()?.jsonObject
                    ?.get("nextContinuationData")?.jsonObject?.get("continuation")?.jsonPrimitive?.content
            }
        }

        return VideoFeedResult(items, continuation)
    }

    fun parseWatchMetadata(json: JsonObject): WatchMetadataResponse {
        // Simplified parsing for WatchMetadata
        return WatchMetadataResponse()
    }

    fun parseWatchNextContinuation(json: JsonObject): VideoFeedResult {
        // Simplified parsing for WatchNextContinuation
        return VideoFeedResult(emptyList(), null)
    }
}

// ----------------------------------------------------------------------------
// [UTILITIES, INTERCEPTORS & MODERATION] Source: utils/InnerTubeHealthCheck.kt
// ----------------------------------------------------------------------------

/**
 * Health check service that verifies the integrity of integrated InnerTube response models,
 * alerting if structural changes or parsing failures occur.
 */
object InnerTubeHealthCheck {
    private const val TAG = "InnerTubeHealth"

    suspend fun checkModelIntegrity(innerTube: InnerTube): HealthStatus {
        return try {
            Timber.tag(TAG).d("Starting InnerTube response model integrity check...")
            val result = innerTube.getSearchSuggestions(YouTubeClient.WEB_REMIX, "health_test")
            if (result.status.value in 200..299) {
                Timber.tag(TAG).i("InnerTube model integrity health check passed successfully.")
                HealthStatus.Healthy
            } else {
                Timber.tag(TAG).w("InnerTube model integrity check returned non-success status: %d", result.status.value)
                HealthStatus.Degraded("Non-success HTTP status: ${result.status.value}")
            }
        } catch (e: Exception) {
            InnerTubeLogger.logParsingError("health_check", e)
            HealthStatus.Unhealthy(e.message ?: "Unknown parsing or network failure")
        }
    }

    sealed interface HealthStatus {
        data object Healthy : HealthStatus
        data class Degraded(val reason: String) : HealthStatus
        data class Unhealthy(val error: String) : HealthStatus
    }
}

// ----------------------------------------------------------------------------
// [UTILITIES, INTERCEPTORS & MODERATION] Source: utils/InnerTubeHealthCheckService.kt
// ----------------------------------------------------------------------------

/**
 * HealthCheckService that periodically or on-demand sends test requests to the InnerTube API,
 * validating response structure against model definitions and providing state for UI warnings.
 * (Dịch vụ kiểm tra sức khỏe gửi yêu cầu kiểm tra và xác thực cấu trúc JSON với mô hình).
 */
object InnerTubeHealthCheckService {
    private val _healthState = MutableStateFlow<HealthStatus>(HealthStatus.Idle)
    val healthState: StateFlow<HealthStatus> = _healthState.asStateFlow()

    suspend fun runHealthCheck(innerTube: InnerTube) {
        _healthState.value = HealthStatus.Checking
        try {
            Timber.tag("InnerTubeHealth").d("Running InnerTube API health check & model validation...")
            val response = innerTube.getSearchSuggestions(YouTubeClient.WEB_REMIX, "diagnostics_test")
            if (response.status.value in 200..299) {
                _healthState.value = HealthStatus.Healthy
                Timber.tag("InnerTubeHealth").i("Health check completed: All models and schema structures are healthy.")
            } else {
                _healthState.value = HealthStatus.Warning("API returned status ${response.status.value}. Possible schema structure mismatch.")
            }
        } catch (e: Exception) {
            _healthState.value = HealthStatus.Error("Model parsing failure or network error: ${e.message}")
            InnerTubeLogger.logParsingError("health_check_service", e)
        }
    }

    sealed interface HealthStatus {
        data object Idle : HealthStatus
        data object Checking : HealthStatus
        data object Healthy : HealthStatus
        data class Warning(val message: String) : HealthStatus
        data class Error(val error: String) : HealthStatus
    }
}

// ----------------------------------------------------------------------------
// [UTILITIES, INTERCEPTORS & MODERATION] Source: utils/InnerTubeInterceptor.kt
// ----------------------------------------------------------------------------

/**
 * Ktor/OkHttp Interceptor that logs all InnerTube API request and response flows using Timber,
 * categorizing errors into 'Data Structure Mismatches' or 'Parsing Failures' and pushing them to InnerTubeLogBuffer.
 */
class InnerTubeInterceptor : Interceptor {
    private val TAG = "InnerTubeNetwork"

    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val url = request.url.toString()
        val startTime = System.currentTimeMillis()

        InnerTubeLogger.logRequest(url, request.method)

        val response = try {
            chain.proceed(request)
        } catch (e: SerializationException) {
            val msg = "[Parsing Failures] Serialization error: ${e.message}"
            Timber.tag(TAG).e(e, msg)
            InnerTubeLogBuffer.addLog(ApiLogEntry.LogCategory.PARSING_FAILURE, msg, url)
            throw e
        } catch (e: IOException) {
            val msg = "[Data Structure Mismatches] Network/IO error: ${e.message}"
            Timber.tag(TAG).e(e, msg)
            InnerTubeLogBuffer.addLog(ApiLogEntry.LogCategory.DATA_STRUCTURE_MISMATCH, msg, url)
            throw e
        } catch (e: Exception) {
            val msg = "[Data Structure Mismatches] Unexpected exception: ${e.message}"
            Timber.tag(TAG).e(e, msg)
            InnerTubeLogBuffer.addLog(ApiLogEntry.LogCategory.DATA_STRUCTURE_MISMATCH, msg, url)
            throw e
        }

        val duration = System.currentTimeMillis() - startTime
        val code = response.code

        if (code in 200..299) {
            InnerTubeLogger.logResponse(url, code, response.body?.contentLength()?.toInt() ?: 0)
        } else {
            val msg = "[Data Structure Mismatches] HTTP status $code in ${duration}ms (Breaking API change suspected)"
            Timber.tag(TAG).w(msg)
            InnerTubeLogBuffer.addLog(ApiLogEntry.LogCategory.DATA_STRUCTURE_MISMATCH, msg, url)
        }

        return response
    }
}

// ----------------------------------------------------------------------------
// [UTILITIES, INTERCEPTORS & MODERATION] Source: utils/InnerTubeLogBuffer.kt
// ----------------------------------------------------------------------------

/**
 * Real-time API log buffer capturing categorized errors ('Data Structure Mismatches' or 'Parsing Failures').
 * (Bộ đệm log thời gian thực lưu trữ các lỗi lệch cấu trúc dữ liệu hoặc phân tích mô hình).
 */
data class ApiLogEntry(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: String = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()),
    val category: LogCategory,
    val message: String,
    val url: String
) {
    enum class LogCategory {
        DATA_STRUCTURE_MISMATCH,
        PARSING_FAILURE,
        INFO
    }
}

object InnerTubeLogBuffer {
    private val _logs = MutableStateFlow<List<ApiLogEntry>>(emptyList())
    val logs: StateFlow<List<ApiLogEntry>> = _logs.asStateFlow()

    private const val MAX_LOGS = 100

    @Synchronized
    fun addLog(category: ApiLogEntry.LogCategory, message: String, url: String) {
        val entry = ApiLogEntry(category = category, message = message, url = url)
        val current = _logs.value.toMutableList()
        current.add(0, entry)
        if (current.size > MAX_LOGS) {
            current.removeAt(current.size - 1)
        }
        _logs.value = current
    }

    @Synchronized
    fun clearLogs() {
        _logs.value = emptyList()
    }
}

// ----------------------------------------------------------------------------
// [UTILITIES, INTERCEPTORS & MODERATION] Source: utils/InnerTubeLogger.kt
// ----------------------------------------------------------------------------

/**
 * Unified logging mechanism within the integrated InnerTube codebase
 * to track API request/response flows and parsing errors in real-time.
 */
object InnerTubeLogger {
    private const val TAG = "InnerTubeTrace"

    fun logRequest(endpoint: String, payloadSummary: String) {
        Timber.tag(TAG).d("API REQUEST -> [%s] Payload: %s", endpoint, payloadSummary)
    }

    fun logResponse(endpoint: String, statusCode: Int, bodySize: Int) {
        Timber.tag(TAG).d("API RESPONSE <- [%s] Status: %d, Size: %d bytes", endpoint, statusCode, bodySize)
    }

    fun logParsingError(endpoint: String, error: Throwable) {
        Timber.tag(TAG).e(error, "PARSING ERROR X [%s] Failed to parse response model structure.", endpoint)
    }
}

// ----------------------------------------------------------------------------
// [UTILITIES, INTERCEPTORS & MODERATION] Source: utils/InnerTubeStreamFilterLayer.kt
// ----------------------------------------------------------------------------

/**
 * Filtering layer in the search and recommendation stream that intercepts raw InnerTube API
 * responses and prunes items flagged as sensitive, violent, or illegal based on updated
 * moderation guidelines.
 */
object InnerTubeStreamFilterLayer {
    private const val TAG = "InnerTubeFilterLayer"

    /**
     * Intercepts and prunes raw SearchResponse contents.
     */
    fun pruneSearchResponse(response: SearchResponse): SearchResponse {
        val tabbed = response.contents?.tabbedSearchResultsRenderer ?: return response
        val updatedTabs = tabbed.tabs?.mapNotNull { tab ->
            if (tab == null) return@mapNotNull null
            val sectionList = tab.tabRenderer?.content?.sectionListRenderer
            if (sectionList != null) {
                val updatedContents = sectionList.contents?.mapNotNull { section ->
                    when {
                        section.musicCardShelfRenderer != null -> {
                            val card = section.musicCardShelfRenderer
                            val title = card.header?.musicCardShelfHeaderBasicRenderer?.title?.runs?.firstOrNull()?.text ?: ""
                            val subtitle = card.subtitle?.runs?.firstOrNull()?.text ?: ""
                            if (!SongContentModerator.isAllowed(title, subtitle)) {
                                Timber.tag(TAG).w("Pruned musicCardShelfRenderer from search: '$title'")
                                null
                            } else {
                                section
                            }
                        }
                        section.musicShelfRenderer != null -> {
                            val shelf = section.musicShelfRenderer
                            val filteredContents = shelf.contents?.filter { content ->
                                val renderer = content.musicResponsiveListItemRenderer
                                if (renderer != null) {
                                    val title = renderer.flexColumns.firstOrNull()
                                        ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.text ?: ""
                                    val artist = renderer.flexColumns.getOrNull(1)
                                        ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.text ?: ""
                                    SongContentModerator.isAllowed(title, artist)
                                } else {
                                    true
                                }
                            }
                            section.copy(musicShelfRenderer = shelf.copy(contents = filteredContents))
                        }
                        section.itemSectionRenderer != null -> {
                            val itemSection = section.itemSectionRenderer
                            val filteredContents = itemSection.contents?.filter { content ->
                                val renderer = content.musicResponsiveListItemRenderer
                                if (renderer != null) {
                                    val title = renderer.flexColumns.firstOrNull()
                                        ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.text ?: ""
                                    val artist = renderer.flexColumns.getOrNull(1)
                                        ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.text ?: ""
                                    SongContentModerator.isAllowed(title, artist)
                                } else {
                                    true
                                }
                            }
                            section.copy(itemSectionRenderer = itemSection.copy(contents = filteredContents))
                        }
                        else -> section
                    }
                }
                tab.copy(
                    tabRenderer = tab.tabRenderer.copy(
                        content = tab.tabRenderer.content.copy(
                            sectionListRenderer = sectionList.copy(contents = updatedContents)
                        )
                    )
                )
            } else {
                tab
            }
        }.orEmpty()

        return response.copy(
            contents = response.contents.copy(
                tabbedSearchResultsRenderer = tabbed.copy(tabs = updatedTabs)
            )
        )
    }

    /**
     * Intercepts and prunes raw BrowseResponse (Home recommendation feed, Explore, Charts, New Releases).
     */
    fun pruneBrowseResponse(response: BrowseResponse): BrowseResponse {
        val singleColumn = response.contents?.singleColumnBrowseResultsRenderer ?: return response
        val tabs = singleColumn.tabs ?: return response

        val updatedTabs = tabs.mapNotNull { tab ->
            if (tab == null) return@mapNotNull null
            val sectionList = tab.tabRenderer?.content?.sectionListRenderer
            if (sectionList != null) {
                val updatedContents = sectionList.contents?.mapNotNull { content ->
                    val carousel = content.musicCarouselShelfRenderer
                    if (carousel != null) {
                        val filteredItems = carousel.contents.filter { item ->
                            val title = item.musicTwoRowItemRenderer?.title?.runs?.firstOrNull()?.text
                                ?: item.musicResponsiveListItemRenderer?.flexColumns?.firstOrNull()
                                    ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.text
                                ?: item.musicMultiRowListItemRenderer?.title?.runs?.firstOrNull()?.text
                                ?: ""
                            val subtitle = item.musicTwoRowItemRenderer?.subtitle?.runs?.firstOrNull()?.text
                                ?: item.musicResponsiveListItemRenderer?.flexColumns?.getOrNull(1)
                                    ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.text
                                ?: item.musicMultiRowListItemRenderer?.subtitle?.runs?.firstOrNull()?.text
                                ?: ""

                            if (title.isNotBlank() && !SongContentModerator.isAllowed(title, subtitle)) {
                                Timber.tag(TAG).w("Pruned recommendation item: '$title' / '$subtitle'")
                                false
                            } else {
                                true
                            }
                        }
                        content.copy(musicCarouselShelfRenderer = carousel.copy(contents = filteredItems))
                    } else {
                        content
                    }
                }
                tab.copy(
                    tabRenderer = tab.tabRenderer.copy(
                        content = tab.tabRenderer.content.copy(
                            sectionListRenderer = sectionList.copy(contents = updatedContents)
                        )
                    )
                )
            } else {
                tab
            }
        }.orEmpty()

        return response.copy(
            contents = response.contents.copy(
                singleColumnBrowseResultsRenderer = singleColumn.copy(tabs = updatedTabs)
            )
        )
    }

    /**
     * Intercepts and prunes raw NextResponse (Queue, Next, Up Next, Radio recommendations).
     */
    fun pruneNextResponse(response: NextResponse): NextResponse {
        val watchNext = response.contents.singleColumnMusicWatchNextResultsRenderer ?: return response
        val tabbed = watchNext.tabbedRenderer?.watchNextTabbedResultsRenderer ?: return response

        val updatedTabs = tabbed.tabs.map { tab ->
            val queue = tab.tabRenderer.content?.musicQueueRenderer
            val playlistPanel = queue?.content?.playlistPanelRenderer
            if (playlistPanel != null) {
                val filteredContents = playlistPanel.contents.filter { content ->
                    val panelVideo = content.playlistPanelVideoRenderer
                    if (panelVideo != null) {
                        val title = panelVideo.title?.runs?.firstOrNull()?.text ?: ""
                        val artist = panelVideo.longBylineText?.runs?.firstOrNull()?.text ?: ""
                        if (!SongContentModerator.isAllowed(title, artist)) {
                            Timber.tag(TAG).w("Pruned next recommendation: '$title' by '$artist'")
                            false
                        } else {
                            true
                        }
                    } else {
                        true
                    }
                }
                tab.copy(
                    tabRenderer = tab.tabRenderer.copy(
                        content = tab.tabRenderer.content.copy(
                            musicQueueRenderer = queue.copy(
                                content = queue.content.copy(
                                    playlistPanelRenderer = playlistPanel.copy(contents = filteredContents)
                                )
                            )
                        )
                    )
                )
            } else {
                tab
            }
        }

        return response.copy(
            contents = response.contents.copy(
                singleColumnMusicWatchNextResultsRenderer = watchNext.copy(
                    tabbedRenderer = watchNext.tabbedRenderer.copy(
                        watchNextTabbedResultsRenderer = tabbed.copy(tabs = updatedTabs)
                    )
                )
            )
        )
    }

    /**
     * Intercepts and prunes search suggestions and raw search suggestions response.
     */
    fun pruneSearchSuggestionsResponse(response: GetSearchSuggestionsResponse): GetSearchSuggestionsResponse {
        val updatedContents = response.contents?.map { section ->
            val ssSection = section.searchSuggestionsSectionRenderer
            if (ssSection != null) {
                val filteredSuggestions = ssSection.contents?.filter { item ->
                    val query = item.searchSuggestionRenderer?.suggestion?.runs?.joinToString("") { it.text } ?: ""
                    val title = item.musicResponsiveListItemRenderer?.flexColumns?.firstOrNull()
                        ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.text ?: ""
                    val subtitle = item.musicResponsiveListItemRenderer?.flexColumns?.getOrNull(1)
                        ?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.firstOrNull()?.text ?: ""

                    when {
                        query.isNotBlank() && !SongContentModerator.isSearchAllowed(query) -> {
                            Timber.tag(TAG).w("Pruned search suggestion query: '$query'")
                            false
                        }
                        title.isNotBlank() && !SongContentModerator.isAllowed(title, subtitle) -> {
                            Timber.tag(TAG).w("Pruned search suggestion item: '$title'")
                            false
                        }
                        else -> true
                    }
                }.orEmpty()
                section.copy(searchSuggestionsSectionRenderer = ssSection.copy(contents = filteredSuggestions))
            } else {
                section
            }
        }
        return response.copy(contents = updatedContents)
    }

    /**
     * Prunes a list of YTItem objects against updated moderation guidelines.
     */
    fun <T : YTItem> pruneItems(items: List<T>): List<T> {
        return items.filter { item ->
            SongContentModerator.isItemAllowed(item)
        }
    }
}

// ----------------------------------------------------------------------------
// [UTILITIES, INTERCEPTORS & MODERATION] Source: utils/RegionalRestrictionInterceptor.kt
// ----------------------------------------------------------------------------

/**
 * Network interceptor or utility function to check the user's IP location via an external API
 * and compare it against the configured restricted countries list to prevent playback and search access.
 *
 * Prevents playback (/player, /watch) and search access (/search, /get_search_suggestions, /next)
 * when the user's detected geolocation belongs to a restricted territory.
 */
object RegionalRestrictionInterceptor : Interceptor {
    private const val TAG = "RegionalRestrictionInterceptor"

    /**
     * Utility function to check the user's IP location via an external API and compare
     * it against the configured restricted countries list to prevent playback and search access.
     */
    fun checkUserIpLocationAndEnforce(context: android.content.Context, onResult: ((Boolean) -> Unit)? = null) {
        SongContentModerator.checkUserIpLocationAndEnforce(context, onResult)
    }

    /**
     * Utility function to evaluate whether playback and search access is currently restricted.
     */
    fun isAccessRestricted(): Boolean {
        return SongContentModerator.isAccessRestricted()
    }

    @Throws(IOException::class)
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val path = request.url.encodedPath

        val isPlaybackOrSearchEndpoint = path.contains("/player") ||
                path.contains("/watch") ||
                path.contains("/search") ||
                path.contains("/get_search_suggestions") ||
                path.contains("/next")

        if (isPlaybackOrSearchEndpoint && SongContentModerator.isAccessRestricted()) {
            val country = SongContentModerator.detectedRegion.value
            Timber.tag(TAG).w("Regional restriction enforced: Blocking $path for country '$country'")

            // Synthesize an HTTP 403 Forbidden Response to cleanly halt InnerTube network access
            val errorJson = """
                {
                    "error": {
                        "code": 403,
                        "message": "Access to playback and search is restricted in your region ($country) by compliance policy.",
                        "status": "PERMISSION_DENIED"
                    }
                }
            """.trimIndent()

            return Response.Builder()
                .request(request)
                .protocol(okhttp3.Protocol.HTTP_1_1)
                .code(403)
                .message("Forbidden: Regional Restriction Active ($country)")
                .body(errorJson.toResponseBody("application/json".toMediaType()))
                .build()
        }

        return chain.proceed(request)
    }
}

// ----------------------------------------------------------------------------
// [UTILITIES, INTERCEPTORS & MODERATION] Source: utils/SongContentModerator.kt
// ----------------------------------------------------------------------------

/**
 * Comprehensive Content Moderation & Family Protection Engine for InnerTube.
 * Protects users across devices (Mobile Phone, Tablet/iPad, Desktop/Laptop, Android TV) and regions/IPs.
 * Filters out scam/fraudulent promotions, phishing links, abusive comments, sensitive media,
 * and regulates shared YouTube Music content as well as home and external search queries.
 *
 * Enforces regional restrictions based on user's IP geolocation against configured restricted countries list.
 */
object SongContentModerator {
    private const val TAG = "SongContentModerator"

    // Counters for blocked threats
    private val _blockedScamCount = MutableStateFlow(0)
    val blockedScamCount: StateFlow<Int> = _blockedScamCount.asStateFlow()

    private val _blockedViolationsCount = MutableStateFlow(0)
    val blockedViolationsCount: StateFlow<Int> = _blockedViolationsCount.asStateFlow()

    private val _detectedFormFactor = MutableStateFlow("Phone")
    val detectedFormFactor: StateFlow<String> = _detectedFormFactor.asStateFlow()

    private val _detectedRegion = MutableStateFlow(Locale.getDefault().country.ifEmpty { "VN" })
    val detectedRegion: StateFlow<String> = _detectedRegion.asStateFlow()

    private val _detectedCountryName = MutableStateFlow("Việt Nam / Vietnam")
    val detectedCountryName: StateFlow<String> = _detectedCountryName.asStateFlow()

    private val _detectedIp = MutableStateFlow("Household IP / Mạng gia đình")
    val detectedIp: StateFlow<String> = _detectedIp.asStateFlow()

    private val _detectedHouseholdStatus = MutableStateFlow("Bảo vệ mạng gia đình an toàn / Family Guard Active")
    val detectedHouseholdStatus: StateFlow<String> = _detectedHouseholdStatus.asStateFlow()

    // Configured restricted countries list to prevent playback and search access
    private val _configuredRestrictedCountries = MutableStateFlow<Set<String>>(
        setOf("KP", "IR", "CU", "SY", "RESTRICTED_TEST")
    )
    val configuredRestrictedCountries: StateFlow<Set<String>> = _configuredRestrictedCountries.asStateFlow()

    private val _isRegionRestricted = MutableStateFlow(false)
    val isRegionRestricted: StateFlow<Boolean> = _isRegionRestricted.asStateFlow()

    private val _outsideSearchCensorshipActive = MutableStateFlow(true)
    val outsideSearchCensorshipActive: StateFlow<Boolean> = _outsideSearchCensorshipActive.asStateFlow()

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(5, TimeUnit.SECONDS)
            .build()
    }

    // 1. Phishing, fraud, and scam keywords
    private val scamKeywords = listOf(
        "lừa đảo", "lua dao", "hack tiền", "nhận quà miễn phí", "tặng thẻ cào",
        "crypto pump", "free robux", "giveaway scam", "whatsapp crypto", "telegram signal",
        "click here for free", "claim your prize", "bot farm", "phishing", "free gift card",
        "hack coin", "mod unlimited money", "free vbucks", "earn 1000$ per day",
        "kiếm tiền online lừa đảo", "nạp thẻ cào giả mạo", "fake token", "airdrop scam",
        "bẫy tài chính", "cờ bạc bịp", "hack like", "hack view ảo", "invest profit guaranteed",
        "fake investment", "carding", "credit card dump"
    )

    // 2. Sensitive, offensive, violent, and illegal violation keywords (Updated Moderation Guidelines)
    private val violationKeywords = listOf(
        "prohibited_explicit_test", "nsfw_sample", "restricted_content_flag",
        "bạo lực cực đoan", "hate speech", "violent gore", "illegal stream crack",
        "warez rip", "suicide encourage", "deepfake porn", "snuff",
        "khiêu dâm độc hại", "xúc phạm danh dự", "nội dung phản cảm cấm", "phát tán mã độc",
        "terrorist propaganda", "bomb making", "child exploitation", "extreme gore",
        "nazi anthem", "beheading video", "heroin sale", "illegal weapons trade",
        "tuyên truyền cực đoan", "kích động bạo lực", "khiêu dâm trẻ em cấm", "buôn bán chất cấm"
    )

    // 3. Prohibited comment spam and malicious redirection patterns
    private val suspiciousUrlPatterns = listOf(
        "bit.ly/", "t.me/", "tinyurl.com/", "wa.me/", "goo.gl/", "click.ru/", "freebonus",
        "shorturl.at/", "cutt.ly/", "adf.ly/", "linkvertise.com/", "iplogger.", "grabify."
    )

    enum class DeviceFormFactor {
        MOBILE_PHONE,
        TABLET_IPAD,
        LAPTOP_PC,
        ANDROID_TV
    }

    /**
     * Checks if search and playback access is restricted based on detected country and configured list.
     */
    fun isAccessRestricted(): Boolean {
        val currentCountry = _detectedRegion.value.uppercase()
        return _isRegionRestricted.value || _configuredRestrictedCountries.value.contains(currentCountry)
    }

    fun setRestrictedCountries(countries: Set<String>) {
        _configuredRestrictedCountries.value = countries.map { it.uppercase().trim() }.toSet()
        evaluateRegionalRestriction()
    }

    fun addRestrictedCountry(countryCode: String) {
        _configuredRestrictedCountries.value = _configuredRestrictedCountries.value + countryCode.uppercase().trim()
        evaluateRegionalRestriction()
    }

    fun removeRestrictedCountry(countryCode: String) {
        _configuredRestrictedCountries.value = _configuredRestrictedCountries.value - countryCode.uppercase().trim()
        evaluateRegionalRestriction()
    }

    private fun evaluateRegionalRestriction() {
        val country = _detectedRegion.value.uppercase()
        val isRestricted = _configuredRestrictedCountries.value.contains(country)
        _isRegionRestricted.value = isRestricted
        if (isRestricted) {
            Timber.tag(TAG).w("Regional restriction active: country '$country' is restricted from search and playback.")
        }
    }

    /**
     * Updates device environment and regional IP/locale configuration.
     */
    fun updateEnvironment(context: android.content.Context, regionCode: String? = null) {
        val formFactor = detectDeviceFormFactor(context)
        _detectedFormFactor.value = when (formFactor) {
            DeviceFormFactor.MOBILE_PHONE -> "Điện thoại di động (Phone)"
            DeviceFormFactor.TABLET_IPAD -> "Máy tính bảng / iPad (Tablet)"
            DeviceFormFactor.LAPTOP_PC -> "Máy tính xách tay / PC (Desktop)"
            DeviceFormFactor.ANDROID_TV -> "Tivi thông minh (Android TV)"
        }

        val region = regionCode?.takeIf { it != "system" && it != "SYSTEM_DEFAULT" }
            ?: Locale.getDefault().country.ifEmpty { "VN" }
        _detectedRegion.value = region.uppercase()
        updateCountryName(region.uppercase())
        evaluateRegionalRestriction()

        // Asynchronously check IP and household network status via external IP lookup API
        detectPublicIpAndCountry(context)
    }

    fun detectDeviceFormFactor(context: android.content.Context): DeviceFormFactor {
        val config = context.resources.configuration
        val uiMode = config.uiMode and Configuration.UI_MODE_TYPE_MASK
        if (uiMode == Configuration.UI_MODE_TYPE_TELEVISION) {
            return DeviceFormFactor.ANDROID_TV
        }
        val screenWidthDp = config.screenWidthDp
        return when {
            screenWidthDp >= 900 -> DeviceFormFactor.LAPTOP_PC
            screenWidthDp >= 600 -> DeviceFormFactor.TABLET_IPAD
            else -> DeviceFormFactor.MOBILE_PHONE
        }
    }

    /**
     * Utility function to check the user's IP location via an external API and compare
     * it against the configured restricted countries list to prevent playback and search access.
     */
    fun checkUserIpLocationAndEnforce(context: android.content.Context, onResult: ((Boolean) -> Unit)? = null) {
        detectPublicIpAndCountry(context, onResult)
    }

    /**
     * Utility function to check the user's IP location via external APIs (with resilient fallbacks)
     * and compare it against the configured restricted countries list to prevent playback and search access.
     */
    fun detectPublicIpAndCountry(context: android.content.Context, onResult: ((Boolean) -> Unit)? = null) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val connMgr = context.getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                val activeNetwork = connMgr?.activeNetwork
                val caps = connMgr?.getNetworkCapabilities(activeNetwork)
                val isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true

                _detectedHouseholdStatus.value = if (isWifi) {
                    "Mạng Wi-Fi gia đình (Family Household Wi-Fi)"
                } else {
                    "Mạng di động cá nhân (Cellular Network)"
                }

                var resolved = false

                // 1. Try primary endpoint (country.is)
                try {
                    val request = Request.Builder()
                        .url("https://api.country.is/")
                        .header("User-Agent", "Listrovia-SafeGuard/1.0")
                        .build()

                    httpClient.newCall(request).execute().use { response ->
                        if (response.isSuccessful) {
                            val body = response.body?.string()
                            if (!body.isNullOrBlank()) {
                                val json = JSONObject(body)
                                val ip = json.optString("ip", "")
                                val country = json.optString("country", "")
                                if (ip.isNotBlank()) _detectedIp.value = ip
                                if (country.isNotBlank()) {
                                    val upperCountry = country.uppercase()
                                    _detectedRegion.value = upperCountry
                                    updateCountryName(upperCountry)
                                    evaluateRegionalRestriction()
                                    resolved = true
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    Timber.tag(TAG).d("Primary IP lookup (country.is) failed: ${e.message}")
                }

                // 2. Secondary fallback (ipwho.is) if primary didn't resolve
                if (!resolved) {
                    try {
                        val request = Request.Builder()
                            .url("https://ipwho.is/")
                            .header("User-Agent", "Listrovia-SafeGuard/1.0")
                            .build()

                        httpClient.newCall(request).execute().use { response ->
                            if (response.isSuccessful) {
                                val body = response.body?.string()
                                if (!body.isNullOrBlank()) {
                                    val json = JSONObject(body)
                                    val ip = json.optString("ip", "")
                                    val country = json.optString("country_code", "")
                                    if (ip.isNotBlank()) _detectedIp.value = ip
                                    if (country.isNotBlank()) {
                                        val upperCountry = country.uppercase()
                                        _detectedRegion.value = upperCountry
                                        updateCountryName(upperCountry)
                                        evaluateRegionalRestriction()
                                        resolved = true
                                    }
                                }
                            }
                        }
                    } catch (e: Exception) {
                        Timber.tag(TAG).d("Secondary IP lookup (ipwho.is) failed: ${e.message}")
                    }
                }

                // 3. Tertiary fallback (ip-api.com)
                if (!resolved) {
                    try {
                        val request = Request.Builder()
                            .url("http://ip-api.com/json")
                            .header("User-Agent", "Listrovia-SafeGuard/1.0")
                            .build()

                        httpClient.newCall(request).execute().use { response ->
                            if (response.isSuccessful) {
                                val body = response.body?.string()
                                if (!body.isNullOrBlank()) {
                                    val json = JSONObject(body)
                                    val ip = json.optString("query", "")
                                    val country = json.optString("countryCode", "")
                                    if (ip.isNotBlank()) _detectedIp.value = ip
                                    if (country.isNotBlank()) {
                                        val upperCountry = country.uppercase()
                                        _detectedRegion.value = upperCountry
                                        updateCountryName(upperCountry)
                                        evaluateRegionalRestriction()
                                        resolved = true
                                    }
                                }
                            }
                        }
                    } catch (e: Exception) {
                        Timber.tag(TAG).d("Tertiary IP lookup (ip-api.com) failed: ${e.message}")
                    }
                }
            } catch (e: Exception) {
                Timber.tag(TAG).d("IP and Geolocation lookup fallback to Locale: ${e.message}")
            } finally {
                evaluateRegionalRestriction()
                onResult?.invoke(isAccessRestricted())
            }
        }
    }

    private fun updateCountryName(countryCode: String) {
        _detectedCountryName.value = when (countryCode) {
            "VN" -> "Việt Nam (Vietnam)"
            "US" -> "Hoa Kỳ (United States)"
            "JP" -> "Nhật Bản (Japan)"
            "KR" -> "Hàn Quốc (South Korea)"
            "SG" -> "Singapore"
            "GB", "UK" -> "Vương quốc Anh (United Kingdom)"
            "DE" -> "Đức (Germany)"
            "FR" -> "Pháp (France)"
            "CA" -> "Canada"
            "AU" -> "Úc (Australia)"
            "IN" -> "Ấn Độ (India)"
            "TH" -> "Thái Lan (Thailand)"
            "ID" -> "Indonesia"
            "PH" -> "Philippines"
            "MY" -> "Malaysia"
            "KP" -> "Triều Tiên (North Korea - Restricted)"
            "IR" -> "Iran (Restricted)"
            "CU" -> "Cuba (Restricted)"
            "SY" -> "Syria (Restricted)"
            else -> "$countryCode (International)"
        }
    }

    /**
     * Validates shared YouTube Music URL or text.
     * Prevents sharing or receiving scam links, malicious shorteners, and banned video content.
     */
    fun isSharedUrlAllowed(urlOrText: String): Boolean {
        if (isAccessRestricted()) {
            _blockedViolationsCount.value += 1
            return false
        }

        val lower = urlOrText.lowercase(Locale.ROOT).trim()
        if (lower.isBlank()) return true

        // Reject known malicious shorteners or redirect trackers
        for (pattern in suspiciousUrlPatterns) {
            if (lower.contains(pattern)) {
                _blockedScamCount.value += 1
                Timber.tag(TAG).w("Blocked malicious shared link: $urlOrText")
                return false
            }
        }

        // Check for scam words embedded in shared text
        for (scam in scamKeywords) {
            if (lower.contains(scam)) {
                _blockedScamCount.value += 1
                Timber.tag(TAG).w("Blocked scam keyword in shared content: $urlOrText")
                return false
            }
        }

        // Check for severe violations
        for (violation in violationKeywords) {
            if (lower.contains(violation)) {
                _blockedViolationsCount.value += 1
                Timber.tag(TAG).w("Blocked violating keyword in shared content: $urlOrText")
                return false
            }
        }

        return true
    }

    /**
     * Checks if a title & artist name is compliant and free of scams and violations.
     * Used by the stream filtering layer to prune raw InnerTube responses.
     */
    fun isAllowed(title: String, artistName: String? = null): Boolean {
        val combined = "$title ${artistName.orEmpty()}".lowercase(Locale.ROOT)

        for (scam in scamKeywords) {
            if (combined.contains(scam)) {
                _blockedScamCount.value += 1
                Timber.tag(TAG).w("Pruned scam/fraud item: matched '$scam' in '$title'")
                return false
            }
        }

        for (violation in violationKeywords) {
            if (combined.contains(violation)) {
                _blockedViolationsCount.value += 1
                Timber.tag(TAG).w("Pruned violating/sensitive content: matched '$violation' in '$title'")
                return false
            }
        }

        return true
    }

    /**
     * Validates any generic YTItem (Song, Album, Playlist, Artist, Episode).
     * Prunes sensitive, violent, or illegal items from search and recommendation streams.
     */
    fun isItemAllowed(item: YTItem): Boolean {
        val title = item.title
        val artist = when (item) {
            is SongItem -> item.artists.joinToString(" ") { it.name }
            is AlbumItem -> item.artists?.joinToString(" ") { it.name }
            is PlaylistItem -> item.author?.name
            is ArtistItem -> item.title
            is EpisodeItem -> item.author?.name
            is PodcastItem -> item.author?.name
            else -> ""
        }
        if (!isAllowed(title, artist)) return false
        if (!isThumbnailSafe(item.thumbnail)) return false
        return true
    }

    /**
     * Validates in-app search queries and search suggestions.
     */
    fun isSearchAllowed(query: String): Boolean {
        if (isAccessRestricted()) return false
        val q = query.lowercase(Locale.ROOT).trim()
        if (q.isBlank()) return true

        for (scam in scamKeywords) {
            if (q.contains(scam)) {
                _blockedScamCount.value += 1
                Timber.tag(TAG).w("Blocked scam search query: '$query'")
                return false
            }
        }
        for (violation in violationKeywords) {
            if (q.contains(violation)) {
                _blockedViolationsCount.value += 1
                Timber.tag(TAG).w("Blocked violating search query: '$query'")
                return false
            }
        }
        return true
    }

    /**
     * Validates queries originating outside the home page or from deep links / external sources.
     */
    fun isOutsideSearchAllowed(query: String): Boolean {
        if (isAccessRestricted()) return false
        if (!_outsideSearchCensorshipActive.value) return isSearchAllowed(query)
        val q = query.lowercase(Locale.ROOT).trim()
        if (q.isBlank()) return true

        if (!isSearchAllowed(q)) return false

        // Stricter check for external / outside search queries
        for (pattern in suspiciousUrlPatterns) {
            if (q.contains(pattern)) {
                _blockedScamCount.value += 1
                return false
            }
        }
        return true
    }

    /**
     * Validates user comments to prevent spam, scam links, and abusive behavior.
     */
    fun isCommentAllowed(text: String): Boolean {
        val content = text.lowercase(Locale.ROOT)
        for (pattern in suspiciousUrlPatterns) {
            if (content.contains(pattern)) {
                _blockedScamCount.value += 1
                Timber.tag(TAG).w("Blocked scam link in comment: '$text'")
                return false
            }
        }
        for (scam in scamKeywords) {
            if (content.contains(scam)) {
                _blockedScamCount.value += 1
                Timber.tag(TAG).w("Blocked scam keyword in comment: '$text'")
                return false
            }
        }
        for (violation in violationKeywords) {
            if (content.contains(violation)) {
                _blockedViolationsCount.value += 1
                Timber.tag(TAG).w("Blocked violating keyword in comment: '$text'")
                return false
            }
        }
        return true
    }

    /**
     * Verifies thumbnail URL safety.
     */
    fun isThumbnailSafe(url: String?): Boolean {
        if (url == null) return true
        val lower = url.lowercase(Locale.ROOT)
        for (pattern in suspiciousUrlPatterns) {
            if (lower.contains(pattern)) return false
        }
        return true
    }

    fun setOutsideSearchCensorship(enabled: Boolean) {
        _outsideSearchCensorshipActive.value = enabled
    }
}

// ----------------------------------------------------------------------------
// [UTILITIES, INTERCEPTORS & MODERATION] Source: utils/Utils.kt
// ----------------------------------------------------------------------------

@JvmName("completedLibrary")
suspend fun Result<PlaylistPage>.completed(): Result<PlaylistPage> = runCatching {
    val page = getOrThrow()
    val songs = page.songs.toMutableList()
    var continuation = page.songsContinuation
    val seenContinuations = mutableSetOf<String>()
    var requestCount = 0
    val maxRequests = 50
    var consecutiveEmptyResponses = 0
    
    while (continuation != null && requestCount < maxRequests) {
        if (continuation in seenContinuations) {
            break
        }
        seenContinuations.add(continuation)
        requestCount++
        
        val continuationPage = YouTube.playlistContinuation(continuation).getOrNull() ?: break
        
        if (continuationPage.songs.isEmpty()) {
            consecutiveEmptyResponses++
            if (consecutiveEmptyResponses >= 2) break
        } else {
            consecutiveEmptyResponses = 0
            songs += continuationPage.songs
        }
        
        continuation = continuationPage.continuation
    }
    PlaylistPage(
        playlist = page.playlist,
        songs = songs,
        songsContinuation = null,
        continuation = page.continuation
    )
}

@JvmName("completedPlaylist")
suspend fun Result<LibraryPage>.completed(): Result<LibraryPage> = runCatching {
    val page = getOrThrow()
    val items = page.items.toMutableList()
    var continuation = page.continuation
    val seenContinuations = mutableSetOf<String>()
    var requestCount = 0
    val maxRequests = 50
    var consecutiveEmptyResponses = 0
    
    while (continuation != null && requestCount < maxRequests) {
        if (continuation in seenContinuations) {
            break
        }
        seenContinuations.add(continuation)
        requestCount++
        
        val continuationPage = YouTube.libraryContinuation(continuation).getOrNull() ?: break
        
        if (continuationPage.items.isEmpty()) {
            consecutiveEmptyResponses++
            if (consecutiveEmptyResponses >= 2) break
        } else {
            consecutiveEmptyResponses = 0
            items += continuationPage.items
        }
        
        continuation = continuationPage.continuation
    }
    LibraryPage(
        items = items,
        continuation = null
    )
}

fun ByteArray.toHex(): String = joinToString(separator = "") { eachByte -> "%02x".format(eachByte) }

fun sha1(str: String): String = MessageDigest.getInstance("SHA-1").digest(str.toByteArray()).toHex()

fun parseCookieString(cookie: String): Map<String, String> =
    cookie.split("; ")
        .filter { it.isNotEmpty() }
        .mapNotNull { part ->
            val splitIndex = part.indexOf('=')
            if (splitIndex == -1) null
            else part.substring(0, splitIndex) to part.substring(splitIndex + 1)
        }
        .toMap()

fun String.parseTime(): Int? {
    try {
        // YouTube Music returns duration with locale-dependent separators
        // (":" en-US, "." some locales, "," EU). Accept all.
        val parts = split(Regex("[:.,]")).map { it.toInt() }
        if (parts.size == 2) {
            return parts[0] * 60 + parts[1]
        }
        if (parts.size == 3) {
            return parts[0] * 3600 + parts[1] * 60 + parts[2]
        }
    } catch (e: Exception) {
        return null
    }
    return null
}

fun isPrivateId(browseId: String): Boolean {
    return browseId.contains("privately")
}

// ----------------------------------------------------------------------------
// [UTILITIES, INTERCEPTORS & MODERATION] Source: utils/YouTubeUrlParser.kt
// ----------------------------------------------------------------------------

/**
 * Utility class for parsing YouTube and YouTube Music URLs.
 * Extracts video IDs, playlist IDs, and creates WatchEndpoints from URLs.
 */
object YouTubeUrlParser {
    /**
     * Represents the type of YouTube link parsed.
     */
    sealed class ParsedUrl {
        abstract val id: String

        data class Video(
            override val id: String,
        ) : ParsedUrl()

        data class Playlist(
            override val id: String,
        ) : ParsedUrl()

        data class Album(
            override val id: String,
        ) : ParsedUrl()

        data class Artist(
            override val id: String,
        ) : ParsedUrl()
    }

    /**
     * Pattern for matching YouTube video URLs.
     * Matches:
     * - https://www.youtube.com/watch?v=VIDEO_ID
     * - https://music.youtube.com/watch?v=VIDEO_ID
     * - https://youtu.be/VIDEO_ID
     * - https://www.youtube.com/shorts/VIDEO_ID
     */
    private val VIDEO_URL_PATTERNS =
        listOf(
            Regex("""(?:https?://)?(?:www\.)?(?:music\.)?youtube\.com/watch\?.*v=([a-zA-Z0-9_-]{11})"""),
            Regex("""(?:https?://)?(?:www\.)?(?:music\.)?youtube\.com/watch\?v=([a-zA-Z0-9_-]{11})"""),
            Regex("""(?:https?://)?youtu\.be/([a-zA-Z0-9_-]{11})"""),
            Regex("""(?:https?://)?(?:www\.)?youtube\.com/shorts/([a-zA-Z0-9_-]{11})"""),
        )

    /**
     * Pattern for matching YouTube playlist URLs.
     * Matches:
     * - https://www.youtube.com/playlist?list=PLAYLIST_ID
     * - https://music.youtube.com/playlist?list=PLAYLIST_ID
     */
    private val PLAYLIST_URL_PATTERN =
        Regex(
            """(?:https?://)?(?:www\.)?(?:music\.)?youtube\.com/playlist\?.*list=([a-zA-Z0-9_-]+)""",
        )

    /**
     * Pattern for matching YouTube Music album URLs.
     * Albums are essentially playlists with specific browse IDs.
     * Matches:
     * - https://music.youtube.com/playlist?list=PLAYLIST_ID
     */
    private val ALBUM_URL_PATTERN =
        Regex(
            """(?:https?://)?(?:www\.)?music\.youtube\.com/playlist\?.*list=([a-zA-Z0-9_-]+)""",
        )

    /**
     * Pattern for matching YouTube Music artist URLs.
     * Matches:
     * - https://music.youtube.com/channel/CHANNEL_ID
     * - https://music.youtube.com/browse/MPREb_... (artist browse ID)
     */
    private val ARTIST_URL_PATTERNS =
        listOf(
            Regex("""(?:https?://)?(?:www\.)?music\.youtube\.com/channel/([a-zA-Z0-9_-]+)"""),
            Regex("""(?:https?://)?(?:www\.)?music\.youtube\.com/browse/(MPRE[a-zA-Z0-9_-]+)"""),
        )

    /**
     * Checks if the given text is a YouTube URL.
     */
    fun isYouTubeUrl(text: String): Boolean = parse(text) != null

    /**
     * Parses a YouTube URL and returns the parsed result.
     *
     * @param url The URL to parse
     * @return ParsedUrl if valid, null otherwise
     */
    fun parse(url: String): ParsedUrl? {
        val trimmedUrl = url.trim()

        // Check for video URLs
        for (pattern in VIDEO_URL_PATTERNS) {
            pattern.find(trimmedUrl)?.let { matchResult ->
                matchResult.groupValues.getOrNull(1)?.let { videoId ->
                    return ParsedUrl.Video(videoId)
                }
            }
        }

        // Check for playlist URLs (non-music.youtube.com)
        if (!trimmedUrl.contains("music.youtube.com")) {
            PLAYLIST_URL_PATTERN.find(trimmedUrl)?.let { matchResult ->
                matchResult.groupValues.getOrNull(1)?.let { playlistId ->
                    return ParsedUrl.Playlist(playlistId)
                }
            }
        }

        // Check for album URLs (music.youtube.com playlists)
        if (trimmedUrl.contains("music.youtube.com")) {
            ALBUM_URL_PATTERN.find(trimmedUrl)?.let { matchResult ->
                matchResult.groupValues.getOrNull(1)?.let { playlistId ->
                    // Albums on YouTube Music use playlist URLs
                    // We'll treat them as albums and let the API determine the actual type
                    return ParsedUrl.Album(playlistId)
                }
            }

            // Check for artist URLs
            for (pattern in ARTIST_URL_PATTERNS) {
                pattern.find(trimmedUrl)?.let { matchResult ->
                    matchResult.groupValues.getOrNull(1)?.let { artistId ->
                        return ParsedUrl.Artist(artistId)
                    }
                }
            }
        }

        return null
    }

    /**
     * Extracts video ID from a YouTube URL.
     *
     * @param url The URL to parse
     * @return Video ID if found, null otherwise
     */
    fun extractVideoId(url: String): String? = (parse(url) as? ParsedUrl.Video)?.id

    /**
     * Extracts playlist ID from a YouTube URL.
     *
     * @param url The URL to parse
     * @return Playlist ID if found, null otherwise
     */
    fun extractPlaylistId(url: String): String? {
        val parsed = parse(url)
        return when (parsed) {
            is ParsedUrl.Playlist -> parsed.id
            is ParsedUrl.Album -> parsed.id
            else -> null
        }
    }

    /**
     * Creates a WatchEndpoint from a YouTube video URL.
     *
     * @param url The URL to parse
     * @return WatchEndpoint if valid video URL, null otherwise
     */
    fun createWatchEndpoint(url: String): WatchEndpoint? =
        extractVideoId(url)?.let { videoId ->
            WatchEndpoint(videoId = videoId)
        }
}

// ----------------------------------------------------------------------------
// [INNERTUBE CLIENT & YOUTUBE FACADE] Source: InnerTube.kt
// ----------------------------------------------------------------------------

/**
 * Provide access to InnerTube endpoints.
 * For making HTTP requests, not parsing response.
 */
@OptIn(ExperimentalEncodingApi::class)
class InnerTube {
    private var httpClient = createClient()

    private companion object {
        const val PLAYBACK_TELEMETRY_VER = "2"
    }

    var locale = YouTubeLocale(
        gl = Locale.getDefault().country,
        hl = Locale.getDefault().toLanguageTag()
    )
    var visitorData: String? = null
    var dataSyncId: String? = null
    var cookie: String? = null
        set(value) {
            field = value
            cookieMap = if (value == null) emptyMap() else parseCookieString(value)
        }
    private var cookieMap = emptyMap<String, String>()

    var proxy: Proxy? = null
        set(value) {
            field = value
            httpClient.close()
            httpClient = createClient()
        }
    
    var proxyAuth: String? = null

    var useLoginForBrowse: Boolean = false

    @OptIn(ExperimentalSerializationApi::class)
    private fun createClient() = HttpClient(OkHttp) {
        expectSuccess = true

        install(ContentNegotiation) {
            json(Json {
                ignoreUnknownKeys = true
                explicitNulls = false
                encodeDefaults = true
                isLenient = true
                coerceInputValues = true
            })
        }

        install(ContentEncoding) {
            gzip(0.9F)
            deflate(0.8F)
        }

        // Enhanced network configuration for better performance
        engine {
            config {
                // Connection pool settings for better connection reuse
                connectionPool(
                    okhttp3.ConnectionPool(
                        10, // maxIdleConnections
                        5, // keepAliveDuration
                        java.util.concurrent.TimeUnit.MINUTES
                    )
                )
                
                // Timeout configurations
                connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                readTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
                writeTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
                
                // Enable HTTP/2 for better performance
                protocols(listOf(okhttp3.Protocol.HTTP_2, okhttp3.Protocol.HTTP_1_1))
                
                // Retry on connection failure
                retryOnConnectionFailure(true)

                // Network Interceptor for Geolocation & Regulatory Compliance
                addInterceptor(com.listrovia.innertube.RegionalRestrictionInterceptor)
                
                // Cache configuration for better performance
                cache(
                    okhttp3.Cache(
                        directory = java.io.File(System.getProperty("java.io.tmpdir"), "http_cache"),
                        maxSize = 50L * 1024L * 1024L // 50 MB
                    )
                )

                // Add logging & health/structure mismatch tracking interceptor
                addInterceptor(com.listrovia.innertube.InnerTubeInterceptor())
                
                // Apply proxy configuration
                this@InnerTube.proxy?.let { proxyConfig ->
                    proxy(proxyConfig)
                }
                
                // Apply proxy authentication
                this@InnerTube.proxyAuth?.let { auth ->
                    proxyAuthenticator { _, response ->
                        response.request.newBuilder()
                            .header("Proxy-Authorization", auth)
                            .build()
                    }
                }
            }
        }

        // Request timeout configuration
        install(HttpTimeout) {
            requestTimeoutMillis = 60000
            connectTimeoutMillis = 30000
            socketTimeoutMillis = 60000
        }

        defaultRequest {
            url(YouTubeClient.API_URL_YOUTUBE_MUSIC)
            // Add common headers for better compatibility
            header("Accept", "application/json")
            header("Accept-Language", "en-US,en;q=0.9")
            header("Cache-Control", "no-cache")
        }
    }

    private fun HttpRequestBuilder.ytClient(
        client: YouTubeClient,
        setLogin: Boolean = false,
        useVisitorData: Boolean = true
    ) {
        contentType(ContentType.Application.Json)
        val isWebClient = client.clientName == "WEB_REMIX" ||
                          client.clientName == "WEB" ||
                          client.clientName == "WEB_CREATOR" ||
                          client.clientName.startsWith("TVHTML5") ||
                          client.clientName == "VISIONOS"

        val origin = if (client.clientName == "WEB_REMIX") YouTubeClient.ORIGIN_YOUTUBE_MUSIC else "https://www.youtube.com"
        val referer = if (client.clientName == "WEB_REMIX") YouTubeClient.REFERER_YOUTUBE_MUSIC else "https://www.youtube.com/"
        headers {
            append("X-Goog-Api-Format-Version", "1")
            append("X-YouTube-Client-Name", client.clientId /* Not a typo. The Client-Name header does contain the client id. */)
            append("X-YouTube-Client-Version", client.clientVersion)
            if (isWebClient) {
                append("X-Origin", origin)
                append("Referer", referer)
            }
            if (useVisitorData) {
                visitorData?.let { append("X-Goog-Visitor-Id", it) }
            }
            if (setLogin && client.loginSupported) {
                cookie?.let { cookie ->
                    append("cookie", cookie)
                    val cookieMap = parseCookieString(cookie)
                    if ("SAPISID" !in cookieMap) return@let
                    val currentTime = System.currentTimeMillis() / 1000
                    val sapisidHash = sha1("$currentTime ${cookieMap["SAPISID"]} $origin")
                    append("Authorization", "SAPISIDHASH ${currentTime}_${sapisidHash}")
                }
            }
        }
        userAgent(client.userAgent)
        parameter("prettyPrint", false)
    }

    /**
     * Simple retry wrapper for transient IO errors (socket aborts, timeouts).
     * Retries the given block up to [maxAttempts] times with exponential backoff.
     * Cancellation is respected since [delay] will throw if the coroutine is cancelled.
     */
    private suspend fun <T> withRetry(
        maxAttempts: Int = 3,
        initialDelay: Long = 500L,
        factor: Double = 2.0,
        block: suspend () -> T,
    ): T {
        var currentDelay = initialDelay
        var attempt = 0
        while (true) {
            try {
                return block()
            } catch (e: java.util.concurrent.CancellationException) {
                throw e
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: IOException) {
                attempt++
                if (attempt >= maxAttempts) throw e
                delay(currentDelay)
                currentDelay = (currentDelay * factor).toLong()
            }
        }
    }

    suspend fun search(
        client: YouTubeClient,
        query: String? = null,
        params: String? = null,
        continuation: String? = null,
    ) = withRetry {
        httpClient.post("search") {
            ytClient(client, setLogin = false)
            setBody(
                SearchBody(
                    context = client.toContext(
                        locale,
                        visitorData,
                        null
                    ),
                    query = query,
                    params = params
                )
            )
            parameter("continuation", continuation)
            parameter("ctoken", continuation)
        }
    }

    suspend fun player(
        client: YouTubeClient,
        videoId: String,
        playlistId: String?,
        signatureTimestamp: Int?,
        poToken: String? = null,
        useVisitorData: Boolean = true,
    ) = withRetry {
        httpClient.post("player") {
            ytClient(client, setLogin = useVisitorData, useVisitorData = useVisitorData)
            setBody(
                PlayerBody(
                    context = client.toContext(locale, if (useVisitorData) visitorData else null, dataSyncId).let {
                        if (client.isEmbedded) {
                            it.copy(
                                thirdParty = Context.ThirdParty(
                                    embedUrl = "https://www.youtube.com/embed/${videoId}"
                                )
                            )
                        } else it
                    },
                    videoId = videoId,
                    playlistId = playlistId,
                    playbackContext = if (client.useSignatureTimestamp && signatureTimestamp != null) {
                        PlayerBody.PlaybackContext(
                            PlayerBody.PlaybackContext.ContentPlaybackContext(
                                signatureTimestamp
                            )
                        )
                    } else null,
                    serviceIntegrityDimensions = if (client.useWebPoTokens && poToken != null) {
                        PlayerBody.ServiceIntegrityDimensions(poToken)
                    } else null,
                )
            )
        }
    }

    suspend fun registerPlayback(
        url: String,
        cpn: String,
        playlistId: String?,
        client: YouTubeClient = YouTubeClient.WEB_REMIX,
    ) = withRetry {
        httpClient.get(url) {
            ytClient(client, true)
            parameter("c", client.clientName)
            parameter("cpn", cpn)
            parameter("ver", PLAYBACK_TELEMETRY_VER)

            if (playlistId != null) {
                parameter("list", playlistId)
                parameter("referrer", "https://music.youtube.com/playlist?list=$playlistId")
            }
        }
    }

    suspend fun browse(
        client: YouTubeClient,
        browseId: String? = null,
        params: String? = null,
        continuation: String? = null,
        setLogin: Boolean = false,
    ) = withRetry {
        httpClient.post("browse") {
            ytClient(client, setLogin = setLogin || useLoginForBrowse)
            setBody(
                BrowseBody(
                    context = client.toContext(
                        locale,
                        visitorData,
                        if (setLogin || useLoginForBrowse) dataSyncId else null
                    ),
                    browseId = browseId,
                    params = params,
                    continuation = continuation
                )
            )
        }
    }

    suspend fun next(
        client: YouTubeClient,
        videoId: String? = null,
        playlistId: String? = null,
        playlistSetVideoId: String? = null,
        index: Int? = null,
        params: String? = null,
        continuation: String? = null,
    ) = withRetry {
        httpClient.post("next") {
            ytClient(client, setLogin = true)
            setBody(
                NextBody(
                    context = client.toContext(locale, visitorData, dataSyncId),
                    videoId = videoId,
                    playlistId = playlistId,
                    playlistSetVideoId = playlistSetVideoId,
                    index = index,
                    params = params,
                    continuation = continuation
                )
            )
        }
    }

    suspend fun feedback(
        client: YouTubeClient,
        tokens: List<String>
    ) = withRetry {
        httpClient.post("feedback") {
            ytClient(client, setLogin = true)
            setBody(
                FeedbackBody(
                    context = client.toContext(locale, visitorData, dataSyncId),
                    feedbackTokens = tokens
                )
            )
        }
    }

    suspend fun getSearchSuggestions(
        client: YouTubeClient,
        input: String,
    ) = withRetry {
        httpClient.post("music/get_search_suggestions") {
            ytClient(client)
            setBody(
                GetSearchSuggestionsBody(
                    context = client.toContext(locale, visitorData, null),
                    input = input
                )
            )
        }
    }

    suspend fun getQueue(
        client: YouTubeClient,
        videoIds: List<String>?,
        playlistId: String?,
    ) = withRetry {
        httpClient.post("music/get_queue") {
            ytClient(client)
            setBody(
                GetQueueBody(
                    context = client.toContext(locale, visitorData, null),
                    videoIds = videoIds,
                    playlistId = playlistId
                )
            )
        }
    }

    suspend fun getTranscript(
        client: YouTubeClient,
        videoId: String,
    ) = withRetry {
        httpClient.post("https://music.youtube.com/youtubei/v1/get_transcript") {
            parameter("key", "AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX3")
            headers {
                append("Content-Type", "application/json")
            }
            setBody(
                GetTranscriptBody(
                    context = client.toContext(locale, null, null),
                    params = Base64.Default.encode(
                        "\n${11.toChar()}$videoId".encodeToByteArray()
                    )
                )
            )
        }
    }

    suspend fun getSwJsData() = withRetry { httpClient.get("https://music.youtube.com/sw.js_data") }

    suspend fun accountMenu(client: YouTubeClient) = withRetry {
        httpClient.post("account/account_menu") {
            ytClient(client, setLogin = true)
            setBody(AccountMenuBody(client.toContext(locale, visitorData, dataSyncId)))
        }
    }

    suspend fun likeVideo(
        client: YouTubeClient,
        videoId: String,
    ) = withRetry {
        httpClient.post("like/like") {
            ytClient(client, setLogin = true)
            setBody(
                LikeBody(
                    context = client.toContext(locale, visitorData, dataSyncId),
                    target = LikeBody.Target.video(videoId)
                )
            )
        }
    }

    suspend fun unlikeVideo(
        client: YouTubeClient,
        videoId: String,
    ) = withRetry {
        httpClient.post("like/removelike") {
            ytClient(client, setLogin = true)
            setBody(
                LikeBody(
                    context = client.toContext(locale, visitorData, dataSyncId),
                    target = LikeBody.Target.video(videoId)
                )
            )
        }
    }

    suspend fun subscribeChannel(
        client: YouTubeClient,
        channelId: String,
        params: String? = null,
    ) = withRetry {
        httpClient.post("subscription/subscribe") {
            ytClient(client, setLogin = true)
            setBody(
                SubscribeBody(
                    context = client.toContext(locale, visitorData, dataSyncId),
                    channelIds = listOf(channelId),
                    params = params
                )
            )
        }
    }

    suspend fun unsubscribeChannel(
        client: YouTubeClient,
        channelId: String,
        params: String? = null,
    ) = withRetry {
        httpClient.post("subscription/unsubscribe") {
            ytClient(client, setLogin = true)
            setBody(
                SubscribeBody(
                    context = client.toContext(locale, visitorData, dataSyncId),
                    channelIds = listOf(channelId),
                    params = params
                )
            )
        }
    }

    suspend fun likePlaylist(
        client: YouTubeClient,
        playlistId: String,
    ) = withRetry {
        httpClient.post("like/like") {
            ytClient(client, setLogin = true)
            setBody(
                LikeBody(
                    context = client.toContext(locale, visitorData, dataSyncId),
                    target = LikeBody.Target.playlist(playlistId)
                )
            )
        }
    }

    suspend fun unlikePlaylist(
        client: YouTubeClient,
        playlistId: String,
    ) = withRetry {
        httpClient.post("like/removelike") {
            ytClient(client, setLogin = true)
            setBody(
                LikeBody(
                    context = client.toContext(locale, visitorData, dataSyncId),
                    target = LikeBody.Target.playlist(playlistId)
                )
            )
        }
    }

    suspend fun addToPlaylist(
        client: YouTubeClient,
        playlistId: String,
        videoId: String,
    ) = withRetry {
        httpClient.post("browse/edit_playlist") {
            ytClient(client, setLogin = true)
            setBody(
                EditPlaylistBody(
                    context = client.toContext(locale, visitorData, dataSyncId),
                    playlistId = playlistId.removePrefix("VL"),
                    actions = listOf(
                        Action.AddVideoAction(addedVideoId = videoId)
                    )
                )
            )
        }
    }

    suspend fun addPlaylistToPlaylist(
        client: YouTubeClient,
        playlistId: String,
        addPlaylistId: String,
    ) = withRetry {
        httpClient.post("browse/edit_playlist") {
            ytClient(client, setLogin = true)
            setBody(
                EditPlaylistBody(
                    context = client.toContext(locale, visitorData, dataSyncId),
                    playlistId = playlistId.removePrefix("VL"),
                    actions = listOf(
                        Action.AddPlaylistAction(addedFullListId = addPlaylistId)
                    )
                )
            )
        }
    }

    suspend fun removeFromPlaylist(
        client: YouTubeClient,
        playlistId: String,
        videoId: String,
        setVideoId: String,
    ) = withRetry {
        httpClient.post("browse/edit_playlist") {
            ytClient(client, setLogin = true)
            setBody(
                EditPlaylistBody(
                    context = client.toContext(locale, visitorData, dataSyncId),
                    playlistId = playlistId.removePrefix("VL"),
                    actions = listOf(
                        Action.RemoveVideoAction(
                            removedVideoId = videoId,
                            setVideoId = setVideoId,
                        )
                    )
                )
            )
        }
    }

    suspend fun moveSongPlaylist(
        client: YouTubeClient,
        playlistId: String,
        setVideoId: String,
        successorSetVideoId: String?,
    ) = withRetry {
        httpClient.post("browse/edit_playlist") {
            ytClient(client, setLogin = true)
            setBody(
                EditPlaylistBody(
                    context = client.toContext(locale, visitorData, dataSyncId),
                    playlistId = playlistId,
                    actions = listOf(
                        Action.MoveVideoAction(
                            movedSetVideoIdSuccessor = successorSetVideoId,
                            setVideoId = setVideoId,
                        )
                    )
                )
            )
        }
    }

    suspend fun createPlaylist(
        client: YouTubeClient,
        title: String,
    ) = withRetry {
        httpClient.post("playlist/create") {
            ytClient(client, true)
            setBody(
                CreatePlaylistBody(
                    context = client.toContext(locale, visitorData, dataSyncId),
                    title = title
                )
            )
        }
    }

    suspend fun renamePlaylist(
        client: YouTubeClient,
        playlistId: String,
        name: String,
    ) = withRetry {
        httpClient.post("browse/edit_playlist") {
            ytClient(client, setLogin = true)
            setBody(
                EditPlaylistBody(
                    context = client.toContext(locale, visitorData, dataSyncId),
                    playlistId = playlistId,
                    actions = listOf(
                        Action.RenamePlaylistAction(
                            playlistName = name
                        )
                    )
                )
            )
        }
    }
    
    suspend fun getUploadCustomThumbnailLink(
        client: YouTubeClient,
        contentLength: Int
    ) = withRetry {
        httpClient.post("https://music.youtube.com/playlist_image_upload/playlist_custom_thumbnail") {
            ytClient(client, setLogin = true)
            headers {
                append("X-Goog-Upload-Command", "start")
                append("X-Goog-Upload-Protocol", "resumable")
                append("X-Goog-Upload-Header-Content-Length", contentLength.toString())
            }
        }
    }

    suspend fun uploadCustomThumbnail(
        client: YouTubeClient,
        uploadId: String,
        image: ByteArray,
    ) = withRetry {
        httpClient.post("https://music.youtube.com/playlist_image_upload/playlist_custom_thumbnail") {
            ytClient(client, setLogin = true)
            parameter("upload_id", uploadId)
            parameter("upload_protocol", "resumable")
            headers {
                append("X-Goog-Upload-Command", "upload, finalize")
                append("X-Goog-Upload-Offset", "0")
            }
            setBody(image)
        }
    }

    suspend fun setThumbnailPlaylist(
        client: YouTubeClient,
        playlistId: String,
        blobId: String,
    ) = withRetry {
        httpClient.post("browse/edit_playlist") {
            ytClient(client, setLogin = true)
            setBody(
                EditPlaylistBody(
                    context = client.toContext(locale, visitorData, dataSyncId),
                    playlistId = playlistId,
                    actions = listOf(
                        Action.SetCustomThumbnailAction(
                            addedCustomThumbnail = Action.SetCustomThumbnailAction.AddedCustomThumbnail(
                                playlistScottyEncryptedBlobId = blobId
                            )
                        )
                    )
                )
            )
        }
    }

    suspend fun removeThumbnailPlaylist(
        client: YouTubeClient,
        playlistId: String
    ) = withRetry {
        httpClient.post("browse/edit_playlist") {
            ytClient(client, setLogin = true)
            setBody(
                EditPlaylistBody(
                    context = client.toContext(locale, visitorData, dataSyncId),
                    playlistId = playlistId,
                    actions = listOf(
                        Action.RemoveCustomThumbnailAction()
                    )
                )
            )
        }
    }

    suspend fun deletePlaylist(
        client: YouTubeClient,
        playlistId: String,
    ) = withRetry {
        httpClient.post("playlist/delete") {
            println("deleting $playlistId")
            ytClient(client, setLogin = true)
            setBody(
                PlaylistDeleteBody(
                    context = client.toContext(locale, visitorData, dataSyncId),
                    playlistId = playlistId
                )
            )
        }
    }

    private suspend fun returnYouTubeDislike(videoId: String) = withRetry {
        httpClient.get("https://returnyoutubedislikeapi.com/Votes?videoId=$videoId") {
            contentType(ContentType.Application.Json)
        }
    }


    /**
     * Initialize a song upload to YouTube Music.
     * Returns the upload URL in the X-Goog-Upload-URL header.
     */
    suspend fun initSongUpload(
        filename: String,
        contentLength: Long
    ) = withRetry {
        val authUser = "0"
        httpClient.post("https://upload.youtube.com/upload/usermusic/http?authuser=$authUser") {
            headers {
                append("X-Goog-Upload-Command", "start")
                append("X-Goog-Upload-Protocol", "resumable")
                append("X-Goog-Upload-Header-Content-Length", contentLength.toString())
                append("X-Goog-AuthUser", authUser)
                append("Origin", YouTubeClient.ORIGIN_YOUTUBE_MUSIC)
                cookie?.let { cookie ->
                    append("cookie", cookie)
                    if ("SAPISID" !in cookieMap) return@let
                    val currentTime = System.currentTimeMillis() / 1000
                    val sapisidHash = sha1("$currentTime ${cookieMap["SAPISID"]} ${YouTubeClient.ORIGIN_YOUTUBE_MUSIC}")
                    append("Authorization", "SAPISIDHASH ${currentTime}_${sapisidHash}")
                }
            }
            contentType(ContentType.Application.FormUrlEncoded)
            setBody("filename=$filename")
        }
    }

    /**
     * Upload song data to the provided upload URL.
     */
    suspend fun uploadSongData(
        uploadUrl: String,
        data: ByteArray,
        onProgress: ((Float) -> Unit)? = null
    ) = withRetry {
        httpClient.post(uploadUrl) {
            headers {
                append("X-Goog-Upload-Command", "upload, finalize")
                append("X-Goog-Upload-Offset", "0")
                append("X-Goog-AuthUser", "0")
                append("Origin", YouTubeClient.ORIGIN_YOUTUBE_MUSIC)
                cookie?.let { cookie ->
                    append("cookie", cookie)
                    if ("SAPISID" !in cookieMap) return@let
                    val currentTime = System.currentTimeMillis() / 1000
                    val sapisidHash = sha1("$currentTime ${cookieMap["SAPISID"]} ${YouTubeClient.ORIGIN_YOUTUBE_MUSIC}")
                    append("Authorization", "SAPISIDHASH ${currentTime}_${sapisidHash}")
                }
            }
            contentType(ContentType.Application.OctetStream)
            setBody(data)
            onUpload { bytesSentTotal, contentLength ->
                contentLength?.let {
                    onProgress?.invoke(bytesSentTotal.toFloat() / it.toFloat())
                }
            }
        }
    }

    /**
     * Delete a privately owned (uploaded) song from YouTube Music.
     */
    suspend fun deletePrivatelyOwnedEntity(entityId: String) = withRetry {
        val context = YouTubeClient.WEB_REMIX.toContext(locale, visitorData, null)
        val requestBody = """{"context":${Json.encodeToString(context)},"entityId":"$entityId"}"""
        httpClient.post("https://music.youtube.com/youtubei/v1/music/delete_privately_owned_entity") {
            contentType(ContentType.Application.Json)
            headers {
                append("Referer", YouTubeClient.REFERER_YOUTUBE_MUSIC)
                append("Origin", YouTubeClient.ORIGIN_YOUTUBE_MUSIC)
                cookie?.let { cookie ->
                    append("cookie", cookie)
                    if ("SAPISID" !in cookieMap) return@let
                    val currentTime = System.currentTimeMillis() / 1000
                    val sapisidHash = sha1("$currentTime ${cookieMap["SAPISID"]} ${YouTubeClient.ORIGIN_YOUTUBE_MUSIC}")
                    append("Authorization", "SAPISIDHASH ${currentTime}_${sapisidHash}")
                }
            }
            parameter("key", "AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX3")
            parameter("prettyPrint", false)
            setBody(requestBody)
        }
    }

    suspend fun getMediaInfo(videoId: String): Result<MediaInfo> =
        runCatching {
            val response = next(client = YouTubeClient.WEB, videoId, null, null, null, null, null).body<NextResponse>()

            val baseForInfo =
                response.contents.twoColumnWatchNextResults
                    ?.results
                    ?.results
                    ?.content
                    ?.find {
                        it?.videoSecondaryInfoRenderer != null
                    }?.videoSecondaryInfoRenderer

            val baseForTitle =
                response.contents.twoColumnWatchNextResults
                    ?.results
                    ?.results
                    ?.content
                    ?.find {
                        it?.videoPrimaryInfoRenderer != null
                    }?.videoPrimaryInfoRenderer

            val returnYouTubeDislikeResponse = runCatching {
                returnYouTubeDislike(videoId).body<ReturnYouTubeDislikeResponse>()
            }.getOrNull()

            return@runCatching MediaInfo(
                videoId = videoId,
                title = baseForTitle
                    ?.title
                    ?.runs
                    ?.firstOrNull()
                    ?.text,
                author = baseForInfo
                    ?.owner
                    ?.videoOwnerRenderer
                    ?.title
                    ?.runs
                    ?.firstOrNull()
                    ?.text,
                authorId =
                    baseForInfo
                        ?.owner
                        ?.videoOwnerRenderer
                        ?.navigationEndpoint
                        ?.browseEndpoint
                        ?.browseId,
                authorThumbnail =
                    baseForInfo
                        ?.owner
                        ?.videoOwnerRenderer
                        ?.thumbnail
                        ?.thumbnails
                        ?.find {
                            it.height == 48
                        }?.url
                        ?.replace("s48", "s960"),
                description = baseForInfo?.attributedDescription?.content,
                subscribers =
                    baseForInfo
                        ?.owner
                        ?.videoOwnerRenderer
                        ?.subscriberCountText
                        ?.simpleText?.split(" ")?.firstOrNull(),
                uploadDate = baseForTitle?.dateText?.simpleText,
                viewCount = returnYouTubeDislikeResponse?.viewCount,
                like = returnYouTubeDislikeResponse?.likes,
                dislike = returnYouTubeDislikeResponse?.dislikes,
            )

        }


}

// ----------------------------------------------------------------------------
// [INNERTUBE CLIENT & YOUTUBE FACADE] Source: YouTube.kt
// ----------------------------------------------------------------------------

/**
 * Parse useful data with [InnerTube] sending requests.
 * Modified from [ViMusic](https://github.com/vfsfitvnm/ViMusic)
 */
object YouTube {
    private val innerTube = InnerTube()
    private const val ENABLE_NEWPIPE_STREAM_INFO_EXTRACTOR = false

    var locale: YouTubeLocale
        get() = innerTube.locale
        set(value) {
            innerTube.locale = value
        }
    var visitorData: String?
        get() = innerTube.visitorData
        set(value) {
            innerTube.visitorData = value
        }
    var dataSyncId: String?
        get() = innerTube.dataSyncId
        set(value) {
            innerTube.dataSyncId = value
        }
    var cookie: String?
        get() = innerTube.cookie
        set(value) {
            innerTube.cookie = value
        }
    var proxy: Proxy?
        get() = innerTube.proxy
        set(value) {
            innerTube.proxy = value
        }

    var proxyAuth: String?
        get() = innerTube.proxyAuth
        set(value) {
            innerTube.proxyAuth = value
        }
    var useLoginForBrowse: Boolean
        get() = innerTube.useLoginForBrowse
        set(value) {
            innerTube.useLoginForBrowse = value
        }

    suspend fun searchSuggestions(query: String): Result<SearchSuggestions> =
        runCatching {
            val rawResponse = innerTube.getSearchSuggestions(WEB_REMIX, query).body<GetSearchSuggestionsResponse>()
            val response = com.listrovia.innertube.InnerTubeStreamFilterLayer.pruneSearchSuggestionsResponse(rawResponse)
            SearchSuggestions(
                queries =
                    response.contents
                        ?.getOrNull(0)
                        ?.searchSuggestionsSectionRenderer
                        ?.contents
                        ?.mapNotNull { content ->
                            content.searchSuggestionRenderer
                                ?.suggestion
                                ?.runs
                                ?.joinToString(separator = "") { it.text }
                        }
                        ?.filter { com.listrovia.innertube.SongContentModerator.isSearchAllowed(it) }
                        .orEmpty(),
                recommendedItems =
                    response.contents
                        ?.getOrNull(1)
                        ?.searchSuggestionsSectionRenderer
                        ?.contents
                        ?.mapNotNull {
                            it.musicResponsiveListItemRenderer?.let { renderer ->
                                SearchSuggestionPage.fromMusicResponsiveListItemRenderer(renderer)
                            }
                        }
                        ?.filter { com.listrovia.innertube.SongContentModerator.isItemAllowed(it) }
                        .orEmpty(),
            )
        }

    suspend fun searchSummary(query: String): Result<SearchSummaryPage> =
        runCatching {
            val rawResponse = innerTube.search(WEB_REMIX, query).body<SearchResponse>()
            val response = com.listrovia.innertube.InnerTubeStreamFilterLayer.pruneSearchResponse(rawResponse)
            val allSummaries = mutableListOf<SearchSummary>()

            response.contents
                ?.tabbedSearchResultsRenderer
                ?.tabs
                ?.firstOrNull()
                ?.tabRenderer
                ?.content
                ?.sectionListRenderer
                ?.contents
                ?.forEach { section ->
                    if (section.musicCardShelfRenderer != null) {
                        // Top result card - keep as single section
                        val items =
                            listOfNotNull(SearchSummaryPage.fromMusicCardShelfRenderer(section.musicCardShelfRenderer))
                                .plus(
                                    section.musicCardShelfRenderer.contents
                                        ?.mapNotNull { it.musicResponsiveListItemRenderer }
                                        ?.mapNotNull(SearchSummaryPage.Companion::fromMusicResponsiveListItemRenderer)
                                        .orEmpty(),
                                ).distinctBy { it.id }

                        if (items.isNotEmpty()) {
                            allSummaries.add(
                                SearchSummary(
                                    title =
                                        section.musicCardShelfRenderer.header
                                            ?.musicCardShelfHeaderBasicRenderer
                                            ?.title
                                            ?.runs
                                            ?.firstOrNull()
                                            ?.text
                                            ?: YouTubeConstants.DEFAULT_TOP_RESULT,
                                    items = items,
                                ),
                            )
                        }
                    } else if (section.musicShelfRenderer != null) {
                        val items =
                            section.musicShelfRenderer.contents
                                ?.getItems()
                                ?.mapNotNull { SearchSummaryPage.fromMusicResponsiveListItemRenderer(it) }
                                ?.distinctBy { it.id }
                                ?: emptyList()

                        if (items.isEmpty()) return@forEach

                        val apiTitle =
                            section.musicShelfRenderer.title
                                ?.runs
                                ?.firstOrNull()
                                ?.text

                        if (apiTitle != null) {
                            // API provided a title, use single section
                            allSummaries.add(SearchSummary(title = apiTitle, items = items))
                        } else {
                            allSummaries.addAll(groupItemsByType(items))
                        }
                    } else if (section.itemSectionRenderer != null) {
                        val items =
                            section.itemSectionRenderer.contents
                                ?.mapNotNull { it.musicResponsiveListItemRenderer }
                                ?.mapNotNull { SearchSummaryPage.fromMusicResponsiveListItemRenderer(it) }
                                ?.distinctBy { it.id }
                                ?: emptyList()

                        if (items.isNotEmpty()) {
                            allSummaries.addAll(groupItemsByType(items))
                        }
                    }
                }

            // Merge sections with the same title
            val mergedSummaries =
                allSummaries
                    .groupBy { it.title }
                    .map { (title, sections) ->
                        SearchSummary(
                            title = title,
                            items = sections.flatMap { it.items }
                                .filter { com.listrovia.innertube.SongContentModerator.isItemAllowed(it) }
                                .distinctBy { it.id },
                        )
                    }
                    .filter { it.items.isNotEmpty() }
                    // Reorder to maintain logical order
                    .sortedBy { summary ->
                        when (summary.title) {
                            YouTubeConstants.DEFAULT_TOP_RESULT -> 0
                            "Songs" -> 1
                            "Videos" -> 2
                            "Albums" -> 3
                            "Artists" -> 4
                            "Playlists" -> 5
                            "Podcasts" -> 6
                            "Episodes" -> 7
                            "Profiles" -> 8
                            else -> 9
                        }
                    }

            SearchSummaryPage(summaries = mergedSummaries)
        }

    private fun groupItemsByType(items: List<YTItem>): List<SearchSummary> {
        val grouped =
            items.groupBy { item ->
                when (item) {
                    is EpisodeItem -> "Episodes"
                    is PodcastItem -> "Podcasts"
                    is AlbumItem -> "Albums"
                    is ArtistItem -> if (item.isProfile) "Profiles" else "Artists"
                    is PlaylistItem -> "Playlists"
                    is SongItem -> when {
                        item.isEpisode -> "Episodes"
                        item.isVideoSong -> "Videos"
                        else -> "Songs"
                    }
                }
            }

        val sectionOrder =
            listOf(
                "Songs", "Videos", "Albums", "Artists", "Playlists",
                "Podcasts", "Episodes", "Profiles", YouTubeConstants.DEFAULT_OTHER_RESULTS,
            )

        return sectionOrder.mapNotNull { sectionName ->
            grouped[sectionName]?.takeIf { it.isNotEmpty() }?.let { groupItems ->
                SearchSummary(title = sectionName, items = groupItems)
            }
        }
    }

    suspend fun search(
        query: String,
        filter: SearchFilter,
    ): Result<SearchResult> =
        runCatching {
            val rawResponse = innerTube.search(WEB_REMIX, query, filter.value).body<SearchResponse>()
            val response = com.listrovia.innertube.InnerTubeStreamFilterLayer.pruneSearchResponse(rawResponse)
            val searchItems = mutableListOf<YTItem>()
            var searchContinuation: String? = null

            response.contents
                ?.tabbedSearchResultsRenderer
                ?.tabs
                ?.firstOrNull()
                ?.tabRenderer
                ?.content
                ?.sectionListRenderer
                ?.contents
                ?.forEach { section ->
                    if (section.musicShelfRenderer != null) {
                        val shelf = section.musicShelfRenderer
                        val items = shelf.contents?.getItems()?.mapNotNull { SearchPage.toYTItem(it) } ?: emptyList()
                        searchItems.addAll(items)
                        if (searchContinuation == null) {
                            searchContinuation = shelf.continuations?.getContinuation()
                        }
                    } else if (section.itemSectionRenderer != null) {
                        val items =
                            section.itemSectionRenderer.contents
                                ?.mapNotNull { it.musicResponsiveListItemRenderer }
                                ?.mapNotNull { SearchPage.toYTItem(it) }
                                ?: emptyList()
                        searchItems.addAll(items)
                    }
                }

            SearchResult(
                items = searchItems.filter { com.listrovia.innertube.SongContentModerator.isItemAllowed(it) }.distinctBy { it.id },
                continuation = searchContinuation,
            )
        }

    suspend fun searchContinuation(continuation: String): Result<SearchResult> =
        runCatching {
            val rawResponse = innerTube.search(WEB_REMIX, continuation = continuation).body<SearchResponse>()
            val response = com.listrovia.innertube.InnerTubeStreamFilterLayer.pruneSearchResponse(rawResponse)
            val items =
                response.continuationContents
                    ?.musicShelfContinuation
                    ?.contents
                    ?.mapNotNull {
                        SearchPage.toYTItem(it.musicResponsiveListItemRenderer)
                    }
                    ?.filter { com.listrovia.innertube.SongContentModerator.isItemAllowed(it) }
                    ?: emptyList()
            SearchResult(
                items = items,
                continuation =
                    if (items.isEmpty()) {
                        null
                    } else {
                        response.continuationContents
                            ?.musicShelfContinuation
                            ?.continuations
                            ?.getContinuation()
                    },
            )
        }

    suspend fun youtubeHomeFeed(continuation: String? = null): Result<VideoFeedResult> =
        runCatching {
            val response = innerTube.browse(YouTubeClient.WEB, browseId = "FEwhat_to_watch", continuation = continuation).body<JsonObject>()
            VideoFeedPage.fromJson(response)
        }

    suspend fun youtubeTrending(continuation: String? = null): Result<VideoFeedResult> =
        runCatching {
            val response = innerTube.browse(YouTubeClient.WEB, browseId = "FEtrending", continuation = continuation).body<JsonObject>()
            VideoFeedPage.fromJson(response)
        }

    suspend fun youtubeCategoryFeed(query: String, continuation: String? = null): Result<VideoFeedResult> =
        runCatching {
            val response = innerTube.search(YouTubeClient.WEB, query = query, continuation = continuation).body<JsonObject>()
            VideoFeedPage.parseSearch(response)
        }

    suspend fun youtubeNewFeed(query: String, continuation: String? = null): Result<VideoFeedResult> =
        runCatching {
            val response = innerTube.search(YouTubeClient.WEB, query = query, continuation = continuation).body<JsonObject>()
            VideoFeedPage.parseSearch(response)
        }

    suspend fun youtubeSearchFeed(query: String, continuation: String? = null): Result<VideoFeedResult> =
        runCatching {
            val response = innerTube.search(YouTubeClient.WEB, query = query, continuation = continuation).body<JsonObject>()
            VideoFeedPage.parseSearch(response)
        }

    suspend fun youtubeSearch(
        query: String,
        filter: String? = null,
        duration: String? = null,
        time: String? = null,
        sort: String? = null,
        params: String? = null,
        continuation: String? = null
    ): Result<VideoFeedResult> =
        runCatching {
            val response = innerTube.search(YouTubeClient.WEB, query = query, params = params ?: filter ?: duration ?: time ?: sort, continuation = continuation).body<JsonObject>()
            VideoFeedPage.parseSearch(response)
        }

    fun combineSearchParams(
        filter: String? = null,
        duration: String? = null,
        time: String? = null,
        sort: String? = null
    ): String? {
        // This is a placeholder for actual param combining logic
        return filter ?: duration ?: time ?: sort
    }



    suspend fun subscribeChannel(channelId: String, subscribe: Boolean): Result<Unit> =
        runCatching {
            // Placeholder for subscription logic
        }

    suspend fun youtubeChannel(channelId: String, params: String? = null): Result<YouTubeChannelPage> =
        runCatching {
             val response = innerTube.browse(YouTubeClient.WEB, browseId = channelId, params = params).body<JsonObject>()
             // Simplified: Just returning basic info
             YouTubeChannelPage(
                 channelId = channelId,
                 title = "Channel",
                 videos = VideoFeedPage.fromJson(response).items.filterIsInstance<YouTubeSearchResultItem.Video>().map { it.item }
             )
        }

    suspend fun youtubeChannelPosts(channelId: String, continuation: String? = null): Result<List<YouTubeChannelPost>> =
        runCatching {
            emptyList() // Simplified
        }

    suspend fun youtubeSearchContinuation(query: String? = null, continuation: String): Result<VideoFeedResult> =
        runCatching {
             val response = innerTube.search(YouTubeClient.WEB, query = query, continuation = continuation).body<JsonObject>()
             VideoFeedPage.parseSearch(response)
        }

    suspend fun youtubeChannelContinuation(channelId: String, continuation: String): Result<VideoFeedResult> =
        runCatching {
            val response = innerTube.browse(YouTubeClient.WEB, continuation = continuation).body<JsonObject>()
            VideoFeedPage.fromJson(response)
        }


    suspend fun watchMetadata(videoId: String): Result<WatchMetadataResponse> =
        runCatching {
            val response = innerTube.next(YouTubeClient.WEB, videoId = videoId).body<JsonObject>()
            VideoFeedPage.parseWatchMetadata(response)
        }

    suspend fun watchMetadataRelatedContinuation(videoId: String, continuation: String): Result<Pair<List<YouTubeVideoItem>, String?>> =
        runCatching {
            val response = innerTube.next(YouTubeClient.WEB, videoId = videoId, continuation = continuation).body<JsonObject>()
            val result = VideoFeedPage.parseWatchNextContinuation(response)
            result.items.filterIsInstance<YouTubeSearchResultItem.Video>().map { it.item } to result.continuation
        }

    suspend fun videoComments(videoId: String): Result<List<YoutubeComment>> =
        runCatching {
             val response = innerTube.next(YouTubeClient.WEB, videoId = videoId).body<JsonObject>()
             VideoFeedPage.parseWatchMetadata(response).comments
        }

    suspend fun videoCommentsContinuation(videoId: String, continuation: String): Result<VideoFeedResult> =
        runCatching {
             val response = innerTube.next(YouTubeClient.WEB, videoId = videoId, continuation = continuation).body<JsonObject>()
             VideoFeedPage.parseWatchNextContinuation(response)
        }

    suspend fun album(
        browseId: String,
        withSongs: Boolean = true,
    ): Result<AlbumPage> =
        runCatching {
            val response = innerTube.browse(WEB_REMIX, browseId).body<BrowseResponse>()
            if (browseId.contains("FEmusic_library_privately_owned_release_detail")) {
                val playlistId =
                    response.header
                        ?.musicDetailHeaderRenderer
                        ?.menu
                        ?.menuRenderer
                        ?.topLevelButtons
                        ?.firstOrNull()
                        ?.buttonRenderer
                        ?.navigationEndpoint
                        ?.watchPlaylistEndpoint
                        ?.playlistId!!
                val albumItem =
                    AlbumItem(
                        browseId = browseId,
                        playlistId = playlistId,
                        title =
                            response.header.musicDetailHeaderRenderer.title.runs
                                ?.firstOrNull()
                                ?.text!!,
                        artists =
                            response.header.musicDetailHeaderRenderer.subtitle.runs?.filter { it.navigationEndpoint != null }?.map {
                                Artist(
                                    name = it.text,
                                    id = it.navigationEndpoint?.browseEndpoint?.browseId,
                                )
                            },
                        year =
                            response.header.musicDetailHeaderRenderer.subtitle.runs
                                ?.lastOrNull()
                                ?.text
                                ?.toIntOrNull(),
                        thumbnail =
                            response.header.musicDetailHeaderRenderer.thumbnail.croppedSquareThumbnailRenderer
                                ?.thumbnail
                                ?.thumbnails
                                ?.lastOrNull()!!
                                .url,
                        explicit = false, // TODO: Extract explicit badge for albums from YouTube response
                    )
                return@runCatching AlbumPage(
                    album = albumItem,
                    songs =
                        response.contents
                            ?.singleColumnBrowseResultsRenderer
                            ?.tabs
                            ?.firstOrNull()
                            ?.tabRenderer
                            ?.content
                            ?.sectionListRenderer
                            ?.contents
                            ?.firstOrNull()
                            ?.musicShelfRenderer
                            ?.contents
                            ?.getItems()
                            ?.mapNotNull {
                                AlbumPage.getSong(it, albumItem)
                            }!!
                            .toMutableList(),
                    otherVersions = emptyList(),
                )
            } else {
                val playlistId =
                    response.microformat
                        ?.microformatDataRenderer
                        ?.urlCanonical
                        ?.substringAfterLast('=')!!
                val albumItem =
                    AlbumItem(
                        browseId = browseId,
                        playlistId = playlistId,
                        title =
                            response.contents
                                ?.twoColumnBrowseResultsRenderer
                                ?.tabs
                                ?.firstOrNull()
                                ?.tabRenderer
                                ?.content
                                ?.sectionListRenderer
                                ?.contents
                                ?.firstOrNull()
                                ?.musicResponsiveHeaderRenderer
                                ?.title
                                ?.runs
                                ?.firstOrNull()
                                ?.text!!,
                        artists =
                            response.contents.twoColumnBrowseResultsRenderer.tabs
                                .firstOrNull()
                                ?.tabRenderer
                                ?.content
                                ?.sectionListRenderer
                                ?.contents
                                ?.firstOrNull()
                                ?.musicResponsiveHeaderRenderer
                                ?.straplineTextOne
                                ?.runs
                                ?.oddElements()
                                ?.map {
                                    Artist(
                                        name = it.text,
                                        id = it.navigationEndpoint?.browseEndpoint?.browseId,
                                    )
                                }!!,
                        year =
                            response.contents.twoColumnBrowseResultsRenderer.tabs
                                .firstOrNull()
                                ?.tabRenderer
                                ?.content
                                ?.sectionListRenderer
                                ?.contents
                                ?.firstOrNull()
                                ?.musicResponsiveHeaderRenderer
                                ?.subtitle
                                ?.runs
                                ?.lastOrNull()
                                ?.text
                                ?.toIntOrNull(),
                        thumbnail =
                            response.contents.twoColumnBrowseResultsRenderer.tabs
                                .firstOrNull()
                                ?.tabRenderer
                                ?.content
                                ?.sectionListRenderer
                                ?.contents
                                ?.firstOrNull()
                                ?.musicResponsiveHeaderRenderer
                                ?.thumbnail
                                ?.musicThumbnailRenderer
                                ?.thumbnail
                                ?.thumbnails
                                ?.lastOrNull()
                                ?.url!!,
                        explicit = false, // TODO: Extract explicit badge for albums from YouTube response
                    )
                val albumSongsList =
                    if (withSongs) {
                        albumSongs(
                            playlistId,
                            albumItem,
                        ).getOrThrow()
                    } else {
                        emptyList()
                    }
                // When YouTube credits the album to a label/distributor channel (the header
                // strapline) but every track names the same performing artist, surface the
                // performer as the album artist instead of the label.
                val performer =
                    albumSongsList.firstOrNull()?.artists?.firstOrNull()?.takeIf { first ->
                        first.name.isNotBlank() &&
                            albumSongsList.all { it.artists.firstOrNull()?.name == first.name }
                    }
                val header =
                    response.contents
                        ?.twoColumnBrowseResultsRenderer
                        ?.tabs
                        ?.firstOrNull()
                        ?.tabRenderer
                        ?.content
                        ?.sectionListRenderer
                        ?.contents
                        ?.firstOrNull()
                        ?.musicResponsiveHeaderRenderer
                val description =
                    header?.description?.musicDescriptionShelfRenderer?.description?.runs?.joinToString("") { it.text }
                val resolvedAlbum =
                    if (performer != null && albumItem.artists?.any { it.name == performer.name } != true) {
                        albumItem.copy(artists = listOf(performer))
                    } else {
                        albumItem
                    }
                return@runCatching AlbumPage(
                    album = resolvedAlbum,
                    songs = albumSongsList,
                    otherVersions =
                        response.contents.twoColumnBrowseResultsRenderer.secondaryContents
                            ?.sectionListRenderer
                            ?.contents
                            ?.getOrNull(
                                1,
                            )?.musicCarouselShelfRenderer
                            ?.contents
                            ?.mapNotNull { it.musicTwoRowItemRenderer }
                            ?.mapNotNull(NewReleaseAlbumPage::fromMusicTwoRowItemRenderer)
                            .orEmpty(),
                    description = description,
                )
            }
        }

    suspend fun albumSongs(
        playlistId: String,
        album: AlbumItem? = null,
    ): Result<List<SongItem>> =
        runCatching {
            var response = innerTube.browse(WEB_REMIX, "VL$playlistId").body<BrowseResponse>()
            val shelf =
                response.contents
                    ?.twoColumnBrowseResultsRenderer
                    ?.secondaryContents
                    ?.sectionListRenderer
                    ?.contents
                    ?.firstOrNull()
            val shelfContents =
                shelf?.musicPlaylistShelfRenderer?.contents
                    ?: shelf?.musicShelfRenderer?.contents
                    ?: emptyList()
            val songs =
                shelfContents
                    .getItems()
                    .mapNotNull {
                        AlbumPage.getSong(it, album)
                    }
                    .toMutableList()
            var continuation =
                shelfContents
                    .getContinuation()
            val seenContinuations = mutableSetOf<String>()
            var requestCount = 0
            val maxRequests = 50 // Prevent excessive API calls

            while (continuation != null && requestCount < maxRequests) {
                // Prevent infinite loops by tracking seen continuations
                if (continuation in seenContinuations) {
                    break
                }
                seenContinuations.add(continuation)
                requestCount++

                response =
                    innerTube
                        .browse(
                            client = WEB_REMIX,
                            continuation = continuation,
                        ).body<BrowseResponse>()
                songs +=
                    response.onResponseReceivedActions
                        ?.firstOrNull()
                        ?.appendContinuationItemsAction
                        ?.continuationItems
                        ?.getItems()
                        ?.mapNotNull {
                            AlbumPage.getSong(it, album)
                        }.orEmpty()
                continuation =
                    response.continuationContents
                        ?.musicPlaylistShelfContinuation
                        ?.continuations
                        ?.getContinuation()
            }
            songs
        }

    suspend fun artist(browseId: String): Result<ArtistPage> =
        runCatching {
            val response = innerTube.browse(WEB_REMIX, browseId).body<BrowseResponse>()

            fun mapRuns(runs: List<Run>?): List<Run>? =
                runs?.map { run ->
                    Run(
                        text = run.text,
                        navigationEndpoint = run.navigationEndpoint,
                    )
                }

            val descriptionRuns =
                response.contents
                    ?.sectionListRenderer
                    ?.contents
                    ?.firstOrNull { it.musicDescriptionShelfRenderer != null }
                    ?.musicDescriptionShelfRenderer
                    ?.description
                    ?.runs
                    ?.let(::mapRuns)
                    ?: response.header
                        ?.musicImmersiveHeaderRenderer
                        ?.description
                        ?.runs
                        ?.let(::mapRuns)

            // Check subscription state from multiple locations:
            // 1. musicImmersiveHeaderRenderer.subscriptionButton (regular artists)
            // 2. musicVisualHeaderRenderer.subscriptionButton (podcast channels)
            val immersiveSubscribed =
                response.header
                    ?.musicImmersiveHeaderRenderer
                    ?.subscriptionButton
                    ?.subscribeButtonRenderer
                    ?.subscribed
            val visualSubscribed =
                response.header
                    ?.musicVisualHeaderRenderer
                    ?.subscriptionButton
                    ?.subscribeButtonRenderer
                    ?.subscribed
            val isSubscribed = immersiveSubscribed ?: visualSubscribed ?: false

            // Also extract channelId from visual header if not in immersive header
            val channelIdFromVisual =
                response.header
                    ?.musicVisualHeaderRenderer
                    ?.subscriptionButton
                    ?.subscribeButtonRenderer
                    ?.channelId

            ArtistPage(
                artist =
                    ArtistItem(
                        id = browseId,
                        title =
                            response.header
                                ?.musicImmersiveHeaderRenderer
                                ?.title
                                ?.runs
                                ?.firstOrNull()
                                ?.text
                                ?: response.header
                                    ?.musicVisualHeaderRenderer
                                    ?.title
                                    ?.runs
                                    ?.firstOrNull()
                                    ?.text
                                ?: response.header
                                    ?.musicHeaderRenderer
                                    ?.title
                                    ?.runs
                                    ?.firstOrNull()
                                    ?.text!!,
                        thumbnail =
                            response.header
                                ?.musicImmersiveHeaderRenderer
                                ?.thumbnail
                                ?.musicThumbnailRenderer
                                ?.getThumbnailUrl()
                                ?: response.header
                                    ?.musicVisualHeaderRenderer
                                    ?.foregroundThumbnail
                                    ?.musicThumbnailRenderer
                                    ?.getThumbnailUrl()
                                ?: response.header
                                    ?.musicDetailHeaderRenderer
                                    ?.thumbnail
                                    ?.musicThumbnailRenderer
                                    ?.getThumbnailUrl(),
                        channelId =
                            response.header
                                ?.musicImmersiveHeaderRenderer
                                ?.subscriptionButton
                                ?.subscribeButtonRenderer
                                ?.channelId
                                ?: channelIdFromVisual,
                        playEndpoint =
                            response.contents
                                ?.singleColumnBrowseResultsRenderer
                                ?.tabs
                                ?.firstOrNull()
                                ?.tabRenderer
                                ?.content
                                ?.sectionListRenderer
                                ?.contents
                                ?.firstOrNull()
                                ?.musicShelfRenderer
                                ?.contents
                                ?.firstOrNull()
                                ?.musicResponsiveListItemRenderer
                                ?.overlay
                                ?.musicItemThumbnailOverlayRenderer
                                ?.content
                                ?.musicPlayButtonRenderer
                                ?.playNavigationEndpoint
                                ?.watchEndpoint,
                        shuffleEndpoint =
                            response.header
                                ?.musicImmersiveHeaderRenderer
                                ?.playButton
                                ?.buttonRenderer
                                ?.navigationEndpoint
                                ?.watchEndpoint
                                ?: response.contents
                                    ?.singleColumnBrowseResultsRenderer
                                    ?.tabs
                                    ?.firstOrNull()
                                    ?.tabRenderer
                                    ?.content
                                    ?.sectionListRenderer
                                    ?.contents
                                    ?.firstOrNull()
                                    ?.musicShelfRenderer
                                    ?.contents
                                    ?.firstOrNull()
                                    ?.musicResponsiveListItemRenderer
                                    ?.navigationEndpoint
                                    ?.watchPlaylistEndpoint,
                        radioEndpoint =
                            response.header
                                ?.musicImmersiveHeaderRenderer
                                ?.startRadioButton
                                ?.buttonRenderer
                                ?.navigationEndpoint
                                ?.watchEndpoint,
                    ),
                sections =
                    response.contents
                        ?.singleColumnBrowseResultsRenderer
                        ?.tabs
                        ?.firstOrNull()
                        ?.tabRenderer
                        ?.content
                        ?.sectionListRenderer
                        ?.contents
                        ?.mapNotNull(ArtistPage::fromSectionListRendererContent)!!,
                description = descriptionRuns?.joinToString(separator = "") { it.text },
                subscriberCountText =
                    response.header
                        ?.musicImmersiveHeaderRenderer
                        ?.subscriptionButton2
                        ?.subscribeButtonRenderer
                        ?.subscriberCountWithSubscribeText
                        ?.runs
                        ?.firstOrNull()
                        ?.text
                        ?: response.header
                            ?.musicImmersiveHeaderRenderer
                            ?.subscriptionButton
                            ?.subscribeButtonRenderer
                            ?.longSubscriberCountText
                            ?.runs
                            ?.firstOrNull()
                            ?.text
                        ?: response.header
                            ?.musicImmersiveHeaderRenderer
                            ?.subscriptionButton
                            ?.subscribeButtonRenderer
                            ?.shortSubscriberCountText
                            ?.runs
                            ?.firstOrNull()
                            ?.text,
                monthlyListenerCount =
                    response.header
                        ?.musicImmersiveHeaderRenderer
                        ?.monthlyListenerCount
                        ?.runs
                        ?.firstOrNull()
                        ?.text,
                descriptionRuns = descriptionRuns,
                isSubscribed = isSubscribed,
            )
        }

    suspend fun artistItems(endpoint: BrowseEndpoint): Result<ArtistItemsPage> =
        runCatching {
            val response = innerTube.browse(WEB_REMIX, endpoint.browseId, endpoint.params).body<BrowseResponse>()
            val sectionContent =
                response.contents
                    ?.singleColumnBrowseResultsRenderer
                    ?.tabs
                    ?.firstOrNull()
                    ?.tabRenderer
                    ?.content
                    ?.sectionListRenderer
                    ?.contents
                    ?.firstOrNull()

            val gridRenderer = sectionContent?.gridRenderer
            val musicCarouselShelfRenderer = sectionContent?.musicCarouselShelfRenderer
            val musicPlaylistShelfRenderer = sectionContent?.musicPlaylistShelfRenderer
            val musicShelfRenderer = sectionContent?.musicShelfRenderer

            when {
                gridRenderer != null -> {
                    ArtistItemsPage(
                        title =
                            gridRenderer.header
                                ?.gridHeaderRenderer
                                ?.title
                                ?.runs
                                ?.firstOrNull()
                                ?.text
                                .orEmpty(),
                        items =
                            gridRenderer.items.mapNotNull {
                                it.musicTwoRowItemRenderer?.let { renderer ->
                                    ArtistItemsPage.fromMusicTwoRowItemRenderer(renderer)
                                }
                            },
                        continuation = gridRenderer.continuations?.getContinuation(),
                    )
                }

                musicCarouselShelfRenderer != null -> {
                    ArtistItemsPage(
                        title =
                            musicCarouselShelfRenderer.header
                                ?.musicCarouselShelfBasicHeaderRenderer
                                ?.title
                                ?.runs
                                ?.firstOrNull()
                                ?.text
                                .orEmpty(),
                        items =
                            musicCarouselShelfRenderer.contents.mapNotNull { content ->
                                content.musicTwoRowItemRenderer?.let { renderer ->
                                    ArtistItemsPage.fromMusicTwoRowItemRenderer(renderer)
                                } ?: content.musicResponsiveListItemRenderer?.let { renderer ->
                                    ArtistItemsPage.fromMusicResponsiveListItemRenderer(renderer)
                                }
                            },
                        continuation = null,
                    )
                }

                musicShelfRenderer != null -> {
                    ArtistItemsPage(
                        title =
                            musicShelfRenderer.title
                                ?.runs
                                ?.firstOrNull()
                                ?.text
                                ?: response.header
                                    ?.musicHeaderRenderer
                                    ?.title
                                    ?.runs
                                    ?.firstOrNull()
                                    ?.text
                                ?: "",
                        items =
                            musicShelfRenderer.contents?.getItems()?.mapNotNull {
                                ArtistItemsPage.fromMusicResponsiveListItemRenderer(it)
                            } ?: emptyList(),
                        continuation = musicShelfRenderer.continuations?.getContinuation(),
                    )
                }

                else -> {
                    ArtistItemsPage(
                        title =
                            response.header
                                ?.musicHeaderRenderer
                                ?.title
                                ?.runs
                                ?.firstOrNull()
                                ?.text ?: "",
                        items =
                            musicPlaylistShelfRenderer?.contents?.getItems()?.mapNotNull {
                                ArtistItemsPage.fromMusicResponsiveListItemRenderer(it)
                            } ?: emptyList(),
                        continuation = musicPlaylistShelfRenderer?.contents?.getContinuation(),
                    )
                }
            }
        }

    suspend fun artistItemsContinuation(continuation: String): Result<ArtistItemsContinuationPage> =
        runCatching {
            val response = innerTube.browse(WEB_REMIX, continuation = continuation).body<BrowseResponse>()

            when {
                response.continuationContents?.gridContinuation != null -> {
                    val gridContinuation = response.continuationContents.gridContinuation
                    val items =
                        gridContinuation.items.mapNotNull {
                            it.musicTwoRowItemRenderer?.let { renderer ->
                                ArtistItemsPage.fromMusicTwoRowItemRenderer(renderer)
                            }
                        }
                    ArtistItemsContinuationPage(
                        items = items,
                        continuation = if (items.isEmpty()) null else gridContinuation.continuations?.getContinuation(),
                    )
                }

                response.continuationContents?.musicPlaylistShelfContinuation != null -> {
                    val musicPlaylistShelfContinuation = response.continuationContents.musicPlaylistShelfContinuation
                    val items =
                        musicPlaylistShelfContinuation.contents.getItems().mapNotNull {
                            ArtistItemsPage.fromMusicResponsiveListItemRenderer(it)
                        }
                    ArtistItemsContinuationPage(
                        items = items,
                        continuation = if (items.isEmpty()) null else musicPlaylistShelfContinuation.continuations?.getContinuation(),
                    )
                }

                else -> {
                    val continuationItems =
                        response.onResponseReceivedActions
                            ?.firstOrNull()
                            ?.appendContinuationItemsAction
                            ?.continuationItems
                    val items =
                        continuationItems?.getItems()?.mapNotNull {
                            ArtistItemsPage.fromMusicResponsiveListItemRenderer(it)
                        } ?: emptyList()
                    ArtistItemsContinuationPage(
                        items = items,
                        continuation = if (items.isEmpty()) null else continuationItems?.getContinuation(),
                    )
                }
            }
        }

    suspend fun playlist(playlistId: String): Result<PlaylistPage> =
        runCatching {
            val response =
                innerTube
                    .browse(
                        client = WEB_REMIX,
                        browseId = "VL$playlistId",
                        setLogin = true,
                    ).body<BrowseResponse>()
            val base =
                response.contents
                    ?.twoColumnBrowseResultsRenderer
                    ?.tabs
                    ?.firstOrNull()
                    ?.tabRenderer
                    ?.content
                    ?.sectionListRenderer
                    ?.contents
                    ?.firstOrNull()
            val header =
                base?.musicResponsiveHeaderRenderer
                    ?: base?.musicEditablePlaylistDetailHeaderRenderer?.header?.musicResponsiveHeaderRenderer

            val editable = base?.musicEditablePlaylistDetailHeaderRenderer != null

            val description: String? =
                header?.description?.musicDescriptionShelfRenderer?.description?.runs?.joinToString("") { it.text }
                    ?: base?.musicEditablePlaylistDetailHeaderRenderer
                        ?.header?.musicDetailHeaderRenderer
                        ?.description?.runs?.joinToString("") { it.text }
                    ?: response.header?.musicDetailHeaderRenderer
                        ?.description?.runs?.joinToString("") { it.text }

            val author: Artist? = run {
                val fromStrapline = header?.straplineTextOne?.runs
                    ?.firstOrNull()
                    ?.let { Artist(name = it.text, id = it.navigationEndpoint?.browseEndpoint?.browseId) }
                if (fromStrapline != null) return@run fromStrapline

                val detailSubtitle = base?.musicEditablePlaylistDetailHeaderRenderer
                    ?.header?.musicDetailHeaderRenderer?.subtitle?.runs
                    ?: response.header?.musicDetailHeaderRenderer?.subtitle?.runs
                if (detailSubtitle != null) {
                    val segments = detailSubtitle.splitBySeparator()
                    val run = segments.getOrNull(1)?.firstOrNull()
                        ?: segments.firstOrNull()?.firstOrNull()
                    val fromDetail = run?.let {
                        Artist(name = it.text, id = it.navigationEndpoint?.browseEndpoint?.browseId)
                    }
                    if (fromDetail != null) return@run fromDetail
                }

                val fromHeaderSubtitle = header?.subtitle?.runs
                    ?.firstOrNull { it.navigationEndpoint != null }
                    ?.let { Artist(name = it.text, id = it.navigationEndpoint?.browseEndpoint?.browseId) }
                if (fromHeaderSubtitle != null) return@run fromHeaderSubtitle

                val facepile = header?.facepile?.avatarStackViewModel
                if (facepile != null) {
                    val name = facepile.text?.content
                    val browseId = facepile.rendererContext?.commandContext?.onTap?.innertubeCommand?.browseEndpoint?.browseId
                    if (name != null) return@run Artist(name = name, id = browseId)
                }

                val fromMusicHeaderStrapline = response.header?.musicHeaderRenderer
                    ?.straplineTextOne?.runs?.firstOrNull()
                    ?.let { Artist(name = it.text, id = it.navigationEndpoint?.browseEndpoint?.browseId) }
                if (fromMusicHeaderStrapline != null) return@run fromMusicHeaderStrapline

                null
            }

            val authorAvatarUrl: String? = header?.facepile
                ?.avatarStackViewModel?.avatars?.firstOrNull()
                ?.avatarViewModel?.image?.sources?.firstOrNull()
                ?.url

            PlaylistPage(
                playlist =
                    PlaylistItem(
                        id = playlistId,
                        title =
                            header?.title?.runs?.firstOrNull()?.text
                                ?: response.header?.musicHeaderRenderer?.title?.runs?.firstOrNull()?.text
                                ?: "",
                        author = author,
                        songCountText =
                            (header?.secondSubtitle
                                ?: response.header?.musicHeaderRenderer?.secondSubtitle)
                                ?.runs
                                ?.findLast {
                                    it.text.any { c -> c.isDigit() } &&
                                        !it.text.contains("view", ignoreCase = true) &&
                                        !it.text.contains("hour", ignoreCase = true) &&
                                        !it.text.contains("minute", ignoreCase = true)
                                }?.text,
                        thumbnail =
                            header?.thumbnail
                                ?.musicThumbnailRenderer
                                ?.thumbnail
                                ?.thumbnails
                                ?.lastOrNull()
                                ?.url
                                ?: response.header
                                    ?.musicHeaderRenderer
                                    ?.thumbnail
                                    ?.musicThumbnailRenderer
                                    ?.thumbnails
                                    ?.lastOrNull()
                                    ?.url
                                ?: "",
                        playEndpoint = null,
                        shuffleEndpoint =
                            header?.buttons?.lastOrNull()
                                ?.menuRenderer?.items?.firstOrNull()
                                ?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint
                                ?: response.header?.musicHeaderRenderer?.buttons?.lastOrNull()
                                    ?.menuRenderer?.items?.firstOrNull()
                                    ?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint,
                        radioEndpoint =
                            header?.buttons?.getOrNull(2)
                                ?.menuRenderer?.items?.find {
                                    it.menuNavigationItemRenderer?.icon?.iconType == "MIX"
                                }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint
                                ?: response.header?.musicHeaderRenderer?.buttons?.getOrNull(2)
                                    ?.menuRenderer?.items?.find {
                                        it.menuNavigationItemRenderer?.icon?.iconType == "MIX"
                                    }?.menuNavigationItemRenderer?.navigationEndpoint?.watchPlaylistEndpoint,
                        isEditable = editable,
                        description = description,
                        authorAvatarUrl = authorAvatarUrl,
                    ),
                songs = run {
                    val twoColShelf =
                        response.contents
                            ?.twoColumnBrowseResultsRenderer
                            ?.secondaryContents
                            ?.sectionListRenderer
                            ?.contents
                            ?.firstOrNull()
                    val twoColContents =
                        twoColShelf?.musicPlaylistShelfRenderer?.contents
                            ?: twoColShelf?.musicShelfRenderer?.contents
                    val singleColShelf =
                        response.contents
                            ?.singleColumnBrowseResultsRenderer
                            ?.tabs
                            ?.firstOrNull()
                            ?.tabRenderer
                            ?.content
                            ?.sectionListRenderer
                            ?.contents
                            ?.firstOrNull()
                    val singleColContents =
                        singleColShelf?.musicPlaylistShelfRenderer?.contents
                            ?: singleColShelf?.musicShelfRenderer?.contents
                    (twoColContents ?: singleColContents)
                        ?.getItems()
                        ?.mapNotNull { PlaylistPage.fromMusicResponsiveListItemRenderer(it) }
                        ?: emptyList()
                },
                songsContinuation = run {
                    val twoColShelf =
                        response.contents
                            ?.twoColumnBrowseResultsRenderer
                            ?.secondaryContents
                            ?.sectionListRenderer
                            ?.contents
                            ?.firstOrNull()
                    val twoColContents =
                        twoColShelf?.musicPlaylistShelfRenderer?.contents
                            ?: twoColShelf?.musicShelfRenderer?.contents
                    val twoColContinuations =
                        twoColShelf?.musicPlaylistShelfRenderer?.continuations
                            ?: twoColShelf?.musicShelfRenderer?.continuations
                    val singleColShelf =
                        response.contents
                            ?.singleColumnBrowseResultsRenderer
                            ?.tabs
                            ?.firstOrNull()
                            ?.tabRenderer
                            ?.content
                            ?.sectionListRenderer
                            ?.contents
                            ?.firstOrNull()
                    val singleColContents =
                        singleColShelf?.musicPlaylistShelfRenderer?.contents
                            ?: singleColShelf?.musicShelfRenderer?.contents
                    val singleColContinuations =
                        singleColShelf?.musicPlaylistShelfRenderer?.continuations
                            ?: singleColShelf?.musicShelfRenderer?.continuations
                    val mergedContents = twoColContents ?: singleColContents
                    val mergedContinuations = twoColContinuations ?: singleColContinuations
                    mergedContents?.getContinuation() ?: mergedContinuations?.getContinuation()
                },
                continuation =
                    response.contents
                        ?.twoColumnBrowseResultsRenderer
                        ?.secondaryContents
                        ?.sectionListRenderer
                        ?.continuations
                        ?.getContinuation(),
            )
        }

    suspend fun playlistContinuation(continuation: String): Result<PlaylistContinuationPage> =
        runCatching {
            val response =
                innerTube
                    .browse(
                        client = WEB_REMIX,
                        continuation = continuation,
                        setLogin = true,
                    ).body<BrowseResponse>()

            val mainContents: List<MusicShelfRenderer.Content> =
                response.continuationContents
                    ?.sectionListContinuation
                    ?.contents
                    ?.mapNotNull { content: SectionListRenderer.Content ->
                        content.musicPlaylistShelfRenderer?.contents
                            ?: content.musicShelfRenderer?.contents
                    }
                    ?.flatten()
                    ?: emptyList()

            val shelfContents: List<MusicShelfRenderer.Content> =
                response.continuationContents?.musicPlaylistShelfContinuation?.contents ?: emptyList()

            val musicShelfContinuationContents: List<MusicShelfRenderer.Content> =
                response.continuationContents?.musicShelfContinuation?.contents ?: emptyList()

            val appendedContents: List<MusicShelfRenderer.Content> =
                response.onResponseReceivedActions
                    ?.firstOrNull()
                    ?.appendContinuationItemsAction
                    ?.continuationItems
                    .orEmpty()

            val allContents = mainContents + shelfContents + musicShelfContinuationContents + appendedContents

            val songs =
                allContents
                    .mapNotNull { content: MusicShelfRenderer.Content -> content.musicResponsiveListItemRenderer }
                    .mapNotNull { renderer -> PlaylistPage.fromMusicResponsiveListItemRenderer(renderer) }

            val nextContinuation =
                if (songs.isEmpty()) {
                    null
                } else {
                    response.continuationContents
                        ?.sectionListContinuation
                        ?.continuations
                        ?.getContinuation()
                        ?: response.continuationContents
                            ?.musicPlaylistShelfContinuation
                            ?.continuations
                            ?.getContinuation()
                        ?: response.continuationContents
                            ?.musicShelfContinuation
                            ?.continuations
                            ?.getContinuation()
                        ?: response.onResponseReceivedActions
                            ?.firstOrNull()
                            ?.appendContinuationItemsAction
                            ?.continuationItems
                            ?.getContinuation()
                }

            PlaylistContinuationPage(
                songs = songs,
                continuation = nextContinuation,
            )
        }

    suspend fun podcast(podcastId: String): Result<PodcastPage> = podcastWithDebug(podcastId) { }

    suspend fun podcastWithDebug(
        podcastId: String,
        log: (String) -> Unit,
    ): Result<PodcastPage> =
        runCatching {
            Timber.d("Fetching podcast with ID: $podcastId")
            val response =
                innerTube
                    .browse(
                        client = WEB_REMIX,
                        browseId = podcastId,
                        setLogin = true,
                    ).body<BrowseResponse>()

            Timber.d("Response received, twoColumnBrowseResultsRenderer: ${response.contents?.twoColumnBrowseResultsRenderer != null}")
            Timber.d("singleColumnBrowseResultsRenderer: ${response.contents?.singleColumnBrowseResultsRenderer != null}")

            // Try twoColumn first (standard layout)
            var header =
                response.contents
                    ?.twoColumnBrowseResultsRenderer
                    ?.tabs
                    ?.firstOrNull()
                    ?.tabRenderer
                    ?.content
                    ?.sectionListRenderer
                    ?.contents
                    ?.firstOrNull()
                    ?.musicResponsiveHeaderRenderer

            // Fallback to singleColumn layout
            if (header == null) {
                header =
                    response.contents
                        ?.singleColumnBrowseResultsRenderer
                        ?.tabs
                        ?.firstOrNull()
                        ?.tabRenderer
                        ?.content
                        ?.sectionListRenderer
                        ?.contents
                        ?.firstOrNull()
                        ?.musicResponsiveHeaderRenderer
                Timber.d("Using singleColumn layout, header found: ${header != null}")
            }

            Timber.d("Header title: ${header?.title?.runs?.firstOrNull()?.text}")

            // Debug: Log button structure
            header?.buttons?.forEachIndexed { i, button ->
                Timber.d(
                    "[PODCAST] Button[$i]: menuRenderer=${button.menuRenderer != null}, toggleButtonRenderer=${button.toggleButtonRenderer != null}, playButtonRenderer=${button.musicPlayButtonRenderer != null}",
                )
                button.menuRenderer?.items?.forEachIndexed { j, item ->
                    Timber.d(
                        "[PODCAST] Button[$i].menuItems[$j]: toggle=${item.toggleMenuServiceItemRenderer?.defaultIcon?.iconType}, nav=${item.menuNavigationItemRenderer?.icon?.iconType}",
                    )
                    // Check for SUBSCRIBE button (like artists have)
                    if (item.toggleMenuServiceItemRenderer?.defaultIcon?.iconType == "SUBSCRIBE") {
                        val channelIds =
                            item.toggleMenuServiceItemRenderer.defaultServiceEndpoint.subscribeEndpoint
                                ?.channelIds
                        Timber.d("[PODCAST] Found SUBSCRIBE button! channelIds=$channelIds")
                    }
                }
                button.toggleButtonRenderer?.let { toggle ->
                    Timber.d(
                        "[PODCAST] Button[$i].toggleButtonRenderer: defaultIcon=${toggle.defaultIcon?.iconType}, defaultToken=${toggle.defaultServiceEndpoint?.feedbackEndpoint?.feedbackToken?.take(
                            30,
                        )}, subscribeChannelIds=${toggle.defaultServiceEndpoint?.subscribeEndpoint?.channelIds}",
                    )
                }
            }

            // Extract channelId and subscription state for subscription (like artists)
            val subscribeToggle =
                header
                    ?.buttons
                    ?.flatMap { button ->
                        button.menuRenderer?.items ?: emptyList()
                    }?.find {
                        it.toggleMenuServiceItemRenderer?.defaultIcon?.iconType == "SUBSCRIBE"
                    }?.toggleMenuServiceItemRenderer
            val channelId =
                subscribeToggle
                    ?.defaultServiceEndpoint
                    ?.subscribeEndpoint
                    ?.channelIds
                    ?.firstOrNull()
            // isSelected indicates user is currently subscribed (toggle is in "toggled" state)
            val isChannelSubscribed = subscribeToggle?.isSelected == true
            Timber.d("[PODCAST] Extracted channelId for subscription: $channelId, isSubscribed: $isChannelSubscribed")

            // Extract library tokens from the header's menu buttons OR toggle buttons
            var libraryTokens =
                header
                    ?.buttons
                    ?.flatMap { button ->
                        button.menuRenderer?.items ?: emptyList()
                    }?.let { menuItems ->
                        PageHelper.extractLibraryTokensFromMenuItems(menuItems)
                    }

            // Also check for standalone toggle buttons (used by some podcasts)
            if (libraryTokens?.addToken == null && libraryTokens?.removeToken == null) {
                header?.buttons?.forEach { button ->
                    button.toggleButtonRenderer?.let { toggle ->
                        val iconType = toggle.defaultIcon?.iconType
                        if (iconType != null && PageHelper.isLibraryIcon(iconType)) {
                            val defaultToken = toggle.defaultServiceEndpoint?.feedbackEndpoint?.feedbackToken
                            val toggledToken = toggle.toggledServiceEndpoint?.feedbackEndpoint?.feedbackToken
                            libraryTokens =
                                if (PageHelper.isAddLibraryIcon(iconType)) {
                                    // BOOKMARK_BORDER: default=add, toggled=remove
                                    PageHelper.LibraryFeedbackTokens(defaultToken, toggledToken)
                                } else {
                                    // BOOKMARK: default=remove, toggled=add
                                    PageHelper.LibraryFeedbackTokens(toggledToken, defaultToken)
                                }
                            val tokens = libraryTokens
                            if (tokens != null) {
                                Timber.d(
                                    "[PODCAST] Found toggle button with library tokens - add: ${tokens.addToken != null}, remove: ${tokens.removeToken != null}",
                                )
                            }
                        }
                    }
                }
            }
            Timber.d("[PODCAST] Library tokens - add: ${libraryTokens?.addToken != null}, remove: ${libraryTokens?.removeToken != null}")

            val podcastItem =
                PodcastItem(
                    id = podcastId,
                    title =
                        header
                            ?.title
                            ?.runs
                            ?.firstOrNull()
                            ?.text ?: "",
                    author =
                        header?.straplineTextOne?.runs?.firstOrNull()?.let {
                            Artist(
                                name = it.text,
                                id = it.navigationEndpoint?.browseEndpoint?.browseId,
                            )
                        },
                    episodeCountText =
                        header
                            ?.secondSubtitle
                            ?.runs
                            ?.firstOrNull()
                            ?.text,
                    thumbnail =
                        header
                            ?.thumbnail
                            ?.musicThumbnailRenderer
                            ?.thumbnail
                            ?.thumbnails
                            ?.lastOrNull()
                            ?.url,
                    playEndpoint =
                        header
                            ?.buttons
                            ?.find {
                                it.menuRenderer
                                    ?.items
                                    ?.firstOrNull()
                                    ?.menuNavigationItemRenderer
                                    ?.icon
                                    ?.iconType == "PLAY_ARROW"
                            }?.menuRenderer
                            ?.items
                            ?.firstOrNull()
                            ?.menuNavigationItemRenderer
                            ?.navigationEndpoint
                            ?.watchPlaylistEndpoint,
                    shuffleEndpoint =
                        header
                            ?.buttons
                            ?.find {
                                it.menuRenderer?.items?.any { item ->
                                    item.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE"
                                } ==
                                    true
                            }?.menuRenderer
                            ?.items
                            ?.find { it.menuNavigationItemRenderer?.icon?.iconType == "MUSIC_SHUFFLE" }
                            ?.menuNavigationItemRenderer
                            ?.navigationEndpoint
                            ?.watchPlaylistEndpoint,
                    libraryAddToken = libraryTokens?.addToken,
                    libraryRemoveToken = libraryTokens?.removeToken,
                    channelId = channelId,
                )

            // Try twoColumn for episodes
            val secondaryContents = response.contents?.twoColumnBrowseResultsRenderer?.secondaryContents
            Timber.d("secondaryContents null: ${secondaryContents == null}")
            Timber.d("secondaryContents.sectionListRenderer null: ${secondaryContents?.sectionListRenderer == null}")
            Timber.d("sectionListRenderer.contents size: ${secondaryContents?.sectionListRenderer?.contents?.size ?: 0}")

            secondaryContents?.sectionListRenderer?.contents?.forEachIndexed { index, content ->
                Timber.d(
                    "Content[$index]: musicShelfRenderer=${content.musicShelfRenderer != null}, musicPlaylistShelfRenderer=${content.musicPlaylistShelfRenderer != null}, gridRenderer=${content.gridRenderer != null}",
                )
                content.musicShelfRenderer?.let { shelf ->
                    Timber.d("musicShelfRenderer.contents size: ${shelf.contents?.size ?: 0}")
                }
                content.musicPlaylistShelfRenderer?.let { shelf ->
                    Timber.d("musicPlaylistShelfRenderer.contents size: ${shelf.contents.size}")
                }
            }

            var episodeContents =
                secondaryContents
                    ?.sectionListRenderer
                    ?.contents
                    ?.firstOrNull()
                    ?.musicShelfRenderer
                    ?.contents

            // Try musicPlaylistShelfRenderer
            if (episodeContents == null) {
                episodeContents =
                    secondaryContents
                        ?.sectionListRenderer
                        ?.contents
                        ?.firstOrNull()
                        ?.musicPlaylistShelfRenderer
                        ?.contents
                Timber.d("Trying musicPlaylistShelfRenderer: ${episodeContents?.size ?: 0}")
            }

            // Fallback to singleColumn
            if (episodeContents == null) {
                episodeContents =
                    response.contents
                        ?.singleColumnBrowseResultsRenderer
                        ?.tabs
                        ?.firstOrNull()
                        ?.tabRenderer
                        ?.content
                        ?.sectionListRenderer
                        ?.contents
                        ?.find { it.musicShelfRenderer != null }
                        ?.musicShelfRenderer
                        ?.contents
                Timber.d("Using singleColumn for episodes, found: ${episodeContents?.size ?: 0}")
            }

            Timber.d("Episode contents count: ${episodeContents?.size ?: 0}")

            // Get episodes from musicMultiRowListItemRenderer (used for podcasts)
            val multiRowItems = episodeContents?.mapNotNull { it.musicMultiRowListItemRenderer } ?: emptyList()
            Timber.d("multiRowItems count: ${multiRowItems.size}")

            multiRowItems.take(2).forEachIndexed { idx, renderer ->
                Timber.d("Episode[$idx] title: ${renderer.title?.runs?.firstOrNull()?.text}")
                Timber.d("Episode[$idx] subtitle: ${renderer.subtitle?.runs?.map { it.text }}")
                Timber.d("Episode[$idx] videoId: ${renderer.onTap?.watchEndpoint?.videoId}")
                Timber.d("Episode[$idx] thumbnail: ${renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl()}")
            }

            val episodes =
                multiRowItems.mapNotNull { renderer ->
                    PodcastPage.fromMusicMultiRowListItemRenderer(renderer, podcastItem)
                }

            Timber.d("Parsed episodes: ${episodes.size}")

            PodcastPage(
                podcast = podcastItem,
                episodes = episodes,
                continuation =
                    response.contents
                        ?.twoColumnBrowseResultsRenderer
                        ?.secondaryContents
                        ?.sectionListRenderer
                        ?.contents
                        ?.firstOrNull()
                        ?.musicShelfRenderer
                        ?.continuations
                        ?.getContinuation()
                        ?: response.contents
                            ?.singleColumnBrowseResultsRenderer
                            ?.tabs
                            ?.firstOrNull()
                            ?.tabRenderer
                            ?.content
                            ?.sectionListRenderer
                            ?.contents
                            ?.find { it.musicShelfRenderer != null }
                            ?.musicShelfRenderer
                            ?.continuations
                            ?.getContinuation(),
                isChannelSubscribed = isChannelSubscribed,
            )
        }

    suspend fun home(
        continuation: String? = null,
        params: String? = null,
    ): Result<HomePage> =
        runCatching {
            Timber.d("home() called with continuation=$continuation, params=$params")
            if (continuation != null) {
                return@runCatching homeContinuation(continuation).getOrThrow()
            }

            val rawResponse = innerTube.browse(WEB_REMIX, browseId = "FEmusic_home", params = params).body<BrowseResponse>()
            val response = com.listrovia.innertube.InnerTubeStreamFilterLayer.pruneBrowseResponse(rawResponse)
            Timber.d("home() response received")
            val continuation =
                response.contents
                    ?.singleColumnBrowseResultsRenderer
                    ?.tabs
                    ?.firstOrNull()
                    ?.tabRenderer
                    ?.content
                    ?.sectionListRenderer
                    ?.continuations
                    ?.getContinuation()
            val sectionListRender =
                response.contents
                    ?.singleColumnBrowseResultsRenderer
                    ?.tabs
                    ?.firstOrNull()
                    ?.tabRenderer
                    ?.content
                    ?.sectionListRenderer
            Timber.d("home() sectionListRender contents size: ${sectionListRender?.contents?.size ?: 0}")
            val carousels = sectionListRender?.contents?.mapNotNull { it.musicCarouselShelfRenderer } ?: emptyList()
            Timber.d("home() carousels count: ${carousels.size}")
            val sections =
                carousels
                    .mapNotNull {
                        HomePage.Section.fromMusicCarouselShelfRenderer(it)
                    }.toMutableList()
            Timber.d("home() sections parsed: ${sections.size}")
            val chips =
                sectionListRender
                    ?.header
                    ?.chipCloudRenderer
                    ?.chips
                    ?.mapNotNull { HomePage.Chip.fromChipCloudChipRenderer(it) }
            Timber.d("home() chips: ${chips?.size ?: 0}")
            HomePage(chips, sections, continuation)
        }

    private suspend fun homeContinuation(continuation: String): Result<HomePage> =
        runCatching {
            val rawResponse =
                innerTube.browse(WEB_REMIX, continuation = continuation).body<BrowseResponse>()
            val response = com.listrovia.innertube.InnerTubeStreamFilterLayer.pruneBrowseResponse(rawResponse)
            val continuation =
                response.continuationContents
                    ?.sectionListContinuation
                    ?.continuations
                    ?.getContinuation()
            HomePage(
                null,
                response.continuationContents
                    ?.sectionListContinuation
                    ?.contents
                    ?.mapNotNull { it.musicCarouselShelfRenderer }
                    ?.mapNotNull {
                        HomePage.Section.fromMusicCarouselShelfRenderer(it)
                    }.orEmpty(),
                continuation,
            )
        }

    suspend fun explore(): Result<ExplorePage> =
        runCatching {
            val rawResponse = innerTube.browse(WEB_REMIX, browseId = "FEmusic_explore").body<BrowseResponse>()
            val response = com.listrovia.innertube.InnerTubeStreamFilterLayer.pruneBrowseResponse(rawResponse)
            ExplorePage(
                newReleaseAlbums =
                    response.contents
                        ?.singleColumnBrowseResultsRenderer
                        ?.tabs
                        ?.firstOrNull()
                        ?.tabRenderer
                        ?.content
                        ?.sectionListRenderer
                        ?.contents
                        ?.find {
                            it.musicCarouselShelfRenderer
                                ?.header
                                ?.musicCarouselShelfBasicHeaderRenderer
                                ?.moreContentButton
                                ?.buttonRenderer
                                ?.navigationEndpoint
                                ?.browseEndpoint
                                ?.browseId ==
                                "FEmusic_new_releases_albums"
                        }?.musicCarouselShelfRenderer
                        ?.contents
                        ?.mapNotNull { it.musicTwoRowItemRenderer }
                        ?.mapNotNull(NewReleaseAlbumPage::fromMusicTwoRowItemRenderer)
                        ?.filter { com.listrovia.innertube.SongContentModerator.isItemAllowed(it) }
                        .orEmpty(),
                moodAndGenres =
                    response.contents
                        ?.singleColumnBrowseResultsRenderer
                        ?.tabs
                        ?.firstOrNull()
                        ?.tabRenderer
                        ?.content
                        ?.sectionListRenderer
                        ?.contents
                        ?.find {
                            it.musicCarouselShelfRenderer
                                ?.header
                                ?.musicCarouselShelfBasicHeaderRenderer
                                ?.moreContentButton
                                ?.buttonRenderer
                                ?.navigationEndpoint
                                ?.browseEndpoint
                                ?.browseId ==
                                "FEmusic_moods_and_genres"
                        }?.musicCarouselShelfRenderer
                        ?.contents
                        ?.mapNotNull { it.musicNavigationButtonRenderer }
                        ?.mapNotNull(MoodAndGenres.Companion::fromMusicNavigationButtonRenderer)
                        .orEmpty(),
            )
        }

    suspend fun newReleaseAlbums(): Result<List<AlbumItem>> =
        runCatching {
            val response = innerTube.browse(WEB_REMIX, browseId = "FEmusic_new_releases_albums").body<BrowseResponse>()
            response.contents
                ?.singleColumnBrowseResultsRenderer
                ?.tabs
                ?.firstOrNull()
                ?.tabRenderer
                ?.content
                ?.sectionListRenderer
                ?.contents
                ?.firstOrNull()
                ?.gridRenderer
                ?.items
                ?.mapNotNull { it.musicTwoRowItemRenderer }
                ?.mapNotNull(NewReleaseAlbumPage::fromMusicTwoRowItemRenderer)
                .orEmpty()
        }

    suspend fun moodAndGenres(): Result<List<MoodAndGenres>> =
        runCatching {
            val response = innerTube.browse(WEB_REMIX, browseId = "FEmusic_moods_and_genres").body<BrowseResponse>()
            response.contents
                ?.singleColumnBrowseResultsRenderer
                ?.tabs
                ?.firstOrNull()
                ?.tabRenderer
                ?.content
                ?.sectionListRenderer
                ?.contents!!
                .mapNotNull(MoodAndGenres.Companion::fromSectionListRendererContent)
        }

    suspend fun browse(
        browseId: String,
        params: String?,
    ): Result<BrowseResult> =
        runCatching {
            // Use authentication for library endpoints
            val needsLogin = browseId.startsWith("FEmusic_library") || browseId == "VLSE" || browseId == "VLRDPN"
            val response = innerTube.browse(WEB_REMIX, browseId = browseId, params = params, setLogin = needsLogin).body<BrowseResponse>()
            val sectionContents =
                response.contents
                    ?.singleColumnBrowseResultsRenderer
                    ?.tabs
                    ?.firstOrNull()
                    ?.tabRenderer
                    ?.content
                    ?.sectionListRenderer
                    ?.contents
            BrowseResult(
                title =
                    response.header
                        ?.musicHeaderRenderer
                        ?.title
                        ?.runs
                        ?.firstOrNull()
                        ?.text,
                items =
                    sectionContents
                        ?.mapNotNull { content ->
                            when {
                                content.gridRenderer != null -> {
                                    BrowseResult.Item(
                                        title =
                                            content.gridRenderer.header
                                                ?.gridHeaderRenderer
                                                ?.title
                                                ?.runs
                                                ?.firstOrNull()
                                                ?.text,
                                        items =
                                            content.gridRenderer.items
                                                .mapNotNull(GridRenderer.Item::musicTwoRowItemRenderer)
                                                .mapNotNull { renderer ->
                                                    // Try LibraryPage first (more lenient for library endpoints), fall back to RelatedPage
                                                    LibraryPage.fromMusicTwoRowItemRenderer(renderer)
                                                        ?: RelatedPage.fromMusicTwoRowItemRenderer(renderer)
                                                },
                                    )
                                }

                                content.musicCarouselShelfRenderer != null -> {
                                    val carouselItems = mutableListOf<YTItem>()
                                    for (carouselContent in content.musicCarouselShelfRenderer.contents) {
                                        val item = carouselContent.musicTwoRowItemRenderer?.let { renderer ->
                                            LibraryPage.fromMusicTwoRowItemRenderer(renderer)
                                                ?: RelatedPage.fromMusicTwoRowItemRenderer(renderer)
                                        } ?: carouselContent.musicMultiRowListItemRenderer?.let { renderer ->
                                            PodcastPage.fromMusicMultiRowListItemRenderer(renderer)
                                        } ?: carouselContent.musicResponsiveListItemRenderer?.let { renderer ->
                                            LibraryPage.fromMusicResponsiveListItemRenderer(renderer)
                                                ?: RelatedPage.fromMusicResponsiveListItemRenderer(renderer)
                                        }
                                        if (item != null) {
                                            carouselItems.add(item)
                                        }
                                    }
                                    BrowseResult.Item(
                                        title =
                                            content.musicCarouselShelfRenderer.header
                                                ?.musicCarouselShelfBasicHeaderRenderer
                                                ?.title
                                                ?.runs
                                                ?.firstOrNull()
                                                ?.text,
                                        items =
                                            content.musicCarouselShelfRenderer.contents.mapNotNull { content ->
                                                content.musicTwoRowItemRenderer?.let { renderer ->
                                                    LibraryPage.fromMusicTwoRowItemRenderer(renderer)
                                                        ?: RelatedPage.fromMusicTwoRowItemRenderer(renderer)
                                                } ?: content.musicMultiRowListItemRenderer?.let { renderer ->
                                                    PodcastPage.fromMusicMultiRowListItemRenderer(renderer)
                                                } ?: content.musicResponsiveListItemRenderer?.let { renderer ->
                                                    LibraryPage.fromMusicResponsiveListItemRenderer(renderer)
                                                        ?: RelatedPage.fromMusicResponsiveListItemRenderer(renderer)
                                                }
                                            },
                                    )
                                }

                                content.musicShelfRenderer != null -> {
                                    BrowseResult.Item(
                                        title =
                                            content.musicShelfRenderer.title
                                                ?.runs
                                                ?.firstOrNull()
                                                ?.text,
                                        items =
                                            content.musicShelfRenderer.contents
                                                ?.mapNotNull(MusicShelfRenderer.Content::musicResponsiveListItemRenderer)
                                                ?.mapNotNull(LibraryPage.Companion::fromMusicResponsiveListItemRenderer)
                                                ?: emptyList(),
                                    )
                                }

                                content.musicPlaylistShelfRenderer != null -> {
                                    BrowseResult.Item(
                                        title = null, // MusicPlaylistShelfRenderer doesn't have a title
                                        items =
                                            content.musicPlaylistShelfRenderer.contents
                                                .getItems()
                                                .mapNotNull(LibraryPage.Companion::fromMusicResponsiveListItemRenderer),
                                    )
                                }

                                else -> {
                                    null
                                }
                            }
                        }.orEmpty(),
            )
        }

    suspend fun library(
        browseId: String,
        tabIndex: Int = 0,
    ): Result<LibraryPage> =
        runCatching {
            val response =
                innerTube
                    .browse(
                        client = WEB_REMIX,
                        browseId = browseId,
                        setLogin = true,
                    ).body<BrowseResponse>()

            val tabs = response.contents?.singleColumnBrowseResultsRenderer?.tabs
            val contents =
                if (tabs != null && tabs.size > tabIndex) {
                    tabs[tabIndex]
                        .tabRenderer.content
                        ?.sectionListRenderer
                        ?.contents
                        ?.firstOrNull()
                } else {
                    null
                }

            when {
                contents?.gridRenderer != null -> {
                    val gridItems = contents.gridRenderer.items
                    val parsedItems =
                        gridItems
                            .mapNotNull(GridRenderer.Item::musicTwoRowItemRenderer)
                            .mapNotNull { LibraryPage.fromMusicTwoRowItemRenderer(it) }
                    LibraryPage(
                        items = parsedItems,
                        continuation = contents.gridRenderer.continuations?.getContinuation(),
                    )
                }

                else -> {
                    val shelfContents = contents?.musicShelfRenderer?.contents
                    if (shelfContents == null) {
                        throw IllegalStateException("No content found for browseId=$browseId")
                    }
                    val listItemRenderers = shelfContents.mapNotNull(MusicShelfRenderer.Content::musicResponsiveListItemRenderer)
                    val parsedItems =
                        listItemRenderers.mapNotNull { renderer ->
                            LibraryPage.fromMusicResponsiveListItemRenderer(renderer)
                        }
                    LibraryPage(
                        items = parsedItems,
                        continuation = contents.musicShelfRenderer.continuations?.getContinuation(),
                    )
                }
            }
        }

    suspend fun libraryContinuation(continuation: String) =
        runCatching {
            val response =
                innerTube
                    .browse(
                        client = WEB_REMIX,
                        continuation = continuation,
                        setLogin = true,
                    ).body<BrowseResponse>()

            val contents = response.continuationContents

            when {
                contents?.gridContinuation != null -> {
                    LibraryContinuationPage(
                        items =
                            contents.gridContinuation.items
                                .mapNotNull(GridRenderer.Item::musicTwoRowItemRenderer)
                                .mapNotNull { LibraryPage.fromMusicTwoRowItemRenderer(it) },
                        continuation = contents.gridContinuation.continuations?.getContinuation(),
                    )
                }

                else -> { // contents?.musicShelfContinuation != null
                    LibraryContinuationPage(
                        items =
                            contents
                                ?.musicShelfContinuation
                                ?.contents!!
                                .mapNotNull(MusicShelfRenderer.Content::musicResponsiveListItemRenderer)
                                .mapNotNull { LibraryPage.fromMusicResponsiveListItemRenderer(it) },
                        continuation = contents.musicShelfContinuation.continuations?.getContinuation(),
                    )
                }
            }
        }

    suspend fun libraryRecentActivity(): Result<LibraryPage> =
        runCatching {
            val continuation = LibraryFilter.FILTER_RECENT_ACTIVITY.value

            val response =
                innerTube
                    .browse(
                        client = WEB_REMIX,
                        continuation = continuation,
                        setLogin = true,
                    ).body<BrowseResponse>()

            val gridItems =
                response.continuationContents
                    ?.sectionListContinuation
                    ?.contents
                    ?.firstOrNull()
                    ?.gridRenderer
                    ?.items

            if (gridItems == null) {
                return@runCatching LibraryPage(
                    items = emptyList(),
                    continuation = null,
                )
            }

            val items =
                gridItems
                    .mapNotNull {
                        it.musicTwoRowItemRenderer?.let { renderer ->
                            LibraryPage.fromMusicTwoRowItemRenderer(renderer)
                        }
                    }.toMutableList()

        /*
         * We need to fetch the artist page when accessing the library because it allows to have
         * a proper playEndpoint, which is needed to correctly report the playing indicator in
         * the home page.
         *
         * Despite this, we need to use the old thumbnail because it's the proper format for a
         * square picture, which is what we need.
         */
            items.forEachIndexed { index, item ->
                if (item is ArtistItem) {
                    artist(item.id).getOrNull()?.artist?.let { fetchedArtist ->
                        items[index] = fetchedArtist.copy(thumbnail = item.thumbnail)
                    }
                }
            }

            LibraryPage(
                items = items,
                continuation = null,
            )
        }

    suspend fun getChartsPage(continuation: String? = null): Result<ChartsPage> =
        runCatching {
            val rawResponse =
                innerTube
                    .browse(
                        client = WEB_REMIX,
                        browseId = "FEmusic_charts",
                        params = "ggMGCgQIgAQ%3D",
                        continuation = continuation,
                    ).body<BrowseResponse>()
            val response = com.listrovia.innertube.InnerTubeStreamFilterLayer.pruneBrowseResponse(rawResponse)

            val sections = mutableListOf<ChartsPage.ChartSection>()

            response.contents
                ?.singleColumnBrowseResultsRenderer
                ?.tabs
                ?.firstOrNull()
                ?.tabRenderer
                ?.content
                ?.sectionListRenderer
                ?.contents
                ?.forEach { content ->

                    content.musicCarouselShelfRenderer?.let { renderer ->
                        val title =
                            renderer.header
                                ?.musicCarouselShelfBasicHeaderRenderer
                                ?.title
                                ?.runs
                                ?.firstOrNull()
                                ?.text
                                ?: return@forEach

                        val items =
                            renderer.contents
                                .mapNotNull { item ->
                                    when {
                                        item.musicResponsiveListItemRenderer != null -> {
                                            convertToChartItem(item.musicResponsiveListItemRenderer)
                                        }

                                        item.musicTwoRowItemRenderer != null -> {
                                            convertMusicTwoRowItem(item.musicTwoRowItemRenderer)
                                        }

                                        else -> {
                                            null
                                        }
                                    }
                                }.filterNotNull()
                                .filter { com.listrovia.innertube.SongContentModerator.isItemAllowed(it) }

                        if (items.isNotEmpty()) {
                            sections.add(
                                ChartsPage.ChartSection(
                                    title = title,
                                    items = items,
                                    chartType = determineChartType(title),
                                ),
                            )
                        }
                    }

                    content.gridRenderer?.let { renderer ->
                        val title =
                            renderer.header
                                ?.gridHeaderRenderer
                                ?.title
                                ?.runs
                                ?.firstOrNull()
                                ?.text
                                ?: return@let

                        val items =
                            renderer.items
                                .mapNotNull { item ->
                                    item.musicTwoRowItemRenderer?.let { renderer ->
                                        convertMusicTwoRowItem(renderer)
                                    }
                                }.filterNotNull()
                                .filter { com.listrovia.innertube.SongContentModerator.isItemAllowed(it) }

                        if (items.isNotEmpty()) {
                            sections.add(
                                ChartsPage.ChartSection(
                                    title = title,
                                    items = items,
                                    chartType = ChartsPage.ChartType.NEW_RELEASES,
                                ),
                            )
                        }
                    }
                }

            ChartsPage(
                sections = sections,
                continuation =
                    response.continuationContents
                        ?.sectionListContinuation
                        ?.continuations
                        ?.getContinuation(),
            )
        }

    private fun determineChartType(title: String): ChartsPage.ChartType =
        when {
            title.contains("Trending", ignoreCase = true) -> ChartsPage.ChartType.TRENDING
            title.contains("Top", ignoreCase = true) -> ChartsPage.ChartType.TOP
            else -> ChartsPage.ChartType.GENRE
        }

    private fun convertToChartItem(renderer: MusicResponsiveListItemRenderer): YTItem? {
        return try {
            when {
                renderer.flexColumns.size >= 3 && renderer.videoId != null -> {
                    val firstColumn =
                        renderer.flexColumns
                            .getOrNull(0)
                            ?.musicResponsiveListItemFlexColumnRenderer
                            ?.text ?: return null

                    val secondColumn =
                        renderer.flexColumns
                            .getOrNull(1)
                            ?.musicResponsiveListItemFlexColumnRenderer
                            ?.text ?: return null

                    val titleRun = firstColumn.runs?.firstOrNull() ?: return null
                    val title = titleRun.text.takeIf { it.isNotBlank() } ?: return null

                    val artists = PageHelper.extractArtists(secondColumn.runs)
                    
                    if (artists.isEmpty()) {
                        Timber.w("convertMusicResponsiveListItemRenderer: Song '$title' (id=${renderer.videoId}) has EMPTY artists list")
                    }

                    val thirdColumn =
                        renderer.flexColumns
                            .getOrNull(2)
                            ?.musicResponsiveListItemFlexColumnRenderer
                            ?.text

                    SongItem(
                        id = renderer.videoId!!,
                        title = title,
                        artists = artists,
                        thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        musicVideoType = renderer.musicVideoType,
                        explicit =
                            renderer.badges?.any {
                                it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                            } == true,
                        chartPosition =
                            thirdColumn
                                ?.runs
                                ?.firstOrNull()
                                ?.text
                                ?.toIntOrNull(),
                        chartChange = thirdColumn?.runs?.getOrNull(1)?.text,
                    )
                }

                else -> {
                    null
                }
            }
        } catch (e: Exception) {
            println("Error converting chart item: ${e.message}\n${Json.encodeToString(renderer)}")
            null
        }
    }

    private fun convertMusicTwoRowItem(renderer: MusicTwoRowItemRenderer): YTItem? {
        return try {
            when {
                renderer.isSong -> {
                    val subtitle = renderer.subtitle?.runs ?: return null
                    val title = renderer.title.runs?.firstOrNull()?.text ?: return null
                    val artists = PageHelper.extractArtists(subtitle)
                    val videoId = renderer.navigationEndpoint.watchEndpoint?.videoId ?: return null
                    
                    if (artists.isEmpty()) {
                        Timber.w("convertMusicTwoRowItem: Song '$title' (id=$videoId) has EMPTY artists list from ${subtitle.size} subtitle runs")
                    }
                    
                    SongItem(
                        id = videoId,
                        title = title,
                        artists = artists,
                        thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        musicVideoType = renderer.musicVideoType,
                        explicit =
                            renderer.subtitleBadges?.any {
                                it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                            } == true,
                    )
                }

                renderer.isAlbum -> {
                    AlbumItem(
                        browseId = renderer.navigationEndpoint.browseEndpoint?.browseId ?: return null,
                        playlistId =
                            renderer.thumbnailOverlay
                                ?.musicItemThumbnailOverlayRenderer
                                ?.content
                                ?.musicPlayButtonRenderer
                                ?.playNavigationEndpoint
                                ?.watchPlaylistEndpoint
                                ?.playlistId ?: return null,
                        title =
                            renderer.title.runs
                                ?.firstOrNull()
                                ?.text ?: return null,
                        artists =
                            renderer.subtitle?.runs?.oddElements()?.drop(1)?.mapNotNull {
                                it.navigationEndpoint?.browseEndpoint?.browseId?.let { id ->
                                    Artist(name = it.text, id = id)
                                }
                            },
                        year =
                            renderer.subtitle
                                ?.runs
                                ?.lastOrNull()
                                ?.text
                                ?.toIntOrNull(),
                        thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        explicit =
                            renderer.subtitleBadges?.any {
                                it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                            } == true,
                    )
                }

                else -> {
                    null
                }
            }
        } catch (e: Exception) {
            println("Error converting two row item: ${e.message}\n${Json.encodeToString(renderer)}")
            null
        }
    }

    suspend fun musicHistory() =
        runCatching {
            val response =
                innerTube
                    .browse(
                        client = WEB_REMIX,
                        browseId = "FEmusic_history",
                        setLogin = true,
                    ).body<BrowseResponse>()

            HistoryPage(
                sections =
                    response.contents
                        ?.singleColumnBrowseResultsRenderer
                        ?.tabs
                        ?.firstOrNull()
                        ?.tabRenderer
                        ?.content
                        ?.sectionListRenderer
                        ?.contents
                        ?.mapNotNull {
                            it.musicShelfRenderer?.let { musicShelfRenderer ->
                                HistoryPage.fromMusicShelfRenderer(musicShelfRenderer)
                            }
                        },
            )
        }

    /**
     * Fetch podcast discovery/recommendations page.
     * Returns sections like "Popular shows", "Popular episodes", category sections.
     */
    suspend fun podcastDiscover(): Result<HomePage> =
        runCatching {
            val rawResponse =
                innerTube
                    .browse(
                        client = WEB_REMIX,
                        browseId = "FEmusic_non_music_audio",
                        setLogin = true,
                    ).body<BrowseResponse>()
            val response = com.listrovia.innertube.InnerTubeStreamFilterLayer.pruneBrowseResponse(rawResponse)

            val sectionListRenderer =
                response.contents
                    ?.singleColumnBrowseResultsRenderer
                    ?.tabs
                    ?.firstOrNull()
                    ?.tabRenderer
                    ?.content
                    ?.sectionListRenderer
            val carousels = sectionListRenderer?.contents?.mapNotNull { it.musicCarouselShelfRenderer } ?: emptyList()
            val sections =
                carousels.mapNotNull {
                    HomePage.Section.fromMusicCarouselShelfRenderer(it)
                }
            val chips =
                sectionListRenderer?.header?.chipCloudRenderer?.chips?.mapNotNull {
                    HomePage.Chip.fromChipCloudChipRenderer(it)
                }
            val continuation = sectionListRenderer?.continuations?.getContinuation()

            HomePage(chips, sections, continuation)
        }

    suspend fun likeVideo(
        videoId: String,
        like: Boolean,
    ) = runCatching {
        if (like) {
            innerTube.likeVideo(WEB_REMIX, videoId)
        } else {
            innerTube.unlikeVideo(WEB_REMIX, videoId)
        }
    }

    suspend fun likePlaylist(
        playlistId: String,
        like: Boolean,
    ) = runCatching {
        if (like) {
            innerTube.likePlaylist(WEB_REMIX, playlistId)
        } else {
            innerTube.unlikePlaylist(WEB_REMIX, playlistId)
        }
    }

    suspend fun subscribeChannel(
        channelId: String,
        subscribe: Boolean,
        params: String? = null,
    ) = runCatching {
        // Default params from YouTube Music API - required for subscription to work
        val subscribeParams = params ?: "EgIIAhgA"
        if (subscribe) {
            innerTube.subscribeChannel(WEB_REMIX, channelId, subscribeParams)
        } else {
            innerTube.unsubscribeChannel(WEB_REMIX, channelId, subscribeParams)
        }
    }

    /**
     * Save a podcast show to library.
     * Uses likePlaylist API. Podcast IDs are "MPSP<playlistId>".
     */
    suspend fun savePodcast(
        podcastId: String,
        save: Boolean,
    ) = runCatching {
        val playlistId = podcastId.removePrefix("MPSP")
        Timber.d("[PODCAST_API] savePodcast: podcastId=$podcastId, playlistId=$playlistId, save=$save")
        if (save) {
            innerTube.likePlaylist(WEB_REMIX, playlistId)
        } else {
            innerTube.unlikePlaylist(WEB_REMIX, playlistId)
        }
    }

    /**
     * Add episode to "Episodes for Later" playlist (SE).
     */
    suspend fun addEpisodeToSavedEpisodes(videoId: String) =
        runCatching {
            innerTube.addToPlaylist(WEB_REMIX, "SE", videoId)
        }

    /**
     * Remove episode from "Episodes for Later" playlist (SE).
     * Note: setVideoId is required for removal and must be obtained from the playlist response.
     */
    suspend fun removeEpisodeFromSavedEpisodes(
        videoId: String,
        setVideoId: String,
    ) = runCatching {
        innerTube.removeFromPlaylist(WEB_REMIX, "SE", videoId, setVideoId)
    }

    suspend fun libraryPodcastChannels(): Result<LibraryPage> {
        Timber.d("[PODCAST_API] libraryPodcastChannels: calling browse with FEmusic_library_non_music_audio_channels_list")
        return runCatching {
            val response =
                innerTube
                    .browse(
                        client = WEB_REMIX,
                        browseId = "FEmusic_library_non_music_audio_channels_list",
                        setLogin = true,
                    ).body<BrowseResponse>()

            val contentList =
                response.contents
                    ?.singleColumnBrowseResultsRenderer
                    ?.tabs
                    ?.firstOrNull()
                    ?.tabRenderer
                    ?.content
                    ?.sectionListRenderer
                    ?.contents ?: emptyList()

            val items =
                contentList.flatMap { content ->
                    when {
                        content.gridRenderer != null -> {
                            content.gridRenderer.items
                                .mapNotNull(GridRenderer.Item::musicTwoRowItemRenderer)
                                .mapNotNull { LibraryPage.fromMusicTwoRowItemRenderer(it) }
                        }

                        content.musicShelfRenderer != null -> {
                            content.musicShelfRenderer.contents
                                ?.mapNotNull(MusicShelfRenderer.Content::musicResponsiveListItemRenderer)
                                ?.mapNotNull { LibraryPage.fromMusicResponsiveListItemRenderer(it) }
                                ?: emptyList()
                        }

                        content.musicCarouselShelfRenderer != null -> {
                            content.musicCarouselShelfRenderer.contents.mapNotNull { content ->
                                content.musicTwoRowItemRenderer?.let { renderer ->
                                    LibraryPage.fromMusicTwoRowItemRenderer(renderer)
                                } ?: content.musicMultiRowListItemRenderer?.let { renderer ->
                                    PodcastPage.fromMusicMultiRowListItemRenderer(renderer)
                                } ?: content.musicResponsiveListItemRenderer?.let { renderer ->
                                    LibraryPage.fromMusicResponsiveListItemRenderer(renderer)
                                }
                            }
                        }

                        else -> {
                            emptyList()
                        }
                    }
                }

            LibraryPage(
                items = items,
                continuation = null,
            )
        }.also { result ->
            result.onFailure { e -> Timber.e(e, "[PODCAST_API] libraryPodcastChannels FAILED") }
            result.onSuccess { Timber.d("[PODCAST_API] libraryPodcastChannels SUCCESS: ${it.items.size} items") }
        }
    }

    suspend fun libraryPodcastEpisodes(): Result<LibraryPage> {
        Timber.d("[PODCAST_API] libraryPodcastEpisodes: calling browse with FEmusic_library_non_music_audio_list")
        return runCatching {
            val response =
                innerTube
                    .browse(
                        client = WEB_REMIX,
                        browseId = "FEmusic_library_non_music_audio_list",
                        setLogin = true,
                    ).body<BrowseResponse>()

            val contents =
                response.contents
                    ?.singleColumnBrowseResultsRenderer
                    ?.tabs
                    ?.firstOrNull()
                    ?.tabRenderer
                    ?.content
                    ?.sectionListRenderer
                    ?.contents
                    ?.firstOrNull()

            val items =
                when {
                    contents?.gridRenderer != null -> {
                        contents.gridRenderer.items
                            .mapNotNull(GridRenderer.Item::musicTwoRowItemRenderer)
                            .mapNotNull { LibraryPage.fromMusicTwoRowItemRenderer(it) }
                    }

                    contents?.musicShelfRenderer != null -> {
                        contents.musicShelfRenderer.contents
                            ?.mapNotNull(MusicShelfRenderer.Content::musicResponsiveListItemRenderer)
                            ?.mapNotNull { LibraryPage.fromMusicResponsiveListItemRenderer(it) }
                            ?: emptyList()
                    }

                    else -> {
                        emptyList()
                    }
                }

            LibraryPage(
                items = items,
                continuation = null,
            )
        }.also { result ->
            result.onFailure { e -> Timber.e(e, "[PODCAST_API] libraryPodcastEpisodes FAILED") }
            result.onSuccess { Timber.d("[PODCAST_API] libraryPodcastEpisodes SUCCESS: ${it.items.size} items") }
        }
    }

    /**
     * Fetch saved podcast shows from library.
     * Uses FEmusic_library_non_music_audio_list and filters to only PodcastItem.
     */
    suspend fun savedPodcastShows(): Result<List<PodcastItem>> =
        runCatching {
            val libraryPage = libraryPodcastEpisodes().getOrThrow()
            libraryPage.items.filterIsInstance<PodcastItem>()
        }

    /**
     * Fetch "New Episodes" auto-playlist (VLRDPN).
     * Returns new episodes from saved/subscribed podcasts.
     */
    suspend fun newEpisodes(): Result<List<SongItem>> {
        Timber.d("[PODCAST_API] newEpisodes: calling browse with VLRDPN")
        return runCatching {
            val response =
                innerTube
                    .browse(
                        client = WEB_REMIX,
                        browseId = "VLRDPN",
                        setLogin = true,
                    ).body<BrowseResponse>()

            val twoColumn = response.contents?.twoColumnBrowseResultsRenderer

            // RDPN may have content in either tabs (first tab) or secondaryContents
            val sections = mutableListOf<SectionListRenderer.Content>()

            // Check tabs path
            twoColumn?.tabs
                ?.firstOrNull()
                ?.tabRenderer
                ?.content
                ?.sectionListRenderer
                ?.contents
                ?.let { sections.addAll(it) }

            // Check secondaryContents path (original working path for RDPN)
            // Use TwoColumnBrowseResultsRenderer's inner SectionListRenderer types
            twoColumn?.secondaryContents?.sectionListRenderer?.contents?.let { secContents ->
                sections.addAll(secContents.map { secContent ->
                    SectionListRenderer.Content(
                        musicCarouselShelfRenderer = null,
                        musicShelfRenderer = secContent.musicShelfRenderer,
                        musicCardShelfRenderer = null,
                        musicPlaylistShelfRenderer = secContent.musicPlaylistShelfRenderer,
                        musicDescriptionShelfRenderer = null,
                        musicResponsiveHeaderRenderer = null,
                        musicEditablePlaylistDetailHeaderRenderer = null,
                        gridRenderer = null,
                        itemSectionRenderer = null,
                    )
                })
            }

            Timber.d("[PODCAST_API] newEpisodes: ${sections.size} section(s) found (${twoColumn?.tabs?.size ?: 0} tab(s), secondary has ${twoColumn?.secondaryContents?.sectionListRenderer?.contents?.size ?: 0})")

            // Log all section types
            sections.forEachIndexed { idx, section ->
                Timber.d("[PODCAST_API] section[$idx]: hasCarousel=${section.musicCarouselShelfRenderer != null} hasShelf=${section.musicShelfRenderer != null} hasPlaylistShelf=${section.musicPlaylistShelfRenderer != null} hasCardShelf=${section.musicCardShelfRenderer != null} hasGrid=${section.gridRenderer != null} hasItemSection=${section.itemSectionRenderer != null}")
                section.musicCarouselShelfRenderer?.let { carousel ->
                    val carouselTitle = carousel.header?.musicCarouselShelfBasicHeaderRenderer?.title?.runs?.joinToString("") { it.text }
                    Timber.d("[PODCAST_API]   carousel title=$carouselTitle, items=${carousel.contents?.size}")
                }
                section.musicShelfRenderer?.let { shelf ->
                    Timber.d("[PODCAST_API]   shelf title=${shelf.title?.runs?.joinToString("") { it.text }}, items=${shelf.contents?.size}")
                    // Log first item's subtitle fields
                    shelf.contents?.firstOrNull()?.musicMultiRowListItemRenderer?.let { r ->
                        val subtitleText = r.subtitle?.runs?.joinToString("") { it.text }
                        val secondSubtitleText = r.secondSubtitle?.runs?.joinToString("") { it.text }
                        val secondarySubtitleText = r.secondarySubtitle?.runs?.joinToString("") { it.text }
                        Timber.d("[PODCAST_API]   first item: subtitle='$subtitleText' secondSubtitle='$secondSubtitleText' secondarySubtitle='$secondarySubtitleText'")
                        val subRuns = r.subtitle?.runs
                        Timber.d("[PODCAST_API]   subtitle runs: ${subRuns?.map { "text='${it.text}' nav=${it.navigationEndpoint?.browseEndpoint?.browseId}" }}")
                        val secRuns = r.secondSubtitle?.runs
                        Timber.d("[PODCAST_API]   secondSubtitle runs: ${secRuns?.map { "text='${it.text}' nav=${it.navigationEndpoint?.browseEndpoint?.browseId}" }}")
                        val menuItems = r.menu?.menuRenderer?.items?.mapIndexed { idx, item ->
                            val navText = item.menuNavigationItemRenderer?.text?.runs?.joinToString("") { it.text }
                            val navId = item.menuNavigationItemRenderer?.navigationEndpoint?.browseEndpoint?.browseId
                            val navPageType = item.menuNavigationItemRenderer?.navigationEndpoint?.browseEndpoint
                                ?.browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType
                            val svcText = item.menuServiceItemRenderer?.text?.runs?.joinToString("") { it.text }
                            val toggleIcon = item.toggleMenuServiceItemRenderer?.defaultIcon?.iconType
                            "[$idx](navText='$navText' navId=$navId pageType=$navPageType svcText='$svcText' toggleIcon=$toggleIcon)"
                        }
                        Timber.d("[PODCAST_API]   first item detailed menu: $menuItems")
                    }
                }
                section.musicPlaylistShelfRenderer?.let { ps ->
                    Timber.d("[PODCAST_API]   playlistShelf playlistId=${ps.playlistId}, items=${ps.contents?.size}")
                }
            }

            // Check singleColumnBrowseResultsRenderer too
            val singleColumn = response.contents?.singleColumnBrowseResultsRenderer
            Timber.d("[PODCAST_API] singleColumn is null=${singleColumn == null}")
            if (singleColumn?.tabs != null) {
                singleColumn.tabs.forEachIndexed { idx, tab ->
                    val tabTitle = tab.tabRenderer.title
                    val tabContent = tab.tabRenderer.content
                    val tabSectionList = tabContent?.sectionListRenderer
                    val tabSectionsSize = tabSectionList?.contents?.size ?: 0
                    Timber.d("[PODCAST_API] singleColumn tab[$idx]: title=$tabTitle, sections=$tabSectionsSize")
                    tabSectionList?.contents?.forEachIndexed { sIdx, section ->
                        val shelf = section.musicShelfRenderer
                        val carousel = section.musicCarouselShelfRenderer
                        if (shelf != null) {
                            Timber.d("[PODCAST_API]   singleCol section[$sIdx] shelf title=${shelf.title?.runs?.joinToString("") { it.text }}, items=${shelf.contents?.size}")
                        }
                        if (carousel != null) {
                            val carTitle = carousel.header?.musicCarouselShelfBasicHeaderRenderer?.title?.runs?.joinToString("") { it.text }
                            Timber.d("[PODCAST_API]   singleCol section[$sIdx] carousel title=$carTitle, items=${carousel.contents?.size}")
                        }
                    }
                }
            }

            // Extract episodes from all section types
            val episodesList = mutableListOf<SongItem>()

            // Helper to process musicShelf
            fun processShelf(shelf: MusicShelfRenderer, sectionPodcastName: String? = null) {
                val podcastName = sectionPodcastName ?: shelf.title?.runs?.joinToString("") { it.text }
                shelf.contents
                    ?.mapNotNull { it.musicMultiRowListItemRenderer }
                    ?.forEach { renderer ->
                        if (renderer.onTap?.watchEndpoint?.videoId == null) return@forEach
                        val title = renderer.title?.runs?.firstOrNull()?.text ?: return@forEach

                        val subtitleGroups = renderer.subtitle?.runs?.splitBySeparator()
                        val duration = subtitleGroups
                            ?.lastOrNull { group ->
                                group.firstOrNull()?.text?.parseTime() != null
                            }
                            ?.firstOrNull()
                            ?.text
                            ?.parseTime()

                        // Strategy 1: secondSubtitle / secondarySubtitle often has the podcast name
                        var artistName: String? = renderer.secondSubtitle?.runs?.joinToString("") { it.text }
                        if (artistName.isNullOrBlank()) {
                            artistName = renderer.secondarySubtitle?.runs?.joinToString("") { it.text }
                        }

                        // Strategy 2: Extract browseId from menu items with browse endpoints
                        var browseId: String? = null
                        val actionLabels = setOf("Save to playlist", "Share", "Remove from library",
                            "Add to library", "Don't recommend this episode", "Start radio",
                            "Go to podcast", "Go to artist", "Go to album")
                        renderer.menu?.menuRenderer?.items?.forEach { item ->
                            val text = item.menuNavigationItemRenderer?.text?.runs?.joinToString("") { it.text }
                            val navEp = item.menuNavigationItemRenderer?.navigationEndpoint?.browseEndpoint
                            if (navEp != null) {
                                if (browseId == null) browseId = navEp.browseId
                                if (text != null && text !in actionLabels && artistName == null) {
                                    artistName = text
                                }
                            }
                        }

                        // Strategy 3: Fallback to section header's podcast name
                        if (artistName.isNullOrBlank()) artistName = podcastName

                        val currentArtistName = artistName
                        val artists = if (!currentArtistName.isNullOrBlank()) {
                            listOf(Artist(name = currentArtistName, id = browseId))
                        } else emptyList()

                        episodesList.add(
                            SongItem(
                                id = renderer.onTap.watchEndpoint.videoId,
                                title = title,
                                artists = artists,
                                album = null,
                                duration = duration,
                                thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: "",
                                isEpisode = true,
                            )
                        )
                    }
            }

            // Process both sections and carousels
            sections.forEach { section ->
                // Process musicShelfRenderer
                section.musicShelfRenderer?.let { shelf ->
                    processShelf(shelf)
                }
                // Process musicCarouselShelfRenderer - each carousel is a podcast group
                section.musicCarouselShelfRenderer?.let { carousel ->
                    val carouselTitle = carousel.header?.musicCarouselShelfBasicHeaderRenderer?.title?.runs?.joinToString("") { it.text }
                    carousel.contents?.forEach { carouselContent ->
                        carouselContent.musicMultiRowListItemRenderer?.let { renderer ->
                            if (renderer.onTap?.watchEndpoint?.videoId == null) return@let
                            val title = renderer.title?.runs?.firstOrNull()?.text ?: return@let

                            val subtitleGroups = renderer.subtitle?.runs?.splitBySeparator()
                            val duration = subtitleGroups
                                ?.lastOrNull { group ->
                                    group.firstOrNull()?.text?.parseTime() != null
                                }
                                ?.firstOrNull()
                                ?.text
                                ?.parseTime()

                            // Try secondSubtitle first, then carousel title
                            var artistName: String? = renderer.secondSubtitle?.runs?.joinToString("") { it.text }
                            if (artistName.isNullOrBlank()) {
                                artistName = renderer.secondarySubtitle?.runs?.joinToString("") { it.text }
                            }
                            if (artistName.isNullOrBlank()) artistName = carouselTitle

                            val currentArtistName = artistName
                            val artists = if (!currentArtistName.isNullOrBlank()) {
                                listOf(Artist(name = currentArtistName, id = null))
                            } else emptyList()

                            episodesList.add(
                                SongItem(
                                    id = renderer.onTap.watchEndpoint.videoId,
                                    title = title,
                                    artists = artists,
                                    album = null,
                                    duration = duration,
                                    thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: "",
                                    isEpisode = true,
                                )
                            )
                        }
                    }
                }
            }

            // Enrich items that have no artist name by calling getMediaInfo (next endpoint)
            val itemsToEnrich = episodesList.filter { it.artists.isEmpty() }
            if (itemsToEnrich.isNotEmpty()) {
                Timber.d("[PODCAST_API] Enriching ${itemsToEnrich.size} items via getMediaInfo")
                coroutineScope {
                    itemsToEnrich
                        .map { episode ->
                            async {
                                val mediaInfo = innerTube.getMediaInfo(episode.id).getOrNull()
                                if (mediaInfo?.author != null) {
                                    episode.copy(
                                        artists = listOf(Artist(name = mediaInfo.author, id = mediaInfo.authorId)),
                                    )
                                } else episode
                            }
                        }
                        .awaitAll()
                        .forEach { enriched ->
                            val idx = episodesList.indexOfFirst { it.id == enriched.id }
                            if (idx >= 0) episodesList[idx] = enriched
                        }
                }
            }

            Timber.d("[PODCAST_API] newEpisodes SUCCESS: ${episodesList.size} items")
            episodesList
        }.also { result ->
            result.onFailure { e -> Timber.e(e, "[PODCAST_API] newEpisodes FAILED") }
        }
    }

    /**
     * Fetch the RDPN "New Episodes" playlist info (title + thumbnail).
     * Uses the same VLRDPN browse call as [newEpisodes] but parses the header instead.
     * Falls back to the first episode thumbnail if no header thumbnail is found.
     */
    suspend fun newEpisodesPlaylistInfo(): Result<PlaylistItem> =
        runCatching {
            val response =
                innerTube
                    .browse(
                        client = WEB_REMIX,
                        browseId = "VLRDPN",
                        setLogin = true,
                    ).body<BrowseResponse>()

            // Try all known header renderers in priority order
            val thumbnail: String? =
                response.header
                    ?.musicImmersiveHeaderRenderer
                    ?.thumbnail
                    ?.musicThumbnailRenderer
                    ?.getThumbnailUrl()
                    ?: response.header
                        ?.musicVisualHeaderRenderer
                        ?.thumbnail
                        ?.musicThumbnailRenderer
                        ?.getThumbnailUrl()
                    ?: response.header
                        ?.musicDetailHeaderRenderer
                        ?.thumbnail
                        ?.croppedSquareThumbnailRenderer
                        ?.thumbnail
                        ?.thumbnails
                        ?.lastOrNull()
                        ?.url
                    // Fall back: thumbnail of the first episode in the list
                    ?: response.contents
                        ?.twoColumnBrowseResultsRenderer
                        ?.secondaryContents
                        ?.sectionListRenderer
                        ?.contents
                        ?.firstOrNull()
                        ?.musicShelfRenderer
                        ?.contents
                        ?.firstOrNull()
                        ?.musicMultiRowListItemRenderer
                        ?.thumbnail
                        ?.musicThumbnailRenderer
                        ?.getThumbnailUrl()

            val title =
                response.header
                    ?.musicImmersiveHeaderRenderer
                    ?.title
                    ?.runs
                    ?.joinToString("") { it.text }
                    ?: response.header
                        ?.musicVisualHeaderRenderer
                        ?.title
                        ?.runs
                        ?.joinToString("") { it.text }
                    ?: "New Episodes"

            PlaylistItem(
                id = "RDPN",
                title = title,
                author = null,
                songCountText = null,
                thumbnail = thumbnail,
                playEndpoint = null,
                shuffleEndpoint = null,
                radioEndpoint = null,
            )
        }

    /**
     * Fetch "Episodes for Later" playlist (VLSE).
     * Returns manually saved episodes.
     */
    suspend fun episodesForLater(): Result<List<SongItem>> =
        runCatching {
            Timber.d("[PODCAST_API] episodesForLater: calling browse with VLSE")
            val response =
                innerTube
                    .browse(
                        client = WEB_REMIX,
                        browseId = "VLSE",
                        setLogin = true,
                    ).body<BrowseResponse>()

            // VLSE uses musicPlaylistShelfRenderer, not musicShelfRenderer
            val contents =
                response.contents
                    ?.twoColumnBrowseResultsRenderer
                    ?.secondaryContents
                    ?.sectionListRenderer
                    ?.contents
                    ?.firstOrNull()

            val shelfContents =
                contents?.musicPlaylistShelfRenderer?.contents
                    ?: contents?.musicShelfRenderer?.contents

            // Parse musicResponsiveListItemRenderer (standard playlist format)
            shelfContents
                ?.mapNotNull { it.musicResponsiveListItemRenderer }
                ?.mapNotNull { renderer ->
                    val videoId = renderer.videoId ?: return@mapNotNull null
                    val setVideoId = renderer.playlistSetVideoId
                    val title =
                        renderer.flexColumns
                            .firstOrNull()
                            ?.musicResponsiveListItemFlexColumnRenderer
                            ?.text
                            ?.runs
                            ?.firstOrNull()
                            ?.text
                            ?: return@mapNotNull null

                    // Subtitle is typically "Channel • Date" or "Channel • Date • Duration"
                    val subtitleGroups = renderer.flexColumns
                        .getOrNull(1)
                        ?.musicResponsiveListItemFlexColumnRenderer
                        ?.text
                        ?.runs
                        ?.splitBySeparator()

                    // Channel is the first group with a navigationEndpoint, or just the first group
                    val artistRun = subtitleGroups
                        ?.firstOrNull { group ->
                            group.firstOrNull()?.navigationEndpoint?.browseEndpoint != null
                        }
                        ?.firstOrNull()
                        ?: subtitleGroups?.firstOrNull()?.firstOrNull()

                    val duration = subtitleGroups
                        ?.drop(1)
                        ?.firstOrNull { group ->
                            group.firstOrNull()?.text?.parseTime() != null
                        }
                        ?.firstOrNull()
                        ?.text
                        ?.parseTime()
                        // Fallback to fixedColumns for duration
                        ?: renderer.fixedColumns?.firstOrNull()
                            ?.musicResponsiveListItemFlexColumnRenderer?.text
                            ?.runs?.firstOrNull()
                            ?.text?.parseTime()

                    SongItem(
                        id = videoId,
                        title = title,
                        artists =
                            artistRun?.let { listOf(Artist(name = it.text, id = it.navigationEndpoint?.browseEndpoint?.browseId)) }
                                ?: emptyList(),
                        album = null,
                        duration = duration,
                        thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: "",
                        setVideoId = setVideoId,
                        isEpisode = true,
                    )
                } ?: emptyList()
        }

    /**
     * Fetch "Continue Listening" / Resume Playback.
     * Returns partially played episodes for resumption.
     */
    suspend fun continueListening(): Result<List<SongItem>> =
        runCatching {
            val response =
                innerTube
                    .browse(
                        client = WEB_REMIX,
                        browseId = "FEmusic_listening_review",
                        setLogin = true,
                    ).body<BrowseResponse>()

            response.contents
                ?.singleColumnBrowseResultsRenderer
                ?.tabs
                ?.firstOrNull()
                ?.tabRenderer
                ?.content
                ?.sectionListRenderer
                ?.contents
                ?.flatMap { section ->
                    section.musicShelfRenderer?.contents?.mapNotNull { content ->
                        content.musicResponsiveListItemRenderer?.let { renderer ->
                            val videoId = renderer.videoId ?: return@mapNotNull null
                            val title =
                                renderer.flexColumns
                                    .firstOrNull()
                                    ?.musicResponsiveListItemFlexColumnRenderer
                                    ?.text
                                    ?.runs
                                    ?.firstOrNull()
                                    ?.text
                                    ?: return@mapNotNull null
                            val artistRun =
                                renderer.flexColumns
                                    .getOrNull(1)
                                    ?.musicResponsiveListItemFlexColumnRenderer
                                    ?.text
                                    ?.runs
                                    ?.firstOrNull()
                            SongItem(
                                id = videoId,
                                title = title,
                                artists =
                                    artistRun?.let { listOf(Artist(name = it.text, id = it.navigationEndpoint?.browseEndpoint?.browseId)) }
                                        ?: emptyList(),
                                album = null,
                                duration = null,
                                thumbnail = renderer.thumbnail?.musicThumbnailRenderer?.getThumbnailUrl() ?: "",
                                isEpisode = true,
                            )
                        }
                    } ?: emptyList()
                } ?: emptyList()
        }

    suspend fun getChannelId(browseId: String): String {
        artist(browseId).onSuccess {
            return it.artist.channelId ?: ""
        }
        return ""
    }

    suspend fun addToPlaylist(
        playlistId: String,
        videoId: String,
    ) = runCatching {
        innerTube.addToPlaylist(WEB_REMIX, playlistId, videoId)
    }

    suspend fun addPlaylistToPlaylist(
        playlistId: String,
        addPlaylistId: String,
    ) = runCatching {
        innerTube.addPlaylistToPlaylist(WEB_REMIX, playlistId, addPlaylistId)
    }

    suspend fun removeFromPlaylist(
        playlistId: String,
        videoId: String,
        setVideoId: String,
    ) = runCatching {
        innerTube.removeFromPlaylist(WEB_REMIX, playlistId, videoId, setVideoId)
    }

    suspend fun moveSongPlaylist(
        playlistId: String,
        setVideoId: String,
        successorSetVideoId: String?,
    ) = runCatching {
        innerTube.moveSongPlaylist(WEB_REMIX, playlistId, setVideoId, successorSetVideoId)
    }

    fun createPlaylist(title: String) =
        runBlocking {
            innerTube.createPlaylist(WEB_REMIX, title).body<CreatePlaylistResponse>().playlistId
        }

    suspend fun renamePlaylist(
        playlistId: String,
        name: String,
    ) = runCatching {
        innerTube.renamePlaylist(WEB_REMIX, playlistId, name)
    }

    suspend fun uploadCustomThumbnailLink(
        playlistId: String,
        image: ByteArray,
    ) = runCatching {
        val uploadUrl = innerTube.getUploadCustomThumbnailLink(WEB_REMIX, image.size).headers["x-guploader-uploadid"]
        val blobReq =
            innerTube.uploadCustomThumbnail(
                WEB_REMIX,
                uploadUrl!!,
                image,
            )
        val blobId = Json.decodeFromString<ImageUploadResponse>(blobReq.bodyAsText()).encryptedBlobId
        innerTube
            .setThumbnailPlaylist(
                WEB_REMIX,
                playlistId,
                blobId,
            ).body<EditPlaylistResponse>()
            .newHeader
            ?.musicEditablePlaylistDetailHeaderRenderer
            ?.header
            ?.musicResponsiveHeaderRenderer
            ?.thumbnail
            ?.musicThumbnailRenderer
            ?.getThumbnailUrl()
    }

    suspend fun removeThumbnailPlaylist(playlistId: String) =
        runCatching {
            innerTube
                .removeThumbnailPlaylist(
                    WEB_REMIX,
                    playlistId,
                ).body<EditPlaylistResponse>()
                .newHeader
                ?.musicEditablePlaylistDetailHeaderRenderer
                ?.header
                ?.musicResponsiveHeaderRenderer
                ?.thumbnail
                ?.musicThumbnailRenderer
                ?.getThumbnailUrl()
        }

    suspend fun deletePlaylist(playlistId: String) =
        runCatching {
            innerTube.deletePlaylist(WEB_REMIX, playlistId)
        }

    suspend fun player(
        videoId: String,
        playlistId: String? = null,
        client: YouTubeClient,
        signatureTimestamp: Int? = null,
        poToken: String? = null,
        useVisitorData: Boolean = true,
    ): Result<PlayerResponse> =
        runCatching {
            innerTube.player(client, videoId, playlistId, signatureTimestamp, poToken, useVisitorData).body<PlayerResponse>()
        }

    suspend fun registerPlayback(
        playlistId: String? = null,
        playbackTracking: String,
    ) = runCatching {
        val cpn =
            (1..16)
                .map {
                    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_"[
                        Random.Default.nextInt(
                            0,
                            64,
                        ),
                    ]
                }.joinToString("")

        innerTube.registerPlayback(
            url = playbackTracking,
            playlistId = playlistId,
            cpn = cpn,
        )
    }

    suspend fun next(
        endpoint: WatchEndpoint,
        continuation: String? = null,
    ): Result<NextResult> =
        runCatching {
            val rawResponse =
                innerTube
                    .next(
                        WEB_REMIX,
                        endpoint.videoId,
                        endpoint.playlistId,
                        endpoint.playlistSetVideoId,
                        endpoint.index,
                        endpoint.params,
                        continuation,
                    ).body<NextResponse>()
            val response = com.listrovia.innertube.InnerTubeStreamFilterLayer.pruneNextResponse(rawResponse)
            val playlistPanelRenderer =
                response.continuationContents?.playlistPanelContinuation
                    ?: response.contents.singleColumnMusicWatchNextResultsRenderer
                        ?.tabbedRenderer
                        ?.watchNextTabbedResultsRenderer
                        ?.tabs
                        ?.get(0)
                        ?.tabRenderer
                        ?.content
                        ?.musicQueueRenderer
                        ?.content
                        ?.playlistPanelRenderer!!
            val title =
                response.contents.singleColumnMusicWatchNextResultsRenderer
                    ?.tabbedRenderer
                    ?.watchNextTabbedResultsRenderer
                    ?.tabs
                    ?.get(0)
                    ?.tabRenderer
                    ?.content
                    ?.musicQueueRenderer
                    ?.header
                    ?.musicQueueHeaderRenderer
                    ?.subtitle
                    ?.runs
                    ?.firstOrNull()
                    ?.text
            val items =
                playlistPanelRenderer.contents.mapNotNull { content ->
                    content.playlistPanelVideoRenderer
                        ?.let(NextPage::fromPlaylistPanelVideoRenderer)
                        ?.let { it to content.playlistPanelVideoRenderer.selected }
                }
            val songs = items.map { it.first }
            val currentIndex = items.indexOfFirst { it.second }.takeIf { it != -1 }

            // load automix items
            playlistPanelRenderer.contents
                .lastOrNull()
                ?.automixPreviewVideoRenderer
                ?.content
                ?.automixPlaylistVideoRenderer
                ?.navigationEndpoint
                ?.watchPlaylistEndpoint
                ?.let { watchPlaylistEndpoint ->
                    return@runCatching next(watchPlaylistEndpoint).getOrThrow().let { result ->
                        result.copy(
                            title = title,
                            items = songs + result.items,
                            lyricsEndpoint =
                                response.contents.singleColumnMusicWatchNextResultsRenderer
                                    ?.tabbedRenderer
                                    ?.watchNextTabbedResultsRenderer
                                    ?.tabs
                                    ?.getOrNull(
                                        1,
                                    )?.tabRenderer
                                    ?.endpoint
                                    ?.browseEndpoint,
                            relatedEndpoint =
                                response.contents.singleColumnMusicWatchNextResultsRenderer
                                    ?.tabbedRenderer
                                    ?.watchNextTabbedResultsRenderer
                                    ?.tabs
                                    ?.getOrNull(
                                        2,
                                    )?.tabRenderer
                                    ?.endpoint
                                    ?.browseEndpoint,
                            currentIndex = currentIndex,
                            endpoint = watchPlaylistEndpoint,
                        )
                    }
                }
            NextResult(
                title = title,
                items = songs,
                currentIndex = currentIndex,
                lyricsEndpoint =
                    response.contents.singleColumnMusicWatchNextResultsRenderer
                        ?.tabbedRenderer
                        ?.watchNextTabbedResultsRenderer
                        ?.tabs
                        ?.getOrNull(
                            1,
                        )?.tabRenderer
                        ?.endpoint
                        ?.browseEndpoint,
                relatedEndpoint =
                    response.contents.singleColumnMusicWatchNextResultsRenderer
                        ?.tabbedRenderer
                        ?.watchNextTabbedResultsRenderer
                        ?.tabs
                        ?.getOrNull(
                            2,
                        )?.tabRenderer
                        ?.endpoint
                        ?.browseEndpoint,
                continuation = playlistPanelRenderer.continuations?.getContinuation(),
                endpoint = endpoint,
            )
        }

    suspend fun lyrics(endpoint: BrowseEndpoint): Result<String?> =
        runCatching {
            val response = innerTube.browse(WEB_REMIX, endpoint.browseId, endpoint.params).body<BrowseResponse>()
            response.contents
                ?.sectionListRenderer
                ?.contents
                ?.firstOrNull { it.musicDescriptionShelfRenderer != null }
                ?.musicDescriptionShelfRenderer
                ?.description
                ?.runs
                ?.joinToString(separator = "") { it.text }
        }

    suspend fun related(endpoint: BrowseEndpoint): Result<RelatedPage> =
        runCatching {
            val rawResponse = innerTube.browse(WEB_REMIX, endpoint.browseId).body<BrowseResponse>()
            val response = com.listrovia.innertube.InnerTubeStreamFilterLayer.pruneBrowseResponse(rawResponse)
            val songs = mutableListOf<SongItem>()
            val albums = mutableListOf<AlbumItem>()
            val artists = mutableListOf<ArtistItem>()
            val playlists = mutableListOf<PlaylistItem>()
            response.contents?.sectionListRenderer?.contents?.forEach { sectionContent ->
                sectionContent.musicCarouselShelfRenderer?.contents?.forEach { content ->
                    when (
                        val item =
                            content.musicResponsiveListItemRenderer?.let(RelatedPage.Companion::fromMusicResponsiveListItemRenderer)
                                ?: content.musicTwoRowItemRenderer?.let(RelatedPage.Companion::fromMusicTwoRowItemRenderer)
                    ) {
                        is SongItem -> {
                            if (content.musicResponsiveListItemRenderer
                                    ?.overlay
                                    ?.musicItemThumbnailOverlayRenderer
                                    ?.content
                                    ?.musicPlayButtonRenderer
                                    ?.playNavigationEndpoint
                                    ?.watchEndpoint
                                    ?.watchEndpointMusicSupportedConfigs
                                    ?.watchEndpointMusicConfig
                                    ?.musicVideoType == MUSIC_VIDEO_TYPE_ATV
                            ) {
                                songs.add(item)
                            }
                        }

                        is AlbumItem -> {
                            albums.add(item)
                        }

                        is ArtistItem -> {
                            artists.add(item)
                        }

                        is PlaylistItem -> {
                            playlists.add(item)
                        }

                        is PodcastItem, is EpisodeItem -> {}

                        null -> {}
                    }
                }
            }
            RelatedPage(
                songs = songs.filter { com.listrovia.innertube.SongContentModerator.isItemAllowed(it) },
                albums = albums.filter { com.listrovia.innertube.SongContentModerator.isItemAllowed(it) },
                artists = artists.filter { com.listrovia.innertube.SongContentModerator.isItemAllowed(it) },
                playlists = playlists.filter { com.listrovia.innertube.SongContentModerator.isItemAllowed(it) },
            )
        }

    suspend fun queue(
        videoIds: List<String>? = null,
        playlistId: String? = null,
    ): Result<List<SongItem>> =
        runCatching {
            if (videoIds != null) {
                assert(videoIds.size <= MAX_GET_QUEUE_SIZE) // Max video limit
            }
            innerTube
                .getQueue(WEB_REMIX, videoIds, playlistId)
                .body<GetQueueResponse>()
                .queueDatas
                .mapNotNull {
                    it.content.playlistPanelVideoRenderer?.let { renderer ->
                        NextPage.fromPlaylistPanelVideoRenderer(renderer)
                    }
                }
        }

    suspend fun transcript(videoId: String): Result<String> =
        runCatching {
            val response = innerTube.getTranscript(WEB, videoId).body<GetTranscriptResponse>()
            response.actions
                ?.firstOrNull()
                ?.updateEngagementPanelAction
                ?.content
                ?.transcriptRenderer
                ?.body
                ?.transcriptBodyRenderer
                ?.cueGroups
                ?.joinToString(
                    separator = "\n",
                ) { group ->
                    val time =
                        group.transcriptCueGroupRenderer.cues[0]
                            .transcriptCueRenderer.startOffsetMs
                    val text =
                        group.transcriptCueGroupRenderer.cues[0]
                            .transcriptCueRenderer.cue.simpleText
                            .trim('♪')
                            .trim(' ')
                    "[%02d:%02d.%03d]$text".format(time / 60000, (time / 1000) % 60, time % 1000)
                }!!
        }

    suspend fun visitorData(): Result<String> =
        runCatching {
            Json
                .parseToJsonElement(innerTube.getSwJsData().bodyAsText().substring(5))
                .jsonArray[0]
                .jsonArray[2]
                .jsonArray
                .first {
                    (it as? JsonPrimitive)?.contentOrNull?.let { candidate ->
                        VISITOR_DATA_REGEX.containsMatchIn(candidate)
                    } ?: false
                }.jsonPrimitive.content
        }

    suspend fun accountInfo(): Result<AccountInfo> =
        runCatching {
            innerTube
                .accountMenu(WEB_REMIX)
                .body<AccountMenuResponse>()
                .actions[0]
                .openPopupAction.popup.multiPageMenuRenderer
                .header
                ?.activeAccountHeaderRenderer
                ?.toAccountInfo()!!
        }

    suspend fun feedback(tokens: List<String>): Result<Boolean> =
        runCatching {
            innerTube
                .feedback(WEB_REMIX, tokens)
                .body<FeedbackResponse>()
                .feedbackResponses
                .all { it.isProcessed }
        }

    /**
     * Add a song to library by fetching fresh feedback tokens from the next endpoint
     * This is more reliable than using cached tokens which might be stale
     */
    suspend fun addSongToLibrary(videoId: String): Result<Boolean> =
        runCatching {
            // Get fresh song data with menu tokens using next endpoint
            val nextResult = next(WatchEndpoint(videoId = videoId)).getOrThrow()
            val song =
                nextResult.items.find { it.id == videoId }
                    ?: throw Exception("Song not found in next response")

            val addToken =
                song.libraryAddToken
                    ?: throw Exception("Add to library token not available")

            feedback(listOf(addToken)).getOrThrow()
        }

    /**
     * Remove a song from library by fetching fresh feedback tokens from the next endpoint
     */
    suspend fun removeSongFromLibrary(videoId: String): Result<Boolean> =
        runCatching {
            // Get fresh song data with menu tokens using next endpoint
            val nextResult = next(WatchEndpoint(videoId = videoId)).getOrThrow()
            val song =
                nextResult.items.find { it.id == videoId }
                    ?: throw Exception("Song not found in next response")

            val removeToken =
                song.libraryRemoveToken
                    ?: throw Exception("Remove from library token not available")

            feedback(listOf(removeToken)).getOrThrow()
        }

    /**
     * Toggle song library status - adds if not in library, removes if in library
     * Uses fresh tokens fetched from the API for reliability
     */
    suspend fun toggleSongLibrary(
        videoId: String,
        addToLibrary: Boolean,
    ): Result<Boolean> =
        runCatching {
            if (addToLibrary) {
                addSongToLibrary(videoId).getOrThrow()
            } else {
                removeSongFromLibrary(videoId).getOrThrow()
            }
        }

    suspend fun getMediaInfo(videoId: String): Result<MediaInfo> =
        runCatching {
            return innerTube.getMediaInfo(videoId)
        }

    suspend fun getTasteProfile(): Result<TasteProfile> =
        runCatching {
            // Browse the taste builder page
            // Note: Full parsing requires additional model support for musicTastebuilderShelfRenderer
            // This returns an empty profile for now - can be enhanced when models are added
            innerTube
                .browse(
                    client = WEB_REMIX,
                    browseId = "FEmusic_tastebuilder",
                    setLogin = true,
                ).body<BrowseResponse>()

            TasteProfile(artists = emptyMap())
        }

    suspend fun setTasteProfile(
        selectedArtists: List<String>,
        allArtists: Map<String, TasteArtist>,
    ): Result<Unit> =
        runCatching {
            val selectedValues = selectedArtists.mapNotNull { allArtists[it]?.selectionValue }
            val impressionValues = allArtists.values.map { it.impressionValue }

            if (selectedValues.isNotEmpty()) {
                feedback(selectedValues + impressionValues).getOrThrow()
            }
        }

    suspend fun removeHistoryItems(feedbackTokens: List<String>): Result<Boolean> =
        runCatching {
            feedback(feedbackTokens).getOrThrow()
        }

    @JvmInline
    value class SearchFilter(
        val value: String,
    ) {
        companion object {
            val FILTER_SONG = SearchFilter("EgWKAQIIAWoKEAkQBRAKEAMQBA%3D%3D")
            val FILTER_VIDEO = SearchFilter("EgWKAQIQAWoKEAkQChAFEAMQBA%3D%3D")
            val FILTER_ALBUM = SearchFilter("EgWKAQIYAWoKEAkQChAFEAMQBA%3D%3D")
            val FILTER_ARTIST = SearchFilter("EgWKAQIgAWoKEAkQChAFEAMQBA%3D%3D")
            val FILTER_FEATURED_PLAYLIST = SearchFilter("EgeKAQQoADgBagwQDhAKEAMQBRAJEAQ%3D")
            val FILTER_COMMUNITY_PLAYLIST = SearchFilter("EgeKAQQoAEABagoQAxAEEAoQCRAF")
            val FILTER_PODCAST = SearchFilter("EgWKAQJQAWoKEAkQChAFEAMQBA%3D%3D")
            val FILTER_EPISODE = SearchFilter("EgWKAQJYAWoKEAkQChAFEAMQBA%3D%3D")
            val FILTER_PROFILE = SearchFilter("EgWKAQJYAWoSEAUQCRADEAQQEBAVEAoQDhAR")
        }
    }

    @JvmInline
    value class LibraryFilter(
        val value: String,
    ) {
        companion object {
            val FILTER_RECENT_ACTIVITY = LibraryFilter("4qmFsgIrEhdGRW11c2ljX2xpYnJhcnlfbGFuZGluZxoQZ2dNR0tnUUlCaEFCb0FZQg%3D%3D")
            val FILTER_RECENTLY_PLAYED = LibraryFilter("4qmFsgIrEhdGRW11c2ljX2xpYnJhcnlfbGFuZGluZxoQZ2dNR0tnUUlCUkFCb0FZQg%3D%3D")
            val FILTER_PLAYLISTS_ALPHABETICAL = LibraryFilter("4qmFsgIrEhdGRW11c2ljX2xpa2VkX3BsYXlsaXN0cxoQZ2dNR0tnUUlBUkFBb0FZQg%3D%3D")
            val FILTER_PLAYLISTS_RECENTLY_SAVED = LibraryFilter("4qmFsgIrEhdGRW11c2ljX2xpa2VkX3BsYXlsaXN0cxoQZ2dNR0tnUUlBQkFCb0FZQg%3D%3D")
        }
    }

    const val MAX_GET_QUEUE_SIZE = 1000

    private val VISITOR_DATA_REGEX = Regex("^Cg[t|s]")

    fun getNewPipeStreamUrls(videoId: String): List<Pair<Int, String>> =
        if (ENABLE_NEWPIPE_STREAM_INFO_EXTRACTOR) {
            NewPipeExtractor.newPipePlayer(videoId)
        } else {
            emptyList()
        }

    suspend fun newPipePlayer(
        videoId: String,
        tempRes: PlayerResponse,
    ): PlayerResponse? {
        if (tempRes.playabilityStatus.status != "OK") {
            return null
        }

        val streamsList = getNewPipeStreamUrls(videoId)
        if (streamsList.isEmpty()) return null

        val decodedSigResponse =
            tempRes.copy(
                streamingData =
                    tempRes.streamingData?.copy(
                        formats =
                            tempRes.streamingData.formats?.map { format ->
                                format.copy(
                                    url = streamsList.find { it.first == format.itag }?.second ?: format.url,
                                )
                            },
                        adaptiveFormats =
                            tempRes.streamingData.adaptiveFormats.map { adaptiveFormat ->
                                adaptiveFormat.copy(
                                    url = streamsList.find { it.first == adaptiveFormat.itag }?.second ?: adaptiveFormat.url,
                                )
                            },
                    ),
            )

        val urlList =
            (
                decodedSigResponse.streamingData
                    ?.adaptiveFormats
                    ?.mapNotNull { it.url }
                    ?.toMutableList() ?: mutableListOf()
            ).apply {
                decodedSigResponse.streamingData
                    ?.formats
                    ?.mapNotNull { it.url }
                    ?.let { addAll(it) }
            }

        return if (urlList.isNotEmpty()) {
            decodedSigResponse
        } else {
            null
        }
    }

    /**
     * Upload a song to YouTube Music.
     * @param filename The name of the file
     * @param data The file data as ByteArray
     * @param onProgress Callback for upload progress (0.0 to 1.0)
     * @return true if upload succeeded
     */
    suspend fun uploadSong(
        filename: String,
        data: ByteArray,
        onProgress: ((Float) -> Unit)? = null,
    ): Result<Boolean> =
        runCatching {
            onProgress?.invoke(0f)

            // Step 1: Initialize upload (5% of progress)
            val initResponse = innerTube.initSongUpload(filename, data.size.toLong())
            val uploadUrl =
                initResponse.headers["X-Goog-Upload-URL"]
                    ?: throw Exception("Failed to get upload URL")

            onProgress?.invoke(0.05f)

            // Step 2: Upload file data (5% to 100% of progress)
            val uploadResponse =
                innerTube.uploadSongData(
                    uploadUrl = uploadUrl,
                    data = data,
                    onProgress = { uploadProgress ->
                        // Map upload progress (0-1) to overall progress (0.05-1.0)
                        onProgress?.invoke(0.05f + uploadProgress * 0.95f)
                    },
                )

            val status = uploadResponse.headers["X-Goog-Upload-Status"]
            status == "final"
        }

    /**
     * Delete an uploaded song from YouTube Music library.
     * @param entityId The entity ID of the uploaded song (typically the video ID)
     * @return true if deletion succeeded
     */
    suspend fun deleteUploadedSong(entityId: String): Result<Boolean> =
        runCatching {
            innerTube.deletePrivatelyOwnedEntity(entityId)
            true
        }

    /**
     * Supported file types for upload
     */
    val SUPPORTED_UPLOAD_TYPES = listOf("mp3", "m4a", "wma", "flac", "ogg")

    /**
     * Maximum file size for upload (300MB)
     */
    const val MAX_UPLOAD_SIZE = 314572800L

    suspend fun resolveArtistIds(items: List<YTItem>): List<YTItem> {
        val missingNames = mutableSetOf<String>()
        for (item in items) {
            when (item) {
                is SongItem -> item.artists.filter { it.id == null }.forEach { missingNames.add(it.name) }
                is AlbumItem -> item.artists?.filter { it.id == null }?.forEach { missingNames.add(it.name) }
                is PlaylistItem -> item.author?.let { if (it.id == null) missingNames.add(it.name) }
                is EpisodeItem -> item.author?.let { if (it.id == null) missingNames.add(it.name) }
                is PodcastItem -> item.author?.let { if (it.id == null) missingNames.add(it.name) }
                else -> {}
            }
        }

        if (missingNames.isEmpty()) return items

        val resolved = coroutineScope {
            val semaphore = kotlinx.coroutines.sync.Semaphore(8)
            missingNames.map { name ->
                async {
                    semaphore.acquire()
                    try {
                        val searchResult = search(name, SearchFilter.FILTER_ARTIST).getOrNull()
                        val normalizedName = name.trim()
                        val artistId = searchResult?.items
                            ?.filterIsInstance<ArtistItem>()
                            ?.firstOrNull { candidate ->
                                candidate.title.trim().equals(normalizedName, ignoreCase = true)
                            }?.id
                        if (artistId != null) name to artistId else null
                    } finally {
                        semaphore.release()
                    }
                }
            }.awaitAll().filterNotNull().toMap()
        }

        fun Artist.resolve() = if (id == null) resolved[name]?.let { copy(id = it) } ?: this else this
        return items.map { item ->
            when (item) {
                is SongItem -> item.copy(artists = item.artists.map { it.resolve() })
                is AlbumItem -> item.copy(artists = item.artists?.map { it.resolve() })
                is PlaylistItem -> item.copy(author = item.author?.resolve())
                is EpisodeItem -> item.copy(author = item.author?.resolve())
                is PodcastItem -> item.copy(author = item.author?.resolve())
                else -> item
            }
        }
    }

    /**
     * Collects all unique missing artist names from [items], resolves them in parallel,
     * and returns a name -> id map. Use this when resolving across multiple sections
     * to avoid duplicate searches for the same artist.
     */
    suspend fun resolveArtistIdMap(items: List<YTItem>): Map<String, String> {
        val missingNames = mutableSetOf<String>()
        for (item in items) {
            when (item) {
                is SongItem -> item.artists.filter { it.id == null }.forEach { missingNames.add(it.name) }
                is AlbumItem -> item.artists?.filter { it.id == null }?.forEach { missingNames.add(it.name) }
                is PlaylistItem -> item.author?.let { if (it.id == null) missingNames.add(it.name) }
                is EpisodeItem -> item.author?.let { if (it.id == null) missingNames.add(it.name) }
                is PodcastItem -> item.author?.let { if (it.id == null) missingNames.add(it.name) }
                else -> {}
            }
        }

        if (missingNames.isEmpty()) return emptyMap()

        return coroutineScope {
            val semaphore = kotlinx.coroutines.sync.Semaphore(8)
            missingNames.map { name ->
                async {
                    semaphore.acquire()
                    try {
                        val searchResult = search(name, SearchFilter.FILTER_ARTIST).getOrNull()
                        val normalizedName = name.trim()
                        val artistId = searchResult?.items
                            ?.filterIsInstance<ArtistItem>()
                            ?.firstOrNull { candidate ->
                                candidate.title.trim().equals(normalizedName, ignoreCase = true)
                            }?.id
                        if (artistId != null) name to artistId else null
                    } finally {
                        semaphore.release()
                    }
                }
            }.awaitAll().filterNotNull().toMap()
        }
    }
}

// ============================================================================
// [VISUAL NORMALIZER] Anti-Distortion & Thumbnail Normalization Engine
// ============================================================================

object InnerTubeVisualNormalizer {
    private val GOOGLE_SIZE_MODIFIER_REGEX = Regex("=w(\\d+)-h(\\d+)(-[a-zA-Z0-9-]+)?")
    private val GOOGLE_SINGLE_SIZE_REGEX = Regex("=s(\\d+)(-[a-zA-Z0-9-]+)?")

    fun normalizeThumbnailUrl(
        rawUrl: String?,
        targetSize: Int = 544,
        preserveAspectForWide: Boolean = true,
    ): String? {
        if (rawUrl.isNullOrBlank()) return null
        val trimmed = rawUrl.trim().let {
            if (it.startsWith("//")) "https:$it" else it
        }

        if (trimmed.contains("lh3.googleusercontent.com") || trimmed.contains("yt3.ggpht.com") || trimmed.contains("yt3.googleusercontent.com")) {
            val match = GOOGLE_SIZE_MODIFIER_REGEX.find(trimmed)
            if (match != null) {
                val origW = match.groupValues[1].toIntOrNull() ?: targetSize
                val origH = match.groupValues[2].toIntOrNull() ?: targetSize
                val ratio = if (origH > 0) origW.toFloat() / origH.toFloat() else 1f
                return if (preserveAspectForWide && (ratio > 1.35f || ratio < 0.75f)) {
                    val scaledW = targetSize
                    val scaledH = (targetSize / ratio).toInt().coerceAtLeast(180)
                    trimmed.replace(GOOGLE_SIZE_MODIFIER_REGEX, "=w$scaledW-h$scaledH-l90-rj")
                } else {
                    trimmed.replace(GOOGLE_SIZE_MODIFIER_REGEX, "=w$targetSize-h$targetSize-c-l90-rj")
                }
            }
            val singleMatch = GOOGLE_SINGLE_SIZE_REGEX.find(trimmed)
            if (singleMatch != null) {
                return trimmed.replace(GOOGLE_SINGLE_SIZE_REGEX, "=s$targetSize-c-l90-rj")
            }
        }
        return trimmed
    }

    fun resizeAndNormalizeUrl(
        url: String,
        width: Int? = null,
        height: Int? = null,
        forceSquareCrop: Boolean = false,
    ): String {
        if (width == null && height == null) return normalizeThumbnailUrl(url) ?: url
        val w = width ?: height ?: 544
        val h = height ?: width ?: 544
        val cropFlag = if (forceSquareCrop || w == h) "-c-l90-rj" else "-l90-rj"

        if (url.contains("lh3.googleusercontent.com") || url.contains("yt3.ggpht.com") || url.contains("yt3.googleusercontent.com")) {
            if (GOOGLE_SIZE_MODIFIER_REGEX.containsMatchIn(url)) {
                return url.replace(GOOGLE_SIZE_MODIFIER_REGEX, "=w$w-h$h$cropFlag")
            }
            if (GOOGLE_SINGLE_SIZE_REGEX.containsMatchIn(url)) {
                return url.replace(GOOGLE_SINGLE_SIZE_REGEX, "=w$w-h$h$cropFlag")
            }
            return "$url=w$w-h$h$cropFlag"
        }

        Regex("https://lh3\\.googleusercontent\\.com/.*=w(\\d+)-h(\\d+).*").matchEntire(url)?.groupValues?.let { group ->
            val W = group[1].toInt()
            val H = group[2].toInt()
            var mW = width ?: 0
            var mH = height ?: 0
            if (mW == 0 && mH != 0) mW = mH * W / H
            if (mW != 0 && mH == 0) mH = mW * H / W
            return "${url.substringBefore("=w")}=w$mW-h$mH-p-l90-rj"
        }
        if (url matches Regex("https://yt3\\.ggpht\\.com/.*=s(\\d+)")) {
            return "$url-s${width ?: height}"
        }
        return url
    }

    fun selectBestThumbnail(thumbnails: List<Thumbnail>?): Thumbnail? {
        if (thumbnails.isNullOrEmpty()) return null
        val squareCandidates = thumbnails.filter { t ->
            val w = t.width ?: 0
            val h = t.height ?: 0
            w > 0 && h > 0 && kotlin.math.abs(w - h).toFloat() / maxOf(w, h).toFloat() <= 0.15f
        }
        val pool = squareCandidates.ifEmpty { thumbnails }
        return pool.maxByOrNull { (it.width ?: 0) * (it.height ?: 0) } ?: thumbnails.lastOrNull()
    }
}

