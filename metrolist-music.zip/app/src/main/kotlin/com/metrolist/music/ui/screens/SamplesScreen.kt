/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.metrolist.music.LocalDatabase
import com.metrolist.music.LocalPlayerConnection
import com.metrolist.music.R
import com.metrolist.music.constants.SongSortType
import com.metrolist.music.db.entities.Song
import com.metrolist.music.extensions.toMediaItem
import com.metrolist.music.playback.queues.ListQueue

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SamplesScreen() {
    val context = LocalContext.current
    val database = LocalDatabase.current
    val playerConnection = LocalPlayerConnection.current

    var songsList by remember { mutableStateOf<List<Song>>(emptyList()) }
    var currentSongIndex by remember { mutableStateOf(0) }
    var isShortsMode by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()

    val currentPlayingSongState by (playerConnection?.currentSong?.collectAsState() ?: remember { mutableStateOf(null) })
    val isCurrentlyPlayingState by (playerConnection?.isPlaying?.collectAsState() ?: remember { mutableStateOf(false) })

    // Default Fallback Samples if the user's database is empty
    val fallbackSongs = remember {
        listOf(
            Song(
                song = com.metrolist.music.db.entities.SongEntity(
                    id = "sample_1",
                    title = "Ambient Echoes",
                    duration = 180,
                    thumbnailUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=400&auto=format&fit=crop&q=60"
                ),
                artists = emptyList()
            ),
            Song(
                song = com.metrolist.music.db.entities.SongEntity(
                    id = "sample_2",
                    title = "Starlight Night",
                    duration = 210,
                    thumbnailUrl = "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=400&auto=format&fit=crop&q=60"
                ),
                artists = emptyList()
            ),
            Song(
                song = com.metrolist.music.db.entities.SongEntity(
                    id = "sample_3",
                    title = "City Waves",
                    duration = 195,
                    thumbnailUrl = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=400&auto=format&fit=crop&q=60"
                ),
                artists = emptyList()
            )
        )
    }

    val activeSongs = if (songsList.isNotEmpty()) songsList else fallbackSongs
    val currentSong = activeSongs.getOrNull(currentSongIndex)

    val dbSongState by remember(currentSong, database) {
        if (currentSong != null && database != null) {
            database.song(currentSong.song.id)
        } else {
            kotlinx.coroutines.flow.flowOf(null)
        }
    }.collectAsState(initial = null)

    val isPlaying = currentSong != null && currentPlayingSongState?.id == currentSong.song.id && isCurrentlyPlayingState
    val isLiked = dbSongState?.song?.liked ?: false
    val isSaved = dbSongState?.song?.inLibrary != null

    // Comments Sheet state
    var showComments by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState()
    val comments = remember(context) {
        mutableStateListOf(
            Comment(context.getString(R.string.samples_comment_user1), context.getString(R.string.samples_comment_text1)),
            Comment(context.getString(R.string.samples_comment_user2), context.getString(R.string.samples_comment_text2)),
            Comment(context.getString(R.string.samples_comment_user3), context.getString(R.string.samples_comment_text3)),
            Comment(context.getString(R.string.samples_comment_user4), context.getString(R.string.samples_comment_text4))
        )
    }
    var newCommentText by remember { mutableStateOf("") }

    // Load actual songs from the library database
    LaunchedEffect(Unit) {
        database.songs(SongSortType.CREATE_DATE, false).collect { list ->
            songsList = list
        }
    }

    // Infinite Rotation animation for the album art when playing
    val infiniteTransition = rememberInfiniteTransition(label = "rotation")
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "angle"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F0C20),
                        Color(0xFF05030A)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Screen Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 24.dp, bottom = 12.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(horizontal = 16.dp)
                ) {
                    Text(
                        text = stringResource(R.string.samples_title),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .width(40.dp)
                            .height(3.dp)
                            .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(1.5.dp))
                    )
                }
            }

            Spacer(modifier = Modifier.weight(0.1f))

            // Main Rotating Album Card
            if (currentSong != null) {
                Box(
                    modifier = Modifier
                        .size(280.dp)
                        .shadow(16.dp, CircleShape)
                        .background(Color.Black, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = currentSong.song.thumbnailUrl,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(260.dp)
                            .clip(CircleShape)
                            .rotate(if (isPlaying) rotationAngle else 0f)
                    )

                    // Inner decorative circle
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .shadow(4.dp, CircleShape)
                            .background(Color(0xFF1E1E1E), CircleShape)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Song Info
                Text(
                    text = currentSong.song.title,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 32.dp)
                )

                Text(
                    text = currentSong.artists.joinToString { it.name }.ifEmpty { "Metrolist Creator" },
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White.copy(alpha = 0.7f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 32.dp).padding(top = 4.dp)
                )
            }

            Spacer(modifier = Modifier.weight(0.1f))

            // Large Play Button & Navigation
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Prev button
                IconButton(
                    onClick = {
                        if (currentSongIndex > 0) {
                            currentSongIndex--
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .background(Color.White.copy(alpha = 0.1f), CircleShape)
                ) {
                    Icon(
                        painter = painterResource(R.drawable.arrow_back),
                        contentDescription = "Previous",
                        tint = Color.White
                    )
                }

                // Play action button
                Button(
                    onClick = {
                        if (currentSong != null) {
                            if (isPlaying) {
                                playerConnection?.player?.pause()
                            } else {
                                if (currentPlayingSongState?.id == currentSong.song.id) {
                                    playerConnection?.player?.play()
                                } else {
                                    playerConnection?.playQueue(
                                        ListQueue(
                                            title = "Samples Mix",
                                            items = listOf(currentSong.toMediaItem())
                                        )
                                    )
                                }
                            }
                        }
                    },
                    modifier = Modifier
                        .width(140.dp)
                        .height(54.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isPlaying) MaterialTheme.colorScheme.error else Color.White,
                        contentColor = if (isPlaying) Color.White else Color.Black
                    ),
                    shape = RoundedCornerShape(27.dp)
                ) {
                    Icon(
                        painter = painterResource(if (isPlaying) R.drawable.pause else R.drawable.play),
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isPlaying) stringResource(R.string.samples_pause) else stringResource(R.string.samples_play),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }

                // Next button
                IconButton(
                    onClick = {
                        if (currentSongIndex < activeSongs.size - 1) {
                            currentSongIndex++
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .background(Color.White.copy(alpha = 0.1f), CircleShape)
                ) {
                    Icon(
                        painter = painterResource(R.drawable.arrow_back),
                        contentDescription = "Next",
                        modifier = Modifier.rotate(180f),
                        tint = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.weight(0.1f))
        }

        // Floating Action Sidebar (Like, Comments, Save, Shorts, Share)
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 16.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Like Button
            FloatingSidebarButton(
                iconRes = if (isLiked) R.drawable.favorite else R.drawable.favorite_border,
                label = stringResource(R.string.samples_like),
                tint = if (isLiked) Color.Red else Color.White,
                onClick = {
                    currentSong?.let { song ->
                        coroutineScope.launch(Dispatchers.IO) {
                            val dbSong = dbSongState ?: song
                            val updated = dbSong.song.toggleLike()
                            if (dbSongState == null) {
                                database.insert(dbSong.song)
                                dbSong.artists.forEach { database.insert(it) }
                            }
                            database.update(updated)
                        }
                    }
                }
            )

            // Comments Button
            FloatingSidebarButton(
                iconRes = R.drawable.lyrics,
                label = stringResource(R.string.samples_comment),
                onClick = { showComments = true }
            )

            // Save Button
            FloatingSidebarButton(
                iconRes = R.drawable.star,
                label = stringResource(R.string.samples_save),
                tint = if (isSaved) Color(0xFFFFD700) else Color.White.copy(alpha = 0.6f),
                onClick = {
                    currentSong?.let { song ->
                        coroutineScope.launch(Dispatchers.IO) {
                            val dbSong = dbSongState ?: song
                            val updated = dbSong.song.toggleLibrary()
                            if (dbSongState == null) {
                                database.insert(dbSong.song)
                                dbSong.artists.forEach { database.insert(it) }
                            }
                            database.update(updated)
                            withContext(Dispatchers.Main) {
                                Toast.makeText(
                                    context,
                                    if (updated.inLibrary != null) {
                                        context.getString(R.string.samples_saved_to_library)
                                    } else {
                                        context.getString(R.string.samples_removed_from_library)
                                    },
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    }
                }
            )

            // Shorts Switcher
            FloatingSidebarButton(
                iconRes = R.drawable.slow_motion_video,
                label = "Shorts",
                tint = if (isShortsMode) MaterialTheme.colorScheme.primary else Color.White,
                onClick = {
                    isShortsMode = !isShortsMode
                    Toast.makeText(
                        context,
                        if (isShortsMode) {
                            context.getString(R.string.samples_shorts_mode_on)
                        } else {
                            context.getString(R.string.samples_shorts_mode_off)
                        },
                        Toast.LENGTH_SHORT
                    ).show()
                }
            )

            // Share Button
            FloatingSidebarButton(
                iconRes = R.drawable.share,
                label = stringResource(R.string.samples_share),
                onClick = {
                    if (currentSong != null) {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, currentSong.song.title)
                            putExtra(
                                Intent.EXTRA_TEXT,
                                context.getString(R.string.samples_share_text, currentSong.song.title)
                            )
                        }
                        context.startActivity(
                            Intent.createChooser(
                                shareIntent,
                                context.getString(R.string.samples_share_title)
                            )
                        )
                    }
                }
            )
        }

        // Comments Bottom Sheet
        if (showComments) {
            ModalBottomSheet(
                onDismissRequest = { showComments = false },
                sheetState = sheetState,
                containerColor = Color(0xFF16151E),
                contentColor = Color.White
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(0.6f)
                        .padding(horizontal = 16.dp)
                ) {
                    Text(
                        text = stringResource(R.string.samples_comments_header, comments.size),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )

                    HorizontalDivider(color = Color.White.copy(alpha = 0.1f))

                    // Comments List
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .padding(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(comments) { comment ->
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .background(MaterialTheme.colorScheme.secondaryContainer, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = comment.author.first().toString(),
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = comment.author,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                                Text(
                                    text = comment.text,
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.padding(start = 40.dp, top = 4.dp),
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }

                    // Write Comment Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 24.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newCommentText,
                            onValueChange = { newCommentText = it },
                            placeholder = { Text(stringResource(R.string.samples_comment_placeholder), color = Color.Gray) },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                                focusedContainerColor = Color.Black.copy(alpha = 0.3f),
                                unfocusedContainerColor = Color.Black.copy(alpha = 0.3f)
                            ),
                            shape = RoundedCornerShape(20.dp),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = {
                                if (newCommentText.isNotBlank()) {
                                    comments.add(0, Comment(context.getString(R.string.samples_comment_me), newCommentText))
                                    newCommentText = ""
                                }
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .background(MaterialTheme.colorScheme.primary, CircleShape)
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.arrow_back),
                                contentDescription = stringResource(R.string.samples_send_desc),
                                tint = Color.White,
                                modifier = Modifier.rotate(180f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FloatingSidebarButton(
    iconRes: Int,
    label: String,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Surface(
            shape = CircleShape,
            color = Color.Black.copy(alpha = 0.5f),
            modifier = Modifier.size(48.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.fillMaxSize()
            ) {
                Icon(
                    painter = painterResource(iconRes),
                    contentDescription = label,
                    tint = tint,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

data class Comment(val author: String, val text: String)
