package com.metrolist.music.ui.screens.equalizer

import com.metrolist.music.eq.data.ParametricEQBand
import com.metrolist.music.eq.data.PresetEQProfiles
import com.metrolist.music.eq.data.SavedEQProfile

/**
 * UI State for EQ Screen
 */
data class EQState(
    val profiles: List<SavedEQProfile> = emptyList(),
    val activeProfileId: String? = null,
    val currentBands: List<ParametricEQBand> = PresetEQProfiles.createDefault10Bands(),
    val currentPreamp: Double = 0.0,
    val isEqualizerEnabled: Boolean = true,
    val importStatus: String? = null,
    val error: String? = null
)
