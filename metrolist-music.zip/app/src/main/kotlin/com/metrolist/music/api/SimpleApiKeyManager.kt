/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.api

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import timber.log.Timber
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

/**
 * ValidationResult: Kết quả kiểm tra cú pháp và tính khả dụng của API Key / Provider Endpoint.
 */
sealed class ValidationResult {
    data class Valid(
        val message: String,
        val statusCode: Int = 200,
        val details: String? = null,
    ) : ValidationResult()

    data class Invalid(
        val message: String,
        val isFormatError: Boolean = false,
        val statusCode: Int? = null,
    ) : ValidationResult()

    data class Error(
        val message: String,
        val throwable: Throwable? = null,
    ) : ValidationResult()
}

/**
 * SimpleApiKeyManager:
 * Lớp tiện ích Android gọn nhẹ để quản lý API Key, hỗ trợ đường dẫn nhà cung cấp chuẩn lẫn tùy chỉnh (Custom Endpoint),
 * đọc cấu hình văn bản thô từ URL (.txt), và thực hiện kiểm tra key cục bộ cũng như qua mạng.
 *
 * Quy tắc:
 * 1. Không phân biệt chữ hoa / chữ thường: Cả chữ hoa (A-Z) và chữ thường (a-z) đều hợp lệ, không báo lỗi.
 * 2. Tiền kiểm tra bất thường (Cơ chế Báo đỏ): Không báo lỗi khi người dùng nhập liệu bình thường.
 *    Chỉ báo lỗi khi phát hiện bất thường rõ ràng:
 *    - Chuỗi chứa ký tự không hợp lệ (khoảng trắng, ký tự đặc biệt ngoài [a-zA-Z0-9_-]).
 *    - URL nhà cung cấp không hợp lệ hoặc sai định dạng (phải bắt đầu bằng http:// hoặc https://).
 *    - Nhà cung cấp từ chối key hoặc trả về lỗi 401, 403, 429.
 * 3. Đọc cấu hình từ xa (.txt) đơn giản, gọn nhẹ.
 * 4. Lưu trữ và đọc API Key qua SharedPreferences an toàn.
 * 5. Che mờ key (maskKey) để hiển thị an toàn trên giao diện nhưng vẫn giữ nguyên độ dài.
 */
object SimpleApiKeyManager {

    private const val PREFS_NAME = "simple_api_key_prefs"
    private const val KEY_SAVED_API_KEY = "saved_api_key"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .callTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    @Volatile
    private var appContext: Context? = null

    /**
     * Khởi tạo context cho SharedPreferences (có thể được gọi khi Application hoặc UI khởi động).
     */
    fun init(context: Context) {
        if (appContext == null) {
            appContext = context.applicationContext
        }
    }

    private fun getPreferences(): SharedPreferences? {
        return appContext?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    /**
     * 1. fetchConfigFromTxtUrl: Tải nội dung văn bản thô từ URL (hỗ trợ .txt hoặc text URL).
     */
    fun fetchConfigFromTxtUrl(url: String, callback: (String?) -> Unit) {
        val cleanUrl = url.trim()
        if (cleanUrl.isBlank() || (!cleanUrl.startsWith("http://", ignoreCase = true) && !cleanUrl.startsWith("https://", ignoreCase = true))) {
            callback(null)
            return
        }

        scope.launch {
            val content = try {
                val request = Request.Builder()
                    .url(cleanUrl)
                    .header("User-Agent", "MetrolistMusic/1.0 (Android)")
                    .header("Accept", "text/plain, text/*, */*")
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        response.body?.string()
                    } else {
                        Timber.w("fetchConfigFromTxtUrl: HTTP ${response.code}")
                        null
                    }
                }
            } catch (e: Exception) {
                Timber.e(e, "fetchConfigFromTxtUrl: Failed to fetch from $cleanUrl")
                null
            }

            withContext(Dispatchers.Main) {
                callback(content)
            }
        }
    }

    /**
     * 2. checkLocalFormat: Kiểm tra cú pháp cục bộ (không dùng mạng) để phát hiện bất thường rõ ràng.
     *
     * - Chữ hoa (A-Z) và chữ thường (a-z) đều được chấp nhận bình thường, KHÔNG phân biệt hoa/thường.
     * - Chỉ báo lỗi khi:
     *   + Chuỗi chứa khoảng trắng hoặc ký tự đặc biệt ngoài [a-zA-Z0-9_-].
     *   + URL nhà cung cấp không hợp lệ (nếu được cung cấp, phải bắt đầu bằng http:// hoặc https://).
     */
    fun checkLocalFormat(apiKey: String, providerUrl: String = ""): ValidationResult {
        val trimmedKey = apiKey.trim()

        // 1. Kiểm tra URL nếu có nhập
        val trimmedUrl = providerUrl.trim()
        if (trimmedUrl.isNotBlank()) {
            val isHttp = trimmedUrl.startsWith("http://", ignoreCase = true)
            val isHttps = trimmedUrl.startsWith("https://", ignoreCase = true)
            if (!isHttp && !isHttps) {
                return ValidationResult.Invalid(
                    message = "URL nhà cung cấp không hợp lệ. Phải bắt đầu bằng http:// hoặc https://",
                    isFormatError = true,
                )
            }
        }

        // Nếu key trống, không kích hoạt lỗi cú pháp bất thường trong quá trình nhập liệu bình thường
        if (trimmedKey.isEmpty()) {
            return ValidationResult.Valid("Key rỗng")
        }

        // 2. Kiểm tra ký tự bất thường: chỉ cho phép [a-zA-Z0-9_-], không cho phép khoảng trắng hoặc ký tự đặc biệt khác
        // regex không phân biệt chữ hoa/chữ thường: (?i)^[a-z0-9_-]+$
        val allowedPattern = Pattern.compile("^[a-zA-Z0-9_-]+$")
        if (!allowedPattern.matcher(trimmedKey).matches()) {
            return ValidationResult.Invalid(
                message = "Khóa chứa ký tự không hợp lệ. Chỉ chấp nhận chữ cái (A-Z, a-z), chữ số (0-9), dấu gạch ngang (-) và gạch dưới (_).",
                isFormatError = true,
            )
        }

        return ValidationResult.Valid("Cú pháp hợp lệ")
    }

    /**
     * 3. validateKey: Gửi yêu cầu kiểm tra (ping) đến server nhà cung cấp.
     * Kiểm tra trạng thái HTTP, phát hiện các mã lỗi 401, 403, 429 hoặc thành công.
     */
    fun validateKey(
        providerUrl: String,
        apiKey: String,
        callback: (ValidationResult) -> Unit,
    ) {
        val cleanKey = apiKey.trim()
        val cleanUrl = providerUrl.trim()

        // Tiền kiểm tra cú pháp cục bộ trước
        val localCheck = checkLocalFormat(cleanKey, cleanUrl)
        if (localCheck is ValidationResult.Invalid) {
            callback(localCheck)
            return
        }

        if (cleanUrl.isBlank()) {
            // Không có endpoint để ping -> xác thực thành công theo định dạng cục bộ
            callback(ValidationResult.Valid("Cú pháp hợp lệ (Không có endpoint kiểm tra trực tiếp)"))
            return
        }

        scope.launch {
            val result = try {
                val pingUrl = cleanUrl

                // Thử ping nhẹ với JSON payload chuẩn OpenAI-compatible hoặc GET
                val mediaType = "application/json; charset=utf-8".toMediaType()
                val requestBody = JSONObject().apply {
                    put("model", "gpt-3.5-turbo")
                    put("messages", JSONArray().apply {
                        put(JSONObject().apply {
                            put("role", "user")
                            put("content", "ping")
                        })
                    })
                    put("max_tokens", 1)
                }.toString().toRequestBody(mediaType)

                val requestBuilder = Request.Builder()
                    .url(pingUrl)
                    .header("User-Agent", "MetrolistMusic/1.0 (Android)")
                    .header("Content-Type", "application/json")

                if (cleanKey.isNotBlank()) {
                    requestBuilder.header("Authorization", "Bearer $cleanKey")
                }

                val request = requestBuilder.post(requestBody).build()

                httpClient.newCall(request).execute().use { response ->
                    val code = response.code
                    when (code) {
                        200 -> ValidationResult.Valid("Xác thực thành công", statusCode = 200)
                        401 -> ValidationResult.Invalid("API Key không hợp lệ hoặc đã bị vô hiệu hóa (HTTP 401).", statusCode = 401)
                        403 -> ValidationResult.Invalid("Không có quyền truy cập hoặc key bị cấm (HTTP 403).", statusCode = 403)
                        429 -> ValidationResult.Invalid("API Key đã hết hạn mức sử dụng hoặc vượt quá tần suất gọi (HTTP 429).", statusCode = 429)
                        in 200..299 -> ValidationResult.Valid("Xác thực thành công (HTTP $code)", statusCode = code)
                        else -> {
                            // Nhiều provider trả về 400 hoặc 404 cho model test nhưng key vẫn được chấp nhận
                            val responseBody = response.body?.string() ?: ""
                            if (responseBody.contains("model", ignoreCase = true) && !responseBody.contains("key", ignoreCase = true)) {
                                ValidationResult.Valid("Endpoint phản hồi khả dụng (HTTP $code)", statusCode = code)
                            } else {
                                ValidationResult.Invalid("Nhà cung cấp từ chối yêu cầu (HTTP $code)", statusCode = code)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.e(e, "validateKey ping failed")
                ValidationResult.Error(e.message ?: "Lỗi kết nối tới nhà cung cấp", throwable = e)
            }

            withContext(Dispatchers.Main) {
                callback(result)
            }
        }
    }

    /**
     * 4. saveApiKey & getSavedApiKey: Lưu trữ và đọc key bằng SharedPreferences.
     */
    fun saveApiKey(key: String): Boolean {
        val prefs = getPreferences() ?: return false
        return prefs.edit().putString(KEY_SAVED_API_KEY, key.trim()).commit()
    }

    fun getSavedApiKey(): String? {
        val prefs = getPreferences() ?: return null
        return prefs.getString(KEY_SAVED_API_KEY, null)
    }

    /**
     * 5. maskKey: Che mờ key để hiển thị an toàn trên giao diện nhưng vẫn giữ nguyên độ dài.
     * Ví dụ:
     * - "sk-1234567890abcdef" -> "sk-12••••••••cdef"
     * - Độ dài chuỗi hiển thị tương đương chính xác với độ dài chuỗi ban đầu.
     */
    fun maskKey(key: String): String {
        val trimmed = key.trim()
        val len = trimmed.length
        if (len <= 4) {
            return "•".repeat(len)
        }
        if (len <= 8) {
            val prefix = trimmed.take(2)
            val suffix = trimmed.takeLast(1)
            val maskedCount = len - prefix.length - suffix.length
            return prefix + "•".repeat(maskedCount) + suffix
        }

        // Với key dài (>= 9 ký tự): giữ 4 ký tự đầu, 4 ký tự cuối, các ký tự ở giữa che bằng dấu chấm tròn '•'
        val prefixLen = minOf(5, len / 4)
        val suffixLen = minOf(4, len / 4)
        val maskedCount = len - prefixLen - suffixLen
        val prefix = trimmed.substring(0, prefixLen)
        val suffix = trimmed.substring(len - suffixLen)
        return prefix + "•".repeat(maskedCount) + suffix
    }
}
