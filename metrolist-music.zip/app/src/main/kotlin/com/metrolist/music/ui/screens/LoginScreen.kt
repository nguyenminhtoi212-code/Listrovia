/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.datastore.preferences.core.edit
import androidx.navigation.NavController
import com.metrolist.innertube.YouTube
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.constants.AccountChannelHandleKey
import com.metrolist.music.constants.AccountEmailKey
import com.metrolist.music.constants.AccountNameKey
import com.metrolist.music.constants.AccountProviderKey
import com.metrolist.music.constants.DataSyncIdKey
import com.metrolist.music.constants.InnerTubeCookieKey
import com.metrolist.music.constants.LoginHistoryKey
import com.metrolist.music.constants.VisitorDataKey
import com.metrolist.music.discord.DiscordRpcManager
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import com.metrolist.music.ui.utils.backToMain
import com.metrolist.music.utils.dataStore
import com.metrolist.music.utils.rememberPreference
import com.metrolist.music.utils.reportException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class LoginHistoryItem(val provider: String, val identifier: String, val timestamp: Long)

fun parseLoginHistory(serialized: String?): List<LoginHistoryItem> {
    if (serialized.isNullOrBlank()) return emptyList()
    return serialized.split(";").mapNotNull { entry ->
        val parts = entry.split("|")
        if (parts.size >= 3) {
            LoginHistoryItem(parts[0], parts[1], parts[2].toLongOrNull() ?: 0L)
        } else {
            null
        }
    }
}

sealed interface PendingLogin {
    data class Custom(val provider: String, val name: String, val email: String) : PendingLogin
    data class Google(
        val cookie: String,
        val visitorData: String,
        val dataSyncId: String,
        val name: String,
        val email: String,
        val channelHandle: String
    ) : PendingLogin
}

fun formatTimestamp(context: android.content.Context, timestamp: Long): String {
    val date = Date(timestamp)
    val now = Calendar.getInstance()
    val timeCalendar = Calendar.getInstance().apply { timeInMillis = timestamp }

    val isToday = now.get(Calendar.YEAR) == timeCalendar.get(Calendar.YEAR) &&
            now.get(Calendar.DAY_OF_YEAR) == timeCalendar.get(Calendar.DAY_OF_YEAR)

    val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault()).format(date)
    return if (isToday) {
        context.getString(R.string.today_format, timeFormat)
    } else {
        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(date)
        context.getString(R.string.before_format, dateFormat, timeFormat)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LoginScreen(navController: NavController) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isCompletingLogin by remember { mutableStateOf(false) }

    var webView: WebView? = null
    var isWebViewLoading by remember { mutableStateOf(true) }
    var visitorDataFromWeb by remember { mutableStateOf("") }
    var dataSyncIdFromWeb by remember { mutableStateOf("") }

    // Custom Login Flow states
    var showGoogleWebView by remember { mutableStateOf(false) }

    // Terms Agreement State: true = agreed, false = disagreed, null = unselected
    var selectedAgreementOption by remember { mutableStateOf<Boolean?>(null) }

    // Pending Login State
    var pendingLogin by remember { mutableStateOf<PendingLogin?>(null) }

    val (loginHistory, onLoginHistoryChange) = rememberPreference(LoginHistoryKey, "")
    val historyItems = remember(loginHistory) { parseLoginHistory(loginHistory) }

    fun commitLogin(pending: PendingLogin) {
        coroutineScope.launch {
            withContext(Dispatchers.IO) {
                context.dataStore.edit { settings ->
                    when (pending) {
                        is PendingLogin.Custom -> {
                            val provider = pending.provider
                            val name = pending.name
                            val email = pending.email

                            settings[AccountProviderKey] = provider.lowercase()
                            settings[AccountNameKey] = name
                            settings[AccountEmailKey] = email
                            settings[AccountChannelHandleKey] = "@${name.replace(" ", "").lowercase()}"

                            // Clear Youtube specific auth tokens when switching to custom login
                            settings.remove(InnerTubeCookieKey)
                            settings.remove(VisitorDataKey)
                            settings.remove(DataSyncIdKey)

                            val timestamp = System.currentTimeMillis()
                            val newEntry = "$provider|$email|$timestamp"
                            val existingHistory = settings[LoginHistoryKey].orEmpty()
                            val updatedHistory = if (existingHistory.isEmpty()) {
                                newEntry
                            } else {
                                "$newEntry;$existingHistory"
                            }
                            settings[LoginHistoryKey] = updatedHistory
                        }
                        is PendingLogin.Google -> {
                            settings[InnerTubeCookieKey] = pending.cookie
                            settings[VisitorDataKey] = pending.visitorData
                            settings[DataSyncIdKey] = pending.dataSyncId
                            settings[AccountNameKey] = pending.name
                            settings[AccountEmailKey] = pending.email
                            settings[AccountChannelHandleKey] = pending.channelHandle
                            settings[AccountProviderKey] = "google"

                            val timestamp = System.currentTimeMillis()
                            val newEntry = "Google|${pending.email.ifBlank { pending.name }}|$timestamp"
                            val existingHistory = settings[LoginHistoryKey].orEmpty()
                            val updatedHistory = if (existingHistory.isEmpty()) {
                                newEntry
                            } else {
                                "$newEntry;$existingHistory"
                            }
                            settings[LoginHistoryKey] = updatedHistory
                        }
                    }
                }
            }

            withContext(Dispatchers.Main) {
                val intent = context.packageManager.getLaunchIntentForPackage(context.packageName)
                intent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                context.startActivity(intent)
                Runtime.getRuntime().exit(0)
            }
        }
    }

    fun completeLogin(onClose: () -> Unit) {
        if (isCompletingLogin) return

        isCompletingLogin = true
        coroutineScope.launch {
            val currentCookie = CookieManager.getInstance().getCookie("https://music.youtube.com").orEmpty()
            if (currentCookie.isBlank()) {
                Timber.d("Login: No YouTube Music cookie found on close, leaving login screen")
                isCompletingLogin = false
                onClose()
                return@launch
            }

            // Save extracted values from the WebView before validating
            val savedVisitorData = visitorDataFromWeb
            val savedDataSyncId = dataSyncIdFromWeb

            // Initialize YouTube object with selected authentication data
            YouTube.cookie = currentCookie
            YouTube.dataSyncId = savedDataSyncId
            YouTube.visitorData = savedVisitorData

            Timber.d("Login: Manual close detected, validating selected account...")

            YouTube
                .accountInfo()
                .onSuccess { info ->
                    Timber.d("Login: Successfully logged in as ${info.name}, displaying terms & policies dialog...")

                    // Clean up WebView
                    webView?.apply {
                        stopLoading()
                        clearHistory()
                        clearCache(true)
                        com.metrolist.music.utils.ensureWebViewCacheDirsExist(context)
                        clearFormData()
                    }

                    withContext(Dispatchers.Main) {
                        pendingLogin = PendingLogin.Google(
                            cookie = currentCookie,
                            visitorData = savedVisitorData,
                            dataSyncId = savedDataSyncId,
                            name = info.name,
                            email = info.email.orEmpty(),
                            channelHandle = info.channelHandle.orEmpty()
                        )
                        showGoogleWebView = false
                        isCompletingLogin = false
                    }
                }.onFailure {
                    Timber.e(it, "Login: Authentication validation failed after manual close")
                    reportException(it)
                    isCompletingLogin = false
                    onClose()
                }
        }
    }

    if (showGoogleWebView) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.fillMaxSize()) {
                TopAppBar(
                    title = {
                        Column {
                            Text(stringResource(R.string.login_google), fontWeight = FontWeight.Bold)
                            Text(
                                "accounts.google.com",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = { showGoogleWebView = false },
                            onLongClick = {},
                        ) {
                            Icon(
                                painterResource(R.drawable.arrow_back),
                                contentDescription = null,
                            )
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { webView?.reload() },
                            onLongClick = {}
                        ) {
                            Icon(
                                painterResource(R.drawable.refresh),
                                contentDescription = "Tải lại",
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )

                if (isWebViewLoading) {
                    LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                AndroidView(
                    modifier = Modifier
                        .windowInsetsPadding(LocalPlayerAwareWindowInsets.current)
                        .fillMaxSize(),
                    factory = { webViewContext ->
                        WebView(webViewContext).apply {
                            webViewClient = object : WebViewClient() {
                                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                                    super.onPageStarted(view, url, favicon)
                                    isWebViewLoading = true
                                }

                                override fun onPageFinished(view: WebView, url: String?) {
                                    super.onPageFinished(view, url)
                                    isWebViewLoading = false
                                    loadUrl("javascript:Android.onRetrieveVisitorData(window.yt.config_.VISITOR_DATA)")
                                    loadUrl("javascript:Android.onRetrieveDataSyncId(window.yt.config_.DATASYNC_ID)")

                                    if (url?.contains("music.youtube.com") == true &&
                                        !isCompletingLogin &&
                                        CookieManager.getInstance().getCookie("https://music.youtube.com").orEmpty().isNotBlank()
                                    ) {
                                        Timber.d("Login: Detected authenticated session on music.youtube.com, completing login...")
                                        completeLogin(navController::navigateUp)
                                    }
                                }
                            }
                            settings.apply {
                                javaScriptEnabled = true
                                setSupportZoom(true)
                                builtInZoomControls = true
                                displayZoomControls = false
                            }
                            addJavascriptInterface(
                                object {
                                    @JavascriptInterface
                                    fun onRetrieveVisitorData(newVisitorData: String?) {
                                        if (newVisitorData != null) {
                                            visitorDataFromWeb = newVisitorData
                                        }
                                    }

                                    @JavascriptInterface
                                    fun onRetrieveDataSyncId(newDataSyncId: String?) {
                                        if (newDataSyncId != null) {
                                            dataSyncIdFromWeb = newDataSyncId.substringBefore("||")
                                        }
                                    }
                                },
                                "Android",
                            )
                            webView = this
                            loadUrl("https://accounts.google.com/ServiceLogin?continue=https%3A%2F%2Fmusic.youtube.com")
                        }
                    },
                )
            }
        }

        BackHandler {
            val currentWebView = webView
            if (currentWebView?.canGoBack() == true) {
                currentWebView.goBack()
            } else {
                showGoogleWebView = false
            }
        }
    } else if (pendingLogin != null) {
        // Step 2: Terms & Policies Screen
        BackHandler {
            pendingLogin = null
            selectedAgreementOption = null
        }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(stringResource(R.string.terms_and_privacy), fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(
                            onClick = {
                                pendingLogin = null
                                selectedAgreementOption = null
                            },
                            onLongClick = {}
                        ) {
                            Icon(
                                painterResource(R.drawable.arrow_back),
                                contentDescription = null,
                            )
                        }
                    },
                )
            },
            contentWindowInsets = LocalPlayerAwareWindowInsets.current
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(64.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            painter = painterResource(id = R.drawable.security),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }

                Text(
                    text = stringResource(R.string.terms_and_privacy),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = stringResource(R.string.login_terms_description),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )

                ElevatedCard(
                    onClick = { navController.navigate("settings/terms_privacy") },
                    colors = CardDefaults.elevatedCardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.info),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = stringResource(R.string.view_terms_and_privacy_link),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            painter = painterResource(R.drawable.navigate_next),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Option 1: Agree Card
                    OutlinedCard(
                        onClick = { selectedAgreementOption = true },
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(
                            width = if (selectedAgreementOption == true) 2.dp else 1.dp,
                            color = if (selectedAgreementOption == true) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                        ),
                        colors = CardDefaults.outlinedCardColors(
                            containerColor = if (selectedAgreementOption == true) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        ) {
                            RadioButton(
                                selected = selectedAgreementOption == true,
                                onClick = { selectedAgreementOption = true }
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = stringResource(R.string.login_terms_agree),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = if (selectedAgreementOption == true) FontWeight.Bold else FontWeight.Normal,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    // Option 2: Disagree Card
                    OutlinedCard(
                        onClick = { selectedAgreementOption = false },
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(
                            width = if (selectedAgreementOption == false) 2.dp else 1.dp,
                            color = if (selectedAgreementOption == false) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outlineVariant
                        ),
                        colors = CardDefaults.outlinedCardColors(
                            containerColor = if (selectedAgreementOption == false) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        ) {
                            RadioButton(
                                selected = selectedAgreementOption == false,
                                onClick = { selectedAgreementOption = false }
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = stringResource(R.string.login_terms_disagree),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = if (selectedAgreementOption == false) FontWeight.Bold else FontWeight.Normal,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                if (selectedAgreementOption == false) {
                    Text(
                        text = stringResource(R.string.login_must_agree_warning),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            pendingLogin = null
                            selectedAgreementOption = null
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.discord_cancel),
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = {
                            pendingLogin?.let { commitLogin(it) }
                        },
                        enabled = selectedAgreementOption == true,
                        modifier = Modifier
                            .weight(1.5f)
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.agree_and_continue),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    } else {
        // Step 1: Login Screen (Main Login Portal)
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = stringResource(R.string.login_title),
                            fontWeight = FontWeight.Bold
                        )
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = { navController.navigateUp() },
                            onLongClick = { navController.backToMain() },
                        ) {
                            Icon(
                                painterResource(R.drawable.arrow_back),
                                contentDescription = null,
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Transparent
                    )
                )
            },
            contentWindowInsets = LocalPlayerAwareWindowInsets.current,
            containerColor = MaterialTheme.colorScheme.background
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Compact Hero Header Card
                ElevatedCard(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.elevatedCardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                    ),
                    elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(52.dp)
                                .background(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = CircleShape
                                )
                        ) {
                            Icon(
                                painter = painterResource(id = R.drawable.login),
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.login_welcome_title),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = stringResource(R.string.login_welcome_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Group 1: Login Providers (Material3SettingsGroup)
                Material3SettingsGroup(
                    title = stringResource(R.string.login_methods),
                    items = listOf(
                        // 1. Google
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.google),
                            title = { Text(stringResource(R.string.login_google), fontWeight = FontWeight.SemiBold) },
                            description = { Text(stringResource(R.string.login_google_desc)) },
                            trailingContent = {
                                Icon(
                                    painter = painterResource(R.drawable.navigate_next),
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            onClick = { showGoogleWebView = true }
                        ),
                        // 2. Discord
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.discord),
                            title = { Text(stringResource(R.string.login_discord), fontWeight = FontWeight.SemiBold) },
                            description = { Text(stringResource(R.string.login_discord_desc)) },
                            trailingContent = {
                                Icon(
                                    painter = painterResource(R.drawable.navigate_next),
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            onClick = {
                                val activity = findActivity(context)
                                if (activity != null) {
                                    if (!DiscordRpcManager.isInitialized()) {
                                        DiscordRpcManager.init(context)
                                    }
                                    DiscordRpcManager.authorize(activity) { success ->
                                        if (success) {
                                            coroutineScope.launch(Dispatchers.IO) {
                                                val token = DiscordRpcManager.getAccessToken()
                                                if (token != null) {
                                                    val user = DiscordRpcManager.fetchCurrentUser(token)
                                                    if (user != null) {
                                                        withContext(Dispatchers.Main) {
                                                            pendingLogin = PendingLogin.Custom("Discord", user.username, "${user.username}@discord.com")
                                                        }
                                                    } else {
                                                        withContext(Dispatchers.Main) {
                                                            android.widget.Toast.makeText(context, context.getString(R.string.discord_error_fetch_user), android.widget.Toast.LENGTH_SHORT).show()
                                                        }
                                                    }
                                                } else {
                                                    withContext(Dispatchers.Main) {
                                                        android.widget.Toast.makeText(context, context.getString(R.string.discord_error_get_token), android.widget.Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                            }
                                        } else {
                                            android.widget.Toast.makeText(context, context.getString(R.string.discord_error_failed_or_cancelled), android.widget.Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                } else {
                                    android.widget.Toast.makeText(context, context.getString(R.string.discord_error_no_activity), android.widget.Toast.LENGTH_SHORT).show()
                                }
                            }
                        ),
                        // 3. Guest Login
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.person),
                            title = { Text(stringResource(R.string.login_guest), fontWeight = FontWeight.SemiBold) },
                            description = { Text(stringResource(R.string.login_guest_desc)) },
                            trailingContent = {
                                Icon(
                                    painter = painterResource(R.drawable.navigate_next),
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            onClick = {
                                pendingLogin = PendingLogin.Custom("Khách", "Khách (Guest)", "guest@metrolist.io")
                            }
                        )
                    )
                )

                // Group 2: Login History (if available)
                if (historyItems.isNotEmpty()) {
                    Material3SettingsGroup(
                        title = stringResource(R.string.login_history),
                        items = historyItems.map { item ->
                            val iconRes = when (item.provider.lowercase()) {
                                "google" -> R.drawable.google
                                "discord" -> R.drawable.discord
                                else -> R.drawable.person
                            }
                            Material3SettingsItem(
                                icon = painterResource(iconRes),
                                title = { Text(item.identifier, fontWeight = FontWeight.Medium) },
                                description = { Text("${item.provider} • ${formatTimestamp(context, item.timestamp)}") },
                                onClick = null
                            )
                        } + listOf(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.delete),
                                title = { Text(stringResource(R.string.clear_login_history), color = MaterialTheme.colorScheme.error) },
                                onClick = { onLoginHistoryChange("") }
                            )
                        )
                    )
                }

                // Group 3: Terms & Info
                Material3SettingsGroup(
                    title = stringResource(R.string.terms_and_privacy),
                    items = listOf(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.security),
                            title = { Text(stringResource(R.string.view_terms_and_privacy_title), fontWeight = FontWeight.Medium) },
                            description = { Text(stringResource(R.string.view_terms_and_privacy_desc)) },
                            onClick = { navController.navigate("settings/terms_privacy") }
                        )
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

private fun findActivity(context: android.content.Context): Activity? {
    var c: android.content.Context? = context
    while (c is android.content.ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}
