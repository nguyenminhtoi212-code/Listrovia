/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.component

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.metrolist.music.R
import com.metrolist.music.constants.LyricsColorTheme
import com.metrolist.music.constants.LyricsColorThemeKey
import com.metrolist.music.constants.LyricsFontWeightKey
import com.metrolist.music.constants.LyricsTextPositionKey
import com.metrolist.music.constants.LyricsTextSizeKey
import com.metrolist.music.constants.PlayerBackgroundStyle
import com.metrolist.music.constants.TranslateLanguageKey
import com.metrolist.music.constants.getLyricsFontWeight
import com.metrolist.music.lyrics.LyricsTranslationHelper
import com.metrolist.music.ui.screens.settings.LyricsPosition
import com.metrolist.music.utils.rememberEnumPreference
import com.metrolist.music.utils.rememberPreference
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Returns the effective accent color for lyrics based on the chosen color theme.
 */
fun getLyricsThemeColor(
    colorThemeName: String,
    primaryColor: Color,
    playerBackground: PlayerBackgroundStyle = PlayerBackgroundStyle.DEFAULT
): Color {
    val theme = try {
        LyricsColorTheme.valueOf(colorThemeName)
    } catch (e: Exception) {
        LyricsColorTheme.DEFAULT
    }
    return when (theme) {
        LyricsColorTheme.DEFAULT -> when (playerBackground) {
            PlayerBackgroundStyle.DEFAULT -> primaryColor
            else -> Color.White
        }
        LyricsColorTheme.WHITE -> Color.White
        LyricsColorTheme.NEON_GREEN -> Color(0xFF1DB954)
        LyricsColorTheme.CYAN -> Color(0xFF00E5FF)
        LyricsColorTheme.AMBER -> Color(0xFFFFB300)
        LyricsColorTheme.PURPLE -> Color(0xFFB388FF)
        LyricsColorTheme.ROSE -> Color(0xFFFF4081)
        LyricsColorTheme.ORANGE -> Color(0xFFFF6D00)
    }
}

@Composable
fun getLyricsThemeDisplayName(theme: LyricsColorTheme): String {
    return when (theme) {
        LyricsColorTheme.DEFAULT -> stringResource(R.string.lyrics_color_default)
        LyricsColorTheme.WHITE -> stringResource(R.string.lyrics_color_white)
        LyricsColorTheme.NEON_GREEN -> stringResource(R.string.lyrics_color_neon_green)
        LyricsColorTheme.CYAN -> stringResource(R.string.lyrics_color_cyan)
        LyricsColorTheme.AMBER -> stringResource(R.string.lyrics_color_amber)
        LyricsColorTheme.PURPLE -> stringResource(R.string.lyrics_color_purple)
        LyricsColorTheme.ROSE -> stringResource(R.string.lyrics_color_rose)
        LyricsColorTheme.ORANGE -> stringResource(R.string.lyrics_color_orange)
    }
}

@Composable
fun getLyricsPositionDisplayName(position: LyricsPosition): String {
    return when (position) {
        LyricsPosition.LEFT -> stringResource(R.string.lyrics_alignment_left)
        LyricsPosition.CENTER -> stringResource(R.string.lyrics_alignment_center)
        LyricsPosition.RIGHT -> stringResource(R.string.lyrics_alignment_right)
    }
}

@Composable
fun getLyricsFontWeightDisplayName(weight: Int): String {
    return when (weight) {
        400 -> stringResource(R.string.lyrics_font_weight_normal)
        500 -> stringResource(R.string.lyrics_font_weight_medium)
        600 -> stringResource(R.string.lyrics_font_weight_semibold)
        800 -> stringResource(R.string.lyrics_font_weight_extrabold)
        else -> stringResource(R.string.lyrics_font_weight_bold)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LyricsCustomizationSheet(
    onDismissRequest: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val coroutineScope = rememberCoroutineScope()

    ModalBottomSheet(
        onDismissRequest = onDismissRequest,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = modifier,
    ) {
        LyricsCustomizationContent(
            onClose = {
                coroutineScope.launch {
                    sheetState.hide()
                    onDismissRequest()
                }
            }
        )
    }
}

@Composable
fun LyricsCustomizationContent(
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var lyricsTextSize by rememberPreference(LyricsTextSizeKey, 28f)
    var lyricsFontWeight by rememberPreference(LyricsFontWeightKey, 700)
    var lyricsPosition by rememberEnumPreference(LyricsTextPositionKey, LyricsPosition.CENTER)
    var lyricsColorTheme by rememberPreference(LyricsColorThemeKey, LyricsColorTheme.DEFAULT.name)
    var translateLanguage by rememberPreference(TranslateLanguageKey, "en")

    val activeColor = getLyricsThemeColor(
        colorThemeName = lyricsColorTheme,
        primaryColor = MaterialTheme.colorScheme.primary,
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .padding(bottom = 32.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.lyrics_customization),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text = stringResource(R.string.lyrics_customization_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            TextButton(onClick = onClose) {
                Text(stringResource(R.string.close))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Live Preview Box with spacious padding and no clipping
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 20.dp),
            ) {
                val previewAlignment = when (lyricsPosition) {
                    LyricsPosition.LEFT -> TextAlign.Start
                    LyricsPosition.CENTER -> TextAlign.Center
                    LyricsPosition.RIGHT -> TextAlign.End
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = when (lyricsPosition) {
                        LyricsPosition.LEFT -> Arrangement.Start
                        LyricsPosition.CENTER -> Arrangement.Center
                        LyricsPosition.RIGHT -> Arrangement.End
                    },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        painter = painterResource(R.drawable.music_note),
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = stringResource(R.string.lyrics_preview_synced_title),
                        fontSize = (lyricsTextSize * 0.55f).coerceAtLeast(12f).sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f),
                        fontWeight = FontWeight.Medium,
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = stringResource(R.string.lyrics_preview_active_line),
                    fontSize = lyricsTextSize.sp,
                    fontWeight = getLyricsFontWeight(lyricsFontWeight),
                    color = activeColor,
                    textAlign = previewAlignment,
                    lineHeight = (lyricsTextSize * 1.25f).sp,
                    modifier = Modifier.fillMaxWidth(),
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = stringResource(R.string.lyrics_preview_next_line),
                    fontSize = (lyricsTextSize * 0.72f).coerceAtLeast(14f).sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f),
                    textAlign = previewAlignment,
                    lineHeight = (lyricsTextSize * 0.95f).sp,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }

        Spacer(modifier = Modifier.height(22.dp))

        // 1. Font Size Control
        Text(
            text = "${stringResource(R.string.lyrics_font_size)}: ${lyricsTextSize.roundToInt()} sp",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Slider(
            value = lyricsTextSize,
            onValueChange = { lyricsTextSize = it },
            valueRange = 16f..42f,
            modifier = Modifier.fillMaxWidth(),
        )
        // Preset Size Chips (scrollable to avoid truncation on small devices)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val sizeChips = listOf(
                stringResource(R.string.lyrics_font_size_small) to 20f,
                stringResource(R.string.lyrics_font_size_medium) to 26f,
                stringResource(R.string.lyrics_font_size_large) to 32f,
                stringResource(R.string.lyrics_font_size_extra_large) to 38f,
            )
            for ((label, size) in sizeChips) {
                val isSelected = lyricsTextSize.roundToInt() == size.roundToInt()
                FilterChip(
                    selected = isSelected,
                    onClick = { lyricsTextSize = size },
                    label = {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 2. Font Weight Control
        Text(
            text = "${stringResource(R.string.lyrics_font_weight)}: ${getLyricsFontWeightDisplayName(lyricsFontWeight)}",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val weightPresets = listOf(
                400 to stringResource(R.string.lyrics_font_weight_normal),
                500 to stringResource(R.string.lyrics_font_weight_medium),
                600 to stringResource(R.string.lyrics_font_weight_semibold),
                700 to stringResource(R.string.lyrics_font_weight_bold),
                800 to stringResource(R.string.lyrics_font_weight_extrabold),
            )
            for ((weightVal, label) in weightPresets) {
                val isSelected = lyricsFontWeight == weightVal
                FilterChip(
                    selected = isSelected,
                    onClick = { lyricsFontWeight = weightVal },
                    label = {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = getLyricsFontWeight(weightVal),
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 3. Alignment Control
        Text(
            text = stringResource(R.string.lyrics_alignment),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val alignmentOptions = listOf(
                LyricsPosition.LEFT,
                LyricsPosition.CENTER,
                LyricsPosition.RIGHT,
            )
            for (pos in alignmentOptions) {
                val isSelected = lyricsPosition == pos
                val containerColor by animateColorAsState(
                    targetValue = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                    label = "alignColor",
                )
                val contentColor by animateColorAsState(
                    targetValue = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                    label = "alignTextColor",
                )

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = containerColor,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { lyricsPosition = pos },
                ) {
                    Box(
                        modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = getLyricsPositionDisplayName(pos),
                            style = MaterialTheme.typography.labelMedium,
                            color = contentColor,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 4. Color Theme Control
        Text(
            text = stringResource(R.string.lyrics_color_theme),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            for (theme in LyricsColorTheme.values()) {
                val isSelected = lyricsColorTheme == theme.name
                val swatchColor = when (theme) {
                    LyricsColorTheme.DEFAULT -> MaterialTheme.colorScheme.primary
                    LyricsColorTheme.WHITE -> Color.White
                    LyricsColorTheme.NEON_GREEN -> Color(0xFF1DB954)
                    LyricsColorTheme.CYAN -> Color(0xFF00E5FF)
                    LyricsColorTheme.AMBER -> Color(0xFFFFB300)
                    LyricsColorTheme.PURPLE -> Color(0xFFB388FF)
                    LyricsColorTheme.ROSE -> Color(0xFFFF4081)
                    LyricsColorTheme.ORANGE -> Color(0xFFFF6D00)
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { lyricsColorTheme = theme.name }
                        .padding(horizontal = 4.dp, vertical = 6.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(swatchColor)
                            .then(
                                if (isSelected) {
                                    Modifier.border(3.dp, MaterialTheme.colorScheme.primary, CircleShape)
                                } else {
                                    Modifier.border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f), CircleShape)
                                }
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (isSelected) {
                            Icon(
                                painter = painterResource(R.drawable.check),
                                contentDescription = null,
                                modifier = Modifier.size(22.dp),
                                tint = if (swatchColor == Color.White) Color.Black else Color.White,
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = getLyricsThemeDisplayName(theme),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 5. Lyrics Language & Translation Switcher
        Text(
            text = stringResource(R.string.lyrics_language),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
        )
        Text(
            text = stringResource(R.string.lyrics_language_desc),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val languages = listOf(
                "vi" to "Tiếng Việt",
                "en" to "English",
                "ja" to "日本語 (Japanese)",
                "ko" to "한국어 (Korean)",
                "zh" to "中文 (Chinese)",
                "es" to "Español",
                "fr" to "Français",
                "de" to "Deutsch",
            )

            for ((code, name) in languages) {
                val isSelected = translateLanguage == code
                FilterChip(
                    selected = isSelected,
                    onClick = {
                        translateLanguage = code
                        LyricsTranslationHelper.triggerManualTranslation()
                    },
                    label = {
                        Text(
                            text = name,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                )
            }
        }
    }
}
