/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.menu

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.metrolist.innertube.YouTube
import com.metrolist.innertube.models.SongItem
import com.metrolist.innertube.utils.completed
import com.metrolist.music.LocalDatabase
import com.metrolist.music.LocalPlayerConnection
import com.metrolist.music.R
import com.metrolist.music.db.entities.PlaylistSong
import com.metrolist.music.db.entities.Song
import com.metrolist.music.db.entities.SongEntity
import com.metrolist.music.extensions.toMediaItem
import com.metrolist.music.models.MediaMetadata
import com.metrolist.music.models.toMediaMetadata
import com.metrolist.music.playback.queues.ListQueue
import com.metrolist.music.ui.component.DefaultDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class TrackSelectionItem(
    val id: String,
    val title: String,
    val subtitle: String?,
    val thumbnailUrl: String?,
    val mediaMetadata: MediaMetadata,
    val songEntity: SongEntity? = null
)

@Composable
fun AddToFavoritesQueueDialog(
    isVisible: Boolean,
    title: String,
    playlistId: String? = null,
    initialSongs: List<SongItem> = emptyList(),
    initialLocalSongs: List<Song> = emptyList(),
    initialSongEntities: List<SongEntity> = emptyList(),
    onDismiss: () -> Unit
) {
    if (!isVisible) return

    val context = LocalContext.current
    val database = LocalDatabase.current
    val playerConnection = LocalPlayerConnection.current
    val scope = rememberCoroutineScope()

    var isLoading by remember { mutableStateOf(true) }
    var tracks by remember { mutableStateOf<List<TrackSelectionItem>>(emptyList()) }
    var selectedIds by remember { mutableStateOf<Set<String>>(emptySet()) }

    LaunchedEffect(playlistId, initialSongs, initialLocalSongs, initialSongEntities) {
        isLoading = true
        withContext(Dispatchers.IO) {
            val loaded = mutableListOf<TrackSelectionItem>()
            if (initialLocalSongs.isNotEmpty()) {
                initialLocalSongs.forEach { song ->
                    val meta = song.toMediaMetadata()
                    loaded.add(
                        TrackSelectionItem(
                            id = song.song.id,
                            title = song.song.title,
                            subtitle = song.artists.joinToString(", ") { it.name },
                            thumbnailUrl = song.song.thumbnailUrl,
                            mediaMetadata = meta,
                            songEntity = song.song
                        )
                    )
                }
            } else if (initialSongEntities.isNotEmpty()) {
                initialSongEntities.forEach { songEnt ->
                    val meta = songEnt.toMediaMetadata()
                    loaded.add(
                        TrackSelectionItem(
                            id = songEnt.id,
                            title = songEnt.title,
                            subtitle = songEnt.albumName,
                            thumbnailUrl = songEnt.thumbnailUrl,
                            mediaMetadata = meta,
                            songEntity = songEnt
                        )
                    )
                }
            } else if (initialSongs.isNotEmpty()) {
                initialSongs.forEach { songItem ->
                    val meta = songItem.toMediaMetadata()
                    loaded.add(
                        TrackSelectionItem(
                            id = songItem.id,
                            title = songItem.title,
                            subtitle = songItem.artists.joinToString(", ") { it.name },
                            thumbnailUrl = songItem.thumbnail,
                            mediaMetadata = meta
                        )
                    )
                }
            } else if (!playlistId.isNullOrEmpty()) {
                // Try database local songs first
                val dbSongs = database.playlistSongsBlocking(playlistId).map(PlaylistSong::song)
                if (dbSongs.isNotEmpty()) {
                    dbSongs.forEach { song ->
                        val meta = song.toMediaMetadata()
                        loaded.add(
                            TrackSelectionItem(
                                id = song.song.id,
                                title = song.song.title,
                                subtitle = song.artists.joinToString(", ") { it.name },
                                thumbnailUrl = song.song.thumbnailUrl,
                                mediaMetadata = meta,
                                songEntity = song.song
                            )
                        )
                    }
                } else {
                    // Fetch YouTube playlist songs
                    val ytPlaylistResult = YouTube.playlist(playlistId).completed()
                    val ytSongs = ytPlaylistResult.getOrNull()?.songs.orEmpty()
                    ytSongs.forEach { songItem ->
                        val meta = songItem.toMediaMetadata()
                        loaded.add(
                            TrackSelectionItem(
                                id = songItem.id,
                                title = songItem.title,
                                subtitle = songItem.artists.joinToString(", ") { it.name },
                                thumbnailUrl = songItem.thumbnail,
                                mediaMetadata = meta
                            )
                        )
                    }
                }
            }
            tracks = loaded
            selectedIds = loaded.map { it.id }.toSet()
        }
        isLoading = false
    }

    DefaultDialog(
        onDismiss = onDismiss,
        content = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp)
            ) {
                // Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.errorContainer,
                        modifier = Modifier.size(42.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                painter = painterResource(R.drawable.favorite),
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.add_to_favorites_queue),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = title,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (isLoading) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(36.dp))
                    }
                } else if (tracks.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = stringResource(R.string.no_songs_found),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    // Select All Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.selected_tracks_format, selectedIds.size, tracks.size),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                        TextButton(
                            onClick = {
                                selectedIds = if (selectedIds.size == tracks.size) {
                                    emptySet()
                                } else {
                                    tracks.map { it.id }.toSet()
                                }
                            }
                        ) {
                            Text(
                                text = if (selectedIds.size == tracks.size) {
                                    stringResource(R.string.deselect_all)
                                } else {
                                    stringResource(R.string.select_all)
                                },
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }

                    // Tracks List
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 280.dp)
                    ) {
                        items(tracks, key = { it.id }) { track ->
                            val isSelected = track.id in selectedIds
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        selectedIds = if (isSelected) {
                                            selectedIds - track.id
                                        } else {
                                            selectedIds + track.id
                                        }
                                    }
                                    .padding(vertical = 6.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isSelected,
                                    onCheckedChange = { checked ->
                                        selectedIds = if (checked) {
                                            selectedIds + track.id
                                        } else {
                                            selectedIds - track.id
                                        }
                                    }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (!track.thumbnailUrl.isNullOrBlank()) {
                                        AsyncImage(
                                            model = track.thumbnailUrl,
                                            contentDescription = null,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    } else {
                                        Icon(
                                            painter = painterResource(R.drawable.music_note),
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = track.title,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (!track.subtitle.isNullOrBlank()) {
                                        Text(
                                            text = track.subtitle,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        buttons = {
            TextButton(onClick = onDismiss) {
                Text(text = stringResource(android.R.string.cancel))
            }
            Button(
                enabled = !isLoading && selectedIds.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                ),
                onClick = {
                    val selectedTracks = tracks.filter { it.id in selectedIds }
                    if (selectedTracks.isNotEmpty()) {
                        scope.launch(Dispatchers.IO) {
                            // Mark songs as liked in local DB
                            selectedTracks.forEach { item ->
                                database.transaction {
                                    insert(item.mediaMetadata, SongEntity::toggleLike)
                                }
                                item.songEntity?.let { songEnt ->
                                    database.query {
                                        update(songEnt.toggleLike())
                                    }
                                }
                            }

                            withContext(Dispatchers.Main) {
                                val mediaItems = selectedTracks.map { it.mediaMetadata.toMediaItem() }
                                if (playerConnection != null) {
                                    if (playerConnection.player.playbackState == androidx.media3.common.Player.STATE_IDLE ||
                                        playerConnection.player.mediaItemCount == 0
                                    ) {
                                        playerConnection.playQueue(
                                            ListQueue(
                                                title = context.getString(R.string.add_to_favorites_queue),
                                                items = mediaItems
                                            )
                                        )
                                    } else {
                                        playerConnection.addToQueue(mediaItems)
                                    }
                                }
                                Toast.makeText(
                                    context,
                                    context.getString(R.string.added_to_favorites_queue, selectedTracks.size),
                                    Toast.LENGTH_SHORT
                                ).show()
                                onDismiss()
                            }
                        }
                    }
                }
            ) {
                Icon(
                    painter = painterResource(R.drawable.favorite),
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "${stringResource(R.string.add_btn)} (${selectedIds.size})")
            }
        }
    )
}
