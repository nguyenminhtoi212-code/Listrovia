/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.api

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import timber.log.Timber
import java.io.File
import java.util.concurrent.TimeUnit

data class OpenRouterModelItem(
    val id: String,
    val name: String,
    val contextLength: Long = 0L,
    val pricing: String = "",
)

data class ClassifiedModels(
    val official: List<OpenRouterModelItem> = emptyList(),   // Phiên bản chính thức (Stable)
    val beta: List<OpenRouterModelItem> = emptyList(),       // Phiên bản thử nghiệm (Beta)
    val developer: List<OpenRouterModelItem> = emptyList(),  // Phiên bản nhà phát triển (Preview/Dev/Experimental)
)

data class MemoryCache(
    val timestamp: Long,
    val data: ClassifiedModels,
)

/**
 * Trình quản lý mô hình OpenRouter tự động tải, phân loại và lưu cache bộ nhớ
 * và bộ nhớ cục bộ (chống mất mạng) theo chu kỳ TTL (mặc định 15 phút).
 */
class OpenRouterModelManager(
    cacheTTLMinutes: Long = 15L,
    private val context: Context? = null,
) {
    private val apiUrl = "https://openrouter.ai/api/v1/models"
    private val storageKey = "openrouter_models_classified"
    private val cacheTTL = cacheTTLMinutes * 60 * 1000L // Thời gian sống của cache (mô-đun bộ nhớ)
    private var _memoryCache: MemoryCache? = null // Khởi tạo bộ nhớ đệm biến tạm

    private val client =
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()

    // 1. Hàm tải dữ liệu và phân loại mô hình
    suspend fun fetchAndClassifyModels(forceRefresh: Boolean = false): ClassifiedModels =
        withContext(Dispatchers.IO) {
            // Kiểm tra bộ nhớ tạm trong RAM để tránh gọi lại API liên tục gây rò rỉ bộ nhớ
            val now = System.currentTimeMillis()
            val cached = _memoryCache
            if (!forceRefresh && cached != null && (now - cached.timestamp < cacheTTL)) {
                return@withContext cached.data
            }

            try {
                val request =
                    Request.Builder()
                        .url(apiUrl)
                        .addHeader("HTTP-Referer", "https://metrolist.cc")
                        .addHeader("X-Title", "Metrolist Music")
                        .get()
                        .build()

                val response = client.newCall(request).execute()
                if (!response.isSuccessful) {
                    throw Exception("HTTP Error: ${response.code}")
                }

                val responseBody = response.body?.string() ?: throw Exception("Empty response body")
                val rawData = JSONObject(responseBody)
                val rawModels = rawData.optJSONArray("data") ?: JSONArray()

                val modelList = mutableListOf<RawModelData>()
                for (i in 0 until rawModels.length()) {
                    val obj = rawModels.optJSONObject(i) ?: continue
                    val id = obj.optString("id", "")
                    if (id.isBlank()) continue
                    val name = obj.optString("name", id)
                    val contextLength = obj.optLong("context_length", 0L)
                    val pricingObj = obj.optJSONObject("pricing")
                    val pricingStr = pricingObj?.toString() ?: ""
                    modelList.add(RawModelData(id = id, name = name, contextLength = contextLength, pricing = pricingStr))
                }

                // Phân loại mô hình theo danh mục
                val classified = _classifyModels(modelList)

                // Giải phóng bộ nhớ RAM cũ trước khi cập nhật dữ liệu mới
                _clearMemory()

                // Lưu vào RAM
                val newMemory = MemoryCache(timestamp = now, data = classified)
                _memoryCache = newMemory

                // Lưu vào LocalStorage / SharedPreferences (Chống mất mạng)
                saveToOfflineStorage(newMemory)

                return@withContext classified
            } catch (error: Exception) {
                Timber.w(error, "Mất kết nối mạng hoặc lỗi API. Đang khôi phục từ bộ nhớ đệm...")
                return@withContext _getOfflineFallback()
            }
        }

    // 2. Logic phân loại mô hình (Stable, Beta, Developer)
    private fun _classifyModels(models: List<RawModelData>): ClassifiedModels {
        val official = mutableListOf<OpenRouterModelItem>()
        val beta = mutableListOf<OpenRouterModelItem>()
        val developer = mutableListOf<OpenRouterModelItem>()

        models.forEach { model ->
            val id = model.id.lowercase()
            val name = (model.name ?: "").lowercase()

            // Rút gọn dữ liệu để tối ưu dung lượng bộ nhớ
            val cleanedItem =
                OpenRouterModelItem(
                    id = model.id,
                    name = model.name.ifBlank { model.id },
                    contextLength = model.contextLength,
                    pricing = model.pricing,
                )

            // Kiểm tra tiêu chí Developer / Experimental / Preview
            if (id.contains("dev") || id.contains("preview") || id.contains("exp") || name.contains("developer")) {
                developer.add(cleanedItem)
            }
            // Kiểm tra tiêu chí Beta
            else if (id.contains("beta") || name.contains("beta") || id.contains("free")) {
                beta.add(cleanedItem)
            }
            // Mặc định là phiên bản chính thức (Official / Stable)
            else {
                official.add(cleanedItem)
            }
        }

        return ClassifiedModels(
            official = official,
            beta = beta,
            developer = developer,
        )
    }

    // 3. Hàm giải phóng bộ nhớ chủ động
    fun _clearMemory() {
        _memoryCache = null
    }

    // 4. Lấy dữ liệu ngoại tuyến khi tắt mạng
    private fun _getOfflineFallback(): ClassifiedModels {
        try {
            val file = getCacheFile()
            if (file != null && file.exists()) {
                val saved = file.readText()
                if (saved.isNotBlank()) {
                    val parsed = JSONObject(saved)
                    val dataObj = parsed.optJSONObject("data")
                    if (dataObj != null) {
                        return parseClassifiedFromJson(dataObj)
                    }
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Lỗi đọc dữ liệu cache cũ")
        }

        // Dữ liệu ngoại tuyến cơ bản dự phòng nếu chưa có bộ nhớ đệm
        return getStaticOfflineFallback()
    }

    private fun saveToOfflineStorage(cache: MemoryCache) {
        try {
            val file = getCacheFile() ?: return
            val root = JSONObject()
            root.put("timestamp", cache.timestamp)

            val dataObj = JSONObject()
            dataObj.put("official", modelListToJsonArray(cache.data.official))
            dataObj.put("beta", modelListToJsonArray(cache.data.beta))
            dataObj.put("developer", modelListToJsonArray(cache.data.developer))

            root.put("data", dataObj)
            file.writeText(root.toString())
        } catch (e: Exception) {
            Timber.e(e, "Không thể lưu bộ nhớ đệm offline vào file")
        }
    }

    private fun getCacheFile(): File? {
        val dir = context?.cacheDir ?: File(System.getProperty("java.io.tmpdir") ?: ".")
        return File(dir, "$storageKey.json")
    }

    private fun modelListToJsonArray(list: List<OpenRouterModelItem>): JSONArray {
        val arr = JSONArray()
        list.forEach { item ->
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("name", item.name)
            obj.put("contextLength", item.contextLength)
            obj.put("pricing", item.pricing)
            arr.put(obj)
        }
        return arr
    }

    private fun parseClassifiedFromJson(obj: JSONObject): ClassifiedModels {
        fun parseList(key: String): List<OpenRouterModelItem> {
            val arr = obj.optJSONArray(key) ?: return emptyList()
            val list = mutableListOf<OpenRouterModelItem>()
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                list.add(
                    OpenRouterModelItem(
                        id = item.optString("id"),
                        name = item.optString("name"),
                        contextLength = item.optLong("contextLength", 0L),
                        pricing = item.optString("pricing", ""),
                    ),
                )
            }
            return list
        }

        return ClassifiedModels(
            official = parseList("official"),
            beta = parseList("beta"),
            developer = parseList("developer"),
        )
    }

    private fun getStaticOfflineFallback(): ClassifiedModels {
        val official =
            listOf(
                OpenRouterModelItem("google/gemini-2.5-flash-lite", "Google: Gemini 2.5 Flash Lite", 1000000L),
                OpenRouterModelItem("google/gemini-2.5-flash", "Google: Gemini 2.5 Flash", 1000000L),
                OpenRouterModelItem("openai/gpt-4o-mini", "OpenAI: GPT-4o-mini", 128000L),
                OpenRouterModelItem("deepseek/deepseek-chat", "DeepSeek: V3", 64000L),
                OpenRouterModelItem("meta-llama/llama-3.3-70b-instruct", "Meta: Llama 3.3 70B Instruct", 131072L),
                OpenRouterModelItem("x-ai/grok-4.1-fast", "xAI: Grok 4.1 Fast", 131072L),
            )

        val beta =
            listOf(
                OpenRouterModelItem("google/gemini-2.0-flash-thinking-exp:free", "Google: Gemini 2.0 Flash Thinking (Free)", 32000L),
                OpenRouterModelItem("meta-llama/llama-3.3-70b-instruct:free", "Meta: Llama 3.3 70B (Free)", 131072L),
                OpenRouterModelItem("deepseek/deepseek-r1:free", "DeepSeek: R1 (Free)", 64000L),
                OpenRouterModelItem("qwen/qwen-2.5-coder-32b-instruct:free", "Qwen: 2.5 Coder 32B (Free)", 32768L),
            )

        val developer =
            listOf(
                OpenRouterModelItem("google/gemini-3-flash-preview", "Google: Gemini 3 Flash Preview", 1000000L),
                OpenRouterModelItem("openai/gpt-4.5-preview", "OpenAI: GPT-4.5 Preview", 128000L),
                OpenRouterModelItem("deepseek/deepseek-v3.1-terminus:exacto", "DeepSeek: V3.1 Terminus (Dev)", 64000L),
            )

        return ClassifiedModels(official = official, beta = beta, developer = developer)
    }

    /**
     * Tự động lấy ra danh sách phiên bản Chính thức (Official) để sử dụng cho ứng dụng,
     * đồng thời log trạng thái các phiên bản theo đúng đặc tả yêu cầu.
     */
    suspend fun getModelsForApp(): List<OpenRouterModelItem> {
        val models = fetchAndClassifyModels()

        Timber.d("--- PHIÊN BẢN CHÍNH THỨC (STABLE) --- %s", models.official.map { it.id })
        Timber.d("--- PHIÊN BẢN BETA --- %s", models.beta.map { it.id })
        Timber.d("--- PHIÊN BẢN NHÀ PHÁT TRIỂN --- %s", models.developer.map { it.id })

        // Tự động lấy ra danh sách phiên bản Chính thức để dùng
        return models.official
    }

    /**
     * Lấy danh sách mô hình theo nhóm cấp độ (Stable, Beta, Developer)
     */
    suspend fun getModelsByTier(tier: String): List<OpenRouterModelItem> {
        val classified = fetchAndClassifyModels()
        return when (tier.lowercase()) {
            "beta" -> classified.beta
            "developer", "dev" -> classified.developer
            else -> classified.official
        }
    }

    /**
     * Đề xuất mô hình AI ngẫu nhiên theo thời gian thực từ đường dẫn https://openrouter.ai/api/v1/models.
     * Cho phép đọc dữ liệu mô hình mới nhất để đề xuất ngẫu nhiên.
     */
    suspend fun getRandomRecommendedModel(
        tier: String? = null,
        forceRefresh: Boolean = false,
    ): OpenRouterModelItem? {
        val classified = fetchAndClassifyModels(forceRefresh = forceRefresh)
        val pool = when (tier?.lowercase()) {
            "beta" -> classified.beta
            "developer", "dev" -> classified.developer
            "stable", "official" -> classified.official
            else -> classified.official + classified.beta + classified.developer
        }.filter { it.id.isNotBlank() }

        return pool.randomOrNull()
    }

    companion object {
        @Volatile
        private var defaultManager: OpenRouterModelManager? = null

        fun getInstance(context: Context? = null, cacheTTLMinutes: Long = 15L): OpenRouterModelManager {
            return defaultManager ?: synchronized(this) {
                defaultManager ?: OpenRouterModelManager(cacheTTLMinutes, context?.applicationContext).also {
                    defaultManager = it
                }
            }
        }

        /**
         * Lấy danh sách mô hình chính thức cho ứng dụng
         */
        suspend fun getModelsForApp(context: Context? = null): List<OpenRouterModelItem> {
            return getInstance(context).getModelsForApp()
        }
    }
}

private data class RawModelData(
    val id: String,
    val name: String,
    val contextLength: Long,
    val pricing: String,
)
