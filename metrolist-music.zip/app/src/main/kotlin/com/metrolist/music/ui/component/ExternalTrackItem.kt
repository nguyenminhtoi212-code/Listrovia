/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.component

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.metrolist.innertube.models.WatchEndpoint
import com.metrolist.music.LocalPlayerConnection
import com.metrolist.music.R
import com.metrolist.music.api.ExternalMusicProviderService
import com.metrolist.music.api.ExternalTrack
import com.metrolist.music.api.MusicSourceProvider
import com.metrolist.music.models.toMediaMetadata
import com.metrolist.music.playback.AudioPreviewManager
import com.metrolist.music.playback.queues.YouTubeQueue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ExternalTrackItem(
    track: ExternalTrack,
    onResolveVideoId: suspend (ExternalTrack) -> String?,
    modifier: Modifier = Modifier,
    externalService: ExternalMusicProviderService? = null,
    onArtistClick: ((String) -> Unit)? = null,
    trailingContent: (@Composable () -> Unit)? = null,
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val playerConnection = LocalPlayerConnection.current
    var isResolving by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var showCommentsSheet by remember { mutableStateOf(false) }
    var resolvedIdForComments by remember { mutableStateOf<String?>(null) }

    val currentPlayingPreviewId by AudioPreviewManager.currentPlayingTrackId.collectAsState()
    val isPreviewPlaying by AudioPreviewManager.isPlaying.collectAsState()
    val isThisPreviewPlaying = isPreviewPlaying && currentPlayingPreviewId == track.id

    fun playTrack() {
        if (playerConnection == null) return
        AudioPreviewManager.stopPreview()
        coroutineScope.launch {
            isResolving = true
            try {
                val videoId = onResolveVideoId(track)
                if (!videoId.isNullOrBlank()) {
                    val songItem = track.toSongItem(videoId)
                    playerConnection.playQueue(
                        YouTubeQueue(
                            endpoint = WatchEndpoint(videoId = videoId),
                            preloadItem = songItem.toMediaMetadata(),
                        )
                    )
                } else {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            context,
                            "Cannot resolve stream for ${track.title}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        context,
                        "Error streaming ${track.title}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } finally {
                isResolving = false
            }
        }
    }

    fun openComments() {
        coroutineScope.launch {
            val videoId = track.resolvedVideoId ?: onResolveVideoId(track) ?: ""
            if (videoId.isNotBlank()) {
                resolvedIdForComments = videoId
                showCommentsSheet = true
            } else {
                Toast.makeText(context, "Cannot load comments", Toast.LENGTH_SHORT).show()
            }
        }
    }

    if (showCommentsSheet && resolvedIdForComments != null && externalService != null) {
        TrackCommentsBottomSheet(
            videoId = resolvedIdForComments!!,
            trackTitle = "${track.title} - ${track.artist}",
            externalService = externalService,
            onDismiss = { showCommentsSheet = false }
        )
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .clickable { playTrack() }
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Thumbnail with Provider Badge
        Box(
            modifier = Modifier.size(52.dp)
        ) {
            AsyncImage(
                model = track.thumbnailUrl,
                contentDescription = track.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            )

            // Provider micro-badge
            Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.75f),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(2.dp)
                    .size(16.dp)
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_apple_music),
                    contentDescription = null,
                    tint = Color.Unspecified,
                    modifier = Modifier.padding(2.dp)
                )
            }
        }

        Spacer(Modifier.width(12.dp))

        // Titles and artist
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = track.title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurface
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 2.dp)
            ) {
                // Provider tag
                val providerColor = Color(0xFFFC3C44)
                Text(
                    text = "Apple Music",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    color = providerColor,
                    modifier = Modifier
                        .background(
                            color = providerColor.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                )

                Spacer(Modifier.width(6.dp))

                Text(
                    text = track.artist + if (track.album.isNotBlank()) " • ${track.album}" else "",
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(Modifier.width(4.dp))

        // 30s Audio Preview Snippet Button
        if (!track.previewUrl.isNullOrBlank()) {
            IconButton(
                onClick = {
                    AudioPreviewManager.playPreview(track.id, track.previewUrl)
                },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    painter = painterResource(if (isThisPreviewPlaying) R.drawable.pause else R.drawable.volume_up),
                    contentDescription = stringResource(R.string.preview_audio_clip),
                    tint = if (isThisPreviewPlaying) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        if (isResolving) {
            CircularProgressIndicator(
                modifier = Modifier.size(24.dp).padding(4.dp),
                strokeWidth = 2.dp,
                color = MaterialTheme.colorScheme.primary
            )
        } else if (trailingContent != null) {
            trailingContent()
        } else {
            Box {
                IconButton(
                    onClick = { showMenu = true },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        painter = painterResource(R.drawable.more_vert),
                        contentDescription = "Menu",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }

                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.play_full_song)) },
                        leadingIcon = {
                            Icon(
                                painter = painterResource(R.drawable.play),
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        onClick = {
                            showMenu = false
                            playTrack()
                        }
                    )

                    if (!track.previewUrl.isNullOrBlank()) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.preview_audio_clip)) },
                            leadingIcon = {
                                Icon(
                                    painter = painterResource(R.drawable.volume_up),
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            onClick = {
                                showMenu = false
                                AudioPreviewManager.playPreview(track.id, track.previewUrl)
                            }
                        )
                    }

                    if (externalService != null) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.view_comments_title)) },
                            leadingIcon = {
                                Icon(
                                    painter = painterResource(R.drawable.chat_bubble),
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            onClick = {
                                showMenu = false
                                openComments()
                            }
                        )
                    }

                    if (onArtistClick != null && track.artist.isNotBlank()) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.view_artist_channel)) },
                            leadingIcon = {
                                Icon(
                                    painter = painterResource(R.drawable.artist),
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            onClick = {
                                showMenu = false
                                onArtistClick(track.artist)
                            }
                        )
                    }

                    if (!track.externalUrl.isNullOrBlank()) {
                        val providerName = "Apple Music"
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.provider_open_external, providerName)) },
                            leadingIcon = {
                                Icon(
                                    painter = painterResource(R.drawable.link),
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            onClick = {
                                showMenu = false
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(track.externalUrl))
                                    context.startActivity(intent)
                                } catch (_: Exception) {}
                            }
                        )
                    }
                }
            }
        }
    }
}
