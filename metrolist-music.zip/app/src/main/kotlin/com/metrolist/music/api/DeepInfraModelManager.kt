package com.metrolist.music.api

import android.content.Context
import android.content.SharedPreferences
import com.metrolist.music.constants.DeepInfraDefaultModel
import com.metrolist.music.constants.DeepInfraModelsUrl
import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.statement.bodyAsText
import io.ktor.http.isSuccess
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import timber.log.Timber
import java.util.Locale
import java.util.concurrent.TimeUnit

data class DeepInfraModelItem(
    val id: String,
    val name: String,
    val providerName: String = "",
    val description: String = "",
    val descriptionVi: String = "",
    val contextLength: Long = 0L,
    val maxTokens: Long = 0L,
    val tags: List<String> = emptyList(),
    val inputCost: Double = 0.0,
    val outputCost: Double = 0.0,
    val isChat: Boolean = true,
    val isReasoning: Boolean = false,
    val rank: Int = 999,
    val rankTitleEn: String = "",
    val rankTitleVi: String = "",
) {
    val formattedContext: String
        get() = when {
            contextLength >= 1048576L -> "${contextLength / 1048576L}M"
            contextLength >= 1024L -> "${contextLength / 1024L}k"
            contextLength > 0L -> "$contextLength"
            else -> ""
        }

    val pricingBadge: String
        get() = when {
            inputCost == 0.0 && outputCost == 0.0 -> "Free"
            inputCost > 0.0 -> String.format(Locale.US, "$%.2f/M", inputCost)
            else -> ""
        }

    fun getDescriptionByLanguage(isVi: Boolean): String {
        return if (isVi && descriptionVi.isNotBlank()) descriptionVi else description
    }

    fun getRankTitleByLanguage(isVi: Boolean): String {
        return if (isVi && rankTitleVi.isNotBlank()) rankTitleVi else rankTitleEn
    }
}

data class DeepInfraClassifiedModels(
    val recommended: List<DeepInfraModelItem>,
    val chatModels: List<DeepInfraModelItem>,
    val reasoningModels: List<DeepInfraModelItem>,
    val allModels: List<DeepInfraModelItem>,
    val timestamp: Long = System.currentTimeMillis(),
) {
    val rankedModels: List<DeepInfraModelItem> get() = recommended
}

class DeepInfraModelManager(
    private val cacheTTLMinutes: Long = 15L,
    private val context: Context? = null,
) {
    private val apiUrl = DeepInfraModelsUrl
    private val storageKey = "deepinfra_models_realtime_cache_v2"
    private val cacheTTL = cacheTTLMinutes * 60 * 1000L

    private var memoryCache: Pair<Long, DeepInfraClassifiedModels>? = null

    private val ktorClient: HttpClient by lazy {
        HttpClient(OkHttp) {
            install(HttpTimeout) {
                requestTimeoutMillis = 20_000L
                connectTimeoutMillis = 15_000L
                socketTimeoutMillis = 20_000L
            }
            expectSuccess = false
        }
    }

    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    suspend fun fetchModels(forceRefresh: Boolean = false): DeepInfraClassifiedModels =
        withContext(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            val cached = memoryCache
            if (!forceRefresh && cached != null && (now - cached.first < cacheTTL)) {
                return@withContext cached.second
            }

            try {
                // Fetch models using Ktor client directly from https://api.deepinfra.com/v1/openai/models
                val responseBody = try {
                    val response = ktorClient.get(apiUrl) {
                        header("User-Agent", "Mozilla/5.0 (Android; Metrolist Music/1.0)")
                        header("Accept", "application/json")
                    }
                    if (!response.status.isSuccess()) {
                        throw Exception("Ktor HTTP Error from DeepInfra: ${response.status.value}")
                    }
                    val body = response.bodyAsText()
                    if (body.isBlank()) throw Exception("Empty body from Ktor")
                    body
                } catch (ktorErr: Exception) {
                    Timber.w(ktorErr, "Ktor request to DeepInfra failed, trying OkHttp fallback")
                    val request = Request.Builder()
                        .url(apiUrl)
                        .addHeader("User-Agent", "Mozilla/5.0 (Android; Metrolist Music/1.0)")
                        .addHeader("Accept", "application/json")
                        .get()
                        .build()
                    val response = okHttpClient.newCall(request).execute()
                    if (!response.isSuccessful) {
                        throw Exception("OkHttp Error from DeepInfra: ${response.code}")
                    }
                    response.body?.string() ?: throw Exception("Empty response body from DeepInfra")
                }

                val rawData = JSONObject(responseBody)
                val rawModels = rawData.optJSONArray("data") ?: JSONArray()

                val allList = mutableListOf<DeepInfraModelItem>()
                val chatList = mutableListOf<DeepInfraModelItem>()
                val reasoningList = mutableListOf<DeepInfraModelItem>()

                for (i in 0 until rawModels.length()) {
                    val obj = rawModels.optJSONObject(i) ?: continue
                    val id = obj.optString("id", "")
                    if (id.isBlank()) continue

                    val provider = if (id.contains("/")) id.substringBefore("/") else "deepinfra"
                    val modelName = if (id.contains("/")) id.substringAfter("/") else id

                    val metadata = obj.optJSONObject("metadata")
                    val description = metadata?.optString("description", "") ?: ""
                    val contextLength = metadata?.optLong("context_length", 0L) ?: 0L
                    val maxTokens = metadata?.optLong("max_tokens", 0L) ?: 0L

                    var inputCost = 0.0
                    var outputCost = 0.0
                    val pricing = metadata?.optJSONObject("pricing")
                    if (pricing != null) {
                        inputCost = pricing.optDouble("input_tokens", 0.0)
                        outputCost = pricing.optDouble("output_tokens", 0.0)
                    }

                    val tagsArray = metadata?.optJSONArray("tags")
                    val tags = mutableListOf<String>()
                    if (tagsArray != null) {
                        for (t in 0 until tagsArray.length()) {
                            tags.add(tagsArray.optString(t))
                        }
                    }

                    val isReasoning = tags.contains("reasoning") ||
                            id.contains("R1", ignoreCase = true) ||
                            id.contains("reasoning", ignoreCase = true) ||
                            id.contains("o1", ignoreCase = true) ||
                            id.contains("o3", ignoreCase = true)

                    val isChat = tags.contains("chat") || tags.contains("text-generation") ||
                            id.contains("Instruct", ignoreCase = true) ||
                            id.contains("chat", ignoreCase = true) ||
                            id.contains("deepseek", ignoreCase = true) ||
                            id.contains("llama", ignoreCase = true) ||
                            id.contains("qwen", ignoreCase = true) ||
                            id.contains("mistral", ignoreCase = true) ||
                            id.contains("gemma", ignoreCase = true) ||
                            id.contains("gemini", ignoreCase = true) ||
                            id.contains("claude", ignoreCase = true) ||
                            id.contains("GLM", ignoreCase = true) ||
                            id.contains("MiMo", ignoreCase = true) ||
                            id.contains("Kimi", ignoreCase = true) ||
                            isReasoning

                    val (rank, rankTitleEn, rankTitleVi, customDescVi) = determineRankAndInfo(id, isReasoning)

                    val descriptionVi = if (customDescVi.isNotBlank()) {
                        customDescVi
                    } else {
                        generateVietnameseDescription(id, provider, tags, contextLength, isReasoning)
                    }

                    val item = DeepInfraModelItem(
                        id = id,
                        name = modelName,
                        providerName = provider,
                        description = description,
                        descriptionVi = descriptionVi,
                        contextLength = contextLength,
                        maxTokens = maxTokens,
                        tags = tags,
                        inputCost = inputCost,
                        outputCost = outputCost,
                        isChat = isChat,
                        isReasoning = isReasoning,
                        rank = rank,
                        rankTitleEn = rankTitleEn,
                        rankTitleVi = rankTitleVi,
                    )

                    allList.add(item)
                    if (isChat) chatList.add(item)
                    if (isReasoning) reasoningList.add(item)
                }

                // Sort recommended models strictly by rank
                val recommendedList = allList
                    .filter { it.rank < 999 }
                    .sortedBy { it.rank }
                    .toMutableList()

                // If recommended list has fewer than 8, supplement with top chat models
                if (recommendedList.size < 8) {
                    for (item in chatList) {
                        if (!recommendedList.contains(item)) {
                            recommendedList.add(item)
                            if (recommendedList.size >= 12) break
                        }
                    }
                }

                val classified = DeepInfraClassifiedModels(
                    recommended = recommendedList,
                    chatModels = if (chatList.isNotEmpty()) chatList else allList,
                    reasoningModels = reasoningList,
                    allModels = allList,
                    timestamp = now,
                )

                memoryCache = Pair(now, classified)
                saveToLocalStorage(classified)
                Timber.i("Successfully loaded ${allList.size} real-time models from DeepInfra")
                classified
            } catch (e: Exception) {
                Timber.w(e, "Error fetching models from DeepInfra, falling back to local storage or defaults")
                loadFromLocalStorage() ?: getStaticFallback()
            }
        }

    private fun determineRankAndInfo(id: String, isReasoning: Boolean): Quadruple<Int, String, String, String> {
        val lower = id.lowercase()
        return when {
            lower == "deepseek-ai/deepseek-v4-flash" -> Quadruple(
                1,
                "#1 Pick: Ultra-Fast Multilingual Inference",
                "#1 Đề xuất: Siêu tốc & Đa ngôn ngữ tối ưu",
                "Mô hình thế hệ mới siêu nhanh, hỗ trợ bộ nhớ đệm lệnh (Prompt Cache), dịch thuật tiếng Việt chuẩn xác và chi phí cực thấp."
            )
            lower.contains("deepseek-v4-pro") -> Quadruple(
                2,
                "#2 Flagship Reasoning: Deep Semantic Understanding",
                "#2 Suy luận đỉnh cao: Hiểu ngữ cảnh sâu sắc",
                "Mô hình suy luận hàng đầu thế giới, am hiểu văn phong ngữ cảnh phức tạp, dịch chuẩn từng sắc thái từ ngữ và ca từ."
            )
            lower.contains("deepseek-r1") -> Quadruple(
                2,
                "#2 Deep Reasoning: Step-by-Step Chain of Thought",
                "#2 Tư duy đa bước: Chuỗi suy luận chuyên sâu",
                "Mô hình tư duy lý luận R1 hàng đầu thế giới, tự kiểm tra và tối ưu kết quả dịch thuật các đoạn lời bài hát phức tạp."
            )
            lower.contains("llama-4-scout") -> Quadruple(
                3,
                "#3 Meta Next-Gen MoE: Ultra Intelligent",
                "#3 Đỉnh cao Meta: Kiến trúc MoE thế hệ mới",
                "Mô hình MoE hiện đại bậc nhất của Meta, phản hồi tự nhiên, lưu loát và ngữ cảnh dài mượt mà."
            )
            lower.contains("llama-3.3-70b") -> Quadruple(
                3,
                "#3 Meta 70B Foundation Turbo",
                "#3 Meta 70B Turbo mạnh mẽ",
                "Khả năng dịch thuật văn phong xuất sắc, từ vựng phong phú và chuẩn mực ngữ pháp cao."
            )
            lower.contains("meta-llama-3.1-8b") -> Quadruple(
                3,
                "#3 Meta Lightweight & Efficient",
                "#3 Meta 8B gọn nhẹ & tốc độ",
                "Mô hình gọn nhẹ, phản hồi nhanh chóng cho các đoạn lời bài hát thông dụng."
            )
            lower.contains("qwen3-coder") -> Quadruple(
                4,
                "#4 Alibaba Qwen3 Flagship: Massive 480B MoE",
                "#4 Siêu tham số Qwen3 MoE từ Alibaba",
                "Mô hình khổng lồ từ Alibaba, đứng đầu về chất lượng tiếng Việt và ngôn ngữ châu Á."
            )
            lower.contains("qwen2.5-72b") -> Quadruple(
                4,
                "#4 Asian Languages Master: Superb Vietnamese",
                "#4 Bậc thầy tiếng Việt & Châu Á",
                "Dịch thuật lời bài hát cực kỳ mượt mà, nắm bắt trọn vẹn ngữ điệu và thành ngữ tiếng Việt."
            )
            lower.contains("qwen3.5") || lower.contains("qwen3-32b") -> Quadruple(
                4,
                "#4 Next-Gen Qwen Reasoning & Chat",
                "#4 Qwen thế hệ mới thông minh",
                "Cân bằng hoàn hảo giữa tốc độ và độ chính xác dịch thuật đa ngôn ngữ."
            )
            lower.contains("gemini-2.5-flash") || lower.contains("gemini-3.5-flash") -> Quadruple(
                5,
                "#5 Google Gemini State-of-the-Art",
                "#5 Công nghệ Google Gemini tiên tiến",
                "Mô hình đa phương thức từ Google, dịch chuẩn xác từng từ với tốc độ ấn tượng."
            )
            lower.contains("gemma-4-31b") || lower.contains("gemma-3-27b") || lower.contains("gemma-3-12b") -> Quadruple(
                5,
                "#5 Google Gemma Multilingual",
                "#5 Google Gemma đa ngôn ngữ",
                "Mô hình mã nguồn mở Google DeepMind hiểu hơn 140 ngôn ngữ, tối ưu hóa ngữ nghĩa câu từ."
            )
            lower.contains("mistral-nemo") || lower.contains("mistral-small") -> Quadruple(
                6,
                "#6 High-Efficiency European AI: Fast & Sharp",
                "#6 Trí tuệ châu Âu: Gọn nhẹ & Sắc bén",
                "Sản phẩm từ Mistral AI của Pháp, phản hồi chuẩn xác, tiết kiệm tài nguyên và dịch thuật tinh tế."
            )
            lower.contains("mimo-v2.5") -> Quadruple(
                7,
                "#7 Xiaomi MoE Multi-Token Prediction",
                "#7 Kiến trúc MoE Xiaomi thế hệ mới",
                "Dự đoán trước nhiều token đồng thời, tối ưu hóa độ trễ thời gian thực cho stream."
            )
            lower.contains("kimi-k2.7") || lower.contains("kimi-k2.6") -> Quadruple(
                8,
                "#8 Moonshot AI: Massive 256k Context Window",
                "#8 Chuyên gia ngữ cảnh lớn 256k tokens",
                "Khả năng ghi nhớ ngữ cảnh cực lớn, duy trì dịch thuật nhất quán từ đầu đến cuối bài hát."
            )
            lower.contains("minimax-m2.7") -> Quadruple(
                9,
                "#9 MiniMax High-Speed Turbo Streaming",
                "#9 MiniMax Turbo tốc độ cao",
                "Mô hình hội thoại thế hệ mới tối ưu cho luồng dữ liệu thời gian thực và văn phong mượt mà."
            )
            lower.contains("gpt-oss-120b") -> Quadruple(
                10,
                "#10 Open Parameter Titan: Comprehensive",
                "#10 Siêu tham số mở toàn diện 120B",
                "Văn phong tự nhiên, kho tàng từ vựng phong phú cho mọi thể loại âm nhạc và văn học."
            )
            lower.contains("claude-opus") -> Quadruple(
                11,
                "#11 Anthropic Claude: High Literary Precision",
                "#11 Trí tuệ Anthropic: Độ chính xác văn học",
                "Chất lượng dịch thuật câu chữ giàu cảm xúc, uyển chuyển và thấu hiểu sâu sắc."
            )
            lower.contains("glm-5") || lower.contains("glm-4") -> Quadruple(
                12,
                "#12 Zhipu AI GLM: Bilingual Excellence",
                "#12 Zhipu GLM: Song ngữ xuất sắc",
                "Mô hình song ngữ mạnh mẽ, tối ưu hóa xử lý ngôn ngữ Đông Á và dịch thuật tự nhiên."
            )
            lower.contains("nemotron") -> Quadruple(
                13,
                "#13 NVIDIA High Performance Inference",
                "#13 NVIDIA hiệu năng cao",
                "Tăng tốc bởi kiến trúc của NVIDIA, tối ưu hóa cho độ trễ thấp và độ tin cậy cao."
            )
            else -> Quadruple(999, "", "", "")
        }
    }

    private fun generateVietnameseDescription(
        id: String,
        provider: String,
        tags: List<String>,
        contextLength: Long,
        isReasoning: Boolean,
    ): String {
        val lower = id.lowercase()
        val contextStr = if (contextLength >= 1024L) "với cửa sổ ngữ cảnh ${contextLength / 1024L}k tokens" else ""

        return when {
            isReasoning -> "Mô hình suy luận logic chuyên sâu với cơ chế phân tích từng bước, tối ưu cho ngữ cảnh phức tạp $contextStr."
            tags.contains("code") || lower.contains("code") || lower.contains("coder") ->
                "Mô hình chuyên sâu về cấu trúc logic và lập trình cú pháp $contextStr, độ chính xác tuyệt đối."
            tags.contains("vision") || tags.contains("vlm") || lower.contains("vl") ->
                "Mô hình đa phương thức tiên tiến kết hợp thị giác và xử lý ngôn ngữ tự nhiên $contextStr."
            lower.contains("qwen") ->
                "Mô hình ngôn ngữ thế hệ mới từ Alibaba, đặc biệt xuất sắc trong việc thấu hiểu tiếng Việt và ngữ nghĩa Á Đông."
            lower.contains("llama") ->
                "Mô hình mã nguồn mở hàng đầu từ Meta AI $contextStr, văn phong tự nhiên và diễn đạt mạch lạc."
            lower.contains("deepseek") ->
                "Mô hình hiệu năng cao từ DeepSeek, xử lý dịch thuật nhanh chóng và chuẩn xác."
            lower.contains("gemma") ->
                "Mô hình mã nguồn mở hiện đại từ Google DeepMind $contextStr, đáng tin cậy và đa ngôn ngữ."
            lower.contains("mistral") ->
                "Mô hình hiệu năng cao từ châu Âu, phản hồi gọn gàng và tiết kiệm độ trễ."
            lower.contains("flux") ->
                "Mô hình tạo ảnh đồ họa chất lượng cao của Black Forest Labs."
            else ->
                "Mô hình trí tuệ nhân tạo thời gian thực được phục vụ trên hạ tầng máy chủ DeepInfra $contextStr."
        }
    }

    private fun saveToLocalStorage(classified: DeepInfraClassifiedModels) {
        val prefs = getPreferences() ?: return
        try {
            val root = JSONObject()
            root.put("timestamp", classified.timestamp)

            fun serializeList(list: List<DeepInfraModelItem>): JSONArray {
                val array = JSONArray()
                for (item in list) {
                    val o = JSONObject()
                    o.put("id", item.id)
                    o.put("name", item.name)
                    o.put("provider", item.providerName)
                    o.put("description", item.description)
                    o.put("description_vi", item.descriptionVi)
                    o.put("context_length", item.contextLength)
                    o.put("max_tokens", item.maxTokens)
                    o.put("input_cost", item.inputCost)
                    o.put("output_cost", item.outputCost)
                    o.put("is_chat", item.isChat)
                    o.put("is_reasoning", item.isReasoning)
                    o.put("rank", item.rank)
                    o.put("rank_title_en", item.rankTitleEn)
                    o.put("rank_title_vi", item.rankTitleVi)
                    val tArray = JSONArray()
                    item.tags.forEach { tArray.put(it) }
                    o.put("tags", tArray)
                    array.put(o)
                }
                return array
            }

            root.put("recommended", serializeList(classified.recommended))
            root.put("chat", serializeList(classified.chatModels))
            root.put("reasoning", serializeList(classified.reasoningModels))
            root.put("all", serializeList(classified.allModels))

            prefs.edit().putString(storageKey, root.toString()).apply()
        } catch (e: Exception) {
            Timber.e(e, "Failed to cache DeepInfra models to local storage")
        }
    }

    private fun loadFromLocalStorage(): DeepInfraClassifiedModels? {
        val prefs = getPreferences() ?: return null
        val raw = prefs.getString(storageKey, null) ?: return null
        return try {
            val root = JSONObject(raw)

            fun deserializeList(key: String): List<DeepInfraModelItem> {
                val array = root.optJSONArray(key) ?: return emptyList()
                val list = mutableListOf<DeepInfraModelItem>()
                for (i in 0 until array.length()) {
                    val o = array.optJSONObject(i) ?: continue
                    val tArray = o.optJSONArray("tags")
                    val tags = mutableListOf<String>()
                    if (tArray != null) {
                        for (t in 0 until tArray.length()) {
                            tags.add(tArray.optString(t))
                        }
                    }
                    list.add(
                        DeepInfraModelItem(
                            id = o.optString("id"),
                            name = o.optString("name"),
                            providerName = o.optString("provider"),
                            description = o.optString("description"),
                            descriptionVi = o.optString("description_vi"),
                            contextLength = o.optLong("context_length"),
                            maxTokens = o.optLong("max_tokens"),
                            inputCost = o.optDouble("input_cost", 0.0),
                            outputCost = o.optDouble("output_cost", 0.0),
                            tags = tags,
                            isChat = o.optBoolean("is_chat", true),
                            isReasoning = o.optBoolean("is_reasoning", false),
                            rank = o.optInt("rank", 999),
                            rankTitleEn = o.optString("rank_title_en"),
                            rankTitleVi = o.optString("rank_title_vi"),
                        )
                    )
                }
                return list
            }

            val rec = deserializeList("recommended")
            val chat = deserializeList("chat")
            val reasoning = deserializeList("reasoning")
            val all = deserializeList("all")
            if (all.isEmpty()) null
            else DeepInfraClassifiedModels(
                recommended = rec,
                chatModels = chat,
                reasoningModels = reasoning,
                allModels = all,
                timestamp = root.optLong("timestamp", System.currentTimeMillis()),
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun getPreferences(): SharedPreferences? {
        return context?.getSharedPreferences("metrolist_deepinfra_models", Context.MODE_PRIVATE)
    }

    fun getStaticFallback(): DeepInfraClassifiedModels {
        val fallbackList = listOf(
            DeepInfraModelItem(
                id = DeepInfraDefaultModel,
                name = "DeepSeek-V4-Flash",
                providerName = "deepseek-ai",
                description = "High efficiency, ultra-fast inference chat model with prompt cache and reasoning",
                descriptionVi = "Mô hình thế hệ mới siêu nhanh, hỗ trợ bộ nhớ đệm lệnh (Prompt Cache), dịch thuật tiếng Việt chuẩn xác và chi phí cực thấp.",
                contextLength = 131072L,
                tags = listOf("chat", "prompt_cache", "reasoning"),
                inputCost = 0.08,
                outputCost = 0.16,
                isChat = true,
                isReasoning = true,
                rank = 1,
                rankTitleEn = "#1 Pick: Ultra-Fast Multilingual Inference",
                rankTitleVi = "#1 Đề xuất: Siêu tốc & Đa ngôn ngữ tối ưu",
            ),
            DeepInfraModelItem(
                id = "deepseek-ai/DeepSeek-V4-Pro",
                name = "DeepSeek-V4-Pro",
                providerName = "deepseek-ai",
                description = "State-of-the-art flagship reasoning and multilingual model",
                descriptionVi = "Mô hình suy luận hàng đầu thế giới, am hiểu văn phong ngữ cảnh phức tạp, dịch chuẩn từng sắc thái từ ngữ.",
                contextLength = 131072L,
                tags = listOf("chat", "prompt_cache"),
                inputCost = 0.27,
                outputCost = 1.10,
                isChat = true,
                isReasoning = true,
                rank = 2,
                rankTitleEn = "#2 Flagship Reasoning: Deep Semantic Understanding",
                rankTitleVi = "#2 Suy luận đỉnh cao: Hiểu ngữ cảnh sâu sắc",
            ),
            DeepInfraModelItem(
                id = "meta-llama/Llama-4-Scout-17B-16E-Instruct",
                name = "Llama-4-Scout-17B-16E-Instruct",
                providerName = "meta-llama",
                description = "Next-generation high-speed multimodal reasoning model",
                descriptionVi = "Mô hình MoE hiện đại bậc nhất của Meta, phản hồi tự nhiên, lưu loát và ngữ cảnh dài mượt mà.",
                contextLength = 131072L,
                tags = listOf("chat", "vlm", "vision"),
                inputCost = 0.15,
                outputCost = 0.60,
                isChat = true,
                isReasoning = false,
                rank = 3,
                rankTitleEn = "#3 Meta Next-Gen MoE: Ultra Intelligent",
                rankTitleVi = "#3 Đỉnh cao Meta: Kiến trúc MoE thế hệ mới",
            ),
            DeepInfraModelItem(
                id = "meta-llama/Llama-3.3-70B-Instruct-Turbo",
                name = "Llama-3.3-70B-Instruct-Turbo",
                providerName = "meta-llama",
                description = "Turbo-accelerated 70B parameter Llama-3.3 foundation model",
                descriptionVi = "Khả năng dịch thuật văn phong xuất sắc, từ vựng phong phú và chuẩn mực ngữ pháp cao.",
                contextLength = 131072L,
                tags = listOf("chat"),
                inputCost = 0.23,
                outputCost = 0.40,
                isChat = true,
                isReasoning = false,
                rank = 3,
                rankTitleEn = "#3 Meta 70B Foundation Turbo",
                rankTitleVi = "#3 Meta 70B Turbo mạnh mẽ",
            ),
            DeepInfraModelItem(
                id = "Qwen/Qwen2.5-72B-Instruct",
                name = "Qwen2.5-72B-Instruct",
                providerName = "Qwen",
                description = "Top tier open-source language model with multilingual comprehension",
                descriptionVi = "Dịch thuật lời bài hát cực kỳ mượt mà, nắm bắt trọn vẹn ngữ điệu và thành ngữ tiếng Việt.",
                contextLength = 131072L,
                tags = listOf("chat"),
                inputCost = 0.23,
                outputCost = 0.40,
                isChat = true,
                isReasoning = false,
                rank = 4,
                rankTitleEn = "#4 Asian Languages Master: Superb Vietnamese",
                rankTitleVi = "#4 Bậc thầy tiếng Việt & Châu Á",
            ),
            DeepInfraModelItem(
                id = "google/gemma-4-31B-it-turbo",
                name = "gemma-4-31B-it-turbo",
                providerName = "google",
                description = "Ultra speed open-weights model from Google DeepMind",
                descriptionVi = "Mô hình mã nguồn mở Google DeepMind với khả năng dịch thuật linh hoạt và độ trễ thấp.",
                contextLength = 131072L,
                tags = listOf("chat", "reasoning"),
                inputCost = 0.14,
                outputCost = 0.28,
                isChat = true,
                isReasoning = true,
                rank = 5,
                rankTitleEn = "#5 Google Gemma Multilingual",
                rankTitleVi = "#5 Google Gemma đa ngôn ngữ",
            ),
            DeepInfraModelItem(
                id = "mistralai/Mistral-Nemo-Instruct-2407",
                name = "Mistral-Nemo-Instruct-2407",
                providerName = "mistralai",
                description = "12B multilingual model built jointly by Mistral AI and NVIDIA",
                descriptionVi = "Sản phẩm từ Mistral AI của Pháp, phản hồi chuẩn xác, tiết kiệm tài nguyên và dịch thuật tinh tế.",
                contextLength = 131072L,
                tags = listOf("chat"),
                inputCost = 0.04,
                outputCost = 0.08,
                isChat = true,
                isReasoning = false,
                rank = 6,
                rankTitleEn = "#6 High-Efficiency European AI: Fast & Sharp",
                rankTitleVi = "#6 Trí tuệ châu Âu: Gọn nhẹ & Sắc bén",
            ),
        )

        return DeepInfraClassifiedModels(
            recommended = fallbackList,
            chatModels = fallbackList,
            reasoningModels = fallbackList.filter { it.isReasoning },
            allModels = fallbackList,
            timestamp = System.currentTimeMillis(),
        )
    }

    companion object {
        @Volatile
        private var defaultManager: DeepInfraModelManager? = null

        fun getInstance(context: Context? = null): DeepInfraModelManager {
            return defaultManager ?: synchronized(this) {
                defaultManager ?: DeepInfraModelManager(15L, context?.applicationContext).also {
                    defaultManager = it
                }
            }
        }
    }
}

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
