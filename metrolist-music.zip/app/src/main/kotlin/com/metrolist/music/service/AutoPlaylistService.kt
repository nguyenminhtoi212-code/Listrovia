/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.service

import android.content.Context
import com.metrolist.music.R
import com.metrolist.music.db.MusicDatabase
import com.metrolist.music.db.entities.PlaylistEntity
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Service that uses Room database metadata (listening history/events & play counts)
 * to auto-generate 'Recently Played' and 'Most Played' playlists for the user.
 */
@Singleton
class AutoPlaylistService @Inject constructor(
    @ApplicationContext private val context: Context,
    private val database: MusicDatabase,
) {
    /**
     * Auto-generates 'Recently Played' playlist in Room database using listening event metadata.
     */
    suspend fun generateRecentlyPlayedPlaylist(limit: Int = 50): PlaylistEntity = withContext(Dispatchers.IO) {
        val now = LocalDateTime.now()
        val recentEvents = database.events().first()
        val recentSongs = recentEvents
            .map { it.song }
            .distinctBy { it.id }
            .take(limit)

        val playlistId = PlaylistEntity.RECENTLY_PLAYED_PLAYLIST_ID
        val playlistName = context.getString(R.string.recently_played)

        val existingPlaylist = database.playlist(playlistId).first()?.playlist
        val playlistEntity = existingPlaylist?.copy(
            name = playlistName,
            isEditable = true,
            isLocal = true,
            lastUpdateTime = now,
        ) ?: PlaylistEntity(
            id = playlistId,
            name = playlistName,
            isEditable = true,
            isLocal = true,
            bookmarkedAt = now,
            lastUpdateTime = now,
        )

        if (existingPlaylist == null) {
            database.insert(playlistEntity)
        } else {
            database.update(playlistEntity)
        }

        database.clearPlaylist(playlistId)

        val fullPlaylist = database.playlist(playlistId).first()
        if (fullPlaylist != null && recentSongs.isNotEmpty()) {
            database.addSongsToPlaylist(fullPlaylist, recentSongs.map { it.id to null })
        }

        playlistEntity
    }

    /**
     * Auto-generates 'Most Played' playlist in Room database using song play count metadata.
     */
    suspend fun generateMostPlayedPlaylist(limit: Int = 50): PlaylistEntity = withContext(Dispatchers.IO) {
        val now = LocalDateTime.now()
        val mostPlayedSongs = database.mostPlayedSongs(
            fromTimeStamp = LocalDateTime.of(1970, 1, 1, 0, 0),
            limit = limit,
            toTimeStamp = now,
        ).first().distinctBy { it.id }

        val playlistId = PlaylistEntity.MOST_PLAYED_PLAYLIST_ID
        val playlistName = context.getString(R.string.most_played)

        val existingPlaylist = database.playlist(playlistId).first()?.playlist
        val playlistEntity = existingPlaylist?.copy(
            name = playlistName,
            isEditable = true,
            isLocal = true,
            lastUpdateTime = now,
        ) ?: PlaylistEntity(
            id = playlistId,
            name = playlistName,
            isEditable = true,
            isLocal = true,
            bookmarkedAt = now,
            lastUpdateTime = now,
        )

        if (existingPlaylist == null) {
            database.insert(playlistEntity)
        } else {
            database.update(playlistEntity)
        }

        database.clearPlaylist(playlistId)

        val fullPlaylist = database.playlist(playlistId).first()
        if (fullPlaylist != null && mostPlayedSongs.isNotEmpty()) {
            database.addSongsToPlaylist(fullPlaylist, mostPlayedSongs.map { it.id to null })
        }

        playlistEntity
    }

    /**
     * Auto-generates both 'Recently Played' and 'Most Played' playlists from Room database metadata.
     */
    suspend fun generateAllAutoPlaylists(limit: Int = 50): List<PlaylistEntity> = withContext(Dispatchers.IO) {
        val recentlyPlayed = generateRecentlyPlayedPlaylist(limit)
        val mostPlayed = generateMostPlayedPlaylist(limit)
        listOf(recentlyPlayed, mostPlayed)
    }
}
