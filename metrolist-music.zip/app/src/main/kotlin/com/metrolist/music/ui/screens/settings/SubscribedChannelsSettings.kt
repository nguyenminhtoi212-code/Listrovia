/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import com.metrolist.music.ui.utils.backToMain
import com.metrolist.music.utils.rememberPreference
import androidx.datastore.preferences.core.booleanPreferencesKey

val ShowSubscribedChannelsPubliclyKey = booleanPreferencesKey("showSubscribedChannelsPublicly")
val AllowOthersToViewSubsKey = booleanPreferencesKey("allowOthersToViewSubs")
val LimitSubscribedChannelsCountKey = booleanPreferencesKey("limitSubscribedChannelsCount")
val RecsBasedOnSubsKey = booleanPreferencesKey("recsBasedOnSubs")

val NewPlaylistNotificationKey = booleanPreferencesKey("newPlaylistNotification")
val NewVideoNotificationKey = booleanPreferencesKey("newVideoNotification")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubscribedChannelsSettings(
    navController: NavController
) {
    val (showPublic, onShowPublicChange) = rememberPreference(key = ShowSubscribedChannelsPubliclyKey, defaultValue = false)
    val (allowOthers, onAllowOthersChange) = rememberPreference(key = AllowOthersToViewSubsKey, defaultValue = false)
    val (limitCount, onLimitCountChange) = rememberPreference(key = LimitSubscribedChannelsCountKey, defaultValue = false)
    val (recsOnSubs, onRecsOnSubsChange) = rememberPreference(key = RecsBasedOnSubsKey, defaultValue = true)

    val (newPlaylistNotification, onNewPlaylistNotificationChange) = rememberPreference(key = NewPlaylistNotificationKey, defaultValue = true)
    val (newVideoNotification, onNewVideoNotificationChange) = rememberPreference(key = NewVideoNotificationKey, defaultValue = true)

    Column(
        Modifier
            .windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom
                )
            )
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Spacer(
            Modifier.windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Top
                )
            )
        )

        Material3SettingsGroup(
            title = stringResource(R.string.subs_manage_group_title),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.group_filled),
                    title = { Text(stringResource(R.string.subs_show_publicly_title)) },
                    trailingContent = {
                        Switch(
                            checked = showPublic,
                            onCheckedChange = onShowPublicChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (showPublic) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onShowPublicChange(!showPublic) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.person),
                    title = { Text(stringResource(R.string.subs_allow_others_title)) },
                    trailingContent = {
                        Switch(
                            checked = allowOthers,
                            onCheckedChange = onAllowOthersChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (allowOthers) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAllowOthersChange(!allowOthers) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.sliders),
                    title = { Text(stringResource(R.string.subs_limit_count_title)) },
                    trailingContent = {
                        Switch(
                            checked = limitCount,
                            onCheckedChange = onLimitCountChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (limitCount) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onLimitCountChange(!limitCount) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.radio),
                    title = { Text(stringResource(R.string.subs_recs_title)) },
                    trailingContent = {
                        Switch(
                            checked = recsOnSubs,
                            onCheckedChange = onRecsOnSubsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (recsOnSubs) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onRecsOnSubsChange(!recsOnSubs) }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.subs_profile_group_title),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.queue_music),
                    title = { Text(stringResource(R.string.subs_new_playlist_title)) },
                    description = { Text(stringResource(R.string.subs_new_playlist_desc)) },
                    trailingContent = {
                        Switch(
                            checked = newPlaylistNotification,
                            onCheckedChange = onNewPlaylistNotificationChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (newPlaylistNotification) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onNewPlaylistNotificationChange(!newPlaylistNotification) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.play),
                    title = { Text(stringResource(R.string.subs_new_video_title)) },
                    description = { Text(stringResource(R.string.subs_new_video_desc)) },
                    trailingContent = {
                        Switch(
                            checked = newVideoNotification,
                            onCheckedChange = onNewVideoNotificationChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (newVideoNotification) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onNewVideoNotificationChange(!newVideoNotification) }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))
    }

    TopAppBar(
        title = { Text(stringResource(R.string.subscribed_channels_screen_title)) },
        navigationIcon = {
            IconButton(
                onClick = navController::navigateUp,
                onLongClick = navController::backToMain,
            ) {
                Icon(
                    painterResource(R.drawable.arrow_back),
                    contentDescription = null,
                )
            }
        }
    )
}
