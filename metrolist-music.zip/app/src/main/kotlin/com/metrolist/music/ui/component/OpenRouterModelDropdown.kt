/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.component

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.metrolist.music.R
import com.metrolist.music.api.OpenRouterModelItem
import com.metrolist.music.constants.OpenRouterTierBeta
import com.metrolist.music.constants.OpenRouterTierDeveloper
import com.metrolist.music.constants.OpenRouterTierStable
import com.metrolist.music.viewmodels.ModelViewModel
import com.valentinilk.shimmer.shimmer

/**
 * Dropdown component backed by Hilt [ModelViewModel] for selecting between 'Stable',
 * 'Beta', and 'Developer' model tiers and their corresponding OpenRouter models.
 * Includes a shimmer loading skeleton and live indicators during model fetching.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OpenRouterModelDropdown(
    modifier: Modifier = Modifier,
    viewModel: ModelViewModel = hiltViewModel(),
    selectedTier: String? = null,
    onTierSelected: ((String) -> Unit)? = null,
    selectedModel: String? = null,
    onModelSelected: ((String) -> Unit)? = null,
    onCustomModelClick: () -> Unit = {},
) {
    val vmSelectedTier by viewModel.selectedTier.collectAsStateWithLifecycle()
    val vmSelectedModel by viewModel.selectedModel.collectAsStateWithLifecycle()
    val classifiedModels by viewModel.classifiedModels.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()

    val currentTier = selectedTier ?: vmSelectedTier
    val currentModel = selectedModel ?: vmSelectedModel

    val handleTierSelected: (String) -> Unit = { tier ->
        viewModel.selectTier(tier)
        onTierSelected?.invoke(tier)
    }

    val handleModelSelected: (String) -> Unit = { modelId ->
        viewModel.selectModel(modelId)
        onModelSelected?.invoke(modelId)
    }

    var tierDropdownExpanded by remember { mutableStateOf(false) }
    var modelDropdownExpanded by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    val currentTierModels: List<OpenRouterModelItem> =
        remember(classifiedModels, currentTier) {
            val models = classifiedModels ?: return@remember emptyList()
            when (currentTier) {
                OpenRouterTierBeta -> models.beta
                OpenRouterTierDeveloper -> models.developer
                else -> models.official
            }
        }

    val filteredModels: List<OpenRouterModelItem> =
        remember(currentTierModels, searchQuery) {
            if (searchQuery.isBlank()) {
                currentTierModels
            } else {
                val q = searchQuery.trim().lowercase()
                currentTierModels.filter {
                    it.id.lowercase().contains(q) || it.name.lowercase().contains(q)
                }
            }
        }

    val currentModelObj = remember(currentTierModels, currentModel) {
        currentTierModels.firstOrNull { it.id == currentModel }
    }

    val officialCount = classifiedModels?.official?.size ?: 0
    val betaCount = classifiedModels?.beta?.size ?: 0
    val devCount = classifiedModels?.developer?.size ?: 0

    val isInitialLoading = isLoading && classifiedModels == null

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // Header with title and refresh button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.discover_tune),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = stringResource(R.string.ai_model),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Text(
                            text = stringResource(R.string.ai_model_tier_desc),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = {
                            viewModel.recommendRandomModel(forceRefresh = false) { chosen ->
                                handleModelSelected(chosen.id)
                            }
                        },
                        enabled = !isLoading,
                        modifier = Modifier.size(36.dp),
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.shuffle),
                            contentDescription = stringResource(R.string.ai_model_random_button),
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp),
                        )
                    }

                    IconButton(
                        onClick = { viewModel.refresh(force = true) },
                        enabled = !isLoading,
                        modifier = Modifier.size(36.dp),
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                            )
                        } else {
                            Icon(
                                painter = painterResource(R.drawable.sync),
                                contentDescription = stringResource(R.string.ai_model_refresh),
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp),
                            )
                        }
                    }
                }
            }

            // Shimmer effect placeholder while fetching models initially
            AnimatedVisibility(
                visible = isInitialLoading,
                enter = fadeIn(),
                exit = fadeOut(),
            ) {
                DropdownShimmerSkeleton()
            }

            // Interactive dropdowns once ready or loaded
            AnimatedVisibility(
                visible = !isInitialLoading,
                enter = fadeIn(),
                exit = fadeOut(),
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    // 1. TIER DROPDOWN SELECTOR: 'Stable', 'Beta', 'Developer'
                    ExposedDropdownMenuBox(
                        expanded = tierDropdownExpanded,
                        onExpandedChange = { tierDropdownExpanded = !tierDropdownExpanded },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        val tierDisplayTitle = when (currentTier) {
                            OpenRouterTierBeta -> stringResource(R.string.ai_model_tier_beta)
                            OpenRouterTierDeveloper -> stringResource(R.string.ai_model_tier_dev)
                            else -> stringResource(R.string.ai_model_tier_stable)
                        }

                        OutlinedTextField(
                            value = tierDisplayTitle,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(stringResource(R.string.ai_model_tier)) },
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = tierDropdownExpanded)
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth(),
                        )

                        ExposedDropdownMenu(
                            expanded = tierDropdownExpanded,
                            onDismissRequest = { tierDropdownExpanded = false },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            // STABLE ITEM
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            modifier = Modifier.fillMaxWidth(),
                                        ) {
                                            Text(
                                                text = stringResource(R.string.ai_model_tier_stable),
                                                fontWeight = if (currentTier == OpenRouterTierStable) FontWeight.Bold else FontWeight.Normal,
                                            )
                                            if (officialCount > 0) {
                                                Text(
                                                    text = "$officialCount models",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.primary,
                                                )
                                            }
                                        }
                                        Text(
                                            text = stringResource(R.string.ai_model_tier_stable_desc),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                },
                                leadingIcon = {
                                    Icon(
                                        painter = painterResource(
                                            if (currentTier == OpenRouterTierStable) R.drawable.check else R.drawable.discover_tune
                                        ),
                                        contentDescription = null,
                                        tint = if (currentTier == OpenRouterTierStable) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(20.dp),
                                    )
                                },
                                onClick = {
                                    handleTierSelected(OpenRouterTierStable)
                                    tierDropdownExpanded = false
                                },
                            )

                            HorizontalDivider(modifier = Modifier.padding(horizontal = 8.dp))

                            // BETA ITEM
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            modifier = Modifier.fillMaxWidth(),
                                        ) {
                                            Text(
                                                text = stringResource(R.string.ai_model_tier_beta),
                                                fontWeight = if (currentTier == OpenRouterTierBeta) FontWeight.Bold else FontWeight.Normal,
                                            )
                                            if (betaCount > 0) {
                                                Text(
                                                    text = "$betaCount models",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.primary,
                                                )
                                            }
                                        }
                                        Text(
                                            text = stringResource(R.string.ai_model_tier_beta_desc),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                },
                                leadingIcon = {
                                    Icon(
                                        painter = painterResource(
                                            if (currentTier == OpenRouterTierBeta) R.drawable.check else R.drawable.discover_tune
                                        ),
                                        contentDescription = null,
                                        tint = if (currentTier == OpenRouterTierBeta) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(20.dp),
                                    )
                                },
                                onClick = {
                                    handleTierSelected(OpenRouterTierBeta)
                                    tierDropdownExpanded = false
                                },
                            )

                            HorizontalDivider(modifier = Modifier.padding(horizontal = 8.dp))

                            // DEVELOPER ITEM
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            modifier = Modifier.fillMaxWidth(),
                                        ) {
                                            Text(
                                                text = stringResource(R.string.ai_model_tier_dev),
                                                fontWeight = if (currentTier == OpenRouterTierDeveloper) FontWeight.Bold else FontWeight.Normal,
                                            )
                                            if (devCount > 0) {
                                                Text(
                                                    text = "$devCount models",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.primary,
                                                )
                                            }
                                        }
                                        Text(
                                            text = stringResource(R.string.ai_model_tier_dev_desc),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                },
                                leadingIcon = {
                                    Icon(
                                        painter = painterResource(
                                            if (currentTier == OpenRouterTierDeveloper) R.drawable.check else R.drawable.discover_tune
                                        ),
                                        contentDescription = null,
                                        tint = if (currentTier == OpenRouterTierDeveloper) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(20.dp),
                                    )
                                },
                                onClick = {
                                    handleTierSelected(OpenRouterTierDeveloper)
                                    tierDropdownExpanded = false
                                },
                            )
                        }
                    }

                    // 2. MODEL DROPDOWN SELECTOR FOR THE CHOSEN TIER
                    ExposedDropdownMenuBox(
                        expanded = modelDropdownExpanded,
                        onExpandedChange = { modelDropdownExpanded = !modelDropdownExpanded },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        val modelDisplayTitle = currentModelObj?.name ?: currentModel.ifBlank {
                            stringResource(R.string.ai_model_select_model)
                        }

                        OutlinedTextField(
                            value = modelDisplayTitle,
                            onValueChange = {},
                            readOnly = true,
                            label = {
                                val tierName = when (currentTier) {
                                    OpenRouterTierBeta -> stringResource(R.string.ai_model_tab_beta)
                                    OpenRouterTierDeveloper -> stringResource(R.string.ai_model_tab_developer)
                                    else -> stringResource(R.string.ai_model_tab_official)
                                }
                                Text("${stringResource(R.string.ai_model)} ($tierName)")
                            },
                            supportingText = {
                                Text(
                                    text = currentModel.ifBlank { "google/gemini-2.5-flash-lite" },
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            },
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = modelDropdownExpanded)
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth(),
                        )

                        ExposedDropdownMenu(
                            expanded = modelDropdownExpanded,
                            onDismissRequest = {
                                modelDropdownExpanded = false
                                searchQuery = ""
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 380.dp),
                        ) {
                            // Search bar inside dropdown
                            Box(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                                OutlinedTextField(
                                    value = searchQuery,
                                    onValueChange = { searchQuery = it },
                                    placeholder = { Text(stringResource(R.string.ai_model_search_placeholder)) },
                                    leadingIcon = {
                                        Icon(
                                            painter = painterResource(R.drawable.search),
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp),
                                        )
                                    },
                                    trailingIcon = {
                                        if (searchQuery.isNotEmpty()) {
                                            IconButton(onClick = { searchQuery = "" }) {
                                                Icon(
                                                    painter = painterResource(R.drawable.close),
                                                    contentDescription = null,
                                                    modifier = Modifier.size(16.dp),
                                                )
                                            }
                                        }
                                    },
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth(),
                                )
                            }

                            HorizontalDivider()

                            if (isLoading && filteredModels.isEmpty()) {
                                DropdownLoadingItemsShimmer()
                            } else if (filteredModels.isEmpty()) {
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = stringResource(R.string.ai_model_none_found),
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    },
                                    onClick = {},
                                    enabled = false,
                                )
                            } else {
                                filteredModels.forEach { item ->
                                    val isSelected = item.id == currentModel
                                    DropdownMenuItem(
                                        text = {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = item.name,
                                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis,
                                                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                                    )
                                                    Text(
                                                        text = item.id,
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis,
                                                    )
                                                }

                                                if (item.contextLength > 0) {
                                                    val contextK = item.contextLength / 1000
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Surface(
                                                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                                                        shape = RoundedCornerShape(6.dp),
                                                    ) {
                                                        Text(
                                                            text = "${contextK}k",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                        )
                                                    }
                                                }
                                            }
                                        },
                                        leadingIcon = {
                                            Icon(
                                                painter = painterResource(
                                                    if (isSelected) R.drawable.check else R.drawable.discover_tune
                                                ),
                                                contentDescription = null,
                                                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(18.dp),
                                            )
                                        },
                                        onClick = {
                                            handleModelSelected(item.id)
                                            modelDropdownExpanded = false
                                            searchQuery = ""
                                        },
                                    )
                                }
                            }

                            HorizontalDivider()

                            // Custom model item
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = stringResource(R.string.ai_model_custom),
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Medium,
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        painter = painterResource(R.drawable.edit),
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp),
                                    )
                                },
                                onClick = {
                                    modelDropdownExpanded = false
                                    searchQuery = ""
                                    onCustomModelClick()
                                },
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Shimmer effect skeleton displayed in Settings dropdown while models are initially loading.
 */
@Composable
private fun DropdownShimmerSkeleton() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shimmer(),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // Shimmer for Tier selector
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Box(
                    modifier = Modifier
                        .width(110.dp)
                        .height(18.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)),
                )
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)),
                )
            }
        }

        // Shimmer for Model selector
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.Center,
            ) {
                Box(
                    modifier = Modifier
                        .width(150.dp)
                        .height(18.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)),
                )
                Spacer(modifier = Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .width(220.dp)
                        .height(12.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)),
                )
            }
        }
    }
}

/**
 * Shimmer effect items displayed inside the dropdown menu while models are loading.
 */
@Composable
private fun DropdownLoadingItemsShimmer() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .shimmer(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        repeat(4) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f),
                ) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)),
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Box(
                            modifier = Modifier
                                .width(130.dp)
                                .height(14.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)),
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .width(190.dp)
                                .height(10.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)),
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .width(36.dp)
                        .height(18.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)),
                )
            }
        }
    }
}
