/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.lyrics.providers

import android.content.Context
import com.metrolist.music.constants.EnableBetterLyricsKey
import com.metrolist.music.lyrics.LyricsProvider
import com.metrolist.music.utils.dataStore
import com.metrolist.music.utils.get
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.defaultRequest
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.parameter
import io.ktor.http.HttpStatusCode
import io.ktor.serialization.kotlinx.json.json
import kotlinx.coroutines.CancellationException
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import org.xml.sax.Attributes
import org.xml.sax.helpers.DefaultHandler
import timber.log.Timber
import java.io.ByteArrayInputStream
import java.util.Stack
import javax.xml.parsers.SAXParserFactory

// --- Data Models ---

@Serializable
data class TTMLResponse(
    val ttml: String? = null,
)

@Serializable
data class SearchResponse(
    val results: List<Track>
)

@Serializable
data class Track(
    val title: String,
    val artist: String,
    val album: String? = null,
    val duration: Double,
    val lyrics: Lyrics? = null
)

@Serializable
data class Lyrics(
    val lines: List<Line>
)

@Serializable
data class Line(
    val text: String,
    val startTime: Double,
    val words: List<Word>? = null
)

@Serializable
data class Word(
    val text: String,
    val startTime: Double,
    val endTime: Double
)

data class LyricLine(
    val startTime: Double,
    val endTime: Double,
    val text: String,
    val agent: String?,
    val isBackground: Boolean,
    val words: List<Word>
)

// --- BetterLyrics HTTP Client & Service ---

object BetterLyrics {
    private const val TAG = "BetterLyrics"

    private val client by lazy {
        HttpClient(OkHttp) {
            install(ContentNegotiation) {
                json(
                    Json {
                        isLenient = true
                        ignoreUnknownKeys = true
                    },
                )
            }

            install(HttpTimeout) {
                requestTimeoutMillis = 15000
                connectTimeoutMillis = 10000
                socketTimeoutMillis = 15000
            }

            defaultRequest {
                url("https://lyrics-api.boidu.dev")
                header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                header("Accept", "application/json")
            }

            expectSuccess = false
        }
    }

    private suspend fun fetchTTML(
        artist: String,
        title: String,
        duration: Int = -1,
        album: String? = null,
    ): String? = try {
        Timber.tag(TAG).d("Fetching TTML for: $title by $artist (dur=$duration, album=$album)")
        val response = client.get("/getLyrics") {
            parameter("s", title)
            parameter("a", artist)
            if (duration > 0) {
                parameter("d", duration)
            }
            if (!album.isNullOrBlank()) {
                parameter("al", album)
            }
        }
        if (response.status == HttpStatusCode.OK) {
            val ttml = response.body<TTMLResponse>().ttml?.trim()?.takeIf { it.isNotEmpty() }
            ttml
        } else {
            Timber.tag(TAG).w("API returned status: ${response.status}")
            null
        }
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Timber.tag(TAG).e(e, "Exception during fetchTTML")
        null
    }

    suspend fun getLyrics(
        title: String,
        artist: String,
        duration: Int,
        album: String? = null,
    ): Result<String> = runCatching {
        val ttml = fetchTTML(artist, title, duration, album)
            ?: throw IllegalStateException("Lyrics unavailable")

        val lrc = TTMLParser.parse(ttml)
        if (lrc.isBlank()) {
            throw IllegalStateException("Failed to parse lyrics")
        }
        lrc
    }
}

// --- BetterLyrics Provider (LyricsProvider Implementation) ---

object BetterLyricsProvider : LyricsProvider {
    override val name = "BetterLyrics"

    override fun isEnabled(context: Context): Boolean = context.dataStore[EnableBetterLyricsKey] ?: true

    override suspend fun getLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): Result<String> = BetterLyrics.getLyrics(title, artist, duration, album)

    override suspend fun getAllLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
        callback: (String) -> Unit,
    ) {
        getLyrics(context, id, title, artist, duration, album).onSuccess(callback)
    }
}

// --- TTML Parser ---

object TTMLParser {

    private sealed interface SaxNode {
        class Text(var content: String) : SaxNode
        class Span(val element: SaxSpanElement) : SaxNode
    }

    private class SaxPElement(
        val agent: String?,
        val role: String?,
        val begin: String,
        val end: String
    ) {
        val contentNodes = mutableListOf<SaxNode>()
    }

    private class SaxSpanElement(
        val role: String?,
        val begin: String,
        val end: String
    ) {
        val contentNodes = mutableListOf<SaxNode>()
    }

    /**
     * Parses TTML XML into standard LRC string.
     */
    fun parse(ttml: String): String {
        val lines = parseTTML(ttml)
        return if (lines.isNotEmpty()) toLRC(lines).trim() else ""
    }

    /**
     * Parses TTML XML string into a list of [LyricLine] using SAX parser.
     */
    fun parseTTML(xmlString: String): List<LyricLine> {
        try {
            val factory = SAXParserFactory.newInstance().apply {
                isNamespaceAware = true
            }
            val parser = factory.newSAXParser()
            val handler = TTMLHandler()
            parser.parse(ByteArrayInputStream(xmlString.toByteArray(Charsets.UTF_8)), handler)
            return handler.parsedLines
        } catch (e: Exception) {
            Timber.e(e, "Failed to parse TTML via SAX")
            return emptyList()
        }
    }

    private class TTMLHandler : DefaultHandler() {
        var lyricOffset = 0.0
        val agentTypes = mutableMapOf<String, String>()
        val parsedLines = mutableListOf<LyricLine>()

        private var currentP: SaxPElement? = null
        private val spanStack = Stack<SaxSpanElement>()

        override fun startElement(
            uri: String,
            localName: String,
            qName: String,
            attributes: Attributes
        ) {
            val name = localName.ifEmpty { qName.substringAfter(':') }

            when (name) {
                "audio" -> {
                    val offsetStr = getAttribute(attributes, "lyricOffset")
                    if (offsetStr.isNotEmpty()) {
                        lyricOffset = offsetStr.toDoubleOrNull() ?: 0.0
                    }
                }
                "agent" -> {
                    val id = getAttribute(attributes, "id", "http://www.w3.org/XML/1998/namespace")
                        .ifEmpty { getAttribute(attributes, "id") }
                    val type = getAttribute(attributes, "type")
                    if (id.isNotEmpty()) {
                        agentTypes[id] = type
                    } else {
                        Timber.w("Agent element found with missing ID attribute")
                    }
                }
                "p" -> {
                    if (currentP != null) {
                        Timber.w("Malformed nesting: <p> element started inside an already active paragraph.")
                    }
                    val agent = getAttribute(attributes, "agent", "http://www.w3.org/ns/ttml#metadata")
                        .ifEmpty { getAttribute(attributes, "agent") }
                        .ifEmpty { null }
                    val role = getAttribute(attributes, "role", "http://www.w3.org/ns/ttml#metadata")
                        .ifEmpty { getAttribute(attributes, "role") }
                        .ifEmpty { null }
                    val begin = getAttribute(attributes, "begin", "http://www.w3.org/ns/ttml#parameter")
                        .ifEmpty { getAttribute(attributes, "begin") }
                    val end = getAttribute(attributes, "end", "http://www.w3.org/ns/ttml#parameter")
                        .ifEmpty { getAttribute(attributes, "end") }

                    currentP = SaxPElement(agent, role, begin, end)
                    spanStack.clear()
                }
                "span" -> {
                    val p = currentP
                    if (p == null) {
                        Timber.w("Malformed TTML: <span> found outside a <p> container.")
                    } else {
                        val role = getAttribute(attributes, "role", "http://www.w3.org/ns/ttml#metadata")
                            .ifEmpty { getAttribute(attributes, "role") }
                            .ifEmpty { null }
                        val begin = getAttribute(attributes, "begin", "http://www.w3.org/ns/ttml#parameter")
                            .ifEmpty { getAttribute(attributes, "begin") }
                        val end = getAttribute(attributes, "end", "http://www.w3.org/ns/ttml#parameter")
                            .ifEmpty { getAttribute(attributes, "end") }

                        val newSpan = SaxSpanElement(role, begin, end)
                        if (spanStack.isNotEmpty()) {
                            spanStack.peek().contentNodes.add(SaxNode.Span(newSpan))
                        } else {
                            p.contentNodes.add(SaxNode.Span(newSpan))
                        }
                        spanStack.push(newSpan)
                    }
                }
            }
        }

        override fun characters(ch: CharArray, start: Int, length: Int) {
            val content = String(ch, start, length)
            val p = currentP ?: return

            val targetNodes = if (spanStack.isNotEmpty()) {
                spanStack.peek().contentNodes
            } else {
                p.contentNodes
            }

            if (targetNodes.isNotEmpty() && targetNodes.last() is SaxNode.Text) {
                val lastText = targetNodes.last() as SaxNode.Text
                lastText.content += content
            } else {
                targetNodes.add(SaxNode.Text(content))
            }
        }

        override fun endElement(uri: String, localName: String, qName: String) {
            val name = localName.ifEmpty { qName.substringAfter(':') }

            when (name) {
                "p" -> {
                    val p = currentP
                    if (p != null) {
                        processParagraph(p)
                        currentP = null
                    } else {
                        Timber.w("Malformed XML: </p> found without matching <p>.")
                    }
                }
                "span" -> {
                    if (spanStack.isNotEmpty()) {
                        spanStack.pop()
                    } else {
                        Timber.w("Malformed XML: </span> found without matching <span>.")
                    }
                }
            }
        }

        private fun getAttribute(attributes: Attributes, localName: String, uri: String? = null): String {
            if (uri != null) {
                val valUri = attributes.getValue(uri, localName)
                if (!valUri.isNullOrEmpty()) return valUri
            }
            val valLocal = attributes.getValue(localName)
            if (!valLocal.isNullOrEmpty()) return valLocal

            for (i in 0 until attributes.length) {
                val qName = attributes.getQName(i)
                val nameOnly = qName.substringAfter(':')
                if (nameOnly == localName) {
                    val value = attributes.getValue(i)
                    if (!value.isNullOrEmpty()) return value
                }
            }
            return ""
        }

        private fun getRecursiveText(span: SaxSpanElement): String {
            val sb = StringBuilder()
            for (node in span.contentNodes) {
                when (node) {
                    is SaxNode.Text -> sb.append(node.content)
                    is SaxNode.Span -> sb.append(getRecursiveText(node.element))
                }
            }
            return sb.toString()
        }

        private fun getRecursiveTextOfNode(node: SaxNode): String {
            return when (node) {
                is SaxNode.Text -> node.content
                is SaxNode.Span -> getRecursiveText(node.element)
            }
        }

        private fun processParagraph(p: SaxPElement) {
            val pAgent = p.agent
            val pRole = p.role
            val isPBackground = pRole == "x-bg"

            if (pAgent != null && !agentTypes.containsKey(pAgent)) {
                Timber.w("Paragraph refers to an undefined agent ID: '$pAgent'")
            }

            val rawSpans = p.contentNodes.filterIsInstance<SaxNode.Span>().map { it.element }
            val filteredSpans = rawSpans.filter { span ->
                val role = span.role
                role != "x-roman" && role != "x-translation"
            }

            val pText = p.contentNodes.joinToString("") { getRecursiveTextOfNode(it) }

            if (filteredSpans.isEmpty() && pText.trim().isEmpty()) {
                return
            }

            val pBeginStr = p.begin
            val pEndStr = p.end

            val pStart = if (pBeginStr.isNotEmpty()) {
                val time = parseTime(pBeginStr)
                if (time == 0.0 && pBeginStr != "0" && pBeginStr != "0s" && pBeginStr != "00:00:00") {
                    Timber.w("Malformed begin time format in <p>: '$pBeginStr'")
                }
                time + lyricOffset
            } else null

            val pEnd = if (pEndStr.isNotEmpty()) {
                val time = parseTime(pEndStr)
                if (time == 0.0 && pEndStr != "0" && pEndStr != "0s" && pEndStr != "00:00:00") {
                    Timber.w("Malformed end time format in <p>: '$pEndStr'")
                }
                time + lyricOffset
            } else null

            val wordsList = mutableListOf<Word>()
            val bgWords = mutableListOf<Word>()

            for (span in filteredSpans) {
                val spanRole = span.role

                if (spanRole == "x-bg") {
                    val innerSpans = span.contentNodes.filterIsInstance<SaxNode.Span>().map { it.element }.filter { inner ->
                        val innerRole = inner.role
                        innerRole != "x-roman" && innerRole != "x-translation"
                    }

                    if (innerSpans.isNotEmpty()) {
                        for (inner in innerSpans) {
                            val wordText = inner.contentNodes.filterIsInstance<SaxNode.Text>().joinToString("") { it.content }.trim()
                            if (wordText.isNotEmpty()) {
                                val sTimeStr = inner.begin
                                val eTimeStr = inner.end
                                val sTime = parseTime(sTimeStr).takeIf { sTimeStr.isNotEmpty() }?.plus(lyricOffset) ?: pStart ?: lyricOffset
                                val eTime = parseTime(eTimeStr).takeIf { eTimeStr.isNotEmpty() }?.plus(lyricOffset) ?: pEnd ?: lyricOffset
                                bgWords.add(Word(wordText, sTime, eTime))
                            }
                        }
                    } else {
                        val wordText = span.contentNodes.filterIsInstance<SaxNode.Text>().joinToString("") { it.content }.trim()
                        if (wordText.isNotEmpty()) {
                            val sTimeStr = span.begin
                            val eTimeStr = span.end
                            val sTime = parseTime(sTimeStr).takeIf { sTimeStr.isNotEmpty() }?.plus(lyricOffset) ?: pStart ?: lyricOffset
                            val eTime = parseTime(eTimeStr).takeIf { eTimeStr.isNotEmpty() }?.plus(lyricOffset) ?: pEnd ?: lyricOffset
                            bgWords.add(Word(wordText, sTime, eTime))
                        }
                    }
                } else {
                    val innerSpans = span.contentNodes.filterIsInstance<SaxNode.Span>().map { it.element }.filter { inner ->
                        val innerRole = inner.role
                        innerRole != "x-roman" && innerRole != "x-translation"
                    }

                    if (innerSpans.isNotEmpty()) {
                        for (inner in innerSpans) {
                            val wordText = inner.contentNodes.filterIsInstance<SaxNode.Text>().joinToString("") { it.content }.trim()
                            if (wordText.isNotEmpty()) {
                                val sTimeStr = inner.begin
                                val eTimeStr = inner.end
                                if (sTimeStr.isNotEmpty() || eTimeStr.isNotEmpty()) {
                                    val sTime = parseTime(sTimeStr).takeIf { sTimeStr.isNotEmpty() }?.plus(lyricOffset) ?: pStart ?: lyricOffset
                                    val eTime = parseTime(eTimeStr).takeIf { eTimeStr.isNotEmpty() }?.plus(lyricOffset) ?: pEnd ?: lyricOffset
                                    wordsList.add(Word(wordText, sTime, eTime))
                                }
                            }
                        }
                    } else {
                        val wordText = span.contentNodes.filterIsInstance<SaxNode.Text>().joinToString("") { it.content }.trim()
                        if (wordText.isNotEmpty()) {
                            val sTimeStr = span.begin
                            val eTimeStr = span.end
                            if (sTimeStr.isNotEmpty() || eTimeStr.isNotEmpty()) {
                                val sTime = parseTime(sTimeStr).takeIf { sTimeStr.isNotEmpty() }?.plus(lyricOffset) ?: pStart ?: lyricOffset
                                val eTime = parseTime(eTimeStr).takeIf { eTimeStr.isNotEmpty() }?.plus(lyricOffset) ?: pEnd ?: lyricOffset
                                wordsList.add(Word(wordText, sTime, eTime))
                            }
                        }
                    }
                }
            }

            val mergedWordsList = mergeSyllables(wordsList)
            val mergedBgWordsList = mergeSyllables(bgWords)

            val finalStart = pStart ?: mergedWordsList.firstOrNull()?.startTime ?: mergedBgWordsList.firstOrNull()?.startTime ?: 0.0
            val finalEnd = pEnd ?: mergedWordsList.lastOrNull()?.endTime ?: mergedBgWordsList.lastOrNull()?.endTime ?: 0.0

            val lineText = if (mergedWordsList.isNotEmpty()) {
                mergedWordsList.joinToString(" ") { it.text }
            } else {
                pText.trim()
            }

            if (lineText.isNotEmpty()) {
                parsedLines.add(LyricLine(finalStart, finalEnd, lineText, pAgent, isPBackground, mergedWordsList))
            }

            if (mergedBgWordsList.isNotEmpty()) {
                val bgStart = mergedBgWordsList.minOf { it.startTime }
                val bgEnd = mergedBgWordsList.maxOf { it.endTime }
                val bgText = mergedBgWordsList.joinToString(" ") { it.text }
                parsedLines.add(LyricLine(bgStart, bgEnd, bgText, pAgent, true, mergedBgWordsList))
            }
        }

        private fun mergeSyllables(words: List<Word>): List<Word> {
            if (words.size < 2) return words
            val merged = mutableListOf<Word>()
            var current = words[0]
            for (i in 1 until words.size) {
                val next = words[i]
                if (Math.abs(current.endTime - next.startTime) < 0.001) {
                    current = Word(current.text + next.text, current.startTime, next.endTime)
                } else {
                    merged.add(current)
                    current = next
                }
            }
            merged.add(current)
            return merged
        }
    }

    private fun parseTime(time: String): Double {
        val t = time.trim()
        if (t.isEmpty()) return 0.0
        val c1 = t.indexOf(':')
        if (c1 != -1) {
            val c2 = t.lastIndexOf(':')
            return if (c1 == c2) {
                (t.substring(0, c1).toIntOrNull() ?: 0) * 60.0 + (t.substring(c1 + 1).toDoubleOrNull() ?: 0.0)
            } else {
                (t.substring(0, c1).toIntOrNull() ?: 0) * 3600.0 + (t.substring(c1 + 1, c2).toIntOrNull() ?: 0) * 60.0 + (t.substring(c2 + 1).toDoubleOrNull() ?: 0.0)
            }
        }
        if (t.endsWith("ms")) return (t.substring(0, t.length - 2).toDoubleOrNull() ?: 0.0) / 1000.0
        val s = if (t.endsWith("s") || t.endsWith("m") || t.endsWith("h")) t.substring(0, t.length - 1) else t
        val v = s.toDoubleOrNull() ?: 0.0
        return when {
            t.endsWith("m") -> v * 60.0
            t.endsWith("h") -> v * 3600.0
            else -> v
        }
    }

    fun toLRC(lines: List<LyricLine>): String {
        val agentMap = mutableMapOf<String, String>()

        // Phase 1: Preserve explicit v1, v2, v1000
        lines.forEach { line ->
            line.agent?.lowercase()?.let { raw ->
                if (raw == "v1" || raw == "v2" || raw == "v1000") {
                    agentMap[raw] = raw
                }
            }
        }

        // Phase 2: Map other agents to v1/v2 if available
        var nextNum = 1
        lines.forEach { line ->
            line.agent?.lowercase()?.let { raw ->
                if (!agentMap.containsKey(raw)) {
                    while (nextNum <= 2 && (agentMap.containsKey("v$nextNum") || agentMap.values.contains("v$nextNum"))) {
                        nextNum++
                    }
                    agentMap[raw] = if (nextNum <= 2) "v$nextNum" else "v1"
                }
            }
        }

        if (agentMap.containsKey("v1000") && agentMap.containsKey("v1")) {
            agentMap["v1000"] = "v2"
        }

        val hasBackgroundLine = lines.any { it.isBackground }
        val multi =
            agentMap.size > 1 ||
                (agentMap.size == 1 && !agentMap.containsKey("v1")) ||
                (hasBackgroundLine && agentMap.size == 1 && agentMap.containsKey("v1"))

        val sb = StringBuilder(lines.size * 128)
        var lastBg = false
        lines.forEach { line ->
            val time = formatLrcTime(line.startTime)
            val isBg = line.isBackground
            if (!isBg) lastBg = false

            val agentId = agentMap[line.agent?.lowercase()]
            val tag = when {
                isBg -> if (lastBg) "" else "{bg}"
                multi && agentId != null -> "{agent:$agentId}"
                else -> ""
            }
            if (isBg) lastBg = true

            sb.append(time).append(tag).append(line.text).append('\n')
            if (line.words.isNotEmpty()) {
                sb.append('<')
                line.words.forEachIndexed { i, w ->
                    sb.append(w.text).append(':').append(w.startTime).append(':').append(w.endTime)
                    if (i < line.words.lastIndex) sb.append('|')
                }
                sb.append(">\n")
            }
        }
        return sb.toString()
    }

    private fun formatLrcTime(time: Double): String {
        val ms = (time * 1000).toLong()
        val m = ms / 60000
        val s = (ms % 60000) / 1000
        val c = (ms % 1000) / 10
        val sb = StringBuilder(10)
        sb.append('[')
        if (m < 10) sb.append('0')
        sb.append(m).append(':')
        if (s < 10) sb.append('0')
        sb.append(s).append('.')
        if (c < 10) sb.append('0')
        sb.append(c).append(']')
        return sb.toString()
    }
}
