/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.playback

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import androidx.datastore.preferences.core.edit
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.TransferListener
import com.metrolist.music.constants.DataTrackerLastResetKey
import com.metrolist.music.constants.DownloadMobileBytesKey
import com.metrolist.music.constants.DownloadWifiBytesKey
import com.metrolist.music.constants.StreamingMobileBytesKey
import com.metrolist.music.constants.StreamingWifiBytesKey
import com.metrolist.music.utils.dataStore
import com.metrolist.music.utils.safeDataStoreEdit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.Interceptor
import okhttp3.MediaType
import okhttp3.Response
import okhttp3.ResponseBody
import okio.Buffer
import okio.BufferedSource
import okio.ForwardingSource
import okio.Source
import okio.buffer
import timber.log.Timber
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Background tracker for network data consumption by the music streaming service.
 * Accurately monitors and classifies bytes streamed/downloaded over Mobile (Cellular)
 * vs Wi-Fi networks in real time and persistently saves statistics to DataStore.
 */
object StreamingDataTracker {
    private const val TAG = "StreamingDataTracker"

    enum class NetworkType {
        WIFI,
        MOBILE,
        OTHER,
        DISCONNECTED
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var appContext: Context? = null
    private var isInitialized = false

    // Real-time In-Memory Counters (Atomic for high throughput ExoPlayer chunks)
    private val rawStreamingMobile = AtomicLong(0L)
    private val rawStreamingWifi = AtomicLong(0L)
    private val rawDownloadMobile = AtomicLong(0L)
    private val rawDownloadWifi = AtomicLong(0L)
    private val isDirty = AtomicBoolean(false)

    // State Flows for Compose UI
    private val _streamingMobileBytes = MutableStateFlow(0L)
    val streamingMobileBytes: StateFlow<Long> = _streamingMobileBytes.asStateFlow()

    private val _streamingWifiBytes = MutableStateFlow(0L)
    val streamingWifiBytes: StateFlow<Long> = _streamingWifiBytes.asStateFlow()

    private val _downloadMobileBytes = MutableStateFlow(0L)
    val downloadMobileBytes: StateFlow<Long> = _downloadMobileBytes.asStateFlow()

    private val _downloadWifiBytes = MutableStateFlow(0L)
    val downloadWifiBytes: StateFlow<Long> = _downloadWifiBytes.asStateFlow()

    private val _currentSpeedBps = MutableStateFlow(0L)
    val currentSpeedBps: StateFlow<Long> = _currentSpeedBps.asStateFlow()

    private val _activeNetworkType = MutableStateFlow(NetworkType.DISCONNECTED)
    val activeNetworkType: StateFlow<NetworkType> = _activeNetworkType.asStateFlow()

    private val _lastResetTimestamp = MutableStateFlow(0L)
    val lastResetTimestamp: StateFlow<Long> = _lastResetTimestamp.asStateFlow()

    // Combined flows
    val totalMobileBytes: StateFlow<Long> = combine(_streamingMobileBytes, _downloadMobileBytes) { s, d ->
        s + d
    }.stateIn(scope, SharingStarted.Eagerly, 0L)

    val totalWifiBytes: StateFlow<Long> = combine(_streamingWifiBytes, _downloadWifiBytes) { s, d ->
        s + d
    }.stateIn(scope, SharingStarted.Eagerly, 0L)

    val grandTotalBytes: StateFlow<Long> = combine(totalMobileBytes, totalWifiBytes) { m, w ->
        m + w
    }.stateIn(scope, SharingStarted.Eagerly, 0L)

    // Throughput speed tracking
    private val bytesInCurrentWindow = AtomicLong(0L)
    private var speedCalculationJob: Job? = null
    private var persistenceJob: Job? = null

    /**
     * Initializes the tracker with the application context.
     * Loads persisted statistics and registers connectivity listeners.
     */
    fun init(context: Context) {
        if (isInitialized) return
        isInitialized = true
        appContext = context.applicationContext

        val ctx = appContext ?: return
        val connectivityManager = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager

        // Determine initial active network type
        updateActiveNetwork(connectivityManager)

        // Register NetworkCallback for real-time network type tracking
        try {
            val request = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            connectivityManager?.registerNetworkCallback(request, object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    updateActiveNetwork(connectivityManager)
                }

                override fun onLost(network: Network) {
                    updateActiveNetwork(connectivityManager)
                }

                override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                    updateActiveNetwork(connectivityManager)
                }
            })
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to register network callback")
        }

        // Load stored counters from DataStore
        scope.launch {
            try {
                val prefs = ctx.dataStore.data.first()
                val sMobile = prefs[StreamingMobileBytesKey] ?: 0L
                val sWifi = prefs[StreamingWifiBytesKey] ?: 0L
                val dMobile = prefs[DownloadMobileBytesKey] ?: 0L
                val dWifi = prefs[DownloadWifiBytesKey] ?: 0L
                val lastReset = prefs[DataTrackerLastResetKey] ?: 0L

                rawStreamingMobile.set(sMobile)
                rawStreamingWifi.set(sWifi)
                rawDownloadMobile.set(dMobile)
                rawDownloadWifi.set(dWifi)

                _streamingMobileBytes.value = sMobile
                _streamingWifiBytes.value = sWifi
                _downloadMobileBytes.value = dMobile
                _downloadWifiBytes.value = dWifi
                _lastResetTimestamp.value = lastReset

                Timber.tag(TAG).d("Loaded data usage: Streaming(Mobile=$sMobile, Wifi=$sWifi), Downloads(Mobile=$dMobile, Wifi=$dWifi)")
            } catch (e: Exception) {
                Timber.tag(TAG).e(e, "Failed to load data usage from DataStore")
            }
        }

        // Start background periodic persistence & speed calculation
        startBackgroundLoops()
    }

    private fun updateActiveNetwork(connectivityManager: ConnectivityManager?) {
        val activeNet = connectivityManager?.activeNetwork
        val caps = if (activeNet != null) connectivityManager.getNetworkCapabilities(activeNet) else null

        val type = when {
            caps == null || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) -> NetworkType.DISCONNECTED
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> NetworkType.WIFI
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> NetworkType.MOBILE
            else -> NetworkType.OTHER
        }
        _activeNetworkType.value = type
    }

    private fun startBackgroundLoops() {
        // Speed calculation ticker (1 second window)
        speedCalculationJob?.cancel()
        speedCalculationJob = scope.launch {
            while (isActive) {
                val transferred = bytesInCurrentWindow.getAndSet(0L)
                _currentSpeedBps.value = transferred
                delay(1000)
            }
        }

        // Periodic flush to DataStore (every 4 seconds when dirty)
        persistenceJob?.cancel()
        persistenceJob = scope.launch {
            while (isActive) {
                delay(4000)
                if (isDirty.compareAndSet(true, false)) {
                    flushToDataStore()
                }
            }
        }
    }

    /**
     * Records streaming audio bytes consumed by ExoPlayer / audio player.
     */
    fun recordStreamingBytes(bytes: Long, isNetwork: Boolean = true) {
        if (bytes <= 0 || !isNetwork) return

        bytesInCurrentWindow.addAndGet(bytes)
        val currentType = _activeNetworkType.value

        if (currentType == NetworkType.MOBILE) {
            val newVal = rawStreamingMobile.addAndGet(bytes)
            _streamingMobileBytes.value = newVal
        } else {
            // Default to Wi-Fi / unmetered
            val newVal = rawStreamingWifi.addAndGet(bytes)
            _streamingWifiBytes.value = newVal
        }
        isDirty.set(true)
    }

    /**
     * Records download bytes consumed during offline music downloads.
     */
    fun recordDownloadBytes(bytes: Long, isNetwork: Boolean = true) {
        if (bytes <= 0 || !isNetwork) return

        bytesInCurrentWindow.addAndGet(bytes)
        val currentType = _activeNetworkType.value

        if (currentType == NetworkType.MOBILE) {
            val newVal = rawDownloadMobile.addAndGet(bytes)
            _downloadMobileBytes.value = newVal
        } else {
            val newVal = rawDownloadWifi.addAndGet(bytes)
            _downloadWifiBytes.value = newVal
        }
        isDirty.set(true)
    }

    /**
     * Persists in-memory counters to DataStore safely.
     */
    private suspend fun flushToDataStore() {
        val ctx = appContext ?: return
        val sMobile = rawStreamingMobile.get()
        val sWifi = rawStreamingWifi.get()
        val dMobile = rawDownloadMobile.get()
        val dWifi = rawDownloadWifi.get()

        ctx.safeDataStoreEdit { prefs ->
            prefs[StreamingMobileBytesKey] = sMobile
            prefs[StreamingWifiBytesKey] = sWifi
            prefs[DownloadMobileBytesKey] = dMobile
            prefs[DownloadWifiBytesKey] = dWifi
        }
    }

    /**
     * Resets all data tracking statistics to 0 and records the reset timestamp.
     */
    fun resetStats() {
        rawStreamingMobile.set(0L)
        rawStreamingWifi.set(0L)
        rawDownloadMobile.set(0L)
        rawDownloadWifi.set(0L)
        bytesInCurrentWindow.set(0L)

        _streamingMobileBytes.value = 0L
        _streamingWifiBytes.value = 0L
        _downloadMobileBytes.value = 0L
        _downloadWifiBytes.value = 0L
        _currentSpeedBps.value = 0L

        val now = System.currentTimeMillis()
        _lastResetTimestamp.value = now

        scope.launch {
            val ctx = appContext ?: return@launch
            ctx.safeDataStoreEdit { prefs ->
                prefs[StreamingMobileBytesKey] = 0L
                prefs[StreamingWifiBytesKey] = 0L
                prefs[DownloadMobileBytesKey] = 0L
                prefs[DownloadWifiBytesKey] = 0L
                prefs[DataTrackerLastResetKey] = now
            }
        }
    }

    /**
     * Media3 TransferListener for music streaming (ExoPlayer).
     */
    val streamingTransferListener = object : TransferListener {
        override fun onTransferInitializing(source: DataSource, dataSpec: DataSpec, isNetwork: Boolean) {}
        override fun onTransferStart(source: DataSource, dataSpec: DataSpec, isNetwork: Boolean) {}

        override fun onBytesTransferred(
            source: DataSource,
            dataSpec: DataSpec,
            isNetwork: Boolean,
            bytesTransferred: Int
        ) {
            if (isNetwork && bytesTransferred > 0) {
                recordStreamingBytes(bytesTransferred.toLong(), isNetwork = true)
            }
        }

        override fun onTransferEnd(source: DataSource, dataSpec: DataSpec, isNetwork: Boolean) {}
    }

    /**
     * Media3 TransferListener for offline download service.
     */
    val downloadTransferListener = object : TransferListener {
        override fun onTransferInitializing(source: DataSource, dataSpec: DataSpec, isNetwork: Boolean) {}
        override fun onTransferStart(source: DataSource, dataSpec: DataSpec, isNetwork: Boolean) {}

        override fun onBytesTransferred(
            source: DataSource,
            dataSpec: DataSpec,
            isNetwork: Boolean,
            bytesTransferred: Int
        ) {
            if (isNetwork && bytesTransferred > 0) {
                recordDownloadBytes(bytesTransferred.toLong(), isNetwork = true)
            }
        }

        override fun onTransferEnd(source: DataSource, dataSpec: DataSpec, isNetwork: Boolean) {}
    }

    /**
     * OkHttp Interceptor to track HTTP data transferred.
     */
    fun createOkHttpInterceptor(isDownload: Boolean = false): Interceptor = Interceptor { chain ->
        val request = chain.request()
        val response = chain.proceed(request)
        val body = response.body ?: return@Interceptor response

        val countingBody = object : ResponseBody() {
            override fun contentType(): MediaType? = body.contentType()
            override fun contentLength(): Long = body.contentLength()

            override fun source(): BufferedSource {
                val forwardingSource = object : ForwardingSource(body.source()) {
                    override fun read(sink: Buffer, byteCount: Long): Long {
                        val readBytes = super.read(sink, byteCount)
                        if (readBytes > 0) {
                            if (isDownload) {
                                recordDownloadBytes(readBytes, isNetwork = true)
                            } else {
                                recordStreamingBytes(readBytes, isNetwork = true)
                            }
                        }
                        return readBytes
                    }
                }
                return forwardingSource.buffer()
            }
        }

        response.newBuilder().body(countingBody).build()
    }
}
