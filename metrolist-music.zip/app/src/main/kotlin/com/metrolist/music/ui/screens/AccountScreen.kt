/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.sp
import androidx.compose.material3.TopAppBarDefaults
import coil3.compose.AsyncImage
import com.metrolist.innertube.models.SongItem
import com.metrolist.music.LocalPlayerConnection
import com.metrolist.music.LocalDatabase
import com.metrolist.music.extensions.toMediaItem
import com.metrolist.music.constants.AppBarHeight
import com.metrolist.music.playback.queues.ListQueue
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.constants.GridItemSize
import com.metrolist.music.constants.GridItemsSizeKey
import com.metrolist.music.constants.GridThumbnailHeight
import com.metrolist.music.db.entities.PodcastEntity
import com.metrolist.music.ui.component.ChipsRow
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.LocalMenuState
import com.metrolist.music.ui.component.YouTubeGridItem
import com.metrolist.music.ui.component.shimmer.GridItemPlaceHolder
import com.metrolist.music.ui.component.shimmer.ListItemPlaceHolder
import com.metrolist.music.ui.component.shimmer.ShimmerHost
import com.metrolist.music.ui.menu.YouTubeAlbumMenu
import com.metrolist.music.ui.menu.YouTubeArtistMenu
import com.metrolist.music.ui.menu.YouTubePlaylistMenu
import com.metrolist.music.ui.utils.backToMain
import com.metrolist.music.utils.rememberEnumPreference
import com.metrolist.music.viewmodels.AccountContentType
import com.metrolist.music.viewmodels.AccountViewModel
import com.metrolist.music.viewmodels.HomeViewModel
import com.metrolist.music.constants.AccountNameKey
import com.metrolist.music.constants.AccountEmailKey
import com.metrolist.music.constants.AccountChannelHandleKey
import com.metrolist.music.constants.AccountProviderKey
import com.metrolist.music.constants.InnerTubeCookieKey
import com.metrolist.music.constants.EnableLiquidGlassKey
import com.metrolist.music.constants.GlassSaturationKey
import com.metrolist.music.constants.GlassBlurRadiusKey
import com.metrolist.music.constants.LensRefractionHeightKey
import com.metrolist.music.constants.LensRefractionAmountKey
import com.metrolist.music.constants.ChromaticAberrationKey
import com.metrolist.music.constants.DepthEffectKey
import com.metrolist.music.constants.SurfaceOpacityKey
import com.metrolist.music.constants.PureBlackKey
import com.metrolist.music.ui.components.liquidGlass
import com.metrolist.music.utils.rememberPreference
import com.metrolist.innertube.utils.parseCookieString
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun AccountScreen(
    navController: NavController,
    viewModel: AccountViewModel = hiltViewModel(),
) {
    val menuState = LocalMenuState.current
    val haptic = LocalHapticFeedback.current

    val coroutineScope = rememberCoroutineScope()

    val playlists by viewModel.playlists.collectAsStateWithLifecycle()
    val albums by viewModel.albums.collectAsStateWithLifecycle()
    val artists by viewModel.artists.collectAsStateWithLifecycle()
    val sePlaylist by viewModel.sePlaylist.collectAsStateWithLifecycle()
    val rdpnPlaylist by viewModel.rdpnPlaylist.collectAsStateWithLifecycle()
    val podcastPlaylists by viewModel.podcastPlaylists.collectAsStateWithLifecycle()
    val podcastChannels by viewModel.podcastChannels.collectAsStateWithLifecycle()
    val selectedContentType by viewModel.selectedContentType.collectAsStateWithLifecycle()
    val gridItemSize by rememberEnumPreference(GridItemsSizeKey, GridItemSize.BIG)

    val homeViewModel: HomeViewModel = hiltViewModel()
    val accountImageUrl by homeViewModel.accountImageUrl.collectAsStateWithLifecycle()
    val accountNamePref by rememberPreference(AccountNameKey, "Guest")
    val accountEmailPref by rememberPreference(AccountEmailKey, "")
    val accountChannelHandlePref by rememberPreference(AccountChannelHandleKey, "")
    val accountProviderPref by rememberPreference(AccountProviderKey, "none")
    val innerTubeCookie by rememberPreference(InnerTubeCookieKey, "")

    val isLoggedIn = remember(innerTubeCookie, accountProviderPref) {
        "SAPISID" in parseCookieString(innerTubeCookie) || accountProviderPref == "discord" || accountProviderPref == "khách" || accountProviderPref == "guest" || accountProviderPref == "google"
    }

    val finalName = if (isLoggedIn) {
        if (accountNamePref.isNotBlank() && accountNamePref != "Guest") accountNamePref else stringResource(R.string.account_metrolist_user)
    } else {
        stringResource(R.string.account_guest_user)
    }

    val finalEmail = if (isLoggedIn && accountEmailPref.isNotBlank()) accountEmailPref else stringResource(R.string.account_email_not_linked)
    val finalHandle = if (isLoggedIn && accountChannelHandlePref.isNotBlank()) accountChannelHandlePref else "@metrolist_guest"

    var showChannelDialog by remember { mutableStateOf(false) }
    var showBadgesDialog by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val database = com.metrolist.music.LocalDatabase.current
    val fromTime = remember { java.time.LocalDateTime.of(2000, 1, 1, 0, 0) }
    val toTime = remember { java.time.LocalDateTime.now() }

    val totalPlayTimeMs by (database?.getTotalPlayTimeInRange(fromTime, toTime)?.collectAsStateWithLifecycle(initialValue = null) ?: remember { mutableStateOf(null) })
    val totalPlayTimeHrs = (totalPlayTimeMs ?: 0L).toFloat() / (1000 * 3600)

    val uniqueArtistsCount by (database?.getUniqueArtistCountInRange(fromTime, toTime)?.collectAsStateWithLifecycle(initialValue = 0) ?: remember { mutableStateOf(0) })
    val uniqueAlbumsCount by (database?.getUniqueAlbumCountInRange(fromTime, toTime)?.collectAsStateWithLifecycle(initialValue = 0) ?: remember { mutableStateOf(0) })

    val downloadedSongs by (database?.downloadedSongs(com.metrolist.music.constants.SongSortType.CREATE_DATE, false)?.collectAsStateWithLifecycle(initialValue = emptyList()) ?: remember { mutableStateOf(emptyList()) })
    val downloadedSongsCount = downloadedSongs.size

    val eqPrefs = remember { context.getSharedPreferences("nanosonic_eq_profiles", android.content.Context.MODE_PRIVATE) }
    val isEqActive = remember { eqPrefs.getString("active_profile_id", null) != null }

    val playTimeProgress = (totalPlayTimeHrs / 50f).coerceIn(0f, 1f)
    val playTimeText = if (playTimeProgress >= 1.0f) "Đã hoàn thành" else String.format(java.util.Locale.getDefault(), "%.1f/50 giờ", totalPlayTimeHrs)

    val artistProgress = (uniqueArtistsCount.toFloat() / 100f).coerceIn(0f, 1f)
    val artistText = if (artistProgress >= 1.0f) "Đã hoàn thành" else "$uniqueArtistsCount/100 nghệ sĩ"

    val albumProgress = (uniqueAlbumsCount.toFloat() / 20f).coerceIn(0f, 1f)
    val albumText = if (albumProgress >= 1.0f) "Đã hoàn thành" else "$uniqueAlbumsCount/20 album"

    val downloadProgress = (downloadedSongsCount.toFloat() / 50f).coerceIn(0f, 1f)
    val downloadText = if (downloadProgress >= 1.0f) "Đã hoàn thành" else "$downloadedSongsCount/50 bài hát"

    val eqProgress = if (isEqActive) 1.0f else 0.0f
    val eqText = if (isEqActive) "Đã hoàn thành" else "0/1 kích hoạt"

    Box(modifier = Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val systemBarsTopPadding = WindowInsets.systemBars.asPaddingValues().calculateTopPadding()
        val headerOffset = with(density) {
            -(systemBarsTopPadding + AppBarHeight).roundToPx()
        }

        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = GridThumbnailHeight + if (gridItemSize == GridItemSize.BIG) 24.dp else (-24).dp),
            contentPadding = LocalPlayerAwareWindowInsets.current.asPaddingValues(),
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                val context = LocalContext.current
                val playerConnection = LocalPlayerConnection.current

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(0.72f)
                ) {
                    // Background Image
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .offset {
                                IntOffset(x = 0, y = headerOffset)
                            }
                    ) {
                        if (accountImageUrl != null) {
                            AsyncImage(
                                model = accountImageUrl,
                                contentDescription = "Background Cover",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(
                                                MaterialTheme.colorScheme.primaryContainer,
                                                MaterialTheme.colorScheme.surface
                                            )
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.person),
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(120.dp)
                                )
                            }
                        }

                        // Dark gradient overlay
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color.Black.copy(alpha = 0.4f),
                                            Color.Black.copy(alpha = 0.0f),
                                            Color.Black.copy(alpha = 0.4f),
                                            Color.Black.copy(alpha = 0.95f)
                                        )
                                    )
                                )
                        )
                    }

                    // Overlaid controls - positioned at bottom of the Box
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomStart)
                            .padding(horizontal = 20.dp, vertical = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Channel Name
                        Text(
                            text = finalName,
                            style = MaterialTheme.typography.headlineLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 32.sp
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        // Subscribe Button
                        var isSubscribedLocal by remember { mutableStateOf(false) }
                        Button(
                            onClick = { isSubscribedLocal = !isSubscribedLocal },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSubscribedLocal) Color.White.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.15f)
                            ),
                            shape = RoundedCornerShape(50),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.3f)),
                            modifier = Modifier.height(40.dp)
                        ) {
                            Text(
                                text = if (isSubscribedLocal) "Đã đăng ký" else "Đăng ký",
                                style = MaterialTheme.typography.labelLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                        }

                        // Beautiful Unlocked Badges Section on Account Page!
                        val badgesUnlockedCount = (if (playTimeProgress >= 1f) 1 else 0) +
                                                 (if (artistProgress >= 1f) 1 else 0) +
                                                 (if (albumProgress >= 1f) 1 else 0) +
                                                 (if (downloadProgress >= 1f) 1 else 0) +
                                                 (if (eqProgress >= 1f) 1 else 0)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showBadgesDialog = true }
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.White.copy(alpha = 0.08f))
                                .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(16.dp))
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.crown),
                                    contentDescription = null,
                                    tint = Color(0xFFFFD700),
                                    modifier = Modifier.size(24.dp)
                                )
                                Column {
                                    Text(
                                        text = stringResource(R.string.badge_achievement_title),
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        color = Color.White,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = stringResource(R.string.badge_unlocked_count, badgesUnlockedCount, 5),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White.copy(alpha = 0.7f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (playTimeProgress >= 1f) Text("🏆", fontSize = 16.sp)
                                if (artistProgress >= 1f) Text("🧭", fontSize = 16.sp)
                                if (albumProgress >= 1f) Text("🦉", fontSize = 16.sp)
                                if (downloadProgress >= 1f) Text("💾", fontSize = 16.sp)
                                if (eqProgress >= 1f) Text("🎸", fontSize = 16.sp)

                                if (badgesUnlockedCount == 0) {
                                    Text(
                                        text = stringResource(R.string.badge_no_unlocked),
                                        style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.5f)),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Icon(
                                    painter = painterResource(R.drawable.navigate_next),
                                    contentDescription = "Chi tiết",
                                    tint = Color.White.copy(alpha = 0.7f),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // "Video" Section Header
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    navController.navigate("auto_playlist/downloaded")
                                },
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Video",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                            Icon(
                                painter = painterResource(R.drawable.navigate_next),
                                contentDescription = "View All Videos",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // Horizontal list of videos
                        val db = LocalDatabase.current
                        val downloadedSongsFlow = remember(db) {
                            db?.downloadedSongs(com.metrolist.music.constants.SongSortType.CREATE_DATE, false)
                        }
                        val downloadedSongs by (downloadedSongsFlow
                            ?.collectAsStateWithLifecycle(initialValue = emptyList<com.metrolist.music.db.entities.Song>())
                            ?: remember { mutableStateOf(emptyList<com.metrolist.music.db.entities.Song>()) })

                        val displaySongs = remember(downloadedSongs) {
                            if (downloadedSongs.isNotEmpty()) {
                                downloadedSongs.take(5).map { song ->
                                    SongItem(
                                        id = song.song.id,
                                        title = song.song.title,
                                        artists = song.artists.map { com.metrolist.innertube.models.Artist(name = it.name, id = it.id) },
                                        thumbnail = song.song.thumbnailUrl ?: "",
                                        duration = song.song.duration,
                                        album = song.song.albumName?.let { com.metrolist.innertube.models.Album(name = it, id = "") }
                                    )
                                }
                            } else {
                                listOf(
                                    SongItem(
                                        id = "mock1",
                                        title = "Funk... Hết ...",
                                        artists = listOf(com.metrolist.innertube.models.Artist(name = finalName, id = "")),
                                        thumbnail = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=400",
                                        duration = 195,
                                        album = null
                                    ),
                                    SongItem(
                                        id = "mock2",
                                        title = "Tết Là Tết Funk",
                                        artists = listOf(com.metrolist.innertube.models.Artist(name = finalName, id = "")),
                                        thumbnail = "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=400",
                                        duration = 260,
                                        album = null
                                    ),
                                    SongItem(
                                        id = "mock3",
                                        title = "Tái Sinh",
                                        artists = listOf(com.metrolist.innertube.models.Artist(name = finalName, id = "")),
                                        thumbnail = "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=400",
                                        duration = 230,
                                        album = null
                                    )
                                )
                            }
                        }

                        LazyRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            items(displaySongs) { song ->
                                Column(
                                    modifier = Modifier
                                        .width(160.dp)
                                        .clickable {
                                            if (song.id.startsWith("mock")) {
                                                Toast.makeText(context, "Đang phát bài hát: ${song.title}", Toast.LENGTH_SHORT).show()
                                            } else {
                                                playerConnection?.playQueue(ListQueue(title = song.title, items = listOf(song.toMediaItem())))
                                            }
                                        }
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(160.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(Color.DarkGray),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        AsyncImage(
                                            model = song.thumbnail,
                                            contentDescription = song.title,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )

                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                                .background(Color.White.copy(alpha = 0.8f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                painter = painterResource(R.drawable.play),
                                                contentDescription = "Play",
                                                tint = Color.Black,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Text(
                                        text = song.title,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        ),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )

                                    Text(
                                        text = song.artists?.firstOrNull()?.name ?: finalName,
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = Color.White.copy(alpha = 0.7f)
                                        ),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }

        item(span = { GridItemSpan(maxLineSpan) }) {
            ChipsRow(
                chips =
                    listOf(
                        AccountContentType.PLAYLISTS to stringResource(R.string.filter_playlists),
                        AccountContentType.ALBUMS to stringResource(R.string.filter_albums),
                        AccountContentType.ARTISTS to stringResource(R.string.filter_artists),
                        AccountContentType.PODCASTS to stringResource(R.string.filter_podcasts),
                    ),
                currentValue = selectedContentType,
                onValueUpdate = { viewModel.setSelectedContentType(it) },
            )
        }

        when (selectedContentType) {
            AccountContentType.PLAYLISTS -> {
                items(
                    items = playlists.orEmpty().distinctBy { it.id },
                    key = { "account_playlist_${it.id}" },
                ) { item ->
                    YouTubeGridItem(
                        item = item,
                        fillMaxWidth = true,
                        modifier =
                            Modifier
                                .combinedClickable(
                                    onClick = {
                                        navController.navigate("online_playlist/${item.id}")
                                    },
                                    onLongClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        menuState.show {
                                            YouTubePlaylistMenu(
                                                playlist = item,
                                                coroutineScope = coroutineScope,
                                                onDismiss = menuState::dismiss,
                                            )
                                        }
                                    },
                                ),
                    )
                }

                if (playlists == null) {
                    items(8) {
                        ShimmerHost {
                            GridItemPlaceHolder(fillMaxWidth = true)
                        }
                    }
                }
            }

            AccountContentType.ALBUMS -> {
                items(
                    items = albums.orEmpty().distinctBy { it.id },
                    key = { "account_album_${it.id}" },
                ) { item ->
                    YouTubeGridItem(
                        item = item,
                        fillMaxWidth = true,
                        modifier =
                            Modifier
                                .combinedClickable(
                                    onClick = {
                                        navController.navigate("album/${item.id}")
                                    },
                                    onLongClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        menuState.show {
                                            YouTubeAlbumMenu(
                                                albumItem = item,
                                                onDismiss = menuState::dismiss,
                                            )
                                        }
                                    },
                                ),
                    )
                }

                if (albums == null) {
                    items(8) {
                        ShimmerHost {
                            GridItemPlaceHolder(fillMaxWidth = true)
                        }
                    }
                }
            }

            AccountContentType.ARTISTS -> {
                items(
                    items = artists.orEmpty().distinctBy { it.id },
                    key = { "account_artist_${it.id}" },
                ) { item ->
                    YouTubeGridItem(
                        item = item,
                        fillMaxWidth = true,
                        modifier =
                            Modifier
                                .combinedClickable(
                                    onClick = {
                                        navController.navigate("artist/${item.id}")
                                    },
                                    onLongClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        menuState.show {
                                            YouTubeArtistMenu(
                                                artist = item,
                                                onDismiss = menuState::dismiss,
                                            )
                                        }
                                    },
                                ),
                    )
                }

                if (artists == null) {
                    items(8) {
                        ShimmerHost {
                            GridItemPlaceHolder(fillMaxWidth = true)
                        }
                    }
                }
            }

            AccountContentType.PODCASTS -> {
                // Show RDPN "New Episodes" playlist if available
                rdpnPlaylist?.let { rdpn ->
                    item(
                        key = "rdpn_playlist",
                        span = { GridItemSpan(maxLineSpan) },
                    ) {
                        SePlaylistAccountItem(
                            thumbnailUrl = rdpn.thumbnail,
                            title = stringResource(R.string.new_episodes),
                            subtitle = stringResource(R.string.auto_playlist),
                            onClick = { navController.navigate("online_playlist/RDPN") },
                        )
                    }
                }

                // Show SE "Episodes for Later" playlist if available
                sePlaylist?.let { se ->
                    item(
                        key = "se_playlist",
                        span = { GridItemSpan(maxLineSpan) },
                    ) {
                        SePlaylistAccountItem(
                            thumbnailUrl = se.thumbnail,
                            title = stringResource(R.string.episodes_for_later),
                            subtitle = stringResource(R.string.auto_playlist),
                            onClick = { navController.navigate("online_playlist/SE") },
                        )
                    }
                }

                // Subscribed podcast shows
                if (podcastPlaylists.isNotEmpty()) {
                    item(
                        key = "podcasts_header",
                        span = { GridItemSpan(maxLineSpan) },
                    ) {
                        Text(
                            text = stringResource(R.string.filter_podcasts),
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.secondary,
                            modifier =
                                Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                        )
                    }
                    itemsIndexed(
                        items = podcastPlaylists,
                        key = { _, item -> "podcast_${item.id}" },
                        span = { _, _ -> GridItemSpan(maxLineSpan) },
                    ) { _, podcast ->
                        PodcastAccountItem(
                            thumbnailUrl = podcast.thumbnailUrl,
                            title = podcast.title,
                            subtitle = podcast.author,
                            onClick = { navController.navigate("online_podcast/${android.net.Uri.encode(podcast.id)}") },
                        )
                    }
                }

                // Podcast channels
                if (podcastChannels.isNotEmpty()) {
                    item(
                        key = "channels_header",
                        span = { GridItemSpan(maxLineSpan) },
                    ) {
                        Text(
                            text = stringResource(R.string.filter_channels),
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.secondary,
                            modifier =
                                Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                        )
                    }
                    itemsIndexed(
                        items = podcastChannels,
                        key = { _, item -> "channel_${item.id}" },
                        span = { _, _ -> GridItemSpan(maxLineSpan) },
                    ) { _, channel ->
                        PodcastChannelAccountItem(
                            thumbnailUrl = channel.thumbnail,
                            name = channel.title,
                            onClick = { navController.navigate("artist/${channel.id}") },
                        )
                    }
                }

                if (rdpnPlaylist == null && sePlaylist == null && podcastPlaylists.isEmpty() && podcastChannels.isEmpty()) {
                    items(4, span = { GridItemSpan(maxLineSpan) }) {
                        ShimmerHost {
                            ListItemPlaceHolder()
                        }
                    }
                }
            }
        }
    }

    if (showChannelDialog) {
        YourChannelDialog(
            name = finalName,
            handle = finalHandle,
            avatarUrl = if (isLoggedIn) accountImageUrl else null,
            onDismiss = { showChannelDialog = false }
        )
    }

    if (showBadgesDialog) {
        BadgesDialog(
            playTimeProgress = playTimeProgress,
            playTimeText = playTimeText,
            artistProgress = artistProgress,
            artistText = artistText,
            albumProgress = albumProgress,
            albumText = albumText,
            downloadProgress = downloadProgress,
            downloadText = downloadText,
            eqProgress = eqProgress,
            eqText = eqText,
            onDismiss = { showBadgesDialog = false }
        )
    }

        // Transparent, gorgeous TopAppBar matching the screenshot!
        TopAppBar(
            title = {},
            navigationIcon = {
                IconButton(
                    onClick = navController::navigateUp,
                    onLongClick = navController::backToMain,
                ) {
                    Icon(
                        painter = painterResource(R.drawable.arrow_back),
                        contentDescription = null,
                        tint = Color.White
                    )
                }
            },
            actions = {
                IconButton(
                    onClick = {
                        navController.navigate("settings/channel")
                    },
                    onLongClick = {}
                ) {
                    Icon(
                        painter = painterResource(R.drawable.link),
                        contentDescription = "Channel Settings",
                        tint = Color.White
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = Color.Transparent,
                scrolledContainerColor = Color.Transparent,
                navigationIconContentColor = Color.White,
                titleContentColor = Color.White,
                actionIconContentColor = Color.White
            )
        )
    }
}

@Composable
private fun AccountMenuRowItem(
    iconId: Int,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            painter = painterResource(iconId),
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
            )
        }
        Icon(
            painter = painterResource(R.drawable.navigate_next),
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun YourChannelDialog(
    name: String,
    handle: String,
    avatarUrl: String?,
    onDismiss: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
            )
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    if (avatarUrl != null) {
                        AsyncImage(
                            model = avatarUrl,
                            contentDescription = "Avatar",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                        )
                    } else {
                        Icon(
                            painter = painterResource(R.drawable.person),
                            contentDescription = "Avatar",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(44.dp)
                        )
                    }
                }

                Text(
                    text = name,
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Text(
                    text = handle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "Người sáng tạo nội dung Metrolist",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.1f))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "1,420+",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Phút nghe",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "18",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Danh sách phát",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "248",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Bài hát đã lưu",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.1f))

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.Start,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "Giới thiệu kênh cá nhân",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Đây là không gian âm nhạc độc quyền của bạn trên Metrolist. Tất cả nội dung đã nghe, bài hát yêu thích và bộ sưu tập cá nhân đều được lưu trữ và tối ưu hóa tại đây.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text("Đóng")
                }
            }
        }
    }
}

@Composable
fun BadgesDialog(
    playTimeProgress: Float,
    playTimeText: String,
    artistProgress: Float,
    artistText: String,
    albumProgress: Float,
    albumText: String,
    downloadProgress: Float,
    downloadText: String,
    eqProgress: Float,
    eqText: String,
    onDismiss: () -> Unit,
) {
    var selectedFilter by remember { mutableStateOf("all") } // "all", "unlocked", "locked"

    val enableLiquidGlass by rememberPreference(EnableLiquidGlassKey, defaultValue = true)
    val glassSaturation by rememberPreference(GlassSaturationKey, defaultValue = 1.3f)
    val glassBlurRadius by rememberPreference(GlassBlurRadiusKey, defaultValue = 24f)
    val lensRefractionHeight by rememberPreference(LensRefractionHeightKey, defaultValue = 14f)
    val lensRefractionAmount by rememberPreference(LensRefractionAmountKey, defaultValue = 0.85f)
    val chromaticAberration by rememberPreference(ChromaticAberrationKey, defaultValue = 0.45f)
    val depthEffect by rememberPreference(DepthEffectKey, defaultValue = 0.75f)
    val surfaceOpacity by rememberPreference(SurfaceOpacityKey, defaultValue = 1.0f)
    val pureBlack by rememberPreference(PureBlackKey, defaultValue = false)

    val dialogBgColor = if (pureBlack) Color.Black else MaterialTheme.colorScheme.surfaceContainerHigh

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 24.dp)
                .then(
                    if (enableLiquidGlass) {
                        Modifier.liquidGlass(
                            enabled = true,
                            blurRadiusDp = glassBlurRadius,
                            saturation = glassSaturation,
                            refractionHeight = lensRefractionHeight,
                            refractionAmount = lensRefractionAmount,
                            chromaticAberration = chromaticAberration,
                            depthEffect = depthEffect,
                            surfaceOpacity = surfaceOpacity,
                            surfaceTintColor = dialogBgColor,
                            shape = RoundedCornerShape(28.dp)
                        )
                    } else {
                        Modifier.background(dialogBgColor, shape = RoundedCornerShape(28.dp))
                    }
                ),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color.Transparent
            ),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Glow star icon at top
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = painterResource(R.drawable.crown),
                        contentDescription = null,
                        tint = Color(0xFFFFD700),
                        modifier = Modifier.size(36.dp)
                    )
                }

                Text(
                    text = stringResource(R.string.badge_hall_of_fame_title),
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Text(
                    text = stringResource(R.string.badge_hall_of_fame_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f),
                    textAlign = TextAlign.Center
                )

                // Filter Buttons (Pill shaped buttons)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val filters = listOf(
                        "all" to stringResource(R.string.badge_filter_all),
                        "unlocked" to stringResource(R.string.badge_filter_unlocked),
                        "locked" to stringResource(R.string.badge_filter_locked)
                    )
                    filters.forEach { (key, label) ->
                        val isSelected = selectedFilter == key
                        Button(
                            onClick = { selectedFilter = key },
                            modifier = Modifier
                                .weight(1f)
                                .height(36.dp),
                            shape = RoundedCornerShape(50),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f),
                                contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                            ),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                            )
                        }
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.12f))

                // Scrollable badge list
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(320.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val badgeList = listOf(
                        Triple("🏆", stringResource(R.string.badge_superfan_title), stringResource(R.string.badge_superfan_desc)) to Pair(playTimeProgress, playTimeText),
                        Triple("🧭", stringResource(R.string.badge_explorer_title), stringResource(R.string.badge_explorer_desc)) to Pair(artistProgress, artistText),
                        Triple("🦉", stringResource(R.string.badge_nightowl_title), stringResource(R.string.badge_nightowl_desc)) to Pair(albumProgress, albumText),
                        Triple("💾", stringResource(R.string.badge_collector_title), stringResource(R.string.badge_collector_desc)) to Pair(downloadProgress, downloadText),
                        Triple("🎸", stringResource(R.string.badge_audiophile_title), stringResource(R.string.badge_audiophile_desc)) to Pair(eqProgress, eqText)
                    )

                    val filteredList = badgeList.filter { (_, stats) ->
                        val (prog, _) = stats
                        when (selectedFilter) {
                            "unlocked" -> prog >= 1f
                            "locked" -> prog < 1f
                            else -> true
                        }
                    }

                    if (filteredList.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (selectedFilter == "unlocked") stringResource(R.string.badge_empty_unlocked) else stringResource(R.string.badge_empty_locked),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                    } else {
                        filteredList.forEach { (info, stats) ->
                            val (emoji, title, desc) = info
                            val (prog, text) = stats
                            BadgeItem(
                                emoji = emoji,
                                title = title,
                                description = desc,
                                progress = prog,
                                progressText = text
                            )
                        }
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.12f))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text(
                        text = stringResource(R.string.badge_awesome_button),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun BadgeItem(
    emoji: String,
    title: String,
    description: String,
    progress: Float,
    progressText: String,
) {
    val isCompleted = progress >= 1.0f
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                if (isCompleted) {
                    Brush.linearGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                            MaterialTheme.colorScheme.secondary.copy(alpha = 0.03f)
                        )
                    )
                } else {
                    Brush.linearGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.onSurface.copy(alpha = 0.03f),
                            MaterialTheme.colorScheme.onSurface.copy(alpha = 0.01f)
                        )
                    )
                }
            )
            .border(
                width = 1.dp,
                color = if (isCompleted) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                        else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f),
                shape = RoundedCornerShape(16.dp)
            )
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Emoji badge artwork with border and custom style
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(
                    if (isCompleted) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                    else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = emoji,
                style = MaterialTheme.typography.titleLarge
            )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                    color = if (isCompleted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f, fill = false),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                
                if (isCompleted) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFFFFD700).copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Đã Đạt",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color(0xFFD4AF37),
                            maxLines = 1,
                            overflow = TextOverflow.Clip
                        )
                    }
                }
            }
            
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
            )

            Spacer(modifier = Modifier.height(10.dp))
            
            // Custom progress bar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(progress)
                            .clip(RoundedCornerShape(3.dp))
                            .background(
                                if (isCompleted) Brush.horizontalGradient(
                                    colors = listOf(
                                        MaterialTheme.colorScheme.primary,
                                        MaterialTheme.colorScheme.secondary
                                    )
                                ) else Brush.horizontalGradient(
                                    colors = listOf(
                                        MaterialTheme.colorScheme.secondary,
                                        MaterialTheme.colorScheme.secondary.copy(alpha = 0.5f)
                                    )
                                )
                            )
                    )
                }
                
                Text(
                    text = progressText,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = if (isCompleted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun SePlaylistAccountItem(
    thumbnailUrl: String?,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier =
            modifier
                .fillMaxWidth()
                .clickable(onClick = onClick)
                .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        Box(
            modifier =
                Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            if (thumbnailUrl != null) {
                AsyncImage(
                    model = thumbnailUrl,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier =
                        Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(8.dp)),
                )
            } else {
                Icon(
                    painter = painterResource(R.drawable.queue_music),
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(28.dp),
                )
            }
        }

        Spacer(Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }

        Icon(
            painter = painterResource(R.drawable.navigate_next),
            contentDescription = null,
        )
    }
}

@Composable
private fun PodcastAccountItem(
    thumbnailUrl: String?,
    title: String,
    subtitle: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier =
            modifier
                .fillMaxWidth()
                .clickable(onClick = onClick)
                .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Box(
            modifier =
                Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            if (thumbnailUrl != null) {
                AsyncImage(
                    model = thumbnailUrl,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier =
                        Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(8.dp)),
                )
            } else {
                Icon(
                    painter = painterResource(R.drawable.queue_music),
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(28.dp),
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun PodcastChannelAccountItem(
    thumbnailUrl: String?,
    name: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier =
            modifier
                .fillMaxWidth()
                .clickable(onClick = onClick)
                .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        AsyncImage(
            model = thumbnailUrl,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier =
                Modifier
                    .size(56.dp)
                    .clip(CircleShape),
        )
        Spacer(Modifier.width(12.dp))
        Text(
            text = name,
            style = MaterialTheme.typography.bodyLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
    }
}
