/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.api

import org.json.JSONObject
import java.time.Instant
import java.time.format.DateTimeFormatter

/**
 * Normalized Error & State Response Schema
 * Standardized across all AI providers (OpenAI, Anthropic, Gemini, OpenRouter, Custom Base URL, Remote .txt)
 *
 * Example JSON representation:
 * {
 *   "status": "ERROR",
 *   "provider": "CUSTOM_PROVIDER",
 *   "endpoint": "https://custom-ai-provider.com/v1",
 *   "key_state": "INVALID",
 *   "error": {
 *     "code": "AUTH_FAILED",
 *     "message": "API Key không hợp lệ hoặc đường dẫn API nhà cung cấp không phản hồi.",
 *     "raw_provider_code": 401,
 *     "timestamp": "2026-09-04T10:00:00Z"
 *   }
 * }
 */
data class NormalizedErrorDetail(
    val code: String,
    val message: String,
    val rawProviderCode: Int? = null,
    val timestamp: String = DateTimeFormatter.ISO_INSTANT.format(Instant.now()),
) {
    fun toJsonObject(): JSONObject = JSONObject().apply {
        put("code", code)
        put("message", message)
        if (rawProviderCode != null) put("raw_provider_code", rawProviderCode)
        put("timestamp", timestamp)
    }
}

data class NormalizedResponseSchema(
    val status: String, // "SUCCESS" or "ERROR"
    val provider: String,
    val endpoint: String,
    val keyState: String, // "VALID_ACTIVE", "EXPIRED", "RENEWED_EXTENDED", "LIFETIME_FREE", "INVALID"
    val error: NormalizedErrorDetail? = null,
    val metadata: Map<String, Any?> = emptyMap(),
) {
    fun toJsonString(indent: Int = 2): String = toJsonObject().toString(indent)

    fun toJsonObject(): JSONObject = JSONObject().apply {
        put("status", status)
        put("provider", provider)
        put("endpoint", endpoint)
        put("key_state", keyState)
        if (error != null) {
            put("error", error.toJsonObject())
        }
        if (metadata.isNotEmpty()) {
            val metaObj = JSONObject()
            metadata.forEach { (k, v) -> metaObj.put(k, v) }
            put("metadata", metaObj)
        }
    }

    companion object {
        fun success(
            provider: String,
            endpoint: String,
            keyState: String,
            metadata: Map<String, Any?> = emptyMap(),
        ): NormalizedResponseSchema {
            return NormalizedResponseSchema(
                status = "SUCCESS",
                provider = provider,
                endpoint = endpoint,
                keyState = keyState,
                metadata = metadata,
            )
        }

        fun error(
            provider: String,
            endpoint: String,
            keyState: String,
            code: String,
            message: String,
            rawProviderCode: Int? = null,
        ): NormalizedResponseSchema {
            return NormalizedResponseSchema(
                status = "ERROR",
                provider = provider,
                endpoint = endpoint,
                keyState = keyState,
                error = NormalizedErrorDetail(
                    code = code,
                    message = message,
                    rawProviderCode = rawProviderCode,
                ),
            )
        }
    }
}
