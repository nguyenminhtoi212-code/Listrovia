/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import timber.log.Timber
import com.metrolist.music.utils.reportException
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil3.compose.AsyncImage
import com.metrolist.innertube.YouTube
import com.metrolist.innertube.utils.parseCookieString
import com.metrolist.music.BuildConfig
import com.metrolist.music.R
import com.metrolist.music.constants.AccountChannelHandleKey
import com.metrolist.music.constants.AccountEmailKey
import com.metrolist.music.constants.AccountNameKey
import com.metrolist.music.constants.DataSyncIdKey
import com.metrolist.music.constants.InnerTubeCookieKey
import com.metrolist.music.constants.UseLoginForBrowse
import com.metrolist.music.constants.AccountProviderKey
import com.metrolist.music.constants.VisitorDataKey
import com.metrolist.music.constants.YtmSyncKey
import com.metrolist.music.ui.component.DefaultDialog
import com.metrolist.music.ui.component.InfoLabel
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import com.metrolist.music.ui.component.PreferenceEntry
import com.metrolist.music.ui.component.TextFieldDialog
import com.metrolist.music.utils.Updater
import com.metrolist.music.utils.rememberPreference
import com.metrolist.music.viewmodels.AccountSettingsViewModel
import com.metrolist.music.viewmodels.HomeViewModel
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow

@Composable
fun AccountSettings(
    navController: NavController,
    onClose: () -> Unit,
    latestVersionName: String,
    isDialog: Boolean = false,
) {
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current

    val (accountNamePref, onAccountNameChange) = rememberPreference(AccountNameKey, "")
    val (accountEmail, onAccountEmailChange) = rememberPreference(AccountEmailKey, "")
    val (accountChannelHandle, onAccountChannelHandleChange) = rememberPreference(AccountChannelHandleKey, "")
    val (innerTubeCookie, onInnerTubeCookieChange) = rememberPreference(InnerTubeCookieKey, "")
    val (visitorData, onVisitorDataChange) = rememberPreference(VisitorDataKey, "")
    val (dataSyncId, onDataSyncIdChange) = rememberPreference(DataSyncIdKey, "")
    val (accountProvider, onAccountProviderChange) = rememberPreference(AccountProviderKey, "none")

    val isLoggedIn = remember(innerTubeCookie, accountProvider) {
        "SAPISID" in parseCookieString(innerTubeCookie) || accountProvider == "discord" || accountProvider == "khách" || accountProvider == "guest"
    }
    val (useLoginForBrowse, onUseLoginForBrowseChange) = rememberPreference(UseLoginForBrowse, true)
    val (ytmSync, onYtmSyncChange) = rememberPreference(YtmSyncKey, true)

    val homeViewModel: HomeViewModel = hiltViewModel()
    val accountSettingsViewModel: AccountSettingsViewModel = hiltViewModel()
    val accountName by homeViewModel.accountName.collectAsStateWithLifecycle()
    val accountImageUrl by homeViewModel.accountImageUrl.collectAsStateWithLifecycle()

    var showToken by remember { mutableStateOf(false) }
    var showTokenEditor by remember { mutableStateOf(false) }
    var showLogoutDialog by remember { mutableStateOf(false) }
    var showDeleteAccountDialog by remember { mutableStateOf(false) }
    var showBadgesDialog by remember { mutableStateOf(false) }

    val database = com.metrolist.music.LocalDatabase.current
    val fromTime = remember { java.time.LocalDateTime.of(2000, 1, 1, 0, 0) }
    val toTime = remember { java.time.LocalDateTime.now() }

    val totalPlayTimeMs by (database?.getTotalPlayTimeInRange(fromTime, toTime)?.collectAsStateWithLifecycle(initialValue = null) ?: remember { mutableStateOf(null) })
    val totalPlayTimeHrs = (totalPlayTimeMs ?: 0L).toFloat() / (1000 * 3600)

    val uniqueArtistsCount by (database?.getUniqueArtistCountInRange(fromTime, toTime)?.collectAsStateWithLifecycle(initialValue = 0) ?: remember { mutableStateOf(0) })
    val uniqueAlbumsCount by (database?.getUniqueAlbumCountInRange(fromTime, toTime)?.collectAsStateWithLifecycle(initialValue = 0) ?: remember { mutableStateOf(0) })

    val downloadedSongs by (database?.downloadedSongs(com.metrolist.music.constants.SongSortType.CREATE_DATE, false)?.collectAsStateWithLifecycle(initialValue = emptyList()) ?: remember { mutableStateOf(emptyList()) })
    val downloadedSongsCount = downloadedSongs.size

    val eqPrefs = remember { context.getSharedPreferences("nanosonic_eq_profiles", android.content.Context.MODE_PRIVATE) }
    val isEqActive = remember { eqPrefs.getString("active_profile_id", null) != null }

    val playTimeProgress = (totalPlayTimeHrs / 50f).coerceIn(0f, 1f)
    val playTimeText = if (playTimeProgress >= 1.0f) "Đã hoàn thành" else String.format(java.util.Locale.getDefault(), "%.1f/50 giờ", totalPlayTimeHrs)

    val artistProgress = (uniqueArtistsCount.toFloat() / 100f).coerceIn(0f, 1f)
    val artistText = if (artistProgress >= 1.0f) "Đã hoàn thành" else "$uniqueArtistsCount/100 nghệ sĩ"

    val albumProgress = (uniqueAlbumsCount.toFloat() / 20f).coerceIn(0f, 1f)
    val albumText = if (albumProgress >= 1.0f) "Đã hoàn thành" else "$uniqueAlbumsCount/20 album"

    val downloadProgress = (downloadedSongsCount.toFloat() / 50f).coerceIn(0f, 1f)
    val downloadText = if (downloadProgress >= 1.0f) "Đã hoàn thành" else "$downloadedSongsCount/50 bài hát"

    val eqProgress = if (isEqActive) 1.0f else 0.0f
    val eqText = if (isEqActive) "Đã hoàn thành" else "0/1 kích hoạt"

    val scope = rememberCoroutineScope()

    val isDark = MaterialTheme.colorScheme.surface.red < 0.5f
    val cardBg = if (isDark) MaterialTheme.colorScheme.surfaceContainerHigh else Color.White
    val screenBg = if (isDark) MaterialTheme.colorScheme.surfaceContainer else Color(0xFFF3F4F6)
    val iconBoxBg = if (isDark) MaterialTheme.colorScheme.surfaceContainerHighest else Color(0xFFE4E7EC)
    val iconTint = if (isDark) MaterialTheme.colorScheme.primary else Color(0xFF1F2937)

    Column(
        modifier = Modifier
            .background(screenBg)
            .padding(20.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Metrolist",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.weight(1f))
            IconButton(onClick = onClose) {
                Icon(
                    painter = painterResource(R.drawable.close),
                    contentDescription = "Close",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // 1. Profile Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    onClose()
                    navController.navigate("account")
                },
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = cardBg
            ),
            border = null
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Avatar
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(if (isDark) MaterialTheme.colorScheme.primaryContainer else Color(0xFFE5E7EB)),
                    contentAlignment = Alignment.Center
                ) {
                    if (isLoggedIn && accountImageUrl != null) {
                        AsyncImage(
                            model = accountImageUrl,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Icon(
                            painter = painterResource(R.drawable.person),
                            contentDescription = null,
                            tint = if (isDark) MaterialTheme.colorScheme.onPrimaryContainer else Color(0xFF6B7280),
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                // Name & Handle (2-layer layout)
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = if (isLoggedIn) {
                            if (accountName.isNotBlank()) accountName else stringResource(R.string.account_metrolist_user)
                        } else {
                            stringResource(R.string.account_guest_user)
                        },
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (isLoggedIn) {
                            when {
                                accountEmail.isNotBlank() -> accountEmail
                                accountChannelHandle.isNotBlank() -> accountChannelHandle
                                else -> stringResource(R.string.account_email_not_linked)
                            }
                        } else {
                            stringResource(R.string.account_email_not_linked)
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Logout/Login Button (Pill shaped OutlinedButton)
                if (isLoggedIn) {
                    OutlinedButton(
                        onClick = { showLogoutDialog = true },
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        ),
                        border = BorderStroke(1.dp, if (isDark) MaterialTheme.colorScheme.outline else Color(0xFFE5E7EB)),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.action_logout),
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            maxLines = 1
                        )
                    }
                } else {
                    OutlinedButton(
                        onClick = {
                            onClose()
                            navController.navigate("login")
                        },
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.primary
                        ),
                        border = BorderStroke(1.dp, if (isDark) MaterialTheme.colorScheme.outline else Color(0xFFE5E7EB)),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.login),
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // 2. Token Section
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    if (!isLoggedIn) showTokenEditor = true
                    else if (!showToken) showToken = true
                    else showTokenEditor = true
                },
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = cardBg
            ),
            border = null
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(iconBoxBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = painterResource(R.drawable.token),
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = when {
                            !isLoggedIn -> stringResource(R.string.advanced_login)
                            showToken -> stringResource(R.string.token_shown)
                            else -> stringResource(R.string.token_hidden)
                        },
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (isLoggedIn && showToken) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = innerTubeCookie.take(40) + "...",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        // 3. Quick Actions Grid (Downloads, History, Stats, Badges)
        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionCard(
                    modifier = Modifier.weight(1f),
                    iconId = R.drawable.download,
                    title = stringResource(R.string.downloaded_songs),
                    onClick = {
                        onClose()
                        navController.navigate("auto_playlist/downloaded")
                    }
                )
                QuickActionCard(
                    modifier = Modifier.weight(1f),
                    iconId = R.drawable.history,
                    title = stringResource(R.string.history),
                    onClick = {
                        onClose()
                        navController.navigate("history")
                    }
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionCard(
                    modifier = Modifier.weight(1f),
                    iconId = R.drawable.stats,
                    title = stringResource(R.string.stats),
                    onClick = {
                        onClose()
                        navController.navigate("stats")
                    }
                )
                QuickActionCard(
                    modifier = Modifier.weight(1f),
                    iconId = R.drawable.crown,
                    title = stringResource(R.string.badges),
                    onClick = {
                        showBadgesDialog = true
                    }
                )
            }
        }

        // 5. Navigation Rows sitting transparently on the background
        Column(
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            NavigationRowItem(
                iconId = R.drawable.settings,
                title = stringResource(R.string.settings),
                onClick = {
                    onClose()
                    navController.navigate("settings")
                }
            )
            if (isLoggedIn && !isDialog) {
                NavigationRowItem(
                    iconId = R.drawable.delete,
                    title = stringResource(R.string.delete_account_title),
                    iconTint = MaterialTheme.colorScheme.error,
                    onClick = {
                        showDeleteAccountDialog = true
                    }
                )
            }
        }
    }
        // Logout confirmation dialog
        if (showLogoutDialog) {
            DefaultDialog(
                onDismiss = { showLogoutDialog = false },
                title = { Text(stringResource(R.string.logout_no_data_title)) },
                content = {
                    Text(
                        text = stringResource(R.string.logout_no_data_message),
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(horizontal = 18.dp)
                    )
                },
                buttons = {
                    TextButton(
                        onClick = {
                            showLogoutDialog = false
                        }
                    ) {
                        Text(stringResource(android.R.string.cancel))
                    }
                    TextButton(
                        onClick = {
                            Timber.d("[LOGOUT_CLEAR] User chose to log out without keeping data")
                            scope.launch {
                                try {
                                    Timber.d("[LOGOUT_CLEAR] Starting clear and logout process")
                                    // Forget account first (stops all sync), then clear data.
                                    // This prevents background syncs from re-adding songs.
                                    accountSettingsViewModel.logoutAndClearLibraryData(context)
                                    Timber.d("[LOGOUT_CLEAR] Library data cleared and account forgotten")
                                } catch (e: Exception) {
                                    Timber.e(e, "[LOGOUT_CLEAR] Error clearing library data, proceeding with logout")
                                    reportException(e)
                                }
                                onInnerTubeCookieChange("")
                                onAccountProviderChange("none")
                                Timber.d("[LOGOUT_CLEAR] Logout complete")
                                showLogoutDialog = false
                                onClose()
                             }
                        }
                    ) {
                        Text(stringResource(R.string.logout_no_data_title))
                    }
                }
            )
        }

        // Delete account confirmation dialog
        if (showDeleteAccountDialog) {
            DefaultDialog(
                onDismiss = { showDeleteAccountDialog = false },
                title = { Text(stringResource(R.string.delete_account_title)) },
                content = {
                    Text(
                        text = stringResource(R.string.delete_account_message),
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(horizontal = 18.dp)
                    )
                },
                buttons = {
                    TextButton(
                        onClick = {
                            showDeleteAccountDialog = false
                        }
                    ) {
                        Text(stringResource(android.R.string.cancel))
                    }
                    TextButton(
                        onClick = {
                            Timber.d("[DELETE_ACCOUNT] User confirmed account deletion")
                            scope.launch {
                                try {
                                    Timber.d("[DELETE_ACCOUNT] Starting deletion and clear process")
                                    accountSettingsViewModel.logoutAndClearLibraryData(context)
                                    Timber.d("[DELETE_ACCOUNT] Library data cleared and account forgotten")
                                } catch (e: Exception) {
                                    Timber.e(e, "[DELETE_ACCOUNT] Error deleting account and library data")
                                    reportException(e)
                                }
                                onInnerTubeCookieChange("")
                                onAccountProviderChange("none")
                                onAccountNameChange("")
                                onAccountEmailChange("")
                                onAccountChannelHandleChange("")
                                onVisitorDataChange("")
                                onDataSyncIdChange("")
                                Timber.d("[DELETE_ACCOUNT] Account deletion complete")
                                showDeleteAccountDialog = false
                                onClose()
                             }
                        }
                    ) {
                        Text(
                            text = stringResource(R.string.delete_account_confirm),
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            )
        }

        if (showTokenEditor) {
            val text = """
                ***INNERTUBE COOKIE*** =$innerTubeCookie
                ***VISITOR DATA*** =$visitorData
                ***DATASYNC ID*** =$dataSyncId
                ***ACCOUNT NAME*** =$accountNamePref
                ***ACCOUNT EMAIL*** =$accountEmail
                ***ACCOUNT CHANNEL HANDLE*** =$accountChannelHandle
            """.trimIndent()

            TextFieldDialog(
                initialTextFieldValue = TextFieldValue(text),
                onDone = { data ->
                    var cookie = ""
                    var visitorDataValue = ""
                    var dataSyncIdValue = ""
                    var accountNameValue = ""
                    var accountEmailValue = ""
                    var accountChannelHandleValue = ""

                    data.split("\n").forEach {
                        when {
                            it.startsWith("***INNERTUBE COOKIE*** =") -> cookie = it.substringAfter("=")
                            it.startsWith("***VISITOR DATA*** =") -> visitorDataValue = it.substringAfter("=")
                            it.startsWith("***DATASYNC ID*** =") -> dataSyncIdValue = it.substringAfter("=")
                            it.startsWith("***ACCOUNT NAME*** =") -> accountNameValue = it.substringAfter("=")
                            it.startsWith("***ACCOUNT EMAIL*** =") -> accountEmailValue = it.substringAfter("=")
                            it.startsWith("***ACCOUNT CHANNEL HANDLE*** =") -> accountChannelHandleValue = it.substringAfter("=")
                        }
                    }
                    // Write all credentials atomically to DataStore and wait for completion
                    // before restarting, preventing the race condition where the process
                    // would be killed before async DataStore coroutines finished writing.
                    accountSettingsViewModel.saveTokenAndRestart(
                        context = context,
                        cookie = cookie,
                        visitorData = visitorDataValue,
                        dataSyncId = dataSyncIdValue,
                        accountName = accountNameValue,
                        accountEmail = accountEmailValue,
                        accountChannelHandle = accountChannelHandleValue,
                    )
                },
                onDismiss = { showTokenEditor = false },
                singleLine = false,
                maxLines = 20,
                isInputValid = { fullText ->
                    // Extract the cookie value from the formatted template line,
                    // then validate it separately — avoids the bug where parseCookieString
                    // received the entire multi-line template and failed to find "SAPISID"
                    // as a key because the "***INNERTUBE COOKIE*** =" prefix shadowed it.
                    val cookieLine = fullText.lines()
                        .find { it.startsWith("***INNERTUBE COOKIE*** =") }
                    val cookieValue = cookieLine?.substringAfter("***INNERTUBE COOKIE*** =")?.trim() ?: ""
                    cookieValue.isNotEmpty() && "SAPISID" in parseCookieString(cookieValue)
                },
                extraContent = {
                    Spacer(Modifier.height(8.dp))
                    InfoLabel(text = stringResource(R.string.token_adv_login_description))
                }
            )
        }

        if (showBadgesDialog) {
            com.metrolist.music.ui.screens.BadgesDialog(
                playTimeProgress = playTimeProgress,
                playTimeText = playTimeText,
                artistProgress = artistProgress,
                artistText = artistText,
                albumProgress = albumProgress,
                albumText = albumText,
                downloadProgress = downloadProgress,
                downloadText = downloadText,
                eqProgress = eqProgress,
                eqText = eqText,
                onDismiss = { showBadgesDialog = false }
            )
        }
    }

@Composable
private fun QuickActionCard(
    modifier: Modifier = Modifier,
    iconId: Int,
    title: String,
    onClick: () -> Unit
) {
    val isDark = MaterialTheme.colorScheme.surface.red < 0.5f
    val cardBg = if (isDark) MaterialTheme.colorScheme.surfaceContainerHigh else Color.White
    val iconBoxBg = if (isDark) MaterialTheme.colorScheme.surfaceContainerHighest else Color(0xFFF0F2F5)
    val iconTint = if (isDark) MaterialTheme.colorScheme.primary else Color(0xFF1F2937)

    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = cardBg
        ),
        border = null
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(iconBoxBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painter = painterResource(iconId),
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ToggleRowItem(
    iconId: Int,
    title: String,
    checked: Boolean,
    enabled: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val isDark = MaterialTheme.colorScheme.surface.red < 0.5f
    val cardBg = if (isDark) MaterialTheme.colorScheme.surfaceContainerHigh else Color.White
    val iconBoxBg = if (isDark) MaterialTheme.colorScheme.surfaceContainerHighest else Color(0xFFF0F2F5)
    val iconTint = if (isDark) MaterialTheme.colorScheme.primary else Color(0xFF1F2937)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = cardBg
        ),
        border = null
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(iconBoxBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painter = painterResource(iconId),
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                modifier = Modifier.weight(1f)
            )
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                enabled = enabled,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = if (isDark) MaterialTheme.colorScheme.onPrimary else Color.White,
                    checkedTrackColor = if (isDark) MaterialTheme.colorScheme.primary else Color(0xFF1F2937),
                    uncheckedThumbColor = if (isDark) MaterialTheme.colorScheme.outline else Color.White,
                    uncheckedTrackColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color(0xFFE5E7EB)
                ),
                thumbContent = {
                    if (checked) {
                        Icon(
                            painter = painterResource(id = R.drawable.check),
                            contentDescription = null,
                            modifier = Modifier.size(12.dp),
                            tint = if (isDark) MaterialTheme.colorScheme.primary else Color.Black
                        )
                    }
                }
            )
        }
    }
}

@Composable
private fun NavigationRowItem(
    iconId: Int,
    title: String,
    iconTint: Color = MaterialTheme.colorScheme.primary,
    onClick: () -> Unit
) {
    val isDark = MaterialTheme.colorScheme.surface.red < 0.5f
    val resolvedTint = if (iconTint == MaterialTheme.colorScheme.primary) {
        if (isDark) MaterialTheme.colorScheme.primary else Color(0xFF1F2937)
    } else {
        iconTint
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            painter = painterResource(iconId),
            contentDescription = null,
            tint = resolvedTint,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
            color = if (iconTint == MaterialTheme.colorScheme.error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
        Icon(
            painter = painterResource(R.drawable.navigate_next),
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
            modifier = Modifier.size(20.dp)
        )
    }
}
