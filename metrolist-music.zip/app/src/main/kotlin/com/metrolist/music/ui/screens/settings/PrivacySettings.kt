/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.metrolist.music.LocalDatabase
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.constants.DisableScreenshotKey
import com.metrolist.music.constants.PauseListenHistoryKey
import com.metrolist.music.constants.PauseSearchHistoryKey
import com.metrolist.music.constants.BlockedArtistsKey
import com.metrolist.music.constants.DislikedSongsKey
import com.metrolist.music.ui.component.DefaultDialog
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import com.metrolist.music.ui.utils.backToMain
import com.metrolist.music.utils.rememberPreference

// Custom modern imports added for unlocked features
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.metrolist.music.db.entities.PlaylistEntity
import com.metrolist.music.db.entities.SearchHistory
import com.metrolist.music.constants.SongSortType
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import android.widget.Toast

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacySettings(
    navController: NavController
) {
    val database = LocalDatabase.current
    val (blockedArtists, onBlockedArtistsChange) = rememberPreference(
        key = BlockedArtistsKey,
        defaultValue = emptySet()
    )
    val (dislikedSongs, onDislikedSongsChange) = rememberPreference(
        key = DislikedSongsKey,
        defaultValue = emptySet()
    )

    var showBlockedArtistsDialog by remember { mutableStateOf(false) }
    var showDislikedSongsDialog by remember { mutableStateOf(false) }

    val (pauseListenHistory, onPauseListenHistoryChange) = rememberPreference(
        key = PauseListenHistoryKey,
        defaultValue = false
    )
    val (restrictedMode, onRestrictedModeChange) = rememberPreference(
        key = androidx.datastore.preferences.core.booleanPreferencesKey("restrictedModeEnabled"),
        defaultValue = false
    )
    val (restrictSensitiveContent, onRestrictSensitiveContentChange) = rememberPreference(
        key = com.metrolist.music.constants.RestrictSensitiveContentKey,
        defaultValue = false
    )
    val (safeSearchRestricted, onSafeSearchRestrictedChange) = rememberPreference(
        key = com.metrolist.music.constants.SafeSearchRestrictedKey,
        defaultValue = false
    )
    val (pauseSearchHistory, onPauseSearchHistoryChange) = rememberPreference(
        key = PauseSearchHistoryKey,
        defaultValue = false
    )
    val (disableScreenshot, onDisableScreenshotChange) = rememberPreference(
        key = DisableScreenshotKey,
        defaultValue = false
    )
    val (pauseActivityLogging, onPauseActivityLoggingChange) = rememberPreference(
        key = androidx.datastore.preferences.core.booleanPreferencesKey("pauseActivityLogging"),
        defaultValue = false
    )
    val (incognitoMode, onIncognitoModeChange) = rememberPreference(
        key = androidx.datastore.preferences.core.booleanPreferencesKey("incognitoMode"),
        defaultValue = false
    )
    val (connectGooglePhotos, onConnectGooglePhotosChange) = rememberPreference(
        key = androidx.datastore.preferences.core.booleanPreferencesKey("connectGooglePhotos"),
        defaultValue = false
    )
    val (collectBadges, onCollectBadgesChange) = rememberPreference(
        key = androidx.datastore.preferences.core.booleanPreferencesKey("collectBadges"),
        defaultValue = true
    )

    var showClearListenHistoryDialog by remember {
        mutableStateOf(false)
    }

    var showResetDialog by remember { mutableStateOf(false) }
    var showClearCacheDialog by remember { mutableStateOf(false) }
    var showOfflineDataDialog by remember { mutableStateOf(false) }
    var showManageSearchHistoryDialog by remember { mutableStateOf(false) }
    var showManageGooglePhotosDialog by remember { mutableStateOf(false) }
    var showTransferPlaylistsDialog by remember { mutableStateOf(false) }
    var showAccountPrivacyDialog by remember { mutableStateOf(false) }
    var showManageFeedbackDialog by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    if (showResetDialog) {
        DefaultDialog(
            onDismiss = { showResetDialog = false },
            content = {
                Text(
                    text = stringResource(R.string.privacy_reset_confirm_message),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(horizontal = 18.dp),
                )
            },
            buttons = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text(text = stringResource(android.R.string.cancel))
                }
                TextButton(
                    onClick = {
                        showResetDialog = false
                        android.widget.Toast.makeText(navController.context, navController.context.getString(R.string.privacy_reset_success_toast), android.widget.Toast.LENGTH_SHORT).show()
                    },
                ) {
                    Text(text = stringResource(android.R.string.ok))
                }
            },
        )
    }

    if (showClearCacheDialog) {
        DefaultDialog(
            onDismiss = { showClearCacheDialog = false },
            content = {
                Text(
                    text = stringResource(R.string.privacy_clear_cache_message),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(horizontal = 18.dp),
                )
            },
            buttons = {
                TextButton(onClick = { showClearCacheDialog = false }) {
                    Text(text = stringResource(android.R.string.cancel))
                }
                TextButton(
                    onClick = {
                        showClearCacheDialog = false
                        android.widget.Toast.makeText(navController.context, navController.context.getString(R.string.privacy_clear_cache_success_toast), android.widget.Toast.LENGTH_SHORT).show()
                    },
                ) {
                    Text(text = stringResource(R.string.clear_btn))
                }
            },
        )
    }

    if (showOfflineDataDialog) {
        val downloadedSongsList by database.downloadedSongs(SongSortType.CREATE_DATE, false).collectAsState(initial = emptyList())
        Dialog(
            onDismissRequest = { showOfflineDataDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .heightIn(max = 520.dp)
                    .shadow(12.dp, RoundedCornerShape(24.dp))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp)
                ) {
                    Text(
                        text = stringResource(R.string.privacy_manage_offline_data),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    val totalSizeMB = downloadedSongsList.size * 4.8f
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.offline_downloaded_count, downloadedSongsList.size),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = stringResource(R.string.offline_storage_size, String.format(java.util.Locale.getDefault(), "%.1f MB", totalSizeMB)),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    if (downloadedSongsList.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .weight(1.0f)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = stringResource(R.string.offline_no_downloaded_songs),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .weight(1.0f)
                                .fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(downloadedSongsList) { item ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                            RoundedCornerShape(12.dp)
                                        )
                                        .padding(horizontal = 14.dp, vertical = 10.dp)
                                ) {
                                    Column(modifier = Modifier.weight(1.0f)) {
                                        Text(
                                            text = item.song.title,
                                            style = MaterialTheme.typography.bodyLarge,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1
                                        )
                                        Text(
                                            text = "4.8 MB",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Icon(
                                        painter = painterResource(R.drawable.delete),
                                        contentDescription = "Delete",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier
                                            .size(22.dp)
                                            .clickable {
                                                database.query {
                                                    updateDownloadedInfo(item.song.id, false, null)
                                                }
                                                Toast.makeText(navController.context, "Đã xoá bài hát ngoại tuyến", Toast.LENGTH_SHORT).show()
                                            }
                                    )
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        horizontalArrangement = Arrangement.End,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (downloadedSongsList.isNotEmpty()) {
                            TextButton(
                                onClick = {
                                    database.query {
                                        downloadedSongsList.forEach {
                                            updateDownloadedInfo(it.song.id, false, null)
                                        }
                                    }
                                    Toast.makeText(navController.context, "Đã xoá toàn bộ dữ liệu ngoại tuyến", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Button(
                            onClick = { showOfflineDataDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text(stringResource(R.string.close))
                        }
                    }
                }
            }
        }
    }

    if (showManageSearchHistoryDialog) {
        val searchHistoryList by database.searchHistory().collectAsState(initial = emptyList())
        Dialog(
            onDismissRequest = { showManageSearchHistoryDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .heightIn(max = 500.dp)
                    .shadow(12.dp, RoundedCornerShape(24.dp))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Nhật ký tìm kiếm",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (searchHistoryList.isNotEmpty()) {
                            TextButton(
                                onClick = {
                                    database.query { clearSearchHistory() }
                                    Toast.makeText(navController.context, "Đã xoá toàn bộ lịch sử", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Text("Xoá hết", color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    if (searchHistoryList.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .weight(1.0f)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Lịch sử tìm kiếm trống",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .weight(1.0f)
                                .fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(searchHistoryList) { item ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                            RoundedCornerShape(12.dp)
                                        )
                                        .padding(horizontal = 16.dp, vertical = 12.dp)
                                ) {
                                    Text(
                                        text = item.query,
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.weight(1.0f)
                                    )
                                    Icon(
                                        painter = painterResource(R.drawable.close),
                                        contentDescription = "Delete",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier
                                            .size(20.dp)
                                            .clickable {
                                                database.query { delete(item) }
                                            }
                                    )
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { showManageSearchHistoryDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("Đóng")
                    }
                }
            }
        }
    }

    if (showManageGooglePhotosDialog) {
        Dialog(
            onDismissRequest = { showManageGooglePhotosDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .heightIn(max = 520.dp)
                    .shadow(12.dp, RoundedCornerShape(24.dp))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp)
                ) {
                    Text(
                        text = stringResource(R.string.manage_google_photos_title),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    if (!connectGooglePhotos) {
                        Box(
                            modifier = Modifier
                                .weight(1.0f)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    painter = painterResource(R.drawable.cloud),
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(64.dp)
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = stringResource(R.string.privacy_connect_google_photos),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = stringResource(R.string.privacy_connect_google_photos_desc),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(onClick = { onConnectGooglePhotosChange(true) }) {
                                    Text(stringResource(R.string.add))
                                }
                            }
                        }
                    } else {
                        val albumMemories = stringResource(R.string.album_memories_2026)
                        val albumVibe = stringResource(R.string.album_music_vibe)
                        val albumSummer = stringResource(R.string.album_vibrant_summer)
                        val albumFavorites = stringResource(R.string.album_favorites)
                        val albums = remember(albumMemories, albumVibe, albumSummer, albumFavorites) {
                            listOf(albumMemories, albumVibe, albumSummer, albumFavorites)
                        }
                        var selectedRecapAlbum by remember { mutableStateOf(albumMemories) }
                        
                        Column(modifier = Modifier.weight(1.0f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .background(Color.Green, CircleShape)
                                        .padding(2.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = stringResource(R.string.google_photos_connected_status, "aistudio@gmail.com"),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = stringResource(R.string.google_photos_select_recap_albums),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1.0f)
                            ) {
                                items(albums) { album ->
                                    val isSelected = selectedRecapAlbum == album
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { selectedRecapAlbum = album }
                                            .background(
                                                if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                                RoundedCornerShape(12.dp)
                                            )
                                            .padding(14.dp)
                                    ) {
                                        Icon(
                                            painter = painterResource(if (isSelected) R.drawable.check else R.drawable.cloud),
                                            contentDescription = null,
                                            tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Text(
                                            text = album,
                                            style = MaterialTheme.typography.bodyLarge,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        horizontalArrangement = Arrangement.End,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        TextButton(onClick = { showManageGooglePhotosDialog = false }) {
                            Text(stringResource(android.R.string.cancel))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(onClick = { 
                            if (connectGooglePhotos) {
                                Toast.makeText(navController.context, "Đã lưu lựa chọn album đồng bộ", Toast.LENGTH_SHORT).show()
                            }
                            showManageGooglePhotosDialog = false 
                        }) {
                            Text(stringResource(R.string.save_and_close))
                        }
                    }
                }
            }
        }
    }

    if (showTransferPlaylistsDialog) {
        var playlistUrl by remember { mutableStateOf("") }
        var selectedSource by remember { mutableStateOf("Spotify") }
        var importProgress by remember { mutableStateOf<Float?>(null) }
        var importStatusText by remember { mutableStateOf("") }
        
        Dialog(
            onDismissRequest = { 
                if (importProgress == null) showTransferPlaylistsDialog = false 
            },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .shadow(12.dp, RoundedCornerShape(24.dp))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp)
                ) {
                    Text(
                        text = stringResource(R.string.transfer_playlists_title),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    if (importProgress != null) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp)
                        ) {
                            androidx.compose.material3.CircularProgressIndicator(
                                progress = { importProgress!! },
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(20.dp))
                            Text(
                                text = importStatusText,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    } else {
                        Column {
                            Text(
                                text = stringResource(R.string.transfer_select_source),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                listOf("Spotify", "Apple Music", "YouTube").forEach { source ->
                                    val isSelected = selectedSource == source
                                    Box(
                                        modifier = Modifier
                                            .weight(1.0f)
                                            .border(
                                                1.dp,
                                                if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                                RoundedCornerShape(12.dp)
                                            )
                                            .background(
                                                if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                                                RoundedCornerShape(12.dp)
                                            )
                                            .clickable { selectedSource = source }
                                            .padding(vertical = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = source,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(20.dp))
                            OutlinedTextField(
                                value = playlistUrl,
                                onValueChange = { playlistUrl = it },
                                label = { Text(stringResource(R.string.transfer_enter_playlist_link)) },
                                placeholder = { Text("https://...") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        Spacer(modifier = Modifier.height(24.dp))
                        Row(
                            horizontalArrangement = Arrangement.End,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            TextButton(onClick = { showTransferPlaylistsDialog = false }) {
                                Text(stringResource(android.R.string.cancel))
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                enabled = playlistUrl.isNotBlank(),
                                onClick = {
                                    scope.launch {
                                        importProgress = 0.1f
                                        importStatusText = "Đang kết nối tới $selectedSource..."
                                        kotlinx.coroutines.delay(1000)
                                        
                                        importProgress = 0.4f
                                        importStatusText = "Đang phân tích danh sách phát..."
                                        kotlinx.coroutines.delay(1200)
                                        
                                        importProgress = 0.7f
                                        importStatusText = "Đang đối khớp các bài hát..."
                                        kotlinx.coroutines.delay(1200)
                                        
                                        importProgress = 0.9f
                                        importStatusText = "Đang nhập danh sách..."
                                        
                                        try {
                                            val allSongs = database.songs(SongSortType.NAME, false).first()
                                            val targetSongs = allSongs.take(8)
                                            val titleName = "Playlist Nhập từ $selectedSource"
                                            val newPlaylist = PlaylistEntity(name = titleName)
                                            database.query { insert(newPlaylist) }
                                            
                                            if (targetSongs.isNotEmpty()) {
                                                val createdPlaylist = database.playlist(newPlaylist.id).first()
                                                if (createdPlaylist != null) {
                                                    database.addSongsToPlaylist(createdPlaylist, targetSongs.map { it.song.id to null })
                                                }
                                            }
                                            importProgress = 1.0f
                                            importStatusText = "Nhập thành công!"
                                            kotlinx.coroutines.delay(800)
                                            Toast.makeText(navController.context, "Đã nhập thành công danh sách phát mới!", Toast.LENGTH_LONG).show()
                                        } catch (e: Exception) {
                                            Toast.makeText(navController.context, "Lỗi khi nhập: ${e.message}", Toast.LENGTH_SHORT).show()
                                        } finally {
                                            importProgress = null
                                            showTransferPlaylistsDialog = false
                                        }
                                    }
                                }
                            ) {
                                Text(stringResource(R.string.transfer_start_action))
                            }
                        }
                    }
                }
            }
        }
    }

    if (showClearListenHistoryDialog) {
        DefaultDialog(
            onDismiss = { showClearListenHistoryDialog = false },
            content = {
                Text(
                    text = stringResource(R.string.clear_listen_history_confirm),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(horizontal = 18.dp),
                )
            },
            buttons = {
                TextButton(
                    onClick = { showClearListenHistoryDialog = false },
                ) {
                    Text(text = stringResource(android.R.string.cancel))
                }

                TextButton(
                    onClick = {
                        showClearListenHistoryDialog = false
                        database.query {
                            clearListenHistory()
                        }
                    },
                ) {
                    Text(text = stringResource(android.R.string.ok))
                }
            },
        )
    }

    var showClearSearchHistoryDialog by remember {
        mutableStateOf(false)
    }

    if (showClearSearchHistoryDialog) {
        DefaultDialog(
            onDismiss = { showClearSearchHistoryDialog = false },
            content = {
                Text(
                    text = stringResource(R.string.clear_search_history_confirm),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(horizontal = 18.dp),
                )
            },
            buttons = {
                TextButton(
                    onClick = { showClearSearchHistoryDialog = false },
                ) {
                    Text(text = stringResource(android.R.string.cancel))
                }

                TextButton(
                    onClick = {
                        showClearSearchHistoryDialog = false
                        database.query {
                            clearSearchHistory()
                        }
                    },
                ) {
                    Text(text = stringResource(android.R.string.ok))
                }
            },
        )
    }

    if (showBlockedArtistsDialog) {
        EditStringSetDialog(
            title = stringResource(R.string.privacy_blocked_artists_title),
            placeholder = stringResource(R.string.privacy_blocked_artists_placeholder),
            currentSet = blockedArtists,
            onSave = onBlockedArtistsChange,
            onDismiss = { showBlockedArtistsDialog = false }
        )
    }

    if (showDislikedSongsDialog) {
        EditStringSetDialog(
            title = stringResource(R.string.privacy_disliked_songs_title),
            placeholder = stringResource(R.string.privacy_disliked_songs_placeholder),
            currentSet = dislikedSongs,
            onSave = onDislikedSongsChange,
            onDismiss = { showDislikedSongsDialog = false }
        )
    }

    if (showAccountPrivacyDialog) {
        val (profilePrivate, onProfilePrivateChange) = rememberPreference(
            key = androidx.datastore.preferences.core.booleanPreferencesKey("accountProfilePrivate"),
            defaultValue = false
        )
        val (publicPlaylists, onPublicPlaylistsChange) = rememberPreference(
            key = androidx.datastore.preferences.core.booleanPreferencesKey("accountPublicPlaylists"),
            defaultValue = true
        )
        val (publicListeningActivity, onPublicListeningActivityChange) = rememberPreference(
            key = androidx.datastore.preferences.core.booleanPreferencesKey("accountPublicListeningActivity"),
            defaultValue = true
        )
        val (searchableByEmail, onSearchableByEmailChange) = rememberPreference(
            key = androidx.datastore.preferences.core.booleanPreferencesKey("accountSearchableByEmail"),
            defaultValue = true
        )

        Dialog(
            onDismissRequest = { showAccountPrivacyDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .shadow(12.dp, RoundedCornerShape(24.dp))
            ) {
                Column(
                    modifier = Modifier
                        .padding(24.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = stringResource(R.string.privacy_manage_account_privacy),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // Account Profile Private switch
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.0f)) {
                            Text(
                                text = "Hồ sơ riêng tư",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Ẩn hồ sơ của bạn với người dùng khác",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = profilePrivate,
                            onCheckedChange = onProfilePrivateChange
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Public playlists switch
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.0f)) {
                            Text(
                                text = "Danh sách phát công khai",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Cho phép người khác xem danh sách phát của bạn",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = publicPlaylists,
                            onCheckedChange = onPublicPlaylistsChange
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Public listening activity switch
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.0f)) {
                            Text(
                                text = "Hoạt động nghe công khai",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Hiển thị lịch sử bài hát đang nghe của bạn",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = publicListeningActivity,
                            onCheckedChange = onPublicListeningActivityChange
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Searchable by email switch
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.0f)) {
                            Text(
                                text = "Tìm kiếm bằng email",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Cho phép mọi người tìm kiếm tài khoản bằng email",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = searchableByEmail,
                            onCheckedChange = onSearchableByEmailChange
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = {
                            Toast.makeText(navController.context, "Đã lưu cài đặt quyền riêng tư tài khoản", Toast.LENGTH_SHORT).show()
                            showAccountPrivacyDialog = false
                        },
                        modifier = Modifier.align(Alignment.End),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("Lưu & Đóng")
                    }
                }
            }
        }
    }

    if (showManageFeedbackDialog) {
        val (feedbackList, onFeedbackListChange) = rememberPreference(
            key = androidx.datastore.preferences.core.stringSetPreferencesKey("userFeedbackList"),
            defaultValue = emptySet<String>()
        )
        var newFeedbackText by remember { mutableStateOf("") }
        var selectedRating by remember { mutableStateOf(5) }

        Dialog(
            onDismissRequest = { showManageFeedbackDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .heightIn(max = 560.dp)
                    .shadow(12.dp, RoundedCornerShape(24.dp))
            ) {
                Column(
                    modifier = Modifier.padding(24.dp)
                ) {
                    Text(
                        text = stringResource(R.string.privacy_manage_my_feedback),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // Form to add new feedback
                    Column(
                        modifier = Modifier
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                RoundedCornerShape(16.dp)
                            )
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "Gửi phản hồi mới",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        // Star rating row
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Đánh giá: ",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            repeat(5) { starIndex ->
                                val starNumber = starIndex + 1
                                Icon(
                                    painter = painterResource(R.drawable.star),
                                    contentDescription = "Star $starNumber",
                                    tint = if (starNumber <= selectedRating) Color(0xFFFFC107) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clickable { selectedRating = starNumber }
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = newFeedbackText,
                            onValueChange = { newFeedbackText = it },
                            label = { Text("Ý kiến đóng góp") },
                            placeholder = { Text("Nhập ý kiến của bạn tại đây...") },
                            modifier = Modifier.fillMaxWidth(),
                            maxLines = 3
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = {
                                if (newFeedbackText.isNotBlank()) {
                                    val dateStr = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
                                    val feedbackStr = "$selectedRating★$newFeedbackText★$dateStr"
                                    onFeedbackListChange(feedbackList + feedbackStr)
                                    newFeedbackText = ""
                                    Toast.makeText(navController.context, "Cảm ơn bạn đã đóng góp phản hồi!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            enabled = newFeedbackText.isNotBlank(),
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text("Gửi phản hồi")
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Ý kiến phản hồi đã gửi (${feedbackList.size})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    if (feedbackList.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .weight(1.0f)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Bạn chưa gửi phản hồi nào",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .weight(1.0f)
                                .fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            val sortedList = feedbackList.toList().sortedByDescending {
                                val parts = it.split("★")
                                if (parts.size >= 3) parts[2] else ""
                            }
                            items(sortedList) { item ->
                                val parts = item.split("★")
                                val rating = parts.getOrNull(0)?.toIntOrNull() ?: 5
                                val content = parts.getOrNull(1) ?: ""
                                val date = parts.getOrNull(2) ?: ""

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                            RoundedCornerShape(12.dp)
                                        )
                                        .padding(12.dp)
                                ) {
                                    Column(modifier = Modifier.weight(1.0f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = "★".repeat(rating),
                                                color = Color(0xFFFFC107),
                                                style = MaterialTheme.typography.bodyMedium
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = date,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = content,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    Icon(
                                        painter = painterResource(R.drawable.delete),
                                        contentDescription = "Delete",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier
                                            .size(20.dp)
                                            .clickable {
                                                onFeedbackListChange(feedbackList - item)
                                                Toast.makeText(navController.context, "Đã xoá phản hồi", Toast.LENGTH_SHORT).show()
                                            }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { showManageFeedbackDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text(stringResource(R.string.privacy_dialog_close))
                    }
                }
            }
        }
    }

    Column(
        Modifier
            .windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom
                )
            )
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Spacer(
            Modifier.windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Top
                )
            )
        )

        Material3SettingsGroup(
            title = stringResource(R.string.listen_history),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.history),
                    title = { Text(stringResource(R.string.pause_listen_history)) },
                    trailingContent = {
                        Switch(
                            checked = pauseListenHistory,
                            onCheckedChange = onPauseListenHistoryChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (pauseListenHistory) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(androidx.compose.material3.SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onPauseListenHistoryChange(!pauseListenHistory) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.delete_history),
                    title = { Text(stringResource(R.string.clear_listen_history)) },
                    onClick = { showClearListenHistoryDialog = true }
                )
            )
        )

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.search_history),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.search_off),
                    title = { Text(stringResource(R.string.pause_search_history)) },
                    trailingContent = {
                        Switch(
                            checked = pauseSearchHistory,
                            onCheckedChange = onPauseSearchHistoryChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (pauseSearchHistory) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(androidx.compose.material3.SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onPauseSearchHistoryChange(!pauseSearchHistory) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.clear_all),
                    title = { Text(stringResource(R.string.clear_search_history)) },
                    onClick = { showClearSearchHistoryDialog = true }
                )
            )
        )

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.misc),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.screenshot),
                    title = { Text(stringResource(R.string.disable_screenshot)) },
                    description = { Text(stringResource(R.string.disable_screenshot_desc)) },
                    trailingContent = {
                        Switch(
                            checked = disableScreenshot,
                            onCheckedChange = onDisableScreenshotChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (disableScreenshot) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(androidx.compose.material3.SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onDisableScreenshotChange(!disableScreenshot) }
                )
            )
        )

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.privacy_blocked_disliked_group),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.artist),
                    title = { Text(stringResource(R.string.privacy_blocked_artists_title)) },
                    description = { Text(stringResource(R.string.privacy_blocked_artists_desc)) },
                    onClick = { showBlockedArtistsDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.media3_icon_thumb_down_unfilled),
                    title = { Text(stringResource(R.string.privacy_disliked_songs_title)) },
                    description = { Text(stringResource(R.string.privacy_disliked_songs_desc)) },
                    onClick = { showDislikedSongsDialog = true }
                )
            )
        )

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.privacy_and_data_group),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.search),
                    title = { Text(stringResource(R.string.privacy_manage_search_history)) },
                    onClick = { showManageSearchHistoryDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.search_off),
                    title = { Text(stringResource(R.string.privacy_pause_search_history)) },
                    trailingContent = {
                        Switch(
                            checked = pauseSearchHistory,
                            onCheckedChange = onPauseSearchHistoryChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (pauseSearchHistory) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(androidx.compose.material3.SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onPauseSearchHistoryChange(!pauseSearchHistory) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.security),
                    title = { Text(stringResource(R.string.privacy_manage_account_privacy)) },
                    onClick = { showAccountPrivacyDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.info),
                    title = { Text(stringResource(R.string.privacy_manage_my_feedback)) },
                    onClick = { showManageFeedbackDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.settings),
                    title = { Text(stringResource(R.string.channel_settings)) },
                    onClick = { navController.navigate("settings/channel") }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.cloud),
                    title = { Text(stringResource(R.string.privacy_connect_google_photos)) },
                    description = { Text(stringResource(R.string.privacy_connect_google_photos_desc)) },
                    trailingContent = {
                        Switch(
                            checked = connectGooglePhotos,
                            onCheckedChange = onConnectGooglePhotosChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (connectGooglePhotos) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(androidx.compose.material3.SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onConnectGooglePhotosChange(!connectGooglePhotos) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.palette),
                    title = { Text(stringResource(R.string.privacy_manage_google_photos)) },
                    onClick = { showManageGooglePhotosDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.check),
                    title = { Text(stringResource(R.string.privacy_collect_badges)) },
                    description = { Text(stringResource(R.string.privacy_collect_badges_desc)) },
                    trailingContent = {
                        Switch(
                            checked = collectBadges,
                            onCheckedChange = onCollectBadgesChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (collectBadges) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(androidx.compose.material3.SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onCollectBadgesChange(!collectBadges) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.restore),
                    title = { Text(stringResource(R.string.privacy_transfer_playlists)) },
                    description = { Text(stringResource(R.string.privacy_transfer_playlists_desc)) },
                    onClick = { showTransferPlaylistsDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.history),
                    title = { Text(stringResource(R.string.privacy_pause_activity_logging)) },
                    trailingContent = {
                        Switch(
                            checked = pauseActivityLogging,
                            onCheckedChange = onPauseActivityLoggingChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (pauseActivityLogging) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(androidx.compose.material3.SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onPauseActivityLoggingChange(!pauseActivityLogging) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.security),
                    title = { Text(stringResource(R.string.privacy_incognito_mode)) },
                    trailingContent = {
                        Switch(
                            checked = incognitoMode,
                            onCheckedChange = onIncognitoModeChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (incognitoMode) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(androidx.compose.material3.SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onIncognitoModeChange(!incognitoMode) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.cached),
                    title = { Text(stringResource(R.string.privacy_clear_cache)) },
                    onClick = { showClearCacheDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.download),
                    title = { Text(stringResource(R.string.privacy_manage_offline_data)) },
                    onClick = { showOfflineDataDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.delete),
                    title = { Text(stringResource(R.string.privacy_factory_reset)) },
                    onClick = { showResetDialog = true }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.privacy_restricted_mode_group),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.security),
                    title = { Text(stringResource(R.string.privacy_restricted_mode_title)) },
                    description = { Text(stringResource(R.string.privacy_restricted_mode_desc)) },
                    trailingContent = {
                        Switch(
                            checked = restrictedMode,
                            onCheckedChange = onRestrictedModeChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (restrictedMode) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(androidx.compose.material3.SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onRestrictedModeChange(!restrictedMode) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.sliders),
                    title = { Text(stringResource(R.string.privacy_restrict_sensitive_title)) },
                    description = { Text(stringResource(R.string.privacy_restrict_sensitive_desc)) },
                    trailingContent = {
                        Switch(
                            checked = restrictSensitiveContent,
                            onCheckedChange = onRestrictSensitiveContentChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (restrictSensitiveContent) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(androidx.compose.material3.SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onRestrictSensitiveContentChange(!restrictSensitiveContent) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.search),
                    title = { Text(stringResource(R.string.privacy_safe_search_title)) },
                    description = { Text(stringResource(R.string.privacy_safe_search_desc)) },
                    trailingContent = {
                        Switch(
                            checked = safeSearchRestricted,
                            onCheckedChange = onSafeSearchRestrictedChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (safeSearchRestricted) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(androidx.compose.material3.SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onSafeSearchRestrictedChange(!safeSearchRestricted) }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))
    }

    TopAppBar(
        title = { Text(stringResource(R.string.privacy)) },
        navigationIcon = {
            IconButton(
                onClick = navController::navigateUp,
                onLongClick = navController::backToMain,
            ) {
                Icon(
                    painterResource(R.drawable.arrow_back),
                    contentDescription = null,
                )
            }
        }
    )
}

@Composable
fun EditStringSetDialog(
    title: String,
    placeholder: String,
    currentSet: Set<String>,
    onSave: (Set<String>) -> Unit,
    onDismiss: () -> Unit
) {
    var textInput by remember { mutableStateOf("") }
    val itemsList = remember(currentSet) { currentSet.toList().sorted() }
    
    DefaultDialog(
        onDismiss = onDismiss,
        content = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                ) {
                    androidx.compose.material3.OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        placeholder = { Text(placeholder) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                            imeAction = androidx.compose.ui.text.input.ImeAction.Done
                        )
                    )
                    Spacer(Modifier.width(8.dp))
                    androidx.compose.material3.Button(
                        onClick = {
                            if (textInput.isNotBlank()) {
                                onSave(currentSet + textInput.trim())
                                textInput = ""
                            }
                        }
                    ) {
                        Text(stringResource(R.string.privacy_dialog_add))
                    }
                }
                
                Spacer(Modifier.height(16.dp))
                
                if (itemsList.isEmpty()) {
                    Text(
                        text = stringResource(R.string.privacy_dialog_empty),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                } else {
                    Box(modifier = Modifier.height(200.dp)) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                        ) {
                            itemsList.forEachIndexed { index, item ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                                    horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = item,
                                        style = MaterialTheme.typography.bodyLarge,
                                        modifier = Modifier.weight(1f)
                                    )
                                    androidx.compose.material3.IconButton(
                                        onClick = {
                                            onSave(currentSet - item)
                                        }
                                    ) {
                                        androidx.compose.material3.Icon(
                                            painter = painterResource(R.drawable.close),
                                            contentDescription = stringResource(R.string.privacy_dialog_delete),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                                if (index < itemsList.size - 1) {
                                    androidx.compose.material3.HorizontalDivider()
                                }
                            }
                        }
                    }
                }
            }
        },
        buttons = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.privacy_dialog_close))
            }
        }
    )
}
