/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.models

import androidx.annotation.StringRes
import com.metrolist.music.R
import com.metrolist.music.db.entities.Song

enum class TagCategory(val label: String, @StringRes val stringRes: Int) {
    ALL("All", R.string.tag_category_all),
    GENRE("Genres", R.string.tag_category_genres),
    MOOD("Moods", R.string.tag_category_moods)
}

data class LibraryTag(
    val id: String,
    val name: String,
    val category: TagCategory,
    val keywords: List<String>
) {
    fun matchesSong(song: Song): Boolean {
        val titleLower = song.song.title.lowercase()
        val albumLower = song.album?.title?.lowercase() ?: ""
        val artistsLower = song.artists.joinToString(" ") { it.name.lowercase() }
        val fullText = "$titleLower $albumLower $artistsLower"

        if (keywords.any { fullText.contains(it) }) {
            return true
        }

        val hash = (song.id.hashCode() and 0x7FFFFFFF)
        val fallbackGenreIndex = hash % ALL_GENRES.size
        val fallbackMoodIndex = (hash / 3) % ALL_MOODS.size

        return (category == TagCategory.GENRE && ALL_GENRES[fallbackGenreIndex].id == id) ||
               (category == TagCategory.MOOD && ALL_MOODS[fallbackMoodIndex].id == id)
    }

    companion object {
        val ALL_GENRES = listOf(
            LibraryTag("pop", "Pop", TagCategory.GENRE, listOf("pop", "dance", "synth", "chart", "hits")),
            LibraryTag("rock", "Rock", TagCategory.GENRE, listOf("rock", "alt", "alternative", "band", "guitar", "punk", "metal", "heavy")),
            LibraryTag("hiphop", "Hip-Hop", TagCategory.GENRE, listOf("hip hop", "hip-hop", "rap", "trap", "beat")),
            LibraryTag("rnb", "R&B", TagCategory.GENRE, listOf("r&b", "rnb", "soul", "funk", "groove")),
            LibraryTag("electronic", "Electronic", TagCategory.GENRE, listOf("electronic", "edm", "house", "techno", "dubstep", "trance", "synthwave")),
            LibraryTag("jazz", "Jazz", TagCategory.GENRE, listOf("jazz", "blues", "swing", "sax", "trumpet")),
            LibraryTag("classical", "Classical", TagCategory.GENRE, listOf("classical", "orchestra", "symphony", "piano", "violin")),
            LibraryTag("acoustic", "Acoustic", TagCategory.GENRE, listOf("acoustic", "unplugged", "folk", "ukulele")),
            LibraryTag("lofi", "Lo-Fi", TagCategory.GENRE, listOf("lo-fi", "lofi", "chillhop", "study")),
            LibraryTag("kpop", "K-Pop", TagCategory.GENRE, listOf("k-pop", "kpop", "korean")),
            LibraryTag("indie", "Indie", TagCategory.GENRE, listOf("indie", "bedroom", "underground"))
        )

        val ALL_MOODS = listOf(
            LibraryTag("chill", "Chill", TagCategory.MOOD, listOf("chill", "relax", "mellow", "calm", "lo-fi", "lofi", "ambient", "soft", "slow", "quiet")),
            LibraryTag("energetic", "Energetic", TagCategory.MOOD, listOf("energy", "energetic", "hyper", "power", "upbeat", "fast", "hype", "boost")),
            LibraryTag("focus", "Focus", TagCategory.MOOD, listOf("focus", "study", "work", "instrumental", "concentration", "deep", "mind")),
            LibraryTag("workout", "Workout", TagCategory.MOOD, listOf("workout", "gym", "run", "cardio", "fitness", "motivation", "beast", "pump")),
            LibraryTag("party", "Party", TagCategory.MOOD, listOf("party", "club", "dance", "dj", "festival", "night", "disco")),
            LibraryTag("romance", "Romance", TagCategory.MOOD, listOf("love", "romantic", "romance", "heart", "sweet", "valentine", "baby")),
            LibraryTag("sad", "Sad", TagCategory.MOOD, listOf("sad", "melancholy", "cry", "lonely", "tear", "broken", "rain", "hurt")),
            LibraryTag("feel_good", "Feel Good", TagCategory.MOOD, listOf("happy", "feel good", "smile", "sunshine", "summer", "joy", "fun", "good")),
            LibraryTag("sleep", "Sleep", TagCategory.MOOD, listOf("sleep", "bedtime", "night", "lullaby", "dream", "rain", "rest"))
        )

        val ALL_TAGS = ALL_MOODS + ALL_GENRES
    }
}
