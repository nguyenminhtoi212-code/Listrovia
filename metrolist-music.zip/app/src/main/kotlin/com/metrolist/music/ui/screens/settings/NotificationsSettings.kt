/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.screens.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.ui.component.IconButton
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import com.metrolist.music.ui.utils.backToMain
import com.metrolist.music.utils.rememberPreference
import androidx.datastore.preferences.core.booleanPreferencesKey

val PushNotificationKey = booleanPreferencesKey("pushNotification")
val NewSongNotificationKey = booleanPreferencesKey("newSongNotification")
val SubscribedChannelNotificationKey = booleanPreferencesKey("subscribedChannelNotification")
val ChannelActivityNotificationKey = booleanPreferencesKey("channelActivityNotification")
val AppUpdateBulletinKey = booleanPreferencesKey("appUpdateBulletin")

val MusicRecsNotificationKey = booleanPreferencesKey("musicRecsNotification")
val PlaylistUpdatedNotificationKey = booleanPreferencesKey("playlistUpdatedNotification")
val PodcastRecsNotificationKey = booleanPreferencesKey("podcastRecsNotification")
val ProductUpdatedNotificationKey = booleanPreferencesKey("productUpdatedNotification")
val RecapNotificationKey = booleanPreferencesKey("recapNotification")
val EventNotificationKey = booleanPreferencesKey("eventNotification")
val NewBadgeNotificationKey = booleanPreferencesKey("newBadgeNotification")
val MyChannelActivityNotificationKey = booleanPreferencesKey("myChannelActivityNotification")
val MyCommentActivityNotificationKey = booleanPreferencesKey("myCommentActivityNotification")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsSettings(
    navController: NavController
) {
    val (pushNotification, onPushNotificationChange) = rememberPreference(key = PushNotificationKey, defaultValue = true)
    val (newSongNotification, onNewSongNotificationChange) = rememberPreference(key = NewSongNotificationKey, defaultValue = true)
    val (subscribedChannelNotification, onSubscribedChannelNotificationChange) = rememberPreference(key = SubscribedChannelNotificationKey, defaultValue = true)
    val (channelActivityNotification, onChannelActivityNotificationChange) = rememberPreference(key = ChannelActivityNotificationKey, defaultValue = true)
    val (appUpdateBulletin, onAppUpdateBulletinChange) = rememberPreference(key = AppUpdateBulletinKey, defaultValue = true)

    val (musicRecsNotification, onMusicRecsNotificationChange) = rememberPreference(key = MusicRecsNotificationKey, defaultValue = true)
    val (playlistUpdatedNotification, onPlaylistUpdatedNotificationChange) = rememberPreference(key = PlaylistUpdatedNotificationKey, defaultValue = true)
    val (podcastRecsNotification, onPodcastRecsNotificationChange) = rememberPreference(key = PodcastRecsNotificationKey, defaultValue = true)
    val (productUpdatedNotification, onProductUpdatedNotificationChange) = rememberPreference(key = ProductUpdatedNotificationKey, defaultValue = false)
    val (recapNotification, onRecapNotificationChange) = rememberPreference(key = RecapNotificationKey, defaultValue = true)
    val (eventNotification, onEventNotificationChange) = rememberPreference(key = EventNotificationKey, defaultValue = true)
    val (newBadgeNotification, onNewBadgeNotificationChange) = rememberPreference(key = NewBadgeNotificationKey, defaultValue = true)
    val (myChannelActivityNotification, onMyChannelActivityNotificationChange) = rememberPreference(key = MyChannelActivityNotificationKey, defaultValue = true)
    val (myCommentActivityNotification, onMyCommentActivityNotificationChange) = rememberPreference(key = MyCommentActivityNotificationKey, defaultValue = true)

    Column(
        Modifier
            .windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom
                )
            )
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Spacer(
            Modifier.windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Top
                )
            )
        )

        Material3SettingsGroup(
            title = stringResource(R.string.notifications_settings),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.music_note),
                    title = { Text(stringResource(R.string.notif_music_recs_title)) },
                    description = { Text(stringResource(R.string.notif_music_recs_desc)) },
                    trailingContent = {
                        Switch(
                            checked = musicRecsNotification,
                            onCheckedChange = onMusicRecsNotificationChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (musicRecsNotification) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onMusicRecsNotificationChange(!musicRecsNotification) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.queue_music),
                    title = { Text(stringResource(R.string.notif_playlist_updated_title)) },
                    description = { Text(stringResource(R.string.notif_playlist_updated_desc)) },
                    trailingContent = {
                        Switch(
                            checked = playlistUpdatedNotification,
                            onCheckedChange = onPlaylistUpdatedNotificationChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (playlistUpdatedNotification) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onPlaylistUpdatedNotificationChange(!playlistUpdatedNotification) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.radio),
                    title = { Text(stringResource(R.string.notif_podcast_recs_title)) },
                    description = { Text(stringResource(R.string.notif_podcast_recs_desc)) },
                    trailingContent = {
                        Switch(
                            checked = podcastRecsNotification,
                            onCheckedChange = onPodcastRecsNotificationChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (podcastRecsNotification) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onPodcastRecsNotificationChange(!podcastRecsNotification) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.newspaper),
                    title = { Text(stringResource(R.string.notif_product_updated_title)) },
                    description = { Text(stringResource(R.string.notif_product_updated_desc)) },
                    trailingContent = {
                        Switch(
                            checked = productUpdatedNotification,
                            onCheckedChange = onProductUpdatedNotificationChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (productUpdatedNotification) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onProductUpdatedNotificationChange(!productUpdatedNotification) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.restore),
                    title = { Text(stringResource(R.string.notif_recap_title)) },
                    description = { Text(stringResource(R.string.notif_recap_desc)) },
                    trailingContent = {
                        Switch(
                            checked = recapNotification,
                            onCheckedChange = onRecapNotificationChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (recapNotification) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onRecapNotificationChange(!recapNotification) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.info),
                    title = { Text(stringResource(R.string.notif_event_title)) },
                    description = { Text(stringResource(R.string.notif_event_desc)) },
                    trailingContent = {
                        Switch(
                            checked = eventNotification,
                            onCheckedChange = onEventNotificationChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (eventNotification) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onEventNotificationChange(!eventNotification) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.group_filled),
                    title = { Text(stringResource(R.string.notif_subscribed_channels_title)) },
                    description = { Text(stringResource(R.string.notif_subscribed_channels_desc)) },
                    onClick = { navController.navigate("settings/subscribed_channels") }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.check),
                    title = { Text(stringResource(R.string.notif_new_badges_title)) },
                    description = { Text(stringResource(R.string.notif_new_badges_desc)) },
                    trailingContent = {
                        Switch(
                            checked = newBadgeNotification,
                            onCheckedChange = onNewBadgeNotificationChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (newBadgeNotification) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onNewBadgeNotificationChange(!newBadgeNotification) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.person),
                    title = { Text(stringResource(R.string.notif_my_channel_activity_title)) },
                    description = { Text(stringResource(R.string.notif_my_channel_activity_desc)) },
                    trailingContent = {
                        Switch(
                            checked = myChannelActivityNotification,
                            onCheckedChange = onMyChannelActivityNotificationChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (myChannelActivityNotification) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onMyChannelActivityNotificationChange(!myChannelActivityNotification) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.info),
                    title = { Text(stringResource(R.string.notif_my_comment_activity_title)) },
                    description = { Text(stringResource(R.string.notif_my_comment_activity_desc)) },
                    trailingContent = {
                        Switch(
                            checked = myCommentActivityNotification,
                            onCheckedChange = onMyCommentActivityNotificationChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (myCommentActivityNotification) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onMyCommentActivityNotificationChange(!myCommentActivityNotification) }
                )
            )
        )
        Spacer(modifier = Modifier.height(16.dp))
    }

    TopAppBar(
        title = { Text(stringResource(R.string.notifications_title)) },
        navigationIcon = {
            IconButton(
                onClick = navController::navigateUp,
                onLongClick = navController::backToMain,
            ) {
                Icon(
                    painterResource(R.drawable.arrow_back),
                    contentDescription = null,
                )
            }
        }
    )
}
