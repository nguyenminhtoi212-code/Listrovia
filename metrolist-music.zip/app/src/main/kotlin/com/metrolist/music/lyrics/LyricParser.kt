/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.lyrics

import java.util.Locale
import java.util.regex.Pattern

/**
 * Structured metadata extracted from .lrc file header tags.
 * Supports standard tags ([ar:], [ti:], [al:], [by:], [offset:], [length:]) as well as custom tags.
 */
data class LrcMetadata(
    val artist: String? = null,
    val title: String? = null,
    val album: String? = null,
    val author: String? = null,
    val creator: String? = null,
    val fileOffset: Long = 0L,
    val length: String? = null,
    val program: String? = null,
    val version: String? = null,
    val language: String? = null,
    val availableLanguages: List<String> = emptyList(),
    val customTags: Map<String, String> = emptyMap()
) {
    val isNotEmpty: Boolean
        get() = !artist.isNullOrBlank() ||
                !title.isNullOrBlank() ||
                !album.isNullOrBlank() ||
                !author.isNullOrBlank() ||
                !creator.isNullOrBlank() ||
                fileOffset != 0L ||
                !length.isNullOrBlank() ||
                !language.isNullOrBlank() ||
                availableLanguages.isNotEmpty() ||
                customTags.isNotEmpty()

    val isEmpty: Boolean
        get() = !isNotEmpty

    /**
     * Returns a concise display credit combining title, artist, and creator.
     */
    fun getFormattedCredit(): String? {
        val parts = mutableListOf<String>()
        if (!title.isNullOrBlank()) parts.add(title)
        if (!artist.isNullOrBlank()) parts.add(artist)
        if (!creator.isNullOrBlank() && creator != artist) parts.add("by $creator")
        return if (parts.isNotEmpty()) parts.joinToString(" • ") else null
    }

    /**
     * Converts metadata back to map representation.
     */
    fun toMap(): Map<String, String> {
        val map = mutableMapOf<String, String>()
        artist?.let { map["ar"] = it }
        title?.let { map["ti"] = it }
        album?.let { map["al"] = it }
        author?.let { map["au"] = it }
        creator?.let { map["by"] = it }
        if (fileOffset != 0L) map["offset"] = fileOffset.toString()
        length?.let { map["length"] = it }
        program?.let { map["re"] = it }
        version?.let { map["ve"] = it }
        language?.let { map["lang"] = it }
        if (availableLanguages.isNotEmpty()) map["languages"] = availableLanguages.joinToString(",")
        map.putAll(customTags)
        return map
    }
}

/**
 * Result data class when parsing an LRC file with metadata.
 */
data class ParsedLyrics(
    val entries: List<LyricsEntry>,
    val metadata: LrcMetadata = LrcMetadata(),
    val rawMetadata: Map<String, String> = emptyMap(),
    val isSynced: Boolean = false
)

/**
 * Utility class that handles .lrc file formats, parsing, serializing,
 * metadata extraction, and mapping playback timestamps to lyric lines.
 */
object LyricParser {

    private val TIMESTAMP_REGEX = Pattern.compile("\\[(\\d{1,2}):(\\d{2})(?:[.:](\\d{2,3}))?\\]")
    private val METADATA_TAG_REGEX = Pattern.compile("^\\[(ti|ar|al|au|by|offset|length|re|ve|tool|[a-zA-Z0-9_-]+):([^\\]]*)\\]$", Pattern.CASE_INSENSITIVE)
    private val AGENT_TAG_REGEX = Pattern.compile("\\{agent:([^}]+)\\}", Pattern.CASE_INSENSITIVE)
    private val BG_TAG_REGEX = Pattern.compile("\\{bg\\}", Pattern.CASE_INSENSITIVE)
    private val PIPE_WORD_BLOCK_REGEX = Pattern.compile("^<(.+)>$")
    private val INLINE_WORD_TAG_REGEX = Pattern.compile("<(\\d{1,2}):(\\d{2})(?:[.:](\\d{2,3}))?>")

    /**
     * Parses a raw LRC string into a list of sorted [LyricsEntry].
     * Supports standard LRC, multi-timestamp lines, TTML pipe word timings, and enhanced LRC.
     * @param lrcContent Raw LRC text.
     * @param userOffsetMs Additional user-configured offset in milliseconds.
     */
    fun parse(lrcContent: String, userOffsetMs: Long = 0L): List<LyricsEntry> {
        return parseWithMetadata(lrcContent, userOffsetMs).entries
    }

    /**
     * Extracts only the metadata tags from an LRC string without parsing all lyric lines.
     */
    fun extractMetadata(lrcContent: String): LrcMetadata {
        if (lrcContent.isBlank()) return LrcMetadata()
        val rawMap = mutableMapOf<String, String>()
        for (line in lrcContent.lines()) {
            val trimmed = line.trim()
            if (trimmed.isEmpty()) continue
            if (!trimmed.startsWith("[")) break
            val metaMatcher = METADATA_TAG_REGEX.matcher(trimmed)
            if (metaMatcher.matches()) {
                val key = metaMatcher.group(1)?.lowercase(Locale.ROOT) ?: ""
                val value = metaMatcher.group(2)?.trim() ?: ""
                rawMap[key] = value
            } else if (TIMESTAMP_REGEX.matcher(trimmed).find()) {
                break
            }
        }
        return buildLrcMetadata(rawMap)
    }

    /**
     * Parses an LRC string into [ParsedLyrics] containing sorted entries, structured [LrcMetadata], and sync state.
     * @param lrcContent Raw LRC text.
     * @param userOffsetMs Additional user-configured offset in milliseconds.
     */
    fun parseWithMetadata(lrcContent: String, userOffsetMs: Long = 0L): ParsedLyrics {
        if (lrcContent.isBlank()) {
            return ParsedLyrics(emptyList(), LrcMetadata(), emptyMap(), false)
        }

        val rawMetadata = mutableMapOf<String, String>()
        val rawEntries = mutableListOf<LyricsEntry>()
        var fileOffsetMs = 0L

        // Fast unescape if wrapped in quotes or contains escape chars
        val cleanContent = unescape(lrcContent)
        val lines = cleanContent.lines()

        var currentLineIndex = 0
        while (currentLineIndex < lines.size) {
            val rawLine = lines[currentLineIndex].trim()
            if (rawLine.isEmpty()) {
                currentLineIndex++
                continue
            }

            // Check metadata tag (e.g. [ar:Artist], [ti:Title], [offset:500])
            val metaMatcher = METADATA_TAG_REGEX.matcher(rawLine)
            if (metaMatcher.matches()) {
                val key = metaMatcher.group(1)?.lowercase(Locale.ROOT) ?: ""
                val value = metaMatcher.group(2)?.trim() ?: ""
                rawMetadata[key] = value
                if (key == "offset") {
                    fileOffsetMs = value.toLongOrNull() ?: 0L
                }
                currentLineIndex++
                continue
            }

            // Check for pipe word-level block (<word:start:end|...>) on subsequent line
            var wordTimings: List<WordTimestamp>? = null
            if (currentLineIndex + 1 < lines.size) {
                val nextLine = lines[currentLineIndex + 1].trim()
                val pipeMatcher = PIPE_WORD_BLOCK_REGEX.matcher(nextLine)
                if (pipeMatcher.matches()) {
                    val inner = pipeMatcher.group(1) ?: ""
                    wordTimings = parsePipeWordTimings(inner)
                    currentLineIndex++ // consume the word timings line
                }
            }

            // Parse timestamp tags and text from current line
            val parsedLines = parseLrcLine(rawLine, wordTimings)
            if (parsedLines.isNotEmpty()) {
                rawEntries.addAll(parsedLines)
            } else if (rawEntries.isEmpty() && !rawLine.startsWith("[")) {
                // If the entire text has no timestamps (plain text lyrics), generate sequential entries
                rawEntries.add(LyricsEntry(rawEntries.size * 1000L, rawLine))
            }

            currentLineIndex++
        }

        val totalOffset = fileOffsetMs + userOffsetMs

        // Apply total offset if present
        val finalEntries = if (totalOffset != 0L) {
            rawEntries.map { entry ->
                entry.copy(time = maxOf(0L, entry.time + totalOffset))
            }
        } else {
            rawEntries
        }

        val sortedEntries = finalEntries.sortedBy { it.time }
        val isSynced = sortedEntries.any { it.time > 0L } || (sortedEntries.size > 1 && sortedEntries.first().time != sortedEntries.last().time)

        val metadata = buildLrcMetadata(rawMetadata)

        return ParsedLyrics(
            entries = sortedEntries,
            metadata = metadata,
            rawMetadata = rawMetadata,
            isSynced = isSynced
        )
    }

    private fun buildLrcMetadata(rawMap: Map<String, String>): LrcMetadata {
        val custom = mutableMapOf<String, String>()
        var artist: String? = null
        var title: String? = null
        var album: String? = null
        var author: String? = null
        var creator: String? = null
        var offset = 0L
        var length: String? = null
        var program: String? = null
        var version: String? = null
        var language: String? = null
        var availableLanguages = emptyList<String>()

        rawMap.forEach { (k, v) ->
            when (k.lowercase(Locale.ROOT)) {
                "ar" -> artist = v
                "ti" -> title = v
                "al" -> album = v
                "au" -> author = v
                "by" -> creator = v
                "offset" -> offset = v.toLongOrNull() ?: 0L
                "length" -> length = v
                "re", "tool" -> program = v
                "ve" -> version = v
                "lang", "language", "lan" -> language = v
                "languages", "langs" -> {
                    availableLanguages = v.split(",", ";", "/", "|").map { it.trim() }.filter { it.isNotEmpty() }
                }
                else -> custom[k] = v
            }
        }

        return LrcMetadata(
            artist = artist,
            title = title,
            album = album,
            author = author,
            creator = creator,
            fileOffset = offset,
            length = length,
            program = program,
            version = version,
            language = language,
            availableLanguages = availableLanguages,
            customTags = custom
        )
    }

    /**
     * Parses a single line that may contain one or multiple timestamps.
     */
    private fun parseLrcLine(line: String, externalWords: List<WordTimestamp>?): List<LyricsEntry> {
        val timestamps = mutableListOf<Long>()
        val tsMatcher = TIMESTAMP_REGEX.matcher(line)
        var lastEnd = 0

        while (tsMatcher.find()) {
            val min = tsMatcher.group(1)?.toLongOrNull() ?: 0L
            val sec = tsMatcher.group(2)?.toLongOrNull() ?: 0L
            val fracStr = tsMatcher.group(3)
            val ms = when {
                fracStr == null -> 0L
                fracStr.length == 2 -> (fracStr.toLongOrNull() ?: 0L) * 10L
                fracStr.length == 3 -> fracStr.toLongOrNull() ?: 0L
                else -> (fracStr.take(3).toLongOrNull() ?: 0L)
            }
            val timeMs = min * 60_000L + sec * 1_000L + ms
            timestamps.add(timeMs)
            lastEnd = tsMatcher.end()
        }

        if (timestamps.isEmpty()) return emptyList()

        var textPart = line.substring(lastEnd).trim()

        // Extract {agent:...} tag
        var agent: String? = null
        val agentMatcher = AGENT_TAG_REGEX.matcher(textPart)
        if (agentMatcher.find()) {
            agent = agentMatcher.group(1)
            textPart = agentMatcher.replaceAll("").trim()
        }

        // Extract {bg} tag
        var isBackground = false
        val bgMatcher = BG_TAG_REGEX.matcher(textPart)
        if (bgMatcher.find()) {
            isBackground = true
            textPart = bgMatcher.replaceAll("").trim()
        }

        // Check for inline enhanced LRC word timings: <00:12.34>word <00:13.00>word2
        val inlineWords = if (externalWords == null && INLINE_WORD_TAG_REGEX.matcher(textPart).find()) {
            parseInlineWordTimings(textPart)
        } else {
            null
        }

        val cleanedText = if (inlineWords != null) {
            cleanInlineTimestamps(textPart)
        } else {
            textPart
        }

        val wordsToUse = externalWords ?: inlineWords

        return timestamps.map { timeMs ->
            LyricsEntry(
                time = timeMs,
                text = cleanedText,
                words = wordsToUse,
                agent = agent,
                isBackground = isBackground
            )
        }
    }

    /**
     * Parses word timestamps formatted as <word:startTimeSec:endTimeSec|...>
     */
    private fun parsePipeWordTimings(raw: String): List<WordTimestamp> {
        val parts = raw.split('|')
        val list = mutableListOf<WordTimestamp>()
        for (part in parts) {
            val seg = part.split(':')
            if (seg.size >= 3) {
                val wordText = seg[0]
                val sTime = seg[1].toDoubleOrNull() ?: continue
                val eTime = seg[2].toDoubleOrNull() ?: continue
                list.add(
                    WordTimestamp(
                        text = wordText,
                        startTime = sTime,
                        endTime = eTime,
                        hasTrailingSpace = true
                    )
                )
            }
        }
        return list
    }

    /**
     * Parses inline word timestamps like: <00:01.20>Hello <00:02.00>World
     */
    private fun parseInlineWordTimings(text: String): List<WordTimestamp> {
        val words = mutableListOf<WordTimestamp>()
        val matcher = INLINE_WORD_TAG_REGEX.matcher(text)
        var lastTimeSec = 0.0
        var lastWord: String? = null

        while (matcher.find()) {
            val min = matcher.group(1)?.toLongOrNull() ?: 0L
            val sec = matcher.group(2)?.toLongOrNull() ?: 0L
            val fracStr = matcher.group(3)
            val ms = when {
                fracStr == null -> 0L
                fracStr.length == 2 -> (fracStr.toLongOrNull() ?: 0L) * 10L
                fracStr.length == 3 -> fracStr.toLongOrNull() ?: 0L
                else -> (fracStr.take(3).toLongOrNull() ?: 0L)
            }
            val timeSec = (min * 60_000L + sec * 1_000L + ms) / 1000.0

            if (lastWord != null) {
                words.add(WordTimestamp(lastWord, lastTimeSec, timeSec, hasTrailingSpace = true))
            }

            val textStart = matcher.end()
            val nextTag = text.indexOf('<', textStart)
            val currentWord = if (nextTag != -1) {
                text.substring(textStart, nextTag).trim()
            } else {
                text.substring(textStart).trim()
            }

            lastWord = currentWord
            lastTimeSec = timeSec
        }

        if (!lastWord.isNullOrEmpty()) {
            words.add(WordTimestamp(lastWord, lastTimeSec, lastTimeSec + 0.5, hasTrailingSpace = true))
        }

        return words
    }

    /**
     * Strips inline timestamp tags <mm:ss.xx> from text.
     */
    private fun cleanInlineTimestamps(text: String): String {
        return text.replace(INLINE_WORD_TAG_REGEX.toRegex(), "").trim()
    }

    /**
     * Fast binary search to find the active lyric line index for a given playback position in milliseconds.
     * Returns the index in [entries], or -1 if entries is empty or playback position is before the first line.
     * @param entries Sorted lyric lines.
     * @param positionMs Current audio playback position in milliseconds.
     * @param userOffsetMs Additional fine-tune offset applied to position (effectivePosition = positionMs + userOffsetMs).
     */
    fun findCurrentLineIndex(entries: List<LyricsEntry>, positionMs: Long, userOffsetMs: Long = 0L): Int {
        if (entries.isEmpty()) return -1
        val effectivePosition = positionMs + userOffsetMs
        if (effectivePosition < entries.first().time) return -1

        var low = 0
        var high = entries.size - 1
        var result = -1

        while (low <= high) {
            val mid = (low + high) ushr 1
            val entryTime = entries[mid].time
            if (entryTime <= effectivePosition) {
                result = mid
                low = mid + 1
            } else {
                high = mid - 1
            }
        }
        return result
    }

    /**
     * Returns all active lyric line indices at [positionMs], including simultaneous vocal tracks/background lines.
     */
    fun findActiveLineIndices(
        entries: List<LyricsEntry>,
        positionMs: Long,
        userOffsetMs: Long = 0L,
        toleranceMs: Long = 3000L
    ): List<Int> {
        val primaryIdx = findCurrentLineIndex(entries, positionMs, userOffsetMs)
        if (primaryIdx == -1) return emptyList()

        val primary = entries[primaryIdx]
        val active = mutableListOf(primaryIdx)

        // Check neighboring lines with identical or close timestamps (background vocals / multi-agent)
        var i = primaryIdx - 1
        while (i >= 0 && Math.abs(entries[i].time - primary.time) <= 100L) {
            active.add(0, i)
            i--
        }

        var j = primaryIdx + 1
        while (j < entries.size && Math.abs(entries[j].time - primary.time) <= 100L) {
            active.add(j)
            j++
        }

        return active
    }

    /**
     * Gets the lyric entry at the specified playback position.
     */
    fun getLineAt(entries: List<LyricsEntry>, positionMs: Long, userOffsetMs: Long = 0L): LyricsEntry? {
        val index = findCurrentLineIndex(entries, positionMs, userOffsetMs)
        return if (index in entries.indices) entries[index] else null
    }

    /**
     * Calculates the progress ratio (0.0 to 1.0) of the current lyric line based on the next line timestamp.
     */
    fun getLineProgress(
        entries: List<LyricsEntry>,
        currentIndex: Int,
        positionMs: Long,
        userOffsetMs: Long = 0L
    ): Float {
        if (currentIndex !in entries.indices) return 0f
        val current = entries[currentIndex]
        val effectivePosition = positionMs + userOffsetMs
        if (effectivePosition < current.time) return 0f

        val nextTime = if (currentIndex + 1 < entries.size) {
            entries[currentIndex + 1].time
        } else {
            current.time + 4000L
        }

        val duration = nextTime - current.time
        if (duration <= 0L) return 1f

        return ((effectivePosition - current.time).toFloat() / duration).coerceIn(0f, 1f)
    }

    /**
     * Formats a list of [LyricsEntry] and optional metadata back into standard .lrc file text.
     */
    fun formatToLrc(entries: List<LyricsEntry>, metadata: LrcMetadata? = null): String {
        val sb = StringBuilder()

        metadata?.let { meta ->
            meta.title?.let { sb.append("[ti:").append(it).append("]\n") }
            meta.artist?.let { sb.append("[ar:").append(it).append("]\n") }
            meta.album?.let { sb.append("[al:").append(it).append("]\n") }
            meta.creator?.let { sb.append("[by:").append(it).append("]\n") }
            meta.author?.let { sb.append("[au:").append(it).append("]\n") }
            if (meta.fileOffset != 0L) sb.append("[offset:").append(meta.fileOffset).append("]\n")
            meta.length?.let { sb.append("[length:").append(it).append("]\n") }
            meta.program?.let { sb.append("[re:").append(it).append("]\n") }
            meta.version?.let { sb.append("[ve:").append(it).append("]\n") }
            meta.customTags.forEach { (k, v) ->
                sb.append('[').append(k).append(':').append(v).append("]\n")
            }
        }

        for (entry in entries) {
            sb.append(formatTime(entry.time))
            if (entry.isBackground) {
                sb.append("{bg}")
            }
            if (!entry.agent.isNullOrBlank()) {
                sb.append("{agent:").append(entry.agent).append('}')
            }
            sb.append(entry.text).append('\n')

            val words = entry.words
            if (!words.isNullOrEmpty()) {
                sb.append('<')
                words.forEachIndexed { idx, w ->
                    sb.append(w.text).append(':').append(w.startTime).append(':').append(w.endTime)
                    if (idx < words.size - 1) sb.append('|')
                }
                sb.append(">\n")
            }
        }

        return sb.toString()
    }

    /**
     * Formats a millisecond timestamp to [mm:ss.xx]
     */
    fun formatTime(timeMs: Long): String {
        val totalSec = maxOf(0L, timeMs) / 1000
        val min = totalSec / 60
        val sec = totalSec % 60
        val hundredths = (maxOf(0L, timeMs) % 1000) / 10
        return String.format(Locale.US, "[%02d:%02d.%02d]", min, sec, hundredths)
    }

    /**
     * Unescape HTML / escape codes in raw LRC string.
     */
    private fun unescape(s: String): String {
        if (!s.contains('\\') && !s.startsWith("\"") && !s.contains('&')) {
            return s
        }
        val unquoted = s.trim().removePrefix("\"").removeSuffix("\"")
        val sb = StringBuilder(unquoted.length)
        var i = 0
        while (i < unquoted.length) {
            val c = unquoted[i]
            if (c == '\\' && i + 1 < unquoted.length) {
                when (val next = unquoted[i + 1]) {
                    '\\' -> sb.append('\\')
                    'n' -> sb.append('\n')
                    'r' -> sb.append('\r')
                    't' -> sb.append('\t')
                    else -> sb.append(c).append(next)
                }
                i += 2
            } else {
                sb.append(c)
                i++
            }
        }
        return sb.toString()
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&apos;", "'")
    }
}
