/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.lyrics.providers

import android.content.Context
import com.metrolist.music.constants.EnablePaxsenixKey
import com.metrolist.music.lyrics.LyricsProvider
import com.metrolist.music.utils.dataStore
import com.metrolist.music.utils.get
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.defaultRequest
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.parameter
import io.ktor.client.statement.bodyAsText
import io.ktor.http.HttpStatusCode
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import timber.log.Timber
import java.net.URLEncoder
import java.util.Locale
import kotlin.math.abs

@Serializable
data class PaxsenixSearchResult(
    val id: String,
    val songName: String? = null,
    val trackName: String? = null,
    val artistName: String? = null,
    val albumName: String? = null,
    val duration: Int? = null,
    val artwork: String? = null,
) {
    val displayName: String get() = trackName ?: songName ?: ""
    val displayArtist: String get() = artistName ?: ""
}

@Serializable
data class PaxsenixLyricText(
    val text: String = "",
    val timestamp: Long = 0,
    val endtime: Long = 0,
    val duration: Long = 0,
    val part: Boolean = false,
)

@Serializable
data class PaxsenixLyricsContent(
    val timestamp: Long = 0,
    val endtime: Long = 0,
    val duration: Long = 0,
    val structure: String? = null,
    val text: List<PaxsenixLyricText> = emptyList(),
    val background: Boolean = false,
    val backgroundText: List<PaxsenixLyricText> = emptyList(),
    val oppositeTurn: Boolean = false,
)

@Serializable
data class PaxsenixMetadata(
    val songwriters: List<String> = emptyList(),
)

@Serializable
data class PaxsenixLyricsResponse(
    val type: String? = null,
    val metadata: PaxsenixMetadata? = null,
    val content: List<PaxsenixLyricsContent> = emptyList(),
    val elrc: String? = null,
    val elrcMultiPerson: String? = null,
    val ttmlContent: String? = null,
    val plain: String? = null,
)

/**
 * Paxsenix Lyrics Retrieval Engine
 */
object Paxsenix {
    private const val TAG = "Paxsenix"
    private const val BASE_URL = "https://lyrics.paxsenix.org"

    @Volatile
    private var appVersion: String = "Unknown"

    private val json = Json {
        isLenient = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val httpClient by lazy {
        HttpClient(OkHttp) {
            install(HttpTimeout) {
                requestTimeoutMillis = 15000
                connectTimeoutMillis = 10000
            }
            install(ContentNegotiation) {
                json(json)
            }
            defaultRequest {
                url(BASE_URL)
                header("User-Agent", "Metrolist/$appVersion")
            }
            expectSuccess = false
        }
    }

    fun init(context: Context) {
        try {
            appVersion = context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "Unknown"
        } catch (e: Exception) {
            Timber.tag(TAG).d(e, "Could not fetch app version")
        }
    }

    private val titleCleanupPatterns = listOf(
        Regex("""\s*\(.*?(official|video|audio|lyrics|lyric|visualizer|hd|hq|4k|remaster|remix|live|acoustic|version|edit|extended|radio|clean|explicit).*?\)""", RegexOption.IGNORE_CASE),
        Regex("""\s*\[.*?(official|video|audio|lyrics|lyric|visualizer|hd|hq|4k|remaster|remix|live|acoustic|version|edit|extended|radio|clean|explicit).*?\]""", RegexOption.IGNORE_CASE),
        Regex("""\s*【.*?】"""),
        Regex("""\s*\|.*$"""),
        Regex("""\s*-\s*(official|video|audio|lyrics|lyric|visualizer).*$""", RegexOption.IGNORE_CASE),
        Regex("""\s*\(feat\..*?\)""", RegexOption.IGNORE_CASE),
        Regex("""\s*\(ft\..*?\)""", RegexOption.IGNORE_CASE),
        Regex("""\s*feat\..*$""", RegexOption.IGNORE_CASE),
        Regex("""\s*ft\..*$""", RegexOption.IGNORE_CASE),
    )

    private val artistSeparators = listOf(" & ", " and ", ", ", " x ", " X ", " feat. ", " feat ", " ft. ", " ft ", " featuring ", " with ")

    private fun cleanTitle(title: String): String {
        var cleaned = title.trim()
        for (pattern in titleCleanupPatterns) {
            cleaned = cleaned.replace(pattern, "")
        }
        return cleaned.trim()
    }

    private fun cleanArtist(artist: String): String {
        var cleaned = artist.trim()
        for (separator in artistSeparators) {
            if (cleaned.contains(separator, ignoreCase = true)) {
                cleaned = cleaned.split(separator, ignoreCase = true, limit = 2)[0]
                break
            }
        }
        return cleaned.trim()
    }

    private suspend fun search(query: String): List<PaxsenixSearchResult> = runCatching {
        val res = httpClient.get("/search") {
            parameter("q", query)
        }
        if (res.status == HttpStatusCode.OK) {
            res.body<List<PaxsenixSearchResult>>()
        } else {
            emptyList()
        }
    }.getOrDefault(emptyList())

    private suspend fun fetchLyricsById(id: String): PaxsenixLyricsResponse? = runCatching {
        val res = httpClient.get("/lyrics") {
            parameter("id", id)
        }
        if (res.status == HttpStatusCode.OK) {
            res.body<PaxsenixLyricsResponse>()
        } else {
            null
        }
    }.getOrNull()

    suspend fun getLyrics(
        title: String,
        artist: String,
        duration: Int,
        album: String? = null,
    ): Result<String> = runCatching {
        val cleanedTitle = cleanTitle(title)
        val cleanedArtist = cleanArtist(artist)

        var searchResults = search("$cleanedTitle $cleanedArtist")
        if (searchResults.isEmpty()) {
            searchResults = search("$title $artist")
        }

        val track = findBestMatch(searchResults, duration)
            ?: throw IllegalStateException("No matching track found on Paxsenix for $title")

        val lyricsResp = fetchLyricsById(track.id)
            ?: throw IllegalStateException("Failed to load lyrics from Paxsenix for track ${track.id}")

        extractBestLyrics(lyricsResp)
            ?: throw IllegalStateException("No usable lyrics payload from Paxsenix for ${track.id}")
    }

    suspend fun getAllLyrics(
        title: String,
        artist: String,
        duration: Int,
        album: String? = null,
        callback: (String) -> Unit,
    ) {
        try {
            val cleanedTitle = cleanTitle(title)
            val cleanedArtist = cleanArtist(artist)

            val searchResults = search("$cleanedTitle $cleanedArtist")
            searchResults.forEach { track ->
                if (duration == -1 || track.duration == null || abs(track.duration - duration) <= 5) {
                    val lyricsResp = fetchLyricsById(track.id)
                    lyricsResp?.let { extractBestLyrics(it)?.let(callback) }
                }
            }
        } catch (e: Exception) {
            Timber.tag(TAG).w(e, "Error fetching all lyrics from Paxsenix")
        }
    }

    private fun findBestMatch(tracks: List<PaxsenixSearchResult>, duration: Int): PaxsenixSearchResult? {
        if (tracks.isEmpty()) return null
        if (duration == -1) return tracks.firstOrNull()

        return tracks.minByOrNull { track ->
            val trackDuration = track.duration ?: 0
            abs(trackDuration - duration)
        }?.takeIf { track ->
            val trackDuration = track.duration ?: 0
            abs(trackDuration - duration) <= 5
        } ?: tracks.firstOrNull()
    }

    private fun extractBestLyrics(response: PaxsenixLyricsResponse): String? {
        // 1. TTML formatted content
        response.ttmlContent?.takeIf { it.isNotBlank() }?.let { ttml ->
            val parsed = TTMLParser.parse(ttml)
            if (parsed.isNotBlank()) return parsed
        }

        // 2. Multi-person ELRC (word-synced)
        response.elrcMultiPerson?.takeIf { it.isNotBlank() }?.let { return it }

        // 3. Standard ELRC
        response.elrc?.takeIf { it.isNotBlank() }?.let { return it }

        // 4. Content lines formatted to LRC
        if (response.content.isNotEmpty()) {
            val lrc = formatContentToLrc(response.content)
            if (lrc.isNotBlank()) return lrc
        }

        // 5. Plain text
        return response.plain?.takeIf { it.isNotBlank() }
    }

    private fun formatContentToLrc(content: List<PaxsenixLyricsContent>): String {
        return content.joinToString("\n") { line ->
            val minutes = (line.timestamp / 1000) / 60
            val seconds = (line.timestamp / 1000) % 60
            val millis = (line.timestamp % 1000) / 10
            val timeTag = String.format(Locale.US, "[%02d:%02d.%02d]", minutes, seconds, millis)
            val text = line.text.joinToString("") { it.text }
            "$timeTag$text"
        }.trim()
    }
}

/**
 * Paxsenix Lyrics Provider
 */
object PaxsenixLyricsProvider : LyricsProvider {
    override val name = "Paxsenix"

    override fun isEnabled(context: Context): Boolean =
        context.dataStore[EnablePaxsenixKey] ?: true

    override suspend fun getLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): Result<String> {
        Paxsenix.init(context)
        return Paxsenix.getLyrics(title, artist, duration, album)
    }

    override suspend fun getAllLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
        callback: (String) -> Unit,
    ) {
        Paxsenix.init(context)
        Paxsenix.getAllLyrics(title, artist, duration, album, callback)
    }
}
