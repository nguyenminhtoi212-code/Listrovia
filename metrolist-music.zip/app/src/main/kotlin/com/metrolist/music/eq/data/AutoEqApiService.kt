package com.metrolist.music.eq.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import timber.log.Timber
import java.io.File
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Provider / Sound recording source definition for AutoEQ
 */
data class AudioMeasurementProvider(
    val id: String,
    val name: String,
    val countryFlag: String,
    val region: String,
    val description: String,
    val rig: String
)

/**
 * Service to fetch AutoEQ sound profiles and presets via open public APIs.
 * Requires NO API KEY and NO USER ACCOUNT.
 * Includes built-in offline calibration catalog for instant access worldwide (including Vietnam V-Sound studio profiles)
 * and can dynamically download and sync the full 9,000+ open database from multiple high-speed CDN mirrors.
 */
class AutoEqApiService(private val context: Context) {

    private val entries = mutableListOf<Entry>()
    private var isIndexed = false

    private val cacheDir = File(context.filesDir, "autoeq_cache")
    private val indexFile = File(cacheDir, "index.md")
    private val indexTimestampFile = File(cacheDir, "index_timestamp")

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    companion object {
        private const val TAG = "AutoEqApiService"

        // Public Open API / CDN Mirrors for AutoEQ Index (no account / no token required)
        private val INDEX_MIRRORS = listOf(
            "https://cdn.jsdelivr.net/gh/jaakkopasanen/AutoEq@master/results/INDEX.md",
            "https://fastly.jsdelivr.net/gh/jaakkopasanen/AutoEq@master/results/INDEX.md",
            "https://raw.githubusercontent.com/jaakkopasanen/AutoEq/master/results/INDEX.md",
            "https://raw.githack.com/jaakkopasanen/AutoEq/master/results/INDEX.md",
            "https://cdn.statically.io/gh/jaakkopasanen/AutoEq/master/results/INDEX.md"
        )

        // Public Open API / CDN Base Mirrors for ParametricEQ files
        private val RAW_BASE_MIRRORS = listOf(
            "https://cdn.jsdelivr.net/gh/jaakkopasanen/AutoEq@master/results",
            "https://fastly.jsdelivr.net/gh/jaakkopasanen/AutoEq@master/results",
            "https://raw.githubusercontent.com/jaakkopasanen/AutoEq/master/results",
            "https://raw.githack.com/jaakkopasanen/AutoEq/master/results"
        )

        private const val CACHE_TTL_MS = 14 * 24 * 60 * 60 * 1000L // 14 days cache
        private val INDEX_LINE_REGEX = Regex("""^-\s*\[(.*?)\]\((.*?)\)(?:\s+by\s+(.*?))?(?:\s+on\s+(.*?))?$""")

        val GLOBAL_PROVIDERS = listOf(
            AudioMeasurementProvider(
                id = "all",
                name = "All Providers",
                countryFlag = "🌍",
                region = "Global",
                description = "Full global audio calibration archive",
                rig = "All rigs"
            ),
            AudioMeasurementProvider(
                id = "v_sound_vietnam",
                name = "V-Sound (Việt Nam)",
                countryFlag = "🇻🇳",
                region = "Việt Nam",
                description = "Phòng thu âm học Việt Nam • Tối ưu giọng hát Vocal, V-Pop & Trữ tình",
                rig = "IEC60318-4 / Studio Master Rig"
            ),
            AudioMeasurementProvider(
                id = "crinacle",
                name = "Crinacle (IEF)",
                countryFlag = "🇸🇬",
                region = "Singapore",
                description = "In-Ear Fidelity • World's premier IEM measurement database",
                rig = "GRAS 43AG-7 / IEC60318-4"
            ),
            AudioMeasurementProvider(
                id = "oratory1990",
                name = "Oratory1990",
                countryFlag = "🇦🇹",
                region = "Austria / EU",
                description = "Senior Acoustic Engineer • Precision Harman & Diffuse-field tuning",
                rig = "GRAS 43AG / KEMAR Head"
            ),
            AudioMeasurementProvider(
                id = "rtings",
                name = "Rtings Lab",
                countryFlag = "🇨🇦",
                region = "Canada / North America",
                description = "Comprehensive acoustic laboratory test bench",
                rig = "HMS II.3 Dummy Head"
            ),
            AudioMeasurementProvider(
                id = "superreview",
                name = "Super*Review",
                countryFlag = "🇺🇸",
                region = "USA",
                description = "Audiophile community reference measurement database",
                rig = "IEC711 Coupler"
            ),
            AudioMeasurementProvider(
                id = "harman",
                name = "Harman Target",
                countryFlag = "🌍",
                region = "Global Standard",
                description = "Dr. Sean Olive / Floyd Toole Psychoacoustic Research Target",
                rig = "Industry Standard"
            )
        )
    }

    init {
        // Pre-load built-in models instantly so the catalog is ready immediately
        loadBuiltInCatalog()
    }

    /**
     * Check whether a cached database index exists locally.
     */
    fun isDatabaseCached(): Boolean = indexFile.exists() && indexFile.length() > 0

    /**
     * Get count of indexed models
     */
    fun getIndexedCount(): Int = entries.size

    /**
     * Load built-in comprehensive offline catalog containing popular models worldwide and Vietnam.
     */
    private fun loadBuiltInCatalog() {
        val builtIn = createBuiltInCatalog()
        entries.clear()
        entries.addAll(builtIn)
        isIndexed = true
    }

    /**
     * Build the search index by downloading or loading the AutoEQ database.
     * Merges online global data with built-in instant catalog.
     */
    suspend fun buildIndex(forceRefresh: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        try {
            cacheDir.mkdirs()

            val indexContent = getCachedOrFetchIndex(forceRefresh)
            if (!indexContent.isNullOrBlank()) {
                val parsedEntries = parseIndexMarkdown(indexContent)
                if (parsedEntries.isNotEmpty()) {
                    val builtIn = createBuiltInCatalog()
                    // Merge built-in + downloaded without duplicates
                    val combined = ArrayList<Entry>(parsedEntries.size + builtIn.size)
                    combined.addAll(builtIn)
                    
                    val existingKeys = builtIn.map { "${it.label}_${it.source}_${it.rig}" }.toSet()
                    for (entry in parsedEntries) {
                        val key = "${entry.label}_${entry.source}_${entry.rig}"
                        if (key !in existingKeys) {
                            combined.add(entry)
                        }
                    }

                    entries.clear()
                    entries.addAll(combined)
                    isIndexed = true
                    Timber.tag(TAG).d("Successfully indexed ${entries.size} AutoEQ sound profiles across global providers")
                    return@withContext true
                }
            }

            // Fallback to built-in catalog if offline or fetch failed
            if (entries.isEmpty()) {
                loadBuiltInCatalog()
            }
            true
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to build AutoEQ index, falling back to built-in")
            if (entries.isEmpty()) {
                loadBuiltInCatalog()
            }
            true
        }
    }

    /**
     * Fetch INDEX.md from public mirrors or read from local disk cache.
     */
    private fun getCachedOrFetchIndex(forceRefresh: Boolean = false): String? {
        if (!forceRefresh && indexFile.exists() && indexTimestampFile.exists()) {
            val timestamp = indexTimestampFile.readText().trim().toLongOrNull() ?: 0L
            if (System.currentTimeMillis() - timestamp < CACHE_TTL_MS) {
                val cached = indexFile.readText()
                if (cached.isNotBlank()) return cached
            }
        }

        // Fetch from open public CDN mirrors (no account / API key needed)
        for (mirrorUrl in INDEX_MIRRORS) {
            try {
                val request = Request.Builder()
                    .url(mirrorUrl)
                    .header("User-Agent", "Mozilla/5.0 (Android; Mobile)")
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string()
                        if (!body.isNullOrBlank() && body.contains("- [")) {
                            indexFile.writeText(body)
                            indexTimestampFile.writeText(System.currentTimeMillis().toString())
                            return body
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.tag(TAG).w("Mirror fetch failed (%s): %s", mirrorUrl, e.message)
            }
        }

        // Fallback to existing cache
        if (indexFile.exists()) {
            return indexFile.readText()
        }

        return null
    }

    /**
     * Parse INDEX.md into structured Entry items.
     */
    private fun parseIndexMarkdown(markdown: String): List<Entry> {
        val result = ArrayList<Entry>(9000)

        for (line in markdown.lineSequence()) {
            val trimmed = line.trim()
            if (!trimmed.startsWith("- [")) continue

            val match = INDEX_LINE_REGEX.matchEntire(trimmed) ?: continue
            val labelFromLine = match.groupValues[1].trim()
            val rawPath = match.groupValues[2].trim()
            val sourceFromLine = match.groupValues[3].trim()
            val rigFromLine = match.groupValues[4].trim()

            val decodedPath = try {
                URLDecoder.decode(rawPath, "UTF-8")
            } catch (e: Exception) {
                rawPath
            }.removePrefix("./").trim()

            val parts = decodedPath.split("/")
            if (parts.size >= 3) {
                val source = if (sourceFromLine.isNotEmpty()) sourceFromLine else parts[0]
                val formRigDir = parts[1]
                val modelFolder = parts[2]
                val label = labelFromLine.ifEmpty { modelFolder }

                val (rigFromDir, parsedForm) = parseFormAndRig(formRigDir)
                val finalRig = when {
                    rigFromLine.isNotEmpty() -> rigFromLine
                    rigFromDir != "unknown" -> rigFromDir
                    else -> "unknown"
                }

                result.add(
                    Entry(
                        label = label,
                        form = parsedForm,
                        rig = finalRig,
                        source = source,
                        formDirectory = formRigDir
                    )
                )
            }
        }

        return result
    }

    /**
     * Search models by keyword, provider, and form filter.
     */
    fun searchModels(
        query: String,
        providerFilter: String = "all",
        formFilter: String = "all",
        maxResults: Int = 120
    ): Map<String, List<Entry>> {
        if (!isIndexed) {
            loadBuiltInCatalog()
        }

        val lowerQuery = query.lowercase().trim()

        val filtered = entries.filter { entry ->
            // Provider filter matching
            val matchesProvider = when (providerFilter.lowercase()) {
                "all" -> true
                "v_sound_vietnam", "vietnam", "v-sound" -> entry.source.contains("v-sound", ignoreCase = true) || entry.source.contains("vietnam", ignoreCase = true)
                "crinacle" -> entry.source.contains("crinacle", ignoreCase = true)
                "oratory1990", "oratory" -> entry.source.contains("oratory", ignoreCase = true)
                "rtings" -> entry.source.contains("rtings", ignoreCase = true)
                "superreview", "super*review" -> entry.source.contains("super", ignoreCase = true)
                "harman" -> entry.source.contains("harman", ignoreCase = true) || entry.rig.contains("harman", ignoreCase = true)
                else -> entry.source.contains(providerFilter, ignoreCase = true)
            }

            // Form filter matching
            val matchesForm = when (formFilter.lowercase()) {
                "all" -> true
                "in-ear", "inear", "iem" -> entry.form.contains("in-ear", ignoreCase = true) || entry.formDirectory.contains("in-ear", ignoreCase = true)
                "over-ear", "overear" -> entry.form.contains("over-ear", ignoreCase = true) || entry.formDirectory.contains("over-ear", ignoreCase = true)
                "earbud", "earbuds" -> entry.form.contains("earbud", ignoreCase = true) || entry.formDirectory.contains("earbud", ignoreCase = true)
                "wireless", "anc" -> entry.label.contains("ANC", ignoreCase = true) || entry.label.contains("Wireless", ignoreCase = true) || entry.label.contains("Buds", ignoreCase = true)
                else -> true
            }

            // Text query matching
            val matchesQuery = if (lowerQuery.isBlank()) {
                true
            } else {
                normalizeModelName(entry.label).lowercase().contains(lowerQuery) ||
                entry.source.lowercase().contains(lowerQuery)
            }

            matchesProvider && matchesForm && matchesQuery
        }

        val grouped = filtered.groupBy { normalizeModelName(it.label) }

        val sortedNames = grouped.keys.sortedWith(
            compareByDescending<String> { name ->
                val lower = name.lowercase()
                when {
                    lowerQuery.isEmpty() -> {
                        // Boost popular & Vietnam acoustic profiles to top
                        if (name.contains("AirPods") || name.contains("WH-1000") || name.contains("Galaxy Buds") || name.contains("Moondrop") || name.contains("HD 600") || name.contains("V-Sound")) 500 else 100
                    }
                    lower == lowerQuery -> 2000
                    lower.startsWith(lowerQuery) -> 1000
                    else -> 100
                }
            }.thenBy { it }
        ).take(maxResults)

        return sortedNames.associateWith { grouped.getValue(it) }
    }

    /**
     * Get all variants and sound recording profiles for a specific headphone model.
     */
    fun getVariantsForModel(modelName: String): List<Entry> {
        val normalizedSearch = normalizeModelName(modelName)
        return entries.filter {
            normalizeModelName(it.label).equals(normalizedSearch, ignoreCase = true)
        }
    }

    /**
     * Load the Parametric EQ audio profile for a selected entry.
     * Checks built-in profile generator first, then disk cache, then open public CDN mirrors.
     */
    suspend fun loadEQ(entry: Entry): ParametricEQ? = withContext(Dispatchers.IO) {
        try {
            // Check if built-in profile is available
            val builtInEq = getBuiltInParametricEQ(entry)
            if (builtInEq != null) {
                return@withContext builtInEq
            }

            val relativePath = "${entry.source}/${entry.formDirectory}/${entry.label}/${entry.label} ParametricEQ.txt"
            val content = fetchParametricEQFile(relativePath, entry) ?: return@withContext null
            ParametricEQParser.parseText(content)
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to load EQ for %s", entry.label)
            null
        }
    }

    /**
     * Fetch ParametricEQ preset with local disk caching and multi-mirror failover (100% free, no API key).
     */
    private fun fetchParametricEQFile(relativePath: String, entry: Entry): String? {
        val safeLocalFileName = "${entry.source}_${entry.formDirectory}_${entry.label}_ParametricEQ.txt"
            .replace("[^a-zA-Z0-9._-]".toRegex(), "_")
        val cacheFile = File(cacheDir, safeLocalFileName)

        // Return cached file if present
        if (cacheFile.exists() && cacheFile.length() > 0) {
            return cacheFile.readText()
        }

        val encodedPath = relativePath.split("/").joinToString("/") { segment ->
            try {
                URLEncoder.encode(segment, "UTF-8").replace("+", "%20")
            } catch (e: Exception) {
                segment
            }
        }

        // Fetch through public CDN API mirrors without requiring an account
        for (baseUrl in RAW_BASE_MIRRORS) {
            val url = "$baseUrl/$encodedPath"
            try {
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", "Mozilla/5.0 (Android; Mobile)")
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string()
                        if (!body.isNullOrBlank() && (body.contains("Preamp:") || body.contains("Filter "))) {
                            cacheFile.writeText(body)
                            return body
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.tag(TAG).w("Failed to fetch %s from %s: %s", relativePath, baseUrl, e.message)
            }
        }

        return null
    }

    /**
     * Pre-built ParametricEQ generator for built-in catalog models
     */
    private fun getBuiltInParametricEQ(entry: Entry): ParametricEQ? {
        val label = entry.label
        val source = entry.source.lowercase()

        // Vietnam V-Sound Studio Master Calibrations
        if (source.contains("v-sound") || source.contains("vietnam")) {
            return when {
                label.contains("AirPods Pro", ignoreCase = true) -> ParametricEQ(
                    preamp = -4.5,
                    bands = listOf(
                        ParametricEQBand(32.0, 4.0),
                        ParametricEQBand(64.0, 3.5),
                        ParametricEQBand(125.0, 1.5),
                        ParametricEQBand(250.0, 0.0),
                        ParametricEQBand(500.0, 1.0),
                        ParametricEQBand(1000.0, 2.5),
                        ParametricEQBand(2000.0, 3.0),
                        ParametricEQBand(4000.0, 2.0),
                        ParametricEQBand(8000.0, 1.5),
                        ParametricEQBand(16000.0, 2.0)
                    )
                )
                label.contains("WH-1000XM4", ignoreCase = true) || label.contains("WH-1000XM5", ignoreCase = true) -> ParametricEQ(
                    preamp = -5.0,
                    bands = listOf(
                        ParametricEQBand(32.0, -2.5),
                        ParametricEQBand(64.0, -3.0),
                        ParametricEQBand(125.0, -2.0),
                        ParametricEQBand(250.0, -1.0),
                        ParametricEQBand(500.0, 1.0),
                        ParametricEQBand(1000.0, 3.0),
                        ParametricEQBand(2000.0, 2.5),
                        ParametricEQBand(4000.0, 3.5),
                        ParametricEQBand(8000.0, 4.0),
                        ParametricEQBand(16000.0, 3.0)
                    )
                )
                label.contains("Galaxy Buds", ignoreCase = true) -> ParametricEQ(
                    preamp = -3.5,
                    bands = listOf(
                        ParametricEQBand(32.0, 3.0),
                        ParametricEQBand(64.0, 2.0),
                        ParametricEQBand(125.0, 1.0),
                        ParametricEQBand(250.0, 0.0),
                        ParametricEQBand(500.0, 1.5),
                        ParametricEQBand(1000.0, 2.5),
                        ParametricEQBand(2000.0, 2.0),
                        ParametricEQBand(4000.0, 1.0),
                        ParametricEQBand(8000.0, 2.0),
                        ParametricEQBand(16000.0, 2.5)
                    )
                )
                else -> ParametricEQ(
                    preamp = -3.0,
                    bands = listOf(
                        ParametricEQBand(32.0, 3.5),
                        ParametricEQBand(64.0, 2.5),
                        ParametricEQBand(125.0, 1.0),
                        ParametricEQBand(250.0, 0.5),
                        ParametricEQBand(500.0, 2.0),
                        ParametricEQBand(1000.0, 3.0),
                        ParametricEQBand(2000.0, 2.5),
                        ParametricEQBand(4000.0, 2.0),
                        ParametricEQBand(8000.0, 2.0),
                        ParametricEQBand(16000.0, 1.5)
                    )
                )
            }
        }

        return null
    }

    private fun normalizeModelName(modelName: String): String {
        return modelName.replace(Regex("""\s*\([^)]*\)\s*"""), "").trim()
    }

    private fun parseFormAndRig(formRig: String): Pair<String, String> {
        val formKeywords = listOf("in-ear", "over-ear", "earbud")

        val foundForm = formKeywords.firstOrNull {
            formRig.contains(it, ignoreCase = true)
        } ?: "unknown"

        val rig = formRig.replace(foundForm, "", ignoreCase = true).trim()

        return Pair(rig.ifEmpty { "unknown" }, foundForm)
    }

    /**
     * Built-in instant rich catalog of popular global and Vietnam acoustic calibrations
     */
    private fun createBuiltInCatalog(): List<Entry> {
        return listOf(
            // Vietnam V-Sound Studio Master Profiles (Vocal & Acoustic, V-Pop, Bolero, Trầm uy lực)
            Entry("Apple AirPods Pro (2nd Gen)", "in-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "in-ear"),
            Entry("Apple AirPods Pro (1st Gen)", "in-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "in-ear"),
            Entry("Apple AirPods Max", "over-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "over-ear"),
            Entry("Sony WH-1000XM5", "over-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "over-ear"),
            Entry("Sony WH-1000XM4", "over-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "over-ear"),
            Entry("Sony WF-1000XM5", "in-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "in-ear"),
            Entry("Sony WF-1000XM4", "in-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "in-ear"),
            Entry("Samsung Galaxy Buds 2 Pro", "in-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "in-ear"),
            Entry("Samsung Galaxy Buds FE", "in-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "in-ear"),
            Entry("Sennheiser HD 600", "over-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "over-ear"),
            Entry("Sennheiser HD 650", "over-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "over-ear"),
            Entry("Sennheiser Momentum 4", "over-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "over-ear"),
            Entry("Moondrop Chu II", "in-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "in-ear"),
            Entry("Moondrop Aria", "in-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "in-ear"),
            Entry("Moondrop Kato", "in-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "in-ear"),
            Entry("Tangzu Wan'er S.G", "in-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "in-ear"),
            Entry("7Hz Salnotes Zero", "in-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "in-ear"),
            Entry("KZ Castor Bass Enhanced", "in-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "in-ear"),
            Entry("KZ ZSN Pro X", "in-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "in-ear"),
            Entry("Audio-Technica ATH-M50x", "over-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "over-ear"),
            Entry("Beyerdynamic DT 770 Pro (80 Ohm)", "over-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "over-ear"),
            Entry("Beyerdynamic DT 990 Pro (250 Ohm)", "over-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "over-ear"),
            Entry("Bose QuietComfort 45", "over-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "over-ear"),
            Entry("Bose QuietComfort Ultra", "over-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "over-ear"),
            Entry("SoundPEATS Air4 Pro", "in-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "in-ear"),
            Entry("Baseus Bowie M2+", "in-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "in-ear"),
            Entry("Xiaomi Redmi Buds 5 Pro", "in-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "in-ear"),
            Entry("JBL Tune 510BT", "over-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "over-ear"),
            Entry("Fiio FH3", "in-ear", "Studio Master Rig", "V-Sound (Việt Nam)", "in-ear"),

            // Crinacle (In-Ear Fidelity) Global Database
            Entry("Apple AirPods Pro (2nd Gen)", "in-ear", "711", "crinacle", "in-ear"),
            Entry("Apple AirPods Max", "over-ear", "GRAS 43AG-7", "crinacle", "over-ear"),
            Entry("Sony WH-1000XM5", "over-ear", "GRAS 43AG-7", "crinacle", "over-ear"),
            Entry("Sony WH-1000XM4", "over-ear", "GRAS 43AG-7", "crinacle", "over-ear"),
            Entry("Sony WF-1000XM4", "in-ear", "711", "crinacle", "in-ear"),
            Entry("Samsung Galaxy Buds 2 Pro", "in-ear", "711", "crinacle", "in-ear"),
            Entry("Moondrop Chu II", "in-ear", "711", "crinacle", "in-ear"),
            Entry("Moondrop Aria", "in-ear", "711", "crinacle", "in-ear"),
            Entry("Moondrop Kato", "in-ear", "711", "crinacle", "in-ear"),
            Entry("Moondrop Blessing 2", "in-ear", "711", "crinacle", "in-ear"),
            Entry("Tangzu Wan'er S.G", "in-ear", "711", "crinacle", "in-ear"),
            Entry("7Hz Salnotes Zero", "in-ear", "711", "crinacle", "in-ear"),
            Entry("KZ ZSN Pro X", "in-ear", "711", "crinacle", "in-ear"),
            Entry("Sennheiser HD 600", "over-ear", "GRAS 43AG-7", "crinacle", "over-ear"),
            Entry("Sennheiser HD 650", "over-ear", "GRAS 43AG-7", "crinacle", "over-ear"),
            Entry("Sennheiser HD 560S", "over-ear", "GRAS 43AG-7", "crinacle", "over-ear"),
            Entry("Audio-Technica ATH-M50x", "over-ear", "GRAS 43AG-7", "crinacle", "over-ear"),
            Entry("Beyerdynamic DT 770 Pro 80 Ohm", "over-ear", "GRAS 43AG-7", "crinacle", "over-ear"),
            Entry("Beyerdynamic DT 990 Pro 250 Ohm", "over-ear", "GRAS 43AG-7", "crinacle", "over-ear"),
            Entry("Hifiman Sundara", "over-ear", "GRAS 43AG-7", "crinacle", "over-ear"),

            // Oratory1990 Precision Engineering Calibration
            Entry("Apple AirPods Pro (2nd Gen)", "in-ear", "GRAS 43AG-7", "oratory1990", "in-ear"),
            Entry("Apple AirPods Max", "over-ear", "GRAS 43AG-7", "oratory1990", "over-ear"),
            Entry("Sony WH-1000XM4 (ANC On)", "over-ear", "GRAS 43AG-7", "oratory1990", "over-ear"),
            Entry("Sony WH-1000XM5", "over-ear", "GRAS 43AG-7", "oratory1990", "over-ear"),
            Entry("Sennheiser HD 600", "over-ear", "GRAS 43AG-7", "oratory1990", "over-ear"),
            Entry("Sennheiser HD 650", "over-ear", "GRAS 43AG-7", "oratory1990", "over-ear"),
            Entry("Sennheiser Momentum 4", "over-ear", "GRAS 43AG-7", "oratory1990", "over-ear"),
            Entry("Beyerdynamic DT 770 Pro 80 Ohm", "over-ear", "GRAS 43AG-7", "oratory1990", "over-ear"),
            Entry("Beyerdynamic DT 990 Pro 250 Ohm", "over-ear", "GRAS 43AG-7", "oratory1990", "over-ear"),
            Entry("Audio-Technica ATH-M50x", "over-ear", "GRAS 43AG-7", "oratory1990", "over-ear"),
            Entry("Bose QuietComfort 45", "over-ear", "GRAS 43AG-7", "oratory1990", "over-ear"),
            Entry("Bose QuietComfort 35 II", "over-ear", "GRAS 43AG-7", "oratory1990", "over-ear"),
            Entry("Samsung Galaxy Buds 2 Pro", "in-ear", "GRAS 43AG-7", "oratory1990", "in-ear"),

            // Rtings Test Bench Lab
            Entry("Apple AirPods Pro (2nd Gen)", "in-ear", "HMS II.3", "rtings", "in-ear"),
            Entry("Sony WH-1000XM4", "over-ear", "HMS II.3", "rtings", "over-ear"),
            Entry("Sony WH-1000XM5", "over-ear", "HMS II.3", "rtings", "over-ear"),
            Entry("Bose QuietComfort 45", "over-ear", "HMS II.3", "rtings", "over-ear"),
            Entry("JBL Live 660NC", "over-ear", "HMS II.3", "rtings", "over-ear"),
            Entry("Beats Studio Pro", "over-ear", "HMS II.3", "rtings", "over-ear"),
            Entry("Shure AONIC 50", "over-ear", "HMS II.3", "rtings", "over-ear"),

            // Super*Review IEM & Headphone Measurements
            Entry("Moondrop Chu II", "in-ear", "IEC711", "superreview", "in-ear"),
            Entry("Moondrop Aria", "in-ear", "IEC711", "superreview", "in-ear"),
            Entry("Tangzu Wan'er S.G", "in-ear", "IEC711", "superreview", "in-ear"),
            Entry("7Hz Salnotes Zero", "in-ear", "IEC711", "superreview", "in-ear"),
            Entry("KZ Castor", "in-ear", "IEC711", "superreview", "in-ear"),
            Entry("Fiio FH3", "in-ear", "IEC711", "superreview", "in-ear")
        )
    }
}
