/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.playback

import java.util.Random
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * Representation of a track in queue for Smart Shuffle analysis
 */
data class ShuffleTrack(
    val index: Int,
    val mediaId: String,
    val artist: String? = null,
    val album: String? = null,
    val playCount: Int = 0,
    val durationMs: Long = 0L,
    val isOriginal: Boolean = true,
)

/**
 * Smart Shuffle Engine
 *
 * Implements an intelligent shuffle algorithm that:
 * 1. Prioritizes less-frequently listened tracks (discovery & rediscovery of library/playlist songs).
 * 2. Maintains musical flow cohesion by:
 *    - Preventing jarring artist and album clustering (anti-repetition distance penalties).
 *    - Interleaving familiar anchor tracks smoothly with less-played gems.
 *    - Ensuring smooth transition dynamics across the entire playback queue.
 * 3. Preserves currently playing song at position 0 so playback continues seamlessly.
 * 4. Respects playlist-first partitioning when enabled.
 * 5. Guarantees mathematical completeness (100% valid permutation, no duplicates, no missing indices).
 */
object SmartShuffleEngine {

    // Tuning constants
    private const val PLAY_COUNT_DECAY_EXPONENT = 0.85
    private const val UNPLAYED_EXPLORATION_BOOST = 1.30
    private const val SAME_ARTIST_PREV_1_PENALTY = 0.08
    private const val SAME_ARTIST_PREV_2_PENALTY = 0.35
    private const val SAME_ARTIST_PREV_3_PENALTY = 0.70
    private const val SAME_ALBUM_PREV_1_PENALTY = 0.12
    private const val SAME_ALBUM_PREV_2_PENALTY = 0.45

    /**
     * Internal normalized representation for ultra-fast processing
     */
    private class FastTrack(
        val originalIndex: Int,
        val normArtist: String?,
        val normAlbum: String?,
        val baseLogWeight: Double,
    )

    /**
     * Calculates the base discovery weight for a song based on lifetime play count.
     * Lower play counts yield higher weights.
     */
    fun calculateDiscoveryWeight(playCount: Int): Double {
        val nonNegativePlayCount = max(0, playCount)
        val base = 1.0 / (1.0 + nonNegativePlayCount.toDouble()).pow(PLAY_COUNT_DECAY_EXPONENT)
        return if (nonNegativePlayCount == 0) {
            base * UNPLAYED_EXPLORATION_BOOST
        } else {
            base
        }
    }

    /**
     * Calculates the cohesion factor (anti-clustering penalty) based on recently queued artists/albums.
     */
    fun calculateCohesionFactor(
        normArtist: String?,
        normAlbum: String?,
        recentArtists: List<String>,
        recentAlbums: List<String>,
    ): Double {
        var factor = 1.0

        if (normArtist != null) {
            val dist = recentArtists.indexOf(normArtist)
            if (dist != -1) {
                factor *= when (dist) {
                    0 -> SAME_ARTIST_PREV_1_PENALTY
                    1 -> SAME_ARTIST_PREV_2_PENALTY
                    2 -> SAME_ARTIST_PREV_3_PENALTY
                    else -> 0.90
                }
            }
        }

        if (normAlbum != null) {
            val dist = recentAlbums.indexOf(normAlbum)
            if (dist != -1) {
                factor *= when (dist) {
                    0 -> SAME_ALBUM_PREV_1_PENALTY
                    1 -> SAME_ALBUM_PREV_2_PENALTY
                    else -> 0.85
                }
            }
        }

        return max(0.001, factor)
    }

    /**
     * Fast O(1) removal from ArrayList by swapping with last element
     */
    private fun <T> ArrayList<T>.swapRemoveAt(index: Int): T {
        val lastIdx = this.size - 1
        if (index != lastIdx) {
            val lastItem = this[lastIdx]
            this[index] = lastItem
        }
        return this.removeAt(lastIdx)
    }

    /**
     * Shuffles a subset pool of tracks with Smart Shuffle rules in O(N log N) / high efficiency.
     */
    private fun smartShufflePool(
        pool: List<ShuffleTrack>,
        currentTrackIndex: Int?,
        random: Random,
    ): List<Int> {
        if (pool.isEmpty()) return emptyList()
        if (pool.size == 1) return listOf(pool[0].index)

        val remaining = ArrayList<FastTrack>(pool.size)
        for (track in pool) {
            val normArtist = track.artist?.trim()?.lowercase()?.takeIf { it.isNotBlank() }
            val normAlbum = track.album?.trim()?.lowercase()?.takeIf { it.isNotBlank() }
            val baseWeight = calculateDiscoveryWeight(track.playCount)
            val baseLogWeight = ln(max(0.00001, baseWeight))
            remaining.add(FastTrack(track.index, normArtist, normAlbum, baseLogWeight))
        }

        val orderedIndices = ArrayList<Int>(pool.size)
        val recentArtists = ArrayDeque<String>(4)
        val recentAlbums = ArrayDeque<String>(4)

        // If currentTrackIndex is in this pool, place it first
        if (currentTrackIndex != null) {
            val currentIdxInRemaining = remaining.indexOfFirst { it.originalIndex == currentTrackIndex }
            if (currentIdxInRemaining != -1) {
                val currentTrack = remaining.swapRemoveAt(currentIdxInRemaining)
                orderedIndices.add(currentTrack.originalIndex)
                currentTrack.normArtist?.let { recentArtists.addFirst(it) }
                currentTrack.normAlbum?.let { recentAlbums.addFirst(it) }
            }
        }

        // Iteratively pick next track using weighted Gumbel-Max stochastic sampling with cohesion adjustment
        while (remaining.isNotEmpty()) {
            val remainingSize = remaining.size
            if (remainingSize == 1) {
                orderedIndices.add(remaining.removeAt(0).originalIndex)
                break
            }

            // For ultra large pools (> 200 items), evaluate a candidate window of items plus random samples
            // to maintain O(N) performance while keeping 100% cohesion and stochasticity
            val candidateCount = if (remainingSize > 250) min(100, remainingSize) else remainingSize

            var bestTrack: FastTrack? = null
            var bestKey = Double.NEGATIVE_INFINITY
            var bestIndex = -1

            val recentArtistsList = recentArtists.toList()
            val recentAlbumsList = recentAlbums.toList()

            for (c in 0 until candidateCount) {
                val i = if (candidateCount == remainingSize) c else (c * (remainingSize / candidateCount) + random.nextInt(remainingSize / candidateCount)).coerceIn(0, remainingSize - 1)
                val candidate = remaining[i]
                val cohesionFactor = calculateCohesionFactor(candidate.normArtist, candidate.normAlbum, recentArtistsList, recentAlbumsList)
                val cohesionLog = ln(cohesionFactor)

                // Gumbel-max trick: key = baseLogWeight + cohesionLog - ln(-ln(U)) where U ~ Uniform(0, 1)
                val u = max(0.000001, random.nextDouble())
                val gumbelNoise = -ln(-ln(u))
                val key = candidate.baseLogWeight + cohesionLog + gumbelNoise

                if (key > bestKey) {
                    bestKey = key
                    bestTrack = candidate
                    bestIndex = i
                }
            }

            if (bestTrack != null && bestIndex >= 0) {
                orderedIndices.add(bestTrack.originalIndex)
                remaining.swapRemoveAt(bestIndex)

                // Update recent history
                bestTrack.normArtist?.let {
                    if (recentArtists.size >= 3) recentArtists.removeLast()
                    recentArtists.addFirst(it)
                }
                bestTrack.normAlbum?.let {
                    if (recentAlbums.size >= 2) recentAlbums.removeLast()
                    recentAlbums.addFirst(it)
                }
            } else {
                orderedIndices.add(remaining.swapRemoveAt(0).originalIndex)
            }
        }

        return orderedIndices
    }

    /**
     * Generates a complete smart shuffle permutation array for the given tracks.
     */
    fun generateSmartShuffleOrder(
        tracks: List<ShuffleTrack>,
        currentIndex: Int,
        shufflePlaylistFirst: Boolean = false,
        originalQueueSize: Int = 0,
        random: Random = Random(),
    ): IntArray {
        val totalCount = tracks.size
        if (totalCount == 0) return IntArray(0)
        if (totalCount == 1) return intArrayOf(tracks[0].index)

        val validCurrentIndex = if (currentIndex in 0 until totalCount) currentIndex else 0

        val resultList: List<Int> = if (shufflePlaylistFirst && originalQueueSize in 1 until totalCount) {
            val originalPool = tracks.filter { it.index < originalQueueSize }
            val addedPool = tracks.filter { it.index >= originalQueueSize }

            if (validCurrentIndex < originalQueueSize) {
                val shuffledOriginal = smartShufflePool(originalPool, validCurrentIndex, random)
                val shuffledAdded = smartShufflePool(addedPool, null, random)
                shuffledOriginal + shuffledAdded
            } else {
                val shuffledAdded = smartShufflePool(addedPool, validCurrentIndex, random)
                val shuffledOriginal = smartShufflePool(originalPool, null, random)
                shuffledAdded + shuffledOriginal
            }
        } else {
            smartShufflePool(tracks, validCurrentIndex, random)
        }

        // Convert to IntArray and perform strict invariant verification
        val resultArray = IntArray(totalCount)
        var pos = 0

        // Ensure currentIndex is strictly at position 0
        resultArray[pos++] = validCurrentIndex
        val seen = HashSet<Int>(totalCount)
        seen.add(validCurrentIndex)

        for (idx in resultList) {
            if (idx != validCurrentIndex && idx in 0 until totalCount && seen.add(idx)) {
                if (pos < totalCount) {
                    resultArray[pos++] = idx
                }
            }
        }

        // Safety fallback: fill any missing indices
        if (pos < totalCount) {
            for (i in 0 until totalCount) {
                if (seen.add(i)) {
                    resultArray[pos++] = i
                    if (pos == totalCount) break
                }
            }
        }

        return resultArray
    }
}
