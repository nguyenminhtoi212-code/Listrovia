plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.ksp)
    alias(libs.plugins.hilt.android)
    alias(libs.plugins.kotlin.serialization)
}

android {
    namespace = "com.listrovia.music"
    compileSdk = 36

    val lastFmKey = System.getenv("LASTFM_API_KEY") ?: (project.findProperty("LASTFM_API_KEY") as? String) ?: ""
    val lastFmSecret = System.getenv("LASTFM_SECRET") ?: (project.findProperty("LASTFM_SECRET") as? String) ?: ""

    defaultConfig {
        applicationId = "com.aistudio.listrovia.prvqyn"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "1.0.2"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // Cấu hình MultiDex (Tự động bật từ API 21+, không cần đặt false gây giới hạn số lượng method)
        // multiDexEnabled = true // Có thể bỏ qua hoặc bật nếu cần thiết, không đặt false

        // Loại bỏ giới hạn ABI để hỗ trợ đầy đủ thiết bị và máy ảo giả lập (x86, x86_64, arm64-v8a, armeabi-v7a)
        ndk {
            abiFilters.clear()
            abiFilters.addAll(setOf("arm64-v8a", "armeabi-v7a", "x86_64", "x86"))
        }

        buildConfigField("Boolean", "CAST_AVAILABLE", "true")
        buildConfigField("String", "ARCHITECTURE", "\"universal\"")
        buildConfigField("Boolean", "UPDATER_AVAILABLE", "false")
        buildConfigField("String", "LASTFM_API_KEY", "\"$lastFmKey\"")
        buildConfigField("String", "LASTFM_SECRET", "\"$lastFmSecret\"")
        buildConfigField("String", "DISCORD_APP_ID", "\"1447278780795064401\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            isDebuggable = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }

    sourceSets {
        getByName("main") {
            java.srcDirs("src/main/java", "src/main/kotlin")
        }
    }

    compileOptions {
        isCoreLibraryDesugaringEnabled = false
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
        viewBinding = true
    }

    packaging {
        resources {
            pickFirsts += setOf("**/kotlin/**", "**/org/**")
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "/META-INF/CONTRIBUTORS.md",
                "/META-INF/README*",
                "/META-INF/LICENSE*",
                "/META-INF/NOTICE*",
                "/META-INF/INDEX.LIST",
                "/META-INF/DEPENDENCIES",
                "/META-INF/*.kotlin_module",
                "**/*.proto",
                "**/*.html"
            )
            // Keep assets html
            pickFirsts += setOf("assets/po_token.html")
        }
        jniLibs {
            useLegacyPackaging = true
            pickFirsts += setOf("**/lib*.so")
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    // --- Desugaring Core (Disabled for minSdk 26+ and multiDexEnabled=false) ---
    // coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")

    // --- AndroidX Core & Lifecycle ---
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.7.0")
    implementation("androidx.lifecycle:lifecycle-process:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation(libs.androidx.activity.compose)
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    // --- Jetpack Compose UI ---
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.8.5")

    // --- Dependency Injection (Hilt) ---
    implementation("com.google.dagger:hilt-android:2.59.2")
    ksp("com.google.dagger:hilt-compiler:2.59.2")
    implementation("androidx.hilt:hilt-navigation-compose:1.1.0")

    // --- Database (Room) ---
    implementation("androidx.room:room-runtime:2.7.0")
    implementation("androidx.room:room-ktx:2.7.0")
    ksp("androidx.room:room-compiler:2.7.0")

    // --- Media3 Engine ---
    implementation("androidx.media3:media3-exoplayer:1.2.1")
    implementation("androidx.media3:media3-session:1.2.1")
    implementation("androidx.media3:media3-common:1.2.1")
    implementation("androidx.media3:media3-datasource:1.2.1")
    implementation("androidx.media3:media3-datasource-okhttp:1.2.1")
    implementation("androidx.media3:media3-extractor:1.2.1")
    implementation("androidx.media3:media3-ui:1.2.1")
    implementation("androidx.media3:media3-cast:1.2.1")

    // --- Network & Ktor ---
    implementation("io.ktor:ktor-client-core:2.3.8")
    implementation("io.ktor:ktor-client-okhttp:2.3.8")
    implementation("io.ktor:ktor-client-cio:2.3.8")
    implementation("io.ktor:ktor-client-content-negotiation:2.3.8")
    implementation("io.ktor:ktor-serialization-kotlinx-json:2.3.8")
    implementation("io.ktor:ktor-client-encoding:2.3.8")
    implementation("io.ktor:ktor-client-websockets:2.3.8")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // --- Image Loading (Coil3) ---
    implementation("io.coil-kt.coil3:coil-compose:3.0.0-alpha06")
    implementation("io.coil-kt.coil3:coil-network-okhttp:3.0.0-alpha06")

    // --- Google Services & Cast ---
    implementation("com.google.android.gms:play-services-cast-framework:21.4.0")
    implementation("com.google.guava:guava:33.0.0-android")

    // --- Serialization, Protobuf & Logging ---
    implementation("com.google.protobuf:protobuf-javalite:3.25.2")
    implementation("com.google.protobuf:protobuf-kotlin-lite:3.25.2")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-guava:1.8.0")
    implementation("com.jakewharton.timber:timber:5.0.1")

    // --- UI Helpers & Utilities ---
    implementation("com.materialkolor:material-kolor:1.4.0")
    implementation("com.valentinilk.shimmer:compose-shimmer:1.2.0")
    implementation("sh.calvin.reorderable:reorderable:1.3.2")
    implementation("com.atilika.kuromoji:kuromoji-ipadic:0.9.0")
    implementation("com.github.TeamNewPipe:NewPipeExtractor:v0.22.6")
    implementation("com.github.yalantis:ucrop:2.2.8")
    implementation("org.apache.commons:commons-lang3:3.14.0")

    // --- AndroidX System Extras ---
    implementation("androidx.palette:palette-ktx:1.0.0")
    implementation("androidx.graphics:graphics-shapes:1.0.0-alpha05")
    implementation("androidx.mediarouter:mediarouter:1.7.0")
    implementation("androidx.browser:browser:1.8.0")
    implementation("androidx.work:work-runtime-ktx:2.9.1")

    // --- Firebase Platform ---
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-crashlytics")
    implementation("com.google.firebase:firebase-analytics") {
        exclude(group = "androidx.privacysandbox.ads", module = "ads-adservices")
        exclude(group = "androidx.privacysandbox.ads", module = "ads-adservices-java")
    }
    implementation("com.google.firebase:firebase-perf")

    // --- Testing ---
    testImplementation(libs.junit)
    testImplementation("org.robolectric:robolectric:4.12.2")
    testImplementation("androidx.test:core-ktx:1.5.0")
    testImplementation("io.ktor:ktor-client-mock:2.3.8")
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    debugImplementation(libs.androidx.ui.tooling)
}

tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile>().configureEach {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
        freeCompilerArgs.addAll(
            "-Xjsr305=strict",
            "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api",
            "-opt-in=androidx.compose.foundation.ExperimentalFoundationApi",
            "-opt-in=androidx.compose.foundation.layout.ExperimentalLayoutApi",
            "-opt-in=androidx.compose.ui.ExperimentalComposeUiApi",
            "-opt-in=kotlinx.coroutines.ExperimentalCoroutinesApi",
            "-opt-in=kotlinx.coroutines.FlowPreview"
        )
    }
}

tasks.register<Copy>("copyDebugApkToOutputs") {
    from(layout.buildDirectory.dir("outputs/apk/debug"))
    include("app-debug.apk")
    into(rootProject.layout.projectDirectory.dir("build-outputs"))
    doLast {
        val dotOutputs = rootProject.layout.projectDirectory.dir(".build-outputs").asFile
        dotOutputs.mkdirs()
        val src = layout.buildDirectory.file("outputs/apk/debug/app-debug.apk").get().asFile
        if (src.exists()) {
            src.copyTo(File(dotOutputs, "app-debug.apk"), overwrite = true)
        }
    }
}

tasks.matching { it.name == "assembleDebug" }.configureEach {
    finalizedBy("copyDebugApkToOutputs")
}
