package coil3

import android.graphics.Bitmap
import androidx.core.graphics.drawable.toBitmap

fun Image.toBitmap(): Bitmap {
    return (this as? BitmapImage)?.bitmap 
        ?: (this as? DrawableImage)?.drawable?.toBitmap() 
        ?: Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
}
