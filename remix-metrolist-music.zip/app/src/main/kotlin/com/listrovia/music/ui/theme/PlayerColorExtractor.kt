/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.palette.graphics.Palette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Encapsulates the extracted color palette derived from album artwork.
 */
data class PlayerPaletteColors(
    val dominant: Color,
    val vibrant: Color,
    val darkVibrant: Color,
    val lightVibrant: Color,
    val muted: Color,
    val darkMuted: Color,
    val lightMuted: Color,
    val seedColor: Color,
    val gradientColors: List<Color>,
    val accentGlow: Color,
    val onDominantText: Color,
    val isDarkArtwork: Boolean = true,
)

/**
 * Player color extraction system for generating gradients and dynamic theme accents from album artwork
 * using the AndroidX Palette API.
 */
object PlayerColorExtractor {

    /**
     * Extracts a complete set of theme and player colors from a Palette instance.
     */
    fun extractPaletteColors(
        palette: Palette,
        fallbackColor: Color = DefaultThemeColor,
        isDarkTheme: Boolean = true,
    ): PlayerPaletteColors {
        val dominantRgb = palette.dominantSwatch?.rgb ?: palette.getDominantColor(fallbackColor.toArgb())
        val dominant = Color(dominantRgb)

        val vibrant = palette.vibrantSwatch?.rgb?.let { Color(it) } ?: dominant
        val darkVibrant = palette.darkVibrantSwatch?.rgb?.let { Color(it) }
            ?: enhanceColorVividness(dominant, 0.8f).copy(alpha = 1f)
        val lightVibrant = palette.lightVibrantSwatch?.rgb?.let { Color(it) }
            ?: enhanceColorVividness(dominant, 1.2f).copy(alpha = 1f)

        val muted = palette.mutedSwatch?.rgb?.let { Color(it) } ?: dominant
        val darkMuted = palette.darkMutedSwatch?.rgb?.let { Color(it) } ?: dominant
        val lightMuted = palette.lightMutedSwatch?.rgb?.let { Color(it) } ?: dominant

        val seedColor = extractPrimarySeedColor(palette, fallbackColor)

        // Accent glow: choose vibrant if available, otherwise dominant enhanced
        val accentGlow = if (isColorVibrant(vibrant)) {
            enhanceColorVividness(vibrant, 1.35f)
        } else if (isColorVibrant(lightVibrant)) {
            lightVibrant
        } else {
            enhanceColorVividness(dominant, 1.2f)
        }

        // Determine if artwork is predominantly dark or light
        val dominantHsv = FloatArray(3)
        android.graphics.Color.colorToHSV(dominantRgb, dominantHsv)
        val isDark = dominantHsv[2] < 0.5f

        val onDominantText = if (isDark) Color.White else Color(0xFF1C1B1F)

        // Generate dynamic atmospheric gradient stops
        val primaryColor = if (isColorVibrant(accentGlow)) accentGlow else enhanceColorVividness(dominant, 1.1f)
        val gradient = listOf(
            primaryColor,
            primaryColor.copy(
                red = (primaryColor.red * 0.55f).coerceAtLeast(0f),
                green = (primaryColor.green * 0.55f).coerceAtLeast(0f),
                blue = (primaryColor.blue * 0.55f).coerceAtLeast(0f),
            ),
            if (isDarkTheme) Color.Black else Color(0xFF121212),
        )

        return PlayerPaletteColors(
            dominant = dominant,
            vibrant = vibrant,
            darkVibrant = darkVibrant,
            lightVibrant = lightVibrant,
            muted = muted,
            darkMuted = darkMuted,
            lightMuted = lightMuted,
            seedColor = seedColor,
            gradientColors = gradient,
            accentGlow = accentGlow,
            onDominantText = onDominantText,
            isDarkArtwork = isDark,
        )
    }

    /**
     * Extracts a primary seed color for dynamic theme color scheme generation
     *
     * @param palette The color palette extracted from album artwork
     * @param fallbackColor Fallback color to use if extraction fails
     * @return Primary seed color for Material 3 dynamic color scheme
     */
    fun extractPrimarySeedColor(
        palette: Palette,
        fallbackColor: Color = DefaultThemeColor,
    ): Color {
        val colorCandidates = listOfNotNull(
            palette.vibrantSwatch,
            palette.dominantSwatch,
            palette.darkVibrantSwatch,
            palette.lightVibrantSwatch,
            palette.mutedSwatch,
            palette.darkMutedSwatch,
            palette.lightMutedSwatch,
        )

        val bestSwatch = colorCandidates.maxByOrNull { calculateColorWeight(it) }
        val fallbackDominant = palette.dominantSwatch?.rgb?.let { Color(it) }
            ?: Color(palette.getDominantColor(fallbackColor.toArgb()))

        return if (bestSwatch != null) {
            val bestColor = Color(bestSwatch.rgb)
            if (isColorVibrant(bestColor)) {
                bestColor
            } else {
                fallbackDominant
            }
        } else {
            fallbackDominant
        }
    }

    /**
     * Extracts colors from a palette and creates a gradient
     * 
     * @param palette The color palette extracted from album artwork
     * @param fallbackColor Fallback color to use if extraction fails
     * @return List of colors for gradient (primary, darker variant, black)
     */
    suspend fun extractGradientColors(
        palette: Palette,
        fallbackColor: Int,
    ): List<Color> = withContext(Dispatchers.Default) {
        
        // Extract all available colors with priority for dominant colors
        val colorCandidates = listOfNotNull(
            palette.dominantSwatch, // High priority for dominant color
            palette.vibrantSwatch,
            palette.darkVibrantSwatch,
            palette.lightVibrantSwatch,
            palette.mutedSwatch,
            palette.darkMutedSwatch,
            palette.lightMutedSwatch,
        )

        // Select best color based on weight (dominance + vibrancy)
        val bestSwatch = colorCandidates.maxByOrNull { calculateColorWeight(it) }
        val fallbackDominant = palette.dominantSwatch?.rgb?.let { Color(it) }
            ?: Color(palette.getDominantColor(fallbackColor))

        val primaryColor = if (bestSwatch != null) {
            val bestColor = Color(bestSwatch.rgb)
            // Ensure the color is suitable for use
            if (isColorVibrant(bestColor)) {
                enhanceColorVividness(bestColor, 1.3f)
            } else {
                // If not vibrant, use dominant color with slight enhancement
                enhanceColorVividness(fallbackDominant, 1.1f)
            }
        } else {
            enhanceColorVividness(fallbackDominant, 1.1f)
        }
        
        // Create sophisticated gradient with 3 color points
        listOf(
            primaryColor, // Start: primary vibrant color
            primaryColor.copy(
                red = (primaryColor.red * 0.6f).coerceAtLeast(0f),
                green = (primaryColor.green * 0.6f).coerceAtLeast(0f),
                blue = (primaryColor.blue * 0.6f).coerceAtLeast(0f),
            ), // Middle: darker version of primary color
            Color.Black, // End: black
        )
    }

    /**
     * Determines if a color is vibrant enough for use in player UI
     * 
     * @param color The color to analyze
     * @return true if the color has sufficient saturation and brightness
     */
    fun isColorVibrant(color: Color): Boolean {
        val argb = color.toArgb()
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(argb, hsv)
        val saturation = hsv[1] // HSV[1] is saturation
        val brightness = hsv[2] // HSV[2] is brightness
        
        // Color is vibrant if it has sufficient saturation and appropriate brightness
        // Avoid colors that are too dark or too bright
        return saturation > 0.25f && brightness > 0.2f && brightness < 0.9f
    }
    
    /**
     * Enhances color vividness by adjusting saturation and brightness
     * 
     * @param color The color to enhance
     * @param saturationFactor Factor to multiply saturation by (default 1.4)
     * @return Enhanced color with improved vividness
     */
    fun enhanceColorVividness(color: Color, saturationFactor: Float = 1.4f): Color {
        val argb = color.toArgb()
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(argb, hsv)
        
        // Increase saturation for more vivid colors
        hsv[1] = (hsv[1] * saturationFactor).coerceAtMost(1.0f)
        // Adjust brightness for better visibility
        hsv[2] = (hsv[2] * 0.9f).coerceIn(0.4f, 0.85f)
        
        return Color(android.graphics.Color.HSVToColor(hsv))
    }

    /**
     * Calculates weight for color selection based on dominance and vibrancy
     * 
     * @param swatch The palette swatch to analyze
     * @return Weight value for color selection priority
     */
    fun calculateColorWeight(swatch: Palette.Swatch?): Float {
        if (swatch == null) return 0f
        val population = swatch.population.toFloat()
        val color = Color(swatch.rgb)
        val argb = color.toArgb()
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(argb, hsv)
        val saturation = hsv[1]
        val brightness = hsv[2]
        
        // Give higher priority to dominance (population) while considering vibrancy
        val populationWeight = population * 2f // Double dominance weight
        val vibrancyBonus = if (saturation > 0.3f && brightness > 0.3f) 1.5f else 1f
        
        return populationWeight * vibrancyBonus * (saturation + brightness) / 2f
    }

    /**
     * Configuration constants for color extraction
     */
    object Config {
        const val MAX_COLOR_COUNT = 32
        const val BITMAP_AREA = 8000
        const val IMAGE_SIZE = 200
        
        // Color enhancement factors
        const val VIBRANT_SATURATION_THRESHOLD = 0.25f
        const val VIBRANT_BRIGHTNESS_MIN = 0.2f
        const val VIBRANT_BRIGHTNESS_MAX = 0.9f
        
        const val POPULATION_WEIGHT_MULTIPLIER = 2f
        const val VIBRANCY_THRESHOLD_SATURATION = 0.3f
        const val VIBRANCY_THRESHOLD_BRIGHTNESS = 0.3f
        const val VIBRANCY_BONUS = 1.5f
        
        const val DEFAULT_SATURATION_FACTOR = 1.4f
        const val VIBRANT_SATURATION_FACTOR = 1.3f
        const val FALLBACK_SATURATION_FACTOR = 1.1f
        
        const val BRIGHTNESS_MULTIPLIER = 0.9f
        const val BRIGHTNESS_MIN = 0.4f
        const val BRIGHTNESS_MAX = 0.85f
        
        const val DARKER_VARIANT_FACTOR = 0.6f
    }
}

