package com.listrovia.music.ui.screens.equalizer.wizard

import androidx.compose.animation.*
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.listrovia.music.LocalPlayerAwareWindowInsets
import com.listrovia.music.R
import com.listrovia.music.eq.data.AutoEqApiService

/**
 * EQ Wizard - Global Acoustics & Vietnam Studio Calibration Flow
 * 100% Free • No API Key required
 */
@Composable
fun WizardScreen(
    viewModel: WizardViewModel = hiltViewModel(),
    onNavigateBack: () -> Unit
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    LaunchedEffect(state.isComplete) {
        if (state.isComplete) {
            onNavigateBack()
        }
    }

    WizardScreenContent(
        state = state,
        onDownloadDatabase = { viewModel.downloadDatabase() },
        onModelSearchQueryChanged = { viewModel.onModelSearchQueryChanged(it) },
        onProviderFilterChanged = { viewModel.onProviderFilterChanged(it) },
        onFormFilterChanged = { viewModel.onFormFilterChanged(it) },
        onModelSelected = { viewModel.onModelSelected(it) },
        onVariantToggled = { viewModel.onVariantToggled(it) },
        onTuningStyleChanged = { viewModel.onTuningStyleChanged(it) },
        onNextClicked = { viewModel.onNextClicked() },
        onBackClicked = { viewModel.onBackClicked() },
        onNavigateBack = onNavigateBack
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WizardScreenContent(
    state: WizardState,
    onDownloadDatabase: () -> Unit,
    onModelSearchQueryChanged: (String) -> Unit,
    onProviderFilterChanged: (String) -> Unit,
    onFormFilterChanged: (String) -> Unit,
    onModelSelected: (DeviceModel) -> Unit,
    onVariantToggled: (String) -> Unit,
    onTuningStyleChanged: (String) -> Unit,
    onNextClicked: () -> Unit,
    onBackClicked: () -> Unit,
    onNavigateBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = when (state.currentStep) {
                                WizardStep.MODEL_SELECTION -> stringResource(R.string.wizard_select_model)
                                WizardStep.VARIANT_SELECTION -> stringResource(R.string.wizard_select_profiles)
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = stringResource(R.string.autoeq_free_banner_title),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = if (state.canGoBack) onBackClicked else onNavigateBack) {
                        Icon(painterResource(R.drawable.arrow_back), contentDescription = null)
                    }
                },
                actions = {
                    if (state.currentStep == WizardStep.MODEL_SELECTION) {
                        IconButton(onClick = onDownloadDatabase) {
                            Icon(
                                painter = painterResource(R.drawable.sync),
                                contentDescription = stringResource(R.string.autoeq_update_cdn_btn),
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                HorizontalDivider()

                AnimatedContent(
                    targetState = state.currentStep,
                    label = "wizard_step",
                    transitionSpec = {
                        (slideInHorizontally { it } + fadeIn()).togetherWith(slideOutHorizontally { -it } + fadeOut())
                    }
                ) { step ->
                    when (step) {
                        WizardStep.MODEL_SELECTION -> ModelSelectionStep(
                            searchQuery = state.modelSearchQuery,
                            selectedProvider = state.selectedProvider,
                            selectedForm = state.selectedForm,
                            models = state.models,
                            totalProfilesCount = state.totalProfilesCount,
                            isLoading = state.isLoading,
                            onDownloadDatabase = onDownloadDatabase,
                            onSearchQueryChanged = onModelSearchQueryChanged,
                            onProviderFilterChanged = onProviderFilterChanged,
                            onFormFilterChanged = onFormFilterChanged,
                            onModelSelected = onModelSelected
                        )
                        WizardStep.VARIANT_SELECTION -> VariantSelectionStep(
                            modelName = state.selectedModel?.name ?: "",
                            variants = state.variants,
                            selectedVariantIds = state.selectedVariantIds,
                            selectedTuningStyle = state.selectedTuningStyle,
                            isLoading = state.isLoading,
                            onVariantToggled = onVariantToggled,
                            onTuningStyleChanged = onTuningStyleChanged,
                            onCompleteClicked = onNextClicked,
                            canComplete = state.canProceed
                        )
                    }
                }
            }

            if (state.error != null) {
                Snackbar(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp)
                ) {
                    Text(state.error)
                }
            }
        }
    }
}

// STEP 1: MODEL SELECTION & PROVIDER / FORM FILTERS

@Composable
private fun ModelSelectionStep(
    searchQuery: String,
    selectedProvider: String,
    selectedForm: String,
    models: List<DeviceModel>,
    totalProfilesCount: Int,
    isLoading: Boolean,
    onDownloadDatabase: () -> Unit,
    onSearchQueryChanged: (String) -> Unit,
    onProviderFilterChanged: (String) -> Unit,
    onFormFilterChanged: (String) -> Unit,
    onModelSelected: (DeviceModel) -> Unit
) {
    val listState = rememberLazyListState()
    val focusManager = LocalFocusManager.current

    LaunchedEffect(listState.isScrollInProgress) {
        if (listState.isScrollInProgress) {
            focusManager.clearFocus()
        }
    }

    val providerOptions = listOf(
        "all" to stringResource(R.string.autoeq_provider_all),
        "v_sound_vietnam" to stringResource(R.string.autoeq_provider_vietnam),
        "crinacle" to stringResource(R.string.autoeq_provider_crinacle),
        "oratory1990" to stringResource(R.string.autoeq_provider_oratory),
        "rtings" to stringResource(R.string.autoeq_provider_rtings),
        "superreview" to stringResource(R.string.autoeq_provider_superreview),
        "harman" to stringResource(R.string.autoeq_provider_harman)
    )

    val formOptions = listOf(
        "all" to stringResource(R.string.autoeq_form_all),
        "in-ear" to stringResource(R.string.autoeq_form_inear),
        "over-ear" to stringResource(R.string.autoeq_form_overear),
        "earbud" to stringResource(R.string.autoeq_form_earbud),
        "wireless" to stringResource(R.string.autoeq_form_wireless)
    )

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = 12.dp,
            bottom = LocalPlayerAwareWindowInsets.current.asPaddingValues().calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Free Global & Vietnam Acoustics Banner Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    painter = painterResource(R.drawable.graphic_eq),
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.autoeq_free_banner_title),
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = stringResource(R.string.autoeq_free_banner_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.7f)
                        ) {
                            Text(
                                text = stringResource(
                                    R.string.autoeq_database_status,
                                    totalProfilesCount.coerceAtLeast(models.size),
                                    AutoEqApiService.GLOBAL_PROVIDERS.size - 1
                                ),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        TextButton(
                            onClick = onDownloadDatabase,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.refresh),
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = stringResource(R.string.autoeq_update_cdn_btn),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }
        }

        // Search Box
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChanged,
                placeholder = { Text(stringResource(R.string.wizard_model_placeholder)) },
                leadingIcon = {
                    Icon(painterResource(R.drawable.search), contentDescription = null)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChanged("") }) {
                            Icon(painterResource(R.drawable.close), contentDescription = null)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Global Measurement Providers Filter Chips
        item {
            Column {
                Text(
                    text = stringResource(R.string.autoeq_provider_all),
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(providerOptions) { (id, label) ->
                        val isSelected = selectedProvider == id
                        FilterChip(
                            selected = isSelected,
                            onClick = { onProviderFilterChanged(id) },
                            label = {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                )
                            },
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }
            }
        }

        // Form Factor Filter Chips
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(formOptions) { (id, label) ->
                    val isSelected = selectedForm == id
                    SuggestionChip(
                        onClick = { onFormFilterChanged(id) },
                        label = {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            )
                        },
                        colors = SuggestionChipDefaults.suggestionChipColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainerLow
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }
        }

        // Models List
        if (isLoading) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }
        } else if (models.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = stringResource(R.string.wizard_no_models),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            items(models) { model ->
                ModelItem(
                    model = model,
                    onClick = { onModelSelected(model) }
                )
            }
        }
    }
}

@Composable
private fun ModelItem(
    model: DeviceModel,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainer
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        painter = painterResource(
                            if (model.form.contains("over", ignoreCase = true)) R.drawable.headphone
                            else if (model.form.contains("in-ear", ignoreCase = true)) R.drawable.graphic_eq
                            else R.drawable.equalizer
                        ),
                        contentDescription = null,
                        modifier = Modifier.size(22.dp),
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = model.name,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Provider Badge
                    val providerBadge = when {
                        model.primaryProvider.contains("v-sound", ignoreCase = true) || model.primaryProvider.contains("vietnam", ignoreCase = true) -> "🇻🇳 V-Sound"
                        model.primaryProvider.contains("crinacle", ignoreCase = true) -> "🇸🇬 Crinacle"
                        model.primaryProvider.contains("oratory", ignoreCase = true) -> "🇦🇹 Oratory"
                        model.primaryProvider.contains("rtings", ignoreCase = true) -> "🇨🇦 Rtings"
                        model.primaryProvider.contains("super", ignoreCase = true) -> "🇺🇸 Super*Review"
                        else -> "🌍 ${model.primaryProvider}"
                    }

                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Text(
                            text = providerBadge,
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (model.hasMultipleVariants) {
                        Text(
                            text = "• ${model.providers.size} calibrations",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
            Icon(
                painter = painterResource(R.drawable.navigate_next),
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// STEP 2: VARIANT SELECTION & SOUND TUNING STYLE

@Composable
private fun VariantSelectionStep(
    modelName: String,
    variants: List<EQProfileVariant>,
    selectedVariantIds: Set<String>,
    selectedTuningStyle: String,
    isLoading: Boolean,
    onVariantToggled: (String) -> Unit,
    onTuningStyleChanged: (String) -> Unit,
    onCompleteClicked: () -> Unit,
    canComplete: Boolean
) {
    val tunings = listOf(
        "harman" to ("🎵 " + stringResource(R.string.autoeq_tuning_harman)),
        "vocal" to ("🗣️ " + stringResource(R.string.autoeq_tuning_vocal)),
        "bass" to ("🔊 " + stringResource(R.string.autoeq_tuning_bass)),
        "treble" to ("✨ " + stringResource(R.string.autoeq_tuning_treble)),
        "relaxing" to ("☕ " + stringResource(R.string.autoeq_tuning_relaxing))
    )

    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = stringResource(R.string.wizard_select_eq_profiles, modelName),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }

            // Sound Tuning Style Selector
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainer
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = stringResource(R.string.autoeq_tuning_style),
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        tunings.forEach { (id, label) ->
                            val isSelected = selectedTuningStyle == id
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { onTuningStyleChanged(id) }
                                    .padding(vertical = 6.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { onTuningStyleChanged(id) }
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    ),
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = stringResource(R.string.wizard_select_profiles),
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }

            items(variants) { variant ->
                VariantItem(
                    variant = variant,
                    isSelected = selectedVariantIds.contains(variant.id),
                    onToggle = { onVariantToggled(variant.id) }
                )
            }
        }

        Surface(
            tonalElevation = 3.dp,
            shadowElevation = 8.dp
        ) {
            val bottomPadding = LocalPlayerAwareWindowInsets.current.asPaddingValues().calculateBottomPadding()
            Button(
                onClick = onCompleteClicked,
                enabled = canComplete && !isLoading,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 14.dp + bottomPadding)
                    .height(52.dp)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                } else {
                    Icon(
                        painter = painterResource(R.drawable.check),
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.wizard_save_profiles),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun VariantItem(
    variant: EQProfileVariant,
    isSelected: Boolean,
    onToggle: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f)
            } else {
                MaterialTheme.colorScheme.surfaceContainer
            }
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = isSelected,
                onCheckedChange = { onToggle() }
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = variant.displayName.substringBefore(" - "),
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                )

                val providerBadge = when {
                    variant.source.contains("v-sound", ignoreCase = true) || variant.source.contains("vietnam", ignoreCase = true) -> "🇻🇳 V-Sound Studio"
                    variant.source.contains("crinacle", ignoreCase = true) -> "🇸🇬 Crinacle (IEF)"
                    variant.source.contains("oratory", ignoreCase = true) -> "🇦🇹 Oratory1990"
                    variant.source.contains("rtings", ignoreCase = true) -> "🇨🇦 Rtings Lab"
                    variant.source.contains("super", ignoreCase = true) -> "🇺🇸 Super*Review"
                    else -> "🌍 ${variant.source}"
                }

                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Text(
                            text = providerBadge,
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (variant.rig != "unknown" && variant.rig.isNotEmpty()) {
                        Text(
                            text = "Rig: ${variant.rig}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
