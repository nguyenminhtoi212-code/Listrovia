/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.player

import com.listrovia.music.utils.joinToArtistString

import androidx.activity.compose.BackHandler
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.add
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ContainedLoadingIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedIconButton
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.core.net.toUri
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadRequest
import androidx.media3.exoplayer.offline.DownloadService
import com.listrovia.music.playback.ExoDownloadService
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.datastore.preferences.core.edit
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.Player.STATE_ENDED
import androidx.navigation.NavController
import androidx.palette.graphics.Palette
import com.listrovia.music.constants.ChromaticAberrationKey
import com.listrovia.music.constants.DepthEffectKey
import com.listrovia.music.constants.EnableLiquidGlassKey
import com.listrovia.music.constants.GlassBlurRadiusKey
import com.listrovia.music.constants.GlassPlayerKey
import com.listrovia.music.constants.GlassSaturationKey
import com.listrovia.music.constants.LensRefractionAmountKey
import com.listrovia.music.constants.LensRefractionHeightKey
import com.listrovia.music.constants.PureBlackKey
import com.listrovia.music.constants.SurfaceOpacityKey
import com.listrovia.music.ui.components.liquidGlass
import com.listrovia.music.LocalNavController
import coil3.compose.AsyncImage
import coil3.imageLoader
import coil3.request.ImageRequest
import coil3.request.allowHardware
import coil3.toBitmap
import com.listrovia.music.LocalDatabase
import com.listrovia.music.LocalDownloadUtil
import com.listrovia.music.LocalListenTogetherManager
import com.listrovia.music.LocalPlayerConnection
import com.listrovia.music.R
import com.listrovia.music.ui.component.CastButton
import com.listrovia.music.ui.component.PlayerSleepTimerDialog
import com.listrovia.music.constants.CropAlbumArtKey
import com.listrovia.music.constants.DarkModeKey
import com.listrovia.music.constants.HidePlayerThumbnailKey
import com.listrovia.music.constants.EnableHapticsKey
import com.listrovia.music.constants.HapticsPlaybackControlsKey
import com.listrovia.music.constants.HapticsSeekbarKey
import com.listrovia.music.constants.HapticsButtonsKey
import com.listrovia.music.constants.HideStatusBarOnFullscreenKey
import com.listrovia.music.constants.KeepScreenOn
import com.listrovia.music.constants.RealTimeVisualizerEnabledKey
import com.listrovia.music.constants.RealTimeVisualizerStyleKey
import com.listrovia.music.ui.component.RealTimeAudioVisualizer
import com.listrovia.music.constants.PlayerBackgroundStyle
import com.listrovia.music.constants.PlayerBackgroundStyleKey
import com.listrovia.music.constants.PlayerButtonsStyle
import com.listrovia.music.constants.PlayerButtonsStyleKey
import com.listrovia.music.constants.PlayerHorizontalPadding
import com.listrovia.music.constants.QueuePeekHeight
import com.listrovia.music.constants.SleepTimerDefaultKey
import com.listrovia.music.constants.SleepTimerFadeOutKey
import com.listrovia.music.constants.SleepTimerStopAfterCurrentSongKey
import com.listrovia.music.constants.SliderStyle
import com.listrovia.music.constants.SliderStyleKey
import com.listrovia.music.constants.SquigglySliderKey
import com.listrovia.music.constants.ThumbnailCornerRadius
import com.listrovia.music.constants.UseNewPlayerDesignKey
import com.listrovia.music.db.entities.LyricsEntity
import com.listrovia.music.extensions.metadata
import com.listrovia.music.extensions.togglePlayPause
import com.listrovia.music.extensions.toggleRepeatMode
import com.listrovia.music.listentogether.RoomRole
import com.listrovia.music.models.MediaMetadata
import com.listrovia.music.ui.component.BottomSheet
import com.listrovia.music.ui.component.BottomSheetState
import com.listrovia.music.ui.component.LocalBottomSheetPageState
import com.listrovia.music.ui.component.LocalMenuState
import com.listrovia.music.ui.component.Lyrics
import com.listrovia.music.ui.component.PlayerSliderTrack
import com.listrovia.music.ui.component.ResizableIconButton
import com.listrovia.music.ui.component.SquigglySlider
import com.listrovia.music.ui.component.WavySlider
import com.listrovia.music.ui.component.VolumeSlider
import com.listrovia.music.ui.component.rememberBottomSheetState
import com.listrovia.music.ui.menu.PlayerMenu
import com.listrovia.music.ui.menu.AddToPlaylistDialog
import com.listrovia.music.constants.DislikedSongsKey
import com.listrovia.music.constants.SmartShuffleKey
import com.listrovia.music.constants.ShowCodecOnPlayerKey
import com.listrovia.music.ui.screens.settings.DarkMode
import com.listrovia.music.ui.theme.PlayerColorExtractor
import com.listrovia.music.ui.theme.PlayerPaletteColors
import com.listrovia.music.ui.theme.PlayerSliderColors
import com.listrovia.music.ui.utils.ShowMediaInfo
import com.listrovia.music.ui.utils.ShowOffsetDialog
import com.listrovia.music.utils.dataStore
import com.listrovia.music.video.VideoPlaybackManager
import com.listrovia.music.utils.makeTimeString
import com.listrovia.music.utils.rememberEnumPreference
import com.listrovia.music.utils.rememberPreference
import com.listrovia.music.utils.safeDataStoreEdit
import dagger.hilt.android.EntryPointAccessors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt
import com.listrovia.music.ui.component.Icon as MIcon
import com.listrovia.music.constants.SleepTimerDefaultKey
import com.listrovia.music.constants.SleepTimerFadeOutKey
import com.listrovia.music.constants.SleepTimerStopAfterCurrentSongKey


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BottomSheetPlayer(
    state: BottomSheetState,
    navController: NavController,
    modifier: Modifier = Modifier,
    pureBlack: Boolean,
) {
    val context = LocalContext.current
    val clipboardManager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val menuState = LocalMenuState.current
    val sleepTimerDefaultSetTemplate = stringResource(R.string.sleep_timer_default_set)
    val copiedTitleStr = stringResource(R.string.copied_title)
    val copiedArtistStr = stringResource(R.string.copied_artist)
    val bottomSheetPageState = LocalBottomSheetPageState.current
    val playerConnection = LocalPlayerConnection.current ?: return

    val (useNewPlayerDesign, onUseNewPlayerDesignChange) =
        rememberPreference(
            UseNewPlayerDesignKey,
            defaultValue = true,
        )
    val (hidePlayerThumbnail, onHidePlayerThumbnailChange) = rememberPreference(HidePlayerThumbnailKey, false)
    val (hideStatusBarOnFullscreen) = rememberPreference(HideStatusBarOnFullscreenKey, false)
    val cropAlbumArt by rememberPreference(CropAlbumArtKey, false)

    val enableLiquidGlass by rememberPreference(EnableLiquidGlassKey, defaultValue = true)
    val glassPlayer by rememberPreference(GlassPlayerKey, defaultValue = true)
    val glassSaturation by rememberPreference(GlassSaturationKey, defaultValue = 1.3f)
    val glassBlurRadius by rememberPreference(GlassBlurRadiusKey, defaultValue = 24f)
    val lensRefractionHeight by rememberPreference(LensRefractionHeightKey, defaultValue = 14f)
    val lensRefractionAmount by rememberPreference(LensRefractionAmountKey, defaultValue = 0.85f)
    val chromaticAberration by rememberPreference(ChromaticAberrationKey, defaultValue = 0.45f)
    val depthEffect by rememberPreference(DepthEffectKey, defaultValue = 0.75f)
    val surfaceOpacity by rememberPreference(SurfaceOpacityKey, defaultValue = 1.0f)

    val isGlassPlayerActive = enableLiquidGlass && glassPlayer
    val realTimeVisualizerEnabled by rememberPreference(RealTimeVisualizerEnabledKey, true)
    val realTimeVisualizerStyle by rememberPreference(RealTimeVisualizerStyleKey, "spectrum")
    val (dislikedSongs, onDislikedSongsChange) = rememberPreference(DislikedSongsKey, emptySet<String>())

    var showInlineLyrics by rememberSaveable {
        mutableStateOf(false)
    }

    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    var isFullScreen by rememberSaveable {
        mutableStateOf(false)
    }

    var isStandbyMode by rememberSaveable {
        mutableStateOf(false)
    }

    var playbackMode by rememberSaveable {
        mutableStateOf(VideoPlaybackManager.PlaybackMode.VIDEO_PLAYBACK)
    }

    val playerBackground by rememberEnumPreference(
        key = PlayerBackgroundStyleKey,
        defaultValue = PlayerBackgroundStyle.DEFAULT,
    )
    val playerButtonsStyle by rememberEnumPreference(
        key = PlayerButtonsStyleKey,
        defaultValue = PlayerButtonsStyle.DEFAULT,
    )

    val isSystemInDarkTheme = isSystemInDarkTheme()
    val darkTheme by rememberEnumPreference(DarkModeKey, defaultValue = DarkMode.AUTO)
    val useDarkTheme =
        remember(darkTheme, isSystemInDarkTheme) {
            if (darkTheme == DarkMode.AUTO) isSystemInDarkTheme else darkTheme == DarkMode.ON
        }

    val shouldUseDarkButtonColors = useDarkTheme

    val isPlaying by playerConnection.isPlaying.collectAsState()
    val isKeepScreenOn by rememberPreference(KeepScreenOn, false)
    val keepScreenOn = isPlaying && isKeepScreenOn

    DisposableEffect(playerBackground, state.isExpanded, useDarkTheme, keepScreenOn, isFullScreen, hideStatusBarOnFullscreen) {
        val window = (context as? android.app.Activity)?.window
        if (window != null && state.isExpanded) {
            val insetsController = WindowCompat.getInsetsController(window, window.decorView)

            when (playerBackground) {
                PlayerBackgroundStyle.DEFAULT -> {
                    insetsController.isAppearanceLightStatusBars = !useDarkTheme
                }

                else -> {
                    insetsController.isAppearanceLightStatusBars = false
                }
            }

            if (isFullScreen && hideStatusBarOnFullscreen) {
                insetsController.hide(WindowInsetsCompat.Type.statusBars())
                insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            } else {
                insetsController.show(WindowInsetsCompat.Type.statusBars())
            }

            if (keepScreenOn && state.isExpanded) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        onDispose {
            if (window != null) {
                val insetsController = WindowCompat.getInsetsController(window, window.decorView)
                insetsController.isAppearanceLightStatusBars = !useDarkTheme
                insetsController.show(WindowInsetsCompat.Type.statusBars())
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }

    BackHandler(enabled = state.isExpanded) {
        state.collapseSoft()
    }



    val onBackgroundColor =
        when (playerBackground) {
            PlayerBackgroundStyle.DEFAULT -> MaterialTheme.colorScheme.secondary
            else -> MaterialTheme.colorScheme.onSurface
        }
    val useBlackBackground =
        remember(isSystemInDarkTheme, darkTheme, pureBlack) {
            val useDarkTheme =
                if (darkTheme == DarkMode.AUTO) isSystemInDarkTheme else darkTheme == DarkMode.ON
            useDarkTheme && pureBlack
        }

    val playbackState by playerConnection.playbackState.collectAsState()
    val mediaMetadata by playerConnection.mediaMetadata.collectAsState()
    val currentSong by playerConnection.currentSong.collectAsStateWithLifecycle(initialValue = null)
    val automix by playerConnection.service.automixItems.collectAsStateWithLifecycle()
    val repeatMode by playerConnection.repeatMode.collectAsStateWithLifecycle()
    val canSkipPrevious by playerConnection.canSkipPrevious.collectAsStateWithLifecycle()
    val canSkipNext by playerConnection.canSkipNext.collectAsStateWithLifecycle()
    val isMuted by playerConnection.isMuted.collectAsStateWithLifecycle()

    val sliderStyle by rememberEnumPreference(SliderStyleKey, SliderStyle.DEFAULT)
    val squigglySlider by rememberPreference(SquigglySliderKey, defaultValue = false)

    // Listen Together state (reactive)
    val listenTogetherManager = LocalListenTogetherManager.current
    val listenTogetherRoleState = listenTogetherManager?.role?.collectAsStateWithLifecycle(initialValue = RoomRole.NONE)
    val isListenTogetherGuest = listenTogetherRoleState?.value == RoomRole.GUEST

    // Cast state - safely access castConnectionHandler to prevent crashes during service lifecycle changes
    val castHandler =
        remember(playerConnection) {
            try {
                playerConnection.service.castConnectionHandler
            } catch (e: Exception) {
                null
            }
        }
    val isCasting by castHandler?.isCasting?.collectAsStateWithLifecycle() ?: remember { mutableStateOf(false) }
    val castPosition by castHandler?.castPosition?.collectAsStateWithLifecycle() ?: remember { mutableLongStateOf(0L) }
    val castDuration by castHandler?.castDuration?.collectAsStateWithLifecycle() ?: remember { mutableLongStateOf(0L) }
    val castIsPlaying by castHandler?.castIsPlaying?.collectAsState() ?: remember { mutableStateOf(false) }
    val playerVolume = playerConnection.service.playerVolume.collectAsStateWithLifecycle()
    val castVolume by castHandler?.castVolume?.collectAsStateWithLifecycle() ?: remember { mutableStateOf(1f) }

    val focusRequester = remember { FocusRequester() }
    val haptic = LocalHapticFeedback.current
    val enableHaptics by rememberPreference(EnableHapticsKey, defaultValue = true)
    val hapticsPlaybackControls by rememberPreference(HapticsPlaybackControlsKey, defaultValue = true)
    val hapticsSeekbar by rememberPreference(HapticsSeekbarKey, defaultValue = true)
    val hapticsButtons by rememberPreference(HapticsButtonsKey, defaultValue = true)

    val performPlaybackHaptic: () -> Unit = {
        if (enableHaptics && hapticsPlaybackControls) {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        }
    }
    val performSeekbarHaptic: () -> Unit = {
        if (enableHaptics && hapticsSeekbar) {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        }
    }
    val performButtonHaptic: () -> Unit = {
        if (enableHaptics && hapticsButtons) {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        }
    }

    LaunchedEffect(state.isExpanded) {
        if (state.isExpanded) {
            delay(100)
            try {
                focusRequester.requestFocus()
            } catch (e: Exception) {
                // Ignore if focus request fails
            }
        }
    }

    LaunchedEffect(playbackMode, mediaMetadata?.id) {
        val metadata = mediaMetadata ?: return@LaunchedEffect
        if (playbackMode == VideoPlaybackManager.PlaybackMode.VIDEO_PLAYBACK) {
            // When switching to video, start playback in VideoPlaybackManager
            // VideoPlaybackManager.play internally pauses MusicService
            VideoPlaybackManager.play(
                context = context,
                videoId = metadata.id,
                title = metadata.title,
                channelName = metadata.artists.joinToString { it.name }
            )
        } else {
            // When switching to audio, let video give way to music
            VideoPlaybackManager.giveWayToMusic(context)
        }
    }

    // Use Cast state when casting, otherwise local player
    val effectiveIsPlaying = if (isCasting) castIsPlaying else isPlaying

    // Use State objects for position/duration to pass to MiniPlayer without causing recomposition
    // These states persist across playback state changes to ensure continuous progress updates.
    // Seed from the player's current values so re-entering composition on resume shows the real
    // time immediately instead of flashing 0:00 until the first poll fires. runCatching guards the
    // player-not-ready race; the poll loop corrects duration if it isn't known yet.
    val showCodecOnPlayer by rememberPreference(ShowCodecOnPlayerKey, false)
    val positionState = remember { mutableLongStateOf(runCatching { playerConnection.player.currentPosition }.getOrDefault(0L)) }
    val durationState = remember {
        mutableLongStateOf(
            (mediaMetadata?.duration?.takeIf { it > 0 }?.toLong()?.times(1000L))
                ?: runCatching { playerConnection.player.duration }.getOrDefault(0L).coerceAtLeast(0L),
        )
    }

    // Convenience accessors for local use
    var position by positionState
    var duration by durationState

    val effectivePosition by remember {
        derivedStateOf {
            if (isCasting) {
                castPosition
            } else {
                position
            }
        }
    }

    var sliderPosition by remember {
        mutableStateOf<Long?>(null)
    }
    // Track when we last manually set position to avoid Cast overwriting it
    var lastManualSeekTime by remember { mutableLongStateOf(0L) }

    var playerPaletteColors by remember {
        mutableStateOf<PlayerPaletteColors?>(null)
    }
    val paletteColorsCache = remember { mutableMapOf<String, PlayerPaletteColors>() }

    var gradientColors by remember {
        mutableStateOf<List<Color>>(emptyList())
    }

    val defaultGradientColors = listOf(MaterialTheme.colorScheme.surface, MaterialTheme.colorScheme.surfaceVariant)
    val fallbackColor = MaterialTheme.colorScheme.surface.toArgb()
    val defaultPrimaryColor = MaterialTheme.colorScheme.primary

    val dominantColor = playerPaletteColors?.dominant ?: gradientColors.firstOrNull() ?: Color.Unspecified
    val accentGlowColor = playerPaletteColors?.accentGlow ?: defaultPrimaryColor

    LaunchedEffect(mediaMetadata?.id, playerBackground, isGlassPlayerActive) {
        val currentMetadata = mediaMetadata
        if (currentMetadata != null && currentMetadata.thumbnailUrl != null) {
            val cachedPalette = paletteColorsCache[currentMetadata.id]
            if (cachedPalette != null) {
                playerPaletteColors = cachedPalette
                gradientColors = cachedPalette.gradientColors
                return@LaunchedEffect
            }
            withContext(Dispatchers.IO) {
                val request =
                    ImageRequest
                        .Builder(context)
                        .data(currentMetadata.thumbnailUrl)
                        .size(120, 120)
                        .allowHardware(false)
                        .memoryCacheKey("palette_${currentMetadata.id}")
                        .build()

                val result = runCatching { context.imageLoader.execute(request) }.getOrNull()
                if (result != null) {
                    val bitmap = result.image?.toBitmap()
                    if (bitmap != null) {
                        val palette =
                            withContext(Dispatchers.Default) {
                                Palette
                                    .from(bitmap)
                                    .maximumColorCount(16)
                                    .resizeBitmapArea(120 * 120)
                                    .generate()
                            }
                        val extractedPalette =
                            PlayerColorExtractor.extractPaletteColors(
                                palette = palette,
                                fallbackColor = defaultPrimaryColor,
                                isDarkTheme = useDarkTheme,
                            )
                        paletteColorsCache[currentMetadata.id] = extractedPalette
                        withContext(Dispatchers.Main) {
                            playerPaletteColors = extractedPalette
                            gradientColors = extractedPalette.gradientColors
                        }
                    }
                }
            }
        } else {
            gradientColors = emptyList()
            playerPaletteColors = null
        }
    }

    val TextBackgroundColor by animateColorAsState(
        targetValue =
            when (playerBackground) {
                PlayerBackgroundStyle.DEFAULT -> MaterialTheme.colorScheme.onBackground
                else -> if (useDarkTheme) Color.White else Color.Black
            },
        label = "TextBackgroundColor",
    )

    val icBackgroundColor by animateColorAsState(
        targetValue =
            when (playerBackground) {
                PlayerBackgroundStyle.DEFAULT -> MaterialTheme.colorScheme.surface
                else -> if (useDarkTheme) Color.Black else Color.White
            },
        label = "icBackgroundColor",
    )

    val (textButtonColor, iconButtonColor) =
        when {
            playerBackground == PlayerBackgroundStyle.BLUR ||
                playerBackground == PlayerBackgroundStyle.GRADIENT -> {
                when (playerButtonsStyle) {
                    PlayerButtonsStyle.DEFAULT -> {
                        if (useDarkTheme) {
                            Pair(Color.White, Color.Black)
                        } else {
                            Pair(Color.Black, Color.White)
                        }
                    }

                    PlayerButtonsStyle.PRIMARY -> {
                        Pair(
                            MaterialTheme.colorScheme.primary,
                            MaterialTheme.colorScheme.onPrimary,
                        )
                    }

                    PlayerButtonsStyle.TERTIARY -> {
                        Pair(
                            MaterialTheme.colorScheme.tertiary,
                            MaterialTheme.colorScheme.onTertiary,
                        )
                    }
                }
            }

            else -> {
                when (playerButtonsStyle) {
                    PlayerButtonsStyle.DEFAULT -> {
                        if (useDarkTheme) {
                            Pair(Color.White, Color.Black)
                        } else {
                            Pair(Color.Black, Color.White)
                        }
                    }

                    PlayerButtonsStyle.PRIMARY -> {
                        Pair(
                            MaterialTheme.colorScheme.primary,
                            MaterialTheme.colorScheme.onPrimary,
                        )
                    }

                    PlayerButtonsStyle.TERTIARY -> {
                        Pair(
                            MaterialTheme.colorScheme.tertiary,
                            MaterialTheme.colorScheme.onTertiary,
                        )
                    }
                }
            }
        }

    // Separate colors for Previous/Next buttons in PRIMARY/TERTIARY modes
    val (sideButtonContainerColor, sideButtonContentColor) =
        when {
            playerBackground == PlayerBackgroundStyle.BLUR ||
                playerBackground == PlayerBackgroundStyle.GRADIENT -> {
                when (playerButtonsStyle) {
                    PlayerButtonsStyle.DEFAULT -> {
                        if (useDarkTheme) {
                            Pair(
                                Color.White.copy(alpha = 0.2f),
                                Color.White,
                            )
                        } else {
                            Pair(
                                Color.Black.copy(alpha = 0.2f),
                                Color.Black,
                            )
                        }
                    }

                    PlayerButtonsStyle.PRIMARY -> {
                        Pair(
                            MaterialTheme.colorScheme.primaryContainer,
                            MaterialTheme.colorScheme.onPrimaryContainer,
                        )
                    }

                    PlayerButtonsStyle.TERTIARY -> {
                        Pair(
                            MaterialTheme.colorScheme.tertiaryContainer,
                            MaterialTheme.colorScheme.onTertiaryContainer,
                        )
                    }
                }
            }

            else -> {
                when (playerButtonsStyle) {
                    PlayerButtonsStyle.DEFAULT -> {
                        Pair(
                            MaterialTheme.colorScheme.surfaceContainerHighest,
                            MaterialTheme.colorScheme.onSurface,
                        )
                    }

                    PlayerButtonsStyle.PRIMARY -> {
                        Pair(
                            MaterialTheme.colorScheme.primaryContainer,
                            MaterialTheme.colorScheme.onPrimaryContainer,
                        )
                    }

                    PlayerButtonsStyle.TERTIARY -> {
                        Pair(
                            MaterialTheme.colorScheme.tertiaryContainer,
                            MaterialTheme.colorScheme.onTertiaryContainer,
                        )
                    }
                }
            }
        }

    val database = LocalDatabase.current
    val download by LocalDownloadUtil.current
        .getDownload(mediaMetadata?.id ?: "")
        .collectAsStateWithLifecycle(initialValue = null)

    val sleepTimerEnabled =
        remember(
            playerConnection.service.sleepTimer?.triggerTime,
            playerConnection.service.sleepTimer?.pauseWhenSongEnd,
        ) {
            playerConnection.service.sleepTimer?.isActive ?: false
        }

    var sleepTimerTimeLeft by remember {
        mutableLongStateOf(0L)
    }

    LaunchedEffect(sleepTimerEnabled) {
        if (sleepTimerEnabled) {
            while (isActive) {
                sleepTimerTimeLeft =
                    if (playerConnection.service.sleepTimer?.pauseWhenSongEnd == true) {
                        playerConnection.player.duration - playerConnection.player.currentPosition
                    } else {
                        (playerConnection.service.sleepTimer?.triggerTime ?: 0L) - System.currentTimeMillis()
                    }
                delay(1000L)
            }
        }
    }

    val scope = rememberCoroutineScope()
    var showSleepTimerDialog by remember {
        mutableStateOf(false)
    }

    val sleepTimerDefault by rememberPreference(SleepTimerDefaultKey, 30f)
    var sleepTimerValue by remember {
        mutableFloatStateOf(sleepTimerDefault)
    }
    val isAtDefault by remember {
        derivedStateOf { sleepTimerValue.roundToInt() == sleepTimerDefault.roundToInt() }
    }
    val sleepTimerStopAfterCurrentSong by rememberPreference(SleepTimerStopAfterCurrentSongKey, false)
    val sleepTimerFadeOut by rememberPreference(SleepTimerFadeOutKey, false)


    PlayerSleepTimerDialog(
        isVisible = showSleepTimerDialog,
        onDismiss = { showSleepTimerDialog = false },
        playerConnection = playerConnection,
    )

    var showChoosePlaylistDialog by rememberSaveable {
        mutableStateOf(false)
    }

    // Position update - only for local playback
    // When casting, we use castPosition directly to avoid sync issues
    // Use isPlaying instead of playbackState to ensure continuous updates during playback
    LaunchedEffect(isPlaying, isCasting) {
        if (!isCasting && isPlaying) {
            while (isActive) {
                delay(100) // Update more frequently for smoother progress bar
                if (sliderPosition == null) { // Only update if user isn't dragging
                    position = playerConnection.player.currentPosition
                    // Don't clobber a valid (metadata-derived) duration with 0/UNSET mid-resolve.
                    playerConnection.player.duration.takeIf { it > 0 }?.let { duration = it }
                }
            }
        }
    }

    // Also update position when playback state changes (e.g., song change, seek)
    LaunchedEffect(playbackState, mediaMetadata?.id) {
        if (!isCasting) {
            position = playerConnection.player.currentPosition
            // Prefer the song's known duration (from metadata, available instantly from the restored
            // queue) so the slider range is right even when restored paused / before the stream
            // resolves; fall back to the player's duration once it is known.
            duration = (mediaMetadata?.duration?.takeIf { it > 0 }?.toLong()?.times(1000L))
                ?: playerConnection.player.duration
        }
    }

    // Auto-switch from repeat one to repeat all when song ends naturally
    var previousMediaId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(playbackState, mediaMetadata?.id) {
        val currentId = mediaMetadata?.id

        // Only switch from REPEAT_ONE to REPEAT_ALL when playback naturally ended
        // (i.e., the player transitioned to ENDED state and then moved to next track).
        // Do NOT switch on manual skips.
        if (currentId != null &&
            currentId != previousMediaId &&
            previousMediaId != null &&
            playbackState == Player.STATE_ENDED &&
            repeatMode == Player.REPEAT_MODE_ONE &&
            !isListenTogetherGuest) {
            playerConnection.player.setRepeatMode(Player.REPEAT_MODE_ALL)
        }

        previousMediaId = currentId
    }

    // When casting, use Cast position/duration directly
    // But wait a bit after manual seeks to let Cast catch up
    LaunchedEffect(isCasting, castPosition, castDuration) {
        if (isCasting && sliderPosition == null) {
            val timeSinceManualSeek = System.currentTimeMillis() - lastManualSeekTime
            if (timeSinceManualSeek > 1500) {
                // Only update from Cast if we haven't manually seeked recently
                position = castPosition
                if (castDuration > 0) duration = castDuration
            }
        }
    }

    val dismissedBound = QueuePeekHeight + WindowInsets.systemBars.asPaddingValues().calculateBottomPadding()

    val queueSheetState =
        rememberBottomSheetState(
            dismissedBound = dismissedBound,
            expandedBound = state.expandedBound,
            collapsedBound = dismissedBound + 1.dp,
            initialAnchor = 1,
        )

    val bottomSheetBackgroundColor =
        when (playerBackground) {
            PlayerBackgroundStyle.BLUR, PlayerBackgroundStyle.GRADIENT -> {
                MaterialTheme.colorScheme.surfaceContainer
            }

            else -> {
                if (useBlackBackground) {
                    Color.Black
                } else {
                    MaterialTheme.colorScheme.surfaceContainer
                }
            }
        }

    val backgroundAlpha = state.progress.coerceIn(0f, 1f)

    BottomSheet(
        state = state,
        modifier = modifier,
        background = {
            Box(
                modifier =
                    Modifier
                        .fillMaxSize()
                        .then(
                            if (isGlassPlayerActive) {
                                Modifier.liquidGlass(
                                    enabled = true,
                                    blurRadiusDp = glassBlurRadius,
                                    saturation = glassSaturation,
                                    refractionHeight = lensRefractionHeight,
                                    refractionAmount = lensRefractionAmount,
                                    chromaticAberration = chromaticAberration,
                                    depthEffect = depthEffect,
                                    surfaceOpacity = surfaceOpacity,
                                    surfaceTintColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                    dominantColor = dominantColor,
                                    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
                                )
                            } else {
                                Modifier.background(bottomSheetBackgroundColor)
                            }
                        ),
            ) {
                when (playerBackground) {
                    PlayerBackgroundStyle.BLUR -> {
                        Crossfade(
                            targetState = mediaMetadata?.thumbnailUrl,
                            animationSpec = tween(400),
                            label = "blurBackground",
                        ) { thumbnailUrl ->
                            if (thumbnailUrl != null) {
                                Box(modifier = Modifier.alpha(backgroundAlpha)) {
                                    AsyncImage(
                                        model =
                                            ImageRequest
                                                .Builder(context)
                                                .data(thumbnailUrl)
                                                .size(50, 50)
                                                .build(),
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier =
                                            Modifier
                                                .fillMaxSize()
                                                .blur(if (useDarkTheme) 12.dp else 10.dp),
                                    )
                                    Box(
                                        modifier =
                                            Modifier
                                                .fillMaxSize()
                                                .background(if (useDarkTheme) Color.Black.copy(alpha = 0.3f) else Color.White.copy(alpha = 0.45f)),
                                    )
                                }
                            }
                        }
                    }

                    PlayerBackgroundStyle.GRADIENT -> {
                        Crossfade(
                            targetState = gradientColors,
                            animationSpec = tween(400),
                            label = "gradientBackground",
                        ) { colors ->
                            if (colors.isNotEmpty()) {
                                val gradientColorStops =
                                    if (colors.size >= 3) {
                                        arrayOf(
                                            0.0f to colors[0],
                                            0.5f to colors[1],
                                            1.0f to colors[2],
                                        )
                                    } else {
                                        arrayOf(
                                            0.0f to colors[0],
                                            0.6f to colors[0].copy(alpha = 0.7f),
                                            1.0f to Color.Black,
                                        )
                                    }
                                Box(
                                    Modifier
                                        .fillMaxSize()
                                        .alpha(backgroundAlpha)
                                        .background(Brush.verticalGradient(colorStops = gradientColorStops))
                                        .background(if (useDarkTheme) Color.Black.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.35f)),
                                )
                            }
                        }
                    }

                    else -> {
                        PlayerBackgroundStyle.DEFAULT
                    }
                }

                // Center-aligned subtle logo watermark
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .alpha(backgroundAlpha),
                    contentAlignment = Alignment.Center
                ) {
                    androidx.compose.foundation.Image(
                        painter = painterResource(R.drawable.ic_launcher_logo),
                        contentDescription = null,
                        modifier = Modifier
                            .size(240.dp)
                            .aspectRatio(1f)
                            .alpha(if (useDarkTheme) 0.12f else 0.08f),
                        contentScale = androidx.compose.ui.layout.ContentScale.Fit
                    )
                }
            }
        },
        onDismiss =
            if (!isListenTogetherGuest) {
                {
                    playerConnection.service.clearAutomix()
                    playerConnection.player.stop()
                    playerConnection.player.clearMediaItems()
                }
            } else {
                null
            },
        collapsedContent = {
            MiniPlayer(
                positionState = positionState,
                durationState = durationState,
                onClick = { state.expandSoft() },
            )
        },
    ) {
        val controlsContent: @Composable ColumnScope.(MediaMetadata) -> Unit = { mediaMetadata ->
            // 1. Title and Artist Row (Full width, no squeezed text)
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = PlayerHorizontalPadding),
            ) {
                if (showInlineLyrics && !isLandscape) {
                    if (hidePlayerThumbnail) {
                        Box(
                            modifier =
                                Modifier
                                    .size(52.dp)
                                    .clip(RoundedCornerShape(ThumbnailCornerRadius))
                                    .background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center,
                        ) {
                            Image(
                                painter = painterResource(R.drawable.ic_launcher_logo),
                                contentDescription = null,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.size(28.dp),
                            )
                        }
                    } else {
                        AsyncImage(
                            model = mediaMetadata.thumbnailUrl,
                            contentDescription = null,
                            contentScale = if (cropAlbumArt) ContentScale.Crop else ContentScale.Fit,
                            modifier =
                                Modifier
                                    .size(52.dp)
                                    .clip(RoundedCornerShape(ThumbnailCornerRadius)),
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                }

                Column(
                    modifier =
                        Modifier
                            .weight(1f)
                            .pointerInput(Unit) {
                                var totalDragX = 0f
                                var totalDragY = 0f
                                detectHorizontalDragGestures(
                                    onDragStart = { totalDragX = 0f },
                                    onHorizontalDrag = { _, dragAmount -> totalDragX += dragAmount },
                                    onDragEnd = {
                                        if (totalDragX < -80f && playerConnection.player.nextMediaItemIndex != -1) {
                                            playerConnection.player.seekToNext()
                                        } else if (totalDragX > 80f && playerConnection.player.previousMediaItemIndex != -1) {
                                            playerConnection.player.seekToPreviousMediaItem()
                                        }
                                    },
                                )
                            }
                            .pointerInput(Unit) {
                                var totalDragY = 0f
                                detectVerticalDragGestures(
                                    onDragStart = { totalDragY = 0f },
                                    onVerticalDrag = { _, dragAmount -> totalDragY += dragAmount },
                                    onDragEnd = {
                                        if (kotlin.math.abs(totalDragY) > 50f) {
                                            val currentVol = playerConnection.player.volume
                                            val newVol = if (totalDragY < 0f) {
                                                (currentVol + 0.1f).coerceIn(0f, 1f)
                                            } else {
                                                (currentVol - 0.1f).coerceIn(0f, 1f)
                                            }
                                            playerConnection.player.volume = newVol
                                        }
                                    }
                                )
                            },
                ) {
                    Text(
                        text = mediaMetadata.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = TextBackgroundColor,
                        modifier =
                            Modifier
                                .basicMarquee(iterations = 1, initialDelayMillis = 3000, velocity = 30.dp)
                                .combinedClickable(
                                    enabled = true,
                                    indication = null,
                                    interactionSource = remember { MutableInteractionSource() },
                                    onClick = {
                                        val albumId =
                                            mediaMetadata.album?.id
                                                ?: currentSong?.album?.id
                                                ?: currentSong?.song?.albumId
                                        if (albumId != null) {
                                            navController.navigate("album/$albumId")
                                            state.collapseSoft()
                                        }
                                    },
                                    onLongClick = {
                                        Toast
                                            .makeText(context, "Sao chép bị hạn chế để bảo vệ bản quyền.", Toast.LENGTH_SHORT)
                                            .show()
                                    },
                                ),
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        if (mediaMetadata.explicit) {
                            MIcon.Explicit()
                            Spacer(modifier = Modifier.width(4.dp))
                        }

                        val validArtists = mediaMetadata.artists.filter { it.name.isNotBlank() }
                        if (validArtists.isNotEmpty()) {
                            val annotatedString =
                                buildAnnotatedString {
                                    validArtists.forEachIndexed { index, artist ->
                                        val tag = "artist_${artist.id.orEmpty()}"
                                        pushStringAnnotation(tag = tag, annotation = artist.id.orEmpty())
                                        withStyle(SpanStyle(color = TextBackgroundColor.copy(alpha = 0.82f), fontSize = 15.sp)) {
                                            append(artist.name)
                                        }
                                        pop()
                                        if (index != validArtists.lastIndex) append(", ")
                                    }
                                }

                            var layoutResult by remember { mutableStateOf<TextLayoutResult?>(null) }
                            var clickOffset by remember { mutableStateOf<Offset?>(null) }
                            Text(
                                text = annotatedString,
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextBackgroundColor.copy(alpha = 0.82f)),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                onTextLayout = { layoutResult = it },
                                modifier =
                                    Modifier
                                        .basicMarquee(iterations = 1, initialDelayMillis = 3000, velocity = 30.dp)
                                        .pointerInput(Unit) {
                                            awaitPointerEventScope {
                                                while (true) {
                                                    val event = awaitPointerEvent()
                                                    val tapPosition = event.changes.firstOrNull()?.position
                                                    if (tapPosition != null) {
                                                        clickOffset = tapPosition
                                                    }
                                                }
                                            }
                                        }.combinedClickable(
                                            enabled = true,
                                            indication = null,
                                            interactionSource = remember { MutableInteractionSource() },
                                            onClick = {
                                                val tapPosition = clickOffset
                                                val layout = layoutResult
                                                if (tapPosition != null && layout != null) {
                                                    val offset = layout.getOffsetForPosition(tapPosition)
                                                    annotatedString
                                                        .getStringAnnotations(offset, offset)
                                                        .firstOrNull()
                                                        ?.let { ann ->
                                                            val artistId = ann.item
                                                            if (artistId.isNotBlank()) {
                                                                navController.navigate("artist/$artistId")
                                                                state.collapseSoft()
                                                            }
                                                        }
                                                }
                                            },
                                            onLongClick = {
                                                Toast
                                                    .makeText(
                                                        context,
                                                        "Sao chép bị hạn chế để bảo vệ bản quyền.",
                                                        Toast.LENGTH_SHORT,
                                                    ).show()
                                            },
                                        ),
                            )
                        }
                    }
                }
            }

            val verticalSpacing = if (isLandscape) 4.dp else 14.dp
            Spacer(Modifier.height(verticalSpacing))

            // 2. Action Bar Row (Compact, Clean, Evenly Spaced)
            val actionShape = RoundedCornerShape(16.dp)
            val actionBorder = androidx.compose.foundation.BorderStroke(1.dp, TextBackgroundColor.copy(alpha = 0.12f))
            val actionColors =
                IconButtonDefaults.outlinedIconButtonColors(
                    containerColor = TextBackgroundColor.copy(alpha = 0.07f),
                    contentColor = TextBackgroundColor,
                )
            val actionButtonSize = if (isLandscape) 36.dp else 42.dp
            val actionIconSize = if (isLandscape) 18.dp else 22.dp

            Row(
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = PlayerHorizontalPadding),
            ) {
                // Playback Mode Toggle (Music / Video)
                androidx.compose.material3.OutlinedIconButton(
                    onClick = {
                        performButtonHaptic()
                        playbackMode = if (playbackMode == VideoPlaybackManager.PlaybackMode.AUDIO_ONLY) 
                            VideoPlaybackManager.PlaybackMode.VIDEO_PLAYBACK 
                        else 
                            VideoPlaybackManager.PlaybackMode.AUDIO_ONLY
                    },
                    shape = actionShape,
                    border = actionBorder,
                    colors = actionColors,
                    modifier = Modifier.size(actionButtonSize),
                ) {
                    Icon(
                        painter = painterResource(if (playbackMode == VideoPlaybackManager.PlaybackMode.AUDIO_ONLY) R.drawable.music_note else R.drawable.video_mode),
                        contentDescription = "Toggle Playback Mode",
                        tint = TextBackgroundColor,
                        modifier = Modifier.size(actionIconSize),
                    )
                }

                // Like / Favorite
                val isEpisode = currentSong?.song?.isEpisode == true
                val isFavorite = if (isEpisode) currentSong?.song?.inLibrary != null else currentSong?.song?.liked == true
                androidx.compose.material3.OutlinedIconButton(
                    onClick = {
                        performButtonHaptic()
                        playerConnection.toggleLike()
                    },
                    shape = actionShape,
                    border = actionBorder,
                    colors = actionColors,
                    modifier = Modifier.size(actionButtonSize),
                ) {
                    Icon(
                        painter = painterResource(if (isFavorite) R.drawable.favorite else R.drawable.favorite_border),
                        contentDescription = "Favorite",
                        tint = if (isFavorite) MaterialTheme.colorScheme.primary else TextBackgroundColor,
                        modifier = Modifier.size(actionIconSize),
                    )
                }

                // Equalizer Quick Shortcut
                androidx.compose.material3.OutlinedIconButton(
                    onClick = {
                        performButtonHaptic()
                        navController.navigate("equalizer")
                        state.collapseSoft()
                    },
                    shape = actionShape,
                    border = actionBorder,
                    colors = actionColors,
                    modifier = Modifier.size(actionButtonSize),
                ) {
                    Icon(
                        painter = painterResource(R.drawable.equalizer),
                        contentDescription = "Equalizer",
                        tint = TextBackgroundColor,
                        modifier = Modifier.size(actionIconSize),
                    )
                }

                // Share Button (System Share Menu)
                androidx.compose.material3.OutlinedIconButton(
                    onClick = {
                        performButtonHaptic()
                        val intent =
                            Intent().apply {
                                action = Intent.ACTION_SEND
                                type = "text/plain"
                                putExtra(
                                    Intent.EXTRA_TEXT,
                                    "https://music.youtube.com/watch?v=${mediaMetadata.id}",
                                )
                            }
                        context.startActivity(Intent.createChooser(intent, null))
                    },
                    shape = actionShape,
                    border = actionBorder,
                    colors = actionColors,
                    modifier = Modifier.size(actionButtonSize),
                ) {
                    Icon(
                        painter = painterResource(R.drawable.share),
                        contentDescription = "Share",
                        tint = TextBackgroundColor,
                        modifier = Modifier.size(actionIconSize),
                    )
                }

                // Download Button
                androidx.compose.material3.OutlinedIconButton(
                    onClick = {
                        performButtonHaptic()
                        if (download?.state == Download.STATE_COMPLETED || download?.state == Download.STATE_DOWNLOADING || download?.state == Download.STATE_QUEUED) {
                            DownloadService.sendRemoveDownload(
                                context,
                                ExoDownloadService::class.java,
                                mediaMetadata.id,
                                false,
                            )
                        } else {
                            database.transaction {
                                insert(mediaMetadata)
                            }
                            val downloadRequest =
                                DownloadRequest
                                    .Builder(mediaMetadata.id, mediaMetadata.id.toUri())
                                    .setCustomCacheKey(mediaMetadata.id)
                                    .setData(mediaMetadata.title.toByteArray())
                                    .build()
                            DownloadService.sendAddDownload(
                                context,
                                ExoDownloadService::class.java,
                                downloadRequest,
                                false,
                            )
                        }
                    },
                    shape = actionShape,
                    border = actionBorder,
                    colors = actionColors,
                    modifier = Modifier.size(actionButtonSize),
                ) {
                    when (download?.state) {
                        Download.STATE_COMPLETED -> {
                            Icon(
                                painter = painterResource(R.drawable.offline),
                                contentDescription = "Remove Download",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(actionIconSize),
                            )
                        }
                        Download.STATE_QUEUED, Download.STATE_DOWNLOADING -> {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = TextBackgroundColor,
                            )
                        }
                        else -> {
                            Icon(
                                painter = painterResource(R.drawable.download),
                                contentDescription = "Download Song",
                                tint = TextBackgroundColor,
                                modifier = Modifier.size(actionIconSize),
                            )
                        }
                    }
                }

                // Details / More Info Dialog
                if (showInlineLyrics) {
                    val currentLyrics by playerConnection.currentLyrics.collectAsStateWithLifecycle(initialValue = null)
                    androidx.compose.material3.OutlinedIconButton(
                        onClick = {
                            menuState.show {
                                com.listrovia.music.ui.menu.LyricsMenu(
                                    lyricsProvider = { currentLyrics },
                                    songProvider = { currentSong?.song },
                                    mediaMetadataProvider = { mediaMetadata },
                                    onDismiss = menuState::dismiss,
                                    onShowOffsetDialog = {
                                        bottomSheetPageState.show {
                                            ShowOffsetDialog(
                                                songProvider = { currentSong?.song },
                                            )
                                        }
                                    },
                                )
                            }
                        },
                        shape = actionShape,
                        border = actionBorder,
                        colors = actionColors,
                        modifier = Modifier.size(actionButtonSize),
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.more_horiz),
                            contentDescription = "Lyrics Options",
                            tint = TextBackgroundColor,
                            modifier = Modifier.size(actionIconSize),
                        )
                    }
                } else {
                    androidx.compose.material3.OutlinedIconButton(
                        onClick = {
                            bottomSheetPageState.show {
                                ShowMediaInfo(mediaMetadata.id)
                            }
                        },
                        shape = actionShape,
                        border = actionBorder,
                        colors = actionColors,
                        modifier = Modifier.size(actionButtonSize),
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.info),
                            contentDescription = "Song Info",
                            tint = TextBackgroundColor,
                            modifier = Modifier.size(actionIconSize),
                        )
                    }
                }
            }

            if (realTimeVisualizerEnabled) {
                Spacer(Modifier.height(if (isLandscape) 2.dp else 4.dp))
                RealTimeAudioVisualizer(
                    isPlaying = effectiveIsPlaying,
                    style = realTimeVisualizerStyle,
                    audioSessionId = playerConnection.player.audioSessionId,
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .height(if (isLandscape) 18.dp else 26.dp)
                            .padding(horizontal = PlayerHorizontalPadding + 8.dp),
                    color = textButtonColor,
                )
                Spacer(Modifier.height(if (isLandscape) 2.dp else 6.dp))
            } else {
                Spacer(Modifier.height(verticalSpacing))
            }

            val maxDurationFloat = if (duration == C.TIME_UNSET) 0f else duration.toFloat()
            val currentTargetPosition = (sliderPosition ?: effectivePosition).toFloat()
            val animatedSliderPosition by animateFloatAsState(
                targetValue = currentTargetPosition,
                animationSpec =
                    if (sliderPosition != null) {
                        snap()
                    } else if (effectiveIsPlaying) {
                        tween(durationMillis = 1000, easing = LinearEasing)
                    } else {
                        spring()
                    },
                label = "AnimatedSeekBar",
            )
            val activeSliderValue = if (sliderPosition != null) currentTargetPosition else animatedSliderPosition.coerceIn(0f, maxDurationFloat)

            when (sliderStyle) {
                SliderStyle.DEFAULT -> {
                    Slider(
                        value = activeSliderValue,
                        valueRange = 0f..maxDurationFloat,
                        onValueChange = {
                            if (!isListenTogetherGuest) {
                                sliderPosition = it.toLong()
                            }
                        },
                        onValueChangeFinished = {
                            if (!isListenTogetherGuest) {
                                performSeekbarHaptic()
                                sliderPosition?.let {
                                    if (isCasting) {
                                        castHandler?.seekTo(it)
                                        lastManualSeekTime = System.currentTimeMillis()
                                    } else {
                                        playerConnection.player.seekTo(it)
                                    }
                                    position = it
                                }
                                sliderPosition = null
                            }
                        },
                        enabled = !isListenTogetherGuest,
                        colors = PlayerSliderColors.getSliderColors(textButtonColor, playerBackground, useDarkTheme),
                        modifier = Modifier.padding(horizontal = PlayerHorizontalPadding),
                    )
                }

                SliderStyle.WAVY -> {
                    if (squigglySlider) {
                        SquigglySlider(
                            value = activeSliderValue,
                            valueRange = 0f..maxDurationFloat,
                            onValueChange = {
                                sliderPosition = it.toLong()
                            },
                            onValueChangeFinished = {
                                performSeekbarHaptic()
                                sliderPosition?.let {
                                    if (isCasting) {
                                        castHandler?.seekTo(it)
                                        lastManualSeekTime = System.currentTimeMillis()
                                    } else {
                                        playerConnection.player.seekTo(it)
                                    }
                                    position = it
                                }
                                sliderPosition = null
                            },
                            modifier = Modifier.padding(horizontal = PlayerHorizontalPadding),
                            colors = PlayerSliderColors.getSliderColors(textButtonColor, playerBackground, useDarkTheme),
                            isPlaying = effectiveIsPlaying,
                        )
                    } else {
                        WavySlider(
                            value = activeSliderValue,
                            valueRange = 0f..maxDurationFloat,
                            onValueChange = {
                                sliderPosition = it.toLong()
                            },
                            onValueChangeFinished = {
                                performSeekbarHaptic()
                                sliderPosition?.let {
                                    if (isCasting) {
                                        castHandler?.seekTo(it)
                                        lastManualSeekTime = System.currentTimeMillis()
                                    } else {
                                        playerConnection.player.seekTo(it)
                                    }
                                    position = it
                                }
                                sliderPosition = null
                            },
                            colors = PlayerSliderColors.getSliderColors(textButtonColor, playerBackground, useDarkTheme),
                            modifier = Modifier.padding(horizontal = PlayerHorizontalPadding),
                            isPlaying = effectiveIsPlaying,
                        )
                    }
                }

                SliderStyle.SLIM -> {
                    Slider(
                        value = activeSliderValue,
                        valueRange = 0f..maxDurationFloat,
                        onValueChange = {
                            if (!isListenTogetherGuest) {
                                sliderPosition = it.toLong()
                            }
                        },
                        onValueChangeFinished = {
                            if (!isListenTogetherGuest) {
                                performSeekbarHaptic()
                                sliderPosition?.let {
                                    if (isCasting) {
                                        castHandler?.seekTo(it)
                                        lastManualSeekTime = System.currentTimeMillis()
                                    } else {
                                        playerConnection.player.seekTo(it)
                                    }
                                    position = it
                                }
                                sliderPosition = null
                            }
                        },
                        enabled = !isListenTogetherGuest,
                        thumb = { Spacer(modifier = Modifier.size(0.dp)) },
                        track = { sliderState ->
                            PlayerSliderTrack(
                                sliderState = sliderState,
                                colors = PlayerSliderColors.getSliderColors(textButtonColor, playerBackground, useDarkTheme),
                            )
                        },
                        modifier = Modifier.padding(horizontal = PlayerHorizontalPadding),
                    )
                }
            }

            Spacer(Modifier.height(4.dp))

            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = PlayerHorizontalPadding + 4.dp),
            ) {
                Text(
                    text = makeTimeString(sliderPosition ?: effectivePosition),
                    style = MaterialTheme.typography.labelMedium,
                    color = TextBackgroundColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )

                if (showCodecOnPlayer) {
                    Text(
                        text = "Opus 160kbps • 48kHz",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextBackgroundColor.copy(alpha = 0.7f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }

                Text(
                    text = if (duration != C.TIME_UNSET) makeTimeString(duration) else "",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextBackgroundColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            Spacer(Modifier.height(verticalSpacing))

            AnimatedVisibility(
                visible = !isFullScreen,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = shrinkVertically(shrinkTowards = Alignment.Top) + slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            ) {
                val playbackRowHeight = if (isLandscape) 44.dp else 56.dp
                val playPauseButtonSize = if (isLandscape) 52.dp else 68.dp
                val playPauseIconSize = if (isLandscape) 28.dp else 34.dp
                val sideButtonSize = if (isLandscape) 38.dp else 44.dp

                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier =
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = PlayerHorizontalPadding),
                    ) {
                        // 1. Shuffle Button
                        val shuffleModeEnabled by playerConnection.shuffleModeEnabled.collectAsStateWithLifecycle()
                        Box(
                            modifier =
                                Modifier
                                    .weight(1f)
                                    .height(playbackRowHeight),
                            contentAlignment = Alignment.Center,
                        ) {
                            ResizableIconButton(
                                icon = if (shuffleModeEnabled) R.drawable.shuffle_on else R.drawable.shuffle,
                                color = if (shuffleModeEnabled) MaterialTheme.colorScheme.primary else TextBackgroundColor,
                                modifier =
                                    Modifier
                                        .size(sideButtonSize)
                                        .padding(4.dp)
                                        .alpha(if (isListenTogetherGuest) 0.5f else 1f),
                                enabled = !isListenTogetherGuest,
                                onClick = {
                                    performPlaybackHaptic()
                                    playerConnection.player.shuffleModeEnabled = !shuffleModeEnabled
                                },
                            )
                        }

                        // 2. Skip Previous Button
                        Box(
                            modifier =
                                Modifier
                                    .weight(1f)
                                    .height(playbackRowHeight),
                            contentAlignment = Alignment.Center,
                        ) {
                            ResizableIconButton(
                                icon = R.drawable.skip_previous,
                                enabled = canSkipPrevious && !isListenTogetherGuest,
                                color = TextBackgroundColor,
                                modifier =
                                    Modifier
                                        .size(sideButtonSize)
                                        .padding(4.dp)
                                        .alpha(if (isListenTogetherGuest) 0.5f else 1f),
                                onClick = {
                                    performPlaybackHaptic()
                                    playerConnection.seekToPrevious()
                                },
                            )
                        }

                        // 3. Play / Pause Button
                        val playPauseInteractionSource = remember { MutableInteractionSource() }
                        val isPlayPausePressed by playPauseInteractionSource.collectIsPressedAsState()
                        val playPauseScale by animateFloatAsState(
                            targetValue = if (isPlayPausePressed) 0.92f else 1f,
                            animationSpec = spring(dampingRatio = androidx.compose.animation.core.Spring.DampingRatioMediumBouncy),
                            label = "playPauseScale",
                        )
                        Box(
                            modifier =
                                Modifier
                                    .size(playPauseButtonSize)
                                    .graphicsLayer {
                                        scaleX = playPauseScale
                                        scaleY = playPauseScale
                                    }.clip(CircleShape)
                                    .background(textButtonColor)
                                    .clickable(
                                        interactionSource = playPauseInteractionSource,
                                        indication = null,
                                    ) {
                                        performPlaybackHaptic()
                                        if (isListenTogetherGuest) {
                                            playerConnection.toggleMute()
                                            return@clickable
                                        }
                                        if (isCasting) {
                                            if (castIsPlaying) {
                                                castHandler?.pause()
                                            } else {
                                                castHandler?.play()
                                            }
                                        } else if (playbackState == STATE_ENDED) {
                                            playerConnection.player.seekTo(0, 0)
                                            playerConnection.player.playWhenReady = true
                                        } else {
                                            playerConnection.player.togglePlayPause()
                                        }
                                    }.focusRequester(focusRequester),
                        ) {
                            Image(
                                painter =
                                    painterResource(
                                        if (isListenTogetherGuest) {
                                            if (isMuted) R.drawable.volume_off else R.drawable.volume_up
                                        } else if (playbackState ==
                                            STATE_ENDED
                                        ) {
                                            R.drawable.replay
                                        } else if (effectiveIsPlaying) {
                                            R.drawable.pause
                                        } else {
                                            R.drawable.play
                                        },
                                    ),
                                contentDescription = if (effectiveIsPlaying) "Pause" else "Play",
                                colorFilter = ColorFilter.tint(iconButtonColor),
                                modifier =
                                    Modifier
                                        .align(Alignment.Center)
                                        .size(playPauseIconSize),
                            )
                        }

                        // 4. Skip Next Button
                        Box(
                            modifier =
                                Modifier
                                    .weight(1f)
                                    .height(playbackRowHeight),
                            contentAlignment = Alignment.Center,
                        ) {
                            ResizableIconButton(
                                icon = R.drawable.skip_next,
                                enabled = canSkipNext && !isListenTogetherGuest,
                                color = TextBackgroundColor,
                                modifier =
                                    Modifier
                                        .size(sideButtonSize)
                                        .padding(4.dp)
                                        .alpha(if (isListenTogetherGuest) 0.5f else 1f),
                                onClick = {
                                    performPlaybackHaptic()
                                    playerConnection.seekToNext()
                                },
                            )
                        }

                        // 5. Repeat Button
                        Box(
                            modifier =
                                Modifier
                                    .weight(1f)
                                    .height(playbackRowHeight),
                            contentAlignment = Alignment.Center,
                        ) {
                            val isRepeatOff = repeatMode == Player.REPEAT_MODE_OFF
                            ResizableIconButton(
                                icon =
                                    when (repeatMode) {
                                        Player.REPEAT_MODE_OFF, Player.REPEAT_MODE_ALL -> R.drawable.repeat
                                        Player.REPEAT_MODE_ONE -> R.drawable.repeat_one
                                        else -> throw IllegalStateException()
                                    },
                                color = if (isRepeatOff) TextBackgroundColor else MaterialTheme.colorScheme.primary,
                                modifier =
                                    Modifier
                                        .size(sideButtonSize)
                                        .padding(4.dp)
                                        .alpha(if (isListenTogetherGuest) 0.5f else 1f),
                                enabled = !isListenTogetherGuest,
                                onClick = {
                                    performPlaybackHaptic()
                                    playerConnection.player.toggleRepeatMode()
                                },
                            )
                        }
                    }
                }
            }
        }

        Box(modifier = Modifier.fillMaxSize()) {
            if (isStandbyMode) {
                StandbyScreen(
                    mediaMetadata = mediaMetadata,
                    isPlaying = isPlaying,
                    playerConnection = playerConnection,
                    onClose = { isStandbyMode = false }
                )
            } else {
                when (LocalConfiguration.current.orientation) {
                    Configuration.ORIENTATION_LANDSCAPE -> {
                        val density = LocalDensity.current
                        val topInset = WindowInsets.systemBars.getTop(density)
                        val bottomInset = WindowInsets.systemBars.getBottom(density)
                        val topPaddingDp = with(density) { topInset.toDp() }
                        val bottomPaddingDp = with(density) { bottomInset.toDp() }

                        Row(
                            modifier =
                                Modifier
                                    .windowInsetsPadding(WindowInsets.systemBars.only(WindowInsetsSides.Horizontal))
                                    .padding(top = topPaddingDp, bottom = bottomPaddingDp)
                                    .fillMaxSize(),
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier =
                                    Modifier
                                        .weight(1.1f)
                                        .fillMaxHeight()
                                        .padding(start = 12.dp, end = 6.dp, top = 4.dp, bottom = 4.dp)
                                        .nestedScroll(state.preUpPostDownNestedScrollConnection),
                            ) {
                                val currentSliderPosition by rememberUpdatedState(sliderPosition)
                                val sliderPositionProvider = remember { { currentSliderPosition } }
                                val isExpandedProvider = remember(state) { { state.isExpanded } }
                                AnimatedContent(
                                    targetState = showInlineLyrics,
                                    label = "LyricsLandscape",
                                    transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(250)) },
                                    modifier = Modifier.fillMaxSize(),
                                ) { showLyrics ->
                                    if (showLyrics) {
                                        InlineLyricsView(
                                            mediaMetadata = mediaMetadata,
                                            showLyrics = showLyrics,
                                            positionProvider = { effectivePosition },
                                        )
                                    } else {
                                        Thumbnail(
                                            sliderPositionProvider = sliderPositionProvider,
                                            modifier = Modifier.fillMaxSize(),
                                            isPlayerExpanded = isExpandedProvider,
                                            isLandscape = true,
                                            isListenTogetherGuest = isListenTogetherGuest,
                                            isVideoMode = playbackMode == VideoPlaybackManager.PlaybackMode.VIDEO_PLAYBACK
                                        )
                                    }
                                }
                            }

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.SpaceBetween,
                                modifier =
                                    Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .padding(start = 6.dp, end = 12.dp, top = 2.dp, bottom = 4.dp)
                                        .verticalScroll(rememberScrollState()),
                            ) {
                                // Landscape Top Bar with quick actions
                                Row(
                                    modifier =
                                        Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = PlayerHorizontalPadding),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    androidx.compose.material3.IconButton(
                                        onClick = { state.collapseSoft() },
                                        modifier = Modifier.size(38.dp),
                                    ) {
                                        Icon(
                                            painter = painterResource(R.drawable.expand_more),
                                            contentDescription = "Thu nhỏ",
                                            tint = TextBackgroundColor,
                                            modifier = Modifier.size(26.dp),
                                        )
                                    }

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    ) {
                                        // Quick toggle button between Lyrics and Cover art ("chuyển qua lại cho ngay")
                                        androidx.compose.material3.IconButton(
                                            onClick = { showInlineLyrics = !showInlineLyrics },
                                            modifier = Modifier.size(38.dp),
                                        ) {
                                            Icon(
                                                painter = painterResource(if (showInlineLyrics) R.drawable.album else R.drawable.lyrics),
                                                contentDescription = if (showInlineLyrics) "Hiển thị ảnh bìa" else "Hiển thị lời bài hát",
                                                tint = if (showInlineLyrics) MaterialTheme.colorScheme.primary else TextBackgroundColor,
                                                modifier = Modifier.size(22.dp),
                                            )
                                        }

                                        androidx.compose.material3.IconButton(
                                            onClick = { isStandbyMode = true },
                                            modifier = Modifier.size(38.dp),
                                        ) {
                                            Icon(
                                                painter = painterResource(R.drawable.bedtime),
                                                contentDescription = "Màn hình chờ",
                                                tint = TextBackgroundColor,
                                                modifier = Modifier.size(20.dp),
                                            )
                                        }

                                        androidx.compose.material3.IconButton(
                                            onClick = {
                                                val currentMeta = mediaMetadata
                                                if (currentMeta != null) {
                                                    menuState.show {
                                                        PlayerMenu(
                                                            mediaMetadata = currentMeta,
                                                            playerBottomSheetState = state,
                                                            onShowDetailsDialog = {
                                                                bottomSheetPageState.show {
                                                                    ShowMediaInfo(currentMeta.id)
                                                                }
                                                            },
                                                            onDismiss = menuState::dismiss,
                                                        )
                                                    }
                                                }
                                            },
                                            modifier = Modifier.size(38.dp),
                                        ) {
                                            Icon(
                                                painter = painterResource(R.drawable.more_vert),
                                                contentDescription = "Thêm tùy chọn",
                                                tint = TextBackgroundColor,
                                                modifier = Modifier.size(22.dp),
                                            )
                                        }
                                    }
                                }

                                Spacer(Modifier.height(4.dp))

                                mediaMetadata?.let {
                                    controlsContent(it)
                                }

                                Spacer(Modifier.height(4.dp))
                            }
                        }
                    }

                    else -> {
                        val bottomPadding by animateDpAsState(
                            targetValue = if (isFullScreen) 0.dp else queueSheetState.collapsedBound,
                            label = "bottomPadding",
                        )
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier =
                                Modifier
                                    .windowInsetsPadding(WindowInsets.systemBars.only(WindowInsetsSides.Horizontal))
                                    .padding(bottom = bottomPadding)
                                    .animateContentSize(),
                        ) {
                            PlayerTopBar(
                                state = state,
                                playbackMode = playbackMode,
                                onPlaybackModeChange = { playbackMode = it },
                                mediaMetadata = mediaMetadata,
                                textButtonColor = textButtonColor,
                                iconButtonColor = iconButtonColor,
                                textColor = TextBackgroundColor,
                                onStandbyClick = { isStandbyMode = true },
                            )

                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.weight(1f),
                            ) {
                                // Remember lambdas to prevent unnecessary recomposition
                                val currentSliderPosition by rememberUpdatedState(sliderPosition)
                                val sliderPositionProvider = remember { { currentSliderPosition } }
                                val isExpandedProvider = remember(state) { { state.isExpanded } }
                                AnimatedContent(
                                    targetState = showInlineLyrics,
                                    label = "Lyrics",
                                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                                ) { showLyrics ->
                                    if (showLyrics) {
                                        InlineLyricsView(
                                            mediaMetadata = mediaMetadata,
                                            showLyrics = showLyrics,
                                            positionProvider = { effectivePosition },
                                        )
                                    } else {
                                        Thumbnail(
                                            sliderPositionProvider = sliderPositionProvider,
                                            modifier = Modifier.nestedScroll(state.preUpPostDownNestedScrollConnection),
                                            isPlayerExpanded = isExpandedProvider,
                                            isListenTogetherGuest = isListenTogetherGuest,
                                            isVideoMode = playbackMode == VideoPlaybackManager.PlaybackMode.VIDEO_PLAYBACK
                                        )
                                    }
                                }
                            }

                            mediaMetadata?.let {
                                controlsContent(it)
                            }

                            Spacer(Modifier.height(16.dp))
                        }
                    }
                }

                AnimatedVisibility(
                    visible = !isFullScreen && !isLandscape,
                    enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                    exit = shrinkVertically(shrinkTowards = Alignment.Top) + slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                ) {
                    Queue(
                        state = queueSheetState,
                        playerBottomSheetState = state,
                        background =
                            if (useBlackBackground) {
                                Color.Black
                            } else {
                                MaterialTheme.colorScheme.surfaceContainer
                            },
                        onBackgroundColor = onBackgroundColor,
                        TextBackgroundColor = TextBackgroundColor,
                        textButtonColor = textButtonColor,
                        iconButtonColor = iconButtonColor,
                        pureBlack = pureBlack,
                        showInlineLyrics = showInlineLyrics,
                        playerBackground = playerBackground,
                        onToggleLyrics = {
                            showInlineLyrics = !showInlineLyrics
                        },
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun InlineLyricsView(
    mediaMetadata: MediaMetadata?,
    showLyrics: Boolean,
    positionProvider: () -> Long,
) {
    val playerConnection = LocalPlayerConnection.current ?: return
    val currentLyrics by playerConnection.currentLyrics.collectAsStateWithLifecycle(initialValue = null)
    val queueWindows by playerConnection.queueWindows.collectAsStateWithLifecycle(initialValue = emptyList())
    val currentWindowIndex by playerConnection.currentWindowIndex.collectAsStateWithLifecycle(initialValue = -1)
    val lyrics = remember(currentLyrics) { currentLyrics?.lyrics?.trim() }
    val context = LocalContext.current
    val database = LocalDatabase.current
    val coroutineScope = rememberCoroutineScope()

    var appInForeground by remember {
        mutableStateOf(
            ProcessLifecycleOwner.get().lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED),
        )
    }
    DisposableEffect(Unit) {
        val lifecycle = ProcessLifecycleOwner.get().lifecycle
        val observer =
            LifecycleEventObserver { _, _ ->
                appInForeground = lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)
            }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }

    val nextMetadata =
        remember(queueWindows, currentWindowIndex) {
            if (currentWindowIndex >= 0 && currentWindowIndex + 1 < queueWindows.size) {
                queueWindows[currentWindowIndex + 1].mediaItem.metadata
            } else {
                null
            }
        }

    var isFetchingLyrics by remember { mutableStateOf(false) }

    LaunchedEffect(mediaMetadata?.id, currentLyrics) {
        if (mediaMetadata != null && currentLyrics == null) {
            isFetchingLyrics = true
            try {
                withContext(Dispatchers.IO) {
                    val entryPoint =
                        EntryPointAccessors.fromApplication(
                            context.applicationContext,
                            com.listrovia.music.di.LyricsHelperEntryPoint::class.java,
                        )
                    val lyricsHelper = entryPoint.lyricsHelper()
                    val fetchedLyricsWithProvider = lyricsHelper.getLyrics(mediaMetadata)
                    database.query {
                        upsert(LyricsEntity(mediaMetadata.id, fetchedLyricsWithProvider.lyrics, fetchedLyricsWithProvider.provider))
                    }
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: Exception) {
                // Handle error gracefully
            } finally {
                isFetchingLyrics = false
            }
        } else {
            isFetchingLyrics = false
        }
    }

    // Prefetch lyrics for the next queue item only while the lyrics pane is visible, the app is in the
    // foreground, and the current track's lyrics row has finished loading (avoids competing with the
    // active fetch).
    LaunchedEffect(
        nextMetadata?.id,
        showLyrics,
        appInForeground,
        mediaMetadata?.id,
        currentLyrics,
    ) {
        if (!showLyrics || !appInForeground || nextMetadata == null) return@LaunchedEffect
        val loadedForCurrent =
            currentLyrics?.let { lyrics ->
                mediaMetadata == null || lyrics.id == mediaMetadata.id
            } == true
        if (mediaMetadata != null && !loadedForCurrent) return@LaunchedEffect
        val nextId = nextMetadata.id
        delay(400)
        if (!showLyrics || !appInForeground || !isActive) return@LaunchedEffect
        withContext(Dispatchers.IO) {
            try {
                val existing = database.lyrics(nextId).first()
                if (existing != null) return@withContext
                val entryPoint =
                    EntryPointAccessors.fromApplication(
                        context.applicationContext,
                        com.listrovia.music.di.LyricsHelperEntryPoint::class.java,
                    )
                val lyricsHelper = entryPoint.lyricsHelper()
                val fetched = lyricsHelper.getLyrics(nextMetadata)
                database.query {
                    upsert(LyricsEntity(nextId, fetched.lyrics, fetched.provider))
                }
            } catch (_: Exception) {
            }
        }
    }

    val enableLiquidGlass by rememberPreference(EnableLiquidGlassKey, defaultValue = true)
    val glassSaturation by rememberPreference(GlassSaturationKey, defaultValue = 1.3f)
    val glassBlurRadius by rememberPreference(GlassBlurRadiusKey, defaultValue = 24f)
    val lensRefractionHeight by rememberPreference(LensRefractionHeightKey, defaultValue = 14f)
    val lensRefractionAmount by rememberPreference(LensRefractionAmountKey, defaultValue = 0.85f)
    val chromaticAberration by rememberPreference(ChromaticAberrationKey, defaultValue = 0.45f)
    val depthEffect by rememberPreference(DepthEffectKey, defaultValue = 0.75f)
    val surfaceOpacity by rememberPreference(SurfaceOpacityKey, defaultValue = 1.0f)
    val pureBlack by rememberPreference(PureBlackKey, defaultValue = false)

    val lyricsBgColor = if (pureBlack) Color.Black else MaterialTheme.colorScheme.surfaceContainerHigh

    Box(
        modifier =
            Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp, vertical = 4.dp)
                .then(
                    if (enableLiquidGlass) {
                        Modifier.liquidGlass(
                            enabled = true,
                            blurRadiusDp = glassBlurRadius,
                            saturation = glassSaturation,
                            refractionHeight = lensRefractionHeight,
                            refractionAmount = lensRefractionAmount,
                            chromaticAberration = chromaticAberration,
                            depthEffect = depthEffect,
                            surfaceOpacity = surfaceOpacity,
                            surfaceTintColor = lyricsBgColor,
                            shape = RoundedCornerShape(20.dp)
                        )
                    } else {
                        Modifier.background(lyricsBgColor, shape = RoundedCornerShape(20.dp))
                    }
                )
                .pointerInput(Unit) {
                    var totalDragX = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { totalDragX = 0f },
                        onHorizontalDrag = { _, dragAmount -> totalDragX += dragAmount },
                        onDragEnd = {
                            if (totalDragX < -80f && playerConnection.player.nextMediaItemIndex != -1) {
                                playerConnection.player.seekToNext()
                            } else if (totalDragX > 80f && playerConnection.player.previousMediaItemIndex != -1) {
                                playerConnection.player.seekToPreviousMediaItem()
                            }
                        }
                    )
                },
        contentAlignment = Alignment.Center,
    ) {
        when {
            lyrics == null || isFetchingLyrics -> {
                ContainedLoadingIndicator()
            }

            lyrics == LyricsEntity.LYRICS_NOT_FOUND -> {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(24.dp),
                ) {
                    Icon(
                        painter = painterResource(R.drawable.lyrics),
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = stringResource(R.string.lyrics_not_found),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            mediaMetadata?.let { meta ->
                                isFetchingLyrics = true
                                coroutineScope.launch(Dispatchers.IO) {
                                    try {
                                        val entryPoint =
                                            EntryPointAccessors.fromApplication(
                                                context.applicationContext,
                                                com.listrovia.music.di.LyricsHelperEntryPoint::class.java,
                                            )
                                        val lyricsHelper = entryPoint.lyricsHelper()
                                        val fetched = lyricsHelper.getLyrics(meta)
                                        database.query {
                                            upsert(LyricsEntity(meta.id, fetched.lyrics, fetched.provider))
                                        }
                                    } catch (_: Exception) {
                                    } finally {
                                        isFetchingLyrics = false
                                    }
                                }
                            }
                        },
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.refresh),
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(stringResource(R.string.retry))
                    }
                }
            }

            else -> {
                val lyricsContent: @Composable () -> Unit = {
                    Lyrics(
                        sliderPositionProvider = positionProvider,
                        modifier = Modifier.padding(horizontal = 24.dp),
                        showLyrics = showLyrics,
                    )
                }
                ProvideTextStyle(
                    value =
                        MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 14.sp,
                            textAlign = TextAlign.Center,
                        ),
                ) {
                    lyricsContent()
                }
            }
        }
    }
}

@Composable
fun MoreActionsButton(
    mediaMetadata: MediaMetadata,
    navController: NavController,
    state: BottomSheetState,
    textButtonColor: Color,
    iconButtonColor: Color,
) {
    val menuState = LocalMenuState.current
    val bottomSheetPageState = LocalBottomSheetPageState.current

    Box(
        modifier =
            Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(textButtonColor)
                .clickable {
                    menuState.show {
                        PlayerMenu(
                            mediaMetadata = mediaMetadata,
                            playerBottomSheetState = state,
                            onShowDetailsDialog = {
                                mediaMetadata.id.let {
                                    bottomSheetPageState.show {
                                        ShowMediaInfo(it)
                                    }
                                }
                            },
                            onDismiss = menuState::dismiss,
                        )
                    }
                },
    ) {
        Image(
            painter = painterResource(R.drawable.more_horiz),
            contentDescription = null,
            colorFilter = ColorFilter.tint(iconButtonColor),
        )
    }
}

@Composable
private fun PlayerTopBar(
    state: BottomSheetState,
    playbackMode: VideoPlaybackManager.PlaybackMode,
    onPlaybackModeChange: (VideoPlaybackManager.PlaybackMode) -> Unit,
    mediaMetadata: MediaMetadata?,
    textButtonColor: Color,
    iconButtonColor: Color,
    textColor: Color,
    onStandbyClick: () -> Unit,
) {
    val menuState = LocalMenuState.current
    val bottomSheetPageState = LocalBottomSheetPageState.current

    val isVideoMode = playbackMode == VideoPlaybackManager.PlaybackMode.VIDEO_PLAYBACK

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Collapse button (down arrow)
        androidx.compose.material3.IconButton(
            onClick = { state.collapseSoft() },
            modifier = Modifier.size(48.dp)
        ) {
            Icon(
                painter = painterResource(R.drawable.expand_more),
                contentDescription = "Collapse Player",
                tint = textColor,
                modifier = Modifier.size(28.dp)
            )
        }

        // Audio/Video switcher pill
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier
                .clip(RoundedCornerShape(24.dp))
                .background(textColor.copy(alpha = 0.10f))
                .padding(3.dp)
        ) {
            val audioBgColor by animateColorAsState(
                targetValue = if (!isVideoMode) textButtonColor else Color.Transparent,
                animationSpec = tween(250),
                label = "audioTabBg"
            )
            val audioIconColor by animateColorAsState(
                targetValue = if (!isVideoMode) iconButtonColor else textColor.copy(alpha = 0.65f),
                animationSpec = tween(250),
                label = "audioTabIcon"
            )
            val videoBgColor by animateColorAsState(
                targetValue = if (isVideoMode) textButtonColor else Color.Transparent,
                animationSpec = tween(250),
                label = "videoTabBg"
            )
            val videoIconColor by animateColorAsState(
                targetValue = if (isVideoMode) iconButtonColor else textColor.copy(alpha = 0.65f),
                animationSpec = tween(250),
                label = "videoTabIcon"
            )

            // Audio tab (Song)
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(width = 52.dp, height = 34.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(audioBgColor)
                    .clickable { onPlaybackModeChange(VideoPlaybackManager.PlaybackMode.AUDIO_ONLY) }
            ) {
                Icon(
                    painter = painterResource(R.drawable.headphone),
                    contentDescription = stringResource(R.string.playback_mode_audio_only),
                    tint = audioIconColor,
                    modifier = Modifier.size(19.dp)
                )
            }

            // Video tab
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(width = 52.dp, height = 34.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(videoBgColor)
                    .clickable { onPlaybackModeChange(VideoPlaybackManager.PlaybackMode.VIDEO_PLAYBACK) }
            ) {
                Icon(
                    painter = painterResource(R.drawable.video_mode),
                    contentDescription = stringResource(R.string.playback_mode_video),
                    tint = videoIconColor,
                    modifier = Modifier.size(19.dp)
                )
            }
        }

        // Bedtime/Sleep timer button
        androidx.compose.material3.IconButton(
            onClick = onStandbyClick,
            modifier = Modifier.size(44.dp)
        ) {
            Icon(
                painter = painterResource(R.drawable.bedtime),
                contentDescription = "Màn hình chờ",
                tint = textColor,
                modifier = Modifier.size(24.dp)
            )
        }

        // Cast button
        CastButton(
            modifier = Modifier.size(44.dp),
            tintColor = textColor
        )

        // More/Ellipsis menu
        androidx.compose.material3.IconButton(
            onClick = {
                if (mediaMetadata != null) {
                    menuState.show {
                        PlayerMenu(
                            mediaMetadata = mediaMetadata,
                            playerBottomSheetState = state,
                            onShowDetailsDialog = {
                                bottomSheetPageState.show {
                                    ShowMediaInfo(mediaMetadata.id)
                                }
                            },
                            onDismiss = menuState::dismiss,
                        )
                    }
                }
            },
            modifier = Modifier.size(44.dp)
        ) {
            Icon(
                painter = painterResource(R.drawable.more_vert),
                contentDescription = "More Options",
                tint = textColor,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}



@Composable
fun StandbyScreen(
    mediaMetadata: MediaMetadata?,
    isPlaying: Boolean,
    playerConnection: com.listrovia.music.playback.PlayerConnection,
    onClose: () -> Unit,
) {
    androidx.activity.compose.BackHandler {
        onClose()
    }

    var currentTime by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (true) {
            val sdf = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
            currentTime = sdf.format(java.util.Date())
            delay(1000)
        }
    }

    val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition(label = "vinylRotation")
    val angle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(15000, easing = androidx.compose.animation.core.LinearEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Restart
        ),
        label = "angle"
    )
    val rotation = if (isPlaying) angle else 0f

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070708))
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        // Exit button at top-right
        androidx.compose.material3.IconButton(
            onClick = onClose,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .statusBarsPadding()
                .padding(8.dp)
                .background(Color.White.copy(alpha = 0.08f), CircleShape)
        ) {
            Icon(
                painter = painterResource(R.drawable.close),
                contentDescription = "Thoát màn hình chờ",
                tint = Color.White
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Elegant large digital clock
            Text(
                text = currentTime,
                style = MaterialTheme.typography.displayLarge.copy(
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 44.sp,
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                ),
                color = Color.White.copy(alpha = 0.95f),
                maxLines = 1,
                softWrap = false,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Rotating Vinyl / Album Art
            Box(
                modifier = Modifier
                    .size(260.dp)
                    .graphicsLayer(rotationZ = rotation),
                contentAlignment = Alignment.Center
            ) {
                // Vinyl outer body
                androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                    drawCircle(color = Color(0xFF111112))
                    // Groove lines
                    for (i in 1..8) {
                        drawCircle(
                            color = Color.White.copy(alpha = 0.05f),
                            radius = size.minDimension / 2 * (i / 10f),
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.dp.toPx())
                        )
                    }
                }

                // Album Art in center
                Box(
                    modifier = Modifier
                        .size(130.dp)
                        .clip(CircleShape)
                        .background(Color.Black)
                ) {
                    AnimatedContent(
                        targetState = mediaMetadata?.thumbnailUrl,
                        transitionSpec = { fadeIn(tween(400)) togetherWith fadeOut(tween(400)) },
                        label = "vinylThumbnailFade",
                        modifier = Modifier.fillMaxSize(),
                    ) { url ->
                        if (url != null) {
                            AsyncImage(
                                model = url,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(MaterialTheme.colorScheme.surfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(R.drawable.ic_launcher_logo),
                                    contentDescription = null,
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier.size(120.dp)
                                )
                            }
                        }
                    }
                }

                // Vinyl center hole
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .background(Color(0xFF070708), CircleShape)
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Song Title & Artist
            Text(
                text = mediaMetadata?.title ?: "Không có bài hát",
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 24.dp)
            )

            Spacer(modifier = Modifier.height(4.dp))

            val standbyArtists = mediaMetadata?.artists?.filter { it.name.isNotBlank() }
                ?.joinToArtistString(" ${stringResource(R.string.and)} ") { it.name }
                ?.ifBlank { "Không có nghệ sĩ" } ?: "Không có nghệ sĩ"

            Text(
                text = standbyArtists,
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White.copy(alpha = 0.6f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 24.dp)
            )

            Spacer(modifier = Modifier.height(40.dp))

            // Minimal Controls Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                androidx.compose.material3.IconButton(
                    onClick = { playerConnection.seekToPrevious() },
                    modifier = Modifier
                        .size(56.dp)
                        .background(Color.White.copy(alpha = 0.05f), CircleShape)
                ) {
                    Icon(
                        painter = painterResource(R.drawable.skip_previous),
                        contentDescription = "Trước",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }

                androidx.compose.material3.IconButton(
                    onClick = { playerConnection.togglePlayPause() },
                    modifier = Modifier
                        .size(72.dp)
                        .background(Color.White, CircleShape)
                ) {
                    Icon(
                        painter = painterResource(
                            if (isPlaying) R.drawable.pause else R.drawable.play
                        ),
                        contentDescription = "Phát/Tạm dừng",
                        tint = Color.Black,
                        modifier = Modifier.size(36.dp)
                    )
                }

                androidx.compose.material3.IconButton(
                    onClick = { playerConnection.seekToNext() },
                    modifier = Modifier
                        .size(56.dp)
                        .background(Color.White.copy(alpha = 0.05f), CircleShape)
                ) {
                    Icon(
                        painter = painterResource(R.drawable.skip_next),
                        contentDescription = "Tiếp theo",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PillButton(
    onClick: () -> Unit,
    @androidx.annotation.DrawableRes icon: Int,
    text: String,
    contentColor: Color,
    containerColor: Color,
    modifier: Modifier = Modifier
) {
    androidx.compose.material3.Button(
        onClick = onClick,
        colors = androidx.compose.material3.ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor
        ),
        shape = RoundedCornerShape(50),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        modifier = modifier.height(40.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                painter = painterResource(icon),
                contentDescription = text,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
            )
        }
    }
}

@Composable
private fun LikeDislikePill(
    isLiked: Boolean,
    isDisliked: Boolean,
    likesCount: String,
    onLikeClick: () -> Unit,
    onDislikeClick: () -> Unit,
    contentColor: Color,
    containerColor: Color,
    modifier: Modifier = Modifier
) {
    androidx.compose.material3.Surface(
        color = containerColor,
        contentColor = contentColor,
        shape = RoundedCornerShape(50),
        modifier = modifier.height(40.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 4.dp)
        ) {
            // Like Button
            androidx.compose.material3.IconButton(
                onClick = onLikeClick,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    painter = painterResource(
                        if (isLiked) R.drawable.thumb_up_filled else R.drawable.media3_icon_thumb_up_unfilled
                    ),
                    contentDescription = "Thích",
                    tint = if (isLiked) MaterialTheme.colorScheme.primary else contentColor,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Likes count text if present
            if (likesCount.isNotEmpty()) {
                Text(
                    text = likesCount,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }

            // Divider
            Box(
                modifier = Modifier
                    .width(1.dp)
                    .height(16.dp)
                    .background(contentColor.copy(alpha = 0.2f))
            )

            // Dislike Button
            androidx.compose.material3.IconButton(
                onClick = onDislikeClick,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    painter = painterResource(
                        if (isDisliked) R.drawable.thumb_down_filled else R.drawable.media3_icon_thumb_down_unfilled
                    ),
                    contentDescription = "Không thích",
                    tint = if (isDisliked) MaterialTheme.colorScheme.error else contentColor,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

private fun getLikesCountString(songId: String?): String {
    if (songId == null) return ""
    // Deterministic random-looking but stable count based on songId hash
    val code = songId.hashCode().coerceAtLeast(0)
    val likes = (code % 850) + 150
    return if (likes >= 1000) {
        String.format(java.util.Locale.getDefault(), "%.1fk", likes / 1000f)
    } else {
        likes.toString()
    }
}

private fun getSharesCountString(songId: String?): String {
    if (songId == null) return "Chia sẻ"
    // Deterministic stable shares count
    val code = songId.hashCode().coerceAtLeast(0)
    val shares = (code % 280) + 20
    return shares.toString()
}
