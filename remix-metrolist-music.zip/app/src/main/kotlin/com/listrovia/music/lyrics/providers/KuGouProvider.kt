/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.lyrics.providers

import android.content.Context
import android.util.Base64
import com.listrovia.music.constants.EnableKugouKey
import com.listrovia.music.lyrics.LyricsProvider
import com.listrovia.music.utils.dataStore
import com.listrovia.music.utils.get
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.request.get
import io.ktor.client.request.parameter
import io.ktor.http.ContentType
import io.ktor.http.HttpStatusCode
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import timber.log.Timber
import kotlin.math.abs

data class Keyword(
    val title: String,
    val artist: String,
    val album: String? = null,
)

@Serializable
data class KuGouSearchSongResponse(
    val status: Int = 0,
    val errcode: Int = 0,
    val error: String = "",
    val data: SongData? = null,
) {
    @Serializable
    data class SongData(
        val info: List<SongInfo> = emptyList(),
    )

    @Serializable
    data class SongInfo(
        val duration: Int = 0,
        val hash: String = "",
    )
}

@Serializable
data class KuGouSearchLyricsResponse(
    val status: Int = 0,
    val info: String = "",
    val errcode: Int = 0,
    val errmsg: String = "",
    val expire: Int = 0,
    val candidates: List<Candidate> = emptyList(),
) {
    @Serializable
    data class Candidate(
        val id: Long = 0,
        @SerialName("product_from")
        val productFrom: String = "",
        val duration: Long = 0,
        val accesskey: String = "",
    )
}

@Serializable
data class KuGouDownloadLyricsResponse(
    val content: String = "",
)

/**
 * KuGou Lyrics Retrieval Engine
 */
object KuGou {
    private const val TAG = "KuGou"
    private const val PAGE_SIZE = 8
    private const val DURATION_TOLERANCE = 8

    var useTraditionalChinese: Boolean = false

    private val client by lazy {
        HttpClient(OkHttp) {
            install(ContentNegotiation) {
                val json = Json {
                    ignoreUnknownKeys = true
                    explicitNulls = false
                    encodeDefaults = true
                    isLenient = true
                }
                json(json)
                json(json, ContentType.Text.Html)
                json(json, ContentType.Text.Plain)
            }
            install(HttpTimeout) {
                requestTimeoutMillis = 15000
                connectTimeoutMillis = 10000
            }
            expectSuccess = false
        }
    }

    suspend fun getLyrics(
        title: String,
        artist: String,
        duration: Int,
        album: String? = null,
    ): Result<String> = runCatching {
        val keyword = generateKeyword(title, artist, album)
        val candidate = getLyricsCandidate(keyword, duration)
            ?: throw IllegalStateException("No lyrics candidate found for $title")

        val downloaded = downloadLyrics(candidate.id, candidate.accesskey)
        if (downloaded.content.isBlank()) {
            throw IllegalStateException("Empty lyrics content returned from KuGou")
        }

        val decoded = Base64.decode(downloaded.content, Base64.DEFAULT).decodeToString()
        decoded.normalizeLyrics().ifBlank {
            throw IllegalStateException("Normalized lyrics empty for $title")
        }
    }

    suspend fun getAllPossibleLyricsOptions(
        title: String,
        artist: String,
        duration: Int,
        album: String? = null,
        callback: (String) -> Unit,
    ) {
        try {
            val keyword = generateKeyword(title, artist, album)
            val songs = searchSongs(keyword)
            songs.data?.info?.forEach { song ->
                if (duration == -1 || abs(song.duration - duration) <= DURATION_TOLERANCE) {
                    val candidate = searchLyricsByHash(song.hash).candidates.firstOrNull()
                    if (candidate != null) {
                        runCatching {
                            val content = downloadLyrics(candidate.id, candidate.accesskey).content
                            if (content.isNotBlank()) {
                                val lyrics = Base64.decode(content, Base64.DEFAULT).decodeToString().normalizeLyrics()
                                if (lyrics.isNotBlank()) callback(lyrics)
                            }
                        }
                    }
                }
            }

            val keywordCandidates = searchLyricsByKeyword(keyword, duration).candidates
            keywordCandidates.forEach { candidate ->
                runCatching {
                    val content = downloadLyrics(candidate.id, candidate.accesskey).content
                    if (content.isNotBlank()) {
                        val lyrics = Base64.decode(content, Base64.DEFAULT).decodeToString().normalizeLyrics()
                        if (lyrics.isNotBlank()) callback(lyrics)
                    }
                }
            }
        } catch (e: Exception) {
            Timber.tag(TAG).w(e, "Error fetching all possible lyrics from KuGou")
        }
    }

    suspend fun getLyricsCandidate(
        keyword: Keyword,
        duration: Int,
    ): KuGouSearchLyricsResponse.Candidate? {
        val songResponse = searchSongs(keyword)
        songResponse.data?.info?.forEach { song ->
            if (duration == -1 || abs(song.duration - duration) <= DURATION_TOLERANCE) {
                val candidate = searchLyricsByHash(song.hash).candidates.firstOrNull()
                if (candidate != null) return candidate
            }
        }
        return searchLyricsByKeyword(keyword, duration).candidates.firstOrNull()
    }

    private suspend fun searchSongs(keyword: Keyword): KuGouSearchSongResponse {
        val query = buildString {
            append(keyword.title)
            append(" - ")
            append(keyword.artist)
            if (!keyword.album.isNullOrBlank()) {
                append(" ")
                append(keyword.album)
            }
        }
        return client.get("https://mobileservice.kugou.com/api/v3/search/song") {
            parameter("version", 9108)
            parameter("plat", 0)
            parameter("pagesize", PAGE_SIZE)
            parameter("showtype", 0)
            parameter("keyword", query)
        }.body()
    }

    private suspend fun searchLyricsByKeyword(
        keyword: Keyword,
        duration: Int,
    ): KuGouSearchLyricsResponse {
        val query = buildString {
            append(keyword.title)
            append(" - ")
            append(keyword.artist)
            if (!keyword.album.isNullOrBlank()) {
                append(" ")
                append(keyword.album)
            }
        }
        return client.get("https://lyrics.kugou.com/search") {
            parameter("ver", 1)
            parameter("man", "yes")
            parameter("client", "pc")
            if (duration != -1) {
                parameter("duration", duration * 1000)
            }
            parameter("keyword", query)
        }.body()
    }

    private suspend fun searchLyricsByHash(hash: String): KuGouSearchLyricsResponse =
        client.get("https://lyrics.kugou.com/search") {
            parameter("ver", 1)
            parameter("man", "yes")
            parameter("client", "pc")
            parameter("hash", hash)
        }.body()

    private suspend fun downloadLyrics(id: Long, accessKey: String): KuGouDownloadLyricsResponse =
        client.get("https://lyrics.kugou.com/download") {
            parameter("fmt", "lrc")
            parameter("charset", "utf8")
            parameter("client", "pc")
            parameter("ver", 1)
            parameter("id", id)
            parameter("accesskey", accessKey)
        }.body()

    private fun normalizeTitle(title: String) =
        title.replace(Regex("""\(.*?\)"""), "")
            .replace(Regex("""（.*?）"""), "")
            .replace(Regex("""「.*?」"""), "")
            .replace(Regex("""『.*?』"""), "")
            .replace(Regex("""<.*?>"""), "")
            .replace(Regex("""《.*?》"""), "")
            .replace(Regex("""〈.*?〉"""), "")
            .replace(Regex("""＜.*?＞"""), "")
            .trim()

    private fun normalizeArtist(artist: String) =
        artist.replace(", ", "、")
            .replace(" & ", "、")
            .replace(".", "")
            .replace("和", "、")
            .replace(Regex("""\(.*?\)"""), "")
            .replace(Regex("""（.*?）"""), "")
            .trim()

    fun generateKeyword(title: String, artist: String, album: String? = null) =
        Keyword(normalizeTitle(title), normalizeArtist(artist), album?.trim())

    private val ACCEPTED_REGEX = Regex("""^\[(\d\d):(\d\d)\.(\d{2,3})\].*""")
    private val BANNED_REGEX = Regex(""".+].+[:：].+""")

    private fun String.normalizeLyrics(): String {
        val lines = lines().filter { it.matches(ACCEPTED_REGEX) }
        if (lines.isEmpty()) return this

        var headCut = 0
        val headLimit = minOf(30, lines.size)
        for (i in 0 until headLimit) {
            if (lines[i].matches(BANNED_REGEX)) {
                headCut = i + 1
            }
        }
        val filtered = lines.drop(headCut)

        var tailCut = 0
        val tailLimit = minOf(30, filtered.size)
        for (i in 0 until tailLimit) {
            if (filtered[filtered.size - 1 - i].matches(BANNED_REGEX)) {
                tailCut = i + 1
            }
        }
        return filtered.dropLast(tailCut).joinToString("\n")
    }
}

/**
 * KuGou Lyrics Provider
 */
object KuGouLyricsProvider : LyricsProvider {
    override val name = "KuGou"

    override fun isEnabled(context: Context): Boolean =
        context.dataStore[EnableKugouKey] ?: true

    override suspend fun getLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): Result<String> = KuGou.getLyrics(title, artist, duration, album)

    override suspend fun getAllLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
        callback: (String) -> Unit,
    ) {
        KuGou.getAllPossibleLyricsOptions(title, artist, duration, album, callback)
    }
}
