package com.listrovia.music.ui.screens.equalizer.wizard

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.listrovia.music.eq.data.AutoEqApiService
import com.listrovia.music.eq.data.EQProfileRepository
import com.listrovia.music.eq.data.ParametricEQBand
import com.listrovia.music.eq.data.SavedEQProfile
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

/**
 * ViewModel for Wizard Screen
 * Handles global audio measurement search (Crinacle, Oratory1990, Rtings, Super*Review, Vietnam V-Sound)
 * completely free without requiring an API key.
 */
@HiltViewModel
class WizardViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val eqProfileRepository: EQProfileRepository
) : ViewModel() {

    private val autoEqSearch = AutoEqApiService(context)

    private val _state = MutableStateFlow(
        WizardState(
            isDatabaseReady = true,
            totalProfilesCount = autoEqSearch.getIndexedCount(),
            providersCount = AutoEqApiService.GLOBAL_PROVIDERS.size - 1
        )
    )
    val state: StateFlow<WizardState> = _state.asStateFlow()

    private var searchJob: Job? = null

    init {
        // Initial search to populate recommended devices right away
        searchModels("", "all", "all")

        // In background, build/refresh the full database index if cached or network available
        viewModelScope.launch {
            val success = autoEqSearch.buildIndex(forceRefresh = false)
            if (success) {
                _state.update {
                    it.copy(
                        totalProfilesCount = autoEqSearch.getIndexedCount()
                    )
                }
                // Refresh list with new index
                searchModels(_state.value.modelSearchQuery, _state.value.selectedProvider, _state.value.selectedForm)
            }
        }
    }

    /**
     * Download or synchronize full 9,000+ open global AutoEQ database from public CDN mirrors (100% free, no API key).
     */
    fun downloadDatabase() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, error = null) }
            val success = autoEqSearch.buildIndex(forceRefresh = true)
            if (!success) {
                _state.update {
                    it.copy(
                        isLoading = false,
                        error = "Failed to synchronize AutoEQ database. Using offline catalog."
                    )
                }
            } else {
                _state.update {
                    it.copy(
                        isLoading = false,
                        isDatabaseReady = true,
                        totalProfilesCount = autoEqSearch.getIndexedCount()
                    )
                }
                searchModels(_state.value.modelSearchQuery, _state.value.selectedProvider, _state.value.selectedForm)
            }
        }
    }

    // STEP 1: FILTERS & SEARCH

    fun onModelSearchQueryChanged(query: String) {
        _state.update { it.copy(modelSearchQuery = query) }

        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            delay(250)
            searchModels(query, _state.value.selectedProvider, _state.value.selectedForm)
        }
    }

    fun onProviderFilterChanged(provider: String) {
        _state.update { it.copy(selectedProvider = provider) }
        searchModels(_state.value.modelSearchQuery, provider, _state.value.selectedForm)
    }

    fun onFormFilterChanged(form: String) {
        _state.update { it.copy(selectedForm = form) }
        searchModels(_state.value.modelSearchQuery, _state.value.selectedProvider, form)
    }

    private fun searchModels(query: String, provider: String, form: String) {
        viewModelScope.launch {
            try {
                val groupedEntries = autoEqSearch.searchModels(query, provider, form)

                val models = groupedEntries.map { (modelName, entriesForModel) ->
                    val primaryProvider = entriesForModel.firstOrNull()?.source ?: "unknown"
                    val allProviders = entriesForModel.map { it.source }.distinct()
                    val primaryForm = entriesForModel.firstOrNull()?.form ?: "unknown"

                    DeviceModel(
                        id = modelName.lowercase().replace(" ", "_").replace("[^a-z0-9_]".toRegex(), ""),
                        name = modelName,
                        form = primaryForm,
                        primaryProvider = primaryProvider,
                        providers = allProviders,
                        hasMultipleVariants = entriesForModel.size > 1
                    )
                }

                _state.update {
                    it.copy(
                        models = models,
                        totalProfilesCount = autoEqSearch.getIndexedCount(),
                        isLoading = false
                    )
                }
            } catch (e: Exception) {
                _state.update {
                    it.copy(
                        models = emptyList(),
                        isLoading = false,
                        error = "Failed to search models: ${e.message}"
                    )
                }
            }
        }
    }

    fun onModelSelected(model: DeviceModel) {
        _state.update { it.copy(selectedModel = model) }
        loadVariants(model.id)
    }

    private fun loadVariants(modelId: String) {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, error = null) }

            try {
                val modelName = _state.value.selectedModel?.name ?: ""
                val entries = autoEqSearch.getVariantsForModel(modelName)

                if (entries.isEmpty()) {
                    _state.update {
                        it.copy(
                            isLoading = false,
                            error = "No EQ profiles found for $modelName"
                        )
                    }
                    return@launch
                }

                val variants = entries.mapIndexed { index, entry ->
                    val label = entry.label
                    val isANC = label.contains("(ANC", ignoreCase = true) ||
                            label.contains("ANC ON", ignoreCase = true) ||
                            label.contains("ANC Off", ignoreCase = true)
                    val isPadModified = label.contains("velour", ignoreCase = true) ||
                            (label.contains("pad", ignoreCase = true) &&
                            !label.contains("(sample", ignoreCase = true))

                    EQProfileVariant(
                        id = "${modelId}_${index}",
                        modelId = modelId,
                        name = entry.label,
                        variant = if (entries.size > 1) {
                            "${entry.source} - ${entry.rig}"
                        } else {
                            null
                        },
                        isANC = isANC,
                        isPadModified = isPadModified,
                        source = entry.source,
                        rig = entry.rig,
                        form = entry.form,
                        description = "Measured by ${entry.source} on ${entry.rig} (${entry.form})"
                    )
                }

                // Default auto-select the first variant
                val defaultSelected = if (variants.isNotEmpty()) setOf(variants.first().id) else emptySet()

                _state.update {
                    it.copy(
                        variants = variants,
                        selectedVariantIds = defaultSelected,
                        currentStep = WizardStep.VARIANT_SELECTION,
                        isLoading = false
                    )
                }
            } catch (e: Exception) {
                _state.update {
                    it.copy(
                        variants = emptyList(),
                        isLoading = false,
                        error = "Failed to load variants: ${e.message}"
                    )
                }
            }
        }
    }

    // STEP 2: VARIANT & TUNING SELECTION

    fun onVariantToggled(variantId: String) {
        _state.update { currentState ->
            val selectedIds = currentState.selectedVariantIds.toMutableSet()
            if (selectedIds.contains(variantId)) {
                selectedIds.remove(variantId)
            } else {
                selectedIds.add(variantId)
            }
            currentState.copy(selectedVariantIds = selectedIds)
        }
    }

    fun onTuningStyleChanged(style: String) {
        _state.update { it.copy(selectedTuningStyle = style) }
    }

    // NAVIGATION

    fun onNextClicked() {
        when (_state.value.currentStep) {
            WizardStep.MODEL_SELECTION -> {
                // Handled in onModelSelected
            }
            WizardStep.VARIANT_SELECTION -> {
                completeWizard()
            }
        }
    }

    fun onBackClicked() {
        _state.update { currentState ->
            when (currentState.currentStep) {
                WizardStep.VARIANT_SELECTION -> {
                    searchModels(currentState.modelSearchQuery, currentState.selectedProvider, currentState.selectedForm)
                    currentState.copy(
                        currentStep = WizardStep.MODEL_SELECTION,
                        variants = emptyList(),
                        selectedVariantIds = emptySet()
                    )
                }
                else -> currentState
            }
        }
    }

    private fun completeWizard() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, error = null) }

            try {
                val currentState = _state.value
                val selectedVariants = currentState.variants.filter {
                    currentState.selectedVariantIds.contains(it.id)
                }

                val modelName = currentState.selectedModel?.name ?: "Unknown"
                val profiles = mutableListOf<SavedEQProfile>()
                val entries = autoEqSearch.getVariantsForModel(modelName)
                val tuningStyle = currentState.selectedTuningStyle

                for (variant in selectedVariants) {
                    try {
                        val matchingEntry = entries.find {
                            it.label == variant.name &&
                                    it.source == variant.source &&
                                    it.rig == variant.rig
                        }

                        if (matchingEntry != null) {
                            val parametricEQ = autoEqSearch.loadEQ(matchingEntry)

                            if (parametricEQ != null) {
                                // Apply tuning style adjustments
                                val (tunedBands, tunedPreamp) = applyTuningAdjustment(
                                    bands = parametricEQ.bands,
                                    preamp = parametricEQ.preamp,
                                    tuningStyle = tuningStyle
                                )

                                val tuningSuffix = when (tuningStyle) {
                                    "vocal" -> " (V-Sound Vocal)"
                                    "bass" -> " (Bass Boost)"
                                    "treble" -> " (Treble & Detail)"
                                    "relaxing" -> " (Warm Relaxing)"
                                    else -> ""
                                }

                                val profile = SavedEQProfile(
                                    id = "${variant.id}_${tuningStyle}",
                                    name = "${variant.name}$tuningSuffix",
                                    deviceModel = variant.name,
                                    source = variant.source,
                                    rig = variant.rig,
                                    bands = tunedBands,
                                    preamp = tunedPreamp,
                                    isCustom = true,
                                    isActive = false
                                )
                                profiles.add(profile)
                            }
                        }
                    } catch (e: Exception) {
                        Timber.w(e, "Failed to load EQ for variant %s", variant.id)
                    }
                }

                if (profiles.isNotEmpty()) {
                    eqProfileRepository.saveProfiles(profiles)

                    // Auto-activate the first profile
                    eqProfileRepository.setActiveProfile(profiles.first().id)

                    _state.update {
                        it.copy(
                            isLoading = false,
                            isComplete = true
                        )
                    }
                } else {
                    _state.update {
                        it.copy(
                            isLoading = false,
                            error = "Failed to load any EQ profiles for the selected variants"
                        )
                    }
                }
            } catch (e: Exception) {
                _state.update {
                    it.copy(
                        isLoading = false,
                        error = "Failed to save profiles: ${e.message}"
                    )
                }
            }
        }
    }

    /**
     * Applies target curve / sound tuning style adjustments
     */
    private fun applyTuningAdjustment(
        bands: List<ParametricEQBand>,
        preamp: Double,
        tuningStyle: String
    ): Pair<List<ParametricEQBand>, Double> {
        val standardFrequencies = listOf(32.0, 64.0, 125.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0, 16000.0)

        // Ensure 10 standard bands mapped
        val bandMap = bands.associateBy { it.frequency }.toMutableMap()
        for (freq in standardFrequencies) {
            if (!bandMap.containsKey(freq)) {
                bandMap[freq] = ParametricEQBand(frequency = freq, gain = 0.0)
            }
        }

        val resultBands = standardFrequencies.map { freq ->
            val baseGain = bandMap[freq]?.gain ?: 0.0
            val deltaGain = when (tuningStyle) {
                "vocal" -> when (freq) {
                    500.0 -> 1.5
                    1000.0 -> 2.5
                    2000.0 -> 2.0
                    4000.0 -> 1.0
                    32.0, 64.0 -> -0.5
                    else -> 0.0
                }
                "bass" -> when (freq) {
                    32.0 -> 5.0
                    64.0 -> 4.0
                    125.0 -> 2.5
                    250.0 -> 1.0
                    else -> 0.0
                }
                "treble" -> when (freq) {
                    2000.0 -> 1.5
                    4000.0 -> 3.0
                    8000.0 -> 4.5
                    16000.0 -> 4.0
                    else -> 0.0
                }
                "relaxing" -> when (freq) {
                    125.0, 250.0 -> 1.5
                    2000.0, 4000.0 -> -1.5
                    8000.0 -> -2.0
                    else -> 0.0
                }
                else -> 0.0
            }
            val finalGain = ((baseGain + deltaGain) * 2).toInt() / 2.0
            ParametricEQBand(frequency = freq, gain = finalGain.coerceIn(-12.0, 12.0))
        }

        val deltaPreamp = when (tuningStyle) {
            "bass" -> -2.5
            "vocal" -> -1.5
            "treble" -> -2.0
            "relaxing" -> 0.5
            else -> 0.0
        }

        val finalPreamp = ((preamp + deltaPreamp) * 2).toInt() / 2.0

        return Pair(resultBands, finalPreamp.coerceIn(-15.0, 5.0))
    }
}
