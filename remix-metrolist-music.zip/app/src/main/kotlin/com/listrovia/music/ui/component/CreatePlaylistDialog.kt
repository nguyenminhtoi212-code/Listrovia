/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.component

import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.listrovia.innertube.YouTube
import com.listrovia.innertube.models.SongItem
import com.listrovia.music.LocalDatabase
import com.listrovia.music.R
import com.listrovia.music.constants.InnerTubeCookieKey
import com.listrovia.music.db.entities.PlaylistEntity
import com.listrovia.music.db.entities.PlaylistSongMap
import com.listrovia.music.extensions.isSyncEnabled
import com.listrovia.music.models.toMediaMetadata
import com.listrovia.music.utils.rememberPreference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.time.LocalDateTime
import java.time.LocalTime
import java.util.logging.Logger

@Composable
fun CreatePlaylistDialog(
    onDismiss: () -> Unit,
    initialTextFieldValue: String? = null,
    allowSyncing: Boolean = true,
    initialAiMode: Boolean = false,
    onPlaylistCreated: ((String) -> Unit)? = null,
) {
    val context = LocalContext.current
    val database = LocalDatabase.current
    val coroutineScope = rememberCoroutineScope()

    var isAiMode by remember { mutableStateOf(initialAiMode) }

    // Standard playlist states
    var playlistName by remember { mutableStateOf(initialTextFieldValue ?: "") }
    val publicVisStr = stringResource(R.string.playlist_visibility_public)
    val unlistedVisStr = stringResource(R.string.playlist_visibility_unlisted)
    val privateVisStr = stringResource(R.string.playlist_visibility_private)

    var visibilityMode by remember(publicVisStr) { mutableStateOf(publicVisStr) }
    var showVisibilityDropdown by remember { mutableStateOf(false) }
    var syncedPlaylist by remember { mutableStateOf(false) }

    val focusRequester = remember { FocusRequester() }

    val innerTubeCookie by rememberPreference(InnerTubeCookieKey, "")
    val isSignedIn = innerTubeCookie.isNotEmpty()

    val notLoggedInYoutubeStr = stringResource(R.string.not_logged_in_youtube)
    val syncDisabledStr = stringResource(R.string.sync_disabled)
    val visibilityOptions = listOf(publicVisStr, unlistedVisStr, privateVisStr)

    // AI playlist states
    var tuneIntoWeather by remember { mutableStateOf(false) }
    var aiPrompt by remember { mutableStateOf("") }
    var songCount by remember { mutableStateOf(15) }
    var isGeneratingAi by remember { mutableStateOf(false) }
    val emptyWarningStr = stringResource(R.string.ai_playlist_empty_warning)

    LaunchedEffect(isAiMode) {
        if (!isAiMode) {
            delay(200)
            focusRequester.requestFocus()
        }
    }

    val onDoneStandardAction = {
        if (playlistName.isNotBlank()) {
            coroutineScope.launch(Dispatchers.IO) {
                val browseId =
                    if (syncedPlaylist && isSignedIn) {
                        YouTube.createPlaylist(playlistName)
                    } else if (syncedPlaylist) {
                        Logger.getLogger("CreatePlaylistDialog").warning("Not signed in")
                        return@launch
                    } else {
                        null
                    }

                val playlistEntity =
                    PlaylistEntity(
                        name = playlistName,
                        browseId = browseId,
                        bookmarkedAt = LocalDateTime.now(),
                        isEditable = true,
                    )

                database.query {
                    insert(playlistEntity)
                }

                withContext(Dispatchers.Main) {
                    onPlaylistCreated?.invoke(playlistEntity.id)
                    onDismiss()
                }
            }
        }
    }

    fun generateAiPlaylist() {
        if (aiPrompt.isBlank() || isGeneratingAi) return
        isGeneratingAi = true

        coroutineScope.launch(Dispatchers.IO) {
            try {
                val weatherVibe = if (tuneIntoWeather) {
                    val hour = LocalTime.now().hour
                    when (hour) {
                        in 5..10 -> "morning energetic fresh"
                        in 11..16 -> "afternoon vibrant sunny"
                        in 17..20 -> "evening acoustic sunset chill"
                        else -> "late night lofi cozy ambient"
                    }
                } else ""

                val searchQuery = if (weatherVibe.isNotBlank()) {
                    "$aiPrompt $weatherVibe"
                } else {
                    aiPrompt.trim()
                }

                Timber.d("AI Playlist generation: query='$searchQuery', count=$songCount")

                val collectedSongs = mutableListOf<SongItem>()
                val seenIds = mutableSetOf<String>()

                // Search primary
                YouTube.search(searchQuery, YouTube.SearchFilter.FILTER_SONG).onSuccess { page ->
                    page.items.filterIsInstance<SongItem>().forEach { song ->
                        if (seenIds.add(song.id)) {
                            collectedSongs.add(song)
                        }
                    }
                }

                // Fallback query if needed
                if (collectedSongs.size < songCount && weatherVibe.isNotBlank()) {
                    YouTube.search(aiPrompt.trim(), YouTube.SearchFilter.FILTER_SONG).onSuccess { page ->
                        page.items.filterIsInstance<SongItem>().forEach { song ->
                            if (seenIds.add(song.id)) {
                                collectedSongs.add(song)
                            }
                        }
                    }
                }

                val finalSongs = collectedSongs.take(songCount)

                if (finalSongs.isEmpty()) {
                    withContext(Dispatchers.Main) {
                        isGeneratingAi = false
                        Toast.makeText(context, emptyWarningStr, Toast.LENGTH_SHORT).show()
                    }
                    return@launch
                }

                val playlistTitle = aiPrompt.trim().take(40).ifBlank { "AI Playlist" }
                val playlistEntity = PlaylistEntity(
                    name = playlistTitle,
                    bookmarkedAt = LocalDateTime.now(),
                    isEditable = true,
                )

                database.query {
                    insert(playlistEntity)
                }

                finalSongs.forEachIndexed { index, songItem ->
                    database.query {
                        insert(songItem.toMediaMetadata())
                        insert(
                            PlaylistSongMap(
                                playlistId = playlistEntity.id,
                                songId = songItem.id,
                                position = index
                            )
                        )
                    }
                }

                database.query {
                    updatePlaylistLastUpdated(playlistEntity.id)
                }

                withContext(Dispatchers.Main) {
                    isGeneratingAi = false
                    onPlaylistCreated?.invoke(playlistEntity.id)
                    onDismiss()
                }
            } catch (e: Exception) {
                Timber.e(e, "Error generating AI playlist")
                withContext(Dispatchers.Main) {
                    isGeneratingAi = false
                    Toast.makeText(context, emptyWarningStr, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    Dialog(
        onDismissRequest = {
            if (!isGeneratingAi) onDismiss()
        }
    ) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
            ),
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("create_playlist_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header Row with Mode Switcher Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isAiMode) stringResource(R.string.create_with_ai) else stringResource(R.string.new_playlist_title),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f)
                    )

                    // Mode Toggle Chips
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = !isAiMode,
                            onClick = { if (!isGeneratingAi) isAiMode = false },
                            label = { Text(stringResource(R.string.standard_playlist), style = MaterialTheme.typography.labelSmall) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )
                        FilterChip(
                            selected = isAiMode,
                            onClick = { if (!isGeneratingAi) isAiMode = true },
                            label = { Text("✨ AI", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    }
                }

                AnimatedContent(
                    targetState = isAiMode,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "playlist_mode_content"
                ) { aiModeActive ->
                    if (aiModeActive) {
                        // AI Playlist Mode (Matches User Screenshot)
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // 1. Tune into Weather Card
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surface,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                                        Text(
                                            text = stringResource(R.string.tune_into_weather),
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = stringResource(R.string.tune_into_weather_desc),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Switch(
                                        checked = tuneIntoWeather,
                                        onCheckedChange = { tuneIntoWeather = it },
                                        enabled = !isGeneratingAi,
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                                            checkedTrackColor = MaterialTheme.colorScheme.primary,
                                            uncheckedThumbColor = MaterialTheme.colorScheme.outline,
                                            uncheckedTrackColor = MaterialTheme.colorScheme.surfaceContainerHighest
                                        )
                                    )
                                }
                            }

                            // 2. Prompt Input Field
                            OutlinedTextField(
                                value = aiPrompt,
                                onValueChange = { aiPrompt = it },
                                placeholder = {
                                    Text(
                                        text = stringResource(R.string.ai_playlist_prompt_hint),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                },
                                enabled = !isGeneratingAi,
                                minLines = 3,
                                maxLines = 5,
                                shape = RoundedCornerShape(16.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("ai_playlist_prompt_input")
                            )

                            // 3. Number of Songs & Slider
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = stringResource(R.string.number_of_songs, songCount),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )

                                Slider(
                                    value = songCount.toFloat(),
                                    onValueChange = { songCount = it.toInt() },
                                    valueRange = 5f..50f,
                                    steps = 8,
                                    enabled = !isGeneratingAi,
                                    colors = SliderDefaults.colors(
                                        thumbColor = MaterialTheme.colorScheme.primary,
                                        activeTrackColor = MaterialTheme.colorScheme.primary,
                                        inactiveTrackColor = MaterialTheme.colorScheme.surfaceContainerHighest
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            // 4. Action Buttons for AI
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.End),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(
                                    onClick = onDismiss,
                                    enabled = !isGeneratingAi,
                                    modifier = Modifier.height(44.dp)
                                ) {
                                    Text(
                                        text = stringResource(R.string.cancel),
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }

                                Button(
                                    onClick = { generateAiPlaylist() },
                                    enabled = aiPrompt.isNotBlank() && !isGeneratingAi,
                                    shape = RoundedCornerShape(50),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.primary,
                                        contentColor = MaterialTheme.colorScheme.onPrimary,
                                        disabledContainerColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                                        disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                    ),
                                    modifier = Modifier
                                        .height(44.dp)
                                        .testTag("generate_ai_playlist_button")
                                ) {
                                    if (isGeneratingAi) {
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            CircularProgressIndicator(
                                                color = MaterialTheme.colorScheme.onPrimary,
                                                strokeWidth = 2.dp,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Text(
                                                text = stringResource(R.string.generating_ai_playlist),
                                                style = MaterialTheme.typography.labelLarge,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    } else {
                                        Text(
                                            text = stringResource(R.string.generate),
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    } else {
                        // Standard Playlist Creation Mode
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Input for Title
                            OutlinedTextField(
                                value = playlistName,
                                onValueChange = { playlistName = it },
                                label = { Text(stringResource(R.string.playlist_title_label)) },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = MaterialTheme.colorScheme.onSurface,
                                    unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                                    focusedLabelColor = MaterialTheme.colorScheme.primary,
                                    unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .focusRequester(focusRequester)
                            )

                            // Visibility Mode Selector
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { showVisibilityDropdown = true }
                            ) {
                                OutlinedTextField(
                                    value = visibilityMode,
                                    onValueChange = {},
                                    readOnly = true,
                                    enabled = false,
                                    label = { Text(stringResource(R.string.playlist_visibility_label)) },
                                    trailingIcon = {
                                        Icon(
                                            painter = painterResource(R.drawable.expand_more),
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onSurface
                                        )
                                    },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                        disabledBorderColor = MaterialTheme.colorScheme.outline,
                                        disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        disabledTrailingIconColor = MaterialTheme.colorScheme.onSurface
                                    ),
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                DropdownMenu(
                                    expanded = showVisibilityDropdown,
                                    onDismissRequest = { showVisibilityDropdown = false },
                                    modifier = Modifier.fillMaxWidth(0.8f)
                                ) {
                                    visibilityOptions.forEach { option ->
                                        DropdownMenuItem(
                                            text = { Text(option) },
                                            onClick = {
                                                visibilityMode = option
                                                showVisibilityDropdown = false
                                            }
                                        )
                                    }
                                }
                            }

                            // Collaborative / Sync Row
                            if (allowSyncing) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = stringResource(R.string.collaborate_sync),
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Switch(
                                        checked = syncedPlaylist,
                                        onCheckedChange = {
                                            coroutineScope.launch {
                                                val isYtmSyncEnabled = withContext(Dispatchers.IO) { context.isSyncEnabled() }
                                                if (!isSignedIn && !syncedPlaylist) {
                                                    Toast.makeText(context, notLoggedInYoutubeStr, Toast.LENGTH_SHORT).show()
                                                } else if (!isYtmSyncEnabled) {
                                                    Toast.makeText(context, syncDisabledStr, Toast.LENGTH_SHORT).show()
                                                } else {
                                                    syncedPlaylist = !syncedPlaylist
                                                }
                                            }
                                        },
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                                            checkedTrackColor = MaterialTheme.colorScheme.primary,
                                            uncheckedThumbColor = MaterialTheme.colorScheme.outline,
                                            uncheckedTrackColor = MaterialTheme.colorScheme.surfaceContainerHighest
                                        )
                                    )
                                }
                            }

                            // Action Buttons for Standard
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.End),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = onDismiss,
                                    shape = RoundedCornerShape(50),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        contentColor = MaterialTheme.colorScheme.onSurface
                                    ),
                                    modifier = Modifier.height(44.dp)
                                ) {
                                    Text(text = stringResource(R.string.cancel), style = MaterialTheme.typography.labelLarge)
                                }

                                Button(
                                    onClick = {
                                        onDoneStandardAction()
                                    },
                                    enabled = playlistName.isNotBlank(),
                                    shape = RoundedCornerShape(50),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.primary,
                                        contentColor = MaterialTheme.colorScheme.onPrimary,
                                        disabledContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.38f),
                                        disabledContentColor = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.38f)
                                    ),
                                    modifier = Modifier.height(44.dp)
                                ) {
                                    Text(
                                        text = stringResource(R.string.create),
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
