/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.navigation.NavController
import coil3.compose.AsyncImage
import com.listrovia.music.ui.utils.resize
import com.listrovia.innertube.YouTube
import com.listrovia.innertube.models.AlbumItem
import com.listrovia.music.LocalDatabase
import com.listrovia.music.LocalListenTogetherManager
import com.listrovia.music.LocalPlayerConnection
import com.listrovia.music.R
import com.listrovia.music.constants.NotificationsReadIdsKey
import com.listrovia.music.utils.rememberPreference
import java.time.Duration
import java.time.LocalDateTime
import kotlinx.coroutines.delay

enum class NotificationFilter {
    ALL, ARTISTS, ACTIVITY
}

enum class NotificationType {
    ARTIST_RELEASE, PLAYBACK, DOWNLOAD, LIKED, HISTORY, SYSTEM
}

@Immutable
data class NotificationItem(
    val id: String,
    val type: NotificationType,
    val title: String,
    val description: String,
    val time: String,
    val timestampMs: Long,
    val artistImageUrl: String? = null,
    val releaseArtworkUrl: String? = null,
    val iconRes: Int? = null,
    val iconColor: Color? = null,
    val route: String? = null
)

private fun formatRelativeTime(context: android.content.Context, timestampMs: Long): String {
    val now = System.currentTimeMillis()
    val diffMs = now - timestampMs
    val seconds = diffMs / 1000
    val minutes = seconds / 60
    val hours = minutes / 60
    val days = hours / 24

    return when {
        seconds < 60 -> context.getString(R.string.notif_just_now)
        minutes < 60 -> context.getString(R.string.notif_minutes_ago, minutes.toInt())
        hours < 24 -> context.getString(R.string.notif_hours_ago, hours.toInt())
        else -> context.getString(R.string.notif_days_ago, days.toInt())
    }
}

private fun formatEventTime(context: android.content.Context, timestamp: LocalDateTime): String {
    return try {
        val now = LocalDateTime.now()
        val duration = Duration.between(timestamp, now)
        val seconds = duration.seconds
        when {
            seconds < 60 -> context.getString(R.string.notif_just_now)
            seconds < 3600 -> context.getString(R.string.notif_minutes_ago, (seconds / 60).toInt())
            seconds < 86400 -> context.getString(R.string.notif_hours_ago, (seconds / 3600).toInt())
            else -> context.getString(R.string.notif_days_ago, (seconds / 86400).toInt())
        }
    } catch (e: Exception) {
        context.getString(R.string.notif_just_now)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsBottomSheet(
    onDismiss: () -> Unit,
    navController: NavController
) {
    val context = LocalContext.current
    val playerConnection = LocalPlayerConnection.current
    val database = LocalDatabase.current ?: playerConnection?.database
    val listenTogetherManager = LocalListenTogetherManager.current

    var selectedFilter by remember { mutableStateOf(NotificationFilter.ALL) }

    // Dynamic state observations
    val currentSongState by (playerConnection?.currentSong?.collectAsState() ?: remember { mutableStateOf(null) })
    val isPlayingState by (playerConnection?.isPlaying?.collectAsState() ?: remember { mutableStateOf(false) })

    val isInRoomState = listenTogetherManager?.isInRoom == true
    val isHostState = listenTogetherManager?.isHost == true

    val recentEvents by (database?.events()?.collectAsState(initial = emptyList()) ?: remember { mutableStateOf(emptyList()) })
    val downloadedSongs by (database?.downloadedSongsByCreateDateAsc()?.collectAsState(initial = emptyList()) ?: remember { mutableStateOf(emptyList()) })
    val likedSongsCount by (database?.likedSongsCount()?.collectAsState(initial = 0) ?: remember { mutableStateOf(0) })
    val bookmarkedArtists by (database?.artistsBookmarkedByCreateDateAsc()?.collectAsState(initial = emptyList()) ?: remember { mutableStateOf(emptyList()) })

    // Online new release albums from YouTube Music
    var onlineNewReleases by remember { mutableStateOf<List<AlbumItem>>(emptyList()) }
    LaunchedEffect(Unit) {
        YouTube.newReleaseAlbums().onSuccess { albums ->
            onlineNewReleases = albums
        }
    }

    // Save read notification IDs in DataStore
    var readIdsString by rememberPreference(NotificationsReadIdsKey, "")
    val readIds = remember(readIdsString) {
        readIdsString.split(",").filter { it.isNotEmpty() }.toSet()
    }

    val nowMs = remember { System.currentTimeMillis() }

    val notifications = remember(
        context,
        currentSongState,
        isPlayingState,
        isInRoomState,
        isHostState,
        recentEvents,
        downloadedSongs,
        likedSongsCount,
        bookmarkedArtists,
        onlineNewReleases
    ) {
        val list = mutableListOf<NotificationItem>()

        // 1. YouTube Music Artist Release Notifications
        // A. Online New Releases
        onlineNewReleases.take(10).forEachIndexed { index, album ->
            val artistName = album.artists?.firstOrNull()?.name ?: context.getString(R.string.artist)
            val releaseTimeMs = nowMs - (index + 1) * 3600000L * 2 // Hourly staggered timestamps
            val releaseDesc = if (album.year != null) {
                context.getString(R.string.notif_released_album_desc, album.title)
            } else {
                context.getString(R.string.notif_released_song_desc, album.title)
            }
            list.add(
                NotificationItem(
                    id = "yt_release_${album.id}",
                    type = NotificationType.ARTIST_RELEASE,
                    title = artistName,
                    description = releaseDesc,
                    time = formatRelativeTime(context, releaseTimeMs),
                    timestampMs = releaseTimeMs,
                    artistImageUrl = album.thumbnail.resize(300, 300),
                    releaseArtworkUrl = album.thumbnail.resize(300, 300),
                    route = "album/${album.id}"
                )
            )
        }

        // B. Bookmarked Artists Releases
        bookmarkedArtists.take(5).forEachIndexed { index, artist ->
            val releaseTimeMs = nowMs - ((index * 8) + 3) * 3600000L * 3
            list.add(
                NotificationItem(
                    id = "artist_bm_release_${artist.id}",
                    type = NotificationType.ARTIST_RELEASE,
                    title = artist.artist.name,
                    description = context.getString(R.string.notif_artist_update_desc),
                    time = formatRelativeTime(context, releaseTimeMs),
                    timestampMs = releaseTimeMs,
                    artistImageUrl = artist.artist.thumbnailUrl,
                    releaseArtworkUrl = artist.artist.thumbnailUrl,
                    route = "artist/${artist.id}"
                )
            )
        }

        // 2. Currently Playing
        currentSongState?.let { song ->
            list.add(
                NotificationItem(
                    id = "current_song_${song.id}",
                    type = NotificationType.PLAYBACK,
                    title = if (isPlayingState) context.getString(R.string.notif_playing_music) else context.getString(R.string.notif_paused_music),
                    description = "${song.title} • ${song.artists.joinToString { it.name }}",
                    time = context.getString(R.string.notif_time_current),
                    timestampMs = nowMs,
                    iconRes = if (isPlayingState) R.drawable.play else R.drawable.pause,
                    iconColor = Color(0xFF4CAF50),
                    releaseArtworkUrl = song.thumbnailUrl,
                    route = null
                )
            )
        }

        // 3. Listen Together Active Session
        if (isInRoomState) {
            list.add(
                NotificationItem(
                    id = "listen_together_active",
                    type = NotificationType.SYSTEM,
                    title = context.getString(R.string.notif_listen_together_room_open),
                    description = if (isHostState) context.getString(R.string.notif_listen_together_host_desc) else context.getString(R.string.notif_listen_together_member_desc),
                    time = context.getString(R.string.notif_time_live),
                    timestampMs = nowMs - 10000L,
                    iconRes = R.drawable.group,
                    iconColor = Color(0xFF2196F3),
                    route = "listen_together"
                )
            )
        }

        // 4. Offline downloads info
        if (downloadedSongs.isNotEmpty()) {
            list.add(
                NotificationItem(
                    id = "downloaded_songs_status",
                    type = NotificationType.DOWNLOAD,
                    title = context.getString(R.string.notif_downloads_completed),
                    description = context.getString(R.string.notif_downloads_desc, downloadedSongs.size),
                    time = context.getString(R.string.notif_time_offline),
                    timestampMs = nowMs - 7200000L,
                    iconRes = R.drawable.download,
                    iconColor = Color(0xFFFF9800),
                    route = "local_playlist/LP_DOWNLOADED"
                )
            )
        }

        // 5. Liked Songs info
        if (likedSongsCount > 0) {
            list.add(
                NotificationItem(
                    id = "liked_songs_status",
                    type = NotificationType.LIKED,
                    title = context.getString(R.string.notif_your_favorites),
                    description = context.getString(R.string.notif_favorites_desc, likedSongsCount),
                    time = context.getString(R.string.notif_time_sync),
                    timestampMs = nowMs - 14400000L,
                    iconRes = R.drawable.favorite,
                    iconColor = Color(0xFFE91E63),
                    route = "online_playlist/LM"
                )
            )
        }

        // 6. Recent History
        recentEvents.take(4).forEachIndexed { idx, eventWithSong ->
            val song = eventWithSong.song
            val eventTimeMs = nowMs - (idx + 1) * 3600000L * 4
            list.add(
                NotificationItem(
                    id = "history_event_${eventWithSong.event.id}",
                    type = NotificationType.HISTORY,
                    title = context.getString(R.string.notif_listened_recently),
                    description = "${song.song.title} • ${song.artists.joinToString { it.name }}",
                    time = formatRelativeTime(context, eventTimeMs),
                    timestampMs = eventTimeMs,
                    iconRes = R.drawable.history,
                    iconColor = Color(0xFF9C27B0),
                    releaseArtworkUrl = song.song.thumbnailUrl,
                    route = "history"
                )
            )
        }

        // Sort strictly by timestamp descending (newest first)
        list.sortedByDescending { it.timestampMs }
    }

    val filteredNotifications = remember(notifications, selectedFilter) {
        when (selectedFilter) {
            NotificationFilter.ALL -> notifications
            NotificationFilter.ARTISTS -> notifications.filter { it.type == NotificationType.ARTIST_RELEASE }
            NotificationFilter.ACTIVITY -> notifications.filter { it.type != NotificationType.ARTIST_RELEASE }
        }
    }

    var isVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        isVisible = true
    }

    var isClosing by remember { mutableStateOf(false) }
    val handleDismiss: () -> Unit = {
        if (!isClosing) {
            isClosing = true
            isVisible = false
        }
    }

    LaunchedEffect(isVisible) {
        if (!isVisible && isClosing) {
            delay(220)
            onDismiss()
        }
    }

    Dialog(
        onDismissRequest = handleDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = handleDismiss
                ),
            contentAlignment = Alignment.TopCenter
        ) {
            AnimatedVisibility(
                visible = isVisible,
                enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(0.85f)
                        .statusBarsPadding()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = {}
                        ),
                    shape = RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    tonalElevation = 8.dp,
                    shadowElevation = 12.dp
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Top Header Bar
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            painter = painterResource(R.drawable.notification),
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = stringResource(R.string.notif_header_title),
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                val unreadCount = notifications.count { it.id !in readIds }
                                if (unreadCount > 0) {
                                    TextButton(
                                        onClick = {
                                            val allIds = notifications.map { it.id }.joinToString(",")
                                            readIdsString = allIds
                                        }
                                    ) {
                                        Text(
                                            text = "${stringResource(R.string.notif_mark_all_read)} ($unreadCount)",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }

                                IconButton(onClick = handleDismiss) {
                                    Icon(
                                        painter = painterResource(R.drawable.close),
                                        contentDescription = stringResource(R.string.close),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

            // YouTube Music Category Filter Chips
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = selectedFilter == NotificationFilter.ALL,
                        onClick = { selectedFilter = NotificationFilter.ALL },
                        label = { Text("${stringResource(R.string.filter_all)} (${notifications.size})") },
                        shape = RoundedCornerShape(20.dp),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                }
                item {
                    val artistCount = notifications.count { it.type == NotificationType.ARTIST_RELEASE }
                    FilterChip(
                        selected = selectedFilter == NotificationFilter.ARTISTS,
                        onClick = { selectedFilter = NotificationFilter.ARTISTS },
                        label = { Text("${stringResource(R.string.filter_artists)} ($artistCount)") },
                        shape = RoundedCornerShape(20.dp),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                }
                item {
                    val activityCount = notifications.count { it.type != NotificationType.ARTIST_RELEASE }
                    FilterChip(
                        selected = selectedFilter == NotificationFilter.ACTIVITY,
                        onClick = { selectedFilter = NotificationFilter.ACTIVITY },
                        label = { Text("${stringResource(R.string.filter_library)} ($activityCount)") },
                        shape = RoundedCornerShape(20.dp),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            if (filteredNotifications.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(240.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.notification),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = stringResource(R.string.no_notifications),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(filteredNotifications, key = { it.id }) { item ->
                        val isUnread = item.id !in readIds

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .clickable {
                                    if (isUnread) {
                                        val newIds = (readIds + item.id).joinToString(",")
                                        readIdsString = newIds
                                    }
                                    handleDismiss()
                                    item.route?.let {
                                        navController.navigate(it)
                                    }
                                },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isUnread) {
                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.18f)
                                } else {
                                    MaterialTheme.colorScheme.surfaceContainer
                                }
                            ),
                            border = if (isUnread) {
                                CardDefaults.outlinedCardBorder().copy(
                                    brush = androidx.compose.ui.graphics.SolidColor(
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
                                    )
                                )
                            } else null
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Left Icon / Artist Avatar
                                if (item.type == NotificationType.ARTIST_RELEASE && !item.artistImageUrl.isNullOrEmpty()) {
                                    Box(modifier = Modifier.size(48.dp)) {
                                        AsyncImage(
                                            model = item.artistImageUrl,
                                            contentDescription = item.title,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .clip(CircleShape)
                                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                        )
                                        Box(
                                            modifier = Modifier
                                                .size(16.dp)
                                                .background(MaterialTheme.colorScheme.primary, CircleShape)
                                                .align(Alignment.BottomEnd),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                painter = painterResource(R.drawable.music_note),
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.onPrimary,
                                                modifier = Modifier.size(10.dp)
                                            )
                                        }
                                    }
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(48.dp)
                                            .background(
                                                color = (item.iconColor ?: MaterialTheme.colorScheme.primary).copy(alpha = 0.15f),
                                                shape = CircleShape
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            painter = painterResource(item.iconRes ?: R.drawable.notification),
                                            contentDescription = null,
                                            tint = item.iconColor ?: MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }

                                // Text details
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = item.title,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = if (isUnread) FontWeight.Bold else FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f)
                                        )

                                        if (isUnread) {
                                            Box(
                                                modifier = Modifier
                                                    .size(8.dp)
                                                    .background(
                                                        color = MaterialTheme.colorScheme.primary,
                                                        shape = CircleShape
                                                    )
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(3.dp))

                                    Text(
                                        text = item.description,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Text(
                                        text = item.time,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                                        fontWeight = FontWeight.Medium
                                    )
                                }

                                // Right Release Artwork Thumbnail (if available)
                                if (!item.releaseArtworkUrl.isNullOrEmpty()) {
                                    AsyncImage(
                                        model = item.releaseArtworkUrl,
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(48.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Bottom pill indicator for top sheet
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .width(38.dp)
                        .height(4.dp)
                        .background(
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                            shape = CircleShape
                        )
                )
            }
        }
    }
}
}
}
}


