/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.playback.queues

import androidx.media3.common.MediaItem
import com.listrovia.innertube.YouTube
import com.listrovia.innertube.models.SongItem
import com.listrovia.music.extensions.toMediaItem
import com.listrovia.music.models.MediaMetadata
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive

class YouTubePlaylistQueue(
    private val playlistId: String,
    private val playlistTitle: String? = null,
    private val initialSongs: List<SongItem> = emptyList(),
    private val initialContinuation: String? = null,
    private val startIndex: Int = 0,
    override val preloadItem: MediaMetadata? = null,
) : Queue {
    private var continuation: String? = initialContinuation
    private var retryCount = 0
    private val maxRetries = 3

    override suspend fun getInitialStatus(): Queue.Status {
        return withContext(IO) {
            if (initialSongs.isNotEmpty()) {
                Queue.Status(
                    title = playlistTitle,
                    items = initialSongs.map { it.toMediaItem() },
                    mediaItemIndex = startIndex,
                )
            } else {
                if (playlistId.startsWith("am_") || playlistId.startsWith("am_pl_")) {
                    val cleanId = playlistId.removePrefix("am_pl_").removePrefix("am_")
                    val songsList = mutableListOf<SongItem>()
                    var playlistTitleResult = playlistTitle ?: "Apple Music Playlist"
                    
                    if (cleanId.all { it.isDigit() }) {
                        try {
                            val url = "https://itunes.apple.com/lookup?id=$cleanId&entity=song&country=vn"
                            val request = okhttp3.Request.Builder()
                                .url(url)
                                .header("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)")
                                .build()
                            val client = okhttp3.OkHttpClient.Builder()
                                .connectTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
                                .readTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
                                .build()

                            client.newCall(request).execute().use { response ->
                                if (response.isSuccessful) {
                                    val body = response.body?.string().orEmpty()
                                    if (body.isNotBlank()) {
                                        val json = kotlinx.serialization.json.Json { ignoreUnknownKeys = true; isLenient = true }
                                        val root = json.parseToJsonElement(body).jsonObject
                                        val results = root["results"]?.jsonArray ?: kotlinx.serialization.json.JsonArray(emptyList())

                                        results.forEach { item ->
                                            val obj = item.jsonObject
                                            val wrapperType = obj["wrapperType"]?.jsonPrimitive?.content ?: ""
                                            if (wrapperType == "collection") {
                                                val collectionName = obj["collectionName"]?.jsonPrimitive?.content
                                                if (!collectionName.isNullOrBlank()) {
                                                    playlistTitleResult = collectionName.toString()
                                                }
                                            } else if (wrapperType == "track") {
                                                val trackId = obj["trackId"]?.jsonPrimitive?.content ?: ""
                                                val trackName = obj["trackName"]?.jsonPrimitive?.content ?: ""
                                                val artistName = obj["artistName"]?.jsonPrimitive?.content ?: "Apple Music"
                                                val albumName = obj["collectionName"]?.jsonPrimitive?.content ?: ""
                                                val art = (obj["artworkUrl100"]?.jsonPrimitive?.content ?: "").replace("100x100bb.jpg", "600x600bb.jpg")
                                                val durationSec = obj["trackTimeMillis"]?.jsonPrimitive?.content?.toIntOrNull()?.let { it / 1000 }
                                                val isExplicit = obj["trackExplicitness"]?.jsonPrimitive?.content == "explicit"

                                                if (trackName.isNotBlank() && trackId.isNotBlank()) {
                                                    songsList.add(
                                                        SongItem(
                                                            id = "am_$trackId",
                                                            title = trackName,
                                                            artists = listOf(com.listrovia.innertube.models.Artist(id = null, name = artistName)),
                                                            album = if (albumName.isNotBlank()) com.listrovia.innertube.models.Album(id = "", name = albumName) else null,
                                                            duration = durationSec,
                                                            thumbnail = art,
                                                            explicit = isExplicit
                                                        )
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            timber.log.Timber.e(e, "Error in iTunes lookup for Apple Music playlist queue")
                        }
                    }

                    if (songsList.isEmpty()) {
                        try {
                            val searchQuery = if (cleanId.all { it.isDigit() }) "Apple Music Top Hits" else cleanId.ifBlank { "Apple Music Top Hits" }
                            val appleAdapter = com.listrovia.music.unified.AppleMusicAdapter()
                            val tracks = appleAdapter.searchTracks(searchQuery, 25)
                            val finalTracks = if (tracks.isNotEmpty()) tracks else appleAdapter.getRecommendations(com.listrovia.music.api.MusicCountry.VIETNAM, com.listrovia.music.api.MusicCategory.ALL, 25)
                            
                            finalTracks.forEach { track ->
                                songsList.add(
                                    SongItem(
                                        id = track.id,
                                        title = track.title,
                                        artists = listOf(com.listrovia.innertube.models.Artist(id = null, name = track.artist)),
                                        album = if (track.album.isNotBlank()) com.listrovia.innertube.models.Album(id = "", name = track.album) else null,
                                        duration = track.durationSeconds,
                                        thumbnail = track.thumbnailUrl,
                                        explicit = track.isExplicit
                                    )
                                )
                            }
                        } catch (e: Exception) {
                            timber.log.Timber.e(e, "Fallback error for Apple Music playlist queue search")
                        }
                    }
                    if (playlistTitleResult.all { it.isDigit() }) {
                        playlistTitleResult = com.listrovia.music.App.instance.getString(com.listrovia.music.R.string.apple_music_playlist_fallback)
                    }
                    continuation = null
                    Queue.Status(
                        title = playlistTitleResult,
                        items = songsList.map { it.toMediaItem() },
                        mediaItemIndex = startIndex,
                    )
                } else {
                    val playlistPage = YouTube.playlist(playlistId).getOrThrow()
                    continuation = playlistPage.songsContinuation
                    Queue.Status(
                        title = playlistPage.playlist.title,
                        items = playlistPage.songs.map { it.toMediaItem() },
                        mediaItemIndex = startIndex,
                    )
                }
            }
        }
    }

    override fun hasNextPage(): Boolean = continuation != null

    override suspend fun nextPage(): List<MediaItem> {
        return withContext(IO) {
            val currentContinuation = continuation ?: return@withContext emptyList()
            var lastException: Throwable? = null
            
            for (attempt in 0..maxRetries) {
                try {
                    val continuationPage = YouTube.playlistContinuation(currentContinuation).getOrThrow()
                    continuation = continuationPage.continuation
                    retryCount = 0
                    return@withContext continuationPage.songs.map { it.toMediaItem() }
                } catch (e: Exception) {
                    lastException = e
                    retryCount++
                    if (retryCount >= maxRetries) {
                        continuation = null
                    }
                }
            }
            throw lastException ?: Exception("Failed to get next page")
        }
    }
}
