/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.screens.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextButton
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.listrovia.music.BuildConfig
import com.listrovia.music.LocalPlayerAwareWindowInsets
import com.listrovia.music.R
import com.listrovia.music.constants.AudioNormalizationKey
import com.listrovia.music.constants.AudioOffload
import com.listrovia.music.constants.AudioTrackPlaybackParamsKey
import com.listrovia.music.constants.AudioQuality
import com.listrovia.music.constants.AudioQualityKey
import com.listrovia.music.constants.AutoDownloadOnLikeKey
import com.listrovia.music.constants.CrossfadeDurationKey
import com.listrovia.music.constants.CrossfadeEnabledKey
import com.listrovia.music.constants.CrossfadeGaplessKey
import com.listrovia.music.constants.AutomixEnabledKey
import com.listrovia.music.constants.AutomixBlendPointKey
import com.listrovia.music.constants.AutoLoadMoreKey
import com.listrovia.music.constants.AutoRadioQueueKey
import com.listrovia.music.constants.AutoSkipNextOnErrorKey
import com.listrovia.music.constants.AutoplayKey
import com.listrovia.music.constants.DisableLoadMoreWhenRepeatAllKey
import com.listrovia.music.constants.EnableGoogleCastKey
import com.listrovia.music.constants.EnableHapticsKey
import com.listrovia.music.constants.HapticsPlaybackControlsKey
import com.listrovia.music.constants.HapticsSeekbarKey
import com.listrovia.music.constants.HapticsButtonsKey
import com.listrovia.music.constants.HistoryDuration
import com.listrovia.music.constants.KeepScreenOn
import com.listrovia.music.constants.RealTimeVisualizerEnabledKey
import com.listrovia.music.constants.RealTimeVisualizerStyleKey
import com.listrovia.music.constants.LoudnessLevel
import com.listrovia.music.constants.LoudnessLevelKey
import com.listrovia.music.constants.PauseOnMute
import com.listrovia.music.constants.PersistentQueueKey
import com.listrovia.music.constants.PersistentShuffleAcrossQueuesKey
import com.listrovia.music.constants.PreventDuplicateTracksInQueueKey
import com.listrovia.music.constants.RememberShuffleAndRepeatKey
import com.listrovia.music.constants.ResumeOnBluetoothConnectKey
import com.listrovia.music.constants.SeekExtraSeconds
import com.listrovia.music.constants.ShufflePlaylistFirstKey
import com.listrovia.music.constants.SmartShuffleKey
import com.listrovia.music.constants.IntelligentShuffleKey
import com.listrovia.music.constants.SimilarContent
import com.listrovia.music.constants.SkipSilenceInstantKey
import com.listrovia.music.constants.SkipSilenceKey
import com.listrovia.music.constants.StopMusicOnTaskClearKey
import com.listrovia.music.constants.VarispeedKey
import com.listrovia.music.constants.LateNightModeKey
import com.listrovia.music.constants.VideoModeKey
import com.listrovia.music.constants.VideoQualityKey
import com.listrovia.music.video.AuraPlayerUtils
import com.listrovia.music.video.AuraPlayerUtils.VideoQuality
import com.listrovia.music.constants.AuraCanvasKey
import com.listrovia.music.constants.ClosedCaptionsKey
import com.listrovia.music.constants.PreferredSubtitleLangKey
import com.listrovia.music.constants.SponsorBlockEnabledKey
import com.listrovia.music.constants.SponsorBlockSkipSponsorKey
import com.listrovia.music.constants.SponsorBlockSkipSelfPromoKey
import com.listrovia.music.constants.SponsorBlockSkipInteractionKey
import com.listrovia.music.constants.SponsorBlockSkipIntroKey
import com.listrovia.music.constants.SponsorBlockSkipOutroKey
import com.listrovia.music.constants.SponsorBlockSkipPreviewKey
import com.listrovia.music.constants.SponsorBlockSkipNonMusicKey
import com.listrovia.music.constants.SponsorBlockSkipFillerKey
import com.listrovia.music.constants.VoiceCommandsEnabledKey
import com.listrovia.music.constants.HandsFreeWakeWordKey
import com.listrovia.music.constants.CustomWakeWordKey
import com.listrovia.music.constants.VoiceResponsesEnabledKey
import com.listrovia.music.constants.AssistantVoiceKey
import com.listrovia.music.constants.VoicePitchKey
import com.listrovia.music.constants.SpeechRateKey
import com.listrovia.music.ui.component.DefaultDialog
import com.listrovia.music.ui.component.EnumDialog
import com.listrovia.music.ui.component.IconButton
import com.listrovia.music.ui.component.Material3SettingsGroup
import com.listrovia.music.ui.component.Material3SettingsItem
import com.listrovia.music.ui.utils.backToMain
import com.listrovia.music.utils.rememberEnumPreference
import com.listrovia.music.utils.rememberPreference
import kotlin.math.roundToInt
import com.listrovia.music.ui.component.SleepTimerDialog
import com.listrovia.music.constants.SleepTimerEnabledKey
import com.listrovia.music.constants.SleepTimerRepeatKey
import com.listrovia.music.constants.SleepTimerCustomDaysKey
import com.listrovia.music.constants.SleepTimerEndTimeKey
import com.listrovia.music.constants.SleepTimerStartTimeKey
import com.listrovia.music.constants.SleepTimerDayTimesKey
import com.listrovia.music.ui.component.decodeDayTimes
import com.listrovia.music.ui.component.encodeDayTimes
import com.listrovia.music.constants.SleepTimerFadeOutKey
import com.listrovia.music.constants.SleepTimerStopAfterCurrentSongKey
import com.listrovia.music.ui.utils.getLoudnessLevelLabel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerSettings(
    navController: NavController
) {
    val (audioQuality, onAudioQualityChange) = rememberEnumPreference(
        AudioQualityKey,
        defaultValue = AudioQuality.AUTO
    )
    val (crossfadeEnabled, onCrossfadeEnabledChange) = rememberPreference(
        CrossfadeEnabledKey,
        defaultValue = false
    )
    val (crossfadeDuration, onCrossfadeDurationChange) = rememberPreference(
        CrossfadeDurationKey,
        defaultValue = 5f
    )
    val (crossfadeGapless, onCrossfadeGaplessChange) = rememberPreference(
        CrossfadeGaplessKey,
        defaultValue = true
    )
    val (automixEnabled, onAutomixEnabledChange) = rememberPreference(
        AutomixEnabledKey,
        defaultValue = false
    )
    val (automixBlendPoint, onAutomixBlendPointChange) = rememberPreference(
        AutomixBlendPointKey,
        defaultValue = 90f
    )
    val (persistentQueue, onPersistentQueueChange) = rememberPreference(
        PersistentQueueKey,
        defaultValue = true
    )
    val (skipSilence, onSkipSilenceChange) = rememberPreference(
        SkipSilenceKey,
        defaultValue = false
    )
    val (skipSilenceInstant, onSkipSilenceInstantChange) = rememberPreference(
        SkipSilenceInstantKey,
        defaultValue = false
    )
    val (audioNormalization, onAudioNormalizationChange) = rememberPreference(
        AudioNormalizationKey,
        defaultValue = true
    )

    val (loudnessLevel, onLoudnessLevelChange) = rememberEnumPreference(
        LoudnessLevelKey,
        defaultValue = LoudnessLevel.BALANCED,
    )

    val (audioOffload, onAudioOffloadChange) = rememberPreference(
        key = AudioOffload,
        defaultValue = false
    )

    val (audioTrackPlaybackParams, onAudioTrackPlaybackParamsChange) = rememberPreference(
        key = AudioTrackPlaybackParamsKey,
        defaultValue = true
    )

    val (varispeed, onVarispeedChange) = rememberPreference(
        key = VarispeedKey,
        defaultValue = false
    )

    val (enableGoogleCast, onEnableGoogleCastChange) = rememberPreference(
        key = EnableGoogleCastKey,
        defaultValue = true
    )

    val (seekExtraSeconds, onSeekExtraSeconds) = rememberPreference(
        SeekExtraSeconds,
        defaultValue = false
    )

    val (autoLoadMore, onAutoLoadMoreChange) = rememberPreference(
        AutoLoadMoreKey,
        defaultValue = false
    )
    val (autoRadioQueue, onAutoRadioQueueChange) = rememberPreference(
        AutoRadioQueueKey,
        defaultValue = false
    )
    val (allowExternalPlay, onAllowExternalPlayChange) = rememberPreference(
        key = androidx.datastore.preferences.core.booleanPreferencesKey("allowExternalPlay"),
        defaultValue = true
    )
    val (doubleTapToSeek, onDoubleTapToSeekChange) = rememberPreference(
        key = androidx.datastore.preferences.core.stringPreferencesKey("doubleTapToSeek"),
        defaultValue = "10 giây"
    )

    val (lateNightMode, onLateNightModeChange) = rememberPreference(LateNightModeKey, defaultValue = false)
    val (videoMode, onVideoModeChange) = rememberPreference(VideoModeKey, defaultValue = true)
    var showVideoQualityDialog by remember { mutableStateOf(false) }
    val (storedVideoQuality, onVideoQualityChange) = rememberPreference(
        VideoQualityKey,
        defaultValue = VideoQuality.QUALITY_720P.name
    )
    val currentVideoQuality = remember(storedVideoQuality) {
        runCatching { VideoQuality.valueOf(storedVideoQuality) }.getOrDefault(VideoQuality.QUALITY_720P)
    }

    LaunchedEffect(currentVideoQuality) {
        AuraPlayerUtils.setPreferredVideoQuality(currentVideoQuality)
    }

    val (auraCanvas, onAuraCanvasChange) = rememberPreference(AuraCanvasKey, defaultValue = false)
    val (closedCaptions, onClosedCaptionsChange) = rememberPreference(ClosedCaptionsKey, defaultValue = false)
    val (preferredSubtitleLang, onPreferredSubtitleLangChange) = rememberPreference(PreferredSubtitleLangKey, defaultValue = "vi")


    val (sponsorBlockEnabled, onSponsorBlockEnabledChange) = rememberPreference(SponsorBlockEnabledKey, defaultValue = true)
    val (sponsorBlockSkipSponsor, onSponsorBlockSkipSponsorChange) = rememberPreference(SponsorBlockSkipSponsorKey, defaultValue = true)
    val (sponsorBlockSkipSelfPromo, onSponsorBlockSkipSelfPromoChange) = rememberPreference(SponsorBlockSkipSelfPromoKey, defaultValue = true)
    val (sponsorBlockSkipInteraction, onSponsorBlockSkipInteractionChange) = rememberPreference(SponsorBlockSkipInteractionKey, defaultValue = true)
    val (sponsorBlockSkipIntro, onSponsorBlockSkipIntroChange) = rememberPreference(SponsorBlockSkipIntroKey, defaultValue = true)
    val (sponsorBlockSkipOutro, onSponsorBlockSkipOutroChange) = rememberPreference(SponsorBlockSkipOutroKey, defaultValue = true)
    val (sponsorBlockSkipPreview, onSponsorBlockSkipPreviewChange) = rememberPreference(SponsorBlockSkipPreviewKey, defaultValue = true)
    val (sponsorBlockSkipNonMusic, onSponsorBlockSkipNonMusicChange) = rememberPreference(SponsorBlockSkipNonMusicKey, defaultValue = true)
    val (sponsorBlockSkipFiller, onSponsorBlockSkipFillerChange) = rememberPreference(SponsorBlockSkipFillerKey, defaultValue = true)

    val (voiceCommandsEnabled, onVoiceCommandsEnabledChange) = rememberPreference(VoiceCommandsEnabledKey, defaultValue = false)
    val (handsFreeWakeWord, onHandsFreeWakeWordChange) = rememberPreference(HandsFreeWakeWordKey, defaultValue = false)
    val (customWakeWord, onCustomWakeWordChange) = rememberPreference(CustomWakeWordKey, defaultValue = "Hey Aura")
    val (voiceResponsesEnabled, onVoiceResponsesEnabledChange) = rememberPreference(VoiceResponsesEnabledKey, defaultValue = true)
    val (assistantVoice, onAssistantVoiceChange) = rememberPreference(AssistantVoiceKey, defaultValue = "aura_female")
    val (voicePitch, onVoicePitchChange) = rememberPreference(VoicePitchKey, defaultValue = 1.0f)
    val (speechRate, onSpeechRateChange) = rememberPreference(SpeechRateKey, defaultValue = 1.0f)

    var showSubtitleLangDialog by remember { mutableStateOf(false) }
    var showAssistantVoiceDialog by remember { mutableStateOf(false) }

    val (initialVolumeSetting, onInitialVolumeSettingChange) = rememberPreference(
        key = com.listrovia.music.constants.InitialVolumeSettingKey,
        defaultValue = "Theo hệ thống"
    )
    var showInitialVolumeDialog by remember { mutableStateOf(false) }
    var showDoubleTapToSeekDialog by remember { mutableStateOf(false) }

    val (hideVolumeSlider, onHideVolumeSliderChange) = rememberPreference(
        key = androidx.datastore.preferences.core.booleanPreferencesKey("hide_volume_slider"),
        defaultValue = false
    )

    val (uniformVolume, onUniformVolumeChange) = rememberPreference(
        key = androidx.datastore.preferences.core.booleanPreferencesKey("uniformVolume"),
        defaultValue = false
    )
    val (dynamicQueue, onDynamicQueueChange) = rememberPreference(
        key = androidx.datastore.preferences.core.booleanPreferencesKey("dynamicQueue"),
        defaultValue = true
    )
    val (disableLoadMoreWhenRepeatAll, onDisableLoadMoreWhenRepeatAllChange) = rememberPreference(
        DisableLoadMoreWhenRepeatAllKey,
        defaultValue = false
    )
    val (autoDownloadOnLike, onAutoDownloadOnLikeChange) = rememberPreference(
        AutoDownloadOnLikeKey,
        defaultValue = false
    )
    val (similarContentEnabled, similarContentEnabledChange) = rememberPreference(
        key = SimilarContent,
        defaultValue = true
    )
    val (autoSkipNextOnError, onAutoSkipNextOnErrorChange) = rememberPreference(
        AutoSkipNextOnErrorKey,
        defaultValue = false
    )
    val (autoplay, onAutoplayChange) = rememberPreference(
        AutoplayKey,
        defaultValue = false
    )
    val (persistentShuffleAcrossQueues, onPersistentShuffleAcrossQueuesChange) = rememberPreference(
        PersistentShuffleAcrossQueuesKey,
        defaultValue = false
    )
    val (rememberShuffleAndRepeat, onRememberShuffleAndRepeatChange) = rememberPreference(
        RememberShuffleAndRepeatKey,
        defaultValue = true
    )
    val (shufflePlaylistFirst, onShufflePlaylistFirstChange) = rememberPreference(
        ShufflePlaylistFirstKey,
        defaultValue = false
    )
    val (smartShuffle, onSmartShuffleChange) = rememberPreference(
        SmartShuffleKey,
        defaultValue = false
    )
    val (intelligentShuffle, onIntelligentShuffleChange) = rememberPreference(
        IntelligentShuffleKey,
        defaultValue = true
    )
    val (preventDuplicateTracksInQueue, onPreventDuplicateTracksInQueueChange) = rememberPreference(
        PreventDuplicateTracksInQueueKey,
        defaultValue = false
    )
    val (stopMusicOnTaskClear, onStopMusicOnTaskClearChange) = rememberPreference(
        StopMusicOnTaskClearKey,
        defaultValue = false
    )
    val (pauseOnMute, onPauseOnMuteChange) = rememberPreference(
        PauseOnMute,
        defaultValue = false
    )
    val (resumeOnBluetoothConnect, onResumeOnBluetoothConnectChange) = rememberPreference(
        ResumeOnBluetoothConnectKey,
        defaultValue = false
    )
    val (enableHaptics, onEnableHapticsChange) = rememberPreference(
        EnableHapticsKey,
        defaultValue = true
    )
    val (hapticsPlaybackControls, onHapticsPlaybackControlsChange) = rememberPreference(
        HapticsPlaybackControlsKey,
        defaultValue = true
    )
    val (hapticsSeekbar, onHapticsSeekbarChange) = rememberPreference(
        HapticsSeekbarKey,
        defaultValue = true
    )
    val (hapticsButtons, onHapticsButtonsChange) = rememberPreference(
        HapticsButtonsKey,
        defaultValue = true
    )
    val (keepScreenOn, onKeepScreenOnChange) = rememberPreference(
        KeepScreenOn,
        defaultValue = false
    )
    val (historyDuration, onHistoryDurationChange) = rememberPreference(
        HistoryDuration,
        defaultValue = 30f
    )

    var showAudioQualityDialog by remember {
        mutableStateOf(false)
    }

    var showLoudnessLevelDialog by remember {
        mutableStateOf(false)
    }

    // Preload settings state
    val (preloadNextSong, onPreloadNextSongChange) = rememberPreference(
        com.listrovia.music.constants.PreloadNextSongKey,
        defaultValue = true
    )
    val (preloadLimit, onPreloadLimitChange) = rememberPreference(
        com.listrovia.music.constants.PreloadLimitKey,
        defaultValue = 10
    )
    val (preloadLyrics, onPreloadLyricsChange) = rememberPreference(
        com.listrovia.music.constants.PreloadLyricsKey,
        defaultValue = true
    )
    val (exportAsMp3, onExportAsMp3Change) = rememberPreference(
        com.listrovia.music.constants.ExportAsMp3Key,
        defaultValue = true
    )

    // Equalizer settings state
    val (eqToggleProfessional, onEqToggleProfessionalChange) = rememberPreference(
        com.listrovia.music.constants.EqToggleProfessionalKey,
        defaultValue = true
    )
    val (eqAdvancedMode, onEqAdvancedModeChange) = rememberPreference(
        com.listrovia.music.constants.EqAdvancedModeKey,
        defaultValue = false
    )
    val (echoSignature, onEchoSignatureChange) = rememberPreference(
        com.listrovia.music.constants.EchoSignatureKey,
        defaultValue = "Signature"
    )
    val (dolbyAtmos, onDolbyAtmosChange) = rememberPreference(
        com.listrovia.music.constants.DolbyAtmosKey,
        defaultValue = "Dolby Rich"
    )
    val (diracAudio, onDiracAudioChange) = rememberPreference(
        com.listrovia.music.constants.DiracAudioKey,
        defaultValue = "Dirac Music"
    )
    val (echoExtractorLastUpdateTime, onEchoExtractorLastUpdateTimeChange) = rememberPreference(
        com.listrovia.music.constants.EchoExtractorLastUpdateTimeKey,
        defaultValue = System.currentTimeMillis() - 4 * 3600 * 1000
    )

    val (bass, onBassChange) = rememberPreference(
        com.listrovia.music.constants.BassKey,
        defaultValue = 0f
    )
    val (mids, onMidsChange) = rememberPreference(
        com.listrovia.music.constants.MidsKey,
        defaultValue = 0f
    )
    val (treble, onTrebleChange) = rememberPreference(
        com.listrovia.music.constants.TrebleKey,
        defaultValue = 0f
    )
    val (showAudioFallbackNotifications, onShowAudioFallbackNotificationsChange) = rememberPreference(
        com.listrovia.music.constants.ShowAudioFallbackNotificationsKey,
        defaultValue = true
    )
    val (audioFormatCodec, onAudioFormatCodecChange) = rememberPreference(
        com.listrovia.music.constants.AudioFormatCodecKey,
        defaultValue = "Opus"
    )

    var showPreloadLimitDialog by remember { mutableStateOf(false) }
    var showEchoSignatureDialog by remember { mutableStateOf(false) }
    var showDolbyAtmosDialog by remember { mutableStateOf(false) }
    var showDiracAudioDialog by remember { mutableStateOf(false) }
    var showAudioFormatCodecDialog by remember { mutableStateOf(false) }


    var echoExtractorUpdating by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()
    val localContext = LocalContext.current

    val (autoResumePlayback, onAutoResumePlaybackChange) = rememberPreference(
        key = androidx.datastore.preferences.core.booleanPreferencesKey("autoResumePlayback"),
        defaultValue = false
    )
    val (repeatModeSetting, onRepeatModeSettingChange) = rememberPreference(
        key = androidx.datastore.preferences.core.stringPreferencesKey("repeatModeSetting"),
        defaultValue = "Tắt"
    )
    val (equalizerEnabled, onEqualizerEnabledChange) = rememberPreference(
        key = androidx.datastore.preferences.core.booleanPreferencesKey("equalizerEnabled"),
        defaultValue = true
    )
    val (wifiOnlyStreaming, onWifiOnlyStreamingChange) = rememberPreference(
        key = androidx.datastore.preferences.core.booleanPreferencesKey("wifiOnlyStreaming"),
        defaultValue = false
    )

    var showRepeatModeDialog by remember { mutableStateOf(false) }

    val powerManager = remember(localContext) { localContext.getSystemService(android.content.Context.POWER_SERVICE) as? android.os.PowerManager }
    val (batteryOptimizationKey, onBatteryOptimizationKeyChange) = rememberPreference(
        key = androidx.datastore.preferences.core.booleanPreferencesKey("batteryOptimizationDisabled"),
        defaultValue = false
    )
    var isIgnoringBatteryOptimization by remember {
        mutableStateOf(powerManager?.isIgnoringBatteryOptimizations(localContext.packageName) == true)
    }
    LaunchedEffect(Unit) {
        isIgnoringBatteryOptimization = powerManager?.isIgnoringBatteryOptimizations(localContext.packageName) == true
    }

    val (realTimeVisualizerEnabled, onRealTimeVisualizerEnabledChange) = rememberPreference(
        key = RealTimeVisualizerEnabledKey,
        defaultValue = true
    )
    val (realTimeVisualizerStyle, onRealTimeVisualizerStyleChange) = rememberPreference(
        key = RealTimeVisualizerStyleKey,
        defaultValue = "spectrum"
    )

    var showVisualizerStyleDialog by remember { mutableStateOf(false) }

    if (showVisualizerStyleDialog) {
        com.listrovia.music.ui.component.DefaultDialog(
            onDismiss = { showVisualizerStyleDialog = false },
            content = {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = stringResource(R.string.audio_visualizer_style),
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    listOf(
                        "spectrum" to stringResource(R.string.visualizer_style_spectrum),
                        "wave" to stringResource(R.string.visualizer_style_wave),
                        "pulse" to stringResource(R.string.visualizer_style_pulse)
                    ).forEach { (styleKey, label) ->
                        TextButton(
                            onClick = {
                                onRealTimeVisualizerStyleChange(styleKey)
                                showVisualizerStyleDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = label)
                        }
                    }
                }
            },
            buttons = {}
        )
    }

    if (showRepeatModeDialog) {
        com.listrovia.music.ui.component.DefaultDialog(
            onDismiss = { showRepeatModeDialog = false },
            content = {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = stringResource(R.string.select_repeat_mode_dialog_title),
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    val repeatModes = listOf(
                        stringResource(R.string.repeat_mode_off),
                        stringResource(R.string.repeat_mode_all),
                        stringResource(R.string.repeat_mode_one)
                    )
                    for (mode in repeatModes) {
                        TextButton(
                            onClick = {
                                onRepeatModeSettingChange(mode)
                                showRepeatModeDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = mode)
                        }
                    }
                }
            },
            buttons = {}
        )
    }

    if (showAudioQualityDialog) {
        EnumDialog(
            onDismiss = { showAudioQualityDialog = false },
            onSelect = {
                onAudioQualityChange(it)
                showAudioQualityDialog = false
            },
            title = stringResource(R.string.audio_quality),
            current = audioQuality,
            values = AudioQuality.values().toList(),
            valueText = {
                when (it) {
                    AudioQuality.AUTO -> stringResource(R.string.audio_quality_auto)
                    AudioQuality.HIGH -> stringResource(R.string.audio_quality_high)
                    AudioQuality.LOW -> stringResource(R.string.audio_quality_low)
                }
            }
        )
    }

    if (showVideoQualityDialog) {
        EnumDialog(
            onDismiss = { showVideoQualityDialog = false },
            onSelect = { quality: VideoQuality ->
                onVideoQualityChange(quality.name)
                AuraPlayerUtils.setPreferredVideoQuality(quality)
                showVideoQualityDialog = false
            },
            title = stringResource(R.string.video_quality),
            current = currentVideoQuality,
            values = VideoQuality.values().toList(),
            valueText = { quality: VideoQuality -> quality.label }
        )
    }

    if (showLoudnessLevelDialog) {
        EnumDialog(
            onDismiss = { showLoudnessLevelDialog = false },
            onSelect = {
                onLoudnessLevelChange(it)
                showLoudnessLevelDialog = false
            },
            title = stringResource(R.string.loudness_level),
            current = loudnessLevel,
            values = LoudnessLevel.values().toList(),
            valueText = { getLoudnessLevelLabel(it) }
        )
    }

    if (showInitialVolumeDialog) {
        EnumDialog(
            onDismiss = { showInitialVolumeDialog = false },
            onSelect = {
                onInitialVolumeSettingChange(it)
                showInitialVolumeDialog = false
            },
            title = "Âm lượng đầu",
            current = initialVolumeSetting,
            values = listOf("Theo hệ thống", "Nhỏ (30%)", "Vừa (50%)", "Lớn (80%)", "Mặc định (100%)"),
            valueText = { it }
        )
    }

    if (showDoubleTapToSeekDialog) {
        EnumDialog(
            onDismiss = { showDoubleTapToSeekDialog = false },
            onSelect = {
                onDoubleTapToSeekChange(it)
                showDoubleTapToSeekDialog = false
            },
            title = "Nhấn đúp để tua",
            current = doubleTapToSeek,
            values = listOf("Tắt", "5 giây", "10 giây", "15 giây", "20 giây"),
            valueText = { it }
        )
    }

    if (showPreloadLimitDialog) {
        EnumDialog(
            onDismiss = { showPreloadLimitDialog = false },
            onSelect = {
                onPreloadLimitChange(it)
                showPreloadLimitDialog = false
            },
            title = "Giới hạn tải trước",
            current = preloadLimit,
            values = listOf(1, 2, 5, 10, 15, 20, 30, 50),
            valueText = { it.toString() }
        )
    }

    if (showEchoSignatureDialog) {
        EnumDialog(
            onDismiss = { showEchoSignatureDialog = false },
            onSelect = {
                onEchoSignatureChange(it)
                showEchoSignatureDialog = false
            },
            title = "Echo Signature",
            current = echoSignature,
            values = listOf("Flat", "Signature", "Acoustic", "Bass Boost", "Pure Clarity", "Soft Bass", "Electronic", "Rock", "Pop", "Jazz", "Voice"),
            valueText = { it }
        )
    }

    if (showDolbyAtmosDialog) {
        EnumDialog(
            onDismiss = { showDolbyAtmosDialog = false },
            onSelect = {
                onDolbyAtmosChange(it)
                showDolbyAtmosDialog = false
            },
            title = "Dolby Atmos",
            current = dolbyAtmos,
            values = listOf("Tắt", "Dolby Open", "Dolby Rich", "Dolby Focused"),
            valueText = { it }
        )
    }

    if (showDiracAudioDialog) {
        EnumDialog(
            onDismiss = { showDiracAudioDialog = false },
            onSelect = {
                onDiracAudioChange(it)
                showDiracAudioDialog = false
            },
            title = "Dirac Audio",
            current = diracAudio,
            values = listOf("Tắt", "Dirac Music", "Dirac Movie", "Dirac Game"),
            valueText = { it }
        )
    }

    if (showAudioFormatCodecDialog) {
        EnumDialog(
            onDismiss = { showAudioFormatCodecDialog = false },
            onSelect = {
                onAudioFormatCodecChange(it)
                showAudioFormatCodecDialog = false
            },
            title = "Chất lượng âm thanh",
            current = audioFormatCodec,
            values = listOf("Opus", "Lossless"),
            valueText = { it }
        )
    }

    if (showSubtitleLangDialog) {
        val options = listOf(
            "vi" to "Tiếng Việt (Vietnamese)",
            "en" to "English (Tiếng Anh)",
            "ja" to "日本語 (Japanese)",
            "ko" to "한국어 (Korean)",
            "zh" to "中文 (Chinese)"
        )
        DefaultDialog(
            onDismiss = { showSubtitleLangDialog = false },
            title = { Text(stringResource(R.string.pref_subtitle_lang)) },
            buttons = {
                TextButton(onClick = { showSubtitleLangDialog = false }) {
                    Text(stringResource(android.R.string.cancel))
                }
            }
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                options.forEach { (key, label) ->
                    Card(
                        onClick = {
                            onPreferredSubtitleLangChange(key)
                            showSubtitleLangDialog = false
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (preferredSubtitleLang == key) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                        )
                    ) {
                        Text(
                            text = label,
                            modifier = Modifier.padding(16.dp),
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }
        }
    }

    if (showAssistantVoiceDialog) {
        val options = listOf(
            "aura_female" to stringResource(R.string.assistant_voice_female),
            "aura_male" to stringResource(R.string.assistant_voice_male),
            "google_tts" to stringResource(R.string.assistant_voice_google),
            "system_default" to stringResource(R.string.assistant_voice_default)
        )
        DefaultDialog(
            onDismiss = { showAssistantVoiceDialog = false },
            title = { Text(stringResource(R.string.assistant_voice)) },
            buttons = {
                TextButton(onClick = { showAssistantVoiceDialog = false }) {
                    Text(stringResource(android.R.string.cancel))
                }
            }
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                options.forEach { (key, label) ->
                    Card(
                        onClick = {
                            onAssistantVoiceChange(key)
                            showAssistantVoiceDialog = false
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (assistantVoice == key) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                        )
                    ) {
                        Text(
                            text = label,
                            modifier = Modifier.padding(16.dp),
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }
        }
    }

    Column(
        Modifier
            .windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom
                )
            )
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Spacer(
            Modifier.windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Top
                )
            )
        )

        Material3SettingsGroup(
            title = stringResource(R.string.player),
            items = buildList {
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.play),
                    title = { Text(stringResource(R.string.player_auto_resume_title)) },
                    trailingContent = {
                        Switch(
                            checked = autoResumePlayback,
                            onCheckedChange = onAutoResumePlaybackChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (autoResumePlayback) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAutoResumePlaybackChange(!autoResumePlayback) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.settings),
                    title = { Text(stringResource(R.string.player_battery_opt_title)) },
                    description = {
                        Text(
                            if (isIgnoringBatteryOptimization || batteryOptimizationKey)
                                stringResource(R.string.player_battery_opt_disabled_desc)
                            else
                                stringResource(R.string.player_battery_opt_enabled_desc)
                        )
                    },
                    trailingContent = {
                        Switch(
                            checked = isIgnoringBatteryOptimization || batteryOptimizationKey,
                            onCheckedChange = { checked ->
                                onBatteryOptimizationKeyChange(checked)
                                try {
                                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                                        val intent = android.content.Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                                            data = android.net.Uri.parse("package:${localContext.packageName}")
                                        }
                                        localContext.startActivity(intent)
                                    } else {
                                        localContext.startActivity(android.content.Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                                    }
                                } catch (_: Exception) {
                                    try {
                                        localContext.startActivity(android.content.Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                                    } catch (_: Exception) {
                                        Toast.makeText(localContext, localContext.getString(R.string.player_battery_opt_error_toast), Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (isIgnoringBatteryOptimization || batteryOptimizationKey) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = {
                        val newState = !(isIgnoringBatteryOptimization || batteryOptimizationKey)
                        onBatteryOptimizationKeyChange(newState)
                        try {
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                                val intent = android.content.Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                                    data = android.net.Uri.parse("package:${localContext.packageName}")
                                }
                                localContext.startActivity(intent)
                            } else {
                                localContext.startActivity(android.content.Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                            }
                        } catch (_: Exception) {
                            try {
                                localContext.startActivity(android.content.Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                            } catch (_: Exception) {
                                Toast.makeText(localContext, localContext.getString(R.string.player_battery_opt_error_toast), Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.restore),
                    title = { Text(stringResource(R.string.player_repeat_mode_title)) },
                    description = { Text(repeatModeSetting) },
                    onClick = { showRepeatModeDialog = true }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.equalizer),
                    title = { Text(stringResource(R.string.player_equalizer_title)) },
                    trailingContent = {
                        Switch(
                            checked = equalizerEnabled,
                            onCheckedChange = onEqualizerEnabledChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (equalizerEnabled) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { navController.navigate("equalizer") }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.equalizer),
                    title = { Text(stringResource(R.string.audio_visualizer)) },
                    description = { Text(stringResource(R.string.audio_visualizer_desc)) },
                    trailingContent = {
                        Switch(
                            checked = realTimeVisualizerEnabled,
                            onCheckedChange = onRealTimeVisualizerEnabledChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (realTimeVisualizerEnabled) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onRealTimeVisualizerEnabledChange(!realTimeVisualizerEnabled) }
                ))
                if (realTimeVisualizerEnabled) {
                    val styleLabel = when (realTimeVisualizerStyle) {
                        "spectrum" -> stringResource(R.string.visualizer_style_spectrum)
                        "wave" -> stringResource(R.string.visualizer_style_wave)
                        "pulse" -> stringResource(R.string.visualizer_style_pulse)
                        else -> realTimeVisualizerStyle
                    }
                    add(Material3SettingsItem(
                        icon = painterResource(R.drawable.palette),
                        title = { Text(stringResource(R.string.audio_visualizer_style)) },
                        description = { Text(styleLabel) },
                        onClick = { showVisualizerStyleDialog = true }
                    ))
                }
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.cloud),
                    title = { Text(stringResource(R.string.stream_on_wifi_only)) },
                    trailingContent = {
                        Switch(
                            checked = wifiOnlyStreaming,
                            onCheckedChange = onWifiOnlyStreamingChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (wifiOnlyStreaming) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onWifiOnlyStreamingChange(!wifiOnlyStreaming) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.graphic_eq),
                    title = { Text(stringResource(R.string.audio_quality)) },
                    description = {
                        Text(
                            when (audioQuality) {
                                AudioQuality.AUTO -> stringResource(R.string.audio_quality_auto)
                                AudioQuality.HIGH -> stringResource(R.string.audio_quality_high)
                                AudioQuality.LOW -> stringResource(R.string.audio_quality_low)
                            }
                        )
                    },
                    onClick = { showAudioQualityDialog = true }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.music_note),
                    title = { Text(stringResource(R.string.audio_format_codec_title)) },
                    description = { Text(audioFormatCodec) },
                    onClick = { showAudioFormatCodecDialog = true }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.notification),
                    title = { Text(stringResource(R.string.show_audio_fallback_notif_title)) },
                    description = { Text(stringResource(R.string.show_audio_fallback_notif_desc)) },
                    trailingContent = {
                        Switch(
                            checked = showAudioFallbackNotifications,
                            onCheckedChange = onShowAudioFallbackNotificationsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (showAudioFallbackNotifications) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onShowAudioFallbackNotificationsChange(!showAudioFallbackNotifications) }
                ))

                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.linear_scale),
                    title = { Text(stringResource(R.string.crossfade)) },
                    description = { Text(stringResource(R.string.crossfade_fade_between_songs)) },
                    trailingContent = {
                        Switch(
                            checked = crossfadeEnabled,
                            onCheckedChange = onCrossfadeEnabledChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (crossfadeEnabled) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onCrossfadeEnabledChange(!crossfadeEnabled) }
                ))
                if (crossfadeEnabled) {
                    add(Material3SettingsItem(
                        icon = painterResource(R.drawable.timer),
                        title = { Text(stringResource(R.string.crossfade_duration)) },
                        description = {
                            Column {
                                Text(pluralStringResource(R.plurals.seconds, crossfadeDuration.toInt(), crossfadeDuration.toInt()))
                                Slider(
                                    value = crossfadeDuration,
                                    onValueChange = onCrossfadeDurationChange,
                                    valueRange = 1f..15f,
                                    steps = 14
                                )
                            }
                        }
                    ))
                    add(Material3SettingsItem(
                        icon = painterResource(R.drawable.album),
                        title = { Text(stringResource(R.string.crossfade_gapless)) },
                        description = { Text(stringResource(R.string.crossfade_gapless_desc)) },
                        trailingContent = {
                            Switch(
                                checked = crossfadeGapless,
                                onCheckedChange = onCrossfadeGaplessChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (crossfadeGapless) R.drawable.check else R.drawable.close
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize)
                                    )
                                }
                            )
                        },
                        onClick = { onCrossfadeGaplessChange(!crossfadeGapless) }
                    ))
                }

                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.discover_tune),
                    title = { Text(stringResource(R.string.automix_title)) },
                    description = { Text(stringResource(R.string.automix_desc)) },
                    trailingContent = {
                        Switch(
                            checked = automixEnabled,
                            onCheckedChange = onAutomixEnabledChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (automixEnabled) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAutomixEnabledChange(!automixEnabled) }
                ))
                if (automixEnabled) {
                    add(Material3SettingsItem(
                        icon = painterResource(R.drawable.trending_up),
                        title = { Text(stringResource(R.string.automix_blend_point_title)) },
                        description = {
                            Column {
                                Text(stringResource(R.string.automix_blend_point_format, automixBlendPoint.roundToInt()))
                                Slider(
                                    value = automixBlendPoint,
                                    onValueChange = onAutomixBlendPointChange,
                                    valueRange = 50f..95f,
                                    steps = 8
                                )
                            }
                        }
                    ))
                }
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.history),
                    title = { Text(stringResource(R.string.history_duration)) },
                    description = {
                        Column {
                            Text(historyDuration.roundToInt().toString())
                            Slider(
                                value = historyDuration,
                                onValueChange = onHistoryDurationChange,
                                valueRange = 1f..100f
                            )
                        }
                    }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.fast_forward),
                    title = { Text(stringResource(R.string.skip_silence)) },
                    description = { Text(stringResource(R.string.skip_silence_desc)) },
                    trailingContent = {
                        Switch(
                            checked = skipSilence,
                            onCheckedChange = onSkipSilenceChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (skipSilence) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onSkipSilenceChange(!skipSilence) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.skip_next),
                    title = { Text(stringResource(R.string.skip_silence_instant)) },
                    description = { Text(stringResource(R.string.skip_silence_instant_desc)) },
                    trailingContent = {
                        Switch(
                            checked = skipSilenceInstant,
                            onCheckedChange = { onSkipSilenceInstantChange(it) },
                            enabled = skipSilence,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (skipSilenceInstant) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { if (skipSilence) onSkipSilenceInstantChange(!skipSilenceInstant) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.volume_up),
                    title = { Text(stringResource(R.string.audio_normalization)) },
                    description = { Text(stringResource(R.string.audio_normalization_desc)) },
                    trailingContent = {
                        Switch(
                            checked = audioNormalization,
                            onCheckedChange = onAudioNormalizationChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (audioNormalization) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAudioNormalizationChange(!audioNormalization) }
                ))
                if (audioNormalization) {
                    add(Material3SettingsItem(
                        icon = painterResource(R.drawable.volume_up),
                        title = { Text(stringResource(R.string.loudness_level)) },
                        description = {
                            Text(getLoudnessLevelLabel(loudnessLevel))
                        },
                        onClick = { showLoudnessLevelDialog = true }
                    ))
                }
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.volume_off),
                    title = { Text(stringResource(R.string.hide_volume_slider)) },
                    description = { Text(stringResource(R.string.hide_volume_slider_desc)) },
                    trailingContent = {
                        Switch(
                            checked = hideVolumeSlider,
                            onCheckedChange = onHideVolumeSliderChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (hideVolumeSlider) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onHideVolumeSliderChange(!hideVolumeSlider) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.graphic_eq),
                    title = { Text(stringResource(R.string.audio_offload)) },
                    description = {
                        Text(
                            if (crossfadeEnabled) stringResource(R.string.audio_offload_disabled_by_crossfade)
                            else stringResource(R.string.audio_offload_description)
                        )
                    },
                    trailingContent = {
                        Switch(
                            checked = if (crossfadeEnabled) false else audioOffload,
                            onCheckedChange = onAudioOffloadChange,
                            enabled = !crossfadeEnabled,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (!crossfadeEnabled && audioOffload) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { if (!crossfadeEnabled) onAudioOffloadChange(!audioOffload) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.graphic_eq),
                    title = { Text(stringResource(R.string.varispeed)) },
                    description = {
                        Text(
                            stringResource(R.string.varispeed_description)
                        )
                    },
                    trailingContent = {
                        Switch(
                            checked = varispeed,
                            onCheckedChange = onVarispeedChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (varispeed) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onVarispeedChange(!varispeed) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.speed),
                    title = { Text(stringResource(R.string.audio_track_playback_params)) },
                    description = {
                        Text(stringResource(R.string.audio_track_playback_params_description))
                    },
                    trailingContent = {
                        Switch(
                            checked = audioTrackPlaybackParams,
                            onCheckedChange = onAudioTrackPlaybackParamsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (audioTrackPlaybackParams) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAudioTrackPlaybackParamsChange(!audioTrackPlaybackParams) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.cast),
                    title = { Text(stringResource(R.string.google_cast)) },
                    description = { Text(stringResource(R.string.google_cast_description)) },
                    trailingContent = {
                        Switch(
                            checked = enableGoogleCast,
                            onCheckedChange = onEnableGoogleCastChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (enableGoogleCast) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onEnableGoogleCastChange(!enableGoogleCast) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.arrow_forward),
                    title = { Text(stringResource(R.string.seek_seconds_addup)) },
                    description = { Text(stringResource(R.string.seek_seconds_addup_description)) },
                    trailingContent = {
                        Switch(
                            checked = seekExtraSeconds,
                            onCheckedChange = onSeekExtraSeconds,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (seekExtraSeconds) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onSeekExtraSeconds(!seekExtraSeconds) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.bedtime),
                    title = { Text(stringResource(R.string.late_night_mode)) },
                    description = { Text(stringResource(R.string.late_night_mode_desc)) },
                    trailingContent = {
                        Switch(
                            checked = lateNightMode,
                            onCheckedChange = onLateNightModeChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(if (lateNightMode) R.drawable.check else R.drawable.close),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onLateNightModeChange(!lateNightMode) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.insert_photo),
                    title = { Text(stringResource(R.string.video_mode)) },
                    description = { Text(stringResource(R.string.video_mode_desc)) },
                    trailingContent = {
                        Switch(
                            checked = videoMode,
                            onCheckedChange = onVideoModeChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(if (videoMode) R.drawable.check else R.drawable.close),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onVideoModeChange(!videoMode) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.video_mode),
                    title = { Text(stringResource(R.string.video_quality)) },
                    description = { Text(currentVideoQuality.label) },
                    onClick = { showVideoQualityDialog = true }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.trending_up),
                    title = { Text(stringResource(R.string.aura_canvas)) },
                    description = { Text(stringResource(R.string.aura_canvas_desc)) },
                    trailingContent = {
                        Switch(
                            checked = auraCanvas,
                            onCheckedChange = onAuraCanvasChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(if (auraCanvas) R.drawable.check else R.drawable.close),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAuraCanvasChange(!auraCanvas) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.chat_bubble),
                    title = { Text(stringResource(R.string.closed_captions)) },
                    description = { Text(stringResource(R.string.closed_captions_desc)) },
                    trailingContent = {
                        Switch(
                            checked = closedCaptions,
                            onCheckedChange = onClosedCaptionsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(if (closedCaptions) R.drawable.check else R.drawable.close),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onClosedCaptionsChange(!closedCaptions) }
                ))
                add(Material3SettingsItem(
                    icon = painterResource(R.drawable.language),
                    title = { Text(stringResource(R.string.pref_subtitle_lang)) },
                    description = {
                        val label = when (preferredSubtitleLang) {
                            "vi" -> "Tiếng Việt (Vietnamese)"
                            "en" -> "English (Tiếng Anh)"
                            "ja" -> "日本語 (Japanese)"
                            "ko" -> "한국어 (Korean)"
                            else -> "中文 (Chinese)"
                        }
                        Text(label)
                    },
                    onClick = { showSubtitleLangDialog = true }
                ))
            }
        )

        Spacer(modifier = Modifier.height(27.dp))

        var showSleepTimerDialog by remember { mutableStateOf(false) }

        val (sleepTimerEnabled, onSleepTimerEnabledChange) = rememberPreference(
            SleepTimerEnabledKey,
            defaultValue = false
        )
        val (sleepTimerRepeat, onSleepTimerRepeatChange) = rememberPreference(
            SleepTimerRepeatKey,
            defaultValue = "daily"
        )
        val (sleepTimerStartTime, onSleepTimerStartTimeChange) = rememberPreference(
            SleepTimerStartTimeKey,
            defaultValue = "22:00"
        )
        val (sleepTimerEndTime, onSleepTimerEndTimeChange) = rememberPreference(
            SleepTimerEndTimeKey,
            defaultValue = "06:00"
        )
        val (sleepTimerCustomDays, onSleepTimerCustomDaysChange) = rememberPreference(
            SleepTimerCustomDaysKey,
            defaultValue = "0,1,2,3,4"
        )
        // Per-day time ranges used in custom mode
        val (sleepTimerDayTimes, onSleepTimerDayTimesChange) = rememberPreference(
            SleepTimerDayTimesKey,
            defaultValue = ""
        )

        val (sleepTimerStopAfterCurrentSong, onSleepTimerStopAfterCurrentSongChange) = rememberPreference (
        SleepTimerStopAfterCurrentSongKey,
        defaultValue = false)
        val (sleepTimerFadeOut, onSleepTimerFadeOutChange) = rememberPreference(
            SleepTimerFadeOutKey,
            false
        )

        if (showSleepTimerDialog) {
            val customDays = sleepTimerCustomDays.split(",").mapNotNull { it.toIntOrNull() }
            val dayTimesMap = decodeDayTimes(sleepTimerDayTimes)

            SleepTimerDialog(
                isVisible = true,
                onDismiss = { showSleepTimerDialog = false },
                onConfirm = { repeat, startTime, endTime, days, dayTimes ->
                    onSleepTimerRepeatChange(repeat)
                    onSleepTimerStartTimeChange(startTime)
                    onSleepTimerEndTimeChange(endTime)
                    onSleepTimerCustomDaysChange(days?.joinToString(",") ?: "0,1,2,3,4")
                    onSleepTimerDayTimesChange(encodeDayTimes(dayTimes))
                    showSleepTimerDialog = false
                },
                initialRepeat = sleepTimerRepeat,
                initialStartTime = sleepTimerStartTime,
                initialEndTime = sleepTimerEndTime,
                initialCustomDays = customDays,
                initialDayTimes = dayTimesMap
            )
        }

        Material3SettingsGroup(
            title = stringResource(R.string.sleep_timer),
            items = buildList {
                add(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.time_auto),
                        title = { Text(stringResource(R.string.enable_automatic_sleeptimer)) },
                        description = { Text(stringResource(R.string.sleeptimer_description)) },
                        trailingContent = {
                            Switch(
                                checked = sleepTimerEnabled,
                                onCheckedChange = onSleepTimerEnabledChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (sleepTimerEnabled) R.drawable.check else R.drawable.close
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize)
                                    )
                                }
                            )
                        },
                        onClick = { onSleepTimerEnabledChange(!sleepTimerEnabled) }
                    )
                )

                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.baseline_event_repeat_24),
                            title = { Text(stringResource(R.string.sleep_timer_repeat)) },
                            description = {
                                Text(
                                    stringResource(R.string.sleep_timer_repeat_description)
                                )
                            },
                            trailingContent = {
                                Switch(
                                    checked = sleepTimerEnabled,
                                    onCheckedChange = {showSleepTimerDialog = true},
                                    thumbContent = {
                                        Icon(
                                            painter = painterResource(
                                                id = if (sleepTimerEnabled) R.drawable.check else R.drawable.close
                                            ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize)
                                        )
                                    }
                                )
                            },
                            onClick = { showSleepTimerDialog = true }
                        )
                    )


                add(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.more_time),
                        title = { Text(stringResource(R.string.sleep_timer_stop_after_current_song_title)) },
                        description = { Text(stringResource(R.string.sleep_timer_stop_after_current_song_description)) },
                        trailingContent = {
                            Switch(
                                checked = sleepTimerStopAfterCurrentSong,
                                onCheckedChange = onSleepTimerStopAfterCurrentSongChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (sleepTimerStopAfterCurrentSong) R.drawable.check else R.drawable.close
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize)
                                    )
                                }
                            )
                        },
                        onClick = { onSleepTimerStopAfterCurrentSongChange(!sleepTimerStopAfterCurrentSong) }
                    )
                )

                add(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.timer_arrow_down),
                        title = { Text(stringResource(R.string.sleep_timer_fade_out_title)) },
                        description = { Text(stringResource(R.string.sleep_timer_fade_out_description)) },
                        trailingContent = {
                            Switch(
                                checked = sleepTimerFadeOut,
                                onCheckedChange = onSleepTimerFadeOutChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (sleepTimerFadeOut) R.drawable.check else R.drawable.close
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize)
                                    )
                                }
                            )
                        },
                        onClick = { onSleepTimerFadeOutChange(!sleepTimerFadeOut) }
                    )
                )

            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        AlarmSettingsSection()

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.sponsorblock),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.close),
                    title = { Text(stringResource(R.string.sponsorblock)) },
                    description = { Text(stringResource(R.string.sponsorblock_desc)) },
                    trailingContent = {
                        Switch(
                            checked = sponsorBlockEnabled,
                            onCheckedChange = onSponsorBlockEnabledChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(if (sponsorBlockEnabled) R.drawable.check else R.drawable.close),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onSponsorBlockEnabledChange(!sponsorBlockEnabled) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.check),
                    title = { Text(stringResource(R.string.sponsorblock_skip_sponsor)) },
                    description = { Text(stringResource(R.string.sponsorblock_skip_sponsor_desc)) },
                    trailingContent = {
                        Switch(
                            checked = sponsorBlockEnabled && sponsorBlockSkipSponsor,
                            enabled = sponsorBlockEnabled,
                            onCheckedChange = onSponsorBlockSkipSponsorChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(if (sponsorBlockEnabled && sponsorBlockSkipSponsor) R.drawable.check else R.drawable.close),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { if (sponsorBlockEnabled) onSponsorBlockSkipSponsorChange(!sponsorBlockSkipSponsor) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.check),
                    title = { Text(stringResource(R.string.sponsorblock_skip_selfpromo)) },
                    description = { Text(stringResource(R.string.sponsorblock_skip_selfpromo_desc)) },
                    trailingContent = {
                        Switch(
                            checked = sponsorBlockEnabled && sponsorBlockSkipSelfPromo,
                            enabled = sponsorBlockEnabled,
                            onCheckedChange = onSponsorBlockSkipSelfPromoChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(if (sponsorBlockEnabled && sponsorBlockSkipSelfPromo) R.drawable.check else R.drawable.close),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { if (sponsorBlockEnabled) onSponsorBlockSkipSelfPromoChange(!sponsorBlockSkipSelfPromo) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.check),
                    title = { Text(stringResource(R.string.sponsorblock_skip_interaction)) },
                    description = { Text(stringResource(R.string.sponsorblock_skip_interaction_desc)) },
                    trailingContent = {
                        Switch(
                            checked = sponsorBlockEnabled && sponsorBlockSkipInteraction,
                            enabled = sponsorBlockEnabled,
                            onCheckedChange = onSponsorBlockSkipInteractionChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(if (sponsorBlockEnabled && sponsorBlockSkipInteraction) R.drawable.check else R.drawable.close),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { if (sponsorBlockEnabled) onSponsorBlockSkipInteractionChange(!sponsorBlockSkipInteraction) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.check),
                    title = { Text(stringResource(R.string.sponsorblock_skip_intro)) },
                    description = { Text(stringResource(R.string.sponsorblock_skip_intro_desc)) },
                    trailingContent = {
                        Switch(
                            checked = sponsorBlockEnabled && sponsorBlockSkipIntro,
                            enabled = sponsorBlockEnabled,
                            onCheckedChange = onSponsorBlockSkipIntroChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(if (sponsorBlockEnabled && sponsorBlockSkipIntro) R.drawable.check else R.drawable.close),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { if (sponsorBlockEnabled) onSponsorBlockSkipIntroChange(!sponsorBlockSkipIntro) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.check),
                    title = { Text(stringResource(R.string.sponsorblock_skip_outro)) },
                    description = { Text(stringResource(R.string.sponsorblock_skip_outro_desc)) },
                    trailingContent = {
                        Switch(
                            checked = sponsorBlockEnabled && sponsorBlockSkipOutro,
                            enabled = sponsorBlockEnabled,
                            onCheckedChange = onSponsorBlockSkipOutroChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(if (sponsorBlockEnabled && sponsorBlockSkipOutro) R.drawable.check else R.drawable.close),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { if (sponsorBlockEnabled) onSponsorBlockSkipOutroChange(!sponsorBlockSkipOutro) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.check),
                    title = { Text(stringResource(R.string.sponsorblock_skip_preview)) },
                    description = { Text(stringResource(R.string.sponsorblock_skip_preview_desc)) },
                    trailingContent = {
                        Switch(
                            checked = sponsorBlockEnabled && sponsorBlockSkipPreview,
                            enabled = sponsorBlockEnabled,
                            onCheckedChange = onSponsorBlockSkipPreviewChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(if (sponsorBlockEnabled && sponsorBlockSkipPreview) R.drawable.check else R.drawable.close),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { if (sponsorBlockEnabled) onSponsorBlockSkipPreviewChange(!sponsorBlockSkipPreview) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.check),
                    title = { Text(stringResource(R.string.sponsorblock_skip_non_music)) },
                    description = { Text(stringResource(R.string.sponsorblock_skip_non_music_desc)) },
                    trailingContent = {
                        Switch(
                            checked = sponsorBlockEnabled && sponsorBlockSkipNonMusic,
                            enabled = sponsorBlockEnabled,
                            onCheckedChange = onSponsorBlockSkipNonMusicChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(if (sponsorBlockEnabled && sponsorBlockSkipNonMusic) R.drawable.check else R.drawable.close),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { if (sponsorBlockEnabled) onSponsorBlockSkipNonMusicChange(!sponsorBlockSkipNonMusic) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.check),
                    title = { Text(stringResource(R.string.sponsorblock_skip_filler)) },
                    description = { Text(stringResource(R.string.sponsorblock_skip_filler_desc)) },
                    trailingContent = {
                        Switch(
                            checked = sponsorBlockEnabled && sponsorBlockSkipFiller,
                            enabled = sponsorBlockEnabled,
                            onCheckedChange = onSponsorBlockSkipFillerChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(if (sponsorBlockEnabled && sponsorBlockSkipFiller) R.drawable.check else R.drawable.close),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { if (sponsorBlockEnabled) onSponsorBlockSkipFillerChange(!sponsorBlockSkipFiller) }
                )
            )
        )

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.queue),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.queue_music),
                    title = { Text(stringResource(R.string.persistent_queue)) },
                    description = { Text(stringResource(R.string.persistent_queue_desc)) },
                    trailingContent = {
                        Switch(
                            checked = persistentQueue,
                            onCheckedChange = onPersistentQueueChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (persistentQueue) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onPersistentQueueChange(!persistentQueue) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.playlist_add),
                    title = { Text(stringResource(R.string.auto_load_more)) },
                    description = { Text(stringResource(R.string.auto_load_more_desc)) },
                    trailingContent = {
                        Switch(
                            checked = autoLoadMore,
                            onCheckedChange = onAutoLoadMoreChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (autoLoadMore) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAutoLoadMoreChange(!autoLoadMore) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.radio),
                    title = { Text(stringResource(R.string.auto_radio_queue)) },
                    description = { Text(stringResource(R.string.auto_radio_queue_desc)) },
                    trailingContent = {
                        Switch(
                            checked = autoRadioQueue,
                            onCheckedChange = onAutoRadioQueueChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (autoRadioQueue) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAutoRadioQueueChange(!autoRadioQueue) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.skip_next),
                    title = { Text(stringResource(R.string.autoplay)) },
                    description = { Text(stringResource(R.string.autoplay_desc)) },
                    trailingContent = {
                        Switch(
                            checked = autoplay,
                            onCheckedChange = onAutoplayChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (autoplay) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAutoplayChange(!autoplay) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.repeat),
                    title = { Text(stringResource(R.string.disable_load_more_when_repeat_all)) },
                    description = { Text(stringResource(R.string.disable_load_more_when_repeat_all_desc)) },
                    trailingContent = {
                        Switch(
                            checked = disableLoadMoreWhenRepeatAll,
                            onCheckedChange = onDisableLoadMoreWhenRepeatAllChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (disableLoadMoreWhenRepeatAll) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onDisableLoadMoreWhenRepeatAllChange(!disableLoadMoreWhenRepeatAll) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.download),
                    title = { Text(stringResource(R.string.auto_download_on_like)) },
                    description = { Text(stringResource(R.string.auto_download_on_like_desc)) },
                    trailingContent = {
                        Switch(
                            checked = autoDownloadOnLike,
                            onCheckedChange = onAutoDownloadOnLikeChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (autoDownloadOnLike) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAutoDownloadOnLikeChange(!autoDownloadOnLike) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.similar),
                    title = { Text(stringResource(R.string.enable_similar_content)) },
                    description = { Text(stringResource(R.string.similar_content_desc)) },
                    trailingContent = {
                        Switch(
                            checked = similarContentEnabled,
                            onCheckedChange = similarContentEnabledChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (similarContentEnabled) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { similarContentEnabledChange(!similarContentEnabled) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.shuffle),
                    title = { Text(stringResource(R.string.persistent_shuffle_title)) },
                    description = { Text(stringResource(R.string.persistent_shuffle_desc)) },
                    trailingContent = {
                        Switch(
                            checked = persistentShuffleAcrossQueues,
                            onCheckedChange = onPersistentShuffleAcrossQueuesChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (persistentShuffleAcrossQueues) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onPersistentShuffleAcrossQueuesChange(!persistentShuffleAcrossQueues) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.shuffle),
                    title = { Text(stringResource(R.string.remember_shuffle_and_repeat)) },
                    description = { Text(stringResource(R.string.remember_shuffle_and_repeat_desc)) },
                    trailingContent = {
                        Switch(
                            checked = rememberShuffleAndRepeat,
                            onCheckedChange = onRememberShuffleAndRepeatChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (rememberShuffleAndRepeat) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onRememberShuffleAndRepeatChange(!rememberShuffleAndRepeat) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.shuffle),
                    title = { Text(stringResource(R.string.shuffle_playlist_first)) },
                    description = { Text(stringResource(R.string.shuffle_playlist_first_desc)) },
                    trailingContent = {
                        Switch(
                            checked = shufflePlaylistFirst,
                            onCheckedChange = onShufflePlaylistFirstChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (shufflePlaylistFirst) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onShufflePlaylistFirstChange(!shufflePlaylistFirst) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.shuffle),
                    title = { Text(stringResource(R.string.intelligent_shuffle_title)) },
                    description = { Text(stringResource(R.string.intelligent_shuffle_desc)) },
                    trailingContent = {
                        Switch(
                            checked = intelligentShuffle,
                            onCheckedChange = onIntelligentShuffleChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (intelligentShuffle) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onIntelligentShuffleChange(!intelligentShuffle) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.shuffle),
                    title = { Text(stringResource(R.string.smart_shuffle_title)) },
                    description = { Text(stringResource(R.string.smart_shuffle_desc)) },
                    trailingContent = {
                        Switch(
                            checked = smartShuffle,
                            onCheckedChange = onSmartShuffleChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (smartShuffle) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onSmartShuffleChange(!smartShuffle) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.queue_music),
                    title = { Text(stringResource(R.string.prevent_duplicate_tracks_in_queue)) },
                    description = { Text(stringResource(R.string.prevent_duplicate_tracks_in_queue_desc)) },
                    trailingContent = {
                        Switch(
                            checked = preventDuplicateTracksInQueue,
                            onCheckedChange = onPreventDuplicateTracksInQueueChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (preventDuplicateTracksInQueue) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onPreventDuplicateTracksInQueueChange(!preventDuplicateTracksInQueue) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.skip_next),
                    title = { Text(stringResource(R.string.auto_skip_next_on_error)) },
                    description = { Text(stringResource(R.string.auto_skip_next_on_error_desc)) },
                    trailingContent = {
                        Switch(
                            checked = autoSkipNextOnError,
                            onCheckedChange = onAutoSkipNextOnErrorChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (autoSkipNextOnError) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAutoSkipNextOnErrorChange(!autoSkipNextOnError) }
                )
            )
        )

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.misc),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.clear_all),
                    title = { Text(stringResource(R.string.stop_music_on_task_clear)) },
                    trailingContent = {
                        Switch(
                            checked = stopMusicOnTaskClear,
                            onCheckedChange = onStopMusicOnTaskClearChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (stopMusicOnTaskClear) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onStopMusicOnTaskClearChange(!stopMusicOnTaskClear) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.volume_off_pause),
                    title = { Text(stringResource(R.string.pause_music_when_media_is_muted)) },
                    trailingContent = {
                        Switch(
                            checked = pauseOnMute,
                            onCheckedChange = onPauseOnMuteChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (pauseOnMute) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onPauseOnMuteChange(!pauseOnMute) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.bluetooth),
                    title = { Text(stringResource(R.string.resume_on_bluetooth_connect)) },
                    trailingContent = {
                        Switch(
                            checked = resumeOnBluetoothConnect,
                            onCheckedChange = onResumeOnBluetoothConnectChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (resumeOnBluetoothConnect) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onResumeOnBluetoothConnectChange(!resumeOnBluetoothConnect) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.screenshot),
                    title = { Text(stringResource(R.string.keep_screen_on_when_player_is_expanded)) },
                    trailingContent = {
                        Switch(
                            checked = keepScreenOn,
                            onCheckedChange = onKeepScreenOnChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (keepScreenOn) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onKeepScreenOnChange(!keepScreenOn) }
                )
            )
        )

        Material3SettingsGroup(
            title = stringResource(R.string.haptic_feedback_title),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.tune),
                    title = { Text(stringResource(R.string.enable_haptics)) },
                    description = { Text(stringResource(R.string.enable_haptics_desc)) },
                    trailingContent = {
                        Switch(
                            checked = enableHaptics,
                            onCheckedChange = onEnableHapticsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (enableHaptics) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onEnableHapticsChange(!enableHaptics) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.play),
                    title = { Text(stringResource(R.string.haptics_playback_controls_title)) },
                    description = { Text(stringResource(R.string.haptics_playback_controls_desc)) },
                    trailingContent = {
                        Switch(
                            checked = enableHaptics && hapticsPlaybackControls,
                            enabled = enableHaptics,
                            onCheckedChange = onHapticsPlaybackControlsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (enableHaptics && hapticsPlaybackControls) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = {
                        if (enableHaptics) {
                            onHapticsPlaybackControlsChange(!hapticsPlaybackControls)
                        }
                    }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.sliders),
                    title = { Text(stringResource(R.string.haptics_seekbar_title)) },
                    description = { Text(stringResource(R.string.haptics_seekbar_desc)) },
                    trailingContent = {
                        Switch(
                            checked = enableHaptics && hapticsSeekbar,
                            enabled = enableHaptics,
                            onCheckedChange = onHapticsSeekbarChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (enableHaptics && hapticsSeekbar) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = {
                        if (enableHaptics) {
                            onHapticsSeekbarChange(!hapticsSeekbar)
                        }
                    }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.favorite),
                    title = { Text(stringResource(R.string.haptics_buttons_title)) },
                    description = { Text(stringResource(R.string.haptics_buttons_desc)) },
                    trailingContent = {
                        Switch(
                            checked = enableHaptics && hapticsButtons,
                            enabled = enableHaptics,
                            onCheckedChange = onHapticsButtonsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (enableHaptics && hapticsButtons) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = {
                        if (enableHaptics) {
                            onHapticsButtonsChange(!hapticsButtons)
                        }
                    }
                )
            )
        )

        Material3SettingsGroup(
            title = stringResource(R.string.playback_features_group),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.equalizer),
                    title = { Text(stringResource(R.string.equalizer_item_title)) },
                    description = { Text(stringResource(R.string.equalizer_item_desc)) },
                    trailingContent = {
                        Switch(
                            checked = equalizerEnabled,
                            onCheckedChange = onEqualizerEnabledChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (equalizerEnabled) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { navController.navigate("equalizer") }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.play),
                    title = { Text(stringResource(R.string.allow_external_play_title)) },
                    description = { Text(stringResource(R.string.allow_external_play_desc)) },
                    trailingContent = {
                        Switch(
                            checked = allowExternalPlay,
                            onCheckedChange = onAllowExternalPlayChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (allowExternalPlay) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onAllowExternalPlayChange(!allowExternalPlay) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.restore),
                    title = { Text(stringResource(R.string.double_tap_to_seek_title)) },
                    description = { Text(doubleTapToSeek) },
                    onClick = { showDoubleTapToSeekDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.volume_off_pause),
                    title = { Text(stringResource(R.string.uniform_volume_title)) },
                    description = { Text(stringResource(R.string.uniform_volume_desc)) },
                    trailingContent = {
                        Switch(
                            checked = uniformVolume,
                            onCheckedChange = onUniformVolumeChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (uniformVolume) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onUniformVolumeChange(!uniformVolume) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.volume_up),
                    title = { Text(stringResource(R.string.initial_volume_title)) },
                    description = { Text(stringResource(R.string.initial_volume_desc_format, initialVolumeSetting)) },
                    onClick = { showInitialVolumeDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.queue_music),
                    title = { Text(stringResource(R.string.dynamic_queue_title)) },
                    description = { Text(stringResource(R.string.dynamic_queue_desc)) },
                    trailingContent = {
                        Switch(
                            checked = dynamicQueue,
                            onCheckedChange = onDynamicQueueChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (dynamicQueue) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onDynamicQueueChange(!dynamicQueue) }
                )
            )
        )

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.preload_and_cache_group),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.download),
                    title = { Text(stringResource(R.string.preload_next_song_title)) },
                    description = { Text(stringResource(R.string.preload_next_song_desc)) },
                    trailingContent = {
                        Switch(
                            checked = preloadNextSong,
                            onCheckedChange = onPreloadNextSongChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (preloadNextSong) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onPreloadNextSongChange(!preloadNextSong) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.timer),
                    title = { Text(stringResource(R.string.preload_limit_title)) },
                    description = { Text(stringResource(R.string.preload_limit_desc_format, preloadLimit)) },
                    onClick = { showPreloadLimitDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.cached),
                    title = { Text(stringResource(R.string.preload_lyrics_title)) },
                    description = { Text(stringResource(R.string.preload_lyrics_desc)) },
                    trailingContent = {
                        Switch(
                            checked = preloadLyrics,
                            onCheckedChange = onPreloadLyricsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (preloadLyrics) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onPreloadLyricsChange(!preloadLyrics) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.download),
                    title = { Text(stringResource(R.string.export_as_mp3_title)) },
                    description = { Text(stringResource(R.string.export_as_mp3_desc)) },
                    trailingContent = {
                        Switch(
                            checked = exportAsMp3,
                            onCheckedChange = onExportAsMp3Change,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (exportAsMp3) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onExportAsMp3Change(!exportAsMp3) }
                )
            )
        )

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.advanced_equalizer_group),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.equalizer),
                    title = { Text(stringResource(R.string.pro_equalizer_mode_title)) },
                    description = { Text(stringResource(R.string.pro_equalizer_mode_desc)) },
                    trailingContent = {
                        Switch(
                            checked = eqToggleProfessional,
                            onCheckedChange = onEqToggleProfessionalChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (eqToggleProfessional) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onEqToggleProfessionalChange(!eqToggleProfessional) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.graphic_eq),
                    title = { Text(stringResource(R.string.eq_advanced_mode_title)) },
                    description = { Text(if (eqAdvancedMode) stringResource(R.string.eq_mode_advanced) else stringResource(R.string.eq_mode_simple)) },
                    trailingContent = {
                        Switch(
                            checked = eqAdvancedMode,
                            onCheckedChange = onEqAdvancedModeChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (eqAdvancedMode) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onEqAdvancedModeChange(!eqAdvancedMode) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.music_note),
                    title = { Text(stringResource(R.string.echo_signature_title)) },
                    description = { Text(stringResource(R.string.echo_signature_desc_format, echoSignature)) },
                    onClick = { showEchoSignatureDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.volume_up),
                    title = { Text(stringResource(R.string.dolby_atmos_title)) },
                    description = { Text(stringResource(R.string.dolby_atmos_desc_format, dolbyAtmos)) },
                    onClick = { showDolbyAtmosDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.radio),
                    title = { Text(stringResource(R.string.dirac_audio_title)) },
                    description = { Text(stringResource(R.string.dirac_audio_desc_format, diracAudio)) },
                    onClick = { showDiracAudioDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.equalizer),
                    title = { Text(stringResource(R.string.bass_title)) },
                    description = {
                        Column {
                            val bassText = "${if (bass >= 0) "+" else ""}${bass.roundToInt()}"
                            Text(bassText)
                            Slider(
                                value = bass,
                                onValueChange = onBassChange,
                                valueRange = -12f..12f,
                                steps = 24
                            )
                        }
                    }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.equalizer),
                    title = { Text(stringResource(R.string.mids_title)) },
                    description = {
                        Column {
                            val midsText = "${if (mids >= 0) "+" else ""}${mids.roundToInt()}"
                            Text(midsText)
                            Slider(
                                value = mids,
                                onValueChange = onMidsChange,
                                valueRange = -12f..12f,
                                steps = 24
                            )
                        }
                    }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.equalizer),
                    title = { Text(stringResource(R.string.treble_title)) },
                    description = {
                        Column {
                            val trebleText = "${if (treble >= 0) "+" else ""}${treble.roundToInt()}"
                            Text(trebleText)
                            Slider(
                                value = treble,
                                onValueChange = onTrebleChange,
                                valueRange = -12f..12f,
                                steps = 24
                            )
                        }
                    }
                )

            )
        )

        Spacer(modifier = Modifier.height(27.dp))

        val lastUpdateText = remember(echoExtractorLastUpdateTime) {
            val instant = java.time.Instant.ofEpochMilli(echoExtractorLastUpdateTime)
            val formatter = java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss dd/MM/yyyy")
                .withZone(java.time.ZoneId.systemDefault())
            formatter.format(instant)
        }

        val nextUpdateText = remember(echoExtractorLastUpdateTime) {
            val nextTime = echoExtractorLastUpdateTime + 24 * 3600 * 1000
            val instant = java.time.Instant.ofEpochMilli(nextTime)
            val formatter = java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss dd/MM/yyyy")
                .withZone(java.time.ZoneId.systemDefault())
            formatter.format(instant)
        }

        Material3SettingsGroup(
            title = stringResource(R.string.echo_extractor_group),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.cloud),
                    title = { Text(stringResource(R.string.echo_extractor_config_title)) },
                    description = {
                        Column {
                            Text(stringResource(R.string.echo_last_updated, lastUpdateText))
                            Text(stringResource(R.string.echo_next_update, nextUpdateText))
                            if (echoExtractorUpdating) {
                                Text(stringResource(R.string.echo_updating), color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    },
                    trailingContent = {
                        Button(
                            onClick = {
                                val now = System.currentTimeMillis()
                                if (now - echoExtractorLastUpdateTime < 15000) {
                                    Toast.makeText(localContext, localContext.getString(R.string.echo_cooldown_toast), Toast.LENGTH_SHORT).show()
                                } else {
                                    coroutineScope.launch {
                                        echoExtractorUpdating = true
                                        delay(1500)
                                        onEchoExtractorLastUpdateTimeChange(System.currentTimeMillis())
                                        echoExtractorUpdating = false
                                        Toast.makeText(localContext, localContext.getString(R.string.echo_updated_success_toast), Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            enabled = !echoExtractorUpdating
                        ) {
                            Text(stringResource(R.string.echo_update_now_btn))
                        }
                    },
                    onClick = {}
                )
            )
        )



        Spacer(modifier = Modifier.height(27.dp))

        var showCustomWakeWordDialog by remember { mutableStateOf(false) }

        if (showCustomWakeWordDialog) {
            var tempWakeWord by remember { mutableStateOf(customWakeWord) }
            DefaultDialog(
                onDismiss = { showCustomWakeWordDialog = false },
                title = { Text("Custom wake word / Từ khóa kích hoạt") },
                buttons = {
                    TextButton(onClick = { showCustomWakeWordDialog = false }) {
                        Text(stringResource(android.R.string.cancel))
                    }
                    TextButton(onClick = {
                        onCustomWakeWordChange(tempWakeWord)
                        showCustomWakeWordDialog = false
                    }) {
                        Text(stringResource(R.string.alarm_save))
                    }
                }
            ) {
                androidx.compose.material3.OutlinedTextField(
                    value = tempWakeWord,
                    onValueChange = { tempWakeWord = it },
                    label = { Text("Wake word") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Material3SettingsGroup(
            title = "Điều khiển bằng giọng nói (Voice Commands & Feedback)",
            items = buildList {
                add(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.mic),
                        title = { Text("Enable voice commands (Bật điều khiển bằng giọng nói)") },
                        description = { Text("Bật điều khiển bằng giọng nói tương tác") },
                        trailingContent = {
                            Switch(
                                checked = voiceCommandsEnabled,
                                onCheckedChange = onVoiceCommandsEnabledChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(if (voiceCommandsEnabled) R.drawable.check else R.drawable.close),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize)
                                    )
                                }
                            )
                        },
                        onClick = { onVoiceCommandsEnabledChange(!voiceCommandsEnabled) }
                    )
                )

                if (voiceCommandsEnabled) {
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.mic),
                            title = { Text("Hands-free wake word") },
                            description = { Text("Nghe từ khóa \"$customWakeWord\" để kích hoạt không chạm") },
                            trailingContent = {
                                Switch(
                                    checked = handsFreeWakeWord,
                                    onCheckedChange = onHandsFreeWakeWordChange,
                                    thumbContent = {
                                        Icon(
                                            painter = painterResource(if (handsFreeWakeWord) R.drawable.check else R.drawable.close),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize)
                                        )
                                    }
                                )
                            },
                            onClick = { onHandsFreeWakeWordChange(!handsFreeWakeWord) }
                        )
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.edit),
                            title = { Text("Custom wake word (Từ khóa kích hoạt)") },
                            description = { Text(customWakeWord) },
                            onClick = { showCustomWakeWordDialog = true }
                        )
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.chat_bubble),
                            title = { Text("Enable voice responses (Bật phản hồi giọng nói)") },
                            trailingContent = {
                                Switch(
                                    checked = voiceResponsesEnabled,
                                    onCheckedChange = onVoiceResponsesEnabledChange,
                                    thumbContent = {
                                        Icon(
                                            painter = painterResource(if (voiceResponsesEnabled) R.drawable.check else R.drawable.close),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize)
                                        )
                                    }
                                )
                            },
                            onClick = { onVoiceResponsesEnabledChange(!voiceResponsesEnabled) }
                        )
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.language),
                            title = { Text("Assistant voice (Giọng nói trợ lý)") },
                            description = {
                                val label = when (assistantVoice) {
                                    "aura_female" -> "Aura Female (Nữ)"
                                    "aura_male" -> "Aura Male (Nam)"
                                    "google_tts" -> "Google Text-To-Speech"
                                    else -> "System Default (Mặc định hệ thống)"
                                }
                                Text(label)
                            },
                            onClick = { showAssistantVoiceDialog = true }
                        )
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.tune),
                            title = { Text("Voice pitch (Độ cao giọng nói: ${String.format("%.1fx", voicePitch)})") },
                            description = {
                                Slider(
                                    value = voicePitch,
                                    onValueChange = onVoicePitchChange,
                                    valueRange = 0.5f..2.0f,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        )
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.speed),
                            title = { Text("Speech rate (Tốc độ nói: ${String.format("%.1fx", speechRate)})") },
                            description = {
                                Slider(
                                    value = speechRate,
                                    onValueChange = onSpeechRateChange,
                                    valueRange = 0.5f..2.0f,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        )
                    )
                }
            }
        )

        Spacer(modifier = Modifier.height(16.dp))
    }

    TopAppBar(
        title = { Text(stringResource(R.string.player_and_audio)) },
        navigationIcon = {
            IconButton(
                onClick = navController::navigateUp,
                onLongClick = navController::backToMain
            ) {
                Icon(
                    painterResource(R.drawable.arrow_back),
                    contentDescription = null
                )
            }
        }
    )
}
