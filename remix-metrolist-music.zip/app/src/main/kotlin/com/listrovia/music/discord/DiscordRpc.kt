package com.listrovia.music.discord

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.core.content.edit
import com.listrovia.music.db.entities.Song
import io.ktor.client.HttpClient
import io.ktor.client.request.header
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsText
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import timber.log.Timber
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlin.math.abs
import kotlin.random.Random

// ============================================================================
// 1. DISCORD DEFAULTS & CONFIGURATION CONSTANTS
// ============================================================================

object DiscordDefaults {
    const val YOUTUBE_WATCH_URL = "https://music.youtube.com/watch?v="

    const val BUTTON1_LABEL = "Listen on YouTube Music"
    const val BUTTON1_URL_TEMPLATE = "https://music.youtube.com/watch?v={song.id}"

    const val BUTTON2_LABEL = "Visit Listrovia"
    const val BUTTON2_URL = "https://listrovia.cc"

    const val STATE_TEMPLATE = "{artist.name}"
    const val DETAILS_TEMPLATE = "{song.name}"

    const val ACTIVITY_TYPE = "2"
    const val ACTIVITY_NAME = ""

    const val USER_STATUS = "online"
    const val STATUS_IDLE = "idle"
    const val STATUS_DND = "dnd"

    const val ACTIVITY_TYPE_LISTENING = "2"
    const val ACTIVITY_TYPE_PLAYING = "0"
    const val ACTIVITY_TYPE_WATCHING = "3"
    const val ACTIVITY_TYPE_COMPETING = "5"

    const val UNKNOWN_ARTIST = "Unknown Artist"
    const val UNKNOWN_ALBUM = "Unknown Album"

    const val DEFAULT_DISCORD_CLIENT_ID = "1447278780795064401"
}

// ============================================================================
// 2. TOKEN STORAGE & ENCRYPTION (DiscordTokenStore)
// ============================================================================

object DiscordTokenStore {
    private const val PREFS_NAME = "discord_token"
    private const val TOKEN_KEY = "access_token"
    private const val REFRESH_TOKEN_KEY = "refresh_token"
    private const val EXPIRES_AT_KEY = "expires_at"
    private const val DEVICE_VENDOR_ID_KEY = "device_vendor_id"
    private const val CLIENT_UUID_KEY = "client_uuid"
    private const val TAG = "DiscordSvc"

    @Volatile
    private var prefs: SharedPreferences? = null

    private val initDeferred = CompletableDeferred<Unit>()

    fun init(context: Context) {
        if (prefs != null) return
        synchronized(this) {
            if (prefs != null) return
            try {
                AesKeystore.getOrCreateKey()
                prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                if (!initDeferred.isCompleted) {
                    initDeferred.complete(Unit)
                }
            } catch (e: Exception) {
                Timber.e(e, "DiscordTokenStore init failed")
                if (!initDeferred.isCompleted) {
                    initDeferred.completeExceptionally(e)
                }
            }
        }
    }

    private fun encrypt(value: String?): String? {
        if (value == null) return null
        return try {
            AesKeystore.encrypt(value)
        } catch (e: Exception) {
            Timber.e(e, "DiscordTokenStore: encrypt failed")
            null
        }
    }

    private fun decrypt(value: String?): String? {
        if (value == null) return null
        return try {
            AesKeystore.decrypt(value)
        } catch (e: Exception) {
            Timber.e(e, "DiscordTokenStore: decrypt failed")
            null
        }
    }

    suspend fun retrieveSuspend(): String? {
        try {
            initDeferred.await()
        } catch (_: Exception) {
            return null
        }
        return retrieve()
    }

    fun store(token: String) {
        storeFull(token, refreshToken = "", expiresInSec = 0L)
    }

    fun storeFull(accessToken: String, refreshToken: String, expiresInSec: Long) {
        val encryptedToken = encrypt(accessToken) ?: run {
            Timber.tag(TAG).w("tokenStore: encryption failed, not persisting access token")
            return
        }
        prefs?.edit {
            putString(TOKEN_KEY, encryptedToken)
            if (refreshToken.isNotEmpty()) {
                val encryptedRefresh = encrypt(refreshToken)
                if (encryptedRefresh != null) {
                    putString(REFRESH_TOKEN_KEY, encryptedRefresh)
                } else {
                    Timber.tag(TAG).w("tokenStore: refresh token encryption failed, skipping")
                }
            }
            if (expiresInSec > 0L) {
                val expiresAt = (System.currentTimeMillis() / 1000L) + expiresInSec
                putLong(EXPIRES_AT_KEY, expiresAt)
            }
        }
        Timber.tag(TAG).d(
            "tokenStore: stored (accessToken length=%d, refreshToken present=%s, expiresIn=%d)",
            accessToken.length,
            refreshToken.isNotEmpty(),
            expiresInSec,
        )
    }

    fun storeAccessToken(accessToken: String) {
        val encryptedToken = encrypt(accessToken) ?: run {
            Timber.tag(TAG).w("tokenStore: encryption failed, not persisting access token")
            return
        }
        prefs?.edit {
            putString(TOKEN_KEY, encryptedToken)
        }
        Timber.tag(TAG).d("tokenStore: access token updated (length=%d)", accessToken.length)
    }

    fun retrieve(): String? {
        val encrypted = prefs?.getString(TOKEN_KEY, null)
        val token = decrypt(encrypted)
        Timber.tag(TAG).d("tokenStore: retrieve (found=%s)", !token.isNullOrEmpty())
        return token
    }

    fun getRefreshToken(): String? {
        val encrypted = prefs?.getString(REFRESH_TOKEN_KEY, null)
        val token = decrypt(encrypted)
        Timber.tag(TAG).d("tokenStore: getRefreshToken (found=%s)", !token.isNullOrEmpty())
        return token
    }

    fun getExpiresAt(): Long {
        val expiresAt = prefs?.getLong(EXPIRES_AT_KEY, 0L) ?: 0L
        Timber.tag(TAG).d("tokenStore: getExpiresAt (value=%d)", expiresAt)
        return expiresAt
    }

    fun getDeviceVendorId(): String? = getOrCreateId(DEVICE_VENDOR_ID_KEY, "device_vendor_id")

    fun getClientUuid(): String? = getOrCreateId(CLIENT_UUID_KEY, "client_uuid")

    private fun getOrCreateId(key: String, logName: String): String? = synchronized(this) {
        val p = prefs ?: return null
        val existing = p.getString(key, null)
        if (existing != null) return@synchronized existing
        val newId = UUID.randomUUID().toString()
        p.edit { putString(key, newId) }
        Timber.tag(TAG).d("tokenStore: generated new %s", logName)
        newId
    }

    fun clear() {
        prefs?.edit {
            remove(TOKEN_KEY)
            remove(REFRESH_TOKEN_KEY)
            remove(EXPIRES_AT_KEY)
            remove(DEVICE_VENDOR_ID_KEY)
            remove(CLIENT_UUID_KEY)
        }
        Timber.tag(TAG).d("tokenStore: cleared")
    }

    internal object AesKeystore {
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "listrovia_discord_token_key"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val GCM_IV_SIZE = 12
        private const val GCM_TAG_SIZE = 128

        private var keyStore: KeyStore? = null

        @Synchronized
        private fun getKeyStore(): KeyStore {
            keyStore?.let { return it }
            val ks = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
            keyStore = ks
            return ks
        }

        @Volatile
        private var testKey: SecretKey? = null

        fun setTestKey(key: SecretKey?) {
            testKey = key
        }

        fun getOrCreateKey(): SecretKey {
            testKey?.let { return it }
            getKeyStore().getKey(KEY_ALIAS, null)?.let { return it as SecretKey }
            val spec = KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build()
            return KeyGenerator.getInstance("AES", ANDROID_KEYSTORE).apply { init(spec) }.generateKey()
        }

        fun encrypt(plaintext: String): String {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
            val iv = cipher.iv
            if (iv.size != GCM_IV_SIZE) {
                throw IllegalStateException("Unexpected IV size: ${iv.size}")
            }
            val ciphertext = cipher.doFinal(plaintext.toByteArray(StandardCharsets.UTF_8))
            val combined = ByteArray(GCM_IV_SIZE + ciphertext.size)
            iv.copyInto(combined, destinationOffset = 0, startIndex = 0, endIndex = GCM_IV_SIZE)
            ciphertext.copyInto(combined, destinationOffset = GCM_IV_SIZE)
            return Base64.encodeToString(combined, Base64.NO_WRAP)
        }

        fun decrypt(encrypted: String): String {
            val combined = Base64.decode(encrypted, Base64.NO_WRAP)
            if (combined.size < GCM_IV_SIZE) {
                throw IllegalArgumentException("Encrypted data too short")
            }
            val iv = combined.copyOfRange(0, GCM_IV_SIZE)
            val ciphertext = combined.copyOfRange(GCM_IV_SIZE, combined.size)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(GCM_TAG_SIZE, iv))
            return String(cipher.doFinal(ciphertext), StandardCharsets.UTF_8)
        }
    }
}

// ============================================================================
// 3. SUPER PROPERTIES & CLIENT TELEMETRY
// ============================================================================

object DiscordSuperProperties {
    private const val TAG = "DiscordSvc"
    private const val CLIENT_VERSION = "314.13 - Stable"
    private const val CLIENT_BUILD_NUMBER = 314013
    private const val RELEASE_CHANNEL = "googleRelease"

    const val USER_AGENT = "Discord-Android/$CLIENT_BUILD_NUMBER;RNA"

    @Volatile
    private var _superProperties: JSONObject? = null

    private fun buildSuperProperties(): JSONObject {
        val vendorId = DiscordTokenStore.getDeviceVendorId()
            ?: UUID.randomUUID().toString()
        val clientUuid = DiscordTokenStore.getClientUuid()
            ?: UUID.randomUUID().toString()

        Timber.tag(TAG).d(
            "superProperties: building (device=%s, os=%s, sdk=%d, vendorId=%s)",
            Build.DEVICE, Build.VERSION.RELEASE, Build.VERSION.SDK_INT, vendorId.take(8),
        )

        return JSONObject().apply {
            put("os", "Android")
            put("browser", "Discord Android")
            put("device", Build.DEVICE)
            put("system_locale", Locale.getDefault().toString())
            put("client_version", CLIENT_VERSION)
            put("release_channel", RELEASE_CHANNEL)
            put("device_vendor_id", vendorId)
            put("client_uuid", clientUuid)
            put("client_launch_id", UUID.randomUUID().toString())
            put("os_version", Build.VERSION.RELEASE)
            put("os_sdk_version", Build.VERSION.SDK_INT.toString())
            put("client_build_number", CLIENT_BUILD_NUMBER)
            put("client_event_source", JSONObject.NULL)
            put("design_id", 0)
        }
    }

    val superProperties: JSONObject
        get() {
            if (_superProperties == null) {
                _superProperties = buildSuperProperties()
            }
            return _superProperties!!
        }

    @Volatile
    private var _base64: String? = null

    val base64: String
        get() {
            if (_base64 == null) {
                _base64 = Base64.encodeToString(
                    superProperties.toString().toByteArray(),
                    Base64.NO_WRAP,
                )
                Timber.tag(TAG).d("superProperties: base64 encoded (length=%d)", _base64!!.length)
            }
            return _base64!!
        }

    fun reset() {
        _superProperties = null
        _base64 = null
    }
}

// ============================================================================
// 4. EXTERNAL ASSETS RESOLVER
// ============================================================================

object DiscordExternalAssets {
    private const val TAG = "DiscordSvc"
    private const val EXTERNAL_ASSETS_API =
        "https://discord.com/api/v9/applications/%s/external-assets"

    private val json = Json { ignoreUnknownKeys = true }
    private val cache = ConcurrentHashMap<String, String>()
    private const val CACHE_MAX_SIZE = 128

    private val client: HttpClient by lazy {
        HttpClient(io.ktor.client.engine.okhttp.OkHttp) {
            install(io.ktor.client.plugins.HttpTimeout) {
                requestTimeoutMillis = 10_000L
                connectTimeoutMillis = 5_000L
                socketTimeoutMillis = 10_000L
            }
            expectSuccess = false
        }
    }

    suspend fun resolve(
        imageUrl: String,
        appId: String,
        token: String,
    ): String? {
        if (imageUrl.isBlank()) return null
        if (imageUrl.startsWith("mp:")) return imageUrl

        cache[imageUrl]?.let {
            Timber.tag(TAG).d("resolve: cache hit for %s -> %s", imageUrl.take(60), it)
            return it
        }
        Timber.tag(TAG).d("resolve: cache miss for %s, calling API", imageUrl.take(60))

        return try {
            val response = client.post(EXTERNAL_ASSETS_API.format(appId)) {
                header("Authorization", token)
                header("User-Agent", DiscordSuperProperties.USER_AGENT)
                header("X-Super-Properties", DiscordSuperProperties.base64)
                header("Content-Type", "application/json")
                setBody(json.encodeToString(ExternalAssetRequest(listOf(imageUrl))))
            }

            val body = response.bodyAsText()
            val statusCode = response.status.value

            if (statusCode in 200..299 && body.isNotBlank()) {
                val parsed = json.decodeFromString<List<ExternalAssetResponse>>(body)
                val assetPath = parsed.firstOrNull()?.externalAssetPath
                if (assetPath != null) {
                    val result = "mp:$assetPath"
                    cache[imageUrl] = result
                    trimCache()
                    Timber.tag(TAG).i("external-assets: resolved %s -> %s", imageUrl.take(60), result)
                    return result
                } else {
                    Timber.tag(TAG).w("external-assets: no path in response for %s: %s", imageUrl.take(60), body.take(200))
                }
            } else {
                Timber.tag(TAG).w("external-assets: HTTP %d for %s: %s", statusCode, imageUrl.take(60), body.take(200))
            }
            null
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "external-assets: failed for %s", imageUrl.take(60))
            null
        }
    }

    private fun trimCache() {
        if (cache.size > CACHE_MAX_SIZE) {
            val toRemove = cache.size - CACHE_MAX_SIZE
            cache.keys.take(toRemove).forEach { cache.remove(it) }
        }
    }

    fun clearCache() {
        Timber.tag(TAG).d("clearCache: clearing %d entries", cache.size)
        cache.clear()
    }

    fun close() {
        runCatching { client.close() }
    }

    @kotlinx.serialization.Serializable
    private data class ExternalAssetRequest(
        val urls: List<String>,
    )

    @kotlinx.serialization.Serializable
    private data class ExternalAssetResponse(
        val url: String? = null,
        @kotlinx.serialization.SerialName("external_asset_path")
        val externalAssetPath: String? = null,
    )
}

// ============================================================================
// 5. TEMPLATE RENDERER
// ============================================================================

object DiscordTemplateRenderer {
    private const val TAG = "DiscordSvc"

    fun render(
        template: String,
        title: String,
        artist: String,
        album: String?,
        songId: String = "",
    ): String {
        val result = template
            .replace("{song.name}", title)
            .replace("{song.id}", songId)
            .replace("{artist.name}", artist)
            .replace("{album.name}", album ?: DiscordDefaults.UNKNOWN_ALBUM)
        Timber.tag(TAG).v("render: template=%s -> result=%s", template, result)
        return result
    }

    val PLACEHOLDERS = listOf(
        "{song.name}",
        "{artist.name}",
        "{album.name}",
        "{song.id}",
    )
}

// ============================================================================
// 6. MODELS & PRESENCE PAYLOADS
// ============================================================================

data class DiscordActivity(
    val activityType: Int = 2,
    val name: String?,
    val state: String,
    val details: String?,
    val startTimestamp: Long,
    val endTimestamp: Long?,
    val largeImage: String?,
    val largeText: String?,
    val smallImage: String?,
    val smallText: String?,
    val button1Label: String?,
    val button1Url: String?,
    val button2Label: String?,
    val button2Url: String?,
) {
    companion object {
        const val TYPE_PLAYING = 0
        const val TYPE_LISTENING = 2
        const val TYPE_WATCHING = 3
        const val TYPE_COMPETING = 5
    }
}

enum class ActivityType(val code: Int) {
    Playing(0),
    Streaming(1),
    Listening(2),
    Watching(3),
    Custom(4),
    Competing(5),
}

enum class PresenceStatus(val wire: String) {
    Online("online"),
    Idle("idle"),
    Dnd("dnd"),
    Invisible("invisible"),
}

data class ActivityPayload(
    val name: String = "",
    val type: Int,
    val details: String? = null,
    val state: String? = null,
    val url: String? = null,
    val largeImage: String? = null,
    val largeText: String? = null,
    val smallImage: String? = null,
    val smallText: String? = null,
    val startMs: Long? = null,
    val endMs: Long? = null,
    val buttons: List<Pair<String, String>> = emptyList(),
)

object DiscordPresence {
    private const val TAG = "DiscordSvc"

    fun buildActivity(
        name: String = "",
        type: ActivityType,
        details: String? = null,
        state: String? = null,
        url: String? = null,
        largeImage: String? = null,
        largeText: String? = null,
        smallImage: String? = null,
        smallText: String? = null,
        startMs: Long? = null,
        endMs: Long? = null,
        buttons: List<Pair<String, String>> = emptyList(),
    ): ActivityPayload = ActivityPayload(
        name = name,
        type = type.code,
        details = details,
        state = state,
        url = url,
        largeImage = largeImage,
        largeText = largeText,
        smallImage = smallImage,
        smallText = smallText,
        startMs = startMs,
        endMs = endMs,
        buttons = buttons,
    ).also {
        Timber.tag(TAG).d(
            "buildActivity: name=%s, type=%d, details=%s, state=%s, buttons=%d, hasLargeImage=%s, hasSmallImage=%s",
            name, type.code, details?.take(40), state?.take(40), buttons.size,
            largeImage != null, smallImage != null,
        )
    }

    fun buildPresenceUpdate(
        status: PresenceStatus,
        afk: Boolean = false,
        since: Long = 0,
        activities: List<ActivityPayload>,
    ): String {
        val d = JSONObject()
        d.put("since", since)
        d.put("activities", JSONArray().apply { activities.forEach { put(activityToJson(it)) } })
        d.put("status", status.wire)
        d.put("afk", afk)

        val root = JSONObject()
        root.put("op", 3)
        root.put("d", d)
        return root.toString()
    }

    private fun activityToJson(activity: ActivityPayload): JSONObject {
        val obj = JSONObject()
        obj.put("name", activity.name)
        obj.put("type", activity.type)
        activity.details?.let { obj.put("details", it) }
        activity.state?.let { obj.put("state", it) }
        activity.url?.let { obj.put("url", it) }

        if (activity.startMs != null || activity.endMs != null) {
            val timestamps = JSONObject()
            activity.startMs?.let { timestamps.put("start", it) }
            activity.endMs?.let { timestamps.put("end", it) }
            obj.put("timestamps", timestamps)
        }

        if (activity.largeImage != null || activity.smallImage != null) {
            val assets = JSONObject()
            activity.largeImage?.let { assets.put("large_image", it) }
            activity.largeText?.let { assets.put("large_text", it) }
            activity.smallImage?.let { assets.put("small_image", it) }
            activity.smallText?.let { assets.put("small_text", it) }
            obj.put("assets", assets)
        }

        if (activity.buttons.isNotEmpty()) {
            val arr = JSONArray()
            val urlArr = JSONArray()
            activity.buttons.forEach { (label, url) ->
                arr.put(label)
                if (url.isNotEmpty()) urlArr.put(url)
            }
            obj.put("buttons", arr)
            if (urlArr.length() > 0) {
                val metadata = JSONObject()
                metadata.put("button_urls", urlArr)
                obj.put("metadata", metadata)
            }
        }

        return obj
    }
}

// ============================================================================
// 7. ACTIVITY BUILDER
// ============================================================================

object DiscordActivityBuilder {
    private const val TAG = "DiscordSvc"

    fun build(
        song: Song,
        artistName: String,
        albumName: String?,
        artistThumbnail: String?,
        songTitle: String,
        startTimestamp: Long,
        endTimestamp: Long?,
        advancedMode: Boolean,
        activityType: Int = DiscordActivity.TYPE_LISTENING,
        activityName: String? = null,
        stateTemplate: String = DiscordDefaults.STATE_TEMPLATE,
        detailsTemplate: String = DiscordDefaults.DETAILS_TEMPLATE,
        btn1Enabled: Boolean = true,
        btn1Label: String = DiscordDefaults.BUTTON1_LABEL,
        btn1Url: String = DiscordDefaults.BUTTON1_URL_TEMPLATE,
        btn2Enabled: Boolean = true,
        btn2Label: String = DiscordDefaults.BUTTON2_LABEL,
        btn2Url: String = DiscordDefaults.BUTTON2_URL,
        detailStateToggle: Boolean = false,
    ): DiscordActivity {
        var state: String
        var details: String?
        val renderedBtn1Label: String?
        val renderedBtn1Url: String?
        val renderedBtn2Label: String?
        val renderedBtn2Url: String?

        if (advancedMode) {
            state = DiscordTemplateRenderer.render(
                stateTemplate.ifEmpty { DiscordDefaults.STATE_TEMPLATE },
                songTitle, artistName, albumName, song.song.id
            )
            details = DiscordTemplateRenderer.render(
                detailsTemplate.ifEmpty { DiscordDefaults.DETAILS_TEMPLATE },
                songTitle, artistName, albumName, song.song.id
            )
            renderedBtn1Label = if (btn1Enabled) {
                DiscordTemplateRenderer.render(
                    btn1Label.ifEmpty { DiscordDefaults.BUTTON1_LABEL },
                    songTitle, artistName, albumName, song.song.id
                )
            } else null
            renderedBtn1Url = if (btn1Enabled) {
                DiscordTemplateRenderer.render(
                    btn1Url.ifEmpty { DiscordDefaults.BUTTON1_URL_TEMPLATE },
                    songTitle, artistName, albumName, song.song.id
                )
            } else null
            renderedBtn2Label = if (btn2Enabled) {
                DiscordTemplateRenderer.render(
                    btn2Label.ifEmpty { DiscordDefaults.BUTTON2_LABEL },
                    songTitle, artistName, albumName, song.song.id
                )
            } else null
            renderedBtn2Url = if (btn2Enabled) {
                DiscordTemplateRenderer.render(
                    btn2Url.ifEmpty { DiscordDefaults.BUTTON2_URL },
                    songTitle, artistName, albumName, song.song.id
                )
            } else null
        } else {
            state = artistName
            details = songTitle
            renderedBtn1Label = DiscordDefaults.BUTTON1_LABEL
            renderedBtn1Url = "${DiscordDefaults.YOUTUBE_WATCH_URL}${song.song.id}"
            renderedBtn2Label = DiscordDefaults.BUTTON2_LABEL
            renderedBtn2Url = DiscordDefaults.BUTTON2_URL
        }

        if (detailStateToggle) {
            val temp = state
            state = details ?: ""
            details = temp.takeIf { it.isNotEmpty() }
        }

        val renderedName = if (advancedMode && !activityName.isNullOrEmpty()) {
            DiscordTemplateRenderer.render(
                activityName,
                songTitle, artistName, albumName, song.song.id,
            )
        } else {
            activityName?.takeIf { it.isNotEmpty() } ?: artistName
        }

        val result = DiscordActivity(
            activityType = activityType,
            name = renderedName,
            state = state,
            details = details,
            startTimestamp = startTimestamp,
            endTimestamp = endTimestamp,
            largeImage = song.song.thumbnailUrl,
            largeText = albumName,
            smallImage = artistThumbnail,
            smallText = artistName,
            button1Label = renderedBtn1Label,
            button1Url = renderedBtn1Url,
            button2Label = renderedBtn2Label,
            button2Url = renderedBtn2Url,
        )

        Timber.tag(TAG).d(
            "build: result — name=%s, type=%d, state=%s, details=%s, btn1=%s, btn2=%s",
            result.name, result.activityType, result.state, result.details,
            result.button1Label?.take(30), result.button2Label?.take(30),
        )

        return result
    }
}

// ============================================================================
// 8. RECONNECT STRATEGY
// ============================================================================

sealed interface ReconnectAction {
    data class Resume(val sessionId: String, val seq: Int) : ReconnectAction
    data object ReIdentify : ReconnectAction
    data object RefreshAndReIdentify : ReconnectAction
    data object SurfaceFatal : ReconnectAction
}

object DiscordReconnectStrategy {
    private const val TAG = "DiscordSvc"

    fun decide(
        closeCode: Int,
        hadSession: Boolean,
        seq: Int,
        sessionId: String?,
    ): ReconnectAction {
        val action = when (closeCode) {
            4000 -> if (hadSession && sessionId != null && seq > 0) {
                ReconnectAction.Resume(sessionId, seq)
            } else {
                ReconnectAction.ReIdentify
            }
            4001 -> ReconnectAction.ReIdentify
            4003 -> ReconnectAction.ReIdentify
            4004 -> ReconnectAction.RefreshAndReIdentify
            4005 -> ReconnectAction.ReIdentify
            4007 -> ReconnectAction.ReIdentify
            4009 -> ReconnectAction.ReIdentify
            4014 -> ReconnectAction.SurfaceFatal
            else -> ReconnectAction.ReIdentify
        }
        Timber.tag(TAG).d(
            "decide: closeCode=%d, hadSession=%s, seq=%d -> %s",
            closeCode, hadSession, seq, action::class.simpleName,
        )
        return action
    }
}

// ============================================================================
// 9. GATEWAY EVENT & WEBSOCKET ENGINE (DiscordGateway)
// ============================================================================

sealed interface GatewayEvent {
    data class Hello(val heartbeatIntervalMs: Long) : GatewayEvent
    data class Ready(val sessionId: String, val resumeGatewayUrl: String?) : GatewayEvent
    data class Resumed(val sessionId: String) : GatewayEvent
    data class HeartbeatAck(val lastSeq: Int?) : GatewayEvent
    data class InvalidSession(val resumable: Boolean) : GatewayEvent
    data class Disconnected(val code: Int, val reason: String, val remote: Boolean) : GatewayEvent
    data object RefreshToken : GatewayEvent
    data class TextDispatch(val op: Int, val t: String?, val d: JSONObject) : GatewayEvent
}

class DiscordGateway(
    private val appId: String,
    private val tokenProvider: suspend () -> String,
    private val externalScope: CoroutineScope,
) {
    private val _events = MutableSharedFlow<GatewayEvent>(
        replay = 0,
        extraBufferCapacity = 64,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )
    val events: SharedFlow<GatewayEvent> = _events.asSharedFlow()

    @Volatile
    private var _currentSeq: Int = 0
    val currentSeq: Int get() = _currentSeq

    @Volatile
    private var _sessionId: String? = null
    val sessionId: String? get() = _sessionId

    @Volatile
    private var webSocket: WebSocket? = null

    @Volatile
    private var isOpen: Boolean = false

    private val webSocketIdCounter = AtomicLong(0L)

    @Volatile
    private var activeWebSocketId: Long = 0L

    @Volatile
    private var gatewayUrl: String = DEFAULT_GATEWAY_URL

    @Volatile
    private var reconnectAttempts: Int = 0

    @Volatile
    private var heartbeatJob: Job? = null

    private val lastAckAtMs = AtomicLong(0L)

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(0, TimeUnit.MILLISECONDS)
        .build()

    suspend fun connect() {
        val myId = webSocketIdCounter.incrementAndGet()
        activeWebSocketId = myId
        val openDeferred = CompletableDeferred<Unit>()
        val request = Request.Builder().url(gatewayUrl).build()
        val listener = createListener(openDeferred, myId)
        val ws = httpClient.newWebSocket(request, listener)
        webSocket = ws
        try {
            openDeferred.await()
            Timber.tag(TAG).i("connect: WS opened (id=%d), gatewayUrl=%s", myId, gatewayUrl)
        } catch (e: Throwable) {
            Timber.tag(TAG).e(e, "connect: failed to open WS (id=%d)", myId)
            runCatching { ws.cancel() }
            webSocket = null
            throw e
        }
    }

    fun close(code: Int = 1000, reason: String? = null) {
        Timber.tag(TAG).i("close: code=%d, reason=%s", code, reason ?: "")
        heartbeatJob?.cancel()
        heartbeatJob = null
        val ws = webSocket
        webSocket = null
        isOpen = false
        activeWebSocketId = webSocketIdCounter.incrementAndGet()
        if (ws != null) {
            runCatching {
                if (reason != null) ws.close(code, reason) else ws.close(code, null)
            }
        }
    }

    fun send(frameJson: String) {
        val ws = webSocket
        if (ws == null || !isOpen) {
            Timber.tag(TAG).w("send: WebSocket not open (ws=%s, isOpen=%s)", ws, isOpen)
            throw IllegalStateException("DiscordGateway: WebSocket is not open")
        }
        Timber.tag(TAG).v("send: frame (length=%d)", frameJson.length)
        val ok = ws.send(frameJson)
        if (!ok) {
            Timber.tag(TAG).w("send: WebSocket send returned false (queue full or closing)")
            throw IllegalStateException("DiscordGateway: WebSocket send returned false (queue full or closing)")
        }
    }

    suspend fun identify(token: String) {
        val frame = buildIdentifyFrame(token)
        send(frame)
        Timber.tag(TAG).i("identify: IDENTIFY sent (token length=%d)", token.length)
    }

    fun presenceUpdate(presenceJson: String) {
        send(presenceJson)
    }

    suspend fun resume(sessionId: String, seq: Int, token: String) {
        val frame = buildResumeFrame(sessionId, seq, token)
        send(frame)
        Timber.tag(TAG).i("resume: RESUME sent (sessionId prefix=%s, seq=%d)", sessionId.take(8), seq)
    }

    fun heartbeat(seq: Int) {
        Timber.tag(TAG).d("heartbeat: sending seq=%d", seq)
        val frame = buildHeartbeatFrame(seq)
        send(frame)
    }

    fun setGatewayUrl(url: String) {
        gatewayUrl = url
        Timber.tag(TAG).i("setGatewayUrl: %s", url)
    }

    fun closeHttp() {
        runCatching {
            httpClient.dispatcher.executorService.shutdown()
            httpClient.connectionPool.evictAll()
        }
    }

    private fun createListener(openDeferred: CompletableDeferred<Unit>, wsId: Long): WebSocketListener =
        object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (wsId != activeWebSocketId) return
                Timber.tag(TAG).i("onOpen: response.code=%d, wsId=%d", response.code, wsId)
                this@DiscordGateway.webSocket = webSocket
                isOpen = true
                lastAckAtMs.set(System.currentTimeMillis())
                openDeferred.complete(Unit)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (wsId != activeWebSocketId) return
                externalScope.launch {
                    try {
                        handleFrame(text)
                    } catch (e: Throwable) {
                        Timber.tag(TAG).e(e, "onMessage: failed to handle text frame")
                    }
                }
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                Timber.tag(TAG).w("onMessage: binary frame received (%d bytes), ignoring", bytes.size)
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                Timber.tag(TAG).i("onClosing: code=%d, reason=%s, wsId=%d", code, reason, wsId)
                runCatching { webSocket.close(1000, null) }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                Timber.tag(TAG).i("onClosed: code=%d, reason=%s, wsId=%d", code, reason, wsId)
                externalScope.launch {
                    handleClose(code, reason, remote = true, closedWebSocketId = wsId)
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (wsId != activeWebSocketId) return
                Timber.tag(TAG).e(t, "onFailure: response=%s, wsId=%d", response?.code, wsId)
                if (!openDeferred.isCompleted) {
                    openDeferred.completeExceptionally(t)
                }
                externalScope.launch {
                    val code = response?.code ?: 4000
                    val retryAfter = response?.header("Retry-After")
                    val reason = if (retryAfter != null) {
                        "${t.message ?: "failure"};retry_after=$retryAfter"
                    } else {
                        t.message ?: "failure"
                    }
                    handleClose(code, reason, remote = false, closedWebSocketId = wsId)
                }
            }
        }

    private suspend fun handleFrame(text: String) {
        val json = try {
            JSONObject(text)
        } catch (e: Throwable) {
            Timber.tag(TAG).e(e, "handleFrame: invalid JSON")
            return
        }

        val op = json.optInt("op", -1)
        val d: JSONObject? = json.optJSONObject("d")
        val t: String? = if (json.has("t")) json.optString("t") else null

        Timber.tag(TAG).v("handleFrame: op=%d t=%s seq=%d", op, t ?: "", json.optInt("s", 0))

        if (json.has("s") && !json.isNull("s")) {
            val seq = json.optInt("s", 0)
            if (seq > 0) _currentSeq = seq
        }

        when (op) {
            HELLO -> {
                val interval = d?.optLong("heartbeat_interval", DEFAULT_HEARTBEAT_MS)
                    ?: DEFAULT_HEARTBEAT_MS
                Timber.tag(TAG).d("handleFrame: HELLO received, heartbeatInterval=%dms", interval)
                startHeartbeat(interval)
                _events.emit(GatewayEvent.Hello(interval))
            }
            HEARTBEAT_ACK -> {
                lastAckAtMs.set(System.currentTimeMillis())
                _events.emit(GatewayEvent.HeartbeatAck(_currentSeq))
            }
            DISPATCH -> {
                when (t) {
                    "READY" -> {
                        val data = d ?: JSONObject()
                        val sessionId = data.optString("session_id", "")
                        val resumeUrl: String? = data.optString("resume_gateway_url", "")
                            .takeIf { it.isNotEmpty() }
                        _sessionId = sessionId
                        Timber.tag(TAG).d(
                            "handleFrame: READY parsed (sessionId prefix=%s, resumeUrl=%s)",
                            sessionId.take(8), resumeUrl?.take(60),
                        )
                        if (resumeUrl != null) setGatewayUrl(resumeUrl)
                        reconnectAttempts = 0
                        _events.emit(GatewayEvent.Ready(sessionId, resumeUrl))
                    }
                    "RESUMED" -> {
                        reconnectAttempts = 0
                        Timber.tag(TAG).d("handleFrame: RESUMED parsed (sessionId prefix=%s)", _sessionId?.take(8))
                        _events.emit(GatewayEvent.Resumed(_sessionId.orEmpty()))
                    }
                    else -> {
                        _events.emit(GatewayEvent.TextDispatch(op, t, d ?: JSONObject()))
                    }
                }
            }
            INVALID_SESSION -> {
                val resumable = (json.opt("d") as? Boolean) ?: false
                Timber.tag(TAG).w("INVALID_SESSION: resumable=%s", resumable)
                if (!resumable) {
                    _sessionId = null
                }
                _events.emit(GatewayEvent.InvalidSession(resumable))
                webSocket?.close(4000, "invalid session")
            }
            HEARTBEAT -> {
                heartbeat(_currentSeq)
            }
            RECONNECT -> {
                Timber.tag(TAG).w("RECONNECT requested by server, closing 4000")
                webSocket?.close(4000, "reconnect requested")
            }
            else -> {
                _events.emit(GatewayEvent.TextDispatch(op, t, d ?: JSONObject()))
            }
        }
    }

    private suspend fun handleClose(code: Int, reason: String, remote: Boolean, closedWebSocketId: Long) {
        if (closedWebSocketId != activeWebSocketId) {
            Timber.tag(TAG).i(
                "handleClose: ignoring stale WS close (closedId=%d, activeId=%d, code=%d)",
                closedWebSocketId, activeWebSocketId, code,
            )
            return
        }
        if (!isOpen && webSocket == null) {
            return
        }
        isOpen = false
        heartbeatJob?.cancel()
        heartbeatJob = null
        webSocket = null

        _events.emit(GatewayEvent.Disconnected(code, reason, remote))

        if (code == 1000 && remote) {
            Timber.tag(TAG).d("handleClose: clean remote close (code=1000), resetting session")
            _sessionId = null
            _currentSeq = 0
            return
        }

        val action = DiscordReconnectStrategy.decide(
            closeCode = code,
            hadSession = _sessionId != null,
            seq = _currentSeq,
            sessionId = _sessionId,
        )
        Timber.tag(TAG).i("handleClose: strategy=%s for closeCode=%d", action::class.simpleName, code)

        when (action) {
            is ReconnectAction.SurfaceFatal -> {
                Timber.tag(TAG).w("SurfaceFatal for closeCode=%d, giving up", code)
                _sessionId = null
                _currentSeq = 0
            }
            is ReconnectAction.RefreshAndReIdentify -> {
                Timber.tag(TAG).w("RefreshAndReIdentify for closeCode=%d, delegating to manager", code)
                _events.emit(GatewayEvent.RefreshToken)
            }
            is ReconnectAction.Resume,
            is ReconnectAction.ReIdentify -> {
                if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
                    Timber.tag(TAG).w("max reconnect attempts reached (%d), giving up", MAX_RECONNECT_ATTEMPTS)
                    _events.emit(
                        GatewayEvent.Disconnected(4000, "max reconnect attempts", remote = false),
                    )
                    return
                }
                reconnectAttempts++
                val delay = if (code == 429) {
                    val retryAfter = parseRetryAfter(reason)
                    retryAfter.coerceAtLeast(60_000L)
                } else {
                    reconnectDelayMs(reconnectAttempts)
                }
                Timber.tag(TAG).i("handleClose: reconnecting in %dms (attempt %d, code=%d)", delay, reconnectAttempts, code)
                delay(delay)
                performReconnect(action)
            }
        }
    }

    private suspend fun performReconnect(action: ReconnectAction) {
        try {
            connect()
        } catch (e: Throwable) {
            Timber.tag(TAG).e(e, "performReconnect: connect failed")
            return
        }

        when (action) {
            is ReconnectAction.Resume -> {
                try {
                    val token = tokenProvider()
                    resume(action.sessionId, action.seq, token)
                } catch (e: Throwable) {
                    Timber.tag(TAG).e(e, "performReconnect: resume failed")
                    webSocket?.close(1011, "resume failed")
                }
            }
            is ReconnectAction.ReIdentify -> {
                try {
                    val token = tokenProvider()
                    identify(token)
                } catch (e: Throwable) {
                    Timber.tag(TAG).e(e, "performReconnect: identify failed")
                    webSocket?.close(1011, "identify failed")
                }
            }
            is ReconnectAction.SurfaceFatal -> {}
            is ReconnectAction.RefreshAndReIdentify -> {}
        }
    }

    private fun startHeartbeat(intervalMs: Long) {
        heartbeatJob?.cancel()
        val jittered = applyJitter(intervalMs, JITTER_RATIO)
        Timber.tag(TAG).i("startHeartbeat: interval=%dms, jittered=%dms", intervalMs, jittered)
        lastAckAtMs.set(System.currentTimeMillis())
        heartbeatJob = externalScope.launch {
            var lastSentAt = System.currentTimeMillis()
            while (isActive && isOpen) {
                delay(jittered)
                if (!isActive || !isOpen) break
                val lastAck = lastAckAtMs.get()
                if (lastAck < lastSentAt) {
                    Timber.tag(TAG).w("heartbeat: no ACK in %d ms, closing with 4000", jittered)
                    webSocket?.close(4000, "heartbeat timeout")
                    break
                }
                lastSentAt = System.currentTimeMillis()
                runCatching { heartbeat(_currentSeq) }
                    .onFailure { Timber.tag(TAG).w(it, "heartbeat: send failed") }
            }
        }
    }

    private fun buildIdentifyFrame(token: String): String {
        val d = JSONObject()
        d.put("token", token)
        d.put("intents", 0)
        val props = JSONObject()
        props.put("os", "android")
        props.put("browser", "Discord Android")
        props.put("device", appId)
        d.put("properties", props)
        d.put("compress", false)
        return wrapOp(IDENTIFY, d)
    }

    private fun buildResumeFrame(sessionId: String, seq: Int, token: String): String {
        val d = JSONObject()
        d.put("token", token)
        d.put("session_id", sessionId)
        d.put("seq", seq)
        return wrapOp(RESUME, d)
    }

    private fun buildHeartbeatFrame(seq: Int): String {
        val root = JSONObject()
        root.put("op", HEARTBEAT)
        if (seq > 0) {
            root.put("d", seq)
        } else {
            root.put("d", JSONObject.NULL)
        }
        return root.toString()
    }

    private fun wrapOp(op: Int, d: JSONObject): String {
        val root = JSONObject()
        root.put("op", op)
        root.put("d", d)
        return root.toString()
    }

    private fun reconnectDelayMs(attempt: Int): Long {
        val base = (RECONNECT_BASE_DELAY_MS * (1L shl (attempt - 1)))
            .coerceAtMost(RECONNECT_MAX_DELAY_MS)
        return applyJitter(base, 0.25)
    }

    private fun parseRetryAfter(reason: String): Long {
        val prefix = ";retry_after="
        val idx = reason.indexOf(prefix)
        if (idx < 0) return 60_000L
        val value = reason.substring(idx + prefix.length).trim()
        val seconds = value.substringBefore(';').substringBefore(',').toDoubleOrNull()
        return if (seconds != null) (seconds * 1000.0).toLong().coerceAtLeast(60_000L) else 60_000L
    }

    private fun applyJitter(intervalMs: Long, ratio: Double): Long {
        if (intervalMs <= 0L) return intervalMs
        val delta = (intervalMs * ratio).toLong()
        if (delta <= 0L) return intervalMs
        val offset = abs(Random.nextLong(delta + 1))
        val sign = if (Random.nextBoolean()) -1L else 1L
        return intervalMs + sign * offset
    }

    companion object {
        private const val TAG = "DiscordSvc"

        private const val DEFAULT_GATEWAY_URL = "wss://gateway.discord.gg/?v=10&encoding=json"
        private const val DEFAULT_HEARTBEAT_MS = 41250L
        private const val JITTER_RATIO = 0.05
        private const val MAX_RECONNECT_ATTEMPTS = 7
        private const val RECONNECT_BASE_DELAY_MS = 1000L
        private const val RECONNECT_MAX_DELAY_MS = 64_000L

        private const val DISPATCH = 0
        private const val HEARTBEAT = 1
        private const val IDENTIFY = 2
        private const val PRESENCE_UPDATE = 3
        private const val VOICE_STATE = 4
        private const val RESUME = 6
        private const val RECONNECT = 7
        private const val INVALID_SESSION = 9
        private const val HELLO = 10
        private const val HEARTBEAT_ACK = 11
    }
}

// ============================================================================
// 10. DISCORD RPC MANAGER (DiscordRpcManager)
// ============================================================================

data class DiscordUser(
    val id: String,
    val username: String,
    val name: String,
    val avatar: String?,
)

object DiscordRpcManager {
    private const val TAG = "DiscordSvc"

    @Volatile
    private var initialized: Boolean = false

    @Volatile
    private var _ready: Boolean = false

    @Volatile
    private var _authorized: Boolean = false

    @Volatile
    private var accessToken: String? = null

    @Volatile
    private var lastActivitySentAtMs: Long = 0L

    @Volatile
    private var lastActivity: ActivityPayload? = null

    @Volatile private var currentSongId: String? = null
    @Volatile private var currentIsPlaying: Boolean = false
    private val currentActivityId = AtomicLong(0L)
    @Volatile private var imageResolutionJob: Job? = null
    @Volatile private var currentActivityHadImages: Boolean = false
    private val reconnectMutex = Mutex()

    private val _accessTokenFlow = MutableStateFlow<String?>(null)
    val accessTokenFlow: StateFlow<String?> = _accessTokenFlow

    private val _connectionStatus = MutableStateFlow(Status.Disconnected)
    val connectionStatus: StateFlow<Status> = _connectionStatus

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError

    private val _currentUser = MutableStateFlow<DiscordUser?>(null)
    val currentUser: StateFlow<DiscordUser?> = _currentUser

    private val _settingsChanged = MutableStateFlow(0)
    val settingsChanged: StateFlow<Int> = _settingsChanged

    fun notifySettingsChanged() {
        Timber.tag(TAG).d("notifySettingsChanged: incrementing (count=%d), invalidating dedup", _settingsChanged.value + 1)
        _settingsChanged.value++
        currentSongId = null
        currentIsPlaying = false
    }

    enum class Status { Disconnected, Authorizing, Connected }

    fun getAccessToken(): String? = accessToken

    fun isInitialized(): Boolean = initialized

    fun isAuthorized(): Boolean = _authorized

    fun isReady(): Boolean = _ready

    fun isShowingSong(songId: String, isPlaying: Boolean): Boolean {
        if (currentSongId != songId || currentIsPlaying != isPlaying) {
            return false
        }
        if (lastActivity == null) {
            return false
        }
        if (currentActivityHadImages &&
            lastActivity?.largeImage == null && lastActivity?.smallImage == null &&
            (imageResolutionJob == null || imageResolutionJob?.isCompleted == true)
        ) {
            return false
        }
        return true
    }

    fun clearLastError() {
        _lastError.value = null
    }

    private var scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val appId: String = BuildConfigProvider.appId

    private var gateway: DiscordGateway = createGateway(scope)

    private fun createGateway(scope: CoroutineScope): DiscordGateway =
        DiscordGateway(
            appId = appId,
            tokenProvider = { "Bearer ${accessToken ?: ""}" },
            externalScope = scope,
        )

    private fun startEventCollection() {
        scope.launch {
            gateway.events.collect { event -> handleGatewayEvent(event) }
        }
    }

    fun init(context: Context) {
        DiscordTokenStore.init(context.applicationContext)
        if (initialized && scope.isActive) {
            Timber.tag(TAG).i("init: already initialized and active, skipping")
            return
        }
        if (!scope.isActive) {
            Timber.tag(TAG).i("init: recreating scope after previous destroy")
            scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
            gateway = createGateway(scope)
        }
        initialized = true
        _connectionStatus.value = Status.Disconnected
        startEventCollection()
        Timber.tag(TAG).i("init: token store initialized, scheduling auto-rehydrate")

        scope.launch {
            val saved = DiscordTokenStore.retrieveSuspend()
            if (!saved.isNullOrEmpty()) {
                Timber.tag(TAG).i("init: found persisted token, reconnecting")
                reconnectWithToken(saved)
            } else {
                Timber.tag(TAG).i("init: no persisted token")
            }
        }
    }

    fun fetchCurrentUser(token: String): DiscordUser? {
        val endpoints = listOf(
            "https://discord.com/api/v10/users/@me",
            "https://discord.com/api/v10/oauth2/@me"
        )
        for (endpoint in endpoints) {
            try {
                val url = URL(endpoint)
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 10_000
                conn.readTimeout = 10_000
                conn.requestMethod = "GET"
                conn.setRequestProperty("Authorization", "Bearer $token")
                conn.setRequestProperty("Accept", "application/json")

                val responseCode = conn.responseCode
                val responseBody = if (responseCode in 200..299) {
                    conn.inputStream.bufferedReader().readText()
                } else {
                    conn.errorStream?.bufferedReader()?.readText() ?: ""
                }
                conn.disconnect()

                if (responseCode in 200..299 && responseBody.isNotBlank()) {
                    val root = JSONObject(responseBody)
                    val userObj = if (root.has("user")) root.getJSONObject("user") else root
                    val id = userObj.optString("id", "")
                    val username = userObj.optString("username", "")
                    if (id.isNotEmpty() && username.isNotEmpty()) {
                        val name = userObj.optString("global_name", username)
                        val avatarHash = userObj.optString("avatar")
                        val avatar = if (avatarHash.isNotEmpty() && avatarHash != "null") {
                            "https://cdn.discordapp.com/avatars/$id/$avatarHash.png"
                        } else null

                        return DiscordUser(id, username, name, avatar)
                    }
                } else {
                    Timber.tag(TAG).w("fetchCurrentUser: endpoint $endpoint HTTP $responseCode body=$responseBody")
                }
            } catch (e: Exception) {
                Timber.tag(TAG).w(e, "fetchCurrentUser: exception on $endpoint")
            }
        }
        return null
    }

    fun setActivity(
        activity: DiscordActivity,
        songId: String? = null,
        isPlaying: Boolean = true,
        status: PresenceStatus = PresenceStatus.Online,
    ) {
        if (!_ready) {
            Timber.tag(TAG).w("setActivity: skipping — not ready (name=%s)", activity.name)
            return
        }

        val stateChanged = songId != currentSongId || isPlaying != currentIsPlaying ||
            (activity.largeImage != null && activity.largeImage != lastActivity?.largeImage) ||
            (activity.smallImage != null && activity.smallImage != lastActivity?.smallImage)

        val now = System.currentTimeMillis()
        if (!stateChanged &&
            lastActivitySentAtMs > 0L && (now - lastActivitySentAtMs) < 2_000L
        ) {
            Timber.tag(TAG).v("setActivity: debounced (<2s since last, stateChanged=%s)", stateChanged)
            return
        }
        lastActivitySentAtMs = now

        currentSongId = songId
        currentIsPlaying = isPlaying
        currentActivityId.incrementAndGet()
        currentActivityHadImages = !activity.largeImage.isNullOrEmpty() || !activity.smallImage.isNullOrEmpty()

        val buttons = buildList {
            if (!activity.button1Label.isNullOrEmpty() && !activity.button1Url.isNullOrEmpty()) {
                add(activity.button1Label to activity.button1Url)
            }
            if (!activity.button2Label.isNullOrEmpty() && !activity.button2Url.isNullOrEmpty()) {
                add(activity.button2Label to activity.button2Url)
            }
        }
        val payloadNoImages = DiscordPresence.buildActivity(
            name = activity.name.orEmpty(),
            type = activityTypeToEnum(activity.activityType),
            details = activity.details,
            state = activity.state,
            startMs = activity.startTimestamp.takeIf { it > 0L },
            endMs = activity.endTimestamp?.takeIf { it > 0L },
            buttons = buttons,
        )

        lastActivity = payloadNoImages

        try {
            val presenceJson = DiscordPresence.buildPresenceUpdate(
                status = status,
                activities = listOf(payloadNoImages),
            )
            Timber.tag(TAG).i("setActivity: sending (type=%d, name=%s, details=%s, state=%s, songId=%s, isPlaying=%s, buttons=%d)",
                activity.activityType, activity.name, activity.details, activity.state, songId, isPlaying, buttons.size)
            gateway.presenceUpdate(presenceJson)
        } catch (e: IllegalStateException) {
            Timber.tag(TAG).w(e, "setActivity: gateway not open")
        } catch (e: Throwable) {
            Timber.tag(TAG).e(e, "setActivity: send failed")
        }

        imageResolutionJob?.cancel()

        val currentToken = accessToken ?: return
        val largeImageUrl = activity.largeImage
        val smallImageUrl = activity.smallImage
        if (largeImageUrl.isNullOrEmpty() && smallImageUrl.isNullOrEmpty()) return

        Timber.tag(TAG).d(
            "setActivity: resolving images — large=%s, small=%s",
            largeImageUrl?.take(80),
            smallImageUrl?.take(80),
        )

        val activityIdAtLaunch = currentActivityId.get()
        val songIdAtLaunch = songId

        imageResolutionJob = scope.launch {
            val tokenHeader = "Bearer $currentToken"
            val largeResolved = if (!largeImageUrl.isNullOrEmpty()) {
                DiscordExternalAssets.resolve(largeImageUrl, appId, tokenHeader)
            } else null
            val smallResolved = if (!smallImageUrl.isNullOrEmpty()) {
                DiscordExternalAssets.resolve(smallImageUrl, appId, tokenHeader)
            } else null

            if (largeResolved == null && smallResolved == null) {
                Timber.tag(TAG).i("setActivity: image resolution returned null, keeping text-only presence")
                return@launch
            }

            if (activityIdAtLaunch != currentActivityId.get()) {
                Timber.tag(TAG).i(
                    "setActivity: stale image resolution (launched activityId=%d, current=%d), skipping re-send",
                    activityIdAtLaunch, currentActivityId.get(),
                )
                return@launch
            }

            val payloadWithImages = DiscordPresence.buildActivity(
                name = activity.name.orEmpty(),
                type = activityTypeToEnum(activity.activityType),
                details = activity.details,
                state = activity.state,
                largeImage = largeResolved,
                largeText = activity.largeText,
                smallImage = smallResolved,
                smallText = activity.smallText,
                startMs = activity.startTimestamp.takeIf { it > 0L },
                endMs = activity.endTimestamp?.takeIf { it > 0L },
                buttons = buttons,
            )

            lastActivity = payloadWithImages

            try {
                val presenceJson = DiscordPresence.buildPresenceUpdate(
                    status = status,
                    activities = listOf(payloadWithImages),
                )
                Timber.tag(TAG).i("setActivity: re-sending with images for songId=%s", songIdAtLaunch)
                gateway.presenceUpdate(presenceJson)
            } catch (e: IllegalStateException) {
                Timber.tag(TAG).w(e, "setActivity: image re-send gateway not open")
            } catch (e: Throwable) {
                Timber.tag(TAG).e(e, "setActivity: image re-send failed")
            }
        }
    }

    fun clear() {
        if (!_ready) {
            Timber.tag(TAG).w("clear: skipping — not ready")
            return
        }
        if (lastActivity == null && currentSongId == null) {
            Timber.tag(TAG).d("clear: already cleared, skipping")
            return
        }
        lastActivity = null
        currentSongId = null
        currentIsPlaying = false
        currentActivityHadImages = false
        currentActivityId.incrementAndGet()
        imageResolutionJob?.cancel()
        try {
            gateway.presenceUpdate(
                DiscordPresence.buildPresenceUpdate(
                    status = PresenceStatus.Online,
                    activities = emptyList(),
                ),
            )
        } catch (e: IllegalStateException) {
            Timber.tag(TAG).w(e, "clear: gateway not open")
        } catch (e: Throwable) {
            Timber.tag(TAG).e(e, "clear: send failed")
        }
    }

    fun reconnectWithToken(token: String) {
        if (!initialized) {
            Timber.tag(TAG).w("reconnectWithToken: not initialized, ignoring")
            return
        }

        scope.launch {
            reconnectMutex.withLock {
                accessToken = token
                _accessTokenFlow.value = token
                DiscordTokenStore.storeAccessToken(token)
                _connectionStatus.value = Status.Authorizing
                try {
                    runCatching { gateway.close(4000, "reconnecting") }
                    gateway.connect()
                    gateway.identify("Bearer $token")
                } catch (e: Throwable) {
                    Timber.tag(TAG).e(e, "reconnectWithToken: connect/identify failed")
                    _lastError.value = "discord_error_loopback_timeout"
                    _connectionStatus.value = Status.Disconnected
                }
            }
        }
    }

    fun disconnect() {
        Timber.tag(TAG).i("disconnect: closing gateway, clearing ready/authorized")
        currentActivityId.incrementAndGet()
        imageResolutionJob?.cancel()
        runCatching { gateway.close(1000, "user disconnect") }
        _connectionStatus.value = Status.Disconnected
        _ready = false
        _authorized = false
        currentSongId = null
        currentIsPlaying = false
        currentActivityHadImages = false
    }

    fun destroy() {
        Timber.tag(TAG).i("destroy: cancelling scope and tearing down (initialized=%s)", initialized)
        currentActivityId.incrementAndGet()
        imageResolutionJob?.cancel()
        runCatching { gateway.close(1000, "destroy") }
        runCatching { gateway.closeHttp() }
        scope.cancel()
        _ready = false
        _authorized = false
        initialized = false
        _connectionStatus.value = Status.Disconnected
        lastActivity = null
        currentSongId = null
        currentIsPlaying = false
        currentActivityHadImages = false
    }

    fun logout() {
        Timber.tag(TAG).i("logout: clearing tokens and disconnecting")
        disconnect()
        accessToken = null
        _accessTokenFlow.value = null
        _currentUser.value = null
        DiscordTokenStore.clear()
        DiscordSuperProperties.reset()
        _lastError.value = null
        lastActivity = null
        currentActivityHadImages = false
    }

    private suspend fun handleGatewayEvent(event: GatewayEvent) {
        when (event) {
            is GatewayEvent.Ready -> {
                Timber.tag(TAG).i("gateway: READY (sessionId prefix=%s)", event.sessionId.take(8))
                _ready = true
                _authorized = true
                _connectionStatus.value = Status.Connected
                _lastError.value = null
                val token = accessToken ?: return
                scope.launch {
                    val user = fetchCurrentUser(token)
                    _currentUser.value = user
                    if (user != null) {
                        Timber.tag(TAG).i("gateway READY: fetched user %s", user.username)
                    }
                }
            }
            is GatewayEvent.Resumed -> {
                Timber.tag(TAG).i("gateway: RESUMED")
                _ready = true
                _authorized = true
                _connectionStatus.value = Status.Connected
                _lastError.value = null
            }
            is GatewayEvent.Disconnected -> {
                Timber.tag(TAG).i("gateway: Disconnected (code=%d, remote=%s, reason=%s)",
                    event.code, event.remote, event.reason)
                _ready = false
                _authorized = false
                _connectionStatus.value = Status.Disconnected
                currentSongId = null
                currentIsPlaying = false
                imageResolutionJob?.cancel()
                imageResolutionJob = null
                if (event.code in setOf(4001, 4004) && event.reason.contains("max reconnect", ignoreCase = true)) {
                    _lastError.value = when (event.code) {
                        4004 -> "discord_error_token_refresh_failed"
                        4001 -> "discord_error_invalid_scope"
                        else -> _lastError.value
                    }
                }
            }
            is GatewayEvent.InvalidSession -> {
                Timber.tag(TAG).w("gateway: InvalidSession (resumable=%s), closing WS to trigger reconnect", event.resumable)
                imageResolutionJob?.cancel()
                imageResolutionJob = null
            }
            is GatewayEvent.RefreshToken -> {
                Timber.tag(TAG).w("gateway: RefreshToken requested, session invalid")
                logout()
            }
            is GatewayEvent.Hello -> Unit
            is GatewayEvent.HeartbeatAck -> Unit
            is GatewayEvent.TextDispatch -> {
                Timber.tag(TAG).v("gateway: TextDispatch op=%d t=%s", event.op, event.t)
            }
        }
    }

    private fun activityTypeToEnum(code: Int): ActivityType = when (code) {
        0 -> ActivityType.Playing
        1 -> ActivityType.Streaming
        2 -> ActivityType.Listening
        3 -> ActivityType.Watching
        4 -> ActivityType.Custom
        5 -> ActivityType.Competing
        else -> ActivityType.Listening
    }
}

private object BuildConfigProvider {
    val appId: String = com.listrovia.music.BuildConfig.DISCORD_APP_ID.ifEmpty { DiscordDefaults.DEFAULT_DISCORD_CLIENT_ID }
}
