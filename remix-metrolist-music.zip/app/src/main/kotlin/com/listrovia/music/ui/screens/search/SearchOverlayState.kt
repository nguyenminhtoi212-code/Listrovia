/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.screens.search

import androidx.compose.runtime.Stable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

val LocalSearchOverlayState = compositionLocalOf { SearchOverlayState() }

@Stable
class SearchOverlayState(
    initialVisible: Boolean = false,
    initialQuery: String = "",
) {
    var isVisible by mutableStateOf(initialVisible)
    var query by mutableStateOf(initialQuery)

    fun show(initialQuery: String = "") {
        if (initialQuery.isNotBlank()) {
            this.query = initialQuery
        }
        isVisible = true
    }

    fun dismiss() {
        isVisible = false
    }

    fun toggle() {
        isVisible = !isVisible
    }

    fun clearQuery() {
        query = ""
    }
}
