package com.listrovia.music.extensions

import android.app.Application
import android.os.Build
import android.webkit.WebView
import com.listrovia.music.BuildConfig
import com.listrovia.music.utils.CrashHandler
import com.listrovia.music.utils.ensureWebViewCacheDirsExist
import timber.log.Timber
import java.io.File

fun Application.setupSystemDefaults() {
    // Install crash handler
    CrashHandler.install(this)

    // Ensure WebView cache subdirectories exist
    ensureWebViewCacheDirsExist(this)

    // Ensure DataStore directory exists
    try {
        val datastoreDir = File(filesDir, "datastore")
        if (!datastoreDir.isDirectory && !datastoreDir.mkdirs()) {
            Timber.w("Could not create DataStore directory at ${datastoreDir.path}")
        }
    } catch (e: Exception) {
        Timber.e(e, "Failed to ensure DataStore directory")
    }

    // Plant logging
    Timber.plant(Timber.DebugTree())

    // Enable WebView debugging in debug builds
    if (BuildConfig.DEBUG) {
        WebView.setWebContentsDebuggingEnabled(true)
    }
}
