/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.component

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.listrovia.music.R
import com.listrovia.music.api.OpenRouterModelItem
import com.listrovia.music.api.*
import com.listrovia.music.constants.OpenRouterTierBeta
import com.listrovia.music.constants.OpenRouterTierDeveloper
import com.listrovia.music.constants.OpenRouterTierStable
import com.listrovia.music.utils.ModelFavoritesManager
import com.listrovia.music.viewmodels.ModelViewModel
import com.valentinilk.shimmer.shimmer

@Composable
fun OpenRouterModelDialog(
    currentModel: String,
    initialTier: String = "Stable",
    onDismiss: () -> Unit,
    onSelectModel: (String) -> Unit,
    onCustomInput: () -> Unit,
    viewModel: ModelViewModel = hiltViewModel(),
) {
    val context = LocalContext.current
    val classifiedModels by viewModel.classifiedModels.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()

    val initialTab = when (initialTier) {
        "Beta" -> 1
        "Developer" -> 2
        else -> 0
    }
    var selectedTab by remember { mutableIntStateOf(initialTab) } // 0: Official, 1: Beta, 2: Developer
    var selectedCategory by remember { mutableStateOf(ModelSourceCategory.ALL) }
    var searchQuery by remember { mutableStateOf("") }
    val favoritesManager = remember { ModelFavoritesManager.getInstance(context) }
    var favoriteVersion by remember { mutableStateOf(0) }

    val currentList: List<OpenRouterModelItem> =
        remember(classifiedModels, selectedTab, selectedCategory, searchQuery, favoriteVersion) {
            val models = classifiedModels ?: return@remember emptyList()
            val baseList =
                when (selectedTab) {
                    0 -> models.official
                    1 -> models.beta
                    2 -> models.developer
                    else -> models.official
                }.filter { favoritesManager.isModelSafeAndPublished(it.id, it.name, provider = "OpenRouter") }
                .filter {
                    when (selectedCategory) {
                        ModelSourceCategory.ALL -> true
                        ModelSourceCategory.VERIFIED -> getModelSourceCategory(it.id, it.providerName) == ModelSourceCategory.VERIFIED
                        ModelSourceCategory.COMMUNITY -> getModelSourceCategory(it.id, it.providerName) == ModelSourceCategory.COMMUNITY
                        ModelSourceCategory.DEVELOPER -> getModelSourceCategory(it.id, it.providerName) == ModelSourceCategory.DEVELOPER
                    }
                }

            if (searchQuery.isBlank()) {
                baseList
            } else {
                val q = searchQuery.trim().lowercase()
                baseList.filter {
                    it.id.lowercase().contains(q) || it.name.lowercase().contains(q)
                }
            }
        }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    text = stringResource(R.string.ai_model),
                    style = MaterialTheme.typography.headlineSmall,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = {
                            viewModel.recommendRandomModel(forceRefresh = false) { chosen ->
                                onSelectModel(chosen.id)
                                onDismiss()
                            }
                        },
                        enabled = !isLoading,
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.shuffle),
                            contentDescription = stringResource(R.string.ai_model_random_button),
                            tint = MaterialTheme.colorScheme.primary,
                        )
                    }

                    IconButton(
                        onClick = { viewModel.refresh(force = true) },
                        enabled = !isLoading,
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp,
                            )
                        } else {
                            Icon(
                                painter = painterResource(R.drawable.sync),
                                contentDescription = stringResource(R.string.ai_model_refresh),
                                tint = MaterialTheme.colorScheme.primary,
                            )
                        }
                    }
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Search bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text(stringResource(R.string.ai_model_search_placeholder)) },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.search),
                            contentDescription = null,
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    painter = painterResource(R.drawable.close),
                                    contentDescription = null,
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth(),
                )

                Spacer(modifier = Modifier.height(10.dp))

                val officialCount = classifiedModels?.official?.size ?: 0
                val betaCount = classifiedModels?.beta?.size ?: 0
                val devCount = classifiedModels?.developer?.size ?: 0

                // Tabs: Official (Stable), Beta, Developer
                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    edgePadding = 0.dp,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = {
                            selectedTab = 0
                            viewModel.selectTier(OpenRouterTierStable)
                        },
                        text = {
                            Text(
                                text = "${stringResource(R.string.ai_model_tab_official)} ($officialCount)",
                                style = MaterialTheme.typography.labelMedium,
                            )
                        },
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = {
                            selectedTab = 1
                            viewModel.selectTier(OpenRouterTierBeta)
                        },
                        text = {
                            Text(
                                text = "${stringResource(R.string.ai_model_tab_beta)} ($betaCount)",
                                style = MaterialTheme.typography.labelMedium,
                            )
                        },
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = {
                            selectedTab = 2
                            viewModel.selectTier(OpenRouterTierDeveloper)
                        },
                        text = {
                            Text(
                                text = "${stringResource(R.string.ai_model_tab_developer)} ($devCount)",
                                style = MaterialTheme.typography.labelMedium,
                            )
                        },
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                ModelSourceCategoryChips(
                    selectedCategory = selectedCategory,
                    onSelectCategory = { selectedCategory = it },
                    modifier = Modifier.fillMaxWidth(),
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Models list
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 340.dp),
                ) {
                    if (isLoading && classifiedModels == null) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .shimmer()
                                .padding(vertical = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            repeat(5) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(20.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)),
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Box(
                                            modifier = Modifier
                                                .width(140.dp)
                                                .height(14.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)),
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Box(
                                            modifier = Modifier
                                                .width(200.dp)
                                                .height(10.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)),
                                        )
                                    }
                                }
                            }
                        }
                    } else if (currentList.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = stringResource(R.string.ai_model_none_found),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    } else {
                        val collapsedProviders = remember { androidx.compose.runtime.mutableStateMapOf<String, Boolean>() }
                        val entries = remember(currentList, collapsedProviders, favoriteVersion) {
                            val favIds = favoritesManager.getFavoriteIds()
                            val favoriteModels = currentList.filter { favIds.contains(it.id) }
                            val nonFavoriteModels = currentList.filter { !favIds.contains(it.id) }

                            val list = mutableListOf<ModelListEntry>()

                            if (favoriteModels.isNotEmpty()) {
                                list.add(ModelListEntry.Header("⭐ Favorite Models", favoriteModels.size, favoriteModels.firstOrNull()?.id ?: ""))
                                if (collapsedProviders["⭐ Favorite Models"] != true) {
                                    favoriteModels.forEach { item ->
                                        list.add(ModelListEntry.OpenRouterModel(item))
                                    }
                                }
                            }

                            val grouped = nonFavoriteModels.groupBy { item ->
                                getProviderVisualInfo(item.id, item.providerName).name
                            }.toSortedMap()

                            grouped.forEach { (providerName, models) ->
                                list.add(ModelListEntry.Header(providerName, models.size, models.firstOrNull()?.id ?: ""))
                                if (collapsedProviders[providerName] != true) {
                                    models.forEach { item ->
                                        list.add(ModelListEntry.OpenRouterModel(item))
                                    }
                                }
                            }
                            list
                        }

                        AnimatedContent(
                            targetState = selectedCategory,
                            transitionSpec = {
                                fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(180))
                            },
                            label = "OpenRouterCategoryTransition",
                        ) { _ ->
                            LazyColumn(modifier = Modifier.fillMaxWidth()) {
                                items(entries, key = { entry ->
                                    when (entry) {
                                        is ModelListEntry.Header -> "header_${entry.providerName}"
                                        is ModelListEntry.OpenRouterModel -> entry.item.id
                                        is ModelListEntry.DeepInfraModel -> entry.model.id
                                    }
                                }) { entry ->
                                    when (entry) {
                                        is ModelListEntry.Header -> {
                                            val isCollapsed = collapsedProviders[entry.providerName] == true
                                            Surface(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 4.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .clickable {
                                                        collapsedProviders[entry.providerName] = !isCollapsed
                                                    },
                                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f),
                                            ) {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                ) {
                                                    ProviderAvatar(
                                                        modelId = entry.sampleModelId,
                                                        providerName = entry.providerName,
                                                        size = 24.dp,
                                                    )
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Text(
                                                        text = entry.providerName,
                                                        style = MaterialTheme.typography.titleSmall,
                                                        fontWeight = FontWeight.Bold,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        modifier = Modifier.weight(1f),
                                                    )
                                                    Surface(
                                                        shape = RoundedCornerShape(10.dp),
                                                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                                    ) {
                                                        Text(
                                                            text = "${entry.count}",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = MaterialTheme.colorScheme.primary,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                        )
                                                    }
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Icon(
                                                        painter = painterResource(
                                                            if (isCollapsed) R.drawable.expand_more else R.drawable.expand_less
                                                        ),
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        modifier = Modifier.size(20.dp),
                                                    )
                                                }
                                            }
                                        }
                                        is ModelListEntry.OpenRouterModel -> {
                                            val item = entry.item
                                            val isSelected = item.id == currentModel
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(10.dp))
                                                    .clickable {
                                                        viewModel.selectModel(item.id)
                                                        onSelectModel(item.id)
                                                    }
                                                    .padding(vertical = 8.dp, horizontal = 8.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                            ) {
                                                RadioButton(
                                                    selected = isSelected,
                                                    onClick = {
                                                        viewModel.selectModel(item.id)
                                                        onSelectModel(item.id)
                                                    },
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                ProviderAvatar(
                                                    modelId = item.id,
                                                    providerName = item.providerName,
                                                    size = 30.dp,
                                                )
                                                Spacer(modifier = Modifier.width(10.dp))
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                    ) {
                                                        Text(
                                                            text = item.name,
                                                            style = MaterialTheme.typography.bodyMedium,
                                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis,
                                                            modifier = Modifier.weight(1f, fill = false),
                                                        )
                                                        ProviderBadge(
                                                            modelId = item.id,
                                                            providerName = item.providerName,
                                                        )
                                                        ModelStatusBadge(
                                                            status = getModelHealthStatus(item.id, item.name),
                                                        )
                                                    }
                                                    Text(
                                                        text = item.id,
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis,
                                                    )
                                                }

                                                if (item.contextLength > 0) {
                                                    val contextK = item.contextLength / 1000
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Surface(
                                                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                                                        shape = RoundedCornerShape(6.dp),
                                                    ) {
                                                        Text(
                                                            text = "${contextK}k",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                        )
                                                    }
                                                }

                                                val isFav = favoritesManager.isFavorite(item.id)
                                                IconButton(
                                                    onClick = {
                                                        favoritesManager.toggleFavorite(item.id)
                                                        favoriteVersion++
                                                    },
                                                    modifier = Modifier.size(36.dp)
                                                ) {
                                                    Icon(
                                                        painter = painterResource(if (isFav) R.drawable.star else R.drawable.favorite_border),
                                                        contentDescription = null,
                                                        tint = if (isFav) Color(0xFFFFC107) else MaterialTheme.colorScheme.onSurfaceVariant,
                                                        modifier = Modifier.size(18.dp),
                                                    )
                                                }
                                            }
                                        }
                                        else -> {}
                                    }
                                }
                            }
                        }
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                // Custom model input trigger
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onCustomInput() }
                        .padding(vertical = 10.dp, horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        painter = painterResource(R.drawable.edit),
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp),
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = stringResource(R.string.ai_model_custom),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium,
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.dismiss))
            }
        },
    )
}
