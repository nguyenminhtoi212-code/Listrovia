package com.listrovia.music.extensions

import android.app.Application
import com.listrovia.innertube.YouTube
import com.listrovia.music.playback.StreamingDataTracker
import com.listrovia.music.security.ContentSafetyScanner
import com.listrovia.music.utils.cipher.CipherDeobfuscator
import com.listrovia.music.utils.YTPlayerUtils
import com.listrovia.music.work.ReleaseNotesWorker
import com.listrovia.music.utils.UpdateNotificationHelper
import com.listrovia.music.utils.CacheAutoManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import timber.log.Timber

fun Application.setupServices(applicationScope: CoroutineScope) {
    com.listrovia.music.utils.ensureWebViewCacheDirsExist(this)

    // Start two-step background content safety & security scanner
    ContentSafetyScanner.startBackgroundScanning(this, applicationScope)

    // Initialize cipher deobfuscator for WEB_REMIX streaming
    CipherDeobfuscator.initialize(this)

    // Initialize background data usage tracker for streaming & downloads
    StreamingDataTracker.init(this)

    // Background tasks
    applicationScope.launch(Dispatchers.IO) {
        // Warm the cipher WebView
        delay(3000)
        runCatching { CipherDeobfuscator.prewarm() }
    }

    applicationScope.launch(Dispatchers.IO) {
        // Warm the PoToken/BotGuard
        delay(8000)
        var waitedMs = 0
        while (YouTube.visitorData == null && waitedMs < 12_000) {
            delay(1000)
            waitedMs += 1000
        }
        runCatching { YTPlayerUtils.prewarmPoToken() }
    }

    applicationScope.launch(Dispatchers.IO) {
        delay(3000)
        runCatching {
            CacheAutoManager.checkAndAutoClearCache(this@setupServices)
        }
    }

    applicationScope.launch(Dispatchers.IO) {
        delay(4000)
        runCatching {
            ReleaseNotesWorker.enqueue(this@setupServices)
            UpdateNotificationHelper.checkAndNotifyAppUpdated(this@setupServices)
        }
    }
}
