/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.screens.search

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedAssistChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.listrovia.innertube.models.AlbumItem
import com.listrovia.innertube.models.ArtistItem
import com.listrovia.innertube.models.SongItem
import com.listrovia.innertube.models.YTItem
import com.listrovia.music.LocalPlayerConnection
import com.listrovia.music.R
import com.listrovia.music.constants.AutoRadioQueueKey
import com.listrovia.music.constants.PersistentSearchOverlayEnabledKey
import com.listrovia.music.ui.screens.Screens
import com.listrovia.music.db.entities.Album
import com.listrovia.music.db.entities.Artist
import com.listrovia.music.db.entities.Song
import com.listrovia.music.extensions.toMediaItem
import com.listrovia.music.models.toMediaMetadata
import com.listrovia.music.playback.queues.ListQueue
import com.listrovia.music.playback.queues.YouTubeQueue
import com.listrovia.music.ui.component.AlbumListItem
import com.listrovia.music.ui.component.ArtistListItem
import com.listrovia.music.ui.component.ExternalTrackItem
import com.listrovia.music.ui.component.LocalMenuState
import com.listrovia.music.ui.component.SongListItem
import com.listrovia.music.ui.component.YouTubeListItem
import com.listrovia.music.ui.menu.SongMenu
import com.listrovia.music.ui.menu.YouTubeAlbumMenu
import com.listrovia.music.ui.menu.YouTubeArtistMenu
import com.listrovia.music.ui.menu.YouTubeSongMenu
import com.listrovia.music.utils.rememberPreference
import com.listrovia.music.viewmodels.PersistentSearchResultState
import com.listrovia.music.viewmodels.PersistentSearchViewModel
import com.listrovia.music.viewmodels.SearchSourceFilter
import com.listrovia.music.viewmodels.SearchTypeFilter
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersistentSearchOverlay(
    state: SearchOverlayState,
    pureBlack: Boolean,
    navController: NavController,
    modifier: Modifier = Modifier,
    viewModel: PersistentSearchViewModel = hiltViewModel(),
) {
    if (!state.isVisible) return

    BackHandler(enabled = state.isVisible) {
        state.dismiss()
    }

    AnimatedVisibility(
        visible = state.isVisible,
        enter = fadeIn() + slideInVertically { -it / 8 },
        exit = fadeOut() + slideOutVertically { -it / 8 },
        modifier = modifier.fillMaxSize(),
    ) {
        RefreshedSearchContent(
            pureBlack = pureBlack,
            navController = navController,
            viewModel = viewModel,
            onDismiss = { state.dismiss() },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RefreshedSearchContent(
    pureBlack: Boolean,
    navController: NavController,
    modifier: Modifier = Modifier,
    viewModel: PersistentSearchViewModel = hiltViewModel(),
    onDismiss: (() -> Unit)? = null,
) {
    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current
    val focusRequester = remember { FocusRequester() }
    val lazyListState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    val playerConnection = LocalPlayerConnection.current
    val menuState = LocalMenuState.current

    val isPlaying by playerConnection?.isEffectivelyPlaying?.collectAsStateWithLifecycle() ?: remember { mutableStateOf(false) }
    val mediaMetadata by playerConnection?.mediaMetadata?.collectAsStateWithLifecycle() ?: remember { mutableStateOf(null) }

    val autoRadioQueue by rememberPreference(AutoRadioQueueKey, defaultValue = false)

    val typeFilter by viewModel.typeFilter.collectAsStateWithLifecycle()
    val resultState by viewModel.resultState.collectAsStateWithLifecycle()
    val searchHistory by viewModel.searchHistory.collectAsStateWithLifecycle()
    val query by viewModel.query.collectAsStateWithLifecycle()

    // Speech recognition launcher
    val voiceLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenText = matches?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                viewModel.query.value = spokenText
                viewModel.saveHistory(spokenText)
            }
        }
    }

    // Dismiss keyboard on scroll
    LaunchedEffect(lazyListState) {
        snapshotFlow { lazyListState.firstVisibleItemScrollOffset }
            .drop(1)
            .collect {
                keyboardController?.hide()
            }
    }

    // Handle back button to clear query or dismiss
    BackHandler(enabled = true) {
        if (query.isNotEmpty()) {
            viewModel.query.value = ""
        } else {
            focusManager.clearFocus()
            onDismiss?.invoke() ?: navController.navigateUp()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                if (pureBlack) Color.Black else MaterialTheme.colorScheme.background
            )
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
        ) {
            // Top Search Bar Section
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                shape = RoundedCornerShape(28.dp),
                color = if (pureBlack) Color(0xFF181818) else MaterialTheme.colorScheme.surfaceContainerHigh,
                tonalElevation = 6.dp,
                shadowElevation = 2.dp,
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            if (query.isNotEmpty()) {
                                viewModel.query.value = ""
                            } else {
                                focusManager.clearFocus()
                                onDismiss?.invoke() ?: navController.navigateUp()
                            }
                        },
                        modifier = Modifier.testTag("refreshed_search_back_button")
                    ) {
                        Icon(
                            painter = painterResource(
                                if (query.isNotEmpty()) R.drawable.arrow_back else R.drawable.search
                            ),
                            contentDescription = stringResource(R.string.search),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 4.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        if (query.isEmpty()) {
                            Text(
                                text = stringResource(R.string.persistent_search_placeholder),
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        BasicTextField(
                            value = query,
                            onValueChange = {
                                viewModel.query.value = it
                            },
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodyLarge.copy(
                                color = MaterialTheme.colorScheme.onSurface
                            ),
                            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                            keyboardOptions = KeyboardOptions(
                                imeAction = ImeAction.Search
                            ),
                            keyboardActions = KeyboardActions(
                                onSearch = {
                                    if (query.isNotBlank()) {
                                        viewModel.saveHistory(query)
                                    }
                                    keyboardController?.hide()
                                }
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .focusRequester(focusRequester)
                                .testTag("refreshed_search_input")
                        )
                    }

                    // Loading spinner
                    if (resultState.isSearchingStreaming || resultState.isSearchingLocal) {
                        CircularProgressIndicator(
                            modifier = Modifier
                                .size(20.dp)
                                .padding(end = 4.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Clear Button
                    if (query.isNotEmpty()) {
                        IconButton(
                            onClick = {
                                viewModel.query.value = ""
                            },
                            modifier = Modifier.testTag("refreshed_search_clear_button")
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.close),
                                contentDescription = stringResource(R.string.clear_search),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Voice Search Button
                    IconButton(
                        onClick = {
                            try {
                                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    putExtra(
                                        RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                                    )
                                    putExtra(
                                        RecognizerIntent.EXTRA_PROMPT,
                                        context.getString(R.string.voice_search_desc)
                                    )
                                }
                                voiceLauncher.launch(intent)
                            } catch (_: Exception) {}
                        },
                        modifier = Modifier.testTag("refreshed_voice_search_button")
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.mic),
                            contentDescription = stringResource(R.string.voice_search_title),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            // Filters Horizontal Scroll Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Type Filters (All / Tracks / Artists / Albums)
                FilterChip(
                    selected = typeFilter == SearchTypeFilter.ALL,
                    onClick = { viewModel.typeFilter.value = SearchTypeFilter.ALL },
                    label = { Text(stringResource(R.string.search_type_all)) }
                )
                FilterChip(
                    selected = typeFilter == SearchTypeFilter.TRACKS,
                    onClick = { viewModel.typeFilter.value = SearchTypeFilter.TRACKS },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.music_note),
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    label = { Text(stringResource(R.string.search_type_tracks)) }
                )
                FilterChip(
                    selected = typeFilter == SearchTypeFilter.ARTISTS,
                    onClick = { viewModel.typeFilter.value = SearchTypeFilter.ARTISTS },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.artist),
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    label = { Text(stringResource(R.string.search_type_artists)) }
                )
                FilterChip(
                    selected = typeFilter == SearchTypeFilter.ALBUMS,
                    onClick = { viewModel.typeFilter.value = SearchTypeFilter.ALBUMS },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.album),
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    label = { Text(stringResource(R.string.search_type_albums)) }
                )
            }

            HorizontalDivider(
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                modifier = Modifier.padding(top = 4.dp)
            )

            // Main Content List
            LazyColumn(
                state = lazyListState,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding =
                    WindowInsets.systemBars
                        .only(WindowInsetsSides.Bottom)
                        .asPaddingValues()
            ) {
                    if (query.isBlank()) {
                        // Empty query state: Quick Suggestion Chips + Search History
                        item(key = "quick_suggestions_header") {
                            Text(
                                text = stringResource(R.string.quick_suggestions),
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp)
                            )
                        }

                        item(key = "quick_suggestions_row") {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState())
                                    .padding(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                viewModel.quickPills.forEach { pill ->
                                    val title = stringResource(pill.titleRes)
                                    ElevatedAssistChip(
                                        onClick = {
                                            viewModel.query.value = pill.query
                                            viewModel.saveHistory(pill.query)
                                        },
                                        label = { Text(title) },
                                        shape = RoundedCornerShape(16.dp)
                                    )
                                }
                            }
                        }

                        // Search History Section
                        if (searchHistory.isNotEmpty()) {
                            item(key = "history_header") {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(start = 16.dp, end = 8.dp, top = 16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = stringResource(R.string.recent_searches),
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    TextButton(
                                        onClick = { viewModel.clearAllHistory() }
                                    ) {
                                        Text(
                                            text = stringResource(R.string.clear_search_history),
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                    }
                                }
                            }

                            items(
                                items = searchHistory,
                                key = { "history_${it.query}" }
                            ) { item ->
                                SuggestionItem(
                                    query = item.query,
                                    online = false,
                                    onClick = {
                                        viewModel.query.value = item.query
                                    },
                                    onDelete = {
                                        viewModel.deleteHistory(item)
                                    },
                                    onFillTextField = {
                                        viewModel.query.value = item.query
                                    },
                                    pureBlack = pureBlack,
                                    modifier = Modifier.animateItem()
                                )
                            }
                        }
                    } else {
                        // Query active: Show Search Results
                        val showTracks = typeFilter == SearchTypeFilter.ALL || typeFilter == SearchTypeFilter.TRACKS
                        val showArtists = typeFilter == SearchTypeFilter.ALL || typeFilter == SearchTypeFilter.ARTISTS
                        val showAlbums = typeFilter == SearchTypeFilter.ALL || typeFilter == SearchTypeFilter.ALBUMS

                        var hasAnyContent = false

                        // 1. Streaming Tracks
                        if (showTracks && resultState.streamingSongs.isNotEmpty()) {
                            hasAnyContent = true
                            item(key = "header_streaming_tracks") {
                                SearchSectionHeader(
                                    title = stringResource(R.string.search_type_tracks),
                                    count = resultState.streamingSongs.size,
                                )
                            }

                            items(
                                items = resultState.streamingSongs,
                                key = { "stream_song_${it.id}" }
                            ) { songItem ->
                                YouTubeListItem(
                                    item = songItem,
                                    isActive = songItem.id == mediaMetadata?.id,
                                    isPlaying = isPlaying,
                                    trailingContent = {
                                        IconButton(
                                            onClick = {
                                                menuState.show {
                                                    YouTubeSongMenu(
                                                        song = songItem,
                                                        onDismiss = {
                                                            menuState.dismiss()
                                                            onDismiss?.invoke() ?: focusManager.clearFocus()
                                                        }
                                                    )
                                                }
                                            }
                                        ) {
                                            Icon(
                                                painter = painterResource(R.drawable.more_vert),
                                                contentDescription = null
                                            )
                                        }
                                    },
                                    modifier = Modifier
                                        .combinedClickable(
                                            onClick = {
                                                viewModel.saveHistory(query)
                                                if (songItem.id == mediaMetadata?.id) {
                                                    playerConnection?.togglePlayPause()
                                                } else {
                                                    playerConnection?.playQueue(
                                                        if (autoRadioQueue) {
                                                            YouTubeQueue.radio(songItem.toMediaMetadata())
                                                        } else {
                                                            ListQueue(
                                                                title = songItem.title,
                                                                items = listOf(songItem.toMediaItem())
                                                            )
                                                        }
                                                    )
                                                }
                                            },
                                            onLongClick = {
                                                menuState.show {
                                                    YouTubeSongMenu(
                                                        song = songItem,
                                                        onDismiss = {
                                                            menuState.dismiss()
                                                            onDismiss?.invoke() ?: focusManager.clearFocus()
                                                        }
                                                    )
                                                }
                                            }
                                        )
                                        .animateItem()
                                )
                            }
                        }

                        // 2. Artists
                        if (showArtists && resultState.streamingArtists.isNotEmpty()) {
                            hasAnyContent = true
                            item(key = "header_artists") {
                                SearchSectionHeader(
                                    title = stringResource(R.string.section_artists),
                                    count = resultState.streamingArtists.size
                                )
                            }

                            items(
                                items = resultState.streamingArtists,
                                key = { "stream_artist_${it.id}" }
                            ) { artist ->
                                YouTubeListItem(
                                    item = artist,
                                    trailingContent = {
                                        IconButton(
                                            onClick = {
                                                menuState.show {
                                                    YouTubeArtistMenu(
                                                        artist = artist,
                                                        onDismiss = {
                                                            menuState.dismiss()
                                                            onDismiss?.invoke() ?: focusManager.clearFocus()
                                                        }
                                                    )
                                                }
                                            }
                                        ) {
                                            Icon(
                                                painter = painterResource(R.drawable.more_vert),
                                                contentDescription = null
                                            )
                                        }
                                    },
                                    modifier = Modifier
                                        .clickable {
                                            viewModel.saveHistory(query)
                                            onDismiss?.invoke() ?: focusManager.clearFocus()
                                            navController.navigate("artist/${artist.id}")
                                        }
                                        .animateItem()
                                )
                            }
                        }

                        // 3. Albums
                        if (showAlbums && resultState.streamingAlbums.isNotEmpty()) {
                            hasAnyContent = true
                            item(key = "header_albums") {
                                SearchSectionHeader(
                                    title = stringResource(R.string.section_albums),
                                    count = resultState.streamingAlbums.size
                                )
                            }

                            items(
                                items = resultState.streamingAlbums,
                                key = { "stream_album_${it.id}" }
                            ) { album ->
                                YouTubeListItem(
                                    item = album,
                                    isActive = album.id == mediaMetadata?.album?.id,
                                    isPlaying = isPlaying,
                                    trailingContent = {
                                        IconButton(
                                            onClick = {
                                                menuState.show {
                                                    YouTubeAlbumMenu(
                                                        albumItem = album,
                                                        onDismiss = {
                                                            menuState.dismiss()
                                                            onDismiss?.invoke() ?: focusManager.clearFocus()
                                                        }
                                                    )
                                                }
                                            }
                                        ) {
                                            Icon(
                                                painter = painterResource(R.drawable.more_vert),
                                                contentDescription = null
                                            )
                                        }
                                    },
                                    modifier = Modifier
                                        .clickable {
                                            viewModel.saveHistory(query)
                                            onDismiss?.invoke() ?: focusManager.clearFocus()
                                            navController.navigate("album/${album.id}")
                                        }
                                        .animateItem()
                                )
                            }
                        }

                        // 4. External Tracks (Apple Music)
                        if (showTracks && resultState.externalTracks.isNotEmpty()) {
                            hasAnyContent = true
                            item(key = "header_external_tracks") {
                                SearchSectionHeader(
                                    title = stringResource(R.string.section_other_streaming_platforms),
                                    count = resultState.externalTracks.size,
                                    badge = stringResource(R.string.search_source_apple_music),
                                    badgeColor = MaterialTheme.colorScheme.secondaryContainer,
                                    badgeTextColor = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }

                            items(
                                items = resultState.externalTracks,
                                key = { "ext_track_${it.uniqueId}" }
                            ) { extTrack ->
                                ExternalTrackItem(
                                    track = extTrack,
                                    externalService = viewModel.externalService,
                                    onResolveVideoId = { viewModel.resolveVideoId(it) },
                                    onArtistClick = { artistName ->
                                        viewModel.query.value = artistName
                                    },
                                    modifier = Modifier.animateItem()
                                )
                            }
                        }

                        // Empty Results Feedback
                        if (!hasAnyContent && !resultState.isSearchingLocal && !resultState.isSearchingStreaming) {
                            item(key = "empty_results") {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 64.dp, start = 32.dp, end = 32.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                                        modifier = Modifier.size(72.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                painter = painterResource(R.drawable.search),
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(36.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(16.dp))

                                    Text(
                                        text = stringResource(R.string.search_no_results_for, query),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Text(
                                        text = stringResource(R.string.search_try_different_keyword),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
            }
        }
    }
}

@Composable
private fun SearchSectionHeader(
    title: String,
    count: Int? = null,
    badge: String? = null,
    badgeColor: Color = MaterialTheme.colorScheme.surfaceVariant,
    badgeTextColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f, fill = false),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            if (count != null) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.surfaceContainerHighest
                ) {
                    Text(
                        text = count.toString(),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }

        if (badge != null) {
            Spacer(modifier = Modifier.width(8.dp))
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = badgeColor
            ) {
                Text(
                    text = badge,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Medium,
                    color = badgeTextColor,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Clip
                )
            }
        }
    }
}
