/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.db.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "version_history")
data class VersionHistoryEntity(
    @PrimaryKey
    val version: String, // e.g. "v13.6.3", "v1.0.1"
    val versionName: String, // e.g. "13.6.3", "1.0.1"
    val releaseDate: String = "",
    val description: String = "",
    val descriptionVi: String = "",
    val descriptionEn: String = "",
    val isCurrent: Boolean = false,
    val installedAt: Long = System.currentTimeMillis()
)
