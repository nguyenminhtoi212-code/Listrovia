package com.listrovia.music.ui.player

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import com.listrovia.music.video.VideoPlaybackService
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.ui.AspectRatioFrameLayout
import com.listrovia.music.R
import com.listrovia.music.video.VideoPlaybackManager

/**
 * Menu Cài đặt Video hợp nhất đồng bộ qua hệ thống chuỗi strings.xml.
 * Tự động chuyển đổi tiếng Anh và tiếng Việt chính xác theo ngôn ngữ ứng dụng / hệ thống.
 * Thiết kế lưới 2 hàng cân bằng tuyệt đối, không bị lệch khung hình hay co rút chữ.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoSettingsBottomSheet(
    onDismissRequest: () -> Unit,
    currentSpeed: Float,
    onSpeedSelected: (Float) -> Unit,
    currentQuality: String,
    onQualitySelected: (String) -> Unit,
    isLoopEnabled: Boolean,
    onToggleLoop: (Boolean) -> Unit,
    onOpenSyncPlayer: () -> Unit,
    onOpenFullscreen: () -> Unit,
    onReloadVideo: () -> Unit,
    activeVideoId: String,
    onNavigateToVideos: (() -> Unit)? = null,
    onNavigateToSearch: (() -> Unit)? = null,
    onNavigateToChannel: ((String) -> Unit)? = null,
    channelName: String? = null,
    channelId: String? = null,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val context = LocalContext.current
    val videoState by VideoPlaybackManager.uiState.collectAsState()

    ModalBottomSheet(
        onDismissRequest = onDismissRequest,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 16.dp,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // --- 1. TIÊU ĐỀ MENU TỪ STRINGS.XML & NÚT ĐÓNG ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.video_mode),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Column {
                        Text(
                            text = stringResource(R.string.video_settings_title),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = stringResource(R.string.video_settings_subtitle),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                IconButton(
                    onClick = onDismissRequest,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        painter = painterResource(R.drawable.close),
                        contentDescription = stringResource(R.string.close),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            HorizontalDivider(
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                modifier = Modifier.padding(bottom = 16.dp)
            )

            // --- 2. TỐC ĐỘ PHÁT LẠI (PLAYBACK SPEED) - LƯỚI 2 HÀNG CÂN ĐỐI ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.video_playback_speed_title),
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "${currentSpeed}x",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainerHighest)
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }

            // Hàng tốc độ 1: 0.5x (Chậm), 0.75x (Vừa), 1.0x (Chuẩn)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SpeedButton(
                    speed = 0.5f,
                    speedText = "0.5x",
                    labelRes = R.string.video_speed_slow,
                    currentSpeed = currentSpeed,
                    onSelect = onSpeedSelected,
                    modifier = Modifier.weight(1f)
                )
                SpeedButton(
                    speed = 0.75f,
                    speedText = "0.75x",
                    labelRes = R.string.video_speed_medium,
                    currentSpeed = currentSpeed,
                    onSelect = onSpeedSelected,
                    modifier = Modifier.weight(1f)
                )
                SpeedButton(
                    speed = 1.0f,
                    speedText = "1.0x",
                    labelRes = R.string.video_speed_normal,
                    currentSpeed = currentSpeed,
                    onSelect = onSpeedSelected,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Hàng tốc độ 2: 1.25x (Nhanh), 1.5x (1.5x), 2.0x (Tối đa)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SpeedButton(
                    speed = 1.25f,
                    speedText = "1.25x",
                    labelRes = R.string.video_speed_fast,
                    currentSpeed = currentSpeed,
                    onSelect = onSpeedSelected,
                    modifier = Modifier.weight(1f)
                )
                SpeedButton(
                    speed = 1.5f,
                    speedText = "1.5x",
                    labelRes = R.string.video_speed_fast,
                    currentSpeed = currentSpeed,
                    onSelect = onSpeedSelected,
                    modifier = Modifier.weight(1f)
                )
                SpeedButton(
                    speed = 2.0f,
                    speedText = "2.0x",
                    labelRes = R.string.video_speed_max,
                    currentSpeed = currentSpeed,
                    onSelect = onSpeedSelected,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // --- 3. ĐỘ PHÂN GIẢI VIDEO (VIDEO QUALITY) TỪ STRINGS.XML ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.video_quality_title),
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = currentQuality,
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainerHighest)
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }

            // Hàng chất lượng 1: Tự động (Auto) và 1080p (Full HD)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QualityButton(
                    qualityKey = "Tự động",
                    title = stringResource(R.string.video_quality_auto),
                    subtitle = stringResource(R.string.video_quality_auto_desc),
                    currentQuality = currentQuality,
                    onSelect = onQualitySelected,
                    modifier = Modifier.weight(1.2f)
                )
                QualityButton(
                    qualityKey = "1080p",
                    title = "1080p",
                    subtitle = stringResource(R.string.video_quality_full_hd),
                    currentQuality = currentQuality,
                    onSelect = onQualitySelected,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Hàng chất lượng 2: 720p, 480p, 360p
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QualityButton(
                    qualityKey = "720p",
                    title = "720p",
                    subtitle = stringResource(R.string.video_quality_hd),
                    currentQuality = currentQuality,
                    onSelect = onQualitySelected,
                    modifier = Modifier.weight(1f)
                )
                QualityButton(
                    qualityKey = "480p",
                    title = "480p",
                    subtitle = stringResource(R.string.video_quality_sd),
                    currentQuality = currentQuality,
                    onSelect = onQualitySelected,
                    modifier = Modifier.weight(1f)
                )
                QualityButton(
                    qualityKey = "360p",
                    title = "360p",
                    subtitle = stringResource(R.string.video_quality_low),
                    currentQuality = currentQuality,
                    onSelect = onQualitySelected,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // --- 4. TỶ LỆ HIỂN THỊ KHUNG HÌNH (ASPECT RATIO) TỪ STRINGS.XML ---
            Text(
                text = stringResource(R.string.video_aspect_ratio_title),
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    Triple(AspectRatioFrameLayout.RESIZE_MODE_FIT, R.string.video_aspect_ratio_fit, R.string.video_aspect_ratio_fit_desc),
                    Triple(AspectRatioFrameLayout.RESIZE_MODE_FILL, R.string.video_aspect_ratio_stretch, R.string.video_aspect_ratio_stretch_desc),
                    Triple(AspectRatioFrameLayout.RESIZE_MODE_ZOOM, R.string.video_aspect_ratio_zoom, R.string.video_aspect_ratio_zoom_desc)
                ).forEach { (mode, titleRes, descRes) ->
                    val isSelected = videoState.resizeMode == mode
                    Surface(
                        onClick = { VideoPlaybackManager.setResizeMode(mode) },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHighest,
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(horizontal = 4.dp, vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = stringResource(titleRes),
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold
                                ),
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = stringResource(descRes),
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                textAlign = TextAlign.Center,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.9f) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // --- 4.5 HẸN GIỜ NGỦ (SLEEP TIMER) TỪ STRINGS.XML ---
            val sleepTimerRemaining = videoState.sleepTimerRemainingSeconds
            val sleepTimerStatusText = when {
                sleepTimerRemaining == 0 -> stringResource(R.string.video_sleep_timer_status_off)
                sleepTimerRemaining == -1 -> stringResource(R.string.video_sleep_timer_end_of_track)
                else -> {
                    val mins = sleepTimerRemaining / 60
                    val secs = sleepTimerRemaining % 60
                    val timeStr = "%02d:%02d".format(mins, secs)
                    stringResource(R.string.video_sleep_timer_status_active, timeStr)
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.video_sleep_timer_title),
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = sleepTimerStatusText,
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = if (sleepTimerRemaining != 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (sleepTimerRemaining != 0) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHighest)
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }

            // Hàng hẹn giờ 1: Đang tắt, 10m, 15m, 30m
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SleepTimerChip(
                    label = stringResource(R.string.video_sleep_timer_off),
                    isSelected = sleepTimerRemaining == 0,
                    onClick = { VideoPlaybackManager.setSleepTimer(0) },
                    modifier = Modifier.weight(1.2f)
                )
                SleepTimerChip(
                    label = stringResource(R.string.video_sleep_timer_10m),
                    isSelected = sleepTimerRemaining in 1..600,
                    onClick = { VideoPlaybackManager.setSleepTimer(10) },
                    modifier = Modifier.weight(1f)
                )
                SleepTimerChip(
                    label = stringResource(R.string.video_sleep_timer_15m),
                    isSelected = sleepTimerRemaining in 601..900,
                    onClick = { VideoPlaybackManager.setSleepTimer(15) },
                    modifier = Modifier.weight(1f)
                )
                SleepTimerChip(
                    label = stringResource(R.string.video_sleep_timer_30m),
                    isSelected = sleepTimerRemaining in 901..1800,
                    onClick = { VideoPlaybackManager.setSleepTimer(30) },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Hàng hẹn giờ 2: 45m, 60m, Hết bài
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SleepTimerChip(
                    label = stringResource(R.string.video_sleep_timer_45m),
                    isSelected = sleepTimerRemaining in 1801..2700,
                    onClick = { VideoPlaybackManager.setSleepTimer(45) },
                    modifier = Modifier.weight(1f)
                )
                SleepTimerChip(
                    label = stringResource(R.string.video_sleep_timer_60m),
                    isSelected = sleepTimerRemaining > 2700,
                    onClick = { VideoPlaybackManager.setSleepTimer(60) },
                    modifier = Modifier.weight(1f)
                )
                SleepTimerChip(
                    label = stringResource(R.string.video_sleep_timer_end_of_track),
                    isSelected = sleepTimerRemaining == -1,
                    onClick = { VideoPlaybackManager.setSleepTimer(-1) },
                    modifier = Modifier.weight(1.3f)
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // --- 5. CÁC TÙY CHỌN BẬT/TẮT TỪ STRINGS.XML ---
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainerHighest)
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                // Tùy chọn Lặp lại video (Loop Video)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.repeat),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        Column {
                            Text(
                                text = stringResource(R.string.video_loop_title),
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = stringResource(R.string.video_loop_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Switch(
                        checked = isLoopEnabled || videoState.isLoopVideoEnabled,
                        onCheckedChange = { onToggleLoop(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                            checkedTrackColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

                // Tùy chọn Chế độ môi trường xung quanh (Ambient Mode)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.tune),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        Column {
                            Text(
                                text = stringResource(R.string.video_ambient_mode_title),
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = stringResource(R.string.video_ambient_mode_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Switch(
                        checked = videoState.ambientModeEnabled,
                        onCheckedChange = { VideoPlaybackManager.setAmbientModeEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                            checkedTrackColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

                // Tùy chọn Âm lượng ổn định (Stable Volume)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.volume_up),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        Column {
                            Text(
                                text = stringResource(R.string.video_stable_volume_title),
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = stringResource(R.string.video_stable_volume_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Switch(
                        checked = videoState.stableVolumeEnabled,
                        onCheckedChange = { VideoPlaybackManager.setStableVolumeEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                            checkedTrackColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

                // Tùy chọn Tự động chuyển bài (Autoplay Next)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.sync),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        Column {
                            Text(
                                text = stringResource(R.string.video_autoplay_title),
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = stringResource(R.string.video_autoplay_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Switch(
                        checked = videoState.autoplayEnabled,
                        onCheckedChange = { VideoPlaybackManager.setAutoplayEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                            checkedTrackColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // --- 5.5 PHỤ ĐỀ & DỊCH AI (AI SUBTITLES & TRANSLATION) ---
            Text(
                text = stringResource(R.string.video_ai_subtitles_title),
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainerHighest)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.video_mode),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        Column {
                            Text(
                                text = stringResource(R.string.video_ai_enable_toggle),
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = stringResource(R.string.video_ai_subtitles_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Switch(
                        checked = videoState.aiSubtitlesEnabled,
                        onCheckedChange = { VideoPlaybackManager.setAiSubtitlesEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                            checkedTrackColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }

                if (videoState.aiSubtitlesEnabled) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

                    Text(
                        text = stringResource(R.string.video_ai_target_lang),
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AiLangButton(
                            langKey = "vi",
                            title = stringResource(R.string.video_ai_lang_vi),
                            currentLang = videoState.aiSubtitleTargetLang,
                            onSelect = { VideoPlaybackManager.setAiSubtitleTargetLang(it) },
                            modifier = Modifier.weight(1f)
                        )
                        AiLangButton(
                            langKey = "en",
                            title = stringResource(R.string.video_ai_lang_en),
                            currentLang = videoState.aiSubtitleTargetLang,
                            onSelect = { VideoPlaybackManager.setAiSubtitleTargetLang(it) },
                            modifier = Modifier.weight(1f)
                        )
                        AiLangButton(
                            langKey = "off",
                            title = stringResource(R.string.video_ai_lang_off),
                            currentLang = videoState.aiSubtitleTargetLang,
                            onSelect = { VideoPlaybackManager.setAiSubtitleTargetLang(it) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // --- 6. CÁC TÁC VỤ VIDEO NÂNG CAO TỪ STRINGS.XML ---
            Text(
                text = stringResource(R.string.video_advanced_features),
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainerHighest)
            ) {
                // Toàn màn hình (Fullscreen)
                ActionRow(
                    icon = R.drawable.fullscreen,
                    title = stringResource(R.string.video_fullscreen_title),
                    subtitle = stringResource(R.string.video_fullscreen_desc),
                    onClick = onOpenFullscreen
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

                // Hình trong hình (Picture-in-Picture)
                if (VideoPlaybackService.supportsPictureInPicture(context)) {
                    ActionRow(
                        icon = R.drawable.ic_pip,
                        title = stringResource(R.string.video_pip_title),
                        subtitle = stringResource(R.string.video_pip_desc),
                        onClick = {
                            onDismissRequest()
                            (context as? Activity)?.let { act ->
                                VideoPlaybackService.enterPictureInPicture(act)
                            }
                        }
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
                }

                // Khám phá video (Browse Videos)
                if (onNavigateToVideos != null) {
                    ActionRow(
                        icon = R.drawable.video_mode,
                        title = stringResource(R.string.video_action_browse_videos),
                        subtitle = stringResource(R.string.video_action_browse_videos_desc),
                        onClick = {
                            onDismissRequest()
                            onNavigateToVideos()
                        }
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
                }

                // Tìm kiếm video (Search Videos)
                if (onNavigateToSearch != null) {
                    ActionRow(
                        icon = R.drawable.search,
                        title = stringResource(R.string.video_action_search_videos),
                        subtitle = stringResource(R.string.video_action_search_videos_desc),
                        onClick = {
                            onDismissRequest()
                            onNavigateToSearch()
                        }
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
                }

                // Kênh phát hành (Channel Details)
                val targetChannel = channelId?.takeIf { it.isNotBlank() } ?: channelName?.takeIf { it.isNotBlank() }
                if (onNavigateToChannel != null && targetChannel != null) {
                    ActionRow(
                        icon = R.drawable.person,
                        title = stringResource(R.string.video_action_channel),
                        subtitle = targetChannel,
                        onClick = {
                            onDismissRequest()
                            onNavigateToChannel(targetChannel)
                        }
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
                }

                // YouTube Sync Player
                ActionRow(
                    icon = R.drawable.sync,
                    title = stringResource(R.string.video_sync_player_title),
                    subtitle = stringResource(R.string.video_sync_player_desc),
                    onClick = onOpenSyncPlayer
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

                // Sao chép liên kết video (Copy Video Link)
                val toastMessage = stringResource(R.string.video_copy_link_toast)
                ActionRow(
                    icon = R.drawable.content_copy,
                    title = stringResource(R.string.video_copy_link_title),
                    subtitle = stringResource(R.string.video_copy_link_desc),
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                        clipboard?.setPrimaryClip(
                            ClipData.newPlainText("YouTube Video Link", "https://www.youtube.com/watch?v=$activeVideoId")
                        )
                        Toast.makeText(context, toastMessage, Toast.LENGTH_SHORT).show()
                        onDismissRequest()
                    }
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))

                // Làm mới khung hình (Reload Video)
                ActionRow(
                    icon = R.drawable.refresh,
                    title = stringResource(R.string.video_reload_title),
                    subtitle = stringResource(R.string.video_reload_desc),
                    onClick = onReloadVideo
                )
            }
        }
    }
}

/**
 * Nút chọn Tốc độ phát hiển thị nhãn dịch từ strings.xml.
 */
@Composable
private fun SpeedButton(
    speed: Float,
    speedText: String,
    labelRes: Int,
    currentSpeed: Float,
    onSelect: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val isSelected = Math.abs(currentSpeed - speed) < 0.05f
    Surface(
        onClick = { onSelect(speed) },
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHighest,
        modifier = modifier.height(44.dp)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = speedText,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold
                ),
                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = stringResource(labelRes),
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = if (isSelected) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f) else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/**
 * Nút chọn Chất lượng video hiển thị nhãn dịch từ strings.xml.
 */
@Composable
private fun QualityButton(
    qualityKey: String,
    title: String,
    subtitle: String,
    currentQuality: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val isSelected = currentQuality.equals(qualityKey, ignoreCase = true)
    Surface(
        onClick = { onSelect(qualityKey) },
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHighest,
        modifier = modifier.height(48.dp)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold
                ),
                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = if (isSelected) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f) else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/**
 * Hàng tác vụ sử dụng chuỗi nội địa hóa từ strings.xml.
 */
@Composable
private fun ActionRow(
    icon: Int,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Icon(
            painter = painterResource(icon),
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp)
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall.copy(lineHeight = 16.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun AiLangButton(
    langKey: String,
    title: String,
    currentLang: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val isSelected = currentLang.equals(langKey, ignoreCase = true)
    Surface(
        onClick = { onSelect(langKey) },
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHighest,
        modifier = modifier.height(44.dp)
    ) {
        Box(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold
                ),
                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center
            )
        }
    }
}

/**
 * Nút chọn mốc thời gian hẹn giờ ngủ với phản hồi giao diện tức thì.
 */
@Composable
private fun SleepTimerChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHighest,
        modifier = modifier.height(44.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold
                ),
                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center
            )
        }
    }
}
