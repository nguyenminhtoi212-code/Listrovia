package com.listrovia.music.discord

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeout
import timber.log.Timber

class DiscordOAuthActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)
        finish()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
        finish()
    }

    private fun handleIntent(intent: Intent?) {
        val data: Uri? = intent?.data
        if (data != null) {
            val code = data.getQueryParameter("code")
            val state = data.getQueryParameter("state")
            val error = data.getQueryParameter("error")
            val errorDescription = data.getQueryParameter("error_description")

            if (error != null) {
                Timber.tag(TAG).w("OAuth error received: %s (%s)", error, errorDescription)
                pendingDeferred?.completeExceptionally(
                    DiscordAuthException.InvalidGrant("OAuth error: $error - $errorDescription")
                )
            } else if (!code.isNullOrEmpty() && !state.isNullOrEmpty()) {
                Timber.tag(TAG).i("OAuth callback received with code and state")
                pendingDeferred?.complete(OAuthCallback(code = code, state = state))
            } else {
                Timber.tag(TAG).w("OAuth callback without valid code or state: %s", data)
                pendingDeferred?.completeExceptionally(
                    DiscordAuthException.InvalidGrant("Missing code or state in callback")
                )
            }
        }
    }

    data class OAuthCallback(
        val code: String,
        val state: String,
    )

    companion object {
        private const val TAG = "DiscordOAuthActivity"
        private var pendingDeferred: CompletableDeferred<OAuthCallback>? = null

        fun newDeferred(): CompletableDeferred<OAuthCallback> {
            val deferred = CompletableDeferred<OAuthCallback>()
            pendingDeferred = deferred
            return deferred
        }

        suspend fun awaitCode(timeoutMs: Long): OAuthCallback {
            val deferred = pendingDeferred ?: throw DiscordAuthException.UserCancelled("No pending authorization")
            return withTimeout(timeoutMs) {
                deferred.await()
            }
        }

        fun cancelPending() {
            pendingDeferred?.cancel()
            pendingDeferred = null
        }
    }
}
