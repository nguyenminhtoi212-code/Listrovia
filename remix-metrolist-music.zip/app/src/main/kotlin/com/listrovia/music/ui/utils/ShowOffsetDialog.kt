package com.listrovia.music.ui.utils

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.listrovia.music.LocalDatabase
import com.listrovia.music.R
import com.listrovia.music.db.entities.SongEntity
import com.listrovia.music.lyrics.LyricsResyncHelper
import kotlinx.coroutines.FlowPreview

@OptIn(FlowPreview::class)
@Composable
fun ShowOffsetDialog(songProvider: () -> SongEntity?) {
    val database = LocalDatabase.current
    val song = songProvider()
    var lyricsOffset by rememberSaveable { mutableIntStateOf(song?.lyricsOffset ?: 0) }
    var textFieldValue by rememberSaveable { mutableStateOf(lyricsOffset.toString()) }

    LaunchedEffect(song?.id) {
        song?.let {
            lyricsOffset = it.lyricsOffset
            textFieldValue = lyricsOffset.toString()
        }
    }

    LaunchedEffect(lyricsOffset) {
        songProvider()?.let { currentSong ->
            database.query {
                upsert(
                    currentSong.copy(
                        lyricsOffset = lyricsOffset
                    )
                )
            }
            LyricsResyncHelper.triggerResync()
        }
    }

    val chipScrollState = rememberScrollState()

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 16.dp)
            .testTag("lyrics_offset_dialog")
    ) {
        // Top Icon & Title
        Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primaryContainer,
            modifier = Modifier.size(56.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    painter = painterResource(R.drawable.fast_forward),
                    contentDescription = stringResource(R.string.lyrics_offset),
                    modifier = Modifier.size(28.dp),
                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = stringResource(R.string.lyrics_offset),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = stringResource(R.string.lyrics_offset_desc),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Large Current Offset Display Badge
        val badgeColor by animateColorAsState(
            targetValue = if (lyricsOffset == 0) {
                MaterialTheme.colorScheme.surfaceVariant
            } else {
                MaterialTheme.colorScheme.primaryContainer
            },
            label = "offset_badge_color"
        )
        val badgeTextColor by animateColorAsState(
            targetValue = if (lyricsOffset == 0) {
                MaterialTheme.colorScheme.onSurfaceVariant
            } else {
                MaterialTheme.colorScheme.onPrimaryContainer
            },
            label = "offset_badge_text_color"
        )

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(badgeColor)
                .padding(horizontal = 24.dp, vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                val sign = if (lyricsOffset > 0) "+" else ""
                Text(
                    text = if (lyricsOffset == 0) stringResource(R.string.lyrics_offset_synced) else "$sign$lyricsOffset ms",
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
                    color = badgeTextColor
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Direct Text Input & Stepper
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            IconButton(
                onClick = {
                    lyricsOffset = (lyricsOffset - 50).coerceIn(-5000, 5000)
                    textFieldValue = lyricsOffset.toString()
                },
                colors = IconButtonDefaults.filledTonalIconButtonColors(),
                modifier = Modifier.testTag("offset_decrement_btn")
            ) {
                Icon(
                    painter = painterResource(R.drawable.remove),
                    contentDescription = stringResource(R.string.lyrics_offset_earlier)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            TextField(
                value = textFieldValue,
                onValueChange = { newText ->
                    val sanitized = newText.filter {
                        it.isDigit() || (it == '-' && newText.indexOf('-') == 0)
                    }
                    val limited = if (sanitized.startsWith('-')) {
                        sanitized.take(6)
                    } else {
                        sanitized.take(5)
                    }
                    textFieldValue = limited

                    when {
                        limited.isEmpty() -> {
                            lyricsOffset = 0
                            textFieldValue = "0"
                        }
                        limited == "-" -> {
                            // keep user typing
                        }
                        else -> {
                            limited.toIntOrNull()?.let { parsedValue ->
                                val clampedValue = parsedValue.coerceIn(-5000, 5000)
                                lyricsOffset = clampedValue
                                if (parsedValue != clampedValue) {
                                    textFieldValue = clampedValue.toString()
                                }
                            }
                        }
                    }
                },
                singleLine = true,
                textStyle = MaterialTheme.typography.titleLarge.copy(
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Bold
                ),
                modifier = Modifier
                    .widthIn(min = 100.dp, max = 130.dp)
                    .testTag("offset_input_field"),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                    cursorColor = MaterialTheme.colorScheme.primary,
                    focusedIndicatorColor = MaterialTheme.colorScheme.primary,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Done
                )
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = {
                    lyricsOffset = (lyricsOffset + 50).coerceIn(-5000, 5000)
                    textFieldValue = lyricsOffset.toString()
                },
                colors = IconButtonDefaults.filledTonalIconButtonColors(),
                modifier = Modifier.testTag("offset_increment_btn")
            ) {
                Icon(
                    painter = painterResource(R.drawable.add),
                    contentDescription = stringResource(R.string.lyrics_offset_later)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quick Preset Step Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(chipScrollState),
            horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally)
        ) {
            val presets = listOf(-500, -100, -50, 0, 50, 100, 500)
            presets.forEach { preset ->
                val isSelected = (preset == 0 && lyricsOffset == 0)
                AssistChip(
                    onClick = {
                        if (preset == 0) {
                            lyricsOffset = 0
                        } else {
                            lyricsOffset = (lyricsOffset + preset).coerceIn(-5000, 5000)
                        }
                        textFieldValue = lyricsOffset.toString()
                    },
                    label = {
                        Text(
                            text = if (preset == 0) stringResource(R.string.lyrics_offset_synced) else "${if (preset > 0) "+" else ""}${preset}ms",
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = if (isSelected) {
                        AssistChipDefaults.assistChipColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            labelColor = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    } else {
                        AssistChipDefaults.assistChipColors()
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Interactive Slider (-3000ms to +3000ms)
        Slider(
            value = lyricsOffset.toFloat(),
            onValueChange = { newValue ->
                val rounded = ((newValue / 25).toInt() * 25).coerceIn(-5000, 5000)
                lyricsOffset = rounded
                textFieldValue = rounded.toString()
            },
            valueRange = -3000f..3000f,
            steps = 239,
            colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary,
                inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("offset_slider")
        )

        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
        ) {
            Text(
                text = "-3000ms (" + stringResource(R.string.lyrics_offset_earlier) + ")",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "+3000ms (" + stringResource(R.string.lyrics_offset_later) + ")",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
