package com.listrovia.music.models

object SettingsOptions {
    val defaultLanguageOptions = listOf("Tiếng Việt", "English", "日本語", "한국어", "Tiếng Trung (Phồn thể)")
    val lyricsPositions = listOf("Trái", "Giữa", "Phải")
    val wordByWordAnimationStyles = listOf("Lyrics V2 (Fluid)", "Apple Music Style", "Standard", "Mặc định")
    val playerBackgroundStyles = listOf("Apple Music", "Dựa theo chủ đề", "Mặc định", "Đơn sắc", "Blurred Album Art")
    val playerButtonColors = listOf("Mặc định", "Chủ đề chính", "Trắng", "Trong suốt")
}
