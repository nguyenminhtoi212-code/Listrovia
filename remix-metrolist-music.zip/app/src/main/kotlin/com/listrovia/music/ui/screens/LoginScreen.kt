/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.screens

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.datastore.preferences.core.edit
import androidx.navigation.NavController
import com.listrovia.innertube.YouTube
import com.listrovia.music.R
import com.listrovia.music.constants.AccountChannelHandleKey
import com.listrovia.music.constants.AccountEmailKey
import com.listrovia.music.constants.AccountNameKey
import com.listrovia.music.constants.AccountProviderKey
import com.listrovia.music.constants.DataSyncIdKey
import com.listrovia.music.constants.HasCompletedOnboardingKey
import com.listrovia.music.constants.InnerTubeCookieKey
import com.listrovia.music.constants.LoginHistoryKey
import com.listrovia.music.constants.TermsAcceptedKey
import com.listrovia.music.constants.VisitorDataKey
import com.listrovia.music.ui.component.IconButton
import com.listrovia.music.ui.component.Material3SettingsGroup
import com.listrovia.music.ui.component.Material3SettingsItem
import com.listrovia.music.ui.utils.backToMain
import com.listrovia.music.utils.dataStore
import com.listrovia.music.utils.ensureWebViewCacheDirsExist
import com.listrovia.music.utils.rememberPreference
import com.listrovia.music.utils.reportException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
sealed interface PendingLogin {
    data class Custom(val provider: String, val name: String, val email: String) : PendingLogin
    data class Google(
        val cookie: String,
        val visitorData: String,
        val dataSyncId: String,
        val name: String,
        val email: String,
        val channelHandle: String
    ) : PendingLogin
}

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LoginScreen(navController: NavController) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isCompletingLogin by remember { mutableStateOf(false) }

    var webView: WebView? = null
    var isWebViewLoading by remember { mutableStateOf(true) }
    var visitorDataFromWeb by remember { mutableStateOf("") }
    var dataSyncIdFromWeb by remember { mutableStateOf("") }

    // Navigation & UI States
    val (hasCompletedOnboarding) = rememberPreference(HasCompletedOnboardingKey, defaultValue = false)
    val (termsAccepted) = rememberPreference(TermsAcceptedKey, defaultValue = false)
    val (accountProvider) = rememberPreference(AccountProviderKey, defaultValue = "none")
    val isUserOnboarded = hasCompletedOnboarding && termsAccepted && accountProvider != "none"

    var showGoogleWebView by remember { mutableStateOf(false) }
    var selectedAgreementOption by remember { mutableStateOf<Boolean?>(null) }
    var pendingLogin by remember { mutableStateOf<PendingLogin?>(null) }

    fun commitLogin(pending: PendingLogin) {
        coroutineScope.launch {
            withContext(Dispatchers.IO) {
                context.dataStore.edit { settings ->
                    settings[HasCompletedOnboardingKey] = true
                    settings[TermsAcceptedKey] = true
                    when (pending) {
                        is PendingLogin.Custom -> {
                            val provider = pending.provider
                            val name = pending.name
                            val email = pending.email

                            settings[AccountProviderKey] = provider.lowercase()
                            settings[AccountNameKey] = name
                            settings[AccountEmailKey] = email
                            settings[AccountChannelHandleKey] = "@${name.replace(" ", "").lowercase()}"

                            settings.remove(InnerTubeCookieKey)
                            settings.remove(VisitorDataKey)
                            settings.remove(DataSyncIdKey)

                            val timestamp = System.currentTimeMillis()
                            val newEntry = "$provider|$email|$timestamp"
                            val existingHistory = settings[LoginHistoryKey].orEmpty()
                            val updatedHistory = if (existingHistory.isEmpty()) {
                                newEntry
                            } else {
                                "$newEntry;$existingHistory"
                            }
                            settings[LoginHistoryKey] = updatedHistory
                        }
                        is PendingLogin.Google -> {
                            settings[InnerTubeCookieKey] = pending.cookie
                            settings[VisitorDataKey] = pending.visitorData
                            settings[DataSyncIdKey] = pending.dataSyncId
                            settings[AccountNameKey] = pending.name
                            settings[AccountEmailKey] = pending.email
                            settings[AccountChannelHandleKey] = pending.channelHandle
                            settings[AccountProviderKey] = "google"

                            val timestamp = System.currentTimeMillis()
                            val newEntry = "Google|${pending.email.ifBlank { pending.name }}|$timestamp"
                            val existingHistory = settings[LoginHistoryKey].orEmpty()
                            val updatedHistory = if (existingHistory.isEmpty()) {
                                newEntry
                            } else {
                                "$newEntry;$existingHistory"
                            }
                            settings[LoginHistoryKey] = updatedHistory
                        }
                    }
                }
            }

            withContext(Dispatchers.Main) {
                when (pending) {
                    is PendingLogin.Google -> {
                        YouTube.cookie = pending.cookie
                        YouTube.visitorData = pending.visitorData
                        YouTube.dataSyncId = pending.dataSyncId
                    }
                    is PendingLogin.Custom -> {
                        YouTube.cookie = null
                        YouTube.visitorData = null
                        YouTube.dataSyncId = null
                    }
                }

                val hasPrevious = navController.previousBackStackEntry != null &&
                    navController.previousBackStackEntry?.destination?.route != "login" &&
                    navController.previousBackStackEntry?.destination?.route != "settings/terms_privacy"

                if (hasPrevious) {
                    navController.navigateUp()
                } else {
                    navController.navigate(Screens.Home.route) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            }
        }
    }

    fun completeGoogleLogin(onClose: () -> Unit) {
        if (isCompletingLogin) return

        isCompletingLogin = true
        coroutineScope.launch {
            val currentCookie = CookieManager.getInstance().getCookie("https://music.youtube.com").orEmpty()
            if (currentCookie.isBlank()) {
                Timber.d("Login: No YouTube Music cookie found on close, leaving login screen")
                isCompletingLogin = false
                onClose()
                return@launch
            }

            val savedVisitorData = visitorDataFromWeb
            val savedDataSyncId = dataSyncIdFromWeb

            YouTube.cookie = currentCookie
            YouTube.dataSyncId = savedDataSyncId
            YouTube.visitorData = savedVisitorData

            Timber.d("Login: Validating Google account...")

            YouTube
                .accountInfo()
                .onSuccess { info ->
                    Timber.d("Login: Successfully authenticated as ${info.name}")

                    webView?.apply {
                        stopLoading()
                        loadUrl("about:blank")
                        clearHistory()
                        clearCache(true)
                        ensureWebViewCacheDirsExist(context)
                        clearFormData()
                    }

                    withContext(Dispatchers.Main) {
                        pendingLogin = PendingLogin.Google(
                            cookie = currentCookie,
                            visitorData = savedVisitorData,
                            dataSyncId = savedDataSyncId,
                            name = info.name,
                            email = info.email.orEmpty(),
                            channelHandle = info.channelHandle.orEmpty()
                        )
                        showGoogleWebView = false
                        isCompletingLogin = false
                    }
                }.onFailure {
                    Timber.e(it, "Login: Authentication validation failed")
                    reportException(it)
                    isCompletingLogin = false
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Xác thực không thành công, vui lòng thử lại.", Toast.LENGTH_SHORT).show()
                    }
                }
        }
    }

    if (showGoogleWebView) {
        // Fullscreen WebView for Google Login
        Box(
            modifier = Modifier
                .fillMaxSize()
                .testTag("google_webview_container")
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                TopAppBar(
                    title = {
                        Column {
                            Text(stringResource(R.string.login_google), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "accounts.google.com",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = { 
                                if (!isCompletingLogin) {
                                    showGoogleWebView = false 
                                }
                            },
                            onLongClick = {},
                            enabled = !isCompletingLogin
                        ) {
                            Icon(
                                painterResource(R.drawable.arrow_back),
                                contentDescription = "Quay lại",
                            )
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { webView?.reload() },
                            onLongClick = {},
                            enabled = !isCompletingLogin
                        ) {
                            Icon(
                                painterResource(R.drawable.refresh),
                                contentDescription = "Tải lại",
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )

                if (isWebViewLoading && !isCompletingLogin) {
                    LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { webViewContext ->
                        WebView(webViewContext).apply {
                            setLayerType(View.LAYER_TYPE_SOFTWARE, null)
                            webViewClient = object : WebViewClient() {
                                override fun onRenderProcessGone(view: WebView?, detail: android.webkit.RenderProcessGoneDetail?): Boolean {
                                    val crashed = detail?.didCrash() == true
                                    Timber.e("Login WebView render process gone! crashed: $crashed")
                                    // If it crashed, we might want to try recreating the WebView or showing an error
                                    if (crashed) {
                                        showGoogleWebView = false
                                        // You could show a snackbar or toast here
                                    }
                                    return true
                                }

                                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                    val url = request?.url?.toString().orEmpty()
                                    if (url.contains("music.youtube.com")) {
                                        val cookie = CookieManager.getInstance().getCookie("https://music.youtube.com").orEmpty()
                                        if (cookie.isNotBlank() && (cookie.contains("SAPISID") || cookie.contains("__Secure-") || cookie.contains("SID"))) {
                                            view?.stopLoading()
                                            completeGoogleLogin { showGoogleWebView = false }
                                            return true
                                        }
                                    }
                                    return false
                                }

                                @Deprecated("Deprecated in Java")
                                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                                    if (url?.contains("music.youtube.com") == true) {
                                        val cookie = CookieManager.getInstance().getCookie("https://music.youtube.com").orEmpty()
                                        if (cookie.isNotBlank() && (cookie.contains("SAPISID") || cookie.contains("__Secure-") || cookie.contains("SID"))) {
                                            view?.stopLoading()
                                            completeGoogleLogin { showGoogleWebView = false }
                                            return true
                                        }
                                    }
                                    return false
                                }

                                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                                    super.onPageStarted(view, url, favicon)
                                    isWebViewLoading = true
                                    if (url?.contains("music.youtube.com") == true && !isCompletingLogin) {
                                        val cookie = CookieManager.getInstance().getCookie("https://music.youtube.com").orEmpty()
                                        if (cookie.isNotBlank() && (cookie.contains("SAPISID") || cookie.contains("__Secure-") || cookie.contains("SID"))) {
                                            view?.stopLoading()
                                            completeGoogleLogin { showGoogleWebView = false }
                                        }
                                    }
                                }

                                override fun onPageFinished(view: WebView, url: String?) {
                                    super.onPageFinished(view, url)
                                    isWebViewLoading = false
                                    loadUrl("javascript:Android.onRetrieveVisitorData(window.yt?.config_?.VISITOR_DATA || '')")
                                    loadUrl("javascript:Android.onRetrieveDataSyncId(window.yt?.config_?.DATASYNC_ID || '')")

                                    if (url?.contains("music.youtube.com") == true && !isCompletingLogin) {
                                        val cookie = CookieManager.getInstance().getCookie("https://music.youtube.com").orEmpty()
                                        if (cookie.isNotBlank()) {
                                            view.stopLoading()
                                            Timber.d("Login: Detected authenticated session on music.youtube.com, completing login...")
                                            completeGoogleLogin { showGoogleWebView = false }
                                        }
                                    }
                                }
                            }
                            settings.apply {
                                javaScriptEnabled = true
                                setSupportZoom(true)
                                builtInZoomControls = true
                                displayZoomControls = false
                            }
                            addJavascriptInterface(
                                object {
                                    @JavascriptInterface
                                    fun onRetrieveVisitorData(newVisitorData: String?) {
                                        if (newVisitorData != null) {
                                            visitorDataFromWeb = newVisitorData
                                        }
                                    }

                                    @JavascriptInterface
                                    fun onRetrieveDataSyncId(newDataSyncId: String?) {
                                        if (newDataSyncId != null) {
                                            dataSyncIdFromWeb = newDataSyncId.substringBefore("||")
                                        }
                                    }
                                },
                                "Android",
                            )
                            webView = this
                            loadUrl("https://accounts.google.com/ServiceLogin?continue=https%3A%2F%2Fmusic.youtube.com")
                        }
                    },
                )
            }

            if (isCompletingLogin) {
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .clickable(enabled = false) {},
                    color = MaterialTheme.colorScheme.background.copy(alpha = 0.96f)
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.padding(32.dp)
                        ) {
                            CircularProgressIndicator(
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(48.dp)
                            )
                            Text(
                                text = "Đang đồng bộ tài khoản Google...",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = "Đang kết nối và chuyển hướng vào ứng dụng, vui lòng đợi trong giây lát...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        BackHandler(enabled = !isCompletingLogin) {
            val currentWebView = webView
            if (currentWebView?.canGoBack() == true) {
                currentWebView.goBack()
            } else {
                showGoogleWebView = false
            }
        }
    } else if (pendingLogin != null) {
        // Step 2: Terms & Policies Agreement Screen
        BackHandler {
            pendingLogin = null
            selectedAgreementOption = null
        }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = stringResource(R.string.terms_and_privacy),
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = {
                                pendingLogin = null
                                selectedAgreementOption = null
                            },
                            onLongClick = {}
                        ) {
                            Icon(
                                painterResource(R.drawable.arrow_back),
                                contentDescription = "Quay lại",
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background
                    )
                )
            },
            contentWindowInsets = WindowInsets.systemBars,
            containerColor = MaterialTheme.colorScheme.background
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentAlignment = Alignment.TopCenter
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 600.dp)
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                        .verticalScroll(rememberScrollState())
                        .testTag("terms_agreement_screen"),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                Spacer(modifier = Modifier.height(4.dp))

                // Security Shield Badge
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(72.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            painter = painterResource(id = R.drawable.security),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }

                Text(
                    text = stringResource(R.string.terms_and_privacy),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = stringResource(R.string.login_terms_description),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp
                )

                // Read full terms & policy link card
                ElevatedCard(
                    onClick = { navController.navigate("settings/terms_privacy") },
                    colors = CardDefaults.elevatedCardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().testTag("view_full_terms_card")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.info),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        Text(
                            text = stringResource(R.string.view_terms_and_privacy_link),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            painter = painterResource(R.drawable.navigate_next),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                HorizontalDivider(
                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                // Agreement Radio Cards
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Option 1: Agree
                    OutlinedCard(
                        onClick = { selectedAgreementOption = true },
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(
                            width = if (selectedAgreementOption == true) 2.dp else 1.dp,
                            color = if (selectedAgreementOption == true) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                        ),
                        colors = CardDefaults.outlinedCardColors(
                            containerColor = if (selectedAgreementOption == true) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surface
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("option_agree_card")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            RadioButton(
                                selected = selectedAgreementOption == true,
                                onClick = { selectedAgreementOption = true }
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = stringResource(R.string.login_terms_agree),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = if (selectedAgreementOption == true) FontWeight.Bold else FontWeight.Normal,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Option 2: Disagree
                    OutlinedCard(
                        onClick = { selectedAgreementOption = false },
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(
                            width = if (selectedAgreementOption == false) 2.dp else 1.dp,
                            color = if (selectedAgreementOption == false) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outlineVariant
                        ),
                        colors = CardDefaults.outlinedCardColors(
                            containerColor = if (selectedAgreementOption == false) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surface
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("option_disagree_card")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            RadioButton(
                                selected = selectedAgreementOption == false,
                                onClick = { selectedAgreementOption = false }
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = stringResource(R.string.login_terms_disagree),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = if (selectedAgreementOption == false) FontWeight.Bold else FontWeight.Normal,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                if (selectedAgreementOption == false) {
                    Text(
                        text = stringResource(R.string.login_must_agree_warning),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Bottom Action Buttons
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = {
                            pendingLogin = null
                            selectedAgreementOption = null
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("terms_back_button"),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.cancel),
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }

                    Button(
                        onClick = {
                            pendingLogin?.let { commitLogin(it) }
                        },
                        enabled = selectedAgreementOption == true,
                        modifier = Modifier
                            .weight(1.6f)
                            .height(52.dp)
                            .testTag("terms_continue_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Text(
                            text = stringResource(R.string.agree_and_continue),
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }
    }
} else {
        // Step 1: Main Login Screen
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = stringResource(R.string.login_title),
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    },
                    navigationIcon = {
                        if (navController.previousBackStackEntry != null && isUserOnboarded) {
                            IconButton(
                                onClick = { navController.navigateUp() },
                                onLongClick = { navController.backToMain() },
                            ) {
                                Icon(
                                    painterResource(R.drawable.arrow_back),
                                    contentDescription = "Quay lại",
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background
                    )
                )
            },
            contentWindowInsets = WindowInsets.systemBars,
            containerColor = MaterialTheme.colorScheme.background
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentAlignment = Alignment.TopCenter
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 600.dp)
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                        .verticalScroll(rememberScrollState())
                        .testTag("login_main_screen"),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                // Hero Card with App Icon and Greeting
                ElevatedCard(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.elevatedCardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                    ),
                    elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth().testTag("login_hero_card")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_launcher_logo),
                                contentDescription = null,
                                contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.login_welcome_title),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = stringResource(R.string.login_welcome_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }

                // Group 1: Login Providers
                Material3SettingsGroup(
                    title = stringResource(R.string.login_methods),
                    items = listOf(
                        // 1. Google Login
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.google),
                            title = { Text(stringResource(R.string.login_google), fontWeight = FontWeight.SemiBold) },
                            description = { Text(stringResource(R.string.login_google_desc)) },
                            trailingContent = {
                                Icon(
                                    painter = painterResource(R.drawable.navigate_next),
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            onClick = { showGoogleWebView = true }
                        ),

                        // 3. Guest Login
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.person),
                            title = { Text(stringResource(R.string.login_guest), fontWeight = FontWeight.SemiBold) },
                            description = { Text(stringResource(R.string.login_guest_desc)) },
                            trailingContent = {
                                Icon(
                                    painter = painterResource(R.drawable.navigate_next),
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            onClick = {
                                pendingLogin = PendingLogin.Custom("Guest", "Khách", "guest@listrovia.com")
                            }
                        )
                    )
                )

                // Group 2: Terms & Policy Preview
                Material3SettingsGroup(
                    title = stringResource(R.string.terms_and_privacy),
                    items = listOf(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.security),
                            title = { Text(stringResource(R.string.view_terms_and_privacy_title), fontWeight = FontWeight.Medium) },
                            description = { Text(stringResource(R.string.view_terms_and_privacy_desc)) },
                            onClick = { navController.navigate("settings/terms_privacy") }
                        )
                    )
                )

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
}

private fun findActivity(context: Context): Activity? {
    var c: Context? = context
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}
