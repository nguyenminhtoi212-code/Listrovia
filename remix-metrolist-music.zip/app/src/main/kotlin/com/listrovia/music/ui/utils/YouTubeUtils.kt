/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

@file:Suppress("LocalVariableName")

package com.listrovia.music.ui.utils

fun String.resize(
    width: Int? = null,
    height: Int? = null,
): String {
    if (width == null && height == null) return this

    // Handle i.ytimg.com upgrade to maxresdefault for large sizes
    if (this.contains("i.ytimg.com/vi/")) {
        if ((width ?: 0) >= 544 || (height ?: 0) >= 544) {
            val names = listOf("hqdefault.jpg", "mqdefault.jpg", "default.jpg", "sddefault.jpg")
            for (name in names) {
                if (this.contains(name)) {
                    return this.replace(name, "maxresdefault.jpg")
                }
            }
        }
        return this
    }

    // Handle Google User Content and Ggpht URLs
    if (this.contains("=") && (this.contains("googleusercontent.com") || this.contains("ggpht.com"))) {
        val parts = this.split("=")
        if (parts.size >= 2) {
            val baseUrl = this.substringBeforeLast("=")
            val params = this.substringAfterLast("=")
            
            // Match wWidth-hHeight pattern
            val whRegex = "^w(\\d+)-h(\\d+)(.*)$".toRegex()
            val whMatch = whRegex.matchEntire(params)
            if (whMatch != null) {
                val W = whMatch.groupValues[1].toInt()
                val H = whMatch.groupValues[2].toInt()
                val suffix = whMatch.groupValues[3]
                
                var w = width
                var h = height
                if (w != null && h == null) h = if (W > 0) (w * H) / W else h
                if (w == null && h != null) w = if (H > 0) (h * W) / H else w
                
                return "$baseUrl=w$w-h$h$suffix"
            }
            
            // Match sSize pattern
            val sRegex = "^s(\\d+)(.*)$".toRegex()
            val sMatch = sRegex.matchEntire(params)
            if (sMatch != null) {
                val suffix = sMatch.groupValues[2]
                if (width != null && height != null) {
                    return "$baseUrl=w$width-h$height-p-l90-rj"
                } else {
                    val size = width ?: height
                    return "$baseUrl=s$size$suffix"
                }
            }
        }
    }

    return this
}
