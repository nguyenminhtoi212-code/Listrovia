/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.listrovia.music.LocalPlayerAwareWindowInsets
import com.listrovia.music.R
import com.listrovia.music.constants.*
import com.listrovia.music.ui.component.DefaultDialog
import com.listrovia.music.ui.component.EnumDialog
import com.listrovia.music.ui.component.IconButton
import com.listrovia.music.ui.component.LyricsCustomizationSheet
import com.listrovia.music.ui.component.Material3SettingsGroup
import com.listrovia.music.ui.component.Material3SettingsItem
import com.listrovia.music.ui.utils.backToMain
import com.listrovia.music.utils.rememberPreference
import com.listrovia.music.utils.rememberEnumPreference
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LyricSettings(
    navController: NavController
) {
    // 1. Sync & Scroll settings
    val (lyricsScroll, onLyricsScrollChange) = rememberPreference(LyricsScrollKey, defaultValue = true)
    val (lyricsClick, onLyricsClickChange) = rememberPreference(LyricsClickKey, defaultValue = true)
    val (enableLyricsQueueTab, onEnableLyricsQueueTabChange) = rememberPreference(EnableLyricsQueueTabKey, defaultValue = false)
    
    // 2. Customizations settings
    val (experimentalLyrics, onExperimentalLyricsChange) = rememberPreference(ExperimentalLyricsKey, defaultValue = true)
    val (lineLanguageDetection, onLineLanguageDetectionChange) = rememberPreference(LineLanguageDetectionKey, defaultValue = false)
    val (lyricsGlowEffect, onLyricsGlowEffectChange) = rememberPreference(LyricsGlowEffectKey, defaultValue = false)
    val (lyricsTextSize, onLyricsTextSizeChange) = rememberPreference(LyricsTextSizeKey, defaultValue = 24f)
    val (lyricsLineSpacing, onLyricsLineSpacingChange) = rememberPreference(LyricsLineSpacingKey, defaultValue = 1.2f)
    
    // 3. Position & Animation
    val (lyricsPosition, onLyricsPositionChange) = rememberEnumPreference(LyricsTextPositionKey, defaultValue = LyricsPosition.CENTER)
    val (lyricsAnimationStyle, onLyricsAnimationStyleChange) = rememberEnumPreference(LyricsAnimationStyleKey, defaultValue = LyricsAnimationStyle.LYRICS_V2_FLUID)

    // 4. AI Translation & Sharing settings
    val (translateLanguage, onTranslateLanguageChange) = rememberPreference(TranslateLanguageKey, defaultValue = "en")
    val (respectAgentPositioning, onRespectAgentPositioningChange) = rememberPreference(RespectAgentPositioningKey, defaultValue = true)
    val (showIntervalIndicator, onShowIntervalIndicatorChange) = rememberPreference(ShowIntervalIndicatorKey, defaultValue = true)

    // Dialog state
    var showLyricsCustomizationSheet by rememberSaveable { mutableStateOf(false) }
    var showLyricsPositionDialog by rememberSaveable { mutableStateOf(false) }
    var showLyricsAnimationStyleDialog by rememberSaveable { mutableStateOf(false) }
    var showLyricsTextSizeDialog by remember { mutableStateOf(false) }
    var showLyricsLineSpacingDialog by remember { mutableStateOf(false) }
    var showLanguageDialog by rememberSaveable { mutableStateOf(false) }

    if (showLanguageDialog) {
        EnumDialog(
            onDismiss = { showLanguageDialog = false },
            onSelect = {
                onTranslateLanguageChange(it)
                showLanguageDialog = false
            },
            title = stringResource(R.string.ai_target_language),
            current = translateLanguage,
            values = LanguageCodeToName.keys.sortedBy { LanguageCodeToName[it] },
            valueText = { LanguageCodeToName[it] ?: it },
        )
    }

    // Dialog for text position
    if (showLyricsPositionDialog) {
        DefaultDialog(
            onDismiss = { showLyricsPositionDialog = false },
            buttons = {
                TextButton(onClick = { showLyricsPositionDialog = false }) {
                    Text(stringResource(android.R.string.cancel))
                }
            }
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.lyrics_text_position),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                LyricsPosition.values().forEach { position ->
                    val name = when (position) {
                        LyricsPosition.LEFT -> stringResource(R.string.left)
                        LyricsPosition.CENTER -> stringResource(R.string.center)
                        LyricsPosition.RIGHT -> stringResource(R.string.right)
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        RadioButton(
                            selected = lyricsPosition == position,
                            onClick = {
                                onLyricsPositionChange(position)
                                showLyricsPositionDialog = false
                            }
                        )
                        Text(
                            text = name,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(start = 16.dp)
                        )
                    }
                }
            }
        }
    }

    // Dialog for animation style
    if (showLyricsAnimationStyleDialog) {
        DefaultDialog(
            onDismiss = { showLyricsAnimationStyleDialog = false },
            buttons = {
                TextButton(onClick = { showLyricsAnimationStyleDialog = false }) {
                    Text(stringResource(android.R.string.cancel))
                }
            }
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.lyrics_animation_style_title),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                LyricsAnimationStyle.values().forEach { style ->
                    val name = when (style) {
                        LyricsAnimationStyle.NONE -> stringResource(R.string.none)
                        LyricsAnimationStyle.FADE -> stringResource(R.string.fade)
                        LyricsAnimationStyle.GLOW -> stringResource(R.string.glow)
                        LyricsAnimationStyle.SLIDE -> stringResource(R.string.slide)
                        LyricsAnimationStyle.KARAOKE -> stringResource(R.string.karaoke)
                        LyricsAnimationStyle.APPLE -> stringResource(R.string.apple_music_style)
                        LyricsAnimationStyle.APPLE_V2 -> stringResource(R.string.lyrics_animation_apple_v2)
                        LyricsAnimationStyle.VIVI_FLUID -> stringResource(R.string.lyrics_animation_vivi_fluid)
                        LyricsAnimationStyle.LYRICS_V2_FLUID -> stringResource(R.string.lyrics_animation_lyrics_v2_fluid)
                        LyricsAnimationStyle.METRO_LYRICS -> stringResource(R.string.lyrics_animation_metro_lyrics)
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        RadioButton(
                            selected = lyricsAnimationStyle == style,
                            onClick = {
                                onLyricsAnimationStyleChange(style)
                                showLyricsAnimationStyleDialog = false
                            }
                        )
                        Text(
                            text = name,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(start = 16.dp)
                        )
                    }
                }
            }
        }
    }

    // Dialog for text size
    if (showLyricsTextSizeDialog) {
        var tempTextSize by remember { mutableFloatStateOf(lyricsTextSize) }
        DefaultDialog(
            onDismiss = { showLyricsTextSizeDialog = false },
            buttons = {
                TextButton(
                    onClick = {
                        tempTextSize = lyricsTextSize
                        showLyricsTextSizeDialog = false
                    }
                ) {
                    Text(stringResource(android.R.string.cancel))
                }
                TextButton(
                    onClick = {
                        onLyricsTextSizeChange(tempTextSize)
                        showLyricsTextSizeDialog = false
                    }
                ) {
                    Text(stringResource(android.R.string.ok))
                }
            }
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(
                    text = stringResource(R.string.lyrics_text_size),
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "${tempTextSize.roundToInt()} sp",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Slider(
                    value = tempTextSize,
                    onValueChange = { tempTextSize = it },
                    valueRange = 16f..36f,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }

    // Dialog for line spacing
    if (showLyricsLineSpacingDialog) {
        var tempLineSpacing by remember { mutableFloatStateOf(lyricsLineSpacing) }
        DefaultDialog(
            onDismiss = { showLyricsLineSpacingDialog = false },
            buttons = {
                TextButton(
                    onClick = {
                        tempLineSpacing = lyricsLineSpacing
                        showLyricsLineSpacingDialog = false
                    }
                ) {
                    Text(stringResource(android.R.string.cancel))
                }
                TextButton(
                    onClick = {
                        onLyricsLineSpacingChange(tempLineSpacing)
                        showLyricsLineSpacingDialog = false
                    }
                ) {
                    Text(stringResource(android.R.string.ok))
                }
            }
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(
                    text = stringResource(R.string.lyrics_line_spacing),
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = String.format(Locale.US, "%.1f", tempLineSpacing),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Slider(
                    value = tempLineSpacing,
                    onValueChange = { tempLineSpacing = it },
                    valueRange = 1.0f..2.0f,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.lyric_settings_title)) },
                navigationIcon = {
                    IconButton(
                        onClick = { navController.backToMain() }
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.arrow_back),
                            contentDescription = stringResource(R.string.back_button_desc)
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            Modifier
                .padding(innerPadding)
                .windowInsetsPadding(
                    LocalPlayerAwareWindowInsets.current.only(
                        WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom,
                    ),
                )
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
        ) {
            // Section 1: Automatic Lyric Sync
            Material3SettingsGroup(
                title = stringResource(R.string.lyric_sync_section),
                items = listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.lyrics),
                        title = { Text(stringResource(R.string.lyric_sync_auto)) },
                        description = { Text(stringResource(R.string.lyric_sync_auto_desc)) },
                        trailingContent = {
                            Switch(
                                checked = lyricsScroll,
                                onCheckedChange = onLyricsScrollChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (lyricsScroll) R.drawable.check else R.drawable.close,
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onLyricsScrollChange(!lyricsScroll) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.lyrics),
                        title = { Text(stringResource(R.string.lyrics_click_change)) },
                        description = { Text(stringResource(R.string.lyrics_click_change_desc)) },
                        trailingContent = {
                            Switch(
                                checked = lyricsClick,
                                onCheckedChange = onLyricsClickChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (lyricsClick) R.drawable.check else R.drawable.close,
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onLyricsClickChange(!lyricsClick) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.queue_music),
                        title = { Text(stringResource(R.string.lyrics_queue_tab_title)) },
                        description = { Text(stringResource(R.string.lyrics_queue_tab_desc)) },
                        trailingContent = {
                            Switch(
                                checked = enableLyricsQueueTab,
                                onCheckedChange = onEnableLyricsQueueTabChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (enableLyricsQueueTab) R.drawable.check else R.drawable.close,
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onEnableLyricsQueueTabChange(!enableLyricsQueueTab) }
                    )
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Section 2: Visual & Customizations
            Material3SettingsGroup(
                title = stringResource(R.string.lyric_appearance_section),
                items = listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.lyrics),
                        title = { Text(stringResource(R.string.experimental_lyrics)) },
                        description = { Text(stringResource(R.string.experimental_lyrics_desc)) },
                        trailingContent = {
                            Switch(
                                checked = experimentalLyrics,
                                onCheckedChange = onExperimentalLyricsChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (experimentalLyrics) R.drawable.check else R.drawable.close,
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onExperimentalLyricsChange(!experimentalLyrics) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.lyrics),
                        title = { Text(stringResource(R.string.lyrics_line_lang_detection_title)) },
                        description = { Text(stringResource(R.string.lyrics_line_lang_detection_desc)) },
                        trailingContent = {
                            Switch(
                                checked = lineLanguageDetection,
                                onCheckedChange = onLineLanguageDetectionChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (lineLanguageDetection) R.drawable.check else R.drawable.close,
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onLineLanguageDetectionChange(!lineLanguageDetection) }
                    ),
                    if (experimentalLyrics) {
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.lyrics),
                            title = { Text(stringResource(R.string.lyrics_glow_effect)) },
                            description = { Text(stringResource(R.string.lyrics_glow_effect_subtext)) },
                            trailingContent = {
                                Switch(
                                    checked = lyricsGlowEffect,
                                    onCheckedChange = onLyricsGlowEffectChange,
                                    thumbContent = {
                                        Icon(
                                            painter = painterResource(
                                                id = if (lyricsGlowEffect) R.drawable.check else R.drawable.close,
                                            ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize),
                                        )
                                    },
                                )
                            },
                            onClick = { onLyricsGlowEffectChange(!lyricsGlowEffect) }
                        )
                    } else {
                        null
                    },
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.lyrics),
                        title = { Text(stringResource(R.string.lyrics_animation_style_title)) },
                        description = {
                            val animName = when (lyricsAnimationStyle) {
                                LyricsAnimationStyle.NONE -> stringResource(R.string.none)
                                LyricsAnimationStyle.FADE -> stringResource(R.string.fade)
                                LyricsAnimationStyle.GLOW -> stringResource(R.string.glow)
                                LyricsAnimationStyle.SLIDE -> stringResource(R.string.slide)
                                LyricsAnimationStyle.KARAOKE -> stringResource(R.string.karaoke)
                                LyricsAnimationStyle.APPLE -> stringResource(R.string.apple_music_style)
                                LyricsAnimationStyle.APPLE_V2 -> stringResource(R.string.lyrics_animation_apple_v2)
                                LyricsAnimationStyle.VIVI_FLUID -> stringResource(R.string.lyrics_animation_vivi_fluid)
                                LyricsAnimationStyle.LYRICS_V2_FLUID -> stringResource(R.string.lyrics_animation_lyrics_v2_fluid)
                                LyricsAnimationStyle.METRO_LYRICS -> stringResource(R.string.lyrics_animation_metro_lyrics)
                            }
                            Text(animName)
                        },
                        onClick = { showLyricsAnimationStyleDialog = true }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.lyrics),
                        title = { Text(stringResource(R.string.lyrics_text_size)) },
                        description = { Text("${lyricsTextSize.roundToInt()} sp") },
                        onClick = { showLyricsTextSizeDialog = true }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.lyrics),
                        title = { Text(stringResource(R.string.lyrics_line_spacing)) },
                        description = { Text("${String.format(Locale.US, "%.1f", lyricsLineSpacing)}x") },
                        onClick = { showLyricsLineSpacingDialog = true }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.tune),
                        title = { Text(stringResource(R.string.lyrics_customization)) },
                        description = { Text(stringResource(R.string.lyrics_customization_desc)) },
                        onClick = { showLyricsCustomizationSheet = true }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.lyrics),
                        title = { Text(stringResource(R.string.lyrics_text_position)) },
                        description = {
                            val posName = when (lyricsPosition) {
                                LyricsPosition.LEFT -> stringResource(R.string.left)
                                LyricsPosition.CENTER -> stringResource(R.string.center)
                                LyricsPosition.RIGHT -> stringResource(R.string.right)
                            }
                            Text(posName)
                        },
                        onClick = { showLyricsPositionDialog = true }
                    )
                ).filterNotNull()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Section 3: AI Translation & Sharing
            Material3SettingsGroup(
                title = stringResource(R.string.ai_lyrics_translation_section),
                items = listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.translate),
                        title = { Text(stringResource(R.string.ai_target_language)) },
                        description = { Text(LanguageCodeToName[translateLanguage] ?: translateLanguage) },
                        onClick = { showLanguageDialog = true }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.lyrics),
                        title = { Text(stringResource(R.string.respect_agent_positioning)) },
                        description = { Text(stringResource(R.string.respect_agent_positioning_desc)) },
                        trailingContent = {
                            Switch(
                                checked = respectAgentPositioning,
                                onCheckedChange = onRespectAgentPositioningChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (respectAgentPositioning) R.drawable.check else R.drawable.close,
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onRespectAgentPositioningChange(!respectAgentPositioning) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.lyrics),
                        title = { Text(stringResource(R.string.show_interval_indicator)) },
                        description = { Text(stringResource(R.string.show_interval_indicator_desc)) },
                        trailingContent = {
                            Switch(
                                checked = showIntervalIndicator,
                                onCheckedChange = onShowIntervalIndicatorChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(
                                            id = if (showIntervalIndicator) R.drawable.check else R.drawable.close,
                                        ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onShowIntervalIndicatorChange(!showIntervalIndicator) }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.share),
                        title = { Text(stringResource(R.string.share_lyrics_feature_title)) },
                        description = { Text(stringResource(R.string.share_lyrics_feature_desc)) },
                        onClick = {}
                    )
                )
            )

            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    if (showLyricsCustomizationSheet) {
        LyricsCustomizationSheet(
            onDismissRequest = { showLyricsCustomizationSheet = false }
        )
    }
}
