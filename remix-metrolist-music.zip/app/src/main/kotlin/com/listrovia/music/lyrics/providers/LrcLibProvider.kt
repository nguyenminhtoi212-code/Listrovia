/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.lyrics.providers

import android.content.Context
import com.listrovia.music.constants.EnableLrcLibKey
import com.listrovia.music.lyrics.LyricsProvider
import com.listrovia.music.utils.dataStore
import com.listrovia.music.utils.get
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.defaultRequest
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.parameter
import io.ktor.http.HttpStatusCode
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import timber.log.Timber
import kotlin.math.abs

@Serializable
data class LrcLibTrack(
    val id: Long = 0,
    val trackName: String = "",
    val artistName: String = "",
    val albumName: String? = null,
    val duration: Double = 0.0,
    val plainLyrics: String? = null,
    val syncedLyrics: String? = null,
    val instrumental: Boolean = false,
) {
    val bestLyrics: String?
        get() = syncedLyrics?.takeIf { it.isNotBlank() } ?: plainLyrics?.takeIf { it.isNotBlank() }
}

/**
 * LrcLib Lyrics Engine
 */
object LrcLib {
    private const val TAG = "LrcLib"

    private val client by lazy {
        HttpClient(OkHttp) {
            install(ContentNegotiation) {
                json(
                    Json {
                        isLenient = true
                        ignoreUnknownKeys = true
                        encodeDefaults = true
                    },
                )
            }
            install(HttpTimeout) {
                requestTimeoutMillis = 15000
                connectTimeoutMillis = 10000
            }
            defaultRequest {
                url("https://lrclib.net")
                header("User-Agent", "Listrovia/Lyrics")
            }
            expectSuccess = false
        }
    }

    private val titleCleanupPatterns = listOf(
        Regex("""\s*\(.*?(official|video|audio|lyrics|lyric|visualizer|hd|hq|4k|remaster|remix|live|acoustic|version|edit|extended|radio|clean|explicit).*?\)""", RegexOption.IGNORE_CASE),
        Regex("""\s*\[.*?(official|video|audio|lyrics|lyric|visualizer|hd|hq|4k|remaster|remix|live|acoustic|version|edit|extended|radio|clean|explicit).*?\]""", RegexOption.IGNORE_CASE),
        Regex("""\s*【.*?】"""),
        Regex("""\s*\|.*$"""),
        Regex("""\s*-\s*(official|video|audio|lyrics|lyric|visualizer).*$""", RegexOption.IGNORE_CASE),
        Regex("""\s*\(feat\..*?\)""", RegexOption.IGNORE_CASE),
        Regex("""\s*\(ft\..*?\)""", RegexOption.IGNORE_CASE),
        Regex("""\s*feat\..*$""", RegexOption.IGNORE_CASE),
        Regex("""\s*ft\..*$""", RegexOption.IGNORE_CASE),
    )

    private val artistSeparators = listOf(" & ", " and ", ", ", " x ", " X ", " feat. ", " feat ", " ft. ", " ft ", " featuring ", " with ")

    private fun cleanTitle(title: String): String {
        var cleaned = title.trim()
        for (pattern in titleCleanupPatterns) {
            cleaned = cleaned.replace(pattern, "")
        }
        return cleaned.trim()
    }

    private fun cleanArtist(artist: String): String {
        var cleaned = artist.trim()
        for (separator in artistSeparators) {
            if (cleaned.contains(separator, ignoreCase = true)) {
                cleaned = cleaned.split(separator, ignoreCase = true, limit = 2)[0]
                break
            }
        }
        return cleaned.trim()
    }

    private suspend fun querySearch(
        trackName: String? = null,
        artistName: String? = null,
        albumName: String? = null,
        query: String? = null,
    ): List<LrcLibTrack> = runCatching {
        val response = client.get("/api/search") {
            if (!query.isNullOrBlank()) parameter("q", query)
            if (!trackName.isNullOrBlank()) parameter("track_name", trackName)
            if (!artistName.isNullOrBlank()) parameter("artist_name", artistName)
            if (!albumName.isNullOrBlank()) parameter("album_name", albumName)
        }
        if (response.status == HttpStatusCode.OK) {
            response.body<List<LrcLibTrack>>()
        } else {
            emptyList()
        }
    }.getOrDefault(emptyList())

    suspend fun getLyrics(
        title: String,
        artist: String,
        duration: Int,
        album: String? = null,
    ): Result<String> = runCatching {
        val cleanedTitle = cleanTitle(title)
        val cleanedArtist = cleanArtist(artist)

        var tracks = querySearch(trackName = cleanedTitle, artistName = cleanedArtist, albumName = album)
        if (tracks.isEmpty()) {
            tracks = querySearch(query = "$cleanedTitle $cleanedArtist")
        }
        if (tracks.isEmpty() && (cleanedTitle != title || cleanedArtist != artist)) {
            tracks = querySearch(query = "$title $artist")
        }

        val nonInstrumental = tracks.filterNot { it.instrumental }
        val matched = findBestTrack(nonInstrumental, duration)
            ?: throw IllegalStateException("No matching lyrics found on LrcLib for $title")

        matched.bestLyrics ?: throw IllegalStateException("Track matched on LrcLib has no lyrics")
    }

    suspend fun getAllLyrics(
        title: String,
        artist: String,
        duration: Int,
        album: String? = null,
        callback: (String) -> Unit,
    ) {
        try {
            val cleanedTitle = cleanTitle(title)
            val cleanedArtist = cleanArtist(artist)

            val tracks = querySearch(query = "$cleanedTitle $cleanedArtist")
            tracks.filterNot { it.instrumental }.forEach { track ->
                if (duration == -1 || abs(track.duration.toInt() - duration) <= 5) {
                    track.bestLyrics?.let(callback)
                }
            }
        } catch (e: Exception) {
            Timber.tag(TAG).w(e, "Error fetching all lyrics from LrcLib")
        }
    }

    private fun findBestTrack(tracks: List<LrcLibTrack>, duration: Int): LrcLibTrack? {
        if (tracks.isEmpty()) return null
        if (duration == -1) {
            return tracks.firstOrNull { it.syncedLyrics != null } ?: tracks.firstOrNull()
        }

        // 1. Strict ±2s tolerance with synced lyrics
        val strictSynced = tracks.filter { it.syncedLyrics != null }
            .minByOrNull { abs(it.duration.toInt() - duration) }
            ?.takeIf { abs(it.duration.toInt() - duration) <= 2 }
        if (strictSynced != null) return strictSynced

        // 2. Relaxed ±5s tolerance with synced lyrics
        val relaxedSynced = tracks.filter { it.syncedLyrics != null }
            .minByOrNull { abs(it.duration.toInt() - duration) }
            ?.takeIf { abs(it.duration.toInt() - duration) <= 5 }
        if (relaxedSynced != null) return relaxedSynced

        // 3. Any lyrics within ±5s tolerance
        return tracks.minByOrNull { abs(it.duration.toInt() - duration) }
            ?.takeIf { abs(it.duration.toInt() - duration) <= 5 }
    }
}

/**
 * LrcLib Lyrics Provider
 */
object LrcLibLyricsProvider : LyricsProvider {
    override val name = "LrcLib"

    override fun isEnabled(context: Context): Boolean =
        context.dataStore[EnableLrcLibKey] ?: true

    override suspend fun getLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): Result<String> = LrcLib.getLyrics(title, artist, duration, album)

    override suspend fun getAllLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
        callback: (String) -> Unit,
    ) {
        LrcLib.getAllLyrics(title, artist, duration, album, callback)
    }
}
