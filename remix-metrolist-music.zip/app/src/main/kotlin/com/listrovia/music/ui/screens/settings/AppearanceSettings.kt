/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.screens.settings

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.only
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.edit
import androidx.navigation.NavController
import com.listrovia.music.LocalPlayerAwareWindowInsets
import com.listrovia.music.R
import com.listrovia.music.constants.ChipSortTypeKey
import com.listrovia.music.constants.CropAlbumArtKey
import com.listrovia.music.constants.ShowArtistCanvasVideoKey
import com.listrovia.music.constants.ShowArtistBackgroundVideoKey
import com.listrovia.music.constants.ShowAlbumCanvasKey
import com.listrovia.music.constants.DefaultOpenTabKey
import com.listrovia.music.constants.DensityScale
import com.listrovia.music.constants.DensityScaleKey
import com.listrovia.music.constants.DarkModeKey
import com.listrovia.music.constants.DynamicThemeKey
import com.listrovia.music.constants.EnableDynamicIconKey
import com.listrovia.music.constants.BlurStandardLyricsKey
import com.listrovia.music.constants.EnableHighRefreshRateKey
import com.listrovia.music.constants.EnableLandscapeScalingKey
import com.listrovia.music.constants.EnableHapticsKey
import com.listrovia.music.constants.HapticsPlaybackControlsKey
import com.listrovia.music.constants.HapticsSeekbarKey
import com.listrovia.music.constants.HapticsButtonsKey
import com.listrovia.music.constants.ExperimentalLyricsKey
import com.listrovia.music.constants.GridItemSize
import com.listrovia.music.constants.GridItemsSizeKey
import com.listrovia.music.constants.HidePlayerThumbnailKey
import com.listrovia.music.constants.HideStatusBarOnFullscreenKey
import com.listrovia.music.constants.LibraryFilter
import com.listrovia.music.constants.ListenTogetherInTopBarKey
import com.listrovia.music.constants.LyricsAnimationStyle
import com.listrovia.music.constants.LyricsAnimationStyleKey
import com.listrovia.music.constants.LyricsClickKey
import com.listrovia.music.constants.LyricsGlowEffectKey
import com.listrovia.music.constants.LyricsLineSpacingKey
import com.listrovia.music.constants.LyricsScrollKey
import com.listrovia.music.constants.LyricsTextPositionKey
import com.listrovia.music.constants.LyricsTextSizeKey
import com.listrovia.music.constants.MiniPlayerBackgroundStyle
import com.listrovia.music.constants.MiniPlayerBackgroundStyleKey
import com.listrovia.music.constants.PlayerBackgroundStyle
import com.listrovia.music.constants.PlayerBackgroundStyleKey
import com.listrovia.music.constants.PlayerButtonsStyle
import com.listrovia.music.constants.PlayerButtonsStyleKey
import com.listrovia.music.constants.PureBlackMiniPlayerKey
import com.listrovia.music.constants.PureBlackKey
import com.listrovia.music.constants.RespectAgentPositioningKey
import com.listrovia.music.constants.SelectedThemeColorKey
import com.listrovia.music.ui.components.CustomColorPickerDialog
import com.listrovia.music.constants.AppFontBoldnessKey
import com.listrovia.music.constants.AppFontKey
import com.listrovia.music.constants.AppFontSizeKey
import com.listrovia.music.constants.ConnectedLinesKey
import com.listrovia.music.constants.LyricsFontKey
import com.listrovia.music.constants.ShowIntervalIndicatorKey
import com.listrovia.music.constants.ShowCachedPlaylistKey
import com.listrovia.music.constants.ShowDownloadedPlaylistKey
import com.listrovia.music.constants.ShowLikedPlaylistKey
import com.listrovia.music.ui.theme.AppFont
import com.listrovia.music.constants.ShowSplashScreenKey
import com.listrovia.music.constants.UseLauncherIconOnSplashKey
import com.listrovia.music.constants.ShowTopPlaylistKey
import com.listrovia.music.constants.ShowUploadedPlaylistKey
import com.listrovia.music.constants.EnableLiquidGlassKey
import com.listrovia.music.constants.GlassSaturationKey
import com.listrovia.music.constants.GlassBlurRadiusKey
import com.listrovia.music.constants.LensRefractionHeightKey
import com.listrovia.music.constants.LensRefractionAmountKey
import com.listrovia.music.constants.ChromaticAberrationKey
import com.listrovia.music.constants.DepthEffectKey
import com.listrovia.music.constants.SurfaceTintColorHexKey
import com.listrovia.music.constants.SurfaceOpacityKey
import com.listrovia.music.constants.GlassTextColorHexKey
import com.listrovia.music.constants.GlassPlayerKey
import com.listrovia.music.constants.GlassMiniPlayerKey
import com.listrovia.music.constants.GlassNavBarKey
import com.listrovia.music.constants.FloatingNavBarKey
import com.listrovia.music.constants.SliderStyle
import com.listrovia.music.constants.SliderStyleKey

import com.listrovia.music.constants.SlimNavBarKey
import com.listrovia.music.constants.SquigglySliderKey
import com.listrovia.music.constants.SwipeSensitivityKey
import com.listrovia.music.constants.SwipeThumbnailKey
import com.listrovia.music.constants.SwipeToRemoveSongKey
import com.listrovia.music.constants.SwipeToSongKey
import com.listrovia.music.constants.UseNewMiniPlayerDesignKey
import com.listrovia.music.constants.UseNewPlayerDesignKey
import com.listrovia.music.constants.EnableRotatingThumbnailKey
import com.listrovia.music.constants.ShowCommentButtonKey
import com.listrovia.music.constants.ShowCodecOnPlayerKey
import com.listrovia.music.constants.ThumbnailCornerRadiusKey
import com.listrovia.music.ui.component.DefaultDialog
import com.listrovia.music.ui.component.EnumDialog
import com.listrovia.music.ui.component.IconButton
import com.listrovia.music.ui.component.Material3SettingsGroup
import com.listrovia.music.ui.component.Material3SettingsItem
import com.listrovia.music.ui.component.PlayerSliderTrack
import com.listrovia.music.ui.component.SquigglySlider
import com.listrovia.music.ui.component.WavySlider
import com.listrovia.music.ui.theme.DefaultThemeColor
import com.listrovia.music.ui.theme.PlayerSliderColors
import com.listrovia.music.ui.utils.backToMain
import com.listrovia.music.utils.IconUtils
import com.listrovia.music.utils.rememberEnumPreference
import com.listrovia.music.utils.rememberPreference
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppearanceSettings(
    navController: NavController,
    activity: Activity,
    snackbarHostState: SnackbarHostState,
) {
    val (darkMode, onDarkModeChange) =
        rememberEnumPreference(
            DarkModeKey,
            defaultValue = DarkMode.AUTO,
        )
    val (dynamicTheme, onDynamicThemeChange) =
        rememberPreference(
            DynamicThemeKey,
            defaultValue = true,
        )
    val (pureBlack, onPureBlackChange) =
        rememberPreference(
            PureBlackKey,
            defaultValue = false,
        )
    val (enableDynamicIcon, onEnableDynamicIconPrefChange) =
        rememberPreference(
            EnableDynamicIconKey,
            defaultValue = true,
        )
    val iconContext = LocalContext.current
    val onEnableDynamicIconChange: (Boolean) -> Unit = { newValue ->
        onEnableDynamicIconPrefChange(newValue)
        IconUtils.setIcon(iconContext, newValue)
    }
    val (enableHighRefreshRate, onEnableHighRefreshRateChange) =
        rememberPreference(
            EnableHighRefreshRateKey,
            defaultValue = true,
        )
    val (enableLandscapeScaling, onEnableLandscapeScalingChange) =
        rememberPreference(
            EnableLandscapeScalingKey,
            defaultValue = false,
        )
    val (selectedThemeColorInt, onSelectedThemeColorChange) =
        rememberPreference(
            SelectedThemeColorKey,
            defaultValue = DefaultThemeColor.toArgb(),
        )
    // Check if user has selected a custom color (not the default/dynamic color)
    val isUsingCustomColor = selectedThemeColorInt != DefaultThemeColor.toArgb()
    var showCustomPrimaryColorDialog by rememberSaveable { mutableStateOf(false) }

    val (useNewPlayerDesign, onUseNewPlayerDesignChange) =
        rememberPreference(
            UseNewPlayerDesignKey,
            defaultValue = true,
        )
    val (miniPlayerBackground, onMiniPlayerBackgroundChange) =
        rememberEnumPreference(
            MiniPlayerBackgroundStyleKey,
            defaultValue = MiniPlayerBackgroundStyle.DEFAULT,
        )

    val availableMiniPlayerBackgroundStyles =
        MiniPlayerBackgroundStyle.entries.filter {
            it != MiniPlayerBackgroundStyle.BLUR || Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
        }

    var showMiniPlayerBackgroundDialog by rememberSaveable { mutableStateOf(false) }

    val (useNewMiniPlayerDesign, onUseNewMiniPlayerDesignChange) =
        rememberPreference(
            UseNewMiniPlayerDesignKey,
            defaultValue = true,
        )
    val (hidePlayerThumbnail, onHidePlayerThumbnailChange) =
        rememberPreference(
            HidePlayerThumbnailKey,
            defaultValue = false,
        )
    val (cropAlbumArt, onCropAlbumArtChange) =
        rememberPreference(
            CropAlbumArtKey,
            defaultValue = false,
        )
    val (showArtistCanvasVideo, onShowArtistCanvasVideoChange) =
        rememberPreference(
            ShowArtistCanvasVideoKey,
            defaultValue = true,
        )
    val (showArtistBackgroundVideo, onShowArtistBackgroundVideoChange) =
        rememberPreference(
            ShowArtistBackgroundVideoKey,
            defaultValue = true,
        )
    val (showAlbumCanvas, onShowAlbumCanvasChange) =
        rememberPreference(
            ShowAlbumCanvasKey,
            defaultValue = true,
        )
    val (enableRotatingThumbnail, onEnableRotatingThumbnailChange) =
        rememberPreference(
            EnableRotatingThumbnailKey,
            defaultValue = false,
        )
    val (showCommentButton, onShowCommentButtonChange) =
        rememberPreference(
            ShowCommentButtonKey,
            defaultValue = false,
        )
    val (showCodecOnPlayer, onShowCodecOnPlayerChange) =
        rememberPreference(
            ShowCodecOnPlayerKey,
            defaultValue = false,
        )
    val (thumbnailCornerRadius, onThumbnailCornerRadiusChange) =
        rememberPreference(
            ThumbnailCornerRadiusKey,
            defaultValue = 12f,
        )

    val (playerBackground, onPlayerBackgroundChange) =
        rememberEnumPreference(
            PlayerBackgroundStyleKey,
            defaultValue = PlayerBackgroundStyle.DEFAULT,
        )

    val (defaultOpenTab, onDefaultOpenTabChange) =
        rememberEnumPreference(
            DefaultOpenTabKey,
            defaultValue = NavigationTab.LIBRARY,
        )
    val (playerButtonsStyle, onPlayerButtonsStyleChange) =
        rememberEnumPreference(
            PlayerButtonsStyleKey,
            defaultValue = PlayerButtonsStyle.DEFAULT,
        )
    val (lyricsPosition, onLyricsPositionChange) =
        rememberEnumPreference(
            LyricsTextPositionKey,
            defaultValue = LyricsPosition.CENTER,
        )
    val (lyricsClick, onLyricsClickChange) = rememberPreference(LyricsClickKey, defaultValue = true)
    val (lyricsScroll, onLyricsScrollChange) =
        rememberPreference(
            LyricsScrollKey,
            defaultValue = true,
        )
    val (hideStatusBarOnFullscreen, onHideStatusBarOnFullscreenChange) =
        rememberPreference(
            HideStatusBarOnFullscreenKey,
            defaultValue = false,
        )
    val (respectAgentPositioning, onRespectAgentPositioningChange) = rememberPreference(RespectAgentPositioningKey, defaultValue = true)
    val (experimentalLyrics, onExperimentalLyricsChange) = rememberPreference(ExperimentalLyricsKey, defaultValue = true)

    val (lyricsGlowEffect, onLyricsGlowEffectChange) = rememberPreference(LyricsGlowEffectKey, defaultValue = false)
    val (blurStandardLyrics, onBlurStandardLyricsChange) = rememberPreference(BlurStandardLyricsKey, defaultValue = true)
    val (lyricsAnimationStyle, onLyricsAnimationStyleChange) =
        rememberEnumPreference(
            LyricsAnimationStyleKey,
            defaultValue = LyricsAnimationStyle.LYRICS_V2_FLUID,
        )
    val (lyricsTextSize, onLyricsTextSizeChange) = rememberPreference(LyricsTextSizeKey, defaultValue = 24f)
    val (lyricsLineSpacing, onLyricsLineSpacingChange) = rememberPreference(LyricsLineSpacingKey, defaultValue = 1.2f)
    val (connectedLines, onConnectedLinesChange) = rememberPreference(ConnectedLinesKey, defaultValue = true)
    val (lyricsFont, onLyricsFontChange) = rememberPreference(LyricsFontKey, defaultValue = "SYSTEM")
    val (showIntervalIndicator, onShowIntervalIndicatorChange) = rememberPreference(ShowIntervalIndicatorKey, defaultValue = true)

    val (appFont, onAppFontChange) = rememberPreference(AppFontKey, defaultValue = "SYSTEM")
    val (appFontSize, onAppFontSizeChange) = rememberPreference(AppFontSizeKey, defaultValue = 100)
    val (appFontBoldness, onAppFontBoldnessChange) = rememberPreference(AppFontBoldnessKey, defaultValue = 0)

    var showLyricsAnimationStyleDialog by remember { mutableStateOf(false) }
    var showLyricsTextSizeDialog by remember { mutableStateOf(false) }
    var showLyricsLineSpacingDialog by remember { mutableStateOf(false) }
    var showLyricsFontDialog by rememberSaveable { mutableStateOf(false) }
    var showAppFontDialog by rememberSaveable { mutableStateOf(false) }
    var showAppFontSizeDialog by rememberSaveable { mutableStateOf(false) }
    var showAppFontBoldnessDialog by rememberSaveable { mutableStateOf(false) }

    val (sliderStyle, onSliderStyleChange) =
        rememberEnumPreference(
            SliderStyleKey,
            defaultValue = SliderStyle.DEFAULT,
        )
    val (squigglySlider, onSquigglySliderChange) =
        rememberPreference(
            SquigglySliderKey,
            defaultValue = false,
        )
    val (swipeThumbnail, onSwipeThumbnailChange) =
        rememberPreference(
            SwipeThumbnailKey,
            defaultValue = true,
        )
    val (swipeSensitivity, onSwipeSensitivityChange) =
        rememberPreference(
            SwipeSensitivityKey,
            defaultValue = 0.73f,
        )
    val (gridItemSize, onGridItemSizeChange) =
        rememberEnumPreference(
            GridItemsSizeKey,
            defaultValue = GridItemSize.SMALL,
        )

    val (slimNav, onSlimNavChange) =
        rememberPreference(
            SlimNavBarKey,
            defaultValue = false,
        )

    val (floatingNavBar, onFloatingNavBarChange) = rememberPreference(FloatingNavBarKey, defaultValue = true)
    val (enableLiquidGlass, onEnableLiquidGlassChange) = rememberPreference(EnableLiquidGlassKey, defaultValue = true)
    val (glassSaturation, onGlassSaturationChange) = rememberPreference(GlassSaturationKey, defaultValue = 1.3f)
    val (glassBlurRadius, onGlassBlurRadiusChange) = rememberPreference(GlassBlurRadiusKey, defaultValue = 24f)
    val (lensRefractionHeight, onLensRefractionHeightChange) = rememberPreference(LensRefractionHeightKey, defaultValue = 14f)
    val (lensRefractionAmount, onLensRefractionAmountChange) = rememberPreference(LensRefractionAmountKey, defaultValue = 0.85f)
    val (chromaticAberration, onChromaticAberrationChange) = rememberPreference(ChromaticAberrationKey, defaultValue = 0.45f)
    val (depthEffect, onDepthEffectChange) = rememberPreference(DepthEffectKey, defaultValue = 0.75f)
    val (surfaceOpacity, onSurfaceOpacityChange) = rememberPreference(SurfaceOpacityKey, defaultValue = 1.0f)
    val (glassPlayer, onGlassPlayerChange) = rememberPreference(GlassPlayerKey, defaultValue = true)
    val (glassMiniPlayer, onGlassMiniPlayerChange) = rememberPreference(GlassMiniPlayerKey, defaultValue = true)
    val (glassNavBar, onGlassNavBarChange) = rememberPreference(GlassNavBarKey, defaultValue = true)

    var showGlassSaturationDialog by remember { mutableStateOf(false) }
    var showGlassBlurRadiusDialog by remember { mutableStateOf(false) }
    var showLensRefractionHeightDialog by remember { mutableStateOf(false) }
    var showLensRefractionAmountDialog by remember { mutableStateOf(false) }
    var showChromaticAberrationDialog by remember { mutableStateOf(false) }
    var showDepthEffectDialog by remember { mutableStateOf(false) }
    var showSurfaceOpacityDialog by remember { mutableStateOf(false) }


    // Density scale preferences
    val context = activity as Context
    val sharedPreferences = remember { context.getSharedPreferences("listrovia_settings", Context.MODE_PRIVATE) }
    val prefDensityScale =
        remember(sharedPreferences) {
            sharedPreferences.getFloat("density_scale_factor", 1.0f)
        }
    val (densityScale, setDensityScale) = rememberPreference(DensityScaleKey, defaultValue = prefDensityScale)
    var showRestartDialog by rememberSaveable { mutableStateOf(false) }
    var showDensityScaleDialog by rememberSaveable { mutableStateOf(false) }

    val onDensityScaleChange: (Float) -> Unit = { newScale ->
        setDensityScale(newScale)
        // Write to SharedPreferences for DensityScaler to read on next startup
        sharedPreferences.edit {
            putFloat("density_scale_factor", newScale)
        }
        showRestartDialog = true
    }

    val (listenTogetherInTopBar, onListenTogetherInTopBarChange) =
        rememberPreference(
            ListenTogetherInTopBarKey,
            defaultValue = true,
        )

    val (enableHaptics, onEnableHapticsChange) =
        rememberPreference(
            EnableHapticsKey,
            defaultValue = true,
        )

    val (hapticsPlaybackControls, onHapticsPlaybackControlsChange) =
        rememberPreference(
            HapticsPlaybackControlsKey,
            defaultValue = true,
        )

    val (hapticsSeekbar, onHapticsSeekbarChange) =
        rememberPreference(
            HapticsSeekbarKey,
            defaultValue = true,
        )

    val (hapticsButtons, onHapticsButtonsChange) =
        rememberPreference(
            HapticsButtonsKey,
            defaultValue = true,
        )

    val (swipeToSong, onSwipeToSongChange) =
        rememberPreference(
            SwipeToSongKey,
            defaultValue = false,
        )

    val (swipeToRemoveSong, onSwipeToRemoveSongChange) =
        rememberPreference(
            SwipeToRemoveSongKey,
            defaultValue = false,
        )

    val (showLikedPlaylist, onShowLikedPlaylistChange) =
        rememberPreference(
            ShowLikedPlaylistKey,
            defaultValue = true,
        )
    val (showDownloadedPlaylist, onShowDownloadedPlaylistChange) =
        rememberPreference(
            ShowDownloadedPlaylistKey,
            defaultValue = true,
        )
    val (showTopPlaylist, onShowTopPlaylistChange) =
        rememberPreference(
            ShowTopPlaylistKey,
            defaultValue = true,
        )
    val (showCachedPlaylist, onShowCachedPlaylistChange) =
        rememberPreference(
            ShowCachedPlaylistKey,
            defaultValue = true,
        )
    val (showUploadedPlaylist, onShowUploadedPlaylistChange) =
        rememberPreference(
            ShowUploadedPlaylistKey,
            defaultValue = true,
        )
    val (showSplashScreen, onShowSplashScreenChange) =
        rememberPreference(
            ShowSplashScreenKey,
            defaultValue = true,
        )
    val (useLauncherIconOnSplash, onUseLauncherIconOnSplashChange) =
        rememberPreference(
            UseLauncherIconOnSplashKey,
            defaultValue = true,
        )

    val availableBackgroundStyles =
        PlayerBackgroundStyle.entries.filter {
            it != PlayerBackgroundStyle.BLUR || Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
        }

    val (defaultChip, onDefaultChipChange) =
        rememberEnumPreference(
            key = ChipSortTypeKey,
            defaultValue = LibraryFilter.LIBRARY,
        )

    var showSliderOptionDialog by rememberSaveable {
        mutableStateOf(false)
    }

    var showPlayerBackgroundDialog by rememberSaveable {
        mutableStateOf(false)
    }

    var showPlayerButtonsStyleDialog by rememberSaveable {
        mutableStateOf(false)
    }

    var showLyricsPositionDialog by rememberSaveable {
        mutableStateOf(false)
    }

    if (showLyricsPositionDialog) {
        EnumDialog(
            onDismiss = { showLyricsPositionDialog = false },
            onSelect = {
                onLyricsPositionChange(it)
                showLyricsPositionDialog = false
            },
            title = stringResource(R.string.lyrics_text_position),
            current = lyricsPosition,
            values = LyricsPosition.values().toList(),
            valueText = {
                when (it) {
                    LyricsPosition.LEFT -> stringResource(R.string.left)
                    LyricsPosition.CENTER -> stringResource(R.string.center)
                    LyricsPosition.RIGHT -> stringResource(R.string.right)
                }
            },
        )
    }

    if (showLyricsAnimationStyleDialog) {
        EnumDialog(
            onDismiss = { showLyricsAnimationStyleDialog = false },
            onSelect = {
                onLyricsAnimationStyleChange(it)
                showLyricsAnimationStyleDialog = false
            },
            title = stringResource(R.string.lyrics_animation_style_title),
            current = lyricsAnimationStyle,
            values = LyricsAnimationStyle.values().toList(),
            valueText = {
                when (it) {
                    LyricsAnimationStyle.NONE -> stringResource(R.string.none)
                    LyricsAnimationStyle.FADE -> stringResource(R.string.fade)
                    LyricsAnimationStyle.GLOW -> stringResource(R.string.glow)
                    LyricsAnimationStyle.SLIDE -> stringResource(R.string.slide)
                    LyricsAnimationStyle.KARAOKE -> stringResource(R.string.karaoke)
                    LyricsAnimationStyle.APPLE -> stringResource(R.string.apple_music_style)
                    LyricsAnimationStyle.APPLE_V2 -> stringResource(R.string.lyrics_animation_apple_v2)
                    LyricsAnimationStyle.VIVI_FLUID -> stringResource(R.string.lyrics_animation_vivi_fluid)
                    LyricsAnimationStyle.LYRICS_V2_FLUID -> stringResource(R.string.lyrics_animation_lyrics_v2_fluid)
                    LyricsAnimationStyle.METRO_LYRICS -> stringResource(R.string.lyrics_animation_metro_lyrics)
                }
            },
        )
    }

    if (showLyricsTextSizeDialog) {
        var tempTextSize by remember { mutableFloatStateOf(lyricsTextSize) }

        DefaultDialog(
            onDismiss = {
                tempTextSize = lyricsTextSize
                showLyricsTextSizeDialog = false
            },
            buttons = {
                TextButton(
                    onClick = {
                        tempTextSize = 24f
                    },
                ) {
                    Text(stringResource(R.string.reset))
                }

                Spacer(modifier = Modifier.weight(1f))

                TextButton(
                    onClick = {
                        tempTextSize = lyricsTextSize
                        showLyricsTextSizeDialog = false
                    },
                ) {
                    Text(stringResource(android.R.string.cancel))
                }
                TextButton(
                    onClick = {
                        onLyricsTextSizeChange(tempTextSize)
                        showLyricsTextSizeDialog = false
                    },
                ) {
                    Text(stringResource(android.R.string.ok))
                }
            },
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(16.dp),
            ) {
                Text(
                    text = stringResource(R.string.lyrics_text_size),
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.padding(bottom = 16.dp),
                )

                Text(
                    text = "${tempTextSize.roundToInt()} sp",
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(bottom = 16.dp),
                )

                Slider(
                    value = tempTextSize,
                    onValueChange = { tempTextSize = it },
                    valueRange = 12f..48f,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }

    if (showLyricsLineSpacingDialog) {
        var tempLineSpacing by remember { mutableFloatStateOf(lyricsLineSpacing) }

        DefaultDialog(
            onDismiss = {
                tempLineSpacing = lyricsLineSpacing
                showLyricsLineSpacingDialog = false
            },
            buttons = {
                TextButton(
                    onClick = {
                        tempLineSpacing = 1.3f
                    },
                ) {
                    Text(stringResource(R.string.reset))
                }

                Spacer(modifier = Modifier.weight(1f))

                TextButton(
                    onClick = {
                        tempLineSpacing = lyricsLineSpacing
                        showLyricsLineSpacingDialog = false
                    },
                ) {
                    Text(stringResource(android.R.string.cancel))
                }
                TextButton(
                    onClick = {
                        onLyricsLineSpacingChange(tempLineSpacing)
                        showLyricsLineSpacingDialog = false
                    },
                ) {
                    Text(stringResource(android.R.string.ok))
                }
            },
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(16.dp),
            ) {
                Text(
                    text = stringResource(R.string.lyrics_line_spacing),
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.padding(bottom = 16.dp),
                )

                Text(
                    text = String.format(Locale.US, "%.1f", tempLineSpacing),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(bottom = 16.dp),
                )

                Slider(
                    value = tempLineSpacing,
                    onValueChange = { tempLineSpacing = it },
                    valueRange = 1.0f..3.0f,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }

    if (showAppFontDialog) {
        DefaultDialog(
            onDismiss = { showAppFontDialog = false },
            buttons = {
                TextButton(onClick = { showAppFontDialog = false }) {
                    Text(stringResource(android.R.string.cancel))
                }
            }
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.app_font_title),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                AppFont.entries.forEach { fontOption ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .clickable {
                                onAppFontChange(fontOption.id)
                                showAppFontDialog = false
                            }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = appFont == fontOption.id,
                            onClick = {
                                onAppFontChange(fontOption.id)
                                showAppFontDialog = false
                            }
                        )
                        Text(
                            text = stringResource(fontOption.displayNameRes),
                            style = MaterialTheme.typography.bodyMedium.copy(fontFamily = fontOption.toFontFamily()),
                            modifier = Modifier.padding(start = 16.dp)
                        )
                    }
                }
            }
        }
    }

    if (showAppFontSizeDialog) {
        var tempSize by remember { mutableFloatStateOf(appFontSize.toFloat()) }
        DefaultDialog(
            onDismiss = { showAppFontSizeDialog = false },
            buttons = {
                TextButton(onClick = {
                    onAppFontSizeChange(100)
                    showAppFontSizeDialog = false
                }) {
                    Text(stringResource(R.string.reset))
                }
                Spacer(modifier = Modifier.weight(1f))
                TextButton(onClick = { showAppFontSizeDialog = false }) {
                    Text(stringResource(android.R.string.cancel))
                }
                TextButton(onClick = {
                    onAppFontSizeChange(tempSize.roundToInt())
                    showAppFontSizeDialog = false
                }) {
                    Text(stringResource(android.R.string.ok))
                }
            }
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = stringResource(R.string.font_size_title),
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                Text(
                    text = "${tempSize.roundToInt()}%",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                Slider(
                    value = tempSize,
                    onValueChange = { tempSize = ((it / 5f).roundToInt() * 5).toFloat() },
                    valueRange = 75f..150f,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }

    if (showAppFontBoldnessDialog) {
        var tempBoldness by remember { mutableFloatStateOf(appFontBoldness.toFloat()) }
        DefaultDialog(
            onDismiss = { showAppFontBoldnessDialog = false },
            buttons = {
                TextButton(onClick = {
                    onAppFontBoldnessChange(0)
                    showAppFontBoldnessDialog = false
                }) {
                    Text(stringResource(R.string.reset))
                }
                Spacer(modifier = Modifier.weight(1f))
                TextButton(onClick = { showAppFontBoldnessDialog = false }) {
                    Text(stringResource(android.R.string.cancel))
                }
                TextButton(onClick = {
                    onAppFontBoldnessChange(tempBoldness.roundToInt())
                    showAppFontBoldnessDialog = false
                }) {
                    Text(stringResource(android.R.string.ok))
                }
            }
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = stringResource(R.string.font_boldness_title),
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                Text(
                    text = "${tempBoldness.roundToInt()}%",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                Slider(
                    value = tempBoldness,
                    onValueChange = { tempBoldness = ((it / 5f).roundToInt() * 5).toFloat() },
                    valueRange = -50f..100f,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }

    if (showLyricsFontDialog) {
        DefaultDialog(
            onDismiss = { showLyricsFontDialog = false },
            buttons = {
                TextButton(onClick = { showLyricsFontDialog = false }) {
                    Text(stringResource(android.R.string.cancel))
                }
            }
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.lyrics_font_title),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                AppFont.entries.forEach { fontOption ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .clickable {
                                onLyricsFontChange(fontOption.id)
                                showLyricsFontDialog = false
                            }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = lyricsFont == fontOption.id,
                            onClick = {
                                onLyricsFontChange(fontOption.id)
                                showLyricsFontDialog = false
                            }
                        )
                        Text(
                            text = stringResource(fontOption.displayNameRes),
                            style = MaterialTheme.typography.bodyMedium.copy(fontFamily = fontOption.toFontFamily()),
                            modifier = Modifier.padding(start = 16.dp)
                        )
                    }
                }
            }
        }
    }

    if (showPlayerButtonsStyleDialog) {
        EnumDialog(
            onDismiss = { showPlayerButtonsStyleDialog = false },
            onSelect = {
                onPlayerButtonsStyleChange(it)
                showPlayerButtonsStyleDialog = false
            },
            title = stringResource(R.string.player_buttons_style),
            current = playerButtonsStyle,
            values = PlayerButtonsStyle.values().toList(),
            valueText = {
                when (it) {
                    PlayerButtonsStyle.DEFAULT -> stringResource(R.string.default_style)
                    PlayerButtonsStyle.PRIMARY -> stringResource(R.string.primary_color_style)
                    PlayerButtonsStyle.TERTIARY -> stringResource(R.string.tertiary_color_style)
                }
            },
        )
    }

    if (showPlayerBackgroundDialog) {
        EnumDialog(
            onDismiss = { showPlayerBackgroundDialog = false },
            onSelect = {
                onPlayerBackgroundChange(it)
                showPlayerBackgroundDialog = false
            },
            title = stringResource(R.string.player_background_style),
            current = playerBackground,
            values = availableBackgroundStyles,
            valueText = {
                when (it) {
                    PlayerBackgroundStyle.DEFAULT -> stringResource(R.string.bg_follow_theme)
                    PlayerBackgroundStyle.COLOR_TINT -> stringResource(R.string.bg_color_tint)
                    PlayerBackgroundStyle.BLUR -> stringResource(R.string.bg_blur)
                    PlayerBackgroundStyle.GLOW_ANIMATED -> stringResource(R.string.bg_glow_animated)
                    PlayerBackgroundStyle.APPLE_MUSIC -> stringResource(R.string.bg_apple_music)
                    PlayerBackgroundStyle.LIVE_MESH -> stringResource(R.string.bg_live_mesh)
                    PlayerBackgroundStyle.LIQUID_GLASS -> stringResource(R.string.bg_liquid_glass)
                    PlayerBackgroundStyle.GRADIENT -> stringResource(R.string.gradient)
                }
            },
        )
    }

    if (showMiniPlayerBackgroundDialog) {
        EnumDialog(
            onDismiss = { showMiniPlayerBackgroundDialog = false },
            onSelect = {
                onMiniPlayerBackgroundChange(it)
                showMiniPlayerBackgroundDialog = false
            },
            title = stringResource(R.string.mini_player_background_style),
            current = miniPlayerBackground,
            values = availableMiniPlayerBackgroundStyles,
            valueText = {
                when (it) {
                    MiniPlayerBackgroundStyle.DEFAULT -> stringResource(R.string.follow_theme)
                    MiniPlayerBackgroundStyle.TRANSPARENT -> stringResource(R.string.transparent)
                    MiniPlayerBackgroundStyle.BLUR -> stringResource(R.string.player_background_blur)
                    MiniPlayerBackgroundStyle.GRADIENT -> stringResource(R.string.gradient)
                    MiniPlayerBackgroundStyle.PURE_BLACK -> stringResource(R.string.pure_black)
                }
            },
        )
    }

    var showDefaultOpenTabDialog by rememberSaveable {
        mutableStateOf(false)
    }

    if (showDefaultOpenTabDialog) {
        EnumDialog(
            onDismiss = { showDefaultOpenTabDialog = false },
            onSelect = {
                onDefaultOpenTabChange(it)
                showDefaultOpenTabDialog = false
            },
            title = stringResource(R.string.default_open_tab),
            current = defaultOpenTab,
            values = listOf(NavigationTab.HOME, NavigationTab.SEARCH, NavigationTab.LIBRARY),
            valueText = {
                when (it) {
                    NavigationTab.HOME -> stringResource(R.string.home)
                    NavigationTab.SEARCH -> stringResource(R.string.search)
                    NavigationTab.LIBRARY -> stringResource(R.string.filter_library)
                    NavigationTab.SAMPLES -> stringResource(R.string.home)
                }
            },
        )
    }

    var showDefaultChipDialog by rememberSaveable {
        mutableStateOf(false)
    }

    if (showDefaultChipDialog) {
        EnumDialog(
            onDismiss = { showDefaultChipDialog = false },
            onSelect = {
                onDefaultChipChange(it)
                showDefaultChipDialog = false
            },
            title = stringResource(R.string.default_lib_chips),
            current = defaultChip,
            values = LibraryFilter.values().toList(),
            valueText = {
                when (it) {
                    LibraryFilter.SONGS -> stringResource(R.string.songs)
                    LibraryFilter.ARTISTS -> stringResource(R.string.artists)
                    LibraryFilter.ALBUMS -> stringResource(R.string.albums)
                    LibraryFilter.PLAYLISTS -> stringResource(R.string.playlists)
                    LibraryFilter.PODCASTS -> stringResource(R.string.filter_podcasts)
                    LibraryFilter.LIBRARY -> stringResource(R.string.filter_library)
                }
            },
        )
    }

    var showGridSizeDialog by rememberSaveable {
        mutableStateOf(false)
    }

    if (showGridSizeDialog) {
        EnumDialog(
            onDismiss = { showGridSizeDialog = false },
            onSelect = {
                onGridItemSizeChange(it)
                showGridSizeDialog = false
            },
            title = stringResource(R.string.grid_cell_size),
            current = gridItemSize,
            values = GridItemSize.values().toList(),
            valueText = {
                when (it) {
                    GridItemSize.BIG -> stringResource(R.string.big)
                    GridItemSize.SMALL -> stringResource(R.string.small)
                }
            },
        )
    }

    if (showRestartDialog) {
        DefaultDialog(
            onDismiss = { showRestartDialog = false },
            buttons = {
                TextButton(
                    onClick = { showRestartDialog = false },
                ) {
                    Text(text = stringResource(android.R.string.cancel))
                }
                TextButton(
                    onClick = {
                        showRestartDialog = false
                        val intent =
                            context.packageManager.getLaunchIntentForPackage(context.packageName)?.apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                            }
                        context.startActivity(intent)
                        Runtime.getRuntime().exit(0)
                    },
                ) {
                    Text(text = stringResource(R.string.restart))
                }
            },
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Text(
                    text = stringResource(R.string.restart_required),
                    style = MaterialTheme.typography.titleLarge,
                )
                Text(
                    text = stringResource(R.string.density_restart_message),
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }
    }



    if (showDensityScaleDialog) {
        DefaultDialog(
            onDismiss = { showDensityScaleDialog = false },
            buttons = {
                TextButton(
                    onClick = { showDensityScaleDialog = false },
                ) {
                    Text(text = stringResource(android.R.string.cancel))
                }
            },
        ) {
            Column {
                DensityScale.entries.forEach { scale ->
                    Row(
                        modifier =
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onDensityScaleChange(scale.value)
                                    showDensityScaleDialog = false
                                }.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = stringResource(scale.stringRes),
                            style = MaterialTheme.typography.bodyLarge,
                            color =
                                if (densityScale == scale.value) {
                                    MaterialTheme.colorScheme.primary
                                } else {
                                    MaterialTheme.colorScheme.onSurface
                                },
                        )
                    }
                }
            }
        }
    }

    if (showSliderOptionDialog) {
        DefaultDialog(
            buttons = {
                TextButton(
                    onClick = { showSliderOptionDialog = false },
                ) {
                    Text(text = stringResource(android.R.string.cancel))
                }
            },
            onDismiss = {
                showSliderOptionDialog = false
            },
        ) {
            val sliderPreviewColors =
                PlayerSliderColors.getSliderColors(
                    MaterialTheme.colorScheme.primary,
                    PlayerBackgroundStyle.DEFAULT,
                    isSystemInDarkTheme(),
                )

            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier =
                            Modifier
                                .aspectRatio(1f)
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .border(
                                    1.dp,
                                    if (sliderStyle == SliderStyle.DEFAULT &&
                                        !squigglySlider
                                    ) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.outlineVariant
                                    },
                                    RoundedCornerShape(16.dp),
                                ).clickable {
                                    onSliderStyleChange(SliderStyle.DEFAULT)
                                    onSquigglySliderChange(false)
                                    showSliderOptionDialog = false
                                }.padding(12.dp),
                    ) {
                        val sliderValue = 0.35f
                        Slider(
                            value = sliderValue,
                            valueRange = 0f..1f,
                            onValueChange = { /* preview only */ },
                            colors = sliderPreviewColors,
                            enabled = false,
                            modifier = Modifier.weight(1f),
                        )
                        Text(
                            text = stringResource(R.string.default_),
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier =
                            Modifier
                                .aspectRatio(1f)
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .border(
                                    1.dp,
                                    if (sliderStyle == SliderStyle.WAVY &&
                                        !squigglySlider
                                    ) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.outlineVariant
                                    },
                                    RoundedCornerShape(16.dp),
                                ).clickable {
                                    onSliderStyleChange(SliderStyle.WAVY)
                                    onSquigglySliderChange(false)
                                    showSliderOptionDialog = false
                                }.padding(12.dp),
                    ) {
                        val sliderValue = 0.5f
                        WavySlider(
                            value = sliderValue,
                            valueRange = 0f..1f,
                            onValueChange = { /* preview only */ },
                            colors = sliderPreviewColors,
                            modifier = Modifier.weight(1f),
                            isPlaying = true,
                            enabled = false,
                        )
                        Text(
                            text = stringResource(R.string.wavy),
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier =
                            Modifier
                                .aspectRatio(1f)
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .border(
                                    1.dp,
                                    if (sliderStyle ==
                                        SliderStyle.SLIM
                                    ) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.outlineVariant
                                    },
                                    RoundedCornerShape(16.dp),
                                ).clickable {
                                    onSliderStyleChange(SliderStyle.SLIM)
                                    onSquigglySliderChange(false)
                                    showSliderOptionDialog = false
                                }.padding(12.dp),
                    ) {
                        val sliderValue = 0.65f
                        Slider(
                            value = sliderValue,
                            valueRange = 0f..1f,
                            onValueChange = { /* preview only */ },
                            thumb = { Spacer(modifier = Modifier.size(0.dp)) },
                            track = { sliderState ->
                                PlayerSliderTrack(
                                    sliderState = sliderState,
                                    colors = sliderPreviewColors,
                                )
                            },
                            colors = sliderPreviewColors,
                            enabled = false,
                            modifier = Modifier.weight(1f),
                        )

                        Text(
                            text = stringResource(R.string.slim),
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier =
                            Modifier
                                .aspectRatio(1f)
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .border(
                                    1.dp,
                                    if (sliderStyle == SliderStyle.WAVY &&
                                        squigglySlider
                                    ) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.outlineVariant
                                    },
                                    RoundedCornerShape(16.dp),
                                ).clickable {
                                    onSliderStyleChange(SliderStyle.WAVY)
                                    onSquigglySliderChange(true)
                                    showSliderOptionDialog = false
                                }.padding(12.dp),
                    ) {
                        val sliderValue = 0.5f
                        SquigglySlider(
                            value = sliderValue,
                            valueRange = 0f..1f,
                            onValueChange = { /* preview only */ },
                            modifier = Modifier.weight(1f),
                            enabled = false,
                            colors = sliderPreviewColors,
                            isPlaying = true,
                        )
                        Text(
                            text = stringResource(R.string.squiggly),
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.appearance)) },
                navigationIcon = {
                    IconButton(
                        onClick = navController::navigateUp,
                        onLongClick = navController::backToMain,
                    ) {
                        Icon(
                            painterResource(R.drawable.arrow_back),
                            contentDescription = null,
                        )
                    }
                },
            )
        }
    ) { innerPadding ->
        Column(
            Modifier
                .padding(innerPadding)
                .windowInsetsPadding(
                    LocalPlayerAwareWindowInsets.current.only(
                        WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom,
                    ),
                )
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
        ) {
        Material3SettingsGroup(
            title = stringResource(R.string.theme),
            items =
                buildList {
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.speed),
                            title = { Text(stringResource(R.string.enable_high_refresh_rate)) },
                            description = { Text(stringResource(R.string.enable_high_refresh_rate_desc)) },
                            trailingContent = {
                                Switch(
                                    checked = enableHighRefreshRate,
                                    onCheckedChange = onEnableHighRefreshRateChange,
                                    thumbContent = {
                                        Icon(
                                            painter =
                                                painterResource(
                                                    id = if (enableHighRefreshRate) R.drawable.check else R.drawable.close,
                                                ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize),
                                        )
                                    },
                                )
                            },
                            onClick = { onEnableHighRefreshRateChange(!enableHighRefreshRate) },
                        ),
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.fullscreen),
                            title = { Text(stringResource(R.string.enable_landscape_scaling)) },
                            description = { Text(stringResource(R.string.enable_landscape_scaling_desc)) },
                            trailingContent = {
                                Switch(
                                    checked = enableLandscapeScaling,
                                    onCheckedChange = onEnableLandscapeScalingChange,
                                    thumbContent = {
                                        Icon(
                                            painter =
                                                painterResource(
                                                    id = if (enableLandscapeScaling) R.drawable.check else R.drawable.close,
                                                ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize),
                                        )
                                    },
                                )
                            },
                            onClick = { onEnableLandscapeScalingChange(!enableLandscapeScaling) },
                        ),
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.palette),
                            title = { Text(stringResource(R.string.enable_dynamic_theme)) },
                            description = { Text(stringResource(R.string.enable_dynamic_theme_desc)) },
                            trailingContent = {
                                Switch(
                                    checked = dynamicTheme,
                                    onCheckedChange = onDynamicThemeChange,
                                    thumbContent = {
                                        Icon(
                                            painter =
                                                painterResource(
                                                    id = if (dynamicTheme) R.drawable.check else R.drawable.close,
                                                ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize),
                                        )
                                    },
                                )
                            },
                            onClick = { onDynamicThemeChange(!dynamicTheme) },
                        ),
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.palette),
                            title = { Text(stringResource(R.string.custom_primary_color_title)) },
                            description = {
                                val hexString = String.format("#%06X", 0xFFFFFF and selectedThemeColorInt)
                                Text(stringResource(R.string.custom_primary_color_format, hexString))
                            },
                            trailingContent = {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(Color(selectedThemeColorInt))
                                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                                )
                            },
                            onClick = { showCustomPrimaryColorDialog = true },
                        ),
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.contrast),
                            title = { Text(stringResource(R.string.pure_black)) },
                            description = { Text(stringResource(R.string.pure_black_amoled_desc)) },
                            trailingContent = {
                                Switch(
                                    checked = pureBlack,
                                    onCheckedChange = onPureBlackChange,
                                    thumbContent = {
                                        Icon(
                                            painter =
                                                painterResource(
                                                    id = if (pureBlack) R.drawable.check else R.drawable.close,
                                                ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize),
                                        )
                                    },
                                )
                            },
                            onClick = { onPureBlackChange(!pureBlack) },
                        ),
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.palette),
                            title = { Text(stringResource(R.string.enable_dynamic_icon)) },
                            description = { Text(stringResource(R.string.enable_dynamic_icon_desc)) },
                            trailingContent = {
                                Switch(
                                    checked = enableDynamicIcon,
                                    onCheckedChange = onEnableDynamicIconChange,
                                    thumbContent = {
                                        Icon(
                                            painter =
                                                painterResource(
                                                    id = if (enableDynamicIcon) R.drawable.check else R.drawable.close,
                                                ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize),
                                        )
                                    },
                                )
                            },
                            onClick = { onEnableDynamicIconChange(!enableDynamicIcon) },
                        ),
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.time_auto),
                            title = { Text(stringResource(R.string.auto_theme_title)) },
                            description = { Text(stringResource(R.string.auto_theme_desc)) },
                            trailingContent = {
                                Switch(
                                    checked = darkMode == DarkMode.AUTO,
                                    onCheckedChange = { isChecked ->
                                        onDarkModeChange(if (isChecked) DarkMode.AUTO else DarkMode.OFF)
                                    },
                                    thumbContent = {
                                        Icon(
                                            painter = painterResource(
                                                id = if (darkMode == DarkMode.AUTO) R.drawable.check else R.drawable.close,
                                            ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize),
                                        )
                                    },
                                )
                            },
                            onClick = {
                                onDarkModeChange(if (darkMode == DarkMode.AUTO) DarkMode.OFF else DarkMode.AUTO)
                            },
                        ),
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.contrast),
                            title = { Text(stringResource(R.string.dark_theme)) },
                            description = {
                                Text(
                                    when (darkMode) {
                                        DarkMode.ON -> stringResource(R.string.dark_theme_on)
                                        DarkMode.OFF -> stringResource(R.string.dark_theme_off)
                                        DarkMode.AUTO -> stringResource(R.string.dark_theme_follow_system)
                                    }
                                )
                            },
                            trailingContent = {
                                Switch(
                                    checked = darkMode == DarkMode.ON,
                                    onCheckedChange = { isChecked ->
                                        onDarkModeChange(if (isChecked) DarkMode.ON else DarkMode.OFF)
                                    },
                                    thumbContent = {
                                        Icon(
                                            painter = painterResource(
                                                id = if (darkMode == DarkMode.ON) R.drawable.check else R.drawable.close,
                                            ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize),
                                        )
                                    },
                                )
                            },
                            onClick = {
                                onDarkModeChange(if (darkMode == DarkMode.ON) DarkMode.OFF else DarkMode.ON)
                            },
                        ),
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.palette),
                            title = { Text(stringResource(R.string.theme)) },
                            description = { Text(stringResource(R.string.theme_desc)) },
                            onClick = { navController.navigate("settings/appearance/theme") },
                        ),
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.fullscreen),
                            title = { Text(stringResource(R.string.show_splash_screen)) },
                            description = { Text(stringResource(R.string.show_splash_screen_desc)) },
                            trailingContent = {
                                Switch(
                                    checked = showSplashScreen,
                                    onCheckedChange = onShowSplashScreenChange,
                                    thumbContent = {
                                        Icon(
                                            painter = painterResource(
                                                id = if (showSplashScreen) R.drawable.check else R.drawable.close,
                                            ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize),
                                        )
                                    },
                                )
                            },
                            onClick = { onShowSplashScreenChange(!showSplashScreen) },
                        ),
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.fullscreen),
                            title = { Text(stringResource(R.string.show_launcher_icon_on_splash)) },
                            description = { Text(stringResource(R.string.show_launcher_icon_on_splash_desc)) },
                            trailingContent = {
                                Switch(
                                    checked = useLauncherIconOnSplash,
                                    onCheckedChange = onUseLauncherIconOnSplashChange,
                                    thumbContent = {
                                        Icon(
                                            painter = painterResource(
                                                id = if (useLauncherIconOnSplash) R.drawable.check else R.drawable.close,
                                            ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize),
                                        )
                                    },
                                )
                            },
                            onClick = { onUseLauncherIconOnSplashChange(!useLauncherIconOnSplash) },
                        ),
                    )
                },
        )

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.fonts_settings_title),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.ic_text_fields),
                    title = { Text(stringResource(R.string.app_font_title)) },
                    description = {
                        val fontDisplayName = stringResource(AppFont.fromId(appFont).displayNameRes)
                        Text(fontDisplayName)
                    },
                    onClick = { showAppFontDialog = true },
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.ic_format_size),
                    title = { Text(stringResource(R.string.font_size_title)) },
                    description = { Text("$appFontSize%") },
                    onClick = { showAppFontSizeDialog = true },
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.ic_format_bold),
                    title = { Text(stringResource(R.string.font_boldness_title)) },
                    description = { Text("$appFontBoldness%") },
                    onClick = { showAppFontBoldnessDialog = true },
                ),
            )
        )

        Spacer(modifier = Modifier.height(27.dp))

        val (pureBlackMiniPlayer, onPureBlackMiniPlayerChange) =
            rememberPreference(
                PureBlackMiniPlayerKey,
                defaultValue = false,
            )

        Material3SettingsGroup(
            title = stringResource(id = R.string.mini_player),
            items =
                buildList {
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.nav_bar),
                            title = { Text(stringResource(R.string.new_mini_player_design)) },
                            trailingContent = {
                                Switch(
                                    checked = useNewMiniPlayerDesign,
                                    onCheckedChange = onUseNewMiniPlayerDesignChange,
                                    thumbContent = {
                                        Icon(
                                            painter =
                                                painterResource(
                                                    id = if (useNewMiniPlayerDesign) R.drawable.check else R.drawable.close,
                                                ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize),
                                        )
                                    },
                                )
                            },
                            onClick = { onUseNewMiniPlayerDesignChange(!useNewMiniPlayerDesign) },
                        ),
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.gradient),
                            title = {
                                Text(
                                    text = stringResource(R.string.mini_player_background_style),
                                    color =
                                        if (!useNewMiniPlayerDesign) {
                                            MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
                                        } else {
                                            MaterialTheme.colorScheme.onSurface
                                        },
                                )
                            },
                            description = {
                                Text(
                                    text =
                                        if (!useNewMiniPlayerDesign) {
                                            stringResource(R.string.mini_player_background_not_available)
                                        } else {
                                            when (miniPlayerBackground) {
                                                MiniPlayerBackgroundStyle.DEFAULT -> stringResource(R.string.follow_theme)
                                                MiniPlayerBackgroundStyle.TRANSPARENT -> stringResource(R.string.transparent)
                                                MiniPlayerBackgroundStyle.BLUR -> stringResource(R.string.player_background_blur)
                                                MiniPlayerBackgroundStyle.GRADIENT -> stringResource(R.string.gradient)
                                                MiniPlayerBackgroundStyle.PURE_BLACK -> stringResource(R.string.pure_black)
                                            }
                                        },
                                    color =
                                        if (!useNewMiniPlayerDesign) {
                                            MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
                                        } else {
                                            MaterialTheme.colorScheme.onSurfaceVariant
                                        },
                                )
                            },
                            onClick = { if (useNewMiniPlayerDesign) showMiniPlayerBackgroundDialog = true },
                        ),
                    )
                },
        )

        Spacer(modifier = Modifier.height(27.dp))

        var showSensitivityDialog by rememberSaveable { mutableStateOf(false) }

        Material3SettingsGroup(
            title = stringResource(R.string.player),
            items =
                listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.palette),
                        title = { Text(stringResource(R.string.new_player_design)) },
                        trailingContent = {
                            Switch(
                                checked = useNewPlayerDesign,
                                onCheckedChange = onUseNewPlayerDesignChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (useNewPlayerDesign) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onUseNewPlayerDesignChange(!useNewPlayerDesign) },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.gradient),
                        title = { Text(stringResource(R.string.player_background_style)) },
                        description = {
                            Text(
                                when (playerBackground) {
                                    PlayerBackgroundStyle.DEFAULT -> stringResource(R.string.bg_follow_theme)
                                    PlayerBackgroundStyle.COLOR_TINT -> stringResource(R.string.bg_color_tint)
                                    PlayerBackgroundStyle.BLUR -> stringResource(R.string.bg_blur)
                                    PlayerBackgroundStyle.GLOW_ANIMATED -> stringResource(R.string.bg_glow_animated)
                                    PlayerBackgroundStyle.APPLE_MUSIC -> stringResource(R.string.bg_apple_music)
                                    PlayerBackgroundStyle.LIVE_MESH -> stringResource(R.string.bg_live_mesh)
                                    PlayerBackgroundStyle.LIQUID_GLASS -> stringResource(R.string.bg_liquid_glass)
                                    PlayerBackgroundStyle.GRADIENT -> stringResource(R.string.gradient)
                                },
                            )
                        },
                        onClick = { showPlayerBackgroundDialog = true },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.hide_image),
                        title = { Text(stringResource(R.string.hide_player_thumbnail)) },
                        description = { Text(stringResource(R.string.hide_player_thumbnail_desc)) },
                        trailingContent = {
                            Switch(
                                checked = hidePlayerThumbnail,
                                onCheckedChange = onHidePlayerThumbnailChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (hidePlayerThumbnail) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onHidePlayerThumbnailChange(!hidePlayerThumbnail) },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.crop),
                        title = { Text(stringResource(R.string.crop_album_art)) },
                        description = { Text(stringResource(R.string.crop_album_art_desc)) },
                        trailingContent = {
                            Switch(
                                checked = cropAlbumArt,
                                onCheckedChange = onCropAlbumArtChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (cropAlbumArt) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onCropAlbumArtChange(!cropAlbumArt) },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.gradient),
                        title = { Text(stringResource(R.string.show_artist_canvas_video)) },
                        description = { Text(stringResource(R.string.show_artist_canvas_video_desc)) },
                        trailingContent = {
                            Switch(
                                checked = showArtistCanvasVideo,
                                onCheckedChange = onShowArtistCanvasVideoChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (showArtistCanvasVideo) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onShowArtistCanvasVideoChange(!showArtistCanvasVideo) },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.fullscreen),
                        title = { Text(stringResource(R.string.show_artist_background_video)) },
                        description = { Text(stringResource(R.string.show_artist_background_video_desc)) },
                        trailingContent = {
                            Switch(
                                checked = showArtistBackgroundVideo,
                                onCheckedChange = onShowArtistBackgroundVideoChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (showArtistBackgroundVideo) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onShowArtistBackgroundVideoChange(!showArtistBackgroundVideo) },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.palette),
                        title = { Text(stringResource(R.string.canvas_title)) },
                        description = { Text(stringResource(R.string.canvas_desc)) },
                        trailingContent = {
                            Switch(
                                checked = showAlbumCanvas,
                                onCheckedChange = onShowAlbumCanvasChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (showAlbumCanvas) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onShowAlbumCanvasChange(!showAlbumCanvas) },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.album),
                        title = { Text(stringResource(R.string.rotating_thumbnail_title)) },
                        description = { Text(stringResource(R.string.rotating_thumbnail_desc)) },
                        trailingContent = {
                            Switch(
                                checked = enableRotatingThumbnail,
                                onCheckedChange = onEnableRotatingThumbnailChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (enableRotatingThumbnail) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onEnableRotatingThumbnailChange(!enableRotatingThumbnail) },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.chat_bubble),
                        title = { Text(stringResource(R.string.show_comment_button_title)) },
                        description = { Text(stringResource(R.string.show_comment_button_desc)) },
                        trailingContent = {
                            Switch(
                                checked = showCommentButton,
                                onCheckedChange = onShowCommentButtonChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (showCommentButton) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onShowCommentButtonChange(!showCommentButton) },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.graphic_eq),
                        title = { Text(stringResource(R.string.show_codec_on_player_title)) },
                        description = { Text(stringResource(R.string.show_codec_on_player_desc)) },
                        trailingContent = {
                            Switch(
                                checked = showCodecOnPlayer,
                                onCheckedChange = onShowCodecOnPlayerChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (showCodecOnPlayer) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onShowCodecOnPlayerChange(!showCodecOnPlayer) },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.crop),
                        title = { Text(stringResource(R.string.thumbnail_corner_radius_title)) },
                        description = {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = stringResource(R.string.thumbnail_corner_radius_desc),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "${thumbnailCornerRadius.toInt()} dp",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Slider(
                                    value = thumbnailCornerRadius,
                                    onValueChange = onThumbnailCornerRadiusChange,
                                    valueRange = 0f..32f,
                                    steps = 31,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.palette),
                        title = { Text(stringResource(R.string.player_buttons_style)) },
                        description = {
                            Text(
                                when (playerButtonsStyle) {
                                    PlayerButtonsStyle.DEFAULT -> stringResource(R.string.default_style)
                                    PlayerButtonsStyle.PRIMARY -> stringResource(R.string.primary_color_style)
                                    PlayerButtonsStyle.TERTIARY -> stringResource(R.string.tertiary_color_style)
                                },
                            )
                        },
                        onClick = { showPlayerButtonsStyleDialog = true },
                    ),

                    Material3SettingsItem(
                        icon = painterResource(R.drawable.sliders),
                        title = { Text(stringResource(R.string.player_slider_style)) },
                        description = {
                            Text(
                                when (sliderStyle) {
                                    SliderStyle.DEFAULT -> {
                                        stringResource(R.string.default_)
                                    }

                                    SliderStyle.WAVY -> {
                                        if (squigglySlider) {
                                            stringResource(R.string.squiggly)
                                        } else {
                                            stringResource(
                                                R.string.wavy,
                                            )
                                        }
                                    }

                                    SliderStyle.SLIM -> {
                                        stringResource(R.string.slim)
                                    }
                                },
                            )
                        },
                        onClick = { showSliderOptionDialog = true },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.swipe),
                        title = { Text(stringResource(R.string.enable_swipe_thumbnail)) },
                        trailingContent = {
                            Switch(
                                checked = swipeThumbnail,
                                onCheckedChange = onSwipeThumbnailChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (swipeThumbnail) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onSwipeThumbnailChange(!swipeThumbnail) },
                    ),
                ) +
                    if (swipeThumbnail) {
                        listOf(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.tune),
                                title = { Text(stringResource(R.string.swipe_sensitivity)) },
                                description = {
                                    Text(
                                        stringResource(
                                            R.string.sensitivity_percentage,
                                            (swipeSensitivity * 100).roundToInt(),
                                        ),
                                    )
                                },
                                onClick = { showSensitivityDialog = true },
                            ),
                        )
                    } else {
                        emptyList()
                    },
        )

        if (showSensitivityDialog) {
            var tempSensitivity by remember { mutableFloatStateOf(swipeSensitivity) }

            DefaultDialog(
                onDismiss = {
                    tempSensitivity = swipeSensitivity
                    showSensitivityDialog = false
                },
                buttons = {
                    TextButton(
                        onClick = {
                            tempSensitivity = 0.73f
                        },
                    ) {
                        Text(stringResource(R.string.reset))
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    TextButton(
                        onClick = {
                            tempSensitivity = swipeSensitivity
                            showSensitivityDialog = false
                        },
                    ) {
                        Text(stringResource(android.R.string.cancel))
                    }
                    TextButton(
                        onClick = {
                            onSwipeSensitivityChange(tempSensitivity)
                            showSensitivityDialog = false
                        },
                    ) {
                        Text(stringResource(android.R.string.ok))
                    }
                },
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(16.dp),
                ) {
                    Text(
                        text = stringResource(R.string.swipe_sensitivity),
                        style = MaterialTheme.typography.headlineSmall,
                        modifier = Modifier.padding(bottom = 16.dp),
                    )

                    Text(
                        text =
                            stringResource(
                                R.string.sensitivity_percentage,
                                (tempSensitivity * 100).roundToInt(),
                            ),
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(bottom = 16.dp),
                    )

                    Slider(
                        value = tempSensitivity,
                        onValueChange = { tempSensitivity = it },
                        valueRange = 0f..1f,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.lyrics),
            items =
                buildList {
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.lyrics),
                            title = { Text(stringResource(R.string.experimental_lyrics)) },
                            description = { Text(stringResource(R.string.experimental_lyrics_desc)) },
                            showBadge = false,
                            trailingContent = {
                                Switch(
                                    checked = experimentalLyrics,
                                    onCheckedChange = { enabled ->
                                        onExperimentalLyricsChange(enabled)
                                    },
                                    thumbContent = {
                                        Icon(
                                            painter =
                                                painterResource(
                                                    id = if (experimentalLyrics) R.drawable.check else R.drawable.close,
                                                ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize),
                                        )
                                    },
                                )
                            },
                            onClick = null,
                        ),
                    )

                    if (experimentalLyrics) {
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.lyrics),
                                title = { Text(stringResource(R.string.lyrics_animation_style_title)) },
                                description = {
                                    Text(
                                        when (lyricsAnimationStyle) {
                                            LyricsAnimationStyle.NONE -> stringResource(R.string.none)
                                            LyricsAnimationStyle.FADE -> stringResource(R.string.fade)
                                            LyricsAnimationStyle.GLOW -> stringResource(R.string.glow)
                                            LyricsAnimationStyle.SLIDE -> stringResource(R.string.slide)
                                            LyricsAnimationStyle.KARAOKE -> stringResource(R.string.karaoke)
                                            LyricsAnimationStyle.APPLE -> stringResource(R.string.apple_music_style)
                                            LyricsAnimationStyle.APPLE_V2 -> stringResource(R.string.lyrics_animation_apple_v2)
                                            LyricsAnimationStyle.VIVI_FLUID -> stringResource(R.string.lyrics_animation_vivi_fluid)
                                            LyricsAnimationStyle.LYRICS_V2_FLUID -> stringResource(R.string.lyrics_animation_lyrics_v2_fluid)
                                            LyricsAnimationStyle.METRO_LYRICS -> stringResource(R.string.lyrics_animation_metro_lyrics)
                                        },
                                    )
                                },
                                onClick = { showLyricsAnimationStyleDialog = true },
                            ),
                        )
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.lyrics),
                                title = { Text(stringResource(R.string.lyrics_glow_effect)) },
                                description = { Text(stringResource(R.string.lyrics_glow_effect_subtext)) },
                                trailingContent = {
                                    Switch(
                                        checked = lyricsGlowEffect,
                                        onCheckedChange = onLyricsGlowEffectChange,
                                        thumbContent = {
                                            Icon(
                                                painter =
                                                    painterResource(
                                                        id = if (lyricsGlowEffect) R.drawable.check else R.drawable.close,
                                                    ),
                                                contentDescription = null,
                                                modifier = Modifier.size(SwitchDefaults.IconSize),
                                            )
                                        },
                                    )
                                },
                                onClick = { onLyricsGlowEffectChange(!lyricsGlowEffect) },
                            ),
                        )
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.lyrics),
                                title = { Text(stringResource(R.string.blur_standard_lyrics)) },
                                description = { Text(stringResource(R.string.blur_standard_lyrics_desc)) },
                                trailingContent = {
                                    Switch(
                                        checked = blurStandardLyrics,
                                        onCheckedChange = onBlurStandardLyricsChange,
                                        thumbContent = {
                                            Icon(
                                                painter =
                                                    painterResource(
                                                        id = if (blurStandardLyrics) R.drawable.check else R.drawable.close,
                                                    ),
                                                contentDescription = null,
                                                modifier = Modifier.size(SwitchDefaults.IconSize),
                                            )
                                        },
                                    )
                                },
                                onClick = { onBlurStandardLyricsChange(!blurStandardLyrics) },
                            ),
                        )
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.lyrics),
                                title = { Text(stringResource(R.string.lyrics_text_size)) },
                                description = { Text("${lyricsTextSize.roundToInt()} sp") },
                                onClick = { showLyricsTextSizeDialog = true },
                            ),
                        )
                        add(
                            Material3SettingsItem(
                                icon = painterResource(R.drawable.lyrics),
                                title = { Text(stringResource(R.string.lyrics_line_spacing)) },
                                description = { Text("${String.format(Locale.US, "%.1f", lyricsLineSpacing)}x") },
                                onClick = { showLyricsLineSpacingDialog = true },
                            ),
                        )
                    }

                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.lyrics),
                            title = { Text(stringResource(R.string.lyrics_text_position)) },
                            description = {
                                Text(
                                    when (lyricsPosition) {
                                        LyricsPosition.LEFT -> stringResource(R.string.left)
                                        LyricsPosition.CENTER -> stringResource(R.string.center)
                                        LyricsPosition.RIGHT -> stringResource(R.string.right)
                                    },
                                )
                            },
                            onClick = { showLyricsPositionDialog = true },
                        ),
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.lyrics),
                            title = { Text(stringResource(R.string.respect_agent_positioning)) },
                            description = { Text(stringResource(R.string.respect_agent_positioning_desc)) },
                            trailingContent = {
                                Switch(
                                    checked = respectAgentPositioning,
                                    onCheckedChange = onRespectAgentPositioningChange,
                                    thumbContent = {
                                        Icon(
                                            painter =
                                                painterResource(
                                                    id = if (respectAgentPositioning) R.drawable.check else R.drawable.close,
                                                ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize),
                                        )
                                    },
                                )
                            },
                            onClick = { onRespectAgentPositioningChange(!respectAgentPositioning) },
                        ),
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.lyrics),
                            title = { Text(stringResource(R.string.lyrics_click_change)) },
                            trailingContent = {
                                Switch(
                                    checked = lyricsClick,
                                    onCheckedChange = onLyricsClickChange,
                                    thumbContent = {
                                        Icon(
                                            painter =
                                                painterResource(
                                                    id = if (lyricsClick) R.drawable.check else R.drawable.close,
                                                ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize),
                                        )
                                    },
                                )
                            },
                            onClick = { onLyricsClickChange(!lyricsClick) },
                        ),
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.lyrics),
                            title = { Text(stringResource(R.string.lyrics_auto_scroll)) },
                            trailingContent = {
                                Switch(
                                    checked = lyricsScroll,
                                    onCheckedChange = onLyricsScrollChange,
                                    thumbContent = {
                                        Icon(
                                            painter =
                                                painterResource(
                                                    id = if (lyricsScroll) R.drawable.check else R.drawable.close,
                                                ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize),
                                        )
                                    },
                                )
                            },
                            onClick = { onLyricsScrollChange(!lyricsScroll) },
                        ),
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.lyrics),
                            title = { Text(stringResource(R.string.hide_status_bar_fullscreen)) },
                            description = { Text(stringResource(R.string.hide_status_bar_fullscreen_desc)) },
                            trailingContent = {
                                Switch(
                                    checked = hideStatusBarOnFullscreen,
                                    onCheckedChange = onHideStatusBarOnFullscreenChange,
                                    thumbContent = {
                                        Icon(
                                            painter =
                                                painterResource(
                                                    id = if (hideStatusBarOnFullscreen) R.drawable.check else R.drawable.close,
                                                ),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize),
                                        )
                                    },
                                )
                            },
                            onClick = { onHideStatusBarOnFullscreenChange(!hideStatusBarOnFullscreen) },
                        ),
                    )
                },
        )

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.liquid_glass_title),
            items = buildList {
                add(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.nav_bar),
                        title = { Text(stringResource(R.string.floating_nav_bar)) },
                        description = { Text(stringResource(R.string.floating_nav_bar_desc)) },
                        trailingContent = {
                            Switch(
                                checked = floatingNavBar,
                                onCheckedChange = onFloatingNavBarChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(id = if (floatingNavBar) R.drawable.check else R.drawable.close),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onFloatingNavBarChange(!floatingNavBar) },
                    )
                )
                add(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.palette),
                        title = { Text(stringResource(R.string.enable_liquid_glass)) },
                        description = { Text(stringResource(R.string.enable_liquid_glass_desc)) },
                        trailingContent = {
                            Switch(
                                checked = enableLiquidGlass,
                                onCheckedChange = onEnableLiquidGlassChange,
                                thumbContent = {
                                    Icon(
                                        painter = painterResource(id = if (enableLiquidGlass) R.drawable.check else R.drawable.close),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onEnableLiquidGlassChange(!enableLiquidGlass) },
                    )
                )

                if (enableLiquidGlass) {
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.tune),
                            title = { Text(stringResource(R.string.glass_saturation)) },
                            description = { Text(stringResource(R.string.glass_saturation_desc) + " (${(glassSaturation * 100).roundToInt()}%)") },
                            onClick = { showGlassSaturationDialog = true },
                        )
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.tune),
                            title = { Text(stringResource(R.string.glass_blur_radius)) },
                            description = { Text("${glassBlurRadius.roundToInt()} dp") },
                            onClick = { showGlassBlurRadiusDialog = true },
                        )
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.tune),
                            title = { Text(stringResource(R.string.lens_refraction_height)) },
                            description = { Text("${lensRefractionHeight.roundToInt()} dp") },
                            onClick = { showLensRefractionHeightDialog = true },
                        )
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.tune),
                            title = { Text(stringResource(R.string.lens_refraction_amount)) },
                            description = { Text("${(lensRefractionAmount * 100).roundToInt()}%") },
                            onClick = { showLensRefractionAmountDialog = true },
                        )
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.tune),
                            title = { Text(stringResource(R.string.chromatic_aberration)) },
                            description = { Text("${(chromaticAberration * 100).roundToInt()}%") },
                            onClick = { showChromaticAberrationDialog = true },
                        )
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.tune),
                            title = { Text(stringResource(R.string.depth_effect)) },
                            description = { Text("${(depthEffect * 100).roundToInt()}%") },
                            onClick = { showDepthEffectDialog = true },
                        )
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.tune),
                            title = { Text(stringResource(R.string.surface_opacity)) },
                            description = { Text(stringResource(R.string.surface_opacity_desc) + " (${(surfaceOpacity * 100).roundToInt()}%)") },
                            onClick = { showSurfaceOpacityDialog = true },
                        )
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.palette),
                            title = { Text(stringResource(R.string.glass_player)) },
                            trailingContent = {
                                Switch(
                                    checked = glassPlayer,
                                    onCheckedChange = onGlassPlayerChange,
                                    thumbContent = {
                                        Icon(
                                            painter = painterResource(id = if (glassPlayer) R.drawable.check else R.drawable.close),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize),
                                        )
                                    },
                                )
                            },
                            onClick = { onGlassPlayerChange(!glassPlayer) },
                        )
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.palette),
                            title = { Text(stringResource(R.string.glass_mini_player)) },
                            trailingContent = {
                                Switch(
                                    checked = glassMiniPlayer,
                                    onCheckedChange = onGlassMiniPlayerChange,
                                    thumbContent = {
                                        Icon(
                                            painter = painterResource(id = if (glassMiniPlayer) R.drawable.check else R.drawable.close),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize),
                                        )
                                    },
                                )
                            },
                            onClick = { onGlassMiniPlayerChange(!glassMiniPlayer) },
                        )
                    )
                    add(
                        Material3SettingsItem(
                            icon = painterResource(R.drawable.palette),
                            title = { Text(stringResource(R.string.glass_nav_bar)) },
                            trailingContent = {
                                Switch(
                                    checked = glassNavBar,
                                    onCheckedChange = onGlassNavBarChange,
                                    thumbContent = {
                                        Icon(
                                            painter = painterResource(id = if (glassNavBar) R.drawable.check else R.drawable.close),
                                            contentDescription = null,
                                            modifier = Modifier.size(SwitchDefaults.IconSize),
                                        )
                                    },
                                )
                            },
                            onClick = { onGlassNavBarChange(!glassNavBar) },
                        )
                    )
                }
            }
        )

        if (showGlassSaturationDialog) {
            var tempVal by remember { mutableFloatStateOf(glassSaturation) }
            DefaultDialog(
                onDismiss = { showGlassSaturationDialog = false },
                buttons = {
                    TextButton(onClick = { tempVal = 1.3f }) { Text(stringResource(R.string.reset)) }
                    Spacer(modifier = Modifier.weight(1f))
                    TextButton(onClick = { showGlassSaturationDialog = false }) { Text(stringResource(android.R.string.cancel)) }
                    TextButton(onClick = {
                        onGlassSaturationChange(tempVal)
                        showGlassSaturationDialog = false
                    }) { Text(stringResource(android.R.string.ok)) }
                }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
                    Text(text = stringResource(R.string.glass_saturation), style = MaterialTheme.typography.headlineSmall)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(text = "${(tempVal * 100).roundToInt()}%")
                    Slider(value = tempVal, onValueChange = { tempVal = it }, valueRange = 0.5f..2.5f)
                }
            }
        }

        if (showGlassBlurRadiusDialog) {
            var tempVal by remember { mutableFloatStateOf(glassBlurRadius) }
            DefaultDialog(
                onDismiss = { showGlassBlurRadiusDialog = false },
                buttons = {
                    TextButton(onClick = { tempVal = 24f }) { Text(stringResource(R.string.reset)) }
                    Spacer(modifier = Modifier.weight(1f))
                    TextButton(onClick = { showGlassBlurRadiusDialog = false }) { Text(stringResource(android.R.string.cancel)) }
                    TextButton(onClick = {
                        onGlassBlurRadiusChange(tempVal)
                        showGlassBlurRadiusDialog = false
                    }) { Text(stringResource(android.R.string.ok)) }
                }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
                    Text(text = stringResource(R.string.glass_blur_radius), style = MaterialTheme.typography.headlineSmall)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(text = "${tempVal.roundToInt()} dp")
                    Slider(value = tempVal, onValueChange = { tempVal = it }, valueRange = 0f..60f)
                }
            }
        }

        if (showLensRefractionHeightDialog) {
            var tempVal by remember { mutableFloatStateOf(lensRefractionHeight) }
            DefaultDialog(
                onDismiss = { showLensRefractionHeightDialog = false },
                buttons = {
                    TextButton(onClick = { tempVal = 14f }) { Text(stringResource(R.string.reset)) }
                    Spacer(modifier = Modifier.weight(1f))
                    TextButton(onClick = { showLensRefractionHeightDialog = false }) { Text(stringResource(android.R.string.cancel)) }
                    TextButton(onClick = {
                        onLensRefractionHeightChange(tempVal)
                        showLensRefractionHeightDialog = false
                    }) { Text(stringResource(android.R.string.ok)) }
                }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
                    Text(text = stringResource(R.string.lens_refraction_height), style = MaterialTheme.typography.headlineSmall)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(text = "${tempVal.roundToInt()} dp")
                    Slider(value = tempVal, onValueChange = { tempVal = it }, valueRange = 0f..30f)
                }
            }
        }

        if (showLensRefractionAmountDialog) {
            var tempVal by remember { mutableFloatStateOf(lensRefractionAmount) }
            DefaultDialog(
                onDismiss = { showLensRefractionAmountDialog = false },
                buttons = {
                    TextButton(onClick = { tempVal = 0.85f }) { Text(stringResource(R.string.reset)) }
                    Spacer(modifier = Modifier.weight(1f))
                    TextButton(onClick = { showLensRefractionAmountDialog = false }) { Text(stringResource(android.R.string.cancel)) }
                    TextButton(onClick = {
                        onLensRefractionAmountChange(tempVal)
                        showLensRefractionAmountDialog = false
                    }) { Text(stringResource(android.R.string.ok)) }
                }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
                    Text(text = stringResource(R.string.lens_refraction_amount), style = MaterialTheme.typography.headlineSmall)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(text = "${(tempVal * 100).roundToInt()}%")
                    Slider(value = tempVal, onValueChange = { tempVal = it }, valueRange = 0f..2f)
                }
            }
        }

        if (showChromaticAberrationDialog) {
            var tempVal by remember { mutableFloatStateOf(chromaticAberration) }
            DefaultDialog(
                onDismiss = { showChromaticAberrationDialog = false },
                buttons = {
                    TextButton(onClick = { tempVal = 0.45f }) { Text(stringResource(R.string.reset)) }
                    Spacer(modifier = Modifier.weight(1f))
                    TextButton(onClick = { showChromaticAberrationDialog = false }) { Text(stringResource(android.R.string.cancel)) }
                    TextButton(onClick = {
                        onChromaticAberrationChange(tempVal)
                        showChromaticAberrationDialog = false
                    }) { Text(stringResource(android.R.string.ok)) }
                }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
                    Text(text = stringResource(R.string.chromatic_aberration), style = MaterialTheme.typography.headlineSmall)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(text = "${(tempVal * 100).roundToInt()}%")
                    Slider(value = tempVal, onValueChange = { tempVal = it }, valueRange = 0f..1f)
                }
            }
        }

        if (showDepthEffectDialog) {
            var tempVal by remember { mutableFloatStateOf(depthEffect) }
            DefaultDialog(
                onDismiss = { showDepthEffectDialog = false },
                buttons = {
                    TextButton(onClick = { tempVal = 0.75f }) { Text(stringResource(R.string.reset)) }
                    Spacer(modifier = Modifier.weight(1f))
                    TextButton(onClick = { showDepthEffectDialog = false }) { Text(stringResource(android.R.string.cancel)) }
                    TextButton(onClick = {
                        onDepthEffectChange(tempVal)
                        showDepthEffectDialog = false
                    }) { Text(stringResource(android.R.string.ok)) }
                }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
                    Text(text = stringResource(R.string.depth_effect), style = MaterialTheme.typography.headlineSmall)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(text = "${(tempVal * 100).roundToInt()}%")
                    Slider(value = tempVal, onValueChange = { tempVal = it }, valueRange = 0f..1f)
                }
            }
        }

        if (showSurfaceOpacityDialog) {
            var tempVal by remember { mutableFloatStateOf(surfaceOpacity) }
            DefaultDialog(
                onDismiss = { showSurfaceOpacityDialog = false },
                buttons = {
                    TextButton(onClick = { tempVal = 1.0f }) { Text(stringResource(R.string.reset)) }
                    Spacer(modifier = Modifier.weight(1f))
                    TextButton(onClick = { showSurfaceOpacityDialog = false }) { Text(stringResource(android.R.string.cancel)) }
                    TextButton(onClick = {
                        onSurfaceOpacityChange(tempVal)
                        showSurfaceOpacityDialog = false
                    }) { Text(stringResource(android.R.string.ok)) }
                }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
                    Text(text = stringResource(R.string.surface_opacity), style = MaterialTheme.typography.headlineSmall)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(text = "${(tempVal * 100).roundToInt()}%")
                    Slider(value = tempVal, onValueChange = { tempVal = it }, valueRange = 0.80f..1.0f)
                }
            }
        }

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.misc),
            items =
                listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.nav_bar),
                        title = { Text(stringResource(R.string.default_open_tab)) },
                        description = {
                            Text(
                                when (defaultOpenTab) {
                                    NavigationTab.HOME -> stringResource(R.string.home)
                                    NavigationTab.SEARCH -> stringResource(R.string.search)
                                    NavigationTab.LIBRARY -> stringResource(R.string.filter_library)
                                    NavigationTab.SAMPLES -> stringResource(R.string.home)
                                },
                            )
                        },
                        onClick = { showDefaultOpenTabDialog = true },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.tab),
                        title = { Text(stringResource(R.string.default_lib_chips)) },
                        description = {
                            Text(
                                when (defaultChip) {
                                    LibraryFilter.SONGS -> stringResource(R.string.songs)
                                    LibraryFilter.ARTISTS -> stringResource(R.string.artists)
                                    LibraryFilter.ALBUMS -> stringResource(R.string.albums)
                                    LibraryFilter.PLAYLISTS -> stringResource(R.string.playlists)
                                    LibraryFilter.PODCASTS -> stringResource(R.string.filter_podcasts)
                                    LibraryFilter.LIBRARY -> stringResource(R.string.filter_library)
                                },
                            )
                        },
                        onClick = { showDefaultChipDialog = true },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.swipe),
                        title = { Text(stringResource(R.string.swipe_song_to_add)) },
                        trailingContent = {
                            Switch(
                                checked = swipeToSong,
                                onCheckedChange = onSwipeToSongChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (swipeToSong) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onSwipeToSongChange(!swipeToSong) },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.swipe),
                        title = { Text(stringResource(R.string.swipe_song_to_remove)) },
                        trailingContent = {
                            Switch(
                                checked = swipeToRemoveSong,
                                onCheckedChange = onSwipeToRemoveSongChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (swipeToRemoveSong) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onSwipeToRemoveSongChange(!swipeToRemoveSong) },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.nav_bar),
                        title = { Text(stringResource(R.string.slim_navbar)) },
                        trailingContent = {
                            Switch(
                                checked = slimNav,
                                onCheckedChange = onSlimNavChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (slimNav) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onSlimNavChange(!slimNav) },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.tune),
                        title = { Text(stringResource(R.string.enable_haptics)) },
                        description = { Text(stringResource(R.string.enable_haptics_desc)) },
                        trailingContent = {
                            Switch(
                                checked = enableHaptics,
                                onCheckedChange = onEnableHapticsChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (enableHaptics) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onEnableHapticsChange(!enableHaptics) },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.play),
                        title = { Text(stringResource(R.string.haptics_playback_controls_title)) },
                        description = { Text(stringResource(R.string.haptics_playback_controls_desc)) },
                        trailingContent = {
                            Switch(
                                checked = enableHaptics && hapticsPlaybackControls,
                                enabled = enableHaptics,
                                onCheckedChange = onHapticsPlaybackControlsChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (enableHaptics && hapticsPlaybackControls) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = {
                            if (enableHaptics) {
                                onHapticsPlaybackControlsChange(!hapticsPlaybackControls)
                            }
                        },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.sliders),
                        title = { Text(stringResource(R.string.haptics_seekbar_title)) },
                        description = { Text(stringResource(R.string.haptics_seekbar_desc)) },
                        trailingContent = {
                            Switch(
                                checked = enableHaptics && hapticsSeekbar,
                                enabled = enableHaptics,
                                onCheckedChange = onHapticsSeekbarChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (enableHaptics && hapticsSeekbar) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = {
                            if (enableHaptics) {
                                onHapticsSeekbarChange(!hapticsSeekbar)
                            }
                        },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.favorite),
                        title = { Text(stringResource(R.string.haptics_buttons_title)) },
                        description = { Text(stringResource(R.string.haptics_buttons_desc)) },
                        trailingContent = {
                            Switch(
                                checked = enableHaptics && hapticsButtons,
                                enabled = enableHaptics,
                                onCheckedChange = onHapticsButtonsChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (enableHaptics && hapticsButtons) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = {
                            if (enableHaptics) {
                                onHapticsButtonsChange(!hapticsButtons)
                            }
                        },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.group_outlined),
                        title = { Text(stringResource(R.string.listen_together_in_top_bar)) },
                        description = { Text(stringResource(R.string.listen_together_in_top_bar_desc)) },
                        trailingContent = {
                            Switch(
                                checked = listenTogetherInTopBar,
                                onCheckedChange = onListenTogetherInTopBarChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (listenTogetherInTopBar) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onListenTogetherInTopBarChange(!listenTogetherInTopBar) },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.grid_view),
                        title = { Text(stringResource(R.string.grid_cell_size)) },
                        description = {
                            Text(
                                when (gridItemSize) {
                                    GridItemSize.BIG -> stringResource(R.string.big)
                                    GridItemSize.SMALL -> stringResource(R.string.small)
                                },
                            )
                        },
                        onClick = { showGridSizeDialog = true },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.grid_view),
                        title = { Text(stringResource(R.string.display_density)) },
                        description = {
                            Text(stringResource(DensityScale.fromValue(densityScale).stringRes))
                        },
                        onClick = { showDensityScaleDialog = true },
                    ),
                ),
        )

        Spacer(modifier = Modifier.height(27.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.auto_playlists),
            items =
                listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.favorite),
                        title = { Text(stringResource(R.string.show_liked_playlist)) },
                        trailingContent = {
                            Switch(
                                checked = showLikedPlaylist,
                                onCheckedChange = onShowLikedPlaylistChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (showLikedPlaylist) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onShowLikedPlaylistChange(!showLikedPlaylist) },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.offline),
                        title = { Text(stringResource(R.string.show_downloaded_playlist)) },
                        trailingContent = {
                            Switch(
                                checked = showDownloadedPlaylist,
                                onCheckedChange = onShowDownloadedPlaylistChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (showDownloadedPlaylist) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onShowDownloadedPlaylistChange(!showDownloadedPlaylist) },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.trending_up),
                        title = { Text(stringResource(R.string.show_top_playlist)) },
                        trailingContent = {
                            Switch(
                                checked = showTopPlaylist,
                                onCheckedChange = onShowTopPlaylistChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (showTopPlaylist) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onShowTopPlaylistChange(!showTopPlaylist) },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.cached),
                        title = { Text(stringResource(R.string.show_cached_playlist)) },
                        trailingContent = {
                            Switch(
                                checked = showCachedPlaylist,
                                onCheckedChange = onShowCachedPlaylistChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (showCachedPlaylist) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onShowCachedPlaylistChange(!showCachedPlaylist) },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.backup),
                        title = { Text(stringResource(R.string.show_uploaded_playlist)) },
                        trailingContent = {
                            Switch(
                                checked = showUploadedPlaylist,
                                onCheckedChange = onShowUploadedPlaylistChange,
                                thumbContent = {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id = if (showUploadedPlaylist) R.drawable.check else R.drawable.close,
                                            ),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                },
                            )
                        },
                        onClick = { onShowUploadedPlaylistChange(!showUploadedPlaylist) },
                    ),
                ),
        )
        Spacer(modifier = Modifier.height(32.dp))
    }
}

    if (showCustomPrimaryColorDialog) {
        CustomColorPickerDialog(
            initialColor = Color(selectedThemeColorInt),
            onColorSelected = { color ->
                onSelectedThemeColorChange(color.toArgb())
            },
            onDismiss = { showCustomPrimaryColorDialog = false }
        )
    }
}

enum class DarkMode {
    ON,
    OFF,
    AUTO,
}

enum class NavigationTab {
    HOME,
    SEARCH,
    LIBRARY,
    SAMPLES,
}

enum class LyricsPosition {
    LEFT,
    CENTER,
    RIGHT,
}

enum class PlayerTextAlignment {
    SIDED,
    CENTER,
}
