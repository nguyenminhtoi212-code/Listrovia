/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.unified

import com.listrovia.innertube.models.Album
import com.listrovia.innertube.models.Artist
import com.listrovia.innertube.models.SongItem
import com.listrovia.music.api.ExternalArtist
import com.listrovia.music.api.ExternalPlaylist
import com.listrovia.music.api.ExternalTrack
import com.listrovia.music.api.MusicCategory
import com.listrovia.music.api.MusicCountry
import com.listrovia.music.api.MusicSourceProvider
import kotlinx.serialization.Serializable

/**
 * Standardized Unified Track representation across all music providers (Spotify, Apple Music, YouTube).
 */
@Serializable
data class UnifiedTrack(
    val id: String,
    val title: String,
    val artist: String,
    val artists: List<String> = emptyList(),
    val album: String = "",
    val thumbnailUrl: String = "",
    val durationSeconds: Int? = null,
    val provider: MusicSourceProvider,
    val previewUrl: String? = null,
    val externalUrl: String? = null,
    val isExplicit: Boolean = false,
    val isrc: String? = null,
    val popularity: Int? = null,
    val releaseDate: String? = null,
    val countryCode: String = "vn",
    val categoryId: String = "all",
    val resolvedVideoId: String? = null,
) {
    val uniqueId: String
        get() {
            val prefix = when (provider) {
                MusicSourceProvider.APPLE_MUSIC -> "am_"
                MusicSourceProvider.YOUTUBE -> "yt_"
                else -> "ext_"
            }
            val cleanId = id.replace(Regex("[^a-zA-Z0-9_]"), "")
            return if (cleanId.startsWith("am_") || cleanId.startsWith("yt_")) {
                cleanId
            } else {
                "$prefix$cleanId"
            }
        }

    fun toSongItem(resolvedId: String? = null): SongItem {
        val targetId = resolvedId ?: resolvedVideoId ?: uniqueId
        val artistList = if (artists.isNotEmpty()) {
            artists.map { Artist(name = it, id = null) }
        } else {
            listOf(Artist(name = artist, id = null))
        }
        return SongItem(
            id = targetId,
            title = title,
            artists = artistList,
            album = if (album.isNotBlank()) Album(name = album, id = "") else null,
            duration = durationSeconds,
            thumbnail = thumbnailUrl,
            explicit = isExplicit
        )
    }

    fun toExternalTrack(): ExternalTrack {
        return ExternalTrack(
            id = id,
            title = title,
            artist = artist,
            album = album,
            thumbnailUrl = thumbnailUrl,
            durationSeconds = durationSeconds,
            provider = provider,
            previewUrl = previewUrl,
            externalUrl = externalUrl,
            isExplicit = isExplicit,
            resolvedVideoId = resolvedVideoId,
            countryCode = countryCode,
            categoryId = categoryId
        )
    }

    companion object {
        fun fromExternalTrack(track: ExternalTrack): UnifiedTrack {
            return UnifiedTrack(
                id = track.id,
                title = track.title,
                artist = track.artist,
                album = track.album,
                thumbnailUrl = track.thumbnailUrl,
                durationSeconds = track.durationSeconds,
                provider = track.provider,
                previewUrl = track.previewUrl,
                externalUrl = track.externalUrl,
                isExplicit = track.isExplicit,
                resolvedVideoId = track.resolvedVideoId,
                countryCode = track.countryCode,
                categoryId = track.categoryId
            )
        }
    }
}

/**
 * Standardized Unified Artist representation across all music providers.
 */
@Serializable
data class UnifiedArtist(
    val id: String,
    val name: String,
    val thumbnailUrl: String = "",
    val followers: String? = null,
    val genres: List<String> = emptyList(),
    val provider: MusicSourceProvider,
    val externalUrl: String? = null,
    val popularity: Int? = null,
) {
    fun toExternalArtist(): ExternalArtist {
        return ExternalArtist(
            id = id,
            name = name,
            thumbnailUrl = thumbnailUrl,
            followers = followers,
            genres = genres,
            provider = provider,
            externalUrl = externalUrl
        )
    }

    companion object {
        fun fromExternalArtist(artist: ExternalArtist): UnifiedArtist {
            return UnifiedArtist(
                id = artist.id,
                name = artist.name,
                thumbnailUrl = artist.thumbnailUrl,
                followers = artist.followers,
                genres = artist.genres,
                provider = artist.provider,
                externalUrl = artist.externalUrl
            )
        }
    }
}

/**
 * Standardized Unified Playlist representation across all music providers.
 */
@Serializable
data class UnifiedPlaylist(
    val id: String,
    val title: String,
    val description: String = "",
    val thumbnailUrl: String = "",
    val trackCount: Int? = null,
    val provider: MusicSourceProvider,
    val externalUrl: String? = null,
    val curator: String? = null,
) {
    fun toExternalPlaylist(): ExternalPlaylist {
        return ExternalPlaylist(
            id = id,
            title = title,
            description = description,
            thumbnailUrl = thumbnailUrl,
            trackCount = trackCount,
            provider = provider,
            externalUrl = externalUrl
        )
    }

    companion object {
        fun fromExternalPlaylist(playlist: ExternalPlaylist): UnifiedPlaylist {
            return UnifiedPlaylist(
                id = playlist.id,
                title = playlist.title,
                description = playlist.description,
                thumbnailUrl = playlist.thumbnailUrl,
                trackCount = playlist.trackCount,
                provider = playlist.provider,
                externalUrl = playlist.externalUrl
            )
        }
    }
}

/**
 * Aggregated search result container across unified sources.
 */
data class UnifiedSearchResult(
    val tracks: List<UnifiedTrack> = emptyList(),
    val artists: List<UnifiedArtist> = emptyList(),
    val playlists: List<UnifiedPlaylist> = emptyList(),
    val provider: MusicSourceProvider = MusicSourceProvider.ALL
)
