/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.api

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import timber.log.Timber
import java.io.File
import java.util.concurrent.TimeUnit

data class OpenRouterModelItem(
    val id: String,
    val name: String,
    val contextLength: Long = 0L,
    val pricing: String = "",
)

data class ClassifiedModels(
    val official: List<OpenRouterModelItem> = emptyList(),   // Phiên bản chính thức (Stable)
    val beta: List<OpenRouterModelItem> = emptyList(),       // Phiên bản thử nghiệm (Beta)
    val developer: List<OpenRouterModelItem> = emptyList(),  // Phiên bản nhà phát triển (Preview/Dev/Experimental)
)

data class MemoryCache(
    val timestamp: Long,
    val data: ClassifiedModels,
)

/**
 * Trình quản lý mô hình OpenRouter tự động tải trực tiếp theo thời gian thực từ
 * https://openrouter.ai/api/v1/models, phân loại và lưu cache bộ nhớ & lưu trữ ngoại tuyến.
 * Không sử dụng dữ liệu mô phỏng cứng (static mock).
 */
class OpenRouterModelManager(
    cacheTTLMinutes: Long = 15L,
    private val context: Context? = null,
) {
    private val apiUrl = "https://openrouter.ai/api/v1/models"
    private val storageKey = "openrouter_models_classified"
    private val cacheTTL = cacheTTLMinutes * 60 * 1000L
    private var _memoryCache: MemoryCache? = null

    private val client =
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .build()

    /**
     * Tải và phân loại danh sách mô hình AI theo thời gian thực từ OpenRouter API.
     */
    suspend fun fetchAndClassifyModels(forceRefresh: Boolean = false): ClassifiedModels =
        withContext(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            val cached = _memoryCache
            if (!forceRefresh && cached != null && (now - cached.timestamp < cacheTTL)) {
                return@withContext cached.data
            }

            try {
                val request =
                    Request.Builder()
                        .url(apiUrl)
                        .addHeader("HTTP-Referer", "https://listrovia.cc")
                        .addHeader("X-Title", "Listrovia Music")
                        .get()
                        .build()

                val response = client.newCall(request).execute()
                if (!response.isSuccessful) {
                    throw Exception("HTTP Error: ${response.code}")
                }

                val responseBody = response.body?.string() ?: throw Exception("Empty response body")
                val rawData = JSONObject(responseBody)
                val rawModels = rawData.optJSONArray("data") ?: JSONArray()

                val modelList = mutableListOf<RawModelData>()
                for (i in 0 until rawModels.length()) {
                    val obj = rawModels.optJSONObject(i) ?: continue
                    val id = obj.optString("id", "")
                    if (id.isBlank()) continue
                    val name = obj.optString("name", id)
                    val contextLength = obj.optLong("context_length", 0L)
                    val pricingObj = obj.optJSONObject("pricing")
                    val pricingStr = pricingObj?.toString() ?: ""
                    modelList.add(RawModelData(id = id, name = name, contextLength = contextLength, pricing = pricingStr))
                }

                val classified = _classifyModels(modelList)
                _clearMemory()

                val newMemory = MemoryCache(timestamp = now, data = classified)
                _memoryCache = newMemory
                saveToOfflineStorage(newMemory)

                return@withContext classified
            } catch (error: Exception) {
                Timber.w(error, "Lỗi kết nối hoặc tải dữ liệu OpenRouter. Đang lấy từ bộ nhớ đệm...")
                return@withContext _getOfflineFallback()
            }
        }

    private fun _classifyModels(models: List<RawModelData>): ClassifiedModels {
        val official = mutableListOf<OpenRouterModelItem>()
        val beta = mutableListOf<OpenRouterModelItem>()
        val developer = mutableListOf<OpenRouterModelItem>()

        models.forEach { model ->
            val id = model.id.lowercase()
            val name = (model.name ?: "").lowercase()

            val cleanedItem =
                OpenRouterModelItem(
                    id = model.id,
                    name = model.name.ifBlank { model.id },
                    contextLength = model.contextLength,
                    pricing = model.pricing,
                )

            if (id.contains("dev") || id.contains("preview") || id.contains("exp") || name.contains("developer")) {
                developer.add(cleanedItem)
            } else if (id.contains("beta") || name.contains("beta") || id.contains("free")) {
                beta.add(cleanedItem)
            } else {
                official.add(cleanedItem)
            }
        }

        return ClassifiedModels(
            official = official,
            beta = beta,
            developer = developer,
        )
    }

    fun _clearMemory() {
        _memoryCache = null
    }

    private fun _getOfflineFallback(): ClassifiedModels {
        try {
            val file = getCacheFile()
            if (file != null && file.exists()) {
                val saved = file.readText()
                if (saved.isNotBlank()) {
                    val parsed = JSONObject(saved)
                    val dataObj = parsed.optJSONObject("data")
                    if (dataObj != null) {
                        return parseClassifiedFromJson(dataObj)
                    }
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Lỗi đọc dữ liệu cache cũ từ bộ nhớ thiết bị")
        }

        return ClassifiedModels(
            official = emptyList(),
            beta = emptyList(),
            developer = emptyList(),
        )
    }

    private fun saveToOfflineStorage(cache: MemoryCache) {
        try {
            val file = getCacheFile() ?: return
            val root = JSONObject()
            root.put("timestamp", cache.timestamp)

            val dataObj = JSONObject()
            dataObj.put("official", modelListToJsonArray(cache.data.official))
            dataObj.put("beta", modelListToJsonArray(cache.data.beta))
            dataObj.put("developer", modelListToJsonArray(cache.data.developer))

            root.put("data", dataObj)
            file.writeText(root.toString())
        } catch (e: Exception) {
            Timber.e(e, "Không thể lưu bộ nhớ đệm offline vào file")
        }
    }

    private fun getCacheFile(): File? {
        val dir = context?.cacheDir ?: File(System.getProperty("java.io.tmpdir") ?: ".")
        return File(dir, "$storageKey.json")
    }

    private fun modelListToJsonArray(list: List<OpenRouterModelItem>): JSONArray {
        val arr = JSONArray()
        list.forEach { item ->
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("name", item.name)
            obj.put("contextLength", item.contextLength)
            obj.put("pricing", item.pricing)
            arr.put(obj)
        }
        return arr
    }

    private fun parseClassifiedFromJson(obj: JSONObject): ClassifiedModels {
        fun parseList(key: String): List<OpenRouterModelItem> {
            val arr = obj.optJSONArray(key) ?: return emptyList()
            val list = mutableListOf<OpenRouterModelItem>()
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                list.add(
                    OpenRouterModelItem(
                        id = item.optString("id"),
                        name = item.optString("name"),
                        contextLength = item.optLong("contextLength", 0L),
                        pricing = item.optString("pricing", ""),
                    ),
                )
            }
            return list
        }

        return ClassifiedModels(
            official = parseList("official"),
            beta = parseList("beta"),
            developer = parseList("developer"),
        )
    }

    suspend fun getModelsForApp(): List<OpenRouterModelItem> {
        val models = fetchAndClassifyModels()
        return models.official
    }

    suspend fun getModelsByTier(tier: String): List<OpenRouterModelItem> {
        val classified = fetchAndClassifyModels()
        return when (tier.lowercase()) {
            "beta" -> classified.beta
            "developer", "dev" -> classified.developer
            else -> classified.official
        }
    }

    suspend fun getRandomRecommendedModel(
        tier: String? = null,
        forceRefresh: Boolean = false,
    ): OpenRouterModelItem? {
        val classified = fetchAndClassifyModels(forceRefresh = forceRefresh)
        val pool = when (tier?.lowercase()) {
            "beta" -> classified.beta
            "developer", "dev" -> classified.developer
            "stable", "official" -> classified.official
            else -> classified.official + classified.beta + classified.developer
        }.filter { it.id.isNotBlank() }

        return pool.randomOrNull()
    }

    companion object {
        @Volatile
        private var defaultManager: OpenRouterModelManager? = null

        fun getInstance(context: Context? = null, cacheTTLMinutes: Long = 15L): OpenRouterModelManager {
            return defaultManager ?: synchronized(this) {
                defaultManager ?: OpenRouterModelManager(cacheTTLMinutes, context?.applicationContext).also {
                    defaultManager = it
                }
            }
        }

        suspend fun getModelsForApp(context: Context? = null): List<OpenRouterModelItem> {
            return getInstance(context).getModelsForApp()
        }
    }
}

private data class RawModelData(
    val id: String,
    val name: String,
    val contextLength: Long,
    val pricing: String,
)
