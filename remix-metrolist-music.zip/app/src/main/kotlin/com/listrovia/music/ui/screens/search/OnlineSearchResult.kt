/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.screens.search

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import com.listrovia.music.utils.pulltorefresh.PullToRefreshBox
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyItemScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.SavedStateHandle
import com.listrovia.music.LocalNavController
import com.listrovia.innertube.YouTube.SearchFilter.Companion.FILTER_ALBUM
import com.listrovia.innertube.YouTube.SearchFilter.Companion.FILTER_ARTIST
import com.listrovia.innertube.YouTube.SearchFilter.Companion.FILTER_COMMUNITY_PLAYLIST
import com.listrovia.innertube.YouTube.SearchFilter.Companion.FILTER_EPISODE
import com.listrovia.innertube.YouTube.SearchFilter.Companion.FILTER_FEATURED_PLAYLIST
import com.listrovia.innertube.YouTube.SearchFilter.Companion.FILTER_PODCAST
import com.listrovia.innertube.YouTube.SearchFilter.Companion.FILTER_PROFILE
import com.listrovia.innertube.YouTube.SearchFilter.Companion.FILTER_SONG
import com.listrovia.innertube.YouTube.SearchFilter.Companion.FILTER_VIDEO
import com.listrovia.innertube.models.AlbumItem
import com.listrovia.innertube.models.ArtistItem
import com.listrovia.innertube.models.EpisodeItem
import com.listrovia.innertube.models.PlaylistItem
import com.listrovia.innertube.models.PodcastItem
import com.listrovia.innertube.models.SongItem
import com.listrovia.innertube.models.WatchEndpoint
import com.listrovia.innertube.models.YTItem
import com.listrovia.music.LocalDatabase
import com.listrovia.music.LocalPlayerConnection
import com.listrovia.music.R
import com.listrovia.music.constants.AutoRadioQueueKey
import com.listrovia.music.constants.HideVideoSongsKey
import com.listrovia.music.constants.MiniPlayerBottomSpacing
import com.listrovia.music.constants.MiniPlayerHeight
import com.listrovia.music.constants.NavigationBarHeight
import com.listrovia.music.constants.PauseSearchHistoryKey
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import com.listrovia.music.api.ExternalArtist
import com.listrovia.music.api.ExternalPlaylist
import com.listrovia.music.api.ExternalTrack
import com.listrovia.music.api.MusicSourceProvider
import com.listrovia.music.db.entities.SearchHistory
import com.listrovia.music.extensions.toMediaItem
import com.listrovia.music.models.toMediaMetadata
import com.listrovia.music.playback.queues.ListQueue
import com.listrovia.music.playback.queues.YouTubeQueue
import com.listrovia.music.ui.component.ChipsRow
import com.listrovia.music.ui.component.EmptyPlaceholder
import com.listrovia.music.ui.component.ExternalArtistItem
import com.listrovia.music.ui.component.ExternalPlaylistItem
import com.listrovia.music.ui.component.ExternalTrackItem
import com.listrovia.music.ui.component.HideOnScrollFAB
import com.listrovia.music.ui.component.LocalMenuState
import com.listrovia.music.ui.component.NavigationTitle
import com.listrovia.music.ui.component.YouTubeListItem
import com.listrovia.music.ui.component.ItemThumbnail
import com.listrovia.music.constants.ThumbnailCornerRadius
import androidx.compose.material3.Surface
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.text.style.TextOverflow
import com.listrovia.music.ui.component.shimmer.ListItemPlaceHolder
import com.listrovia.music.ui.component.shimmer.ShimmerHost
import com.listrovia.music.ui.menu.YouTubeAlbumMenu
import com.listrovia.music.ui.menu.YouTubeArtistMenu
import com.listrovia.music.ui.menu.YouTubePlaylistMenu
import com.listrovia.music.ui.menu.YouTubeSongMenu
import com.listrovia.music.utils.SearchRoutes
import com.listrovia.music.utils.rememberPreference
import com.listrovia.music.viewmodels.OnlineSearchViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun OnlineSearchResult(
    viewModel: OnlineSearchViewModel = hiltViewModel(),
    pureBlack: Boolean = false,
    savedStateHandle: SavedStateHandle? = null
) {
    val navController = LocalNavController.current
    val database = LocalDatabase.current
    val menuState = LocalMenuState.current
    val playerConnection = LocalPlayerConnection.current ?: return
    val haptic = LocalHapticFeedback.current
    val isPlaying by playerConnection.isEffectivelyPlaying.collectAsStateWithLifecycle()
    val mediaMetadata by playerConnection.mediaMetadata.collectAsStateWithLifecycle()

    val coroutineScope = rememberCoroutineScope()
    val lazyListState = rememberLazyListState()
    val focusManager = LocalFocusManager.current
    val focusRequester = remember { FocusRequester() }
    val scrollToTopCount by savedStateHandle
        ?.getStateFlow("scrollToTopCount", 0)
        ?.collectAsStateWithLifecycle(initialValue = 0) ?: remember { mutableIntStateOf(0) }

    var lastHandledCount by rememberSaveable { mutableIntStateOf(0) }
    var isSearchFocused by remember { mutableStateOf(false) }
    val keyboardController = LocalSoftwareKeyboardController.current

    LaunchedEffect(scrollToTopCount) {
        if (scrollToTopCount > lastHandledCount) {
            lastHandledCount = scrollToTopCount
            kotlinx.coroutines.delay(100)
            try {
                focusRequester.requestFocus()
                keyboardController?.show()
            } catch (e: Exception) {
            }
            // Set focused AFTER requesting focus, not before

            isSearchFocused = true
        }
    }

    val pauseSearchHistory by rememberPreference(PauseSearchHistoryKey, defaultValue = false)
    val hideVideoSongs by rememberPreference(HideVideoSongsKey, defaultValue = false)
    val autoRadioQueue by rememberPreference(AutoRadioQueueKey, defaultValue = false)

    BackHandler(enabled = isSearchFocused) {
        isSearchFocused = false
        focusManager.clearFocus()
    }

    // Extract query from navigation arguments
    val encodedQuery = navController.currentBackStackEntry?.arguments?.getString("query") ?: ""
    val decodedQuery = remember(encodedQuery) { SearchRoutes.decodeQuery(encodedQuery) }

    var query by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(decodedQuery, TextRange(decodedQuery.length)))
    }

    val onSearch: (String) -> Unit =
        remember {
            { searchQuery ->
                if (searchQuery.isNotEmpty()) {
                    isSearchFocused = false
                    focusManager.clearFocus()

                    navController.navigate(SearchRoutes.resultRoute(searchQuery)) {
                        popUpTo(SearchRoutes.ROUTE) {
                            inclusive = true
                        }

                        if (!pauseSearchHistory) {
                            coroutineScope.launch(Dispatchers.IO) {
                                database.query {
                                    insert(SearchHistory(query = searchQuery))
                                }
                            }
                        }
                    }
                }
            }
        }

    // Update query when decodedQuery changes
    LaunchedEffect(decodedQuery) {
        query = TextFieldValue(decodedQuery, TextRange(decodedQuery.length))
    }

    // Clear video filter if hideVideoSongs setting is enabled and filter is set to FILTER_VIDEO
    LaunchedEffect(hideVideoSongs) {
        if (hideVideoSongs && viewModel.filter.value == FILTER_VIDEO) {
            viewModel.filter.value = null
        }
    }

    val searchFilter by viewModel.filter.collectAsStateWithLifecycle()
    val searchSummary = viewModel.summaryPage
    val currentProvider by viewModel.provider.collectAsStateWithLifecycle()
    val appleMusicResults by viewModel.appleMusicResults.collectAsStateWithLifecycle()
    val appleMusicArtists by viewModel.appleMusicArtists.collectAsStateWithLifecycle()
    val appleMusicPlaylists by viewModel.appleMusicPlaylists.collectAsStateWithLifecycle()
    val isExternalLoading by viewModel.isExternalLoading.collectAsStateWithLifecycle()
    val itemsPage by remember(searchFilter) {
        derivedStateOf {
            searchFilter?.value?.let {
                viewModel.viewStateMap[it]
            }
        }
    }

    LaunchedEffect(lazyListState) {
        snapshotFlow {
            lazyListState.layoutInfo.visibleItemsInfo.any { it.key == "loading" }
        }.collect { shouldLoadMore ->
            if (!shouldLoadMore) return@collect
            viewModel.loadMore()
        }
    }

    val ytItemContent: @Composable LazyItemScope.(YTItem) -> Unit = { item: YTItem ->
        val longClick = {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            menuState.show {
                when (item) {
                    is SongItem -> {
                        YouTubeSongMenu(
                            song = item,
                            onDismiss = menuState::dismiss,
                        )
                    }

                    is AlbumItem -> {
                        YouTubeAlbumMenu(
                            albumItem = item,
                            onDismiss = menuState::dismiss,
                        )
                    }

                    is ArtistItem -> {
                        YouTubeArtistMenu(
                            artist = item,
                            onDismiss = menuState::dismiss,
                        )
                    }

                    is PlaylistItem -> {
                        YouTubePlaylistMenu(
                            playlist = item,
                            coroutineScope = coroutineScope,
                            onDismiss = menuState::dismiss,
                        )
                    }

                    is PodcastItem -> {
                        YouTubePlaylistMenu(
                            playlist = item.asPlaylistItem(),
                            coroutineScope = coroutineScope,
                            onDismiss = menuState::dismiss,
                        )
                    }

                    is EpisodeItem -> {
                        YouTubeSongMenu(
                            song = item.asSongItem(),
                            onDismiss = menuState::dismiss,
                        )
                    }
                }
            }
        }
        YouTubeListItem(
            item = item,
            isActive =
                when (item) {
                    is SongItem -> mediaMetadata?.id == item.id
                    is AlbumItem -> mediaMetadata?.album?.id == item.id
                    is EpisodeItem -> mediaMetadata?.id == item.id
                    else -> false
                },
            isPlaying = isPlaying,
            trailingContent = {
                IconButton(
                    onClick = longClick,
                ) {
                    Icon(
                        painter = painterResource(R.drawable.more_vert),
                        contentDescription = null,
                    )
                }
            },
            modifier =
                Modifier
                    .combinedClickable(
                        onClick = {
                            when (item) {
                                is SongItem -> {
                                    if (item.id == mediaMetadata?.id) {
                                        playerConnection.togglePlayPause()
                                    } else {
                                        playerConnection.playQueue(
                                            if (autoRadioQueue) {
                                                YouTubeQueue(
                                                    WatchEndpoint(videoId = item.id),
                                                    item.toMediaMetadata(),
                                                )
                                            } else {
                                                ListQueue(
                                                    title = item.title,
                                                    items = listOf(item.toMediaItem())
                                                )
                                            }
                                        )
                                    }
                                }

                                is AlbumItem -> {
                                    navController.navigate("album/${item.id}")
                                }

                                is ArtistItem -> {
                                    navController.navigate("artist/${item.id}")
                                }

                                is PlaylistItem -> {
                                    navController.navigate("online_playlist/${item.id}")
                                }

                                is PodcastItem -> {
                                    navController.navigate("online_podcast/${android.net.Uri.encode(item.id)}")
                                }

                                is EpisodeItem -> {
                                    if (item.id == mediaMetadata?.id) {
                                        playerConnection.togglePlayPause()
                                    } else {
                                        playerConnection.playQueue(
                                            YouTubeQueue(
                                                WatchEndpoint(videoId = item.id),
                                                item.toMediaMetadata(),
                                            ),
                                        )
                                    }
                                }
                            }
                        },
                        onLongClick = longClick,
                    ).animateItem(),
        )
    }

    Column(
        modifier =
            Modifier
                .fillMaxSize()
                .background(if (pureBlack) Color.Black else MaterialTheme.colorScheme.background)
                .windowInsetsPadding(WindowInsets.systemBars.only(WindowInsetsSides.Top)),
    ) {
        // Google-style SearchBar with Material 3 design
        OutlinedTextField(
            value = query,
            onValueChange = { newQuery ->
                query = newQuery
            },
            placeholder = {
                Text(
                    text = stringResource(R.string.search_yt_music),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            },
            leadingIcon = {
                IconButton(
                    onClick = { navController.navigateUp() },
                ) {
                    Icon(
                        painter = painterResource(R.drawable.arrow_back),
                        contentDescription = stringResource(R.string.dismiss),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            },
            trailingIcon = {
                if (query.text.isNotEmpty()) {
                    IconButton(
                        onClick = {
                            query = TextFieldValue("")
                        },
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.close),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            },
            keyboardOptions =
                KeyboardOptions(
                    imeAction = ImeAction.Search,
                ),
            keyboardActions =
                KeyboardActions(
                    onSearch = {
                        onSearch(query.text)
                    },
                ),
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            colors =
                OutlinedTextFieldDefaults.colors(
                    focusedContainerColor =
                        if (pureBlack) {
                            MaterialTheme.colorScheme.surface
                        } else {
                            MaterialTheme.colorScheme.surfaceContainerHigh
                        },
                    unfocusedContainerColor =
                        if (pureBlack) {
                            MaterialTheme.colorScheme.surface
                        } else {
                            MaterialTheme.colorScheme.surfaceContainerHigh
                        },
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                ),
            modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .focusRequester(focusRequester)
                    .onFocusChanged { focusState ->
                        if (focusState.isFocused) {
                            isSearchFocused = true
                        }
                    },
        )

        // Main content area below search bar
        PullToRefreshBox(
            isRefreshing = isExternalLoading && currentProvider == MusicSourceProvider.APPLE_MUSIC,
            onRefresh = { viewModel.forceRefreshAppleMusic() },
            enabled = currentProvider == MusicSourceProvider.APPLE_MUSIC,
            modifier = Modifier.weight(1f),
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                ) {
                val providerChips = listOf(
                    MusicSourceProvider.ALL to stringResource(R.string.search_source_all),
                    MusicSourceProvider.YOUTUBE to stringResource(R.string.search_source_youtube),
                    MusicSourceProvider.APPLE_MUSIC to stringResource(R.string.search_source_apple_music),
                )

                ChipsRow(
                    chips = providerChips,
                    currentValue = currentProvider,
                    onValueUpdate = {
                        if (viewModel.provider.value != it) {
                            viewModel.provider.value = it
                            viewModel.filter.value = null
                        }
                        coroutineScope.launch {
                            lazyListState.animateScrollToItem(0)
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )

                val visibleChips = if (currentProvider == MusicSourceProvider.APPLE_MUSIC) {
                    listOf(
                        null to stringResource(R.string.filter_all),
                        FILTER_SONG to stringResource(R.string.filter_songs),
                        FILTER_ARTIST to stringResource(R.string.filter_artists),
                        FILTER_ALBUM to stringResource(R.string.filter_albums),
                    )
                } else {
                    listOf(
                        null to stringResource(R.string.filter_all),
                        FILTER_SONG to stringResource(R.string.filter_songs),
                    ).let { baseChips ->
                        if (!hideVideoSongs) {
                            baseChips + (FILTER_VIDEO to stringResource(R.string.filter_videos))
                        } else {
                            baseChips
                        }
                    } +
                        listOf(
                            FILTER_ALBUM to stringResource(R.string.filter_albums),
                            FILTER_ARTIST to stringResource(R.string.filter_artists),
                            FILTER_COMMUNITY_PLAYLIST to stringResource(R.string.filter_community_playlists),
                            FILTER_FEATURED_PLAYLIST to stringResource(R.string.filter_featured_playlists),
                            FILTER_PODCAST to stringResource(R.string.filter_podcasts),
                            FILTER_EPISODE to stringResource(R.string.filter_episodes),
                            FILTER_PROFILE to stringResource(R.string.filter_profiles),
                        )
                }

                ChipsRow(
                    chips = visibleChips,
                    currentValue = searchFilter,
                    onValueUpdate = {
                        if (viewModel.filter.value != it) {
                            viewModel.filter.value = it
                        }
                        coroutineScope.launch {
                            lazyListState.animateScrollToItem(0)
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )

                AnimatedContent(
                    targetState = Triple(decodedQuery, searchFilter, currentProvider),
                    transitionSpec = {
                        fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(180))
                    },
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    label = "SearchTransition"
                ) { (queryState, filterState, providerState) ->
                    LazyColumn(
                        state = lazyListState,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                    if (providerState == MusicSourceProvider.APPLE_MUSIC) {
                        item {
                            NavigationTitle(stringResource(R.string.search_source_apple_music))
                        }
                        if (isExternalLoading && appleMusicResults == null && appleMusicArtists == null) {
                            item {
                                ShimmerHost {
                                    repeat(6) {
                                        ListItemPlaceHolder()
                                    }
                                }
                            }
                        } else {
                            if (filterState == null || filterState == FILTER_ARTIST) {
                                if (!appleMusicArtists.isNullOrEmpty()) {
                                    if (filterState == null) {
                                        item {
                                            NavigationTitle("Nghệ sĩ Apple Music")
                                        }
                                    }
                                    if (filterState == FILTER_ARTIST) {
                                        items(
                                            items = appleMusicArtists.orEmpty(),
                                            key = { "am_artist_vertical_${it.id}" }
                                        ) { artist ->
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable {
                                                        navController.navigate("artist/${if (artist.id.startsWith("am_")) artist.id else "am_${artist.name.lowercase().replace(" ", "_")}"}")
                                                    }
                                                    .padding(horizontal = 16.dp, vertical = 8.dp)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(56.dp)
                                                        .clip(CircleShape)
                                                ) {
                                                    ItemThumbnail(
                                                        thumbnailUrl = artist.thumbnailUrl,
                                                        isActive = false,
                                                        isPlaying = false,
                                                        shape = CircleShape,
                                                        modifier = Modifier.fillMaxSize()
                                                    )
                                                    
                                                    Surface(
                                                        shape = CircleShape,
                                                        color = Color.Black.copy(alpha = 0.65f),
                                                        modifier = Modifier
                                                            .align(Alignment.BottomEnd)
                                                            .size(18.dp)
                                                    ) {
                                                        Icon(
                                                            painter = painterResource(R.drawable.ic_apple_music),
                                                            contentDescription = "Apple Music",
                                                            tint = Color.Unspecified,
                                                            modifier = Modifier.padding(3.dp)
                                                        )
                                                    }
                                                }
                                                Spacer(modifier = Modifier.width(16.dp))
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = artist.name,
                                                        style = MaterialTheme.typography.titleMedium,
                                                        fontWeight = FontWeight.Bold,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                    Text(
                                                        text = artist.followers ?: "Apple Music Artist",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                        }
                                    } else {
                                        item {
                                            LazyRow(
                                                contentPadding = PaddingValues(horizontal = 16.dp),
                                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                                modifier = Modifier.padding(bottom = 12.dp)
                                            ) {
                                                items(
                                                    items = appleMusicArtists.orEmpty(),
                                                    key = { "am_artist_${it.id}" }
                                                ) { artist ->
                                                    ExternalArtistItem(
                                                        artist = artist,
                                                        onClick = { navController.navigate("artist/${if (artist.id.startsWith("am_")) artist.id else "am_${artist.name.lowercase().replace(" ", "_")}"}") }
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            if (filterState == null || filterState == FILTER_SONG) {
                                if (!appleMusicResults.isNullOrEmpty()) {
                                    if (filterState == null) {
                                        item {
                                            NavigationTitle("Bài hát Apple Music")
                                        }
                                    }
                                    items(
                                        items = appleMusicResults.orEmpty(),
                                        key = { "ap_${it.id}" }
                                    ) { track ->
                                        ExternalTrackItem(
                                            track = track,
                                            externalService = viewModel.externalMusicProviderService,
                                            onArtistClick = { artistName -> navController.navigate("artist/am_${artistName.lowercase().replace(" ", "_")}") },
                                            onResolveVideoId = { viewModel.resolveVideoId(it) }
                                        )
                                    }
                                }
                            }

                            if (filterState == null || filterState == FILTER_ALBUM) {
                                if (!appleMusicPlaylists.isNullOrEmpty()) {
                                    if (filterState == null) {
                                        item {
                                            NavigationTitle("Danh sách phát Apple Music")
                                        }
                                    }
                                    if (filterState == FILTER_ALBUM) {
                                        items(
                                            items = appleMusicPlaylists.orEmpty(),
                                            key = { "am_pl_vertical_${it.id}" }
                                        ) { playlist ->
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable {
                                                        navController.navigate("online_playlist/${playlist.id}")
                                                    }
                                                    .padding(horizontal = 16.dp, vertical = 8.dp)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(56.dp)
                                                        .clip(RoundedCornerShape(ThumbnailCornerRadius))
                                                ) {
                                                    ItemThumbnail(
                                                        thumbnailUrl = playlist.thumbnailUrl,
                                                        isActive = false,
                                                        isPlaying = false,
                                                        shape = RoundedCornerShape(ThumbnailCornerRadius),
                                                        modifier = Modifier.fillMaxSize()
                                                    )
                                                    
                                                    Surface(
                                                        shape = CircleShape,
                                                        color = Color.Black.copy(alpha = 0.65f),
                                                        modifier = Modifier
                                                            .align(Alignment.BottomEnd)
                                                            .size(18.dp)
                                                    ) {
                                                        Icon(
                                                            painter = painterResource(R.drawable.ic_apple_music),
                                                            contentDescription = "Apple Music",
                                                            tint = Color.Unspecified,
                                                            modifier = Modifier.padding(3.dp)
                                                        )
                                                    }
                                                }
                                                Spacer(modifier = Modifier.width(16.dp))
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = playlist.title,
                                                        style = MaterialTheme.typography.titleMedium,
                                                        fontWeight = FontWeight.Bold,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                    Text(
                                                        text = playlist.description.ifBlank { "Apple Music Playlist" },
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                }
                                            }
                                        }
                                    } else {
                                        item {
                                            LazyRow(
                                                contentPadding = PaddingValues(horizontal = 16.dp),
                                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                                modifier = Modifier.padding(bottom = 12.dp)
                                            ) {
                                                items(
                                                    items = appleMusicPlaylists.orEmpty(),
                                                    key = { "am_pl_${it.id}" }
                                                ) { playlist ->
                                                    ExternalPlaylistItem(
                                                        playlist = playlist,
                                                        onClick = { navController.navigate("online_playlist/${playlist.id}") }
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            val filterEmpty = when (filterState) {
                                FILTER_ARTIST -> appleMusicArtists.isNullOrEmpty()
                                FILTER_SONG -> appleMusicResults.isNullOrEmpty()
                                FILTER_ALBUM -> appleMusicPlaylists.isNullOrEmpty()
                                else -> appleMusicResults.isNullOrEmpty() && appleMusicArtists.isNullOrEmpty() && appleMusicPlaylists.isNullOrEmpty()
                            }

                            if (filterEmpty) {
                                item {
                                    EmptyPlaceholder(
                                        icon = R.drawable.search,
                                        text = stringResource(R.string.no_results_found),
                                    )
                                }
                            }
                        }
                    } else if (filterState == null) {
                        // In ALL mode with All filter, also show Apple Music artists & tracks highlights if available!
                        if (!appleMusicArtists.isNullOrEmpty()) {
                            item {
                                NavigationTitle("Nghệ sĩ Apple Music")
                            }
                            item {
                                LazyRow(
                                    contentPadding = PaddingValues(horizontal = 16.dp),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    modifier = Modifier.padding(bottom = 12.dp)
                                ) {
                                    items(
                                        items = appleMusicArtists.orEmpty().take(8),
                                        key = { "all_am_artist_${it.id}" }
                                    ) { artist ->
                                        ExternalArtistItem(
                                            artist = artist,
                                            onClick = { navController.navigate("artist/${if (artist.id.startsWith("am_")) artist.id else "am_${artist.name.lowercase().replace(" ", "_")}"}") }
                                        )
                                    }
                                }
                            }
                        }

                        if (!appleMusicResults.isNullOrEmpty()) {
                            item {
                                NavigationTitle(stringResource(R.string.apple_music_top_hits))
                            }
                            items(
                                items = appleMusicResults.orEmpty().take(4),
                                key = { "all_ap_${it.id}" }
                            ) { track ->
                                ExternalTrackItem(
                                    track = track,
                                    externalService = viewModel.externalMusicProviderService,
                                    onArtistClick = { artistName -> navController.navigate("artist/am_${artistName.lowercase().replace(" ", "_")}") },
                                    onResolveVideoId = { viewModel.resolveVideoId(it) }
                                )
                            }
                        }

                        searchSummary?.summaries?.forEach { summary ->
                            item {
                                NavigationTitle(summary.title)
                            }

                            itemsIndexed(
                                items = summary.items,
                                key = { index, item -> "${summary.title}/${item.id}/$index" },
                                itemContent = { index, item -> ytItemContent(item) },
                            )
                        }

                        if (searchSummary?.summaries?.isEmpty() == true && appleMusicResults.isNullOrEmpty()) {
                            item {
                                EmptyPlaceholder(
                                    icon = R.drawable.search,
                                    text = stringResource(R.string.no_results_found),
                                )
                            }
                        }
                    } else {
                        items(
                            items = itemsPage?.items.orEmpty().distinctBy { it.id },
                            key = { "filtered_${it.id}" },
                            itemContent = ytItemContent,
                        )

                        if (itemsPage?.continuation != null) {
                            item(key = "loading") {
                                ShimmerHost {
                                    repeat(3) {
                                        ListItemPlaceHolder()
                                    }
                                }
                            }
                        }

                        if (itemsPage?.items?.isEmpty() == true) {
                            item {
                                EmptyPlaceholder(
                                    icon = R.drawable.search,
                                    text = stringResource(R.string.no_results_found),
                                )
                            }
                        }
                    }

                    if (filterState == null && searchSummary == null || filterState != null && itemsPage == null) {
                        item {
                            ShimmerHost {
                                repeat(8) {
                                    ListItemPlaceHolder()
                                }
                            }
                        }
                    }

                    item(key = "bottom_spacer") {
                        Spacer(modifier = Modifier.height(MiniPlayerHeight + MiniPlayerBottomSpacing + NavigationBarHeight))
                    }
                  }
                }
            }
            if (isSearchFocused) {
                OnlineSearchScreen(
                    query = query.text,
                    onQueryChange = { query = it },
                    onSearch = onSearch,
                    onDismiss = {
                        isSearchFocused = false
                        focusManager.clearFocus()
                    },
                    pureBlack = pureBlack,
                )
            }
        }
    }
}
}
