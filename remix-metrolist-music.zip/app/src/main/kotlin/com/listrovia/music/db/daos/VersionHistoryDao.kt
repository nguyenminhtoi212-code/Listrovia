/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.db.daos

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Upsert
import com.listrovia.music.db.entities.VersionHistoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface VersionHistoryDao {
    @Query("SELECT * FROM version_history ORDER BY installedAt DESC, version DESC")
    fun getAllVersionHistory(): Flow<List<VersionHistoryEntity>>

    @Query("SELECT * FROM version_history WHERE version = :version LIMIT 1")
    suspend fun getVersionHistory(version: String): VersionHistoryEntity?

    @Upsert
    suspend fun upsertVersionHistory(versionHistory: VersionHistoryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(versionHistories: List<VersionHistoryEntity>)

    @Query("DELETE FROM version_history WHERE version = :version")
    suspend fun deleteVersionHistory(version: String)

    @Query("DELETE FROM version_history")
    suspend fun clearVersionHistory()

    @Query("UPDATE version_history SET isCurrent = 0")
    suspend fun resetCurrentVersion()

    @Query("UPDATE version_history SET isCurrent = 1 WHERE version = :version OR versionName = :version")
    suspend fun markCurrentVersion(version: String)

    @Query("SELECT COUNT(*) FROM version_history")
    suspend fun getCount(): Int
}
