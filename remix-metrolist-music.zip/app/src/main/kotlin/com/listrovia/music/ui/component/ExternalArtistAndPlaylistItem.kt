/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.component

import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.listrovia.music.R
import com.listrovia.music.api.ExternalArtist
import com.listrovia.music.api.ExternalPlaylist
import com.listrovia.music.api.MusicSourceProvider
import com.listrovia.music.constants.ThumbnailCornerRadius

@Composable
fun ExternalPlaylistItem(
    playlist: ExternalPlaylist,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
) {
    GridItem(
        modifier = modifier.clickable { onClick?.invoke() },
        title = {
            Text(
                text = playlist.title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.basicMarquee().fillMaxWidth()
            )
        },
        subtitle = {
            val descriptionText = playlist.description.ifBlank {
                if (playlist.provider == MusicSourceProvider.APPLE_MUSIC) "Apple Music" else "YouTube Music"
            }
            Text(
                text = descriptionText,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.secondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        },
        thumbnailContent = {
            ItemThumbnail(
                thumbnailUrl = playlist.thumbnailUrl,
                isActive = false,
                isPlaying = false,
                shape = RoundedCornerShape(ThumbnailCornerRadius),
                title = playlist.title,
            )

            val isApple = playlist.provider == MusicSourceProvider.APPLE_MUSIC || playlist.id.startsWith("am_")
            val badgeIcon = if (isApple) R.drawable.ic_apple_music else R.drawable.ic_launcher_logo
            Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.65f),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(4.dp)
                    .size(20.dp)
            ) {
                Icon(
                    painter = painterResource(badgeIcon),
                    contentDescription = if (isApple) "Apple Music" else "YouTube Music",
                    tint = Color.Unspecified,
                    modifier = Modifier.padding(3.dp)
                )
            }
        }
    )
}

@Composable
fun ExternalArtistItem(
    artist: ExternalArtist,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
) {
    GridItem(
        modifier = modifier.clickable { onClick?.invoke() },
        title = {
            Text(
                text = artist.name,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.basicMarquee().fillMaxWidth()
            )
        },
        subtitle = {
            val subtext = artist.followers ?: artist.genres.firstOrNull() ?: ""
            if (subtext.isNotBlank()) {
                Text(
                    text = subtext,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.secondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        thumbnailContent = {
            ItemThumbnail(
                thumbnailUrl = artist.thumbnailUrl,
                isActive = false,
                isPlaying = false,
                shape = CircleShape,
                title = artist.name,
            )

            val isApple = artist.provider == MusicSourceProvider.APPLE_MUSIC || artist.id.startsWith("am_")
            val badgeIcon = if (isApple) R.drawable.ic_apple_music else R.drawable.ic_launcher_logo
            Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.65f),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(4.dp)
                    .size(20.dp)
            ) {
                Icon(
                    painter = painterResource(badgeIcon),
                    contentDescription = if (isApple) "Apple Music" else "YouTube Music",
                    tint = Color.Unspecified,
                    modifier = Modifier.padding(3.dp)
                )
            }
        }
    )
}
