/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.component

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.listrovia.music.R
import com.listrovia.music.api.ExternalArtist
import com.listrovia.music.api.ExternalPlaylist
import com.listrovia.music.api.MusicSourceProvider

import com.listrovia.music.ui.component.ItemThumbnail
import com.listrovia.music.constants.ThumbnailCornerRadius

@Composable
fun ExternalPlaylistItem(
    playlist: ExternalPlaylist,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
) {
    Column(
        modifier = modifier
            .width(160.dp)
            .clip(RoundedCornerShape(ThumbnailCornerRadius))
            .clickable {
                if (onClick != null) {
                    onClick()
                }
            }
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(152.dp)
                .clip(RoundedCornerShape(ThumbnailCornerRadius))
        ) {
            ItemThumbnail(
                thumbnailUrl = playlist.thumbnailUrl,
                isActive = false,
                isPlaying = false,
                shape = RoundedCornerShape(ThumbnailCornerRadius),
                modifier = Modifier.fillMaxSize()
            )

            // Provider tag badge
            val isApple = playlist.provider == MusicSourceProvider.APPLE_MUSIC || playlist.id.startsWith("am_")
            val badgeIcon = if (isApple) R.drawable.ic_apple_music else R.drawable.ic_launcher_logo
            Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.65f),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .size(24.dp)
            ) {
                Icon(
                    painter = painterResource(badgeIcon),
                    contentDescription = if (isApple) "Apple Music" else "YouTube Music",
                    tint = Color.Unspecified,
                    modifier = Modifier.padding(4.dp)
                )
            }
        }

        Spacer(Modifier.height(10.dp))

        Text(
            text = playlist.title,
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 4.dp)
        )

        if (playlist.description.isNotBlank()) {
            Text(
                text = playlist.description,
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
        }
    }
}

@Composable
fun ExternalArtistItem(
    artist: ExternalArtist,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .width(110.dp)
            .clip(RoundedCornerShape(ThumbnailCornerRadius))
            .clickable {
                if (onClick != null) {
                    onClick()
                }
            }
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(100.dp)
                .clip(CircleShape)
        ) {
            ItemThumbnail(
                thumbnailUrl = artist.thumbnailUrl,
                isActive = false,
                isPlaying = false,
                shape = CircleShape,
                modifier = Modifier.fillMaxSize()
            )

            val isApple = artist.provider == MusicSourceProvider.APPLE_MUSIC || artist.id.startsWith("am_")
            val badgeIcon = if (isApple) R.drawable.ic_apple_music else R.drawable.ic_launcher_logo
            Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.65f),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(22.dp)
            ) {
                Icon(
                    painter = painterResource(badgeIcon),
                    contentDescription = if (isApple) "Apple Music" else "YouTube Music",
                    tint = Color.Unspecified,
                    modifier = Modifier.padding(4.dp)
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        Text(
            text = artist.name,
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 2.dp)
        )

        val subtext = artist.followers ?: artist.genres.firstOrNull()
        if (!subtext.isNullOrBlank()) {
            Text(
                text = subtext,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
