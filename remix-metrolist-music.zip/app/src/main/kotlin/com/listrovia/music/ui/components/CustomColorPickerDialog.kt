package com.listrovia.music.ui.components

import android.graphics.Color as AndroidColor
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.materialkolor.PaletteStyle
import com.materialkolor.rememberDynamicColorScheme
import com.listrovia.music.R
import com.listrovia.music.ui.theme.DefaultThemeColor

val PresetCustomColors = listOf(
    Color(0xFF6750A4), // M3 Default Purple
    Color(0xFFEC5464), // Crimson Red
    Color(0xFFD81B60), // Rose
    Color(0xFF9C27B0), // Magenta
    Color(0xFF673AB7), // Deep Violet
    Color(0xFF3949AB), // Indigo
    Color(0xFF1E88E5), // Electric Blue
    Color(0xFF00ACC1), // Vibrant Cyan
    Color(0xFF00897B), // Emerald Teal
    Color(0xFF43A047), // Vivid Green
    Color(0xFF7CB342), // Lime Green
    Color(0xFFFFB300), // Amber Gold
    Color(0xFFFB8C00), // Sunset Orange
    Color(0xFFF4511E), // Deep Orange
    Color(0xFFE91E63), // Hot Pink
    Color(0xFF00BCD4), // Sky Blue
)

@Composable
fun CustomColorPickerDialog(
    initialColor: Color = DefaultThemeColor,
    onColorSelected: (Color) -> Unit,
    onDismiss: () -> Unit
) {
    var currentColor by remember { mutableStateOf(initialColor) }
    
    // HSV state
    val initialHsv = remember(initialColor) {
        FloatArray(3).apply { AndroidColor.colorToHSV(initialColor.toArgb(), this) }
    }
    var hue by remember { mutableFloatStateOf(initialHsv[0]) }
    var saturation by remember { mutableFloatStateOf(initialHsv[1]) }
    var value by remember { mutableFloatStateOf(initialHsv[2]) }
    
    var hexInput by remember(currentColor) {
        mutableStateOf(String.format("#%06X", 0xFFFFFF and currentColor.toArgb()))
    }
    var isHexError by remember { mutableStateOf(false) }

    val focusManager = LocalFocusManager.current
    val animatedCurrentColor by animateColorAsState(targetValue = currentColor, label = "colorAnimation")

    fun updateFromHsv(h: Float, s: Float, v: Float) {
        hue = h
        saturation = s
        value = v
        val hsvArray = floatArrayOf(h, s, v)
        val argb = AndroidColor.HSVToColor(hsvArray)
        currentColor = Color(argb)
        hexInput = String.format("#%06X", 0xFFFFFF and argb)
        isHexError = false
    }

    fun updateFromHex(hex: String) {
        hexInput = hex
        val cleanedHex = hex.removePrefix("#").trim()
        if (cleanedHex.length == 6) {
            try {
                val parsedColorInt = android.graphics.Color.parseColor("#$cleanedHex")
                val newColor = Color(parsedColorInt)
                currentColor = newColor
                val hsvArr = FloatArray(3).apply { AndroidColor.colorToHSV(parsedColorInt, this) }
                hue = hsvArr[0]
                saturation = hsvArr[1]
                value = hsvArr[2]
                isHexError = false
            } catch (e: Exception) {
                isHexError = true
            }
        } else {
            isHexError = cleanedHex.isNotEmpty()
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .clip(RoundedCornerShape(28.dp)),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Dialog Title & Live Preview Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = stringResource(R.string.custom_primary_color_title),
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = stringResource(R.string.pick_seed_color_desc),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    // Color Preview Badge
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(animatedCurrentColor)
                            .border(2.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                    )
                }

                // Preset Swatches Grid
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = stringResource(R.string.preset_colors),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(8),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(90.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        userScrollEnabled = false
                    ) {
                        items(PresetCustomColors) { presetColor ->
                            val isSelected = currentColor.toArgb() == presetColor.toArgb()
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(presetColor)
                                    .clickable {
                                        val hsvArr = FloatArray(3).apply { 
                                            AndroidColor.colorToHSV(presetColor.toArgb(), this) 
                                        }
                                        updateFromHsv(hsvArr[0], hsvArr[1], hsvArr[2])
                                    }
                                    .then(
                                        if (isSelected) {
                                            Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                        } else Modifier
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Icon(
                                        painter = painterResource(R.drawable.check),
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Hue Slider
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = stringResource(R.string.color_hue),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${hue.toInt()}°",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    
                    val rainbowGradient = Brush.horizontalGradient(
                        listOf(
                            Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red
                        )
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(rainbowGradient)
                    )
                    Slider(
                        value = hue,
                        onValueChange = { updateFromHsv(it, saturation, value) },
                        valueRange = 0f..360f,
                        colors = SliderDefaults.colors(
                            thumbColor = animatedCurrentColor,
                            activeTrackColor = Color.Transparent,
                            inactiveTrackColor = Color.Transparent
                        )
                    )
                }

                // Saturation & Brightness Sliders
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Saturation
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = stringResource(R.string.color_saturation),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${(saturation * 100).toInt()}%",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Slider(
                            value = saturation,
                            onValueChange = { updateFromHsv(hue, it, value) },
                            valueRange = 0f..1f
                        )
                    }

                    // Value/Brightness
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = stringResource(R.string.color_brightness),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${(value * 100).toInt()}%",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Slider(
                            value = value,
                            onValueChange = { updateFromHsv(hue, saturation, it) },
                            valueRange = 0.1f..1f
                        )
                    }
                }

                // Hex Code Input Field
                OutlinedTextField(
                    value = hexInput,
                    onValueChange = { updateFromHex(it) },
                    label = { Text(stringResource(R.string.hex_color_code)) },
                    singleLine = true,
                    isError = isHexError,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    )
                )

                // Material Kolor Dynamic Color Scheme Preview Box
                val previewScheme = rememberDynamicColorScheme(
                    seedColor = currentColor,
                    isDark = isSystemInDarkTheme(),
                    style = PaletteStyle.TonalSpot
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = previewScheme.surfaceContainer
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.material_kolor_generated_scheme),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = previewScheme.onSurface
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            ColorSwatchItem("P", stringResource(R.string.color_swatch_primary), previewScheme.primary, previewScheme.onPrimary)
                            ColorSwatchItem("S", stringResource(R.string.color_swatch_secondary), previewScheme.secondary, previewScheme.onSecondary)
                            ColorSwatchItem("T", stringResource(R.string.color_swatch_tertiary), previewScheme.tertiary, previewScheme.onTertiary)
                            ColorSwatchItem("C", stringResource(R.string.color_swatch_container), previewScheme.primaryContainer, previewScheme.onPrimaryContainer)
                        }
                    }
                }

                // Dialog Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = {
                            val defaultColor = DefaultThemeColor
                            val hsvArr = FloatArray(3).apply { AndroidColor.colorToHSV(defaultColor.toArgb(), this) }
                            updateFromHsv(hsvArr[0], hsvArr[1], hsvArr[2])
                        }
                    ) {
                        Text(stringResource(R.string.reset_default))
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = onDismiss) {
                            Text(stringResource(android.R.string.cancel))
                        }
                        TextButton(
                            onClick = {
                                onColorSelected(currentColor)
                                onDismiss()
                            }
                        ) {
                            Text(stringResource(R.string.apply_action), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ColorSwatchItem(
    badge: String,
    label: String,
    color: Color,
    onColor: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(color),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = badge,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = onColor
            )
        }
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
