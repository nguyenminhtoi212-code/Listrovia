package com.listrovia.music.ui.theme

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.listrovia.music.R

val bbhBartle = FontFamily(
    Font(R.font.bbh_bartle_regular, FontWeight.Normal)
)

enum class AppFont(val id: String, val displayNameRes: Int) {
    SYSTEM("SYSTEM", R.string.font_system_default),
    SANS_SERIF("SANS_SERIF", R.string.font_sans_serif),
    SERIF("SERIF", R.string.font_serif),
    MONOSPACE("MONOSPACE", R.string.font_monospace),
    CURSIVE("CURSIVE", R.string.font_cursive),
    BBH_BARTLE("BBH_BARTLE", R.string.font_bbh_bartle);

    fun toFontFamily(): FontFamily = when (this) {
        SYSTEM -> FontFamily.Default
        SANS_SERIF -> FontFamily.SansSerif
        SERIF -> FontFamily.Serif
        MONOSPACE -> FontFamily.Monospace
        CURSIVE -> FontFamily.Cursive
        BBH_BARTLE -> bbhBartle
    }

    companion object {
        fun fromId(id: String?): AppFont = entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: SYSTEM
    }
}

fun getAppFontFamily(id: String?): FontFamily = AppFont.fromId(id).toFontFamily()
