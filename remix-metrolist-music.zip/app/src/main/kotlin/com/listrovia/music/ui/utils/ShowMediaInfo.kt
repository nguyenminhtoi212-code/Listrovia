/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.utils

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.text.format.Formatter
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLocale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.listrovia.innertube.YouTube
import com.listrovia.innertube.models.MediaInfo
import com.listrovia.music.LocalDatabase
import com.listrovia.music.LocalPlayerConnection
import com.listrovia.music.R
import com.listrovia.music.constants.LoudnessLevel
import com.listrovia.music.constants.LoudnessLevelKey
import com.listrovia.music.db.entities.FormatEntity
import com.listrovia.music.db.entities.Song
import com.listrovia.music.ui.component.Material3SettingsGroup
import com.listrovia.music.ui.component.Material3SettingsItem
import com.listrovia.music.ui.component.shimmer.ShimmerHost
import com.listrovia.music.ui.component.shimmer.TextPlaceholder
import com.listrovia.music.utils.cipher.CipherDeobfuscator
import com.listrovia.music.utils.cipher.PlayerDatesStore
import com.listrovia.music.utils.rememberEnumPreference

@Composable
fun getLoudnessLevelLabel(loudnessLevel: LoudnessLevel): String {
    return when (loudnessLevel) {
        LoudnessLevel.AGGRESSIVE -> stringResource(R.string.loudness_level_aggressive)
        LoudnessLevel.LOUD -> stringResource(R.string.loudness_level_loud)
        LoudnessLevel.BALANCED -> stringResource(R.string.loudness_level_balanced)
        LoudnessLevel.QUIET -> stringResource(R.string.loudness_level_quiet)
    }
}

@Composable
private fun createSettingsItem(
    label: String,
    value: String?,
    iconRes: Int? = null
): Material3SettingsItem {
    val unknown = stringResource(R.string.unknown)
    val displayText = value?.ifBlank { null } ?: unknown
    return Material3SettingsItem(
        title = { Text(label) },
        description = { Text(displayText) },
        icon = iconRes?.let { painterResource(it) },
        onClick = null
    )
}

@Composable
private fun AudioTechnicalTile(
    label: String,
    value: String,
    iconRes: Int,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    painter = painterResource(iconRes),
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun ShowMediaInfo(videoId: String) {
    if (videoId.isBlank()) return

    val windowInsets = WindowInsets.systemBars

    var info by remember { mutableStateOf<MediaInfo?>(null) }
    var isLoading by remember { mutableStateOf(true) }

    val database = LocalDatabase.current
    var song by remember { mutableStateOf<Song?>(null) }
    var currentFormat by remember { mutableStateOf<FormatEntity?>(null) }

    val playerConnection = LocalPlayerConnection.current
    val currentStreamClient by playerConnection?.currentStreamClient?.collectAsState() ?: remember { mutableStateOf(null) }
    val context = LocalContext.current

    val loudnessLevel by rememberEnumPreference(
        LoudnessLevelKey,
        defaultValue = LoudnessLevel.BALANCED
    )

    val targetLufs: Float = loudnessLevel.targetLufs

    LaunchedEffect(videoId) {
        isLoading = true
        info = YouTube.getMediaInfo(videoId).getOrNull()
        isLoading = false
    }

    LaunchedEffect(videoId) {
        database.song(videoId).collect {
            song = it
        }
    }

    LaunchedEffect(videoId) {
        database.format(videoId).collect {
            currentFormat = it
        }
    }

    val effectiveFormat = currentFormat ?: song?.format
    val hasData = info != null || song != null || effectiveFormat != null

    LazyColumn(
        state = rememberLazyListState(),
        modifier = Modifier
            .padding(windowInsets.asPaddingValues())
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (isLoading && !hasData) {
            item(contentType = "MediaInfoLoader") {
                ShimmerHost {
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(all = 16.dp)
                    ) {
                        TextPlaceholder()
                    }
                }
            }
        } else {
            item(contentType = "TechnicalAudioHero") {
                val title = info?.title ?: song?.title ?: "Playing Track"
                val artist = info?.author ?: song?.artists?.joinToString { it.name }?.ifBlank { null } ?: "Unknown Artist"
                val bitrateKbps = effectiveFormat?.bitrate?.let { it / 1000 }
                val sampleRateHz = effectiveFormat?.sampleRate
                val sampleRateKHz = sampleRateHz?.let { String.format(LocalLocale.current.platformLocale, "%.1f kHz", it / 1000f) }
                val mimeType = effectiveFormat?.mimeType
                val codecs = effectiveFormat?.codecs
                val fileSize = effectiveFormat?.contentLength?.let { Formatter.formatShortFileSize(context, it) }
                val measuredLufs: Double? = effectiveFormat?.perceptualLoudnessDb
                    ?: effectiveFormat?.loudnessDb?.let { it + LoudnessLevel.AGGRESSIVE.targetLufs }
                val loudnessStr = measuredLufs?.let { String.format(LocalLocale.current.platformLocale, "%.1f dB", it - targetLufs) }

                // Audio Format derived pill label
                val formatLabel = remember(mimeType, codecs) {
                    when {
                        codecs?.contains("flac", ignoreCase = true) == true || mimeType?.contains("flac", ignoreCase = true) == true -> "FLAC Lossless"
                        codecs?.contains("opus", ignoreCase = true) == true || mimeType?.contains("webm", ignoreCase = true) == true -> "WebM (Opus)"
                        codecs?.contains("mp4a", ignoreCase = true) == true || mimeType?.contains("mp4", ignoreCase = true) == true || mimeType?.contains("m4a", ignoreCase = true) == true -> "M4A (AAC)"
                        mimeType?.contains("mpeg", ignoreCase = true) == true -> "MP3"
                        !codecs.isNullOrBlank() -> codecs
                        !mimeType.isNullOrBlank() -> mimeType.removePrefix("audio/")
                        else -> "Audio Stream"
                    }
                }

                // Audio Quality Badge logic
                val isLossless = (bitrateKbps ?: 0) >= 900 || codecs?.contains("flac", ignoreCase = true) == true
                val isHighQuality = (bitrateKbps ?: 0) >= 250

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainer
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        // Header row with Badge & Icon
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape)
                                        .background(
                                            Brush.linearGradient(
                                                colors = if (isLossless) listOf(Color(0xFFFFD700), Color(0xFFFFA000))
                                                else if (isHighQuality) listOf(Color(0xFF00E5FF), Color(0xFF0088FF))
                                                else listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.tertiary)
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        painter = painterResource(R.drawable.equalizer),
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                Column {
                                    Text(
                                        text = "Song Info & Technical Specs",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Audio stream quality & playback format",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            // Quality Badge Pill
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = if (isLossless) Color(0xFFFFD700).copy(alpha = 0.2f)
                                else if (isHighQuality) Color(0xFF00E5FF).copy(alpha = 0.2f)
                                else MaterialTheme.colorScheme.primaryContainer,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isLossless) Color(0xFFFFD700)
                                    else if (isHighQuality) Color(0xFF00E5FF)
                                    else MaterialTheme.colorScheme.primary
                                )
                            ) {
                                Text(
                                    text = if (isLossless) "LOSSLESS" else if (isHighQuality) "HIGH QUALITY" else "STANDARD",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (isLossless) Color(0xFFFFD700)
                                    else if (isHighQuality) Color(0xFF00E5FF)
                                    else MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Currently playing track title preview
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceContainerLow)
                                .padding(12.dp)
                        ) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = artist,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Technical Grid (2x3 tiles)
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                AudioTechnicalTile(
                                    label = stringResource(R.string.bitrate),
                                    value = bitrateKbps?.let { "$it Kbps" } ?: "N/A",
                                    iconRes = R.drawable.gradient,
                                    modifier = Modifier.weight(1f)
                                )
                                AudioTechnicalTile(
                                    label = stringResource(R.string.sample_rate),
                                    value = sampleRateKHz ?: sampleRateHz?.let { "$it Hz" } ?: "N/A",
                                    iconRes = R.drawable.contrast,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                AudioTechnicalTile(
                                    label = "Audio Format",
                                    value = formatLabel,
                                    iconRes = R.drawable.radio,
                                    modifier = Modifier.weight(1f)
                                )
                                AudioTechnicalTile(
                                    label = stringResource(R.string.codecs),
                                    value = codecs ?: "Default",
                                    iconRes = R.drawable.info,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                AudioTechnicalTile(
                                    label = stringResource(R.string.loudness),
                                    value = loudnessStr ?: "N/A",
                                    iconRes = R.drawable.volume_up,
                                    modifier = Modifier.weight(1f)
                                )
                                AudioTechnicalTile(
                                    label = stringResource(R.string.file_size),
                                    value = fileSize ?: "N/A",
                                    iconRes = R.drawable.content_copy,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Copy Specs Button
                        OutlinedButton(
                            onClick = {
                                val specsText = buildString {
                                    appendLine("🎵 Track: $title - $artist")
                                    appendLine("🔊 Audio Quality: ${if (isLossless) "Lossless" else if (isHighQuality) "High Quality" else "Standard"}")
                                    appendLine("📻 Format: $formatLabel (${mimeType ?: "N/A"})")
                                    appendLine("⚙️ Codec: ${codecs ?: "N/A"}")
                                    appendLine("⚡ Bitrate: ${bitrateKbps?.let { "$it Kbps" } ?: "N/A"}")
                                    appendLine("🎚️ Sample Rate: ${sampleRateKHz ?: sampleRateHz?.let { "$it Hz" } ?: "N/A"}")
                                    appendLine("📊 Loudness: ${loudnessStr ?: "N/A"}")
                                    appendLine("📁 File Size: ${fileSize ?: "N/A"}")
                                    appendLine("🔑 Media ID: $videoId")
                                }
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Technical Audio Metadata", specsText))
                                Toast.makeText(context, "Technical audio metadata copied to clipboard", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.content_copy),
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "Copy Audio Specs")
                        }
                    }
                }
            }

            item(contentType = "MediaDetails") {
                Column {
                    val notApplicable = stringResource(R.string.not_applicable)
                    val unknown = stringResource(R.string.unknown)

                    // Base list (General)
                    val baseItems = mutableListOf<Material3SettingsItem>()
                    baseItems += createSettingsItem(
                        stringResource(R.string.song_title),
                        info?.title ?: song?.title,
                        R.drawable.music_note
                    )
                    baseItems += createSettingsItem(
                        stringResource(R.string.song_artists),
                        info?.author ?: song?.artists?.joinToString { it.name }?.ifBlank { null },
                        R.drawable.person
                    )
                    val albumTitle = song?.album?.title ?: song?.song?.albumName
                    if (!albumTitle.isNullOrBlank()) {
                        baseItems += createSettingsItem(
                            stringResource(R.string.view_album),
                            albumTitle,
                            R.drawable.media3_icon_bookmark_filled
                        )
                    }
                    baseItems += createSettingsItem(
                        stringResource(R.string.media_id),
                        song?.id ?: info?.videoId ?: videoId,
                        R.drawable.key_vertical
                    )
                    val durationSec = song?.song?.duration ?: -1
                    if (durationSec > 0) {
                        baseItems += createSettingsItem(
                            stringResource(R.string.history_duration),
                            String.format("%d:%02d", durationSec / 60, durationSec % 60),
                            R.drawable.play
                        )
                    }

                    Material3SettingsGroup(
                        title = stringResource(R.string.general),
                        items = baseItems
                    )

                    Spacer(Modifier.height(8.dp))

                    // Extended list (Information)
                    val isWebStream = currentStreamClient in setOf("WEB_REMIX", "WEB_CREATOR", "TVHTML5", "WEB")
                    val playerHash = if (isWebStream) CipherDeobfuscator.lastUsedPlayerHash else null
                    val measuredLufs: Double? = effectiveFormat?.perceptualLoudnessDb
                        ?: effectiveFormat?.loudnessDb?.let { it + LoudnessLevel.AGGRESSIVE.targetLufs }

                    val extendedItems = mutableListOf<Material3SettingsItem>()

                    if (info?.viewCount != null) {
                        extendedItems += createSettingsItem(
                            stringResource(R.string.views),
                            numberFormatter(info!!.viewCount!!),
                            R.drawable.media3_icon_feed
                        )
                    }
                    if (info?.like != null) {
                        extendedItems += createSettingsItem(
                            stringResource(R.string.likes),
                            numberFormatter(info!!.like!!),
                            R.drawable.media3_icon_thumb_up_unfilled
                        )
                    }
                    if (info?.dislike != null) {
                        extendedItems += createSettingsItem(
                            stringResource(R.string.dislikes),
                            numberFormatter(info!!.dislike!!),
                            R.drawable.media3_icon_thumb_down_unfilled
                        )
                    }
                    if (!info?.uploadDate.isNullOrBlank()) {
                        extendedItems += createSettingsItem(
                            stringResource(R.string.sort_by_create_date),
                            info?.uploadDate,
                            R.drawable.info
                        )
                    }

                    if (effectiveFormat != null) {
                        if (effectiveFormat.itag != null) {
                            extendedItems += createSettingsItem("Itag", effectiveFormat.itag.toString(), R.drawable.key)
                        }
                    }

                    if (!currentStreamClient.isNullOrBlank()) {
                        extendedItems += createSettingsItem(
                            stringResource(R.string.stream_client),
                            currentStreamClient,
                            R.drawable.play
                        )
                    }

                    extendedItems += createSettingsItem(
                        stringResource(R.string.format_player_hash),
                        if (isWebStream) playerHash else notApplicable,
                        R.drawable.lock
                    )

                    extendedItems += createSettingsItem(
                        stringResource(R.string.format_cipher_support_added),
                        if (isWebStream) PlayerDatesStore.get(playerHash) else notApplicable,
                        R.drawable.key_vertical
                    )

                    if (effectiveFormat != null) {
                        if (!effectiveFormat.mimeType.isNullOrBlank()) {
                            extendedItems += createSettingsItem(
                                stringResource(R.string.mime_type),
                                effectiveFormat.mimeType,
                                R.drawable.info
                            )
                        }
                        if (!effectiveFormat.codecs.isNullOrBlank()) {
                            extendedItems += createSettingsItem(
                                stringResource(R.string.codecs),
                                effectiveFormat.codecs,
                                R.drawable.radio
                            )
                        }
                        if (effectiveFormat.bitrate != null) {
                            extendedItems += createSettingsItem(
                                stringResource(R.string.bitrate),
                                "${effectiveFormat.bitrate / 1000} Kbps",
                                R.drawable.gradient
                            )
                        }
                        if (effectiveFormat.sampleRate != null) {
                            extendedItems += createSettingsItem(
                                stringResource(R.string.sample_rate),
                                "${effectiveFormat.sampleRate} Hz",
                                R.drawable.contrast
                            )
                        }
                    }

                    if (measuredLufs != null) {
                        extendedItems += createSettingsItem(
                            stringResource(R.string.loudness),
                            String.format(LocalLocale.current.platformLocale, "%.2f dB", measuredLufs - targetLufs),
                            R.drawable.volume_up
                        )
                    }

                    extendedItems += createSettingsItem(
                        stringResource(R.string.loudness_level),
                        getLoudnessLevelLabel(loudnessLevel),
                        R.drawable.volume_up
                    )

                    if (playerConnection != null) {
                        extendedItems += createSettingsItem(
                            stringResource(R.string.volume),
                            "${(playerConnection.player.volume * 100).toInt()}%",
                            R.drawable.volume_mute
                        )
                    }

                    if (effectiveFormat?.contentLength != null) {
                        extendedItems += createSettingsItem(
                            stringResource(R.string.file_size),
                            Formatter.formatShortFileSize(context, effectiveFormat.contentLength),
                            R.drawable.content_copy
                        )
                    }

                    if (extendedItems.isNotEmpty()) {
                        Material3SettingsGroup(
                            title = stringResource(R.string.information),
                            items = extendedItems
                        )

                        Spacer(Modifier.height(8.dp))
                    }

                    val descriptionText = info?.description ?: unknown
                    if (descriptionText != unknown) {
                        Material3SettingsGroup(
                            title = stringResource(R.string.description),
                            items = listOf(
                                createSettingsItem(
                                    stringResource(R.string.description),
                                    descriptionText,
                                    R.drawable.info
                                )
                            )
                        )
                    }
                }
            }
        }
    }
}
