/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.lyrics.providers

import android.content.Context
import com.listrovia.music.lyrics.LyricsProvider
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.parameter
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.contentType
import io.ktor.http.isSuccess
import io.ktor.serialization.kotlinx.json.json
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import timber.log.Timber
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger
import kotlin.random.Random

data class RecognitionResult(
    val trackId: String,
    val title: String,
    val artist: String,
    val album: String?,
    val coverArtUrl: String?,
    val coverArtHqUrl: String?,
    val genre: String?,
    val releaseDate: String?,
    val label: String?,
    val lyrics: List<String>?,
    val shazamUrl: String?,
    val appleMusicUrl: String?,
    val spotifyUrl: String?,
    val isrc: String?,
    val youtubeVideoId: String? = null,
)

sealed class RecognitionStatus {
    data object Ready : RecognitionStatus()
    data object Listening : RecognitionStatus()
    data object Processing : RecognitionStatus()
    data class Success(val result: RecognitionResult) : RecognitionStatus()
    data class NoMatch(val message: String = "No matches found") : RecognitionStatus()
    data class Error(val message: String) : RecognitionStatus()
}

@Serializable
data class ShazamRequestJson(
    @SerialName("geolocation")
    val geolocation: Geolocation,
    @SerialName("signature")
    val signature: Signature,
    @SerialName("timestamp")
    val timestamp: Long,
    @SerialName("timezone")
    val timezone: String,
) {
    @Serializable
    data class Geolocation(
        @SerialName("altitude")
        val altitude: Double,
        @SerialName("latitude")
        val latitude: Double,
        @SerialName("longitude")
        val longitude: Double,
    )

    @Serializable
    data class Signature(
        @SerialName("samplems")
        val samplems: Long,
        @SerialName("timestamp")
        val timestamp: Long,
        @SerialName("uri")
        val uri: String,
    )
}

@Serializable
data class ShazamResponseJson(
    @SerialName("matches")
    val matches: List<Match?>? = null,
    @SerialName("location")
    val location: Location? = null,
    @SerialName("timestamp")
    val timestamp: Long? = null,
    @SerialName("timezone")
    val timezone: String? = null,
    @SerialName("track")
    val track: Track? = null,
    @SerialName("tagid")
    val tagid: String? = null,
) {
    @Serializable
    data class Match(
        @SerialName("id")
        val id: String? = null,
        @SerialName("offset")
        val offset: Double? = null,
        @SerialName("timeskew")
        val timeskew: Double? = null,
        @SerialName("frequencyskew")
        val frequencyskew: Double? = null,
    )

    @Serializable
    data class Location(
        @SerialName("latitude")
        val latitude: Double? = null,
        @SerialName("longitude")
        val longitude: Double? = null,
        @SerialName("altitude")
        val altitude: Double? = null,
        @SerialName("accuracy")
        val accuracy: Double? = null,
    )

    @Serializable
    data class Track(
        @SerialName("layout")
        val layout: String? = null,
        @SerialName("type")
        val type: String? = null,
        @SerialName("key")
        val key: String? = null,
        @SerialName("title")
        val title: String? = null,
        @SerialName("subtitle")
        val subtitle: String? = null,
        @SerialName("images")
        val images: Images? = null,
        @SerialName("share")
        val share: Share? = null,
        @SerialName("hub")
        val hub: Hub? = null,
        @SerialName("sections")
        val sections: List<Section?>? = null,
        @SerialName("url")
        val url: String? = null,
        @SerialName("artists")
        val artists: List<Artist?>? = null,
        @SerialName("isrc")
        val isrc: String? = null,
        @SerialName("genres")
        val genres: Genres? = null,
        @SerialName("relatedtracksurl")
        val relatedtracksurl: String? = null,
        @SerialName("albumadamid")
        val albumadamid: String? = null,
    ) {
        @Serializable
        data class Images(
            @SerialName("background")
            val background: String? = null,
            @SerialName("coverart")
            val coverart: String? = null,
            @SerialName("coverarthq")
            val coverarthq: String? = null,
            @SerialName("joecolor")
            val joecolor: String? = null,
        )

        @Serializable
        data class Share(
            @SerialName("subject")
            val subject: String? = null,
            @SerialName("text")
            val text: String? = null,
            @SerialName("href")
            val href: String? = null,
            @SerialName("image")
            val image: String? = null,
            @SerialName("twitter")
            val twitter: String? = null,
            @SerialName("html")
            val html: String? = null,
            @SerialName("avatar")
            val avatar: String? = null,
            @SerialName("snapchat")
            val snapchat: String? = null,
        )

        @Serializable
        data class Hub(
            @SerialName("type")
            val type: String? = null,
            @SerialName("image")
            val image: String? = null,
            @SerialName("actions")
            val actions: List<Action?>? = null,
            @SerialName("options")
            val options: List<Option?>? = null,
            @SerialName("providers")
            val providers: List<Provider?>? = null,
            @SerialName("explicit")
            val explicit: Boolean? = null,
            @SerialName("displayname")
            val displayname: String? = null,
        ) {
            @Serializable
            data class Action(
                @SerialName("name")
                val name: String? = null,
                @SerialName("type")
                val type: String? = null,
                @SerialName("id")
                val id: String? = null,
                @SerialName("uri")
                val uri: String? = null,
            )

            @Serializable
            data class Option(
                @SerialName("caption")
                val caption: String? = null,
                @SerialName("actions")
                val actions: List<OptionAction?>? = null,
                @SerialName("beacondata")
                val beacondata: Beacondata? = null,
                @SerialName("image")
                val image: String? = null,
                @SerialName("type")
                val type: String? = null,
                @SerialName("listcaption")
                val listcaption: String? = null,
                @SerialName("overflowimage")
                val overflowimage: String? = null,
                @SerialName("colouroverflowimage")
                val colouroverflowimage: Boolean? = null,
                @SerialName("providername")
                val providername: String? = null,
            ) {
                @Serializable
                data class OptionAction(
                    @SerialName("name")
                    val name: String? = null,
                    @SerialName("type")
                    val type: String? = null,
                    @SerialName("uri")
                    val uri: String? = null,
                    @SerialName("id")
                    val id: String? = null,
                )

                @Serializable
                data class Beacondata(
                    @SerialName("type")
                    val type: String? = null,
                    @SerialName("providername")
                    val providername: String? = null,
                )
            }

            @Serializable
            data class Provider(
                @SerialName("caption")
                val caption: String? = null,
                @SerialName("images")
                val images: ProviderImages? = null,
                @SerialName("actions")
                val actions: List<ProviderAction?>? = null,
                @SerialName("type")
                val type: String? = null,
            ) {
                @Serializable
                data class ProviderImages(
                    @SerialName("overflow")
                    val overflow: String? = null,
                    @SerialName("default")
                    val default: String? = null,
                )

                @Serializable
                data class ProviderAction(
                    @SerialName("name")
                    val name: String? = null,
                    @SerialName("type")
                    val type: String? = null,
                    @SerialName("uri")
                    val uri: String? = null,
                )
            }
        }

        @Serializable
        data class Section(
            @SerialName("type")
            val type: String? = null,
            @SerialName("metapages")
            val metapages: List<Metapage?>? = null,
            @SerialName("tabname")
            val tabname: String? = null,
            @SerialName("metadata")
            val metadata: List<Metadata?>? = null,
            @SerialName("url")
            val url: String? = null,
            @SerialName("text")
            val text: List<String>? = null,
        ) {
            @Serializable
            data class Metapage(
                @SerialName("image")
                val image: String? = null,
                @SerialName("caption")
                val caption: String? = null,
            )

            @Serializable
            data class Metadata(
                @SerialName("title")
                val title: String? = null,
                @SerialName("text")
                val text: String? = null,
            )
        }

        @Serializable
        data class Artist(
            @SerialName("id")
            val id: String? = null,
            @SerialName("adamid")
            val adamid: String? = null,
        )

        @Serializable
        data class Genres(
            @SerialName("primary")
            val primary: String? = null,
        )
    }
}

/**
 * Shazam Music Recognition Engine
 */
object Shazam {
    private const val TAG = "ShazamApi"

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private const val MAX_CONCURRENT_REQUESTS = 2
    private const val MIN_REQUEST_INTERVAL_MS = 1000L
    private const val MAX_RETRIES = 3
    private const val INITIAL_RETRY_DELAY_MS = 2000L
    private const val CACHE_DURATION_MS = 300000L
    private const val MAX_QUEUE_SIZE = 50

    private val activeRequests = AtomicInteger(0)
    private var lastRequestTime = 0L
    private val requestMutex = Mutex()
    private val requestQueue = ConcurrentLinkedQueue<PendingRequest>()
    private val resultCache = ConcurrentHashMap<String, CachedResult>()
    private var nextRequestId = 0L
    private var isProcessingQueue = false

    private val client by lazy {
        HttpClient(OkHttp) {
            install(ContentNegotiation) {
                json(
                    Json {
                        isLenient = true
                        ignoreUnknownKeys = true
                        encodeDefaults = true
                    },
                )
            }
            install(HttpTimeout) {
                requestTimeoutMillis = 30000
            }
            expectSuccess = false
        }
    }

    private val userAgents = listOf(
        "Dalvik/2.1.0 (Linux; U; Android 14; Pixel 8 Build/UD1A.230803.041)",
        "Dalvik/2.1.0 (Linux; U; Android 13; SM-S918B Build/TP1A.220624.014)",
        "Dalvik/2.1.0 (Linux; U; Android 12; Pixel 6 Build/SQ1D.220205.004)",
        "Dalvik/2.1.0 (Linux; U; Android 11; SM-G998B Build/RP1A.200720.012)",
    )

    private val timezones = listOf(
        "Europe/Paris", "Europe/London", "America/New_York",
        "America/Los_Angeles", "Asia/Tokyo", "Asia/Dubai", "Asia/Ho_Chi_Minh",
    )

    suspend fun recognize(signature: String, sampleDurationMs: Long): Result<RecognitionResult> {
        val cacheKey = signature.hashCode().toString()
        getCachedResult(cacheKey)?.let {
            Timber.tag(TAG).d("Cache hit for key=%s", cacheKey)
            return Result.success(it)
        }

        Timber.tag(TAG).d("No cache hit, enqueueing request (pending=%d, active=%d)", requestQueue.size, activeRequests.get())
        return enqueueRequest(signature, sampleDurationMs)
    }

    fun getPendingRequestsCount(): Int = requestQueue.size
    fun getActiveRequestsCount(): Int = activeRequests.get()

    fun clearCache() {
        resultCache.clear()
    }

    fun cancelPendingRequests() {
        while (requestQueue.isNotEmpty()) {
            requestQueue.poll()?.completeWith(Result.failure(Exception("Request cancelled")))
        }
    }

    fun cleanup() {
        cancelPendingRequests()
        clearCache()
        client.close()
    }

    private suspend fun enqueueRequest(
        signature: String,
        sampleDurationMs: Long,
    ): Result<RecognitionResult> = requestMutex.withLock {
        if (requestQueue.size >= MAX_QUEUE_SIZE) {
            Timber.tag(TAG).w("Request queue full (%d/%d), rejecting request", requestQueue.size, MAX_QUEUE_SIZE)
            return Result.failure(Exception("Request queue is full. Please wait."))
        }

        val requestId = nextRequestId++
        val request = PendingRequest(
            id = requestId,
            signature = signature,
            sampleDurationMs = sampleDurationMs,
        )

        requestQueue.offer(request)
        Timber.tag(TAG).d("Request #%d enqueued (queue size=%d)", requestId, requestQueue.size)

        if (!isProcessingQueue) {
            isProcessingQueue = true
            scope.launch { processQueue() }
        }

        return request.awaitResult()
    }

    private suspend fun processQueue() {
        while (true) {
            val request = requestQueue.poll() ?: break

            while (activeRequests.get() >= MAX_CONCURRENT_REQUESTS) {
                delay(100)
            }

            activeRequests.incrementAndGet()

            scope.launch {
                try {
                    val result = executeRequest(request.signature, request.sampleDurationMs)
                    request.completeWith(result)
                } catch (e: Exception) {
                    Timber.tag(TAG).w(e, "Request #%d failed in queue processor", request.id)
                    request.completeWith(Result.failure(e))
                } finally {
                    activeRequests.decrementAndGet()
                }
            }

            enforceRateLimit()
        }

        isProcessingQueue = false
    }

    private suspend fun executeRequest(
        signature: String,
        sampleDurationMs: Long,
    ): Result<RecognitionResult> {
        var lastException: Exception? = null

        for (attempt in 0 until MAX_RETRIES) {
            try {
                enforceRateLimit()
                val result = performRecognition(signature, sampleDurationMs)
                cacheResult(signature.hashCode().toString(), result)
                Timber.tag(TAG).d("Request succeeded on attempt %d", attempt + 1)
                return Result.success(result)
            } catch (e: Exception) {
                lastException = e
                Timber.tag(TAG).w(e, "Request failed on attempt %d/%d: %s", attempt + 1, MAX_RETRIES, e.message)

                if (e.message?.contains("429") == true || e.message?.contains("Too many requests", ignoreCase = true) == true) {
                    if (attempt < MAX_RETRIES - 1) {
                        val delayTime = INITIAL_RETRY_DELAY_MS * (1 shl attempt)
                        delay(delayTime)
                        continue
                    }
                } else {
                    throw e
                }
            }
        }

        throw lastException ?: Exception("Recognition failed after $MAX_RETRIES attempts")
    }

    private suspend fun performRecognition(
        signature: String,
        sampleDurationMs: Long,
    ): RecognitionResult {
        val timestamp = System.currentTimeMillis() / 1000
        val uuid1 = UUID.randomUUID().toString().uppercase()
        val uuid2 = UUID.randomUUID().toString()

        val request = ShazamRequestJson(
            geolocation = ShazamRequestJson.Geolocation(
                altitude = Random.nextDouble() * 400 + 100,
                latitude = Random.nextDouble() * 180 - 90,
                longitude = Random.nextDouble() * 360 - 180,
            ),
            signature = ShazamRequestJson.Signature(
                samplems = sampleDurationMs,
                timestamp = timestamp,
                uri = signature,
            ),
            timestamp = timestamp,
            timezone = timezones.random(),
        )

        val response = client.post("https://amp.shazam.com/discovery/v5/en/US/android/-/tag/$uuid1/$uuid2") {
            parameter("sync", "true")
            parameter("webv3", "true")
            parameter("sampling", "true")
            parameter("connected", "")
            parameter("shazamapiversion", "v3")
            parameter("sharehub", "true")
            parameter("video", "v3")
            header("User-Agent", userAgents.random())
            header("Content-Language", "en_US")
            contentType(ContentType.Application.Json)
            setBody(request)
        }

        if (!response.status.isSuccess()) {
            val statusCode = response.status.value
            when (statusCode) {
                429 -> throw Exception("Too many requests")
                404 -> throw Exception("No match found")
                in 500..599 -> throw Exception("Shazam service temporarily unavailable")
                else -> throw Exception("Recognition failed (error $statusCode)")
            }
        }

        val shazamResponse = response.body<ShazamResponseJson>()
        return shazamResponse.toRecognitionResult()
            ?: throw Exception("No match found")
    }

    private suspend fun enforceRateLimit() {
        val currentTime = System.currentTimeMillis()
        val timeSinceLastRequest = currentTime - lastRequestTime
        if (timeSinceLastRequest < MIN_REQUEST_INTERVAL_MS) {
            val delayTime = MIN_REQUEST_INTERVAL_MS - timeSinceLastRequest
            delay(delayTime)
        }
        lastRequestTime = System.currentTimeMillis()
    }

    private fun getCachedResult(key: String): RecognitionResult? {
        val cached = resultCache[key] ?: return null
        if (System.currentTimeMillis() - cached.timestamp > CACHE_DURATION_MS) {
            resultCache.remove(key)
            return null
        }
        return cached.result
    }

    private fun cacheResult(key: String, result: RecognitionResult) {
        resultCache[key] = CachedResult(System.currentTimeMillis(), result)
        if (resultCache.size > 100) {
            val currentTime = System.currentTimeMillis()
            resultCache.entries.removeIf { currentTime - it.value.timestamp > CACHE_DURATION_MS }
        }
    }

    private fun ShazamResponseJson.toRecognitionResult(): RecognitionResult? {
        val track = this.track ?: return null

        val songSection = track.sections?.find { it?.type == "SONG" }
        val metadata = songSection?.metadata
        val album = metadata?.find { it?.title == "Album" }?.text
        val label = metadata?.find { it?.title == "Label" }?.text
        val releaseDate = metadata?.find { it?.title == "Released" }?.text

        val lyricsSection = track.sections?.find { it?.type == "LYRICS" }
        val lyrics = lyricsSection?.text

        val appleAction = track.hub?.options?.firstOrNull {
            it?.providername?.contains("apple", ignoreCase = true) == true
        }?.actions?.firstOrNull()

        val spotifyProvider = track.hub?.providers?.find {
            it?.caption?.contains("spotify", ignoreCase = true) == true
        }

        val youtubeAction = track.hub?.options?.find {
            it?.type?.contains("video", ignoreCase = true) == true
        }?.actions?.firstOrNull()

        val youtubeVideoId = youtubeAction?.uri?.let { uri ->
            uri.substringAfterLast("v=", "").takeIf { it.isNotEmpty() }
                ?: uri.substringAfterLast("/", "").takeIf { it.isNotEmpty() && it.length == 11 }
        }

        return RecognitionResult(
            trackId = track.key ?: tagid ?: "",
            title = track.title ?: "",
            artist = track.subtitle ?: "",
            album = album,
            coverArtUrl = track.images?.coverart,
            coverArtHqUrl = track.images?.coverarthq,
            genre = track.genres?.primary,
            releaseDate = releaseDate,
            label = label,
            lyrics = lyrics,
            shazamUrl = track.url,
            appleMusicUrl = appleAction?.uri,
            spotifyUrl = spotifyProvider?.actions?.firstOrNull()?.uri,
            isrc = track.isrc,
            youtubeVideoId = youtubeVideoId,
        )
    }

    private class PendingRequest(
        val id: Long,
        val signature: String,
        val sampleDurationMs: Long,
    ) {
        private val deferred = CompletableDeferred<Result<RecognitionResult>>()

        suspend fun awaitResult(): Result<RecognitionResult> = deferred.await()

        fun completeWith(result: Result<RecognitionResult>) {
            deferred.complete(result)
        }
    }

    private data class CachedResult(
        val timestamp: Long,
        val result: RecognitionResult,
    )

    suspend fun getLyrics(
        title: String,
        artist: String,
        duration: Int,
        album: String? = null,
    ): Result<String> = runCatching {
        val query = "$title $artist".trim()
        val searchResponse = client.get("https://core.shazam.com/v1/en/US/android/search") {
            parameter("query", query)
            parameter("numResults", "3")
            header("User-Agent", userAgents.random())
        }
        val text = searchResponse.bodyAsText()
        val trackKey = Regex(""""key"\s*:\s*"(\d+)"""").find(text)?.groupValues?.get(1)
            ?: throw IllegalStateException("No Shazam track key found for $title")

        val trackResponse = client.get("https://amp.shazam.com/discovery/v5/en/US/android/-/track/$trackKey") {
            header("User-Agent", userAgents.random())
        }
        val trackJson = trackResponse.body<ShazamResponseJson.Track>()
        val lyrics = trackJson.sections?.find { it?.type == "LYRICS" }?.text
            ?: throw IllegalStateException("No lyrics found in Shazam track")

        lyrics.joinToString("\n").ifBlank {
            throw IllegalStateException("Empty lyrics for Shazam track")
        }
    }

    suspend fun getAllLyrics(
        title: String,
        artist: String,
        duration: Int,
        album: String? = null,
        callback: (String) -> Unit,
    ) {
        getLyrics(title, artist, duration, album).onSuccess(callback)
    }
}

/**
 * ShazamKit Lyrics Provider
 */
object ShazamLyricsProvider : LyricsProvider {
    override val name = "ShazamKit"

    override fun isEnabled(context: Context): Boolean = true

    override suspend fun getLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): Result<String> = Shazam.getLyrics(title, artist, duration, album)

    override suspend fun getAllLyrics(
        context: Context,
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
        callback: (String) -> Unit,
    ) {
        Shazam.getAllLyrics(title, artist, duration, album, callback)
    }
}
