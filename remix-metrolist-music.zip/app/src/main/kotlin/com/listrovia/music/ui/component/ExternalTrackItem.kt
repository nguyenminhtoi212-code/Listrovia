/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.component

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.listrovia.innertube.models.WatchEndpoint
import com.listrovia.music.LocalPlayerConnection
import com.listrovia.music.R
import com.listrovia.music.api.ExternalMusicProviderService
import com.listrovia.music.api.ExternalTrack
import com.listrovia.music.api.MusicSourceProvider
import com.listrovia.music.models.toMediaMetadata
import com.listrovia.music.playback.AudioPreviewManager
import com.listrovia.music.playback.queues.YouTubeQueue
import com.listrovia.music.ui.component.ItemThumbnail
import com.listrovia.music.constants.ThumbnailCornerRadius
import androidx.compose.foundation.layout.fillMaxSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ExternalTrackItem(
    track: ExternalTrack,
    onResolveVideoId: suspend (ExternalTrack) -> String?,
    modifier: Modifier = Modifier,
    externalService: ExternalMusicProviderService? = null,
    onArtistClick: ((String) -> Unit)? = null,
    trailingContent: (@Composable () -> Unit)? = null,
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val playerConnection = LocalPlayerConnection.current
    var isResolving by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var showCommentsSheet by remember { mutableStateOf(false) }
    var resolvedIdForComments by remember { mutableStateOf<String?>(null) }

    val currentPlayingPreviewId by AudioPreviewManager.currentPlayingTrackId.collectAsState()
    val isPreviewPlaying by AudioPreviewManager.isPlaying.collectAsState()
    val isThisPreviewPlaying = isPreviewPlaying && currentPlayingPreviewId == track.id

    fun playTrack() {
        if (playerConnection == null) return
        AudioPreviewManager.stopPreview()
        coroutineScope.launch {
            isResolving = true
            try {
                val videoId = onResolveVideoId(track)
                if (!videoId.isNullOrBlank()) {
                    val songItem = track.toSongItem(videoId)
                    playerConnection.playQueue(
                        YouTubeQueue(
                            endpoint = WatchEndpoint(videoId = videoId),
                            preloadItem = songItem.toMediaMetadata(),
                        )
                    )
                } else {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            context,
                            "Cannot resolve stream for ${track.title}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        context,
                        "Error streaming ${track.title}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } finally {
                isResolving = false
            }
        }
    }

    fun openComments() {
        coroutineScope.launch {
            val videoId = track.resolvedVideoId ?: onResolveVideoId(track) ?: ""
            if (videoId.isNotBlank()) {
                resolvedIdForComments = videoId
                showCommentsSheet = true
            } else {
                Toast.makeText(context, "Cannot load comments", Toast.LENGTH_SHORT).show()
            }
        }
    }

    if (showCommentsSheet && resolvedIdForComments != null && externalService != null) {
        TrackCommentsBottomSheet(
            videoId = resolvedIdForComments!!,
            trackTitle = "${track.title} - ${track.artist}",
            externalService = externalService,
            onDismiss = { showCommentsSheet = false }
        )
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .clickable { playTrack() }
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Thumbnail with Provider Badge
        Box(
            modifier = Modifier.size(56.dp)
        ) {
            ItemThumbnail(
                thumbnailUrl = track.thumbnailUrl,
                isActive = isResolving,
                isPlaying = false, // Not used here
                shape = RoundedCornerShape(ThumbnailCornerRadius),
                modifier = Modifier.fillMaxSize()
            )

            // Provider micro-badge
            val isApple = track.provider == MusicSourceProvider.APPLE_MUSIC || track.id.startsWith("am_")
            val badgeIcon = if (isApple) R.drawable.ic_apple_music else R.drawable.ic_launcher_logo
            Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.65f),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(2.dp)
                    .size(18.dp)
            ) {
                Icon(
                    painter = painterResource(badgeIcon),
                    contentDescription = if (isApple) "Apple Music" else "YouTube Music",
                    tint = Color.Unspecified,
                    modifier = Modifier.padding(3.dp)
                )
            }
        }

        Spacer(Modifier.width(16.dp))

        // Titles and artist
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = track.title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurface
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 2.dp)
            ) {
                Text(
                    text = track.artist + if (track.album.isNotBlank()) " • ${track.album}" else "",
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.clickable(enabled = onArtistClick != null) {
                        onArtistClick?.invoke(track.artist)
                    }
                )
            }
        }

        Spacer(Modifier.width(4.dp))

        // 30s Audio Preview Snippet Button
        if (!track.previewUrl.isNullOrBlank()) {
            IconButton(
                onClick = {
                    AudioPreviewManager.playPreview(track.id, track.previewUrl)
                },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    painter = painterResource(if (isThisPreviewPlaying) R.drawable.pause else R.drawable.volume_up),
                    contentDescription = stringResource(R.string.preview_audio_clip),
                    tint = if (isThisPreviewPlaying) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        if (isResolving) {
            CircularProgressIndicator(
                modifier = Modifier.size(24.dp).padding(4.dp),
                strokeWidth = 2.dp,
                color = MaterialTheme.colorScheme.primary
            )
        } else if (trailingContent != null) {
            trailingContent()
        } else {
            Box {
                IconButton(
                    onClick = { showMenu = true },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        painter = painterResource(R.drawable.more_vert),
                        contentDescription = "Menu",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }

                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.play_full_song)) },
                        leadingIcon = {
                            Icon(
                                painter = painterResource(R.drawable.play),
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        onClick = {
                            showMenu = false
                            playTrack()
                        }
                    )

                    if (!track.previewUrl.isNullOrBlank()) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.preview_audio_clip)) },
                            leadingIcon = {
                                Icon(
                                    painter = painterResource(R.drawable.volume_up),
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            onClick = {
                                showMenu = false
                                AudioPreviewManager.playPreview(track.id, track.previewUrl)
                            }
                        )
                    }

                    if (externalService != null) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.view_comments_title)) },
                            leadingIcon = {
                                Icon(
                                    painter = painterResource(R.drawable.chat_bubble),
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            onClick = {
                                showMenu = false
                                openComments()
                            }
                        )
                    }

                    if (onArtistClick != null && track.artist.isNotBlank()) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.view_artist_channel)) },
                            leadingIcon = {
                                Icon(
                                    painter = painterResource(R.drawable.artist),
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            onClick = {
                                showMenu = false
                                onArtistClick(track.artist)
                            }
                        )
                    }
                }
            }
        }
    }
}
