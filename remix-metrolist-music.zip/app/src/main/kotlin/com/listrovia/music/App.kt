/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ComponentCallbacks2
import android.content.Context
import android.os.Build
import android.widget.Toast
import coil3.ImageLoader
import coil3.PlatformContext
import coil3.SingletonImageLoader
import coil3.disk.DiskCache
import coil3.disk.directory
import coil3.memory.MemoryCache
import coil3.request.CachePolicy
import coil3.request.allowHardware
import coil3.request.crossfade
import com.listrovia.innertube.YouTube
import com.listrovia.innertube.models.ArtistConjunctions
import com.listrovia.innertube.models.YouTubeLocale
import com.listrovia.music.utils.LastFmManager
import com.listrovia.music.extensions.setupServices
import com.listrovia.music.extensions.setupSystemDefaults
import com.listrovia.music.lyrics.providers.KuGou
import com.listrovia.music.BuildConfig
import com.listrovia.music.constants.*
import com.listrovia.music.di.ApplicationScope
import com.listrovia.music.extensions.toEnum
import com.listrovia.music.extensions.toInetSocketAddress
import com.listrovia.music.playback.StreamingDataTracker
import com.listrovia.music.security.ContentSafetyScanner
import com.listrovia.music.utils.CrashHandler
import com.listrovia.music.utils.YTPlayerUtils
import com.listrovia.music.utils.cipher.CipherDeobfuscator
import com.listrovia.music.utils.dataStore
import com.listrovia.music.utils.ensureWebViewCacheDirsExist
import com.listrovia.music.utils.safeDataStoreEdit
import com.listrovia.music.utils.reportException
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import okhttp3.Credentials
import timber.log.Timber
import java.io.File
import java.io.IOException
import java.net.Authenticator
import java.net.PasswordAuthentication
import java.net.Proxy
import java.util.Locale
import javax.inject.Inject

@HiltAndroidApp
class App :
    Application(),
    SingletonImageLoader.Factory {
    @Inject
    @ApplicationScope
    lateinit var applicationScope: CoroutineScope

    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(base)
        // Only attempt hidden API exemption on Android 9 (P) and 10 (Q) where supported by VM
        if (Build.VERSION.SDK_INT in Build.VERSION_CODES.P..Build.VERSION_CODES.Q) {
            runCatching {
                val forName = Class::class.java.getDeclaredMethod("forName", String::class.java)
                val getDeclaredMethod = Class::class.java.getDeclaredMethod(
                    "getDeclaredMethod",
                    String::class.java,
                    arrayOf<Class<*>>()::class.java
                )
                val vmRuntimeClass = forName.invoke(null, "dalvik.system.VMRuntime") as Class<*>
                val getRuntime = getDeclaredMethod.invoke(vmRuntimeClass, "getRuntime", null) as java.lang.reflect.Method
                val setHiddenApiExemptions = getDeclaredMethod.invoke(
                    vmRuntimeClass,
                    "setHiddenApiExemptions",
                    arrayOf(arrayOf<String>()::class.java)
                ) as java.lang.reflect.Method
                val vmRuntime = getRuntime.invoke(null)
                setHiddenApiExemptions.invoke(vmRuntime, arrayOf("L"))
            }.onFailure {
                // Gracefully ignore reflection restrictions on restricted platforms
            }
        }
    }



    override fun onCreate() {
        instance = this
        super.onCreate()

        setupSystemDefaults()

        setupServices(applicationScope)

        // Pre-read Coil cache size on background to avoid runBlocking in newImageLoader
        applicationScope.launch(Dispatchers.IO) {
            cachedCoilCacheSize = dataStore.data.map { it[MaxImageCacheSizeKey] ?: 512 }.first()
        }

        // تهيئة إعدادات التطبيق عند الإقلاع
        applicationScope.launch {
            // Apply settings (incl. YouTube.proxy) FIRST: the cipher/PoToken OkHttpClients are built
            // once and cached, so warming them before the proxy is set would snapshot a null proxy and
            // bypass a configured proxy for the whole session. Warm-up is launched only after this.
            initializeSettings()

            // Automatically check and clear image and network cache if exceeding threshold
            launch(Dispatchers.IO) {
                delay(3000)
                runCatching {
                    com.listrovia.music.utils.CacheAutoManager.checkAndAutoClearCache(this@App)
                }
            }

            // Schedule background release notes check and Room sync worker
            launch(Dispatchers.IO) {
                delay(4000)
                runCatching {
                    com.listrovia.music.work.ReleaseNotesWorker.enqueue(this@App)
                    com.listrovia.music.utils.UpdateNotificationHelper.checkAndNotifyAppUpdated(this@App)
                }
            }

            observeSettingsChanges()
        }
    }

    private suspend fun initializeSettings() {
        val settings = dataStore.data.first()
        val locale = Locale.getDefault()
        val languageTag = locale.language

        ArtistConjunctions.conjunctions = listOf(
            R.string.and,
        ).mapNotNull { id ->
            runCatching { getString(id) }.getOrNull()
        }

        YouTube.locale =
            YouTubeLocale(
                gl =
                    settings[ContentCountryKey]?.takeIf { it != SYSTEM_DEFAULT }
                        ?: locale.country.takeIf { it in CountryCodeToName }
                        ?: "US",
                hl =
                    settings[ContentLanguageKey]?.takeIf { it != SYSTEM_DEFAULT }
                        ?: locale.language.takeIf { it in LanguageCodeToName }
                        ?: languageTag.takeIf { it in LanguageCodeToName }
                        ?: "en",
            )

        if (languageTag == "zh-TW") {
            KuGou.useTraditionalChinese = true
        }

        // Initialize LastFM with API keys from BuildConfig (GitHub Secrets)
        LastFmManager.initialize(
            apiKey = BuildConfig.LASTFM_API_KEY.takeIf { it.isNotEmpty() } ?: "",
            secret = BuildConfig.LASTFM_SECRET.takeIf { it.isNotEmpty() } ?: "",
        )

        if (settings[ProxyEnabledKey] == true) {
            val username = settings[ProxyUsernameKey].orEmpty()
            val password = settings[ProxyPasswordKey].orEmpty()
            val type = settings[ProxyTypeKey].toEnum(defaultValue = Proxy.Type.HTTP)

            if (username.isNotEmpty() || password.isNotEmpty()) {
                if (type == Proxy.Type.HTTP) {
                    YouTube.proxyAuth = Credentials.basic(username, password)
                } else {
                    Authenticator.setDefault(
                        object : Authenticator() {
                            override fun getPasswordAuthentication(): PasswordAuthentication =
                                PasswordAuthentication(username, password.toCharArray())
                        },
                    )
                }
            }
            try {
                settings[ProxyUrlKey]?.let {
                    YouTube.proxy = Proxy(type, it.toInetSocketAddress())
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@App, getString(R.string.failed_to_parse_proxy), Toast.LENGTH_SHORT).show()
                }
                reportException(e)
            }
        }

        YouTube.useLoginForBrowse = settings[UseLoginForBrowse] ?: true

        // Create notification channels for updates and install alerts with sound & vibration
        com.listrovia.music.utils.UpdateNotificationHelper.createNotificationChannels(this)

        // Create download notification channel
        androidx.media3.common.util.NotificationUtil.createNotificationChannel(
            this,
            com.listrovia.music.playback.ExoDownloadService.CHANNEL_ID,
            R.string.downloading,
            0,
            androidx.media3.common.util.NotificationUtil.IMPORTANCE_LOW
        )
    }

    private fun observeSettingsChanges() {
        applicationScope.launch(Dispatchers.IO) {
            dataStore.data
                .map { it[VisitorDataKey] }
                .distinctUntilChanged()
                .collect { visitorData ->
                    YouTube.visitorData = visitorData?.takeIf { it != "null" }
                        ?: YouTube.visitorData().getOrNull()?.also { newVisitorData ->
                            try {
                                safeDataStoreEdit { settings ->
                                    settings[VisitorDataKey] = newVisitorData
                                }
                            } catch (e: IOException) {
                                Timber.e(e, "DataStore write failed for visitor data")
                                reportException(e)
                            }
                        }
                }
        }

        applicationScope.launch(Dispatchers.IO) {
            dataStore.data
                .map { it[DataSyncIdKey] }
                .distinctUntilChanged()
                .collect { dataSyncId ->
                    YouTube.dataSyncId =
                        dataSyncId?.let {
                            it.takeIf { !it.contains("||") }
                                ?: it.takeIf { it.endsWith("||") }?.substringBefore("||")
                                ?: it.substringAfter("||")
                        }
                }
        }

        applicationScope.launch(Dispatchers.IO) {
            dataStore.data
                .map { it[InnerTubeCookieKey] }
                .distinctUntilChanged()
                .collect { cookie ->
                    try {
                        YouTube.cookie = cookie
                    } catch (e: Exception) {
                        Timber.e(e, "Could not parse cookie. Clearing existing cookie.")
                        forgetAccount(this@App)
                    }
                }
        }

        applicationScope.launch(Dispatchers.IO) {
            dataStore.data
                .map { it[LastFMSessionKey] }
                .distinctUntilChanged()
                .collect { session ->
                    try {
                        LastFmManager.sessionKey = session
                    } catch (e: Exception) {
                        Timber.e("Error while loading last.fm session key. %s", e.message)
                    }
                }
        }

        applicationScope.launch(Dispatchers.IO) {
            dataStore.data
                .map { Triple(it[ContentCountryKey], it[ContentLanguageKey], it[AppLanguageKey]) }
                .distinctUntilChanged()
                .collect { (contentCountry, contentLanguage, appLanguage) ->
                    val systemLocale = Locale.getDefault()
                    val effectiveAppLocale =
                        appLanguage
                            ?.takeUnless { it == SYSTEM_DEFAULT }
                            ?.let { Locale.forLanguageTag(it) }
                            ?: systemLocale

                    YouTube.locale =
                        YouTubeLocale(
                            gl =
                                contentCountry?.takeIf { it != SYSTEM_DEFAULT }
                                    ?: effectiveAppLocale.country.takeIf { it in CountryCodeToName }
                                    ?: systemLocale.country.takeIf { it in CountryCodeToName }
                                    ?: "US",
                            hl =
                                contentLanguage?.takeIf { it != SYSTEM_DEFAULT }
                                    ?: effectiveAppLocale.toLanguageTag().takeIf { it in LanguageCodeToName }
                                    ?: effectiveAppLocale.language.takeIf { it in LanguageCodeToName }
                                    ?: "en",
                        )
                }
        }

        applicationScope.launch(Dispatchers.IO) {
            dataStore.data
                .map { 
                    listOf(
                        it[AutoClearCacheEnabledKey],
                        it[AutoClearCacheThresholdKey],
                        it[AutoClearImageCacheKey],
                        it[AutoClearNetworkCacheKey]
                    )
                }
                .distinctUntilChanged()
                .collect {
                    runCatching {
                        com.listrovia.music.utils.CacheAutoManager.checkAndAutoClearCache(this@App)
                    }
                }
        }
    }

    @Volatile
    private var cachedCoilCacheSize: Int? = null

    override fun newImageLoader(context: PlatformContext): ImageLoader {
        val cacheSize = cachedCoilCacheSize ?: runBlocking {
            dataStore.data.map { it[MaxImageCacheSizeKey] ?: 512 }.first()
        }
        return ImageLoader
            .Builder(this)
            .apply {
                crossfade(true)
                allowHardware(false)
                // Memory cache for fast image loading (prevents network requests on recomposition)
                memoryCache {
                    MemoryCache
                        .Builder()
                        .maxSizePercent(context, 0.15)
                        .build()
                }
                if (cacheSize == 0) {
                    diskCachePolicy(CachePolicy.DISABLED)
                } else {
                    diskCache(
                        DiskCache
                            .Builder()
                            .directory(cacheDir.resolve("coil"))
                            .maxSizeBytes(cacheSize * 1024 * 1024L)
                            .build(),
                    )
                    // Allow reading from disk cache as fallback when network is unavailable
                    networkCachePolicy(CachePolicy.ENABLED)
                }
            }.build()
    }
    companion object {
        lateinit var instance: App
            private set

        suspend fun forgetAccount(context: Context) {
            Timber.d("forgetAccount: Starting logout process")

            // Clear DataStore preferences
            Timber.d("forgetAccount: Clearing DataStore preferences")
            val cleared = context.safeDataStoreEdit { settings ->
                settings.remove(InnerTubeCookieKey)
                settings.remove(VisitorDataKey)
                settings.remove(DataSyncIdKey)
                settings.remove(AccountNameKey)
                settings.remove(AccountEmailKey)
                settings.remove(AccountChannelHandleKey)
            }
            if (!cleared) {
                Timber.e("forgetAccount: Failed to clear DataStore preferences — proceeding with in-memory cleanup only")
            } else {
                Timber.d("forgetAccount: DataStore preferences cleared")
            }

            // Immediately clear YouTube object's auth state
            Timber.d("forgetAccount: Clearing YouTube object auth state")
            Timber.d(
                "forgetAccount: Before - cookie=${YouTube.cookie?.take(
                    50,
                )}, visitorData=${YouTube.visitorData?.take(20)}, dataSyncId=${YouTube.dataSyncId?.take(20)}",
            )
            YouTube.cookie = null
            YouTube.visitorData = null
            YouTube.dataSyncId = null
            Timber.d(
                "forgetAccount: After - cookie=${YouTube.cookie}, visitorData=${YouTube.visitorData}, dataSyncId=${YouTube.dataSyncId}",
            )

            // Clear WebView cookies to prevent auto-relogin
            Timber.d("forgetAccount: Clearing WebView CookieManager")
            withContext(Dispatchers.Main) {
                android.webkit.CookieManager.getInstance().apply {
                    removeAllCookies { removed ->
                        Timber.d("forgetAccount: CookieManager.removeAllCookies callback: removed=$removed")
                    }
                    flush()
                }
            }
            Timber.d("forgetAccount: Logout process complete")
        }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        Timber.i("App.onTrimMemory: level=$level")
        runCatching {
            val imageLoader = coil3.SingletonImageLoader.get(this)
            val memoryCache = imageLoader.memoryCache
            if (memoryCache != null) {
                if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW ||
                    level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND
                ) {
                    memoryCache.trimToSize((memoryCache.maxSize * 0.25).toLong().coerceAtLeast(0L))
                } else if (level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) {
                    memoryCache.trimToSize((memoryCache.maxSize * 0.5).toLong().coerceAtLeast(0L))
                }
            }
            Unit
        }
    }

    override fun onLowMemory() {
        super.onLowMemory()
        Timber.w("App.onLowMemory: clearing memory caches")
        runCatching {
            val imageLoader = coil3.SingletonImageLoader.get(this)
            imageLoader.memoryCache?.clear()
            Unit
        }
    }
}
