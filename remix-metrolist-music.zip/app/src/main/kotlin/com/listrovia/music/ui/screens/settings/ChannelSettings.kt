/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.screens.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.listrovia.music.LocalPlayerAwareWindowInsets
import com.listrovia.music.R
import com.listrovia.music.ui.component.IconButton
import com.listrovia.music.ui.component.Material3SettingsGroup
import com.listrovia.music.ui.component.Material3SettingsItem
import com.listrovia.music.ui.utils.backToMain
import com.listrovia.music.utils.rememberPreference
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.layout.fillMaxWidth

val KeepPlaylistsPrivateKey = booleanPreferencesKey("keepPlaylistsPrivate")
val KeepSubsPrivateKey = booleanPreferencesKey("keepSubsPrivate")
val KeepLikedVideosPrivateKey = booleanPreferencesKey("keepLikedVideosPrivate")
val ShowRecentActivityKey = booleanPreferencesKey("showRecentActivity")

val ShareNonStopCollectionKey = booleanPreferencesKey("shareNonStopCollection")
val SharePersonalCollectionKey = booleanPreferencesKey("sharePersonalCollection")
val ProfileNameKey = androidx.datastore.preferences.core.stringPreferencesKey("username")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChannelSettings(
    navController: NavController
) {
    val (keepPlaylistsPrivate, onKeepPlaylistsPrivateChange) = rememberPreference(key = KeepPlaylistsPrivateKey, defaultValue = true)
    val (keepSubsPrivate, onKeepSubsPrivateChange) = rememberPreference(key = KeepSubsPrivateKey, defaultValue = true)
    val (keepLikedPrivate, onKeepLikedPrivateChange) = rememberPreference(key = KeepLikedVideosPrivateKey, defaultValue = true)
    val (showRecentActivity, onShowRecentActivityChange) = rememberPreference(key = ShowRecentActivityKey, defaultValue = false)

    val (shareNonStopCollection, onShareNonStopCollectionChange) = rememberPreference(key = ShareNonStopCollectionKey, defaultValue = false)
    val (sharePersonalCollection, onSharePersonalCollectionChange) = rememberPreference(key = SharePersonalCollectionKey, defaultValue = false)
    val (username, onUsernameChange) = rememberPreference(key = ProfileNameKey, defaultValue = stringResource(R.string.default_username))

    val (restrictedMode, onRestrictedModeChange) = rememberPreference(
        key = androidx.datastore.preferences.core.booleanPreferencesKey("restrictedModeEnabled"),
        defaultValue = false
    )
    val (hideSensitiveComments, onHideSensitiveCommentsChange) = rememberPreference(
        key = com.listrovia.music.constants.HideSensitiveCommentsKey,
        defaultValue = false
    )
    val (restrictedModeSubscribers, onRestrictedModeSubscribersChange) = rememberPreference(
        key = com.listrovia.music.constants.RestrictedModeSubscribersKey,
        defaultValue = false
    )

    val context = LocalContext.current
    var showUsernameDialog by remember { mutableStateOf(false) }
    var showAvatarInfoDialog by remember { mutableStateOf(false) }

    Column(
        Modifier
            .windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom
                )
            )
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Spacer(
            Modifier.windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Top
                )
            )
        )

        Material3SettingsGroup(
            title = stringResource(R.string.channel_privacy_group_title),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.security),
                    title = { Text(stringResource(R.string.channel_keep_playlists_private)) },
                    trailingContent = {
                        Switch(
                            checked = keepPlaylistsPrivate,
                            onCheckedChange = onKeepPlaylistsPrivateChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (keepPlaylistsPrivate) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onKeepPlaylistsPrivateChange(!keepPlaylistsPrivate) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.security),
                    title = { Text(stringResource(R.string.channel_keep_subs_private)) },
                    trailingContent = {
                        Switch(
                            checked = keepSubsPrivate,
                            onCheckedChange = onKeepSubsPrivateChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (keepSubsPrivate) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onKeepSubsPrivateChange(!keepSubsPrivate) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.favorite),
                    title = { Text(stringResource(R.string.channel_keep_liked_private)) },
                    trailingContent = {
                        Switch(
                            checked = keepLikedPrivate,
                            onCheckedChange = onKeepLikedPrivateChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (keepLikedPrivate) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onKeepLikedPrivateChange(!keepLikedPrivate) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.history),
                    title = { Text(stringResource(R.string.channel_show_recent_activity)) },
                    trailingContent = {
                        Switch(
                            checked = showRecentActivity,
                            onCheckedChange = onShowRecentActivityChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (showRecentActivity) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onShowRecentActivityChange(!showRecentActivity) }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.channel_profile_group_title),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.person),
                    title = { Text(stringResource(R.string.channel_profile_name)) },
                    description = { Text(username) },
                    onClick = { showUsernameDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.info),
                    title = { Text(stringResource(R.string.channel_photo_and_info)) },
                    description = { Text(stringResource(R.string.channel_photo_and_info_desc)) },
                    onClick = { showAvatarInfoDialog = true }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.favorite),
                    title = { Text(stringResource(R.string.channel_share_non_stop)) },
                    description = { Text(stringResource(R.string.channel_share_non_stop_desc)) },
                    trailingContent = {
                        Switch(
                            checked = shareNonStopCollection,
                            onCheckedChange = onShareNonStopCollectionChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (shareNonStopCollection) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onShareNonStopCollectionChange(!shareNonStopCollection) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.security),
                    title = { Text(stringResource(R.string.channel_adv_privacy_settings)) },
                    onClick = { navController.navigate("settings/privacy") }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.restore),
                    title = { Text(stringResource(R.string.channel_share_personal)) },
                    description = {
                        Text(stringResource(R.string.channel_share_personal_desc))
                    },
                    trailingContent = {
                        Switch(
                            checked = sharePersonalCollection,
                            onCheckedChange = onSharePersonalCollectionChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (sharePersonalCollection) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onSharePersonalCollectionChange(!sharePersonalCollection) }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        Material3SettingsGroup(
            title = stringResource(R.string.channel_restricted_group_title),
            items = listOf(
                Material3SettingsItem(
                    icon = painterResource(R.drawable.security),
                    title = { Text(stringResource(R.string.channel_restricted_mode_title)) },
                    description = { Text(stringResource(R.string.channel_restricted_mode_desc)) },
                    trailingContent = {
                        Switch(
                            checked = restrictedMode,
                            onCheckedChange = onRestrictedModeChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (restrictedMode) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onRestrictedModeChange(!restrictedMode) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.info),
                    title = { Text(stringResource(R.string.hide_sensitive_comments_title)) },
                    description = { Text(stringResource(R.string.hide_sensitive_comments_desc)) },
                    trailingContent = {
                        Switch(
                            checked = hideSensitiveComments,
                            onCheckedChange = onHideSensitiveCommentsChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (hideSensitiveComments) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onHideSensitiveCommentsChange(!hideSensitiveComments) }
                ),
                Material3SettingsItem(
                    icon = painterResource(R.drawable.account),
                    title = { Text(stringResource(R.string.restricted_subscribers_title)) },
                    description = { Text(stringResource(R.string.restricted_subscribers_desc)) },
                    trailingContent = {
                        Switch(
                            checked = restrictedModeSubscribers,
                            onCheckedChange = onRestrictedModeSubscribersChange,
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        id = if (restrictedModeSubscribers) R.drawable.check else R.drawable.close
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        )
                    },
                    onClick = { onRestrictedModeSubscribersChange(!restrictedModeSubscribers) }
                )
            )
        )

        Spacer(modifier = Modifier.height(16.dp))
    }

    if (showUsernameDialog) {
        var tempName by remember { mutableStateOf(username) }
        AlertDialog(
            onDismissRequest = { showUsernameDialog = false },
            title = { Text(stringResource(R.string.channel_change_profile_name_title)) },
            text = {
                OutlinedTextField(
                    value = tempName,
                    onValueChange = { tempName = it },
                    label = { Text(stringResource(R.string.channel_new_profile_name_label)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (tempName.trim().isNotEmpty()) {
                            onUsernameChange(tempName.trim())
                            Toast.makeText(context, context.getString(R.string.channel_profile_name_updated_toast), Toast.LENGTH_SHORT).show()
                        }
                        showUsernameDialog = false
                    }
                ) {
                    Text(stringResource(android.R.string.ok))
                }
            },
            dismissButton = {
                TextButton(onClick = { showUsernameDialog = false }) {
                    Text(stringResource(android.R.string.cancel))
                }
            }
        )
    }

    if (showAvatarInfoDialog) {
        AlertDialog(
            onDismissRequest = { showAvatarInfoDialog = false },
            title = { Text(stringResource(R.string.channel_photo_and_info)) },
            text = {
                Text(stringResource(R.string.channel_photo_info_dialog_desc))
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showAvatarInfoDialog = false
                        Toast.makeText(context, context.getString(R.string.channel_photo_info_synced_toast), Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Text(stringResource(R.string.close_btn))
                }
            }
        )
    }

    TopAppBar(
        title = { Text(stringResource(R.string.channel_settings)) },
        navigationIcon = {
            IconButton(
                onClick = navController::navigateUp,
                onLongClick = navController::backToMain,
            ) {
                Icon(
                    painterResource(R.drawable.arrow_back),
                    contentDescription = null,
                )
            }
        }
    )
}
