/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.api

import android.content.Context
import com.listrovia.innertube.YouTube
import com.listrovia.innertube.models.Album
import com.listrovia.innertube.models.Artist
import com.listrovia.innertube.models.SongItem
import com.listrovia.music.unified.AppleMusicAdapter
import com.listrovia.music.unified.UnifiedArtist
import com.listrovia.music.unified.UnifiedMusicRepository
import com.listrovia.music.unified.UnifiedPlaylist
import com.listrovia.music.unified.UnifiedTrack
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

enum class MusicSourceProvider {
    ALL,
    YOUTUBE,
    APPLE_MUSIC,
    ;

    val displayName: String
        get() = when (this) {
            ALL -> try { com.listrovia.music.App.instance.getString(com.listrovia.music.R.string.search_source_all) } catch (e: Exception) { "All" }
            YOUTUBE -> try { com.listrovia.music.App.instance.getString(com.listrovia.music.R.string.search_source_youtube) } catch (e: Exception) { "YouTube Music" }
            APPLE_MUSIC -> try { com.listrovia.music.App.instance.getString(com.listrovia.music.R.string.search_source_apple_music) } catch (e: Exception) { "Apple Music" }
        }
}

enum class MusicCountry(val code: String, val resId: Int, val flag: String) {
    VIETNAM("vn", com.listrovia.music.R.string.music_country_vn, "🇻🇳"),
    US("us", com.listrovia.music.R.string.music_country_us, "🇺🇸"),
    UK("gb", com.listrovia.music.R.string.music_country_gb, "🇬🇧"),
    JAPAN("jp", com.listrovia.music.R.string.music_country_jp, "🇯🇵"),
    KOREA("kr", com.listrovia.music.R.string.music_country_kr, "🇰🇷"),
    FRANCE("fr", com.listrovia.music.R.string.music_country_fr, "🇫🇷"),
    ;

    val displayName: String
        get() {
            return try {
                com.listrovia.music.App.instance.getString(resId)
            } catch (e: Exception) {
                when (this) {
                    VIETNAM -> "Việt Nam"
                    US -> "Toàn cầu / US"
                    UK -> "Vương quốc Anh"
                    JAPAN -> "Nhật Bản"
                    KOREA -> "Hàn Quốc"
                    FRANCE -> "Pháp"
                }
            }
        }
}

enum class MusicCategory(val id: String, val resId: Int, val emoji: String, val isKidsFamily: Boolean = false) {
    ALL("all", com.listrovia.music.R.string.music_category_all, "🌟"),
    KIDS_FAMILY("kids", com.listrovia.music.R.string.music_category_kids, "👶", isKidsFamily = true),
    VPOP("vpop", com.listrovia.music.R.string.music_category_vpop, "🇻🇳"),
    POP_GLOBAL("pop", com.listrovia.music.R.string.music_category_pop, "🌍"),
    KPOP_JPOP("asian", com.listrovia.music.R.string.music_category_asian, "🌸"),
    CHILL_ACOUSTIC("chill", com.listrovia.music.R.string.music_category_chill, "☕"),
    EDM_DANCE("dance", com.listrovia.music.R.string.music_category_dance, "⚡"),
    ;

    val title: String
        get() {
            return try {
                com.listrovia.music.App.instance.getString(resId)
            } catch (e: Exception) {
                when (this) {
                    ALL -> "Tất cả"
                    KIDS_FAMILY -> "Thiếu nhi & Cho Cháu"
                    VPOP -> "V-Pop & Trữ tình"
                    POP_GLOBAL -> "Pop & US-UK"
                    KPOP_JPOP -> "K-Pop & J-Pop"
                    CHILL_ACOUSTIC -> "Thư giãn & Acoustic"
                    EDM_DANCE -> "Sôi động & EDM"
                }
            }
        }
}

data class ExternalTrack(
    val id: String,
    val title: String,
    val artist: String,
    val album: String = "",
    val thumbnailUrl: String = "",
    val durationSeconds: Int? = null,
    val provider: MusicSourceProvider,
    val previewUrl: String? = null,
    val externalUrl: String? = null,
    val isExplicit: Boolean = false,
    val resolvedVideoId: String? = null,
    val countryCode: String = "vn",
    val categoryId: String = "all",
) {
    val uniqueId: String
        get() {
            val prefix = when (provider) {
                MusicSourceProvider.APPLE_MUSIC -> "am_"
                MusicSourceProvider.YOUTUBE -> "yt_"
                else -> "ext_"
            }
            val cleanId = id.replace(Regex("[^a-zA-Z0-9_]"), "")
            return if (cleanId.startsWith("am_") || cleanId.startsWith("yt_")) {
                cleanId
            } else {
                "$prefix$cleanId"
            }
        }

    fun toSongItem(resolvedId: String? = null): SongItem {
        val targetId = resolvedId ?: resolvedVideoId ?: uniqueId
        return SongItem(
            id = targetId,
            title = title,
            artists = listOf(Artist(name = artist, id = null)),
            album = if (album.isNotBlank()) Album(name = album, id = "") else null,
            duration = durationSeconds,
            thumbnail = thumbnailUrl,
            explicit = isExplicit
        )
    }
}

data class ExternalPlaylist(
    val id: String,
    val title: String,
    val description: String = "",
    val thumbnailUrl: String = "",
    val trackCount: Int? = null,
    val provider: MusicSourceProvider,
    val externalUrl: String? = null,
)

data class ExternalArtist(
    val id: String,
    val name: String,
    val thumbnailUrl: String = "",
    val followers: String? = null,
    val genres: List<String> = emptyList(),
    val provider: MusicSourceProvider,
    val externalUrl: String? = null,
)

data class UserComment(
    val id: String,
    val authorName: String,
    val authorAvatarUrl: String = "",
    val content: String,
    val publishedTime: String = "",
    val likeCount: String = "",
)

@Singleton
class ExternalMusicProviderService @Inject constructor(
    @ApplicationContext private val context: Context,
    val appleMusicAdapter: AppleMusicAdapter = AppleMusicAdapter(),
) {
    val unifiedRepository: UnifiedMusicRepository = UnifiedMusicRepository(appleMusicAdapter)

    /**
     * Search songs from Apple Music / iTunes API via AppleMusicAdapter.
     */
    suspend fun searchAppleMusic(query: String, limit: Int = 25): List<ExternalTrack> {
        return appleMusicAdapter.searchTracks(query, limit).map { it.toExternalTrack() }
    }

    /**
     * Search Artists from Apple Music API via Unified Music Interface.
     */
    suspend fun searchArtists(
        query: String,
        provider: MusicSourceProvider = MusicSourceProvider.ALL
    ): List<ExternalArtist> {
        return unifiedRepository.searchArtists(query, provider).map { it.toExternalArtist() }
    }

    /**
     * Search Playlists from Apple Music API via Unified Music Interface.
     */
    suspend fun searchPlaylists(
        query: String,
        provider: MusicSourceProvider = MusicSourceProvider.ALL
    ): List<ExternalPlaylist> {
        return unifiedRepository.searchPlaylists(query, provider).map { it.toExternalPlaylist() }
    }

    /**
     * Fetches Apple Music Top Hits & Charts based on selected Country & Category.
     */
    suspend fun getAppleMusicCharts(
        country: MusicCountry = MusicCountry.VIETNAM,
        category: MusicCategory = MusicCategory.ALL,
    ): List<ExternalTrack> {
        return appleMusicAdapter.getRecommendations(country, category).map { it.toExternalTrack() }
    }

    /**
     * Fetches Apple Music Top Playlists based on selected Country & Category.
     */
    suspend fun getAppleMusicPlaylists(
        country: MusicCountry = MusicCountry.VIETNAM,
        category: MusicCategory = MusicCategory.ALL,
    ): List<ExternalPlaylist> {
        return appleMusicAdapter.getFeaturedPlaylists(country, category).map { it.toExternalPlaylist() }
    }

    /**
     * Fetches Top Artists on Apple Music based on selected Country & Category.
     */
    suspend fun getTopAppleMusicArtists(
        country: MusicCountry = MusicCountry.VIETNAM,
        category: MusicCategory = MusicCategory.ALL,
    ): List<ExternalArtist> {
        return appleMusicAdapter.getTopArtists(country, category).map { it.toExternalArtist() }
    }

    /**
     * Resolves an external track to a playable YouTube videoId with concurrent thread-safe cache.
     */
    suspend fun resolveToPlayableVideoId(title: String, artist: String): String? {
        return unifiedRepository.resolveToPlayableVideoId(title, artist)
    }

    /**
     * Fetches real user comments for a song/video in real time.
     */
    suspend fun fetchCommentsForVideo(videoId: String): List<UserComment> {
        return unifiedRepository.fetchCommentsForVideo(videoId)
    }
}
