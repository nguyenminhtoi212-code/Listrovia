/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.api

import android.content.Context
import android.content.SharedPreferences
import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.statement.bodyAsText
import io.ktor.http.isSuccess
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import timber.log.Timber
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

data class DeepInfraModelItem(
    val id: String,
    val name: String,
    val providerName: String = "",
    val description: String = "",
    val descriptionVi: String = "",
    val contextLength: Long = 0L,
    val maxTokens: Long = 0L,
    val tags: List<String> = emptyList(),
    val inputCost: Double = 0.0,
    val outputCost: Double = 0.0,
    val isChat: Boolean = true,
    val isReasoning: Boolean = false,
    val rank: Int = 999,
    val rankTitleEn: String = "",
    val rankTitleVi: String = "",
) {
    val formattedContext: String
        get() = when {
            contextLength >= 1048576L -> "${contextLength / 1048576L}M"
            contextLength >= 1024L -> "${contextLength / 1024L}k"
            contextLength > 0L -> "$contextLength"
            else -> ""
        }

    val pricingBadge: String
        get() = when {
            inputCost == 0.0 && outputCost == 0.0 -> "Free"
            inputCost > 0.0 -> String.format(Locale.US, "$%.2f/M", inputCost)
            else -> ""
        }

    fun getDescriptionByLanguage(isVi: Boolean): String {
        return if (isVi && descriptionVi.isNotBlank()) descriptionVi else description
    }

    fun getRankTitleByLanguage(isVi: Boolean): String {
        return if (isVi && rankTitleVi.isNotBlank()) rankTitleVi else rankTitleEn
    }
}

data class DeepInfraClassifiedModels(
    val recommended: List<DeepInfraModelItem> = emptyList(),
    val chatModels: List<DeepInfraModelItem> = emptyList(),
    val reasoningModels: List<DeepInfraModelItem> = emptyList(),
    val allModels: List<DeepInfraModelItem> = emptyList(),
    val timestamp: Long = System.currentTimeMillis(),
) {
    val rankedModels: List<DeepInfraModelItem> get() = recommended
}

/**
 * Trình quản lý mô hình DeepInfra tải dữ liệu 100% thời gian thực từ
 * https://api.deepinfra.com/v1/openai/models.
 *
 * Sử dụng extension function [JSONObject.toModelItem] để đóng gói logic phân tích cú pháp,
 * trích xuất an toàn tất cả các trường siêu dữ liệu với giá trị mặc định hợp lý.
 */
class DeepInfraModelManager(
    cacheTTLMinutes: Long = 15L,
    private val context: Context? = null,
) {
    private val apiUrl = "https://api.deepinfra.com/v1/openai/models"
    private val storageKey = "deepinfra_models_realtime_cache_v2"
    private val cacheTTL = cacheTTLMinutes * 60 * 1000L

    private var memoryCache: Pair<Long, DeepInfraClassifiedModels>? = null
    private val fetchMutex = Mutex()

    private val ktorClient: HttpClient by lazy {
        HttpClient(OkHttp) {
            install(HttpTimeout) {
                requestTimeoutMillis = 20_000L
                connectTimeoutMillis = 15_000L
                socketTimeoutMillis = 20_000L
            }
            expectSuccess = false
        }
    }

    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    /**
     * Tải danh sách mô hình thời gian thực và áp dụng thuật toán xếp hạng động tại runtime.
     */
    suspend fun fetchModels(forceRefresh: Boolean = false): DeepInfraClassifiedModels =
        withContext(Dispatchers.IO) {
            fetchMutex.withLock {
                val now = System.currentTimeMillis()
                val cached = memoryCache
                if (!forceRefresh && cached != null && (now - cached.first < cacheTTL)) {
                    return@withLock cached.second
                }

                try {
                    // 1. Tải phản hồi JSON từ DeepInfra API qua Ktor hoặc OkHttp fallback
                    val responseBody = try {
                        val response = ktorClient.get(apiUrl) {
                            header("User-Agent", "Mozilla/5.0 (Android; Listrovia Music/1.0)")
                            header("Accept", "application/json")
                        }
                        if (!response.status.isSuccess()) {
                            throw Exception("Ktor HTTP Error from DeepInfra: ${response.status.value}")
                        }
                        val body = response.bodyAsText()
                        if (body.isBlank()) throw Exception("Empty body from Ktor")
                        body
                    } catch (ktorErr: Exception) {
                        Timber.w(ktorErr, "Ktor request to DeepInfra failed, trying OkHttp fallback")
                        val request = Request.Builder()
                            .url(apiUrl)
                            .addHeader("User-Agent", "Mozilla/5.0 (Android; Listrovia Music/1.0)")
                            .addHeader("Accept", "application/json")
                            .get()
                            .build()
                        val response = okHttpClient.newCall(request).execute()
                        if (!response.isSuccessful) {
                            throw Exception("OkHttp Error from DeepInfra: ${response.code}")
                        }
                        response.body?.string() ?: throw Exception("Empty response body from DeepInfra")
                    }

                    val rawData = JSONObject(responseBody)
                    val rawModels = rawData.optJSONArray("data") ?: JSONArray()

                    // 2. Phân tích gọn gàng sử dụng extension function JSONObject.toModelItem(id)
                    val rawParsedList = mutableListOf<RawModelMeta>()
                    for (i in 0 until rawModels.length()) {
                        val obj = rawModels.optJSONObject(i) ?: continue
                        val id = obj.optString("id", "").trim()
                        if (id.isBlank()) continue

                        try {
                            rawParsedList.add(obj.toModelItem(id))
                        } catch (itemErr: Exception) {
                            Timber.w(itemErr, "Bỏ qua mô hình không hợp lệ tại index $i")
                        }
                    }

                    if (rawParsedList.isEmpty()) {
                        throw Exception("Không tìm thấy mô hình hợp lệ từ API DeepInfra")
                    }

                    // 3. Thực thi thuật toán sắp xếp động tại Runtime (Runtime Dynamic Sorting Algorithm)
                    val scoredList = rawParsedList.mapIndexed { index, raw ->
                        val dynamicScore = calculateRuntimeModelScore(raw, rawIndex = index)
                        raw to dynamicScore
                    }

                    // Sắp xếp giảm dần theo điểm số năng lực tại runtime
                    val sortedByScore = scoredList.sortedByDescending { it.second }.map { it.first }

                    val allList = mutableListOf<DeepInfraModelItem>()
                    val chatList = mutableListOf<DeepInfraModelItem>()
                    val reasoningList = mutableListOf<DeepInfraModelItem>()
                    val recommendedList = mutableListOf<DeepInfraModelItem>()

                    for ((rankIndex, raw) in sortedByScore.withIndex()) {
                        val currentRank = rankIndex + 1
                        val (rankTitleEn, rankTitleVi) = generateDynamicRankTitles(raw, currentRank)

                        val item = DeepInfraModelItem(
                            id = raw.id,
                            name = raw.name,
                            providerName = raw.provider,
                            description = raw.description,
                            descriptionVi = raw.description,
                            contextLength = raw.contextLength,
                            maxTokens = raw.maxTokens,
                            tags = raw.tags,
                            inputCost = raw.inputCost,
                            outputCost = raw.outputCost,
                            isChat = raw.isChat,
                            isReasoning = raw.isReasoning,
                            rank = if (currentRank <= 10) currentRank else 999,
                            rankTitleEn = rankTitleEn,
                            rankTitleVi = rankTitleVi,
                        )

                        allList.add(item)
                        if (raw.isChat) chatList.add(item)
                        if (raw.isReasoning) reasoningList.add(item)
                        if (raw.isChat && currentRank <= 20) recommendedList.add(item)
                    }

                    val classified = DeepInfraClassifiedModels(
                        recommended = if (recommendedList.isNotEmpty()) recommendedList else chatList.take(20),
                        chatModels = if (chatList.isNotEmpty()) chatList else allList,
                        reasoningModels = reasoningList,
                        allModels = allList,
                        timestamp = now,
                    )

                    memoryCache = Pair(now, classified)
                    saveToLocalStorage(classified)
                    Timber.i("Tải thành công và phân loại ${allList.size} mô hình từ DeepInfra API")
                    classified
                } catch (e: Exception) {
                    Timber.w(e, "Lỗi khi tải mô hình từ DeepInfra, khôi phục từ bộ nhớ đệm cục bộ")
                    loadFromLocalStorage() ?: DeepInfraClassifiedModels()
                }
            }
        }

    /**
     * Extension function đóng gói logic phân tích cú pháp từ JSONObject thành [RawModelMeta].
     * Trích xuất an toàn tất cả các trường siêu dữ liệu bằng safe navigation và giá trị mặc định hợp lý.
     */
    private fun JSONObject.toModelItem(id: String): RawModelMeta {
        val ownedBy = optString("owned_by", "").trim()
        val provider = if (ownedBy.isNotBlank()) {
            ownedBy
        } else if (id.contains("/")) {
            id.substringBefore("/")
        } else {
            "deepinfra"
        }
        val modelName = if (id.contains("/")) id.substringAfter("/") else id

        val metadata = optJSONObject("metadata")

        val description = metadata?.optString("description", "")?.ifBlank { null }
            ?: optString("description", "")

        val contextLength = metadata?.optLong("context_length", 0L)?.takeIf { it > 0L }
            ?: metadata?.optLong("reported_context_length", 0L)?.takeIf { it > 0L }
            ?: optLong("context_length", 0L)

        val maxTokens = metadata?.optLong("max_tokens", 0L)?.takeIf { it > 0L }
            ?: optLong("max_tokens", 0L)

        var inputCost = 0.0
        var outputCost = 0.0
        val pricing = metadata?.optJSONObject("pricing") ?: optJSONObject("pricing")
        if (pricing != null) {
            inputCost = pricing.optDouble("input_tokens", pricing.optDouble("prompt", 0.0))
            outputCost = pricing.optDouble("output_tokens", pricing.optDouble("completion", 0.0))
        }

        val tagsArray = metadata?.optJSONArray("tags") ?: optJSONArray("tags")
        val tags = mutableListOf<String>()
        if (tagsArray != null) {
            for (t in 0 until tagsArray.length()) {
                val tag = tagsArray.optString(t, "").trim()
                if (tag.isNotBlank()) {
                    tags.add(tag)
                }
            }
        }

        val isReasoning = tags.any { tag ->
            tag.equals("reasoning", ignoreCase = true) ||
                tag.equals("think", ignoreCase = true) ||
                tag.equals("thinking", ignoreCase = true)
        }

        val isChat = tags.isEmpty() || tags.any { tag ->
            tag.equals("chat", ignoreCase = true) ||
                tag.equals("text-generation", ignoreCase = true) ||
                tag.equals("instruct", ignoreCase = true) ||
                tag.equals("llm", ignoreCase = true) ||
                tag.equals("nlp", ignoreCase = true) ||
                tag.equals("general", ignoreCase = true)
        } || isReasoning

        return RawModelMeta(
            id = id,
            name = modelName,
            provider = provider,
            description = description,
            contextLength = contextLength,
            maxTokens = maxTokens,
            tags = tags,
            inputCost = inputCost,
            outputCost = outputCost,
            isChat = isChat,
            isReasoning = isReasoning,
        )
    }

    /**
     * Thuật toán tính điểm xếp hạng động tại runtime dựa trên các thuộc tính metadata:
     * 1. 'tags' presence: Các thẻ hiệu năng (featured, popular, translation, reasoning, fast, v.v.)
     * 2. 'context_length': Độ lớn của cửa sổ ngữ cảnh (token capacity)
     * 3. 'input_cost': Hiệu quả chi phí token (cost-efficiency / affordable pricing)
     * 4. 'model version & parameters': Tham số và phiên bản mô hình được phân tích qua regex
     */
    private fun calculateRuntimeModelScore(meta: RawModelMeta, rawIndex: Int): Double {
        var score = 0.0

        // 1. Đánh giá dựa trên sự hiện diện của các thẻ 'tags' (Tags Presence Weighting)
        meta.tags.forEach { tag ->
            when (tag.lowercase().trim()) {
                "featured", "recommended", "flagship" -> score += 500.0
                "popular", "trending", "verified" -> score += 350.0
                "translation", "translate", "multilingual" -> score += 400.0
                "reasoning", "thinking", "cot" -> score += 300.0
                "fast", "turbo", "speed", "latency" -> score += 200.0
                "chat", "text-generation", "instruct", "llm" -> score += 150.0
                "code", "coding", "math" -> score += 100.0
                else -> score += 20.0 // Điểm hiện diện thẻ thông thường
            }
        }

        // 2. Đánh giá dựa trên độ dài ngữ cảnh 'context_length' (Context Length Weighting)
        if (meta.contextLength > 0L) {
            val contextK = meta.contextLength / 1024.0
            score += when {
                contextK >= 1000.0 -> 500.0 // 1M+ tokens
                contextK >= 256.0 -> 400.0  // 256k tokens
                contextK >= 128.0 -> 300.0  // 128k tokens
                contextK >= 64.0 -> 200.0   // 64k tokens
                contextK >= 32.0 -> 150.0   // 32k tokens
                contextK >= 8.0 -> 80.0     // 8k tokens
                else -> 40.0
            }
        }

        // 3. Đánh giá dựa trên chi phí đầu vào 'input_cost' (Input Cost & Efficiency Weighting)
        score += when {
            meta.inputCost == 0.0 && meta.outputCost == 0.0 -> 150.0 // Hoàn toàn miễn phí
            meta.inputCost in 0.001..0.20 -> 120.0                  // Chi phí siêu thấp (< $0.20/M)
            meta.inputCost in 0.20..0.60 -> 80.0                    // Chi phí trung bình
            meta.inputCost > 0.60 -> 30.0                           // Chi phí cao / Premium
            else -> 60.0
        }

        // 4. Đánh giá phiên bản & kích thước tham số mô hình động (Dynamic Model Version / Parameters)
        val nameLower = meta.name.lowercase()
        val paramPattern = Pattern.compile("(\\d+)b\\b")
        val paramMatcher = paramPattern.matcher(nameLower)
        if (paramMatcher.find()) {
            val paramSize = paramMatcher.group(1)?.toDoubleOrNull() ?: 0.0
            score += (paramSize * 2.5).coerceAtMost(250.0)
        }

        val versionPattern = Pattern.compile("[rv]?(\\d+(?:\\.\\d+)?)")
        val versionMatcher = versionPattern.matcher(nameLower)
        if (versionMatcher.find()) {
            val versionNum = versionMatcher.group(1)?.toDoubleOrNull() ?: 0.0
            if (versionNum >= 3.0) score += 100.0
            else if (versionNum >= 2.0) score += 50.0
        }

        // 5. Ưu tiên mô hình Chat & điều chỉnh thứ tự gốc API
        if (meta.isChat) score += 100.0
        score -= (rawIndex * 0.5)

        return score
    }

    /**
     * Tạo tiêu đề xếp hạng động (Dynamic Rank Badges) cho các mô hình hàng đầu tại runtime
     */
    private fun generateDynamicRankTitles(meta: RawModelMeta, rank: Int): Pair<String, String> {
        if (rank > 10) return Pair("", "")

        val providerCap = meta.provider.replaceFirstChar { it.uppercase() }
        val titleEn = when {
            rank == 1 -> "#1 Top Performer: ${meta.name}"
            meta.isReasoning -> "#$rank Reasoning: ${meta.name}"
            meta.tags.any { it.equals("fast", true) || it.equals("turbo", true) } -> "#$rank Fast: ${meta.name}"
            meta.contextLength >= 131072L -> "#$rank High Context: ${meta.name}"
            else -> "#$rank $providerCap: ${meta.name}"
        }

        val titleVi = when {
            rank == 1 -> "#1 Hiệu năng hàng đầu: ${meta.name}"
            meta.isReasoning -> "#$rank Suy luận chuyên sâu: ${meta.name}"
            meta.tags.any { it.equals("fast", true) || it.equals("turbo", true) } -> "#$rank Tốc độ cao: ${meta.name}"
            meta.contextLength >= 131072L -> "#$rank Ngữ cảnh lớn: ${meta.name}"
            else -> "#$rank $providerCap: ${meta.name}"
        }

        return Pair(titleEn, titleVi)
    }

    private suspend fun saveToLocalStorage(classified: DeepInfraClassifiedModels) {
        val prefs = getPreferences() ?: return
        try {
            val root = JSONObject()
            root.put("timestamp", classified.timestamp)

            fun serializeList(list: List<DeepInfraModelItem>): JSONArray {
                val array = JSONArray()
                for (item in list) {
                    val o = JSONObject()
                    o.put("id", item.id)
                    o.put("name", item.name)
                    o.put("provider", item.providerName)
                    o.put("description", item.description)
                    o.put("description_vi", item.descriptionVi)
                    o.put("context_length", item.contextLength)
                    o.put("max_tokens", item.maxTokens)
                    o.put("input_cost", item.inputCost)
                    o.put("output_cost", item.outputCost)
                    o.put("is_chat", item.isChat)
                    o.put("is_reasoning", item.isReasoning)
                    o.put("rank", item.rank)
                    o.put("rank_title_en", item.rankTitleEn)
                    o.put("rank_title_vi", item.rankTitleVi)
                    val tArray = JSONArray()
                    item.tags.forEach { tArray.put(it) }
                    o.put("tags", tArray)
                    array.put(o)
                }
                return array
            }

            root.put("recommended", serializeList(classified.recommended))
            root.put("chat", serializeList(classified.chatModels))
            root.put("reasoning", serializeList(classified.reasoningModels))
            root.put("all", serializeList(classified.allModels))

            prefs.edit().putString(storageKey, root.toString()).apply()

            // Lưu dữ liệu vào Room Database
            context?.let { ctx ->
                val entities = classified.allModels.map { item ->
                    val isRec = classified.recommended.any { it.id == item.id }
                    val tier = when {
                        isRec -> "Recommended"
                        item.isReasoning -> "Reasoning"
                        item.isChat -> "Chat"
                        else -> "All"
                    }
                    com.listrovia.music.db.entities.AiModelCacheEntity(
                        id = item.id,
                        provider = "DeepInfra",
                        name = item.name,
                        description = item.description,
                        descriptionVi = item.descriptionVi,
                        providerName = item.providerName,
                        tier = tier,
                        sourceCategory = com.listrovia.music.ui.component.getModelSourceCategory(item.id, item.providerName).name,
                        healthStatus = com.listrovia.music.ui.component.getModelHealthStatus(item.id, item.name).name,
                        contextLength = item.contextLength,
                        maxTokens = item.maxTokens,
                        pricingBadge = item.pricingBadge,
                        isChat = item.isChat,
                        isReasoning = item.isReasoning,
                        rank = item.rank,
                        rankTitleEn = item.rankTitleEn,
                        rankTitleVi = item.rankTitleVi,
                        cachedAt = classified.timestamp,
                    )
                }
                com.listrovia.music.db.AiModelCacheDatabase.getInstance(ctx).aiModelCacheDao().insertModels(entities)
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to cache DeepInfra models to Room / local storage")
        }
    }

    private suspend fun loadFromLocalStorage(): DeepInfraClassifiedModels? {
        // 1. Thử đọc từ Room Database
        context?.let { ctx ->
            try {
                val roomModels = com.listrovia.music.db.AiModelCacheDatabase.getInstance(ctx).aiModelCacheDao().getModelsByProvider("DeepInfra")
                if (roomModels.isNotEmpty()) {
                    fun mapToItem(e: com.listrovia.music.db.entities.AiModelCacheEntity) = DeepInfraModelItem(
                        id = e.id,
                        name = e.name,
                        providerName = e.providerName,
                        description = e.description,
                        descriptionVi = e.descriptionVi,
                        contextLength = e.contextLength,
                        maxTokens = e.maxTokens,
                        isChat = e.isChat,
                        isReasoning = e.isReasoning,
                        rank = e.rank,
                        rankTitleEn = e.rankTitleEn,
                        rankTitleVi = e.rankTitleVi,
                    )
                    val all = roomModels.map { mapToItem(it) }
                    val rec = roomModels.filter { it.tier == "Recommended" }.map { mapToItem(it) }.ifEmpty { all.take(20) }
                    val chat = roomModels.filter { it.isChat }.map { mapToItem(it) }.ifEmpty { all }
                    val reasoning = roomModels.filter { it.isReasoning }.map { mapToItem(it) }
                    return DeepInfraClassifiedModels(
                        recommended = rec,
                        chatModels = chat,
                        reasoningModels = reasoning,
                        allModels = all,
                    )
                }
            } catch (e: Exception) {
                Timber.w(e, "Lỗi đọc DeepInfra từ Room")
            }
        }

        val prefs = getPreferences() ?: return null
        val raw = prefs.getString(storageKey, null) ?: return null
        return try {
            val root = JSONObject(raw)

            fun deserializeList(key: String): List<DeepInfraModelItem> {
                val array = root.optJSONArray(key) ?: return emptyList()
                val list = mutableListOf<DeepInfraModelItem>()
                for (i in 0 until array.length()) {
                    val o = array.optJSONObject(i) ?: continue
                    val tArray = o.optJSONArray("tags")
                    val tags = mutableListOf<String>()
                    if (tArray != null) {
                        for (t in 0 until tArray.length()) {
                            val tag = tArray.optString(t, "").trim()
                            if (tag.isNotBlank()) {
                                tags.add(tag)
                            }
                        }
                    }
                    list.add(
                        DeepInfraModelItem(
                            id = o.optString("id", ""),
                            name = o.optString("name", ""),
                            providerName = o.optString("provider", ""),
                            description = o.optString("description", ""),
                            descriptionVi = o.optString("description_vi", ""),
                            contextLength = o.optLong("context_length", 0L),
                            maxTokens = o.optLong("max_tokens", 0L),
                            inputCost = o.optDouble("input_cost", 0.0),
                            outputCost = o.optDouble("output_cost", 0.0),
                            tags = tags,
                            isChat = o.optBoolean("is_chat", true),
                            isReasoning = o.optBoolean("is_reasoning", false),
                            rank = o.optInt("rank", 999),
                            rankTitleEn = o.optString("rank_title_en", ""),
                            rankTitleVi = o.optString("rank_title_vi", ""),
                        )
                    )
                }
                return list
            }

            val rec = deserializeList("recommended")
            val chat = deserializeList("chat")
            val reasoning = deserializeList("reasoning")
            val all = deserializeList("all")
            if (all.isEmpty()) null
            else DeepInfraClassifiedModels(
                recommended = rec,
                chatModels = chat,
                reasoningModels = reasoning,
                allModels = all,
                timestamp = root.optLong("timestamp", System.currentTimeMillis()),
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun getPreferences(): SharedPreferences? {
        return context?.getSharedPreferences("listrovia_deepinfra_models", Context.MODE_PRIVATE)
    }

    companion object {
        @Volatile
        private var defaultManager: DeepInfraModelManager? = null

        fun getInstance(context: Context? = null): DeepInfraModelManager {
            return defaultManager ?: synchronized(this) {
                defaultManager ?: DeepInfraModelManager(15L, context?.applicationContext).also {
                    defaultManager = it
                }
            }
        }
    }
}

private data class RawModelMeta(
    val id: String,
    val name: String,
    val provider: String,
    val description: String,
    val contextLength: Long,
    val maxTokens: Long,
    val tags: List<String>,
    val inputCost: Double,
    val outputCost: Double,
    val isChat: Boolean,
    val isReasoning: Boolean,
)
