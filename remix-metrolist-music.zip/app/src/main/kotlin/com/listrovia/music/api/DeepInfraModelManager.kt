package com.listrovia.music.api

import android.content.Context
import android.content.SharedPreferences
import com.listrovia.music.constants.DeepInfraDefaultModel
import com.listrovia.music.constants.DeepInfraModelsUrl
import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.statement.bodyAsText
import io.ktor.http.isSuccess
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import timber.log.Timber
import java.util.Locale
import java.util.concurrent.TimeUnit

data class DeepInfraModelItem(
    val id: String,
    val name: String,
    val providerName: String = "",
    val description: String = "",
    val descriptionVi: String = "",
    val contextLength: Long = 0L,
    val maxTokens: Long = 0L,
    val tags: List<String> = emptyList(),
    val inputCost: Double = 0.0,
    val outputCost: Double = 0.0,
    val isChat: Boolean = true,
    val isReasoning: Boolean = false,
    val rank: Int = 999,
    val rankTitleEn: String = "",
    val rankTitleVi: String = "",
) {
    val formattedContext: String
        get() = when {
            contextLength >= 1048576L -> "${contextLength / 1048576L}M"
            contextLength >= 1024L -> "${contextLength / 1024L}k"
            contextLength > 0L -> "$contextLength"
            else -> ""
        }

    val pricingBadge: String
        get() = when {
            inputCost == 0.0 && outputCost == 0.0 -> "Free"
            inputCost > 0.0 -> String.format(Locale.US, "$%.2f/M", inputCost)
            else -> ""
        }

    fun getDescriptionByLanguage(isVi: Boolean): String {
        return if (isVi && descriptionVi.isNotBlank()) descriptionVi else description
    }

    fun getRankTitleByLanguage(isVi: Boolean): String {
        return if (isVi && rankTitleVi.isNotBlank()) rankTitleVi else rankTitleEn
    }
}

data class DeepInfraClassifiedModels(
    val recommended: List<DeepInfraModelItem>,
    val chatModels: List<DeepInfraModelItem>,
    val reasoningModels: List<DeepInfraModelItem>,
    val allModels: List<DeepInfraModelItem>,
    val timestamp: Long = System.currentTimeMillis(),
) {
    val rankedModels: List<DeepInfraModelItem> get() = recommended
}

class DeepInfraModelManager(
    private val cacheTTLMinutes: Long = 15L,
    private val context: Context? = null,
) {
    private val apiUrl = DeepInfraModelsUrl
    private val storageKey = "deepinfra_models_realtime_cache_v2"
    private val cacheTTL = cacheTTLMinutes * 60 * 1000L

    private var memoryCache: Pair<Long, DeepInfraClassifiedModels>? = null
    private val fetchMutex = Mutex()

    private val ktorClient: HttpClient by lazy {
        HttpClient(OkHttp) {
            install(HttpTimeout) {
                requestTimeoutMillis = 20_000L
                connectTimeoutMillis = 15_000L
                socketTimeoutMillis = 20_000L
            }
            expectSuccess = false
        }
    }

    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    suspend fun fetchModels(forceRefresh: Boolean = false): DeepInfraClassifiedModels =
        withContext(Dispatchers.IO) {
            fetchMutex.withLock {
                val now = System.currentTimeMillis()
                val cached = memoryCache
                if (!forceRefresh && cached != null && (now - cached.first < cacheTTL)) {
                    return@withLock cached.second
                }

                try {
                    // Fetch models using Ktor client directly from https://api.deepinfra.com/v1/openai/models
                val responseBody = try {
                    val response = ktorClient.get(apiUrl) {
                        header("User-Agent", "Mozilla/5.0 (Android; Listrovia Music/1.0)")
                        header("Accept", "application/json")
                    }
                    if (!response.status.isSuccess()) {
                        throw Exception("Ktor HTTP Error from DeepInfra: ${response.status.value}")
                    }
                    val body = response.bodyAsText()
                    if (body.isBlank()) throw Exception("Empty body from Ktor")
                    body
                } catch (ktorErr: Exception) {
                    Timber.w(ktorErr, "Ktor request to DeepInfra failed, trying OkHttp fallback")
                    val request = Request.Builder()
                        .url(apiUrl)
                        .addHeader("User-Agent", "Mozilla/5.0 (Android; Listrovia Music/1.0)")
                        .addHeader("Accept", "application/json")
                        .get()
                        .build()
                    val response = okHttpClient.newCall(request).execute()
                    if (!response.isSuccessful) {
                        throw Exception("OkHttp Error from DeepInfra: ${response.code}")
                    }
                    response.body?.string() ?: throw Exception("Empty response body from DeepInfra")
                }

                val rawData = JSONObject(responseBody)
                val rawModels = rawData.optJSONArray("data") ?: JSONArray()

                val allList = mutableListOf<DeepInfraModelItem>()
                val chatList = mutableListOf<DeepInfraModelItem>()
                val reasoningList = mutableListOf<DeepInfraModelItem>()

                for (i in 0 until rawModels.length()) {
                    val obj = rawModels.optJSONObject(i) ?: continue
                    val id = obj.optString("id", "")
                    if (id.isBlank()) continue

                    val ownedBy = obj.optString("owned_by", "")
                    val provider = if (ownedBy.isNotBlank()) ownedBy else (if (id.contains("/")) id.substringBefore("/") else "deepinfra")
                    val modelName = if (id.contains("/")) id.substringAfter("/") else id

                    val metadata = obj.optJSONObject("metadata")
                    val description = metadata?.optString("description", "") ?: ""
                    val contextLength = metadata?.optLong("context_length", 0L) ?: 0L
                    val maxTokens = metadata?.optLong("max_tokens", 0L) ?: 0L

                    var inputCost = 0.0
                    var outputCost = 0.0
                    val pricing = metadata?.optJSONObject("pricing")
                    if (pricing != null) {
                        inputCost = pricing.optDouble("input_tokens", 0.0)
                        outputCost = pricing.optDouble("output_tokens", 0.0)
                    }

                    val tagsArray = metadata?.optJSONArray("tags")
                    val tags = mutableListOf<String>()
                    if (tagsArray != null) {
                        for (t in 0 until tagsArray.length()) {
                            tags.add(tagsArray.optString(t))
                        }
                    }

                    val isReasoning = tags.contains("reasoning") ||
                            id.contains("R1", ignoreCase = true) ||
                            id.contains("reasoning", ignoreCase = true) ||
                            id.contains("o1", ignoreCase = true) ||
                            id.contains("o3", ignoreCase = true)

                    val isChat = tags.contains("chat") || tags.contains("text-generation") ||
                            id.contains("Instruct", ignoreCase = true) ||
                            id.contains("chat", ignoreCase = true) ||
                            id.contains("deepseek", ignoreCase = true) ||
                            id.contains("llama", ignoreCase = true) ||
                            id.contains("qwen", ignoreCase = true) ||
                            id.contains("mistral", ignoreCase = true) ||
                            id.contains("gemma", ignoreCase = true) ||
                            id.contains("gemini", ignoreCase = true) ||
                            id.contains("claude", ignoreCase = true) ||
                            id.contains("GLM", ignoreCase = true) ||
                            id.contains("MiMo", ignoreCase = true) ||
                            id.contains("Kimi", ignoreCase = true) ||
                            isReasoning

                    val (rank, rankTitleEn, rankTitleVi, customDescVi) = determineRankAndInfo(id, isReasoning)

                    val descriptionVi = if (customDescVi.isNotBlank()) {
                        customDescVi
                    } else {
                        generateVietnameseDescription(id, provider, tags, contextLength, isReasoning)
                    }

                    val item = DeepInfraModelItem(
                        id = id,
                        name = modelName,
                        providerName = provider,
                        description = description,
                        descriptionVi = descriptionVi,
                        contextLength = contextLength,
                        maxTokens = maxTokens,
                        tags = tags,
                        inputCost = inputCost,
                        outputCost = outputCost,
                        isChat = isChat,
                        isReasoning = isReasoning,
                        rank = rank,
                        rankTitleEn = rankTitleEn,
                        rankTitleVi = rankTitleVi,
                    )

                    allList.add(item)
                    if (isChat) chatList.add(item)
                    if (isReasoning) reasoningList.add(item)
                }

                // Sort recommended models strictly by rank
                val recommendedList = allList
                    .filter { it.rank < 999 }
                    .sortedBy { it.rank }
                    .toMutableList()

                // If recommended list has fewer than 8, supplement with top chat models
                if (recommendedList.size < 8) {
                    for (item in chatList) {
                        if (!recommendedList.contains(item)) {
                            recommendedList.add(item)
                            if (recommendedList.size >= 12) break
                        }
                    }
                }

                if (allList.isEmpty()) {
                    throw Exception("No valid models parsed from DeepInfra API")
                }

                val classified = DeepInfraClassifiedModels(
                    recommended = recommendedList,
                    chatModels = if (chatList.isNotEmpty()) chatList else allList,
                    reasoningModels = reasoningList,
                    allModels = allList,
                    timestamp = now,
                )

                memoryCache = Pair(now, classified)
                saveToLocalStorage(classified)
                Timber.i("Successfully loaded ${allList.size} real-time models from DeepInfra")
                classified
            } catch (e: Exception) {
                Timber.w(e, "Error fetching models from DeepInfra, falling back to local storage or defaults")
                loadFromLocalStorage() ?: getStaticFallback()
            }
          }
        }

    private fun determineRankAndInfo(id: String, isReasoning: Boolean): Quadruple<Int, String, String, String> {
        val lower = id.lowercase()
        return when {
            lower.contains("deepseek-v3") -> Quadruple(
                1,
                "#1 Flagship Chat: DeepSeek-V3",
                "#1 Trò chuyện hàng đầu: DeepSeek-V3",
                "Mô hình ngôn ngữ MoE 671 tỷ tham số cực mạnh từ DeepSeek, dịch thuật lời bài hát siêu việt."
            )
            lower.contains("deepseek-r1") -> Quadruple(
                2,
                "#2 Flagship Reasoning: DeepSeek-R1",
                "#2 Suy luận hàng đầu: DeepSeek-R1",
                "Mô hình tư duy lý luận R1 hàng đầu thế giới với chuỗi suy nghĩ từng bước chuyên sâu."
            )
            lower.contains("llama-3.3-70b") -> Quadruple(
                3,
                "#3 Meta Flagship: Llama-3.3-70B",
                "#3 Meta hàng đầu: Llama-3.3-70B",
                "Mô hình 70 tỷ tham số xuất sắc từ Meta AI, thấu hiểu ngữ cảnh và cấu trúc câu từ tự nhiên."
            )
            lower.contains("qwen2.5-coder") -> Quadruple(
                4,
                "#4 Coding Master: Qwen2.5-Coder",
                "#4 Chuyên gia lập trình: Qwen2.5-Coder",
                "Mô hình chuyên sâu về cấu trúc logic, phân tích mã nguồn và lập trình từ Alibaba."
            )
            lower.contains("qwen2.5-72b") -> Quadruple(
                5,
                "#5 Asian Languages: Qwen2.5-72B",
                "#5 Ngôn ngữ châu Á: Qwen2.5-72B",
                "Bậc thầy ngôn ngữ châu Á và tiếng Việt từ Alibaba, nắm bắt sắc sảo mọi thành ngữ."
            )
            lower.contains("meta-llama-3.1-8b") -> Quadruple(
                6,
                "#6 Meta Lightweight: Llama-3.1-8B",
                "#6 Meta gọn nhẹ: Llama-3.1-8B",
                "Mô hình 8B gọn nhẹ từ Meta AI, lý tưởng cho tốc độ phản hồi nhanh và độ trễ thấp."
            )
            lower.contains("mistral-nemo") -> Quadruple(
                7,
                "#7 European Flagship: Mistral Nemo 12B",
                "#7 Pháp hàng đầu: Mistral Nemo 12B",
                "Mô hình 12B hợp tác bởi Mistral AI và NVIDIA, dịch thuật sắc bén tinh tế."
            )
            else -> Quadruple(999, "", "", "")
        }
    }

    private fun generateVietnameseDescription(
        id: String,
        provider: String,
        tags: List<String>,
        contextLength: Long,
        isReasoning: Boolean,
    ): String {
        val lower = id.lowercase()
        val contextStr = if (contextLength >= 1024L) "với cửa sổ ngữ cảnh ${contextLength / 1024L}k tokens" else ""

        return when {
            isReasoning -> "Mô hình suy luận logic chuyên sâu với cơ chế phân tích từng bước, tối ưu cho ngữ cảnh phức tạp $contextStr."
            tags.contains("code") || lower.contains("code") || lower.contains("coder") ->
                "Mô hình chuyên sâu về cấu trúc logic và lập trình cú pháp $contextStr, độ chính xác tuyệt đối."
            tags.contains("vision") || tags.contains("vlm") || lower.contains("vl") ->
                "Mô hình đa phương thức tiên tiến kết hợp thị giác và xử lý ngôn ngữ tự nhiên $contextStr."
            lower.contains("qwen") ->
                "Mô hình ngôn ngữ thế hệ mới từ Alibaba, đặc biệt xuất sắc trong việc thấu hiểu tiếng Việt và ngữ nghĩa Á Đông."
            lower.contains("llama") ->
                "Mô hình mã nguồn mở hàng đầu từ Meta AI $contextStr, văn phong tự nhiên và diễn đạt mạch lạc."
            lower.contains("deepseek") ->
                "Mô hình hiệu năng cao từ DeepSeek, xử lý dịch thuật nhanh chóng và chuẩn xác."
            lower.contains("gemma") ->
                "Mô hình mã nguồn mở hiện đại từ Google DeepMind $contextStr, đáng tin cậy và đa ngôn ngữ."
            lower.contains("mistral") ->
                "Mô hình hiệu năng cao từ châu Âu, phản hồi gọn gàng và tiết kiệm độ trễ."
            lower.contains("flux") ->
                "Mô hình tạo ảnh đồ họa chất lượng cao của Black Forest Labs."
            else ->
                "Mô hình trí tuệ nhân tạo thời gian thực được phục vụ trên hạ tầng máy chủ DeepInfra $contextStr."
        }
    }

    private fun saveToLocalStorage(classified: DeepInfraClassifiedModels) {
        val prefs = getPreferences() ?: return
        try {
            val root = JSONObject()
            root.put("timestamp", classified.timestamp)

            fun serializeList(list: List<DeepInfraModelItem>): JSONArray {
                val array = JSONArray()
                for (item in list) {
                    val o = JSONObject()
                    o.put("id", item.id)
                    o.put("name", item.name)
                    o.put("provider", item.providerName)
                    o.put("description", item.description)
                    o.put("description_vi", item.descriptionVi)
                    o.put("context_length", item.contextLength)
                    o.put("max_tokens", item.maxTokens)
                    o.put("input_cost", item.inputCost)
                    o.put("output_cost", item.outputCost)
                    o.put("is_chat", item.isChat)
                    o.put("is_reasoning", item.isReasoning)
                    o.put("rank", item.rank)
                    o.put("rank_title_en", item.rankTitleEn)
                    o.put("rank_title_vi", item.rankTitleVi)
                    val tArray = JSONArray()
                    item.tags.forEach { tArray.put(it) }
                    o.put("tags", tArray)
                    array.put(o)
                }
                return array
            }

            root.put("recommended", serializeList(classified.recommended))
            root.put("chat", serializeList(classified.chatModels))
            root.put("reasoning", serializeList(classified.reasoningModels))
            root.put("all", serializeList(classified.allModels))

            prefs.edit().putString(storageKey, root.toString()).apply()
        } catch (e: Exception) {
            Timber.e(e, "Failed to cache DeepInfra models to local storage")
        }
    }

    private fun loadFromLocalStorage(): DeepInfraClassifiedModels? {
        val prefs = getPreferences() ?: return null
        val raw = prefs.getString(storageKey, null) ?: return null
        return try {
            val root = JSONObject(raw)

            fun deserializeList(key: String): List<DeepInfraModelItem> {
                val array = root.optJSONArray(key) ?: return emptyList()
                val list = mutableListOf<DeepInfraModelItem>()
                for (i in 0 until array.length()) {
                    val o = array.optJSONObject(i) ?: continue
                    val tArray = o.optJSONArray("tags")
                    val tags = mutableListOf<String>()
                    if (tArray != null) {
                        for (t in 0 until tArray.length()) {
                            tags.add(tArray.optString(t))
                        }
                    }
                    list.add(
                        DeepInfraModelItem(
                            id = o.optString("id"),
                            name = o.optString("name"),
                            providerName = o.optString("provider"),
                            description = o.optString("description"),
                            descriptionVi = o.optString("description_vi"),
                            contextLength = o.optLong("context_length"),
                            maxTokens = o.optLong("max_tokens"),
                            inputCost = o.optDouble("input_cost", 0.0),
                            outputCost = o.optDouble("output_cost", 0.0),
                            tags = tags,
                            isChat = o.optBoolean("is_chat", true),
                            isReasoning = o.optBoolean("is_reasoning", false),
                            rank = o.optInt("rank", 999),
                            rankTitleEn = o.optString("rank_title_en"),
                            rankTitleVi = o.optString("rank_title_vi"),
                        )
                    )
                }
                return list
            }

            val rec = deserializeList("recommended")
            val chat = deserializeList("chat")
            val reasoning = deserializeList("reasoning")
            val all = deserializeList("all")
            if (all.isEmpty()) null
            else DeepInfraClassifiedModels(
                recommended = rec,
                chatModels = chat,
                reasoningModels = reasoning,
                allModels = all,
                timestamp = root.optLong("timestamp", System.currentTimeMillis()),
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun getPreferences(): SharedPreferences? {
        return context?.getSharedPreferences("listrovia_deepinfra_models", Context.MODE_PRIVATE)
    }

    fun getStaticFallback(): DeepInfraClassifiedModels {
        val fallbackList = listOf(
            DeepInfraModelItem(
                id = DeepInfraDefaultModel,
                name = "DeepSeek-V3",
                providerName = "deepseek-ai",
                description = "State-of-the-art 671B Mixtral-of-Experts language model, excellent for lyrics translation.",
                descriptionVi = "Mô hình ngôn ngữ MoE 671 tỷ tham số siêu việt, dịch thuật lời bài hát cực kỳ trôi chảy và mượt mà.",
                contextLength = 131072L,
                tags = listOf("chat", "text-generation"),
                inputCost = 0.14,
                outputCost = 0.28,
                isChat = true,
                isReasoning = false,
                rank = 1,
                rankTitleEn = "#1 Flagship Chat: DeepSeek-V3",
                rankTitleVi = "#1 Trò chuyện hàng đầu: DeepSeek-V3",
            ),
            DeepInfraModelItem(
                id = "deepseek-ai/DeepSeek-R1",
                name = "DeepSeek-R1",
                providerName = "deepseek-ai",
                description = "Flagship reasoning model with step-by-step thinking for complex problems.",
                descriptionVi = "Mô hình suy luận hàng đầu thế giới với chuỗi suy nghĩ từng bước chuyên sâu.",
                contextLength = 163840L,
                tags = listOf("chat", "reasoning"),
                inputCost = 0.55,
                outputCost = 2.19,
                isChat = true,
                isReasoning = true,
                rank = 2,
                rankTitleEn = "#2 Flagship Reasoning: DeepSeek-R1",
                rankTitleVi = "#2 Suy luận hàng đầu: DeepSeek-R1",
            ),
            DeepInfraModelItem(
                id = "meta-llama/Llama-3.3-70B-Instruct",
                name = "Llama-3.3-70B-Instruct",
                providerName = "meta-llama",
                description = "State-of-the-art 70B foundation model with exceptional multilingual quality.",
                descriptionVi = "Mô hình 70 tỷ tham số xuất sắc từ Meta AI, thấu hiểu ngữ cảnh và cấu trúc câu từ tự nhiên.",
                contextLength = 131072L,
                tags = listOf("chat"),
                inputCost = 0.23,
                outputCost = 0.40,
                isChat = true,
                isReasoning = false,
                rank = 3,
                rankTitleEn = "#3 Meta Flagship: Llama-3.3-70B",
                rankTitleVi = "#3 Meta hàng đầu: Llama-3.3-70B",
            ),
            DeepInfraModelItem(
                id = "Qwen/Qwen2.5-72B-Instruct",
                name = "Qwen2.5-72B-Instruct",
                providerName = "Qwen",
                description = "Alibaba flagship model, extremely strong in Vietnamese and Asian languages.",
                descriptionVi = "Bậc thầy ngôn ngữ châu Á và tiếng Việt từ Alibaba, nắm bắt sắc sảo mọi thành ngữ.",
                contextLength = 131072L,
                tags = listOf("chat"),
                inputCost = 0.23,
                outputCost = 0.40,
                isChat = true,
                isReasoning = false,
                rank = 5,
                rankTitleEn = "#5 Asian Languages: Qwen2.5-72B",
                rankTitleVi = "#5 Ngôn ngữ châu Á: Qwen2.5-72B",
            ),
            DeepInfraModelItem(
                id = "meta-llama/Meta-Llama-3.1-8B-Instruct",
                name = "Meta-Llama-3.1-8B-Instruct",
                providerName = "meta-llama",
                description = "Lightweight Meta model, great for high speed and low latency.",
                descriptionVi = "Mô hình 8B gọn nhẹ từ Meta AI, lý tưởng cho tốc độ phản hồi nhanh và độ trễ thấp.",
                contextLength = 131072L,
                tags = listOf("chat"),
                inputCost = 0.05,
                outputCost = 0.08,
                isChat = true,
                isReasoning = false,
                rank = 6,
                rankTitleEn = "#6 Meta Lightweight: Llama-3.1-8B",
                rankTitleVi = "#6 Meta gọn nhẹ: Llama-3.1-8B",
            ),
            DeepInfraModelItem(
                id = "mistralai/Mistral-Nemo-Instruct-2407",
                name = "Mistral-Nemo-Instruct-2407",
                providerName = "mistralai",
                description = "12B model built with NVIDIA, sharp and cost-effective.",
                descriptionVi = "Mô hình 12B hợp tác bởi Mistral AI và NVIDIA, dịch thuật sắc bén tinh tế.",
                contextLength = 128000L,
                tags = listOf("chat"),
                inputCost = 0.04,
                outputCost = 0.08,
                isChat = true,
                isReasoning = false,
                rank = 7,
                rankTitleEn = "#7 European Flagship: Mistral Nemo 12B",
                rankTitleVi = "#7 Pháp hàng đầu: Mistral Nemo 12B",
            ),
        )

        return DeepInfraClassifiedModels(
            recommended = fallbackList,
            chatModels = fallbackList,
            reasoningModels = fallbackList.filter { it.isReasoning },
            allModels = fallbackList,
            timestamp = System.currentTimeMillis(),
        )
    }

    companion object {
        @Volatile
        private var defaultManager: DeepInfraModelManager? = null

        fun getInstance(context: Context? = null): DeepInfraModelManager {
            return defaultManager ?: synchronized(this) {
                defaultManager ?: DeepInfraModelManager(15L, context?.applicationContext).also {
                    defaultManager = it
                }
            }
        }
    }
}

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
