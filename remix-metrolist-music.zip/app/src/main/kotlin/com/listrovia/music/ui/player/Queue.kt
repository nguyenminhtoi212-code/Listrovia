/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.player

import android.annotation.SuppressLint
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.add
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Surface
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberSwipeToDismissBoxState
import com.listrovia.music.ui.component.PlayingIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalClipboard
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.edit
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.exoplayer.source.ShuffleOrder.DefaultShuffleOrder
import com.listrovia.music.LocalNavController
import com.listrovia.music.LocalListenTogetherManager
import com.listrovia.music.LocalPlayerConnection
import com.listrovia.music.R
import com.listrovia.music.constants.ListItemHeight
import com.listrovia.music.constants.PlayerBackgroundStyle
import com.listrovia.music.constants.QueueEditLockKey
import com.listrovia.music.constants.EnableLyricsQueueTabKey
import com.listrovia.music.constants.UseNewPlayerDesignKey
import com.listrovia.music.constants.ShowCommentButtonKey
import com.listrovia.music.constants.BlockedArtistsKey
import com.listrovia.music.constants.DislikedSongsKey
import com.listrovia.music.extensions.metadata
import com.listrovia.music.extensions.move
import com.listrovia.music.extensions.toggleRepeatMode
import com.listrovia.music.listentogether.RoomRole
import com.listrovia.music.models.MediaMetadata
import com.listrovia.music.constants.EnableLiquidGlassKey
import com.listrovia.music.constants.GlassSaturationKey
import com.listrovia.music.constants.GlassBlurRadiusKey
import com.listrovia.music.constants.LensRefractionHeightKey
import com.listrovia.music.constants.LensRefractionAmountKey
import com.listrovia.music.constants.ChromaticAberrationKey
import com.listrovia.music.constants.DepthEffectKey
import com.listrovia.music.constants.SurfaceOpacityKey
import com.listrovia.music.constants.PureBlackKey
import com.listrovia.music.ui.components.liquidGlass
import com.listrovia.music.ui.component.ActionPromptDialog
import com.listrovia.music.ui.component.PlayerSleepTimerDialog
import com.listrovia.music.ui.component.BottomSheet
import com.listrovia.music.ui.component.BottomSheetState
import com.listrovia.music.ui.component.LocalBottomSheetPageState
import com.listrovia.music.ui.component.LocalMenuState
import com.listrovia.music.ui.component.MediaMetadataListItem
import com.listrovia.music.ui.menu.PlayerMenu
import com.listrovia.music.ui.menu.QueueMenu
import com.listrovia.music.ui.menu.SelectionMediaMetadataMenu
import com.listrovia.music.ui.utils.ShowMediaInfo
import com.listrovia.music.utils.dataStore
import com.listrovia.music.utils.makeTimeString
import com.listrovia.music.utils.rememberPreference
import com.listrovia.music.utils.safeDataStoreEdit
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import sh.calvin.reorderable.ReorderableItem
import sh.calvin.reorderable.rememberReorderableLazyColumnState
import kotlin.math.roundToInt
import com.listrovia.music.constants.SleepTimerDefaultKey
import android.widget.Toast
import androidx.compose.runtime.derivedStateOf
import com.listrovia.music.constants.SleepTimerFadeOutKey
import com.listrovia.music.constants.SleepTimerStopAfterCurrentSongKey
import androidx.compose.runtime.derivedStateOf
import androidx.compose.material3.Button


@SuppressLint("UnrememberedMutableState")
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Queue(
    state: BottomSheetState,
    playerBottomSheetState: BottomSheetState,
    modifier: Modifier = Modifier,
    background: Color,
    onBackgroundColor: Color,
    TextBackgroundColor: Color,
    textButtonColor: Color,
    iconButtonColor: Color,
    pureBlack: Boolean,
    showInlineLyrics: Boolean,
    playerBackground: PlayerBackgroundStyle = PlayerBackgroundStyle.DEFAULT,
    onToggleLyrics: () -> Unit = {},
) {
    val navController = LocalNavController.current
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val clipboardManager = LocalClipboard.current
    val menuState = LocalMenuState.current
    val sleepTimerDefaultSetTemplate = stringResource(R.string.sleep_timer_default_set)
    val bottomSheetPageState = LocalBottomSheetPageState.current

    // Listen Together state (reactive)
    val listenTogetherManager = LocalListenTogetherManager.current
    val listenTogetherRoleState = listenTogetherManager?.role?.collectAsStateWithLifecycle(initialValue = com.listrovia.music.listentogether.RoomRole.NONE)
    val isListenTogetherGuest = listenTogetherRoleState?.value == RoomRole.GUEST

    val playerConnection = LocalPlayerConnection.current ?: return
    val isPlaying by playerConnection.isEffectivelyPlaying.collectAsStateWithLifecycle()
    val repeatMode by playerConnection.repeatMode.collectAsStateWithLifecycle()

    val currentWindowIndex by playerConnection.currentWindowIndex.collectAsStateWithLifecycle()
    val mediaMetadata by playerConnection.mediaMetadata.collectAsStateWithLifecycle()

    val currentFormat by playerConnection.currentFormat.collectAsStateWithLifecycle(initialValue = null)

    val selectedSongs = remember { mutableStateListOf<MediaMetadata>() }
    val selectedItems = remember { mutableStateListOf<Timeline.Window>() }

    // Cast state - safely access castConnectionHandler to prevent crashes during service lifecycle changes
    val castHandler =
        remember(playerConnection) {
            try {
                playerConnection.service.castConnectionHandler
            } catch (e: Exception) {
                null
            }
        }
    val isCasting by castHandler?.isCasting?.collectAsStateWithLifecycle() ?: remember { mutableStateOf(false) }
    val castIsPlaying by castHandler?.castIsPlaying?.collectAsStateWithLifecycle() ?: remember { mutableStateOf(false) }

    var inSelectMode by rememberSaveable { mutableStateOf(false) }
    val selection =
        rememberSaveable(
            saver =
                listSaver<MutableList<String>, String>(
                    save = { it.toList() },
                    restore = { it.toMutableStateList() },
                ),
        ) { mutableStateListOf() }
    val onExitSelectionMode = {
        inSelectMode = false
        selection.clear()
    }
    if (inSelectMode) {
        BackHandler(onBack = onExitSelectionMode)
    }

    var locked by rememberPreference(QueueEditLockKey, defaultValue = true)
    var selectedTab by rememberSaveable { androidx.compose.runtime.mutableIntStateOf(0) }
    val (enableLyricsQueueTab, _) = rememberPreference(
        EnableLyricsQueueTabKey,
        defaultValue = false,
    )
    val effectiveSelectedTab = if (enableLyricsQueueTab) selectedTab else 0

    val blockedArtists by rememberPreference(BlockedArtistsKey, emptySet())
    val dislikedSongs by rememberPreference(DislikedSongsKey, emptySet())

    val (useNewPlayerDesign, onUseNewPlayerDesignChange) =
        rememberPreference(
            UseNewPlayerDesignKey,
            defaultValue = true,
        )

    val snackbarHostState = remember { SnackbarHostState() }
    var dismissJob: Job? by remember { mutableStateOf(null) }
    val showCommentButton by rememberPreference(ShowCommentButtonKey, false)

    val coroutineScope = rememberCoroutineScope()
    var showSleepTimerDialog by remember { mutableStateOf(false) }
    val sleepTimerDefault by rememberPreference(SleepTimerDefaultKey, 30f)
    var sleepTimerValue by remember { mutableFloatStateOf(sleepTimerDefault) }
    val isAtDefault by remember {
        derivedStateOf { sleepTimerValue.roundToInt() == sleepTimerDefault.roundToInt() }
    }
    val sleepTimerStopAfterCurrentSong by rememberPreference(SleepTimerStopAfterCurrentSongKey, false)
    val sleepTimerFadeOut by rememberPreference(SleepTimerFadeOutKey, false)
    val sleepTimerEnabled = remember(
        playerConnection.service.sleepTimer?.triggerTime,
        playerConnection.service.sleepTimer?.pauseWhenSongEnd
    ) {
        playerConnection.service.sleepTimer?.isActive ?: false
    }
    var sleepTimerTimeLeft by remember { mutableLongStateOf(0L) }

    LaunchedEffect(sleepTimerEnabled) {
        if (sleepTimerEnabled) {
            while (isActive) {
                sleepTimerTimeLeft =
                    if (playerConnection.service.sleepTimer?.pauseWhenSongEnd == true) {
                        playerConnection.player.duration - playerConnection.player.currentPosition
                    } else {
                        (playerConnection.service.sleepTimer?.triggerTime ?: 0L) - System.currentTimeMillis()
                    }
                delay(1000L)
            }
        }
    }

    BottomSheet(
        state = state,
        modifier = modifier,
        background = {
            val enableLiquidGlass by rememberPreference(EnableLiquidGlassKey, defaultValue = true)
            val glassSaturation by rememberPreference(GlassSaturationKey, defaultValue = 1.3f)
            val glassBlurRadius by rememberPreference(GlassBlurRadiusKey, defaultValue = 24f)
            val lensRefractionHeight by rememberPreference(LensRefractionHeightKey, defaultValue = 14f)
            val lensRefractionAmount by rememberPreference(LensRefractionAmountKey, defaultValue = 0.85f)
            val chromaticAberration by rememberPreference(ChromaticAberrationKey, defaultValue = 0.45f)
            val depthEffect by rememberPreference(DepthEffectKey, defaultValue = 0.75f)
            val surfaceOpacity by rememberPreference(SurfaceOpacityKey, defaultValue = 1.0f)
            val pureBlack by rememberPreference(PureBlackKey, defaultValue = false)

            val bgColor = if (pureBlack) Color.Black else MaterialTheme.colorScheme.surfaceContainerHigh

            Box(
                Modifier
                    .fillMaxSize()
                    .then(
                        if (state.isExpanded && enableLiquidGlass) {
                            Modifier.liquidGlass(
                                enabled = true,
                                blurRadiusDp = glassBlurRadius,
                                saturation = glassSaturation,
                                refractionHeight = lensRefractionHeight,
                                refractionAmount = lensRefractionAmount,
                                chromaticAberration = chromaticAberration,
                                depthEffect = depthEffect,
                                surfaceOpacity = surfaceOpacity,
                                surfaceTintColor = bgColor,
                                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
                            )
                        } else if (state.isExpanded) {
                            Modifier.background(bgColor, shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                        } else {
                            Modifier.background(Color.Unspecified)
                        }
                    )
            )
        },
        collapsedContent = {
            if (useNewPlayerDesign) {
                // New design
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 30.dp, vertical = 12.dp)
                            .windowInsetsPadding(
                                WindowInsets.systemBars.only(
                                    WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal,
                                ),
                            ),
                ) {
                    val buttonShape = RoundedCornerShape(16.dp)
                    val buttonBorder = androidx.compose.foundation.BorderStroke(1.dp, TextBackgroundColor.copy(alpha = 0.15f))
                    val buttonColors = androidx.compose.material3.IconButtonDefaults.outlinedIconButtonColors(
                        containerColor = TextBackgroundColor.copy(alpha = 0.06f),
                        contentColor = TextBackgroundColor
                    )

                    // 1. Queue Button
                    androidx.compose.material3.OutlinedIconButton(
                        onClick = {
                            selectedTab = 0
                            state.expandSoft()
                        },
                        shape = buttonShape,
                        border = buttonBorder,
                        colors = androidx.compose.material3.IconButtonDefaults.outlinedIconButtonColors(
                            containerColor = if (state.isExpanded && selectedTab == 0) TextBackgroundColor.copy(alpha = 0.22f) else TextBackgroundColor.copy(alpha = 0.06f),
                            contentColor = TextBackgroundColor
                        ),
                        modifier = Modifier.size(44.dp),
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.queue_music),
                            contentDescription = "Danh sách phát",
                            modifier = Modifier.size(24.dp),
                            tint = TextBackgroundColor,
                        )
                    }

                    // 2. Bedtime/Sleep Timer Button
                    androidx.compose.material3.OutlinedIconButton(
                        onClick = {
                            if (sleepTimerEnabled) {
                                playerConnection.service.sleepTimer?.clear()
                            } else {
                                showSleepTimerDialog = true
                            }
                        },
                        shape = buttonShape,
                        border = buttonBorder,
                        colors = androidx.compose.material3.IconButtonDefaults.outlinedIconButtonColors(
                            containerColor = if (sleepTimerEnabled) TextBackgroundColor.copy(alpha = 0.22f) else TextBackgroundColor.copy(alpha = 0.06f),
                            contentColor = TextBackgroundColor
                        ),
                        modifier = Modifier.size(44.dp),
                    ) {
                        if (sleepTimerEnabled) {
                            Text(
                                text = makeTimeString(sleepTimerTimeLeft),
                                color = TextBackgroundColor,
                                fontSize = 10.sp,
                                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                                maxLines = 1,
                            )
                        } else {
                            Icon(
                                painter = painterResource(R.drawable.bedtime),
                                contentDescription = "Hẹn giờ ngủ",
                                modifier = Modifier.size(24.dp),
                                tint = TextBackgroundColor,
                            )
                        }
                    }

                    // 3. Lyrics Button
                    androidx.compose.material3.OutlinedIconButton(
                        onClick = {
                            if (enableLyricsQueueTab) {
                                selectedTab = 1
                                state.expandSoft()
                            }
                            onToggleLyrics()
                        },
                        shape = buttonShape,
                        border = buttonBorder,
                        colors = androidx.compose.material3.IconButtonDefaults.outlinedIconButtonColors(
                            containerColor = if (showInlineLyrics || (state.isExpanded && effectiveSelectedTab == 1)) TextBackgroundColor.copy(alpha = 0.22f) else TextBackgroundColor.copy(alpha = 0.06f),
                            contentColor = TextBackgroundColor
                        ),
                        modifier = Modifier.size(44.dp),
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.lyrics),
                            contentDescription = "Lời bài hát",
                            modifier = Modifier.size(24.dp),
                            tint = TextBackgroundColor,
                        )
                    }

                    // 4. Equalizer Button
                    androidx.compose.material3.OutlinedIconButton(
                        onClick = {
                            navController.navigate("equalizer")
                        },
                        shape = buttonShape,
                        border = buttonBorder,
                        colors = buttonColors,
                        modifier = Modifier.size(44.dp),
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.equalizer),
                            contentDescription = "Bộ chỉnh âm",
                            modifier = Modifier.size(24.dp),
                            tint = TextBackgroundColor,
                        )
                    }

                    // 5. Comment Button (when enabled)
                    if (showCommentButton) {
                        androidx.compose.material3.OutlinedIconButton(
                            onClick = {
                                try {
                                    navController.navigate("comments")
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            },
                            shape = buttonShape,
                            border = buttonBorder,
                            colors = buttonColors,
                            modifier = Modifier.size(44.dp),
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.chat_bubble),
                                contentDescription = "Bình luận",
                                modifier = Modifier.size(22.dp),
                                tint = Color.White,
                            )
                        }
                    }

                }
            } else {
                // Old design
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 30.dp, vertical = 12.dp)
                            .windowInsetsPadding(
                                WindowInsets.systemBars
                                    .only(WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal),
                            ),
                ) {
                    TextButton(
                        onClick = { state.expandSoft() },
                        modifier = Modifier.weight(1f),
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Icon(
                                painter = painterResource(id = R.drawable.queue_music),
                                contentDescription = null,
                                modifier = Modifier.size(20.dp),
                                tint = TextBackgroundColor,
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(id = R.string.queue),
                                color = TextBackgroundColor,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.basicMarquee(),
                            )
                        }
                    }

                    TextButton(
                        enabled = !isListenTogetherGuest,
                        onClick = {
                            if (!isListenTogetherGuest) {
                                if (sleepTimerEnabled) {
                                    playerConnection.service.sleepTimer?.clear()
                                } else {
                                    showSleepTimerDialog = true
                                }
                            }
                        },
                        modifier = Modifier.weight(1.2f),
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Icon(
                                painter = painterResource(id = R.drawable.bedtime),
                                contentDescription = null,
                                modifier = Modifier.size(20.dp),
                                tint = TextBackgroundColor,
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            AnimatedContent(
                                label = "sleepTimer",
                                targetState = sleepTimerEnabled,
                            ) { enabled ->
                                if (enabled) {
                                    Text(
                                        text = makeTimeString(sleepTimerTimeLeft),
                                        color = TextBackgroundColor,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.basicMarquee(),
                                    )
                                } else {
                                    Text(
                                        text = stringResource(id = R.string.sleep_timer),
                                        color = TextBackgroundColor,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.basicMarquee(),
                                    )
                                }
                            }
                        }
                    }

                    TextButton(
                        onClick = {
                            onToggleLyrics()
                        },
                        modifier = Modifier.weight(1f),
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Icon(
                                painter = painterResource(id = R.drawable.lyrics),
                                contentDescription = null,
                                modifier = Modifier.size(20.dp),
                                tint = TextBackgroundColor,
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(R.string.lyrics),
                                color = TextBackgroundColor,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.basicMarquee(),
                            )
                        }
                    }
                }
            }

            PlayerSleepTimerDialog(
                isVisible = showSleepTimerDialog,
                onDismiss = { showSleepTimerDialog = false },
                playerConnection = playerConnection,
            )
        },
    ) {
        val queueTitle by playerConnection.queueTitle.collectAsStateWithLifecycle()
        val queueWindows by playerConnection.queueWindows.collectAsStateWithLifecycle()
        val automix by playerConnection.service.automixItems.collectAsStateWithLifecycle()
        val mutableQueueWindows = remember { mutableStateListOf<Timeline.Window>() }
        val queueLength =
            remember(queueWindows) {
                queueWindows.sumOf { it.mediaItem.metadata!!.duration }
            }

        val coroutineScope = rememberCoroutineScope()

        val headerItems = 1
        val lazyListState = rememberLazyListState()
        var dragInfo by remember { mutableStateOf<Pair<Int, Int>?>(null) }

        val currentPlayingUid =
            remember(currentWindowIndex, queueWindows) {
                if (currentWindowIndex in queueWindows.indices) {
                    queueWindows[currentWindowIndex].uid
                } else {
                    null
                }
            }

        val reorderableState =
            rememberReorderableLazyColumnState(
                lazyListState = lazyListState,
                onMove = { from, to ->
                    val safeFrom = (from.index - headerItems).coerceIn(0, mutableQueueWindows.lastIndex)
                    val safeTo = (to.index - headerItems).coerceIn(0, mutableQueueWindows.lastIndex)

                    if (safeFrom != safeTo) {
                        mutableQueueWindows.move(safeFrom, safeTo)
                        if (!playerConnection.player.shuffleModeEnabled) {
                            playerConnection.player.moveMediaItem(safeFrom, safeTo)
                        } else {
                            playerConnection.player.setShuffleOrder(
                                DefaultShuffleOrder(
                                    queueWindows
                                        .map { it.firstPeriodIndex }
                                        .toMutableList()
                                        .move(safeFrom, safeTo)
                                        .toIntArray(),
                                    System.currentTimeMillis(),
                                ),
                            )
                        }
                    }
                }
            )

        LaunchedEffect(queueWindows, blockedArtists, dislikedSongs) {
            mutableQueueWindows.apply {
                clear()
                addAll(queueWindows.filter { window ->
                    val metadata = window.mediaItem.metadata
                    if (metadata != null) {
                        val isBlocked = metadata.artists.any { artist ->
                            blockedArtists.any { blocked -> blocked.equals(artist.name, ignoreCase = true) || blocked == artist.id }
                        }
                        val isDisliked = dislikedSongs.contains(metadata.id) || dislikedSongs.any { disliked -> disliked.equals(metadata.title, ignoreCase = true) }
                        !isBlocked && !isDisliked
                    } else {
                        true
                    }
                })
            }
        }

        LaunchedEffect(mutableQueueWindows, currentWindowIndex) {
            if (currentWindowIndex != -1) {
                lazyListState.scrollToItem(currentWindowIndex)
            }
        }

        Box(
            modifier =
                Modifier
                    .fillMaxSize()
                    .background(background),
        ) {
            if (effectiveSelectedTab == 0) {
                LazyColumn(
                state = lazyListState,
                contentPadding =
                    WindowInsets.systemBars
                        .add(
                            WindowInsets(
                                top = ListItemHeight + 8.dp,
                                bottom = ListItemHeight + 8.dp,
                            ),
                        ).asPaddingValues(),
                modifier = Modifier.nestedScroll(state.preUpPostDownNestedScrollConnection),
            ) {
                item(key = "queue_top_spacer") {
                    Spacer(
                        modifier =
                            Modifier
                                .animateContentSize()
                                .height(if (inSelectMode) 48.dp else 0.dp),
                    )
                }

                item(key = "queue_header") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.queue),
                            style = MaterialTheme.typography.titleLarge,
                            color = TextBackgroundColor
                        )
                        IconButton(onClick = { locked = !locked }) {
                            Icon(
                                painter = painterResource(if (locked) R.drawable.lock else R.drawable.edit),
                                contentDescription = if (locked) "Unlock to reorder" else "Lock to prevent reordering",
                                tint = TextBackgroundColor
                            )
                        }
                    }
                }

                if (mutableQueueWindows.isEmpty()) {
                    item(key = "empty_queue_state") {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 48.dp, horizontal = 24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                                modifier = Modifier.size(64.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        painter = painterResource(R.drawable.queue_music),
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            }
                            Text(
                                text = stringResource(R.string.recs_no_items_selected),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                itemsIndexed(
                    items = mutableQueueWindows,
                    key = { _, item -> item.uid.hashCode() },
                ) { index, window ->
                    ReorderableItem(
                        reorderableState,
                        key = window.uid.hashCode(),
                    ) {
                        val currentItem by rememberUpdatedState(window)
                        val isActive = window.uid == currentPlayingUid
                        val dismissBoxState =
                            rememberSwipeToDismissBoxState(
                                positionalThreshold = { totalDistance -> totalDistance },
                            )

                        var processedDismiss by remember { mutableStateOf(false) }
                        val removedSongMsg =
                            stringResource(R.string.removed_song_from_playlist, currentItem.mediaItem.metadata?.title ?: "")
                        val undoStr = stringResource(R.string.undo)
                        LaunchedEffect(dismissBoxState.currentValue) {
                            val dv = dismissBoxState.currentValue
                            if (!processedDismiss && !isListenTogetherGuest && (
                                    dv == SwipeToDismissBoxValue.StartToEnd ||
                                        dv == SwipeToDismissBoxValue.EndToStart
                                )
                            ) {
                                processedDismiss = true
                                playerConnection.player.removeMediaItem(currentItem.firstPeriodIndex)
                                dismissJob?.cancel()
                                dismissJob =
                                    coroutineScope.launch {
                                        val snackbarResult =
                                            snackbarHostState.showSnackbar(
                                                message = removedSongMsg,
                                                actionLabel = undoStr,
                                                duration = SnackbarDuration.Short,
                                            )
                                        if (snackbarResult == SnackbarResult.ActionPerformed) {
                                            playerConnection.player.addMediaItem(currentItem.mediaItem)
                                            playerConnection.player.moveMediaItem(
                                                mutableQueueWindows.size,
                                                currentItem.firstPeriodIndex,
                                            )
                                        }
                                    }
                            }
                            if (dv == SwipeToDismissBoxValue.Settled) {
                                processedDismiss = false
                            }
                        }

                        val onCheckedChange: (Boolean) -> Unit = {
                            if (it) {
                                selection.add(window.mediaItem.mediaId)
                            } else {
                                selection.remove(window.mediaItem.mediaId)
                            }
                        }

                        val content: @Composable () -> Unit = {
                            Row(
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier
                                    .animateItem()
                                    .fillMaxWidth()
                                    .padding(horizontal = if (isActive) 8.dp else 0.dp, vertical = if (isActive) 4.dp else 0.dp)
                                    .then(
                                        if (isActive) {
                                            Modifier
                                                .clip(RoundedCornerShape(16.dp))
                                                .background(
                                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                                                )
                                                .border(
                                                    width = 1.dp,
                                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.45f),
                                                    shape = RoundedCornerShape(16.dp)
                                                )
                                        } else {
                                            Modifier
                                        }
                                    ),
                            ) {
                                MediaMetadataListItem(
                                    mediaMetadata = window.mediaItem.metadata!!,
                                    isSelected = false,
                                    isActive = isActive,
                                    isPlaying = isPlaying && isActive,
                                    trailingContent = {
                                        if (isActive && isPlaying) {
                                            PlayingIndicator(
                                                color = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier
                                                    .height(18.dp)
                                                    .padding(end = 6.dp),
                                            )
                                        }
                                        if (inSelectMode) {
                                            Checkbox(
                                                checked = window.mediaItem.mediaId in selection,
                                                onCheckedChange = onCheckedChange,
                                            )
                                        } else {
                                            if (!isListenTogetherGuest) {
                                                IconButton(
                                                    onClick = {
                                                        menuState.show {
                                                            QueueMenu(
                                                                mediaMetadata = window.mediaItem.metadata!!,
                                                                playerBottomSheetState = playerBottomSheetState,
                                                                onShowDetailsDialog = {
                                                                    window.mediaItem.mediaId.let {
                                                                        bottomSheetPageState.show {
                                                                            ShowMediaInfo(it)
                                                                        }
                                                                    }
                                                                },
                                                                onDismiss = menuState::dismiss,
                                                            )
                                                        }
                                                    },
                                                ) {
                                                    Icon(
                                                        painter = painterResource(R.drawable.more_vert),
                                                        contentDescription = null,
                                                    )
                                                }
                                            }
                                            if (!locked && !isListenTogetherGuest) {
                                                IconButton(
                                                    onClick = { },
                                                    modifier = Modifier.draggableHandle(),
                                                ) {
                                                    Icon(
                                                        painter = painterResource(R.drawable.drag_handle),
                                                        contentDescription = null,
                                                    )
                                                }
                                            }
                                        }
                                    },
                                    modifier =
                                        Modifier
                                            .fillMaxWidth()
                                            .background(if (isActive) Color.Transparent else background)
                                            .combinedClickable(
                                                onClick = {
                                                    if (inSelectMode) {
                                                        onCheckedChange(window.mediaItem.mediaId !in selection)
                                                    } else if (!isListenTogetherGuest) {
                                                        if (index == currentWindowIndex) {
                                                            if (isCasting) {
                                                                if (castIsPlaying) {
                                                                    castHandler?.pause()
                                                                } else {
                                                                    castHandler?.play()
                                                                }
                                                            } else {
                                                                playerConnection.togglePlayPause()
                                                            }
                                                        } else {
                                                            if (isCasting) {
                                                                val mediaId = window.mediaItem.mediaId
                                                                val navigated = castHandler?.navigateToMediaIfInQueue(mediaId) ?: false
                                                                if (!navigated) {
                                                                    playerConnection.player.seekToDefaultPosition(window.firstPeriodIndex)
                                                                }
                                                            } else {
                                                                playerConnection.player.seekToDefaultPosition(
                                                                    window.firstPeriodIndex,
                                                                )
                                                                playerConnection.player.playWhenReady = true
                                                            }
                                                        }
                                                    }
                                                },
                                                onLongClick = {
                                                    if (!inSelectMode) {
                                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                        inSelectMode = true
                                                        onCheckedChange(true)
                                                    }
                                                },
                                            ),
                                )
                            }
                        }

                        if (locked) {
                            content()
                        } else {
                            SwipeToDismissBox(
                                state = dismissBoxState,
                                backgroundContent = {},
                            ) {
                                content()
                            }
                        }
                    }
                }

                if (automix.isNotEmpty()) {
                    item(key = "automix_divider") {
                        HorizontalDivider(
                            modifier =
                                Modifier
                                    .padding(vertical = 8.dp, horizontal = 4.dp)
                                    .animateItem(),
                        )

                        Text(
                            text = stringResource(R.string.similar_content),
                            modifier = Modifier.padding(start = 16.dp),
                        )
                    }

                    itemsIndexed(
                        items = automix,
                        key = { _, it -> it.mediaId },
                    ) { index, item ->
                        Row(
                            horizontalArrangement = Arrangement.Center,
                        ) {
                            MediaMetadataListItem(
                                mediaMetadata = item.metadata!!,
                                trailingContent = {
                                    if (!isListenTogetherGuest) {
                                        IconButton(
                                            onClick = {
                                                playerConnection.service.playNextAutomix(
                                                    item,
                                                    index,
                                                )
                                            },
                                        ) {
                                            Icon(
                                                painter = painterResource(R.drawable.playlist_play),
                                                contentDescription = null,
                                            )
                                        }
                                        IconButton(
                                            onClick = {
                                                playerConnection.service.addToQueueAutomix(
                                                    item,
                                                    index,
                                                )
                                            },
                                        ) {
                                            Icon(
                                                painter = painterResource(R.drawable.queue_music),
                                                contentDescription = null,
                                            )
                                        }
                                    }
                                },
                                modifier =
                                    Modifier
                                        .fillMaxWidth()
                                        .combinedClickable(
                                            onClick = {},
                                            onLongClick = {
                                                menuState.show {
                                                    QueueMenu(
                                                        mediaMetadata = item.metadata!!,
                                                        playerBottomSheetState = playerBottomSheetState,
                                                        onShowDetailsDialog = {
                                                            item.mediaId.let {
                                                                bottomSheetPageState.show {
                                                                    ShowMediaInfo(it)
                                                                }
                                                            }
                                                        },
                                                        onDismiss = menuState::dismiss,
                                                    )
                                                }
                                            },
                                        ).animateItem(),
                            )
                        }
                    }
                }
            }
        } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = ListItemHeight + 8.dp, bottom = ListItemHeight)
                ) {
                    LyricsTabContent(
                        playerConnection = playerConnection,
                    )
                }
            }
        }

        Column(
            modifier =
                Modifier
                    .clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() },
                    ) { }
                    .background(
                        if (pureBlack) {
                            Color.Black
                        } else {
                            MaterialTheme.colorScheme
                                .secondaryContainer
                                .copy(alpha = 0.90f)
                        },
                    ).windowInsetsPadding(
                        WindowInsets.systemBars
                            .only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal),
                    ),
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier =
                    Modifier
                        .height(ListItemHeight)
                        .padding(horizontal = 12.dp),
            ) {
                if (enableLyricsQueueTab) {
                    androidx.compose.material3.FilterChip(
                        selected = effectiveSelectedTab == 0,
                        onClick = { selectedTab = 0 },
                        label = { Text(stringResource(R.string.queue), style = MaterialTheme.typography.labelMedium) },
                        leadingIcon = {
                            Icon(
                                painter = painterResource(R.drawable.queue_music),
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                            )
                        },
                        shape = RoundedCornerShape(20.dp),
                    )

                    androidx.compose.material3.FilterChip(
                        selected = effectiveSelectedTab == 1,
                        onClick = { selectedTab = 1 },
                        label = { Text(stringResource(R.string.lyrics), style = MaterialTheme.typography.labelMedium) },
                        leadingIcon = {
                            Icon(
                                painter = painterResource(R.drawable.lyrics),
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                            )
                        },
                        shape = RoundedCornerShape(20.dp),
                    )
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.queue_music),
                            contentDescription = null,
                            modifier = Modifier.size(20.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = stringResource(R.string.queue),
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

                if (effectiveSelectedTab == 0) {
                    AnimatedVisibility(
                        visible = !inSelectMode,
                        enter = fadeIn() + slideInVertically { it },
                        exit = fadeOut() + slideOutVertically { it },
                    ) {
                        val totalDurationMs = remember(mutableQueueWindows.toList()) {
                            mutableQueueWindows.sumOf { (it.mediaItem.metadata?.duration?.toLong() ?: 0L) * 1000L }
                        }
                        val durationFormatted = remember(totalDurationMs) {
                            if (totalDurationMs > 0L) makeTimeString(totalDurationMs) else null
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            IconButton(
                                onClick = { locked = !locked },
                                modifier = Modifier.size(36.dp),
                            ) {
                                Icon(
                                    painter = painterResource(if (locked) R.drawable.lock else R.drawable.lock_open),
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp),
                                    tint = if (!locked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                modifier = Modifier.padding(end = 4.dp)
                            ) {
                                Text(
                                    text = buildString {
                                        append(pluralStringResource(R.plurals.n_song, queueWindows.size, queueWindows.size))
                                        if (durationFormatted != null) {
                                            append(" • ")
                                            append(durationFormatted)
                                        }
                                    },
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            AnimatedVisibility(
                visible = inSelectMode,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically(),
            ) {
                val selectedSongs =
                    remember(selection.toList(), mutableQueueWindows) {
                        mutableQueueWindows
                            .filter { it.mediaItem.mediaId in selection }
                            .mapNotNull { it.mediaItem.metadata }
                    }
                val selectedItems =
                    remember(selection.toList(), mutableQueueWindows) {
                        mutableQueueWindows.filter { it.mediaItem.mediaId in selection }
                    }
                val count = selection.size
                Row(
                    modifier =
                        Modifier
                            .height(48.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(
                        onClick = onExitSelectionMode,
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.close),
                            contentDescription = null,
                        )
                    }
                    Text(
                        text = pluralStringResource(R.plurals.n_selected, count, count),
                        modifier = Modifier.weight(1f),
                    )
                    Checkbox(
                        checked = count == mutableQueueWindows.size && count > 0,
                        onCheckedChange = {
                            if (count == mutableQueueWindows.size) {
                                selection.clear()
                            } else {
                                selection.clear()
                                mutableQueueWindows.forEach {
                                    selection.add(it.mediaItem.mediaId)
                                }
                            }
                        },
                    )
                    IconButton(
                        enabled = count > 0,
                        onClick = {
                            menuState.show {
                                SelectionMediaMetadataMenu(
                                    songSelection = selectedSongs,
                                    onDismiss = menuState::dismiss,
                                    clearAction = onExitSelectionMode,
                                    currentItems = selectedItems,
                                )
                            }
                        },
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.more_vert),
                            contentDescription = null,
                            tint = LocalContentColor.current,
                        )
                    }
                }
            }
            if (pureBlack) {
                HorizontalDivider()
            }
        }

        val shuffleModeEnabled by playerConnection.shuffleModeEnabled.collectAsStateWithLifecycle()

        Box(
            modifier =
                Modifier
                    .background(
                        if (pureBlack) {
                            Color.Black
                        } else {
                            MaterialTheme.colorScheme
                                .secondaryContainer
                                .copy(alpha = 0.90f)
                        },
                    ).fillMaxWidth()
                    .height(
                        ListItemHeight +
                            WindowInsets.systemBars
                                .asPaddingValues()
                                .calculateBottomPadding(),
                    ).align(Alignment.BottomCenter)
                    .clickable {
                        state.collapseSoft()
                    }.windowInsetsPadding(
                        WindowInsets.systemBars
                            .only(WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal),
                    ).padding(12.dp),
        ) {
            IconButton(
                enabled = !isListenTogetherGuest,
                modifier = Modifier.align(Alignment.CenterStart),
                onClick = {
                    coroutineScope
                        .launch {
                            lazyListState.animateScrollToItem(
                                if (playerConnection.player.shuffleModeEnabled) playerConnection.player.currentMediaItemIndex else 0,
                            )
                        }.invokeOnCompletion {
                            playerConnection.player.shuffleModeEnabled =
                                !playerConnection.player.shuffleModeEnabled
                        }
                },
            ) {
                val baseAlpha = if (shuffleModeEnabled) 1f else 0.5f
                val finalAlpha = if (!isListenTogetherGuest) baseAlpha else 0.3f
                Icon(
                    painter = painterResource(R.drawable.shuffle),
                    contentDescription = null,
                    modifier = Modifier.alpha(finalAlpha),
                )
            }

            Icon(
                painter = painterResource(R.drawable.expand_more),
                contentDescription = null,
                modifier = Modifier.align(Alignment.Center),
            )

            IconButton(
                enabled = !isListenTogetherGuest,
                modifier = Modifier.align(Alignment.CenterEnd),
                onClick = playerConnection.player::toggleRepeatMode,
            ) {
                val baseAlpha = if (repeatMode == Player.REPEAT_MODE_OFF) 0.5f else 1f
                val finalAlpha = if (!isListenTogetherGuest) baseAlpha else 0.3f
                Icon(
                    painter =
                        painterResource(
                            when (repeatMode) {
                                Player.REPEAT_MODE_OFF, Player.REPEAT_MODE_ALL -> R.drawable.repeat
                                Player.REPEAT_MODE_ONE -> R.drawable.repeat_one
                                else -> throw IllegalStateException()
                            },
                        ),
                    contentDescription = null,
                    modifier = Modifier.alpha(finalAlpha),
                )
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier =
                Modifier
                    .padding(
                        bottom =
                            ListItemHeight +
                                WindowInsets.systemBars
                                    .asPaddingValues()
                                    .calculateBottomPadding(),
                    ).align(Alignment.BottomCenter),
        )
    }
}


