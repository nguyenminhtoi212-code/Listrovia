/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.listrovia.music.LocalPlayerAwareWindowInsets
import com.listrovia.music.R
import com.listrovia.music.constants.*
import com.listrovia.music.ui.component.IconButton
import com.listrovia.music.ui.component.Material3SettingsGroup
import com.listrovia.music.ui.component.Material3SettingsItem
import com.listrovia.music.ui.utils.backToMain
import com.listrovia.music.utils.rememberPreference
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AmbientSettings(
    navController: NavController
) {
    var musicArtSize by rememberPreference(AmbientMusicArtSizeKey, defaultValue = 85f)
    var showSongName by rememberPreference(AmbientShowSongNameKey, defaultValue = true)
    var showArtistName by rememberPreference(AmbientShowArtistNameKey, defaultValue = true)
    var showLyrics by rememberPreference(AmbientShowLyricsKey, defaultValue = true)

    var forceOpus by rememberPreference(ForceOpusAudioKey, defaultValue = false)
    var enableHttp3 by rememberPreference(EnableHttp3Key, defaultValue = false)

    var showArtSizeDialog by remember { mutableStateOf(false) }

    if (showArtSizeDialog) {
        AlertDialog(
            onDismissRequest = { showArtSizeDialog = false },
            title = { Text(stringResource(R.string.ambient_music_art_size)) },
            text = {
                Column {
                    Text(text = "${musicArtSize.roundToInt()}%", style = MaterialTheme.typography.bodyLarge)
                    Spacer(modifier = Modifier.height(8.dp))
                    Slider(
                        value = musicArtSize,
                        onValueChange = { musicArtSize = (it / 5).roundToInt() * 5f },
                        valueRange = 50f..100f,
                        steps = 10
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showArtSizeDialog = false }) {
                    Text(stringResource(android.R.string.ok))
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.ambient_mode_settings_title)) },
                navigationIcon = {
                    IconButton(
                        onClick = navController::navigateUp,
                        onLongClick = navController::backToMain
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.arrow_back),
                            contentDescription = null
                        )
                    }
                }
            )
        },
        contentWindowInsets = LocalPlayerAwareWindowInsets.current
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            Material3SettingsGroup(
                title = stringResource(R.string.ambient_display_options),
                items = listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.crop),
                        title = { Text(stringResource(R.string.ambient_music_art_size)) },
                        description = { Text("${musicArtSize.roundToInt()}%") },
                        onClick = { showArtSizeDialog = true }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.tune),
                        title = { Text(stringResource(R.string.ambient_show_song_name)) },
                        description = { Text(stringResource(R.string.ambient_show_song_name_desc)) },
                        trailingContent = {
                            Switch(
                                checked = showSongName,
                                onCheckedChange = { showSongName = it }
                            )
                        },
                        onClick = { showSongName = !showSongName }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.person),
                        title = { Text(stringResource(R.string.ambient_show_artist_name)) },
                        description = { Text(stringResource(R.string.ambient_show_artist_name_desc)) },
                        trailingContent = {
                            Switch(
                                checked = showArtistName,
                                onCheckedChange = { showArtistName = it }
                            )
                        },
                        onClick = { showArtistName = !showArtistName }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.lyrics),
                        title = { Text(stringResource(R.string.ambient_show_lyrics)) },
                        description = { Text(stringResource(R.string.ambient_show_lyrics_desc)) },
                        trailingContent = {
                            Switch(
                                checked = showLyrics,
                                onCheckedChange = { showLyrics = it }
                            )
                        },
                        onClick = { showLyrics = !showLyrics }
                    )
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            Material3SettingsGroup(
                title = stringResource(R.string.player_and_audio),
                items = listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.album),
                        title = { Text(stringResource(R.string.force_opus_audio)) },
                        description = { Text(stringResource(R.string.force_opus_audio_desc)) },
                        trailingContent = {
                            Switch(
                                checked = forceOpus,
                                onCheckedChange = { forceOpus = it }
                            )
                        },
                        onClick = { forceOpus = !forceOpus }
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.language),
                        title = { Text(stringResource(R.string.enable_http3)) },
                        description = { Text(stringResource(R.string.enable_http3_desc)) },
                        trailingContent = {
                            Switch(
                                checked = enableHttp3,
                                onCheckedChange = { enableHttp3 = it }
                            )
                        },
                        onClick = { enableHttp3 = !enableHttp3 }
                    )
                )
            )
        }
    }
}
