package com.listrovia.music.ui.theme

import android.graphics.Bitmap
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.LocalOverscrollConfiguration
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.saveable.Saver
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.palette.graphics.Palette
import com.materialkolor.PaletteStyle
import com.materialkolor.rememberDynamicColorScheme

val DefaultThemeColor = Color(0xFF6750A4)

val ColorSaver: Saver<Color, Int> = Saver(
    save = { it.toArgb() },
    restore = { Color(it) }
)

fun Bitmap.extractThemeColor(): Color {
    val palette = Palette.from(this)
        .maximumColorCount(16)
        .resizeBitmapArea(100 * 100)
        .generate()
    return PlayerColorExtractor.extractPrimarySeedColor(palette, DefaultThemeColor)
}

fun Bitmap.extractPaletteColors(isDarkTheme: Boolean = true): PlayerPaletteColors {
    val palette = Palette.from(this)
        .maximumColorCount(16)
        .resizeBitmapArea(100 * 100)
        .generate()
    return PlayerColorExtractor.extractPaletteColors(palette, DefaultThemeColor, isDarkTheme)
}

@Composable
fun ListroviaTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    pureBlack: Boolean = false,
    themeColor: Color = DefaultThemeColor,
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = rememberDynamicColorScheme(
        seedColor = themeColor,
        isDark = darkTheme,
        style = PaletteStyle.TonalSpot
    )

    val finalScheme = if (darkTheme && pureBlack) {
        colorScheme.copy(
            background = Color.Black,
            surface = Color.Black,
            surfaceContainerLowest = Color.Black,
            surfaceContainerLow = Color(0xFF0E0E0E),
            surfaceContainer = Color(0xFF161616),
            surfaceContainerHigh = Color(0xFF202020),
            surfaceContainerHighest = Color(0xFF2B2B2B),
        )
    } else colorScheme

    MaterialTheme(
        colorScheme = finalScheme,
        content = {
            CompositionLocalProvider(LocalOverscrollConfiguration provides null) {
                content()
            }
        }
    )
}

