/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.unified

import com.listrovia.music.api.MusicCategory
import com.listrovia.music.api.MusicCountry
import com.listrovia.music.api.MusicSourceProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import timber.log.Timber
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Apple Music Adapter - Connects to the Apple Music / MusicKit RSS & iTunes Web API
 * and normalizes raw JSON responses into the [UnifiedMusicInterface] standard data structure.
 */
@Singleton
class AppleMusicAdapter @Inject constructor() : UnifiedMusicInterface {

    override val provider: MusicSourceProvider = MusicSourceProvider.APPLE_MUSIC

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val jsonParser = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    override suspend fun searchTracks(query: String, limit: Int): List<UnifiedTrack> = withContext(Dispatchers.IO) {
        val list = mutableListOf<UnifiedTrack>()
        try {
            val encodedQuery = URLEncoder.encode(query, "UTF-8")
            val url = "https://itunes.apple.com/search?term=$encodedQuery&entity=song&limit=$limit"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)")
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val root = jsonParser.parseToJsonElement(body).jsonObject
                    val results = root["results"]?.jsonArray
                    results?.forEach { item ->
                        val obj = item.jsonObject
                        val rawId = obj["trackId"]?.jsonPrimitive?.content ?: ""
                        val title = obj["trackName"]?.jsonPrimitive?.content ?: ""
                        val artist = obj["artistName"]?.jsonPrimitive?.content ?: ""
                        val album = obj["collectionName"]?.jsonPrimitive?.content ?: ""
                        val art = (obj["artworkUrl100"]?.jsonPrimitive?.content ?: "").replace("100x100bb.jpg", "600x600bb.jpg")
                        val durationMs = obj["trackTimeMillis"]?.jsonPrimitive?.content?.toIntOrNull()
                        val previewUrl = obj["previewUrl"]?.jsonPrimitive?.content
                        val trackViewUrl = obj["trackViewUrl"]?.jsonPrimitive?.content
                        val isExplicit = obj["trackExplicitness"]?.jsonPrimitive?.content == "explicit"

                        if (title.isNotBlank() && rawId.isNotBlank()) {
                            list.add(
                                UnifiedTrack(
                                    id = "am_$rawId",
                                    title = title,
                                    artist = artist,
                                    artists = listOf(artist),
                                    album = album,
                                    thumbnailUrl = art,
                                    durationSeconds = durationMs?.let { it / 1000 },
                                    provider = MusicSourceProvider.APPLE_MUSIC,
                                    previewUrl = previewUrl,
                                    externalUrl = trackViewUrl,
                                    isExplicit = isExplicit
                                )
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Apple Music searchTracks error")
        }
        return@withContext list
    }

    override suspend fun searchArtists(query: String, limit: Int): List<UnifiedArtist> = withContext(Dispatchers.IO) {
        val artists = mutableListOf<UnifiedArtist>()
        try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = "https://itunes.apple.com/search?term=$encoded&entity=musicArtist&limit=$limit"
            val request = Request.Builder().url(url).build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val root = jsonParser.parseToJsonElement(body).jsonObject
                    val results = root["results"]?.jsonArray
                    coroutineScope {
                        val deferreds = results?.map { item ->
                            async {
                                val obj = item.jsonObject
                                val rawId = obj["artistId"]?.jsonPrimitive?.content ?: ""
                                val name = obj["artistName"]?.jsonPrimitive?.content ?: ""
                                val genre = obj["primaryGenreName"]?.jsonPrimitive?.content ?: ""
                                val artistLinkUrl = obj["artistLinkUrl"]?.jsonPrimitive?.content

                                if (name.isNotBlank() && rawId.isNotBlank()) {
                                    var thumbnail = ""
                                    try {
                                        val lookupUrl = "https://itunes.apple.com/lookup?id=$rawId&entity=album&limit=1"
                                        val lookupRequest = Request.Builder().url(lookupUrl).build()
                                        client.newCall(lookupRequest).execute().use { lookupResp ->
                                            if (lookupResp.isSuccessful) {
                                                val lookupBody = lookupResp.body?.string() ?: ""
                                                val lookupRoot = jsonParser.parseToJsonElement(lookupBody).jsonObject
                                                val lookupResults = lookupRoot["results"]?.jsonArray
                                                lookupResults?.forEach { resItem ->
                                                    val resObj = resItem.jsonObject
                                                    val wrapperType = resObj["wrapperType"]?.jsonPrimitive?.content
                                                    if (wrapperType == "collection" || wrapperType == "track") {
                                                        val art = resObj["artworkUrl100"]?.jsonPrimitive?.content
                                                        if (!art.isNullOrBlank()) {
                                                            thumbnail = art.replace("100x100bb.jpg", "600x600bb.jpg")
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    } catch (e: Exception) {
                                        Timber.w(e, "Error fetching thumbnail for artist $name")
                                    }

                                    UnifiedArtist(
                                        id = "am_art_$rawId",
                                        name = name,
                                        thumbnailUrl = thumbnail,
                                        genres = if (genre.isNotBlank()) listOf(genre) else emptyList(),
                                        provider = MusicSourceProvider.APPLE_MUSIC,
                                        externalUrl = artistLinkUrl
                                    )
                                } else {
                                    null
                                }
                            }
                        }
                        val resolved = deferreds?.awaitAll()?.filterNotNull()
                        if (resolved != null) {
                            artists.addAll(resolved)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Timber.w(e, "Apple Music searchArtists error")
        }
        return@withContext artists
    }

    override suspend fun searchPlaylists(query: String, limit: Int): List<UnifiedPlaylist> = withContext(Dispatchers.IO) {
        // Apple Music search via iTunes returns album/playlist collections
        val playlists = mutableListOf<UnifiedPlaylist>()
        try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = "https://itunes.apple.com/search?term=$encoded&entity=album&limit=$limit"
            val request = Request.Builder().url(url).build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val root = jsonParser.parseToJsonElement(body).jsonObject
                    val results = root["results"]?.jsonArray
                    results?.forEach { item ->
                        val obj = item.jsonObject
                        val rawId = obj["collectionId"]?.jsonPrimitive?.content ?: ""
                        val name = obj["collectionName"]?.jsonPrimitive?.content ?: ""
                        val artist = obj["artistName"]?.jsonPrimitive?.content ?: "Apple Music"
                        val art = (obj["artworkUrl100"]?.jsonPrimitive?.content ?: "").replace("100x100bb.jpg", "600x600bb.jpg")
                        val trackCount = obj["trackCount"]?.jsonPrimitive?.content?.toIntOrNull()
                        val viewUrl = obj["collectionViewUrl"]?.jsonPrimitive?.content

                        if (name.isNotBlank() && rawId.isNotBlank()) {
                            playlists.add(
                                UnifiedPlaylist(
                                    id = "am_pl_$rawId",
                                    title = name,
                                    description = artist,
                                    thumbnailUrl = art,
                                    trackCount = trackCount,
                                    provider = MusicSourceProvider.APPLE_MUSIC,
                                    externalUrl = viewUrl
                                )
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Timber.w(e, "Apple Music searchPlaylists error")
        }
        return@withContext playlists
    }

    override suspend fun getRecommendations(
        country: MusicCountry,
        category: MusicCategory,
        limit: Int
    ): List<UnifiedTrack> = withContext(Dispatchers.IO) {
        val tracks = mutableListOf<UnifiedTrack>()

        // 1. Try Apple Music RSS most-played API for country
        if (category == MusicCategory.ALL) {
            try {
                val url = "https://rss.applemarketingtools.com/api/v2/${country.code}/music/most-played/$limit/songs.json"
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", "Mozilla/5.0")
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string() ?: ""
                        val root = jsonParser.parseToJsonElement(body).jsonObject
                        val results = root["feed"]?.jsonObject?.get("results")?.jsonArray
                        results?.forEach { item ->
                            val obj = item.jsonObject
                            val rawId = obj["id"]?.jsonPrimitive?.content ?: ""
                            val title = obj["name"]?.jsonPrimitive?.content ?: ""
                            val artist = obj["artistName"]?.jsonPrimitive?.content ?: ""
                            val art = (obj["artworkUrl100"]?.jsonPrimitive?.content ?: "").replace("100x100bb.jpg", "600x600bb.jpg")
                            val externalUrl = obj["url"]?.jsonPrimitive?.content

                            if (title.isNotBlank() && rawId.isNotBlank()) {
                                tracks.add(
                                    UnifiedTrack(
                                        id = "am_$rawId",
                                        title = title,
                                        artist = artist,
                                        artists = listOf(artist),
                                        thumbnailUrl = art,
                                        provider = MusicSourceProvider.APPLE_MUSIC,
                                        externalUrl = externalUrl,
                                        countryCode = country.code,
                                        categoryId = category.id
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.w(e, "Apple Music RSS fetch failed for ${country.code}")
            }
        }

        // 2. Category-specific search or Fallback
        if (tracks.isEmpty() || category != MusicCategory.ALL) {
            try {
                val queryStr = getCategoryAppleSearchQuery(country, category)
                val searchTerm = URLEncoder.encode(queryStr, "UTF-8")
                val url = "https://itunes.apple.com/search?term=$searchTerm&country=${country.code}&entity=song&limit=$limit"
                val request = Request.Builder().url(url).build()
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string() ?: ""
                        val root = jsonParser.parseToJsonElement(body).jsonObject
                        val results = root["results"]?.jsonArray
                        results?.forEach { item ->
                            val obj = item.jsonObject
                            val rawId = obj["trackId"]?.jsonPrimitive?.content ?: ""
                            val title = obj["trackName"]?.jsonPrimitive?.content ?: ""
                            val artist = obj["artistName"]?.jsonPrimitive?.content ?: ""
                            val album = obj["collectionName"]?.jsonPrimitive?.content ?: ""
                            val art = (obj["artworkUrl100"]?.jsonPrimitive?.content ?: "").replace("100x100bb.jpg", "600x600bb.jpg")
                            val preview = obj["previewUrl"]?.jsonPrimitive?.content
                            val extUrl = obj["trackViewUrl"]?.jsonPrimitive?.content
                            val trackExplicitness = obj["trackExplicitness"]?.jsonPrimitive?.content
                            val isExplicit = trackExplicitness?.equals("explicit", ignoreCase = true) ?: false

                            if (title.isNotBlank() && rawId.isNotBlank() && (!category.isKidsFamily || !isExplicit)) {
                                tracks.add(
                                    UnifiedTrack(
                                        id = "am_$rawId",
                                        title = title,
                                        artist = artist,
                                        artists = listOf(artist),
                                        album = album,
                                        thumbnailUrl = art,
                                        previewUrl = preview,
                                        provider = MusicSourceProvider.APPLE_MUSIC,
                                        externalUrl = extUrl,
                                        isExplicit = isExplicit,
                                        countryCode = country.code,
                                        categoryId = category.id
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.w(e, "Apple Music category search failed for ${country.code} ${category.id}")
            }
        }

        return@withContext tracks.distinctBy { "${it.title.lowercase()}_${it.artist.lowercase()}" }
    }

    override suspend fun getFeaturedPlaylists(
        country: MusicCountry,
        category: MusicCategory,
        limit: Int
    ): List<UnifiedPlaylist> = withContext(Dispatchers.IO) {
        val playlists = mutableListOf<UnifiedPlaylist>()
        if (category == MusicCategory.ALL) {
            try {
                val url = "https://rss.applemarketingtools.com/api/v2/${country.code}/music/most-played/$limit/playlists.json"
                val request = Request.Builder().url(url).build()
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string() ?: ""
                        val root = jsonParser.parseToJsonElement(body).jsonObject
                        val results = root["feed"]?.jsonObject?.get("results")?.jsonArray
                        results?.forEach { item ->
                            val obj = item.jsonObject
                            val rawId = obj["id"]?.jsonPrimitive?.content ?: ""
                            val name = obj["name"]?.jsonPrimitive?.content ?: ""
                            val artist = obj["artistName"]?.jsonPrimitive?.content ?: "Apple Music"
                            val art = (obj["artworkUrl100"]?.jsonPrimitive?.content ?: "").replace("100x100bb.jpg", "600x600bb.jpg")
                            val externalUrl = obj["url"]?.jsonPrimitive?.content

                            if (name.isNotBlank() && rawId.isNotBlank()) {
                                playlists.add(
                                    UnifiedPlaylist(
                                        id = "am_pl_$rawId",
                                        title = name,
                                        description = artist,
                                        thumbnailUrl = art,
                                        provider = MusicSourceProvider.APPLE_MUSIC,
                                        externalUrl = externalUrl
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.w(e, "Apple Music featured playlists error for ${country.code}")
            }
        }

        if (playlists.isEmpty() || category != MusicCategory.ALL) {
            try {
                val queryStr = getCategoryAppleSearchQuery(country, category) + " playlist"
                val searchTerm = URLEncoder.encode(queryStr, "UTF-8")
                val url = "https://itunes.apple.com/search?term=$searchTerm&country=${country.code}&entity=album&limit=$limit"
                val request = Request.Builder().url(url).build()
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string() ?: ""
                        val root = jsonParser.parseToJsonElement(body).jsonObject
                        val results = root["results"]?.jsonArray
                        results?.forEach { item ->
                            val obj = item.jsonObject
                            val rawId = obj["collectionId"]?.jsonPrimitive?.content ?: ""
                            val name = obj["collectionName"]?.jsonPrimitive?.content ?: ""
                            val artist = obj["artistName"]?.jsonPrimitive?.content ?: "Apple Music"
                            val art = (obj["artworkUrl100"]?.jsonPrimitive?.content ?: "").replace("100x100bb.jpg", "600x600bb.jpg")
                            val trackCount = obj["trackCount"]?.jsonPrimitive?.content?.toIntOrNull()
                            val viewUrl = obj["collectionViewUrl"]?.jsonPrimitive?.content

                            if (name.isNotBlank() && rawId.isNotBlank()) {
                                playlists.add(
                                    UnifiedPlaylist(
                                        id = "am_pl_$rawId",
                                        title = name,
                                        description = artist,
                                        thumbnailUrl = art,
                                        trackCount = trackCount,
                                        provider = MusicSourceProvider.APPLE_MUSIC,
                                        externalUrl = viewUrl
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.w(e, "Apple Music curated search fallback error for category ${category.id}")
            }
        }
        return@withContext playlists.distinctBy { it.title.lowercase() }
    }

    override suspend fun getTopArtists(
        country: MusicCountry,
        category: MusicCategory,
        limit: Int
    ): List<UnifiedArtist> = withContext(Dispatchers.IO) {
        val query = getCategoryAppleSearchQuery(country, category)
        return@withContext searchArtists(query, limit)
    }

    override suspend fun getTrackById(id: String): UnifiedTrack? = withContext(Dispatchers.IO) {
        val cleanId = id.removePrefix("am_").removePrefix("apple:")
        try {
            val url = "https://itunes.apple.com/lookup?id=$cleanId&entity=song"
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: return@withContext null
                    val root = jsonParser.parseToJsonElement(body).jsonObject
                    val item = root["results"]?.jsonArray?.firstOrNull()?.jsonObject ?: return@withContext null
                    val rawId = item["trackId"]?.jsonPrimitive?.content ?: cleanId
                    val title = item["trackName"]?.jsonPrimitive?.content ?: ""
                    val artist = item["artistName"]?.jsonPrimitive?.content ?: ""
                    val album = item["collectionName"]?.jsonPrimitive?.content ?: ""
                    val art = (item["artworkUrl100"]?.jsonPrimitive?.content ?: "").replace("100x100bb.jpg", "600x600bb.jpg")
                    val durationMs = item["trackTimeMillis"]?.jsonPrimitive?.content?.toIntOrNull()
                    val previewUrl = item["previewUrl"]?.jsonPrimitive?.content
                    val externalUrl = item["trackViewUrl"]?.jsonPrimitive?.content
                    val isExplicit = item["trackExplicitness"]?.jsonPrimitive?.content == "explicit"

                    return@withContext UnifiedTrack(
                        id = "am_$rawId",
                        title = title,
                        artist = artist,
                        artists = listOf(artist),
                        album = album,
                        thumbnailUrl = art,
                        durationSeconds = durationMs?.let { it / 1000 },
                        provider = MusicSourceProvider.APPLE_MUSIC,
                        previewUrl = previewUrl,
                        externalUrl = externalUrl,
                        isExplicit = isExplicit
                    )
                }
            }
        } catch (e: Exception) {
            Timber.w(e, "Apple Music getTrackById error: $id")
        }
        return@withContext null
    }

    private fun getCategoryAppleSearchQuery(country: MusicCountry, category: MusicCategory): String {
        return when (category) {
            MusicCategory.ALL -> when (country) {
                MusicCountry.VIETNAM -> "vietnam top hits"
                MusicCountry.US -> "top hits billboard"
                MusicCountry.UK -> "uk top 40"
                MusicCountry.JAPAN -> "j-pop top hits"
                MusicCountry.KOREA -> "k-pop top hits"
                MusicCountry.FRANCE -> "france top hits"
            }
            MusicCategory.KIDS_FAMILY -> when (country) {
                MusicCountry.VIETNAM -> "nhạc thiếu nhi bé yêu"
                MusicCountry.JAPAN -> "nhạc thiếu nhi nhật bản"
                MusicCountry.KOREA -> "nhạc thiếu nhi hàn quốc"
                MusicCountry.FRANCE -> "comptines enfants français"
                else -> "kids songs disney nursery rhymes"
            }
            MusicCategory.VPOP -> when (country) {
                MusicCountry.VIETNAM -> "nhạc vpop trẻ"
                MusicCountry.US -> "v-pop hot hits us"
                else -> "vietnamese v-pop"
            }
            MusicCategory.POP_GLOBAL -> when (country) {
                MusicCountry.VIETNAM -> "nhạc pop hot"
                MusicCountry.US -> "top billboard hot pop"
                MusicCountry.UK -> "uk pop hits billboard"
                MusicCountry.JAPAN -> "japanese pop hits j-pop"
                MusicCountry.KOREA -> "korean pop hits k-pop"
                MusicCountry.FRANCE -> "variété française pop"
            }
            MusicCategory.KPOP_JPOP -> when (country) {
                MusicCountry.VIETNAM -> "kpop jpop hot hits việt nam"
                MusicCountry.JAPAN -> "j-pop hot hits top"
                MusicCountry.KOREA -> "k-pop hot hits top"
                else -> "k-pop and j-pop hits"
            }
            MusicCategory.CHILL_ACOUSTIC -> when (country) {
                MusicCountry.VIETNAM -> "acoustic lofi chill buồn tâm trạng việt nam"
                MusicCountry.JAPAN -> "acoustic lofi chill japan"
                MusicCountry.KOREA -> "acoustic lofi chill korea"
                MusicCountry.FRANCE -> "acoustic lofi chill france"
                else -> "us-uk chill acoustic lofi coffee"
            }
            MusicCategory.EDM_DANCE -> when (country) {
                MusicCountry.VIETNAM -> "nhạc edm remix vinahouse cực mạnh việt nam"
                MusicCountry.JAPAN -> "electronic dance edm japan"
                MusicCountry.KOREA -> "electronic dance edm korea"
                MusicCountry.FRANCE -> "club french touch dance house"
                else -> "dance edm club hits ultra remix"
            }
        }
    }
}
