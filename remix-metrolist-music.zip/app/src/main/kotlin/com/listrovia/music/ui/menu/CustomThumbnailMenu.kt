/**
 * Listrovia Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.listrovia.music.ui.menu

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.listrovia.music.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomThumbnailMenu(
    onEdit: () -> Unit,
    onPalette: () -> Unit = {},
    onRemove: () -> Unit,
    onDismiss: () -> Unit,
    canRemove: Boolean = true,
) {
    LazyColumn(
        contentPadding = PaddingValues(
            start = 8.dp,
            top = 8.dp,
            end = 8.dp,
            bottom = 8.dp + WindowInsets.systemBars.asPaddingValues().calculateBottomPadding(),
        ),
    ) {
        item {
            ListItem(
                headlineContent = {
                    Text(text = stringResource(R.string.playlist_cover_tab_palette))
                },
                supportingContent = {
                    Text(text = stringResource(R.string.custom_playlist_cover_subtitle))
                },
                leadingContent = {
                    Icon(
                        painter = painterResource(R.drawable.palette),
                        contentDescription = null,
                    )
                },
                modifier = Modifier.clickable {
                    onPalette()
                    onDismiss()
                }
            )
        }
        item {
            ListItem(
                headlineContent = {
                    Text(text = stringResource(R.string.choose_from_library))
                },
                supportingContent = {
                    Text(text = stringResource(R.string.playlist_cover_pick_from_device_desc))
                },
                leadingContent = {
                    Icon(
                        painter = painterResource(R.drawable.insert_photo),
                        contentDescription = null,
                    )
                },
                modifier = Modifier.clickable {
                    onEdit()
                    onDismiss()
                }
            )
        }
        if (canRemove) {
            item {
                ListItem(
                    headlineContent = {
                        Text(text = stringResource(R.string.remove_custom_image))
                    },
                    leadingContent = {
                        Icon(
                            painter = painterResource(R.drawable.delete),
                            contentDescription = null,
                        )
                    },
                    modifier = Modifier.clickable {
                        onRemove()
                        onDismiss()
                    }
                )
            }
        }
    }
}

