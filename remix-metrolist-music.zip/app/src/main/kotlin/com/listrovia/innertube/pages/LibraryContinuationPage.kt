package com.listrovia.innertube.pages

import com.listrovia.innertube.models.YTItem

data class LibraryContinuationPage(
    val items: List<YTItem>,
    val continuation: String?,
)
