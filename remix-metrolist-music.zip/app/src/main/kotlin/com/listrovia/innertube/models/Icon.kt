package com.listrovia.innertube.models

import kotlinx.serialization.Serializable

@Serializable
data class Icon(
    val iconType: String,
)
