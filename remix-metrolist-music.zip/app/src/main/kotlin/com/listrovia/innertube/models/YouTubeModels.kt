package com.listrovia.innertube.models

import kotlinx.serialization.Serializable

@Serializable
data class YouTubeVideoItem(
    val videoId: String,
    val title: String,
    val channelName: String,
    val channelId: String? = null,
    val description: String? = null,
    val viewCountText: String? = null,
    val publishedTimeText: String? = null,
    val durationText: String? = null,
    val thumbnails: List<Thumbnail> = emptyList(),
    val isLive: Boolean = false,
)

@Serializable
data class YouTubeChannelPage(
    val channelId: String,
    val title: String,
    val avatarUrl: String? = null,
    val bannerUrl: String? = null,
    val subscriberCountText: String? = null,
    val videosCountText: String? = null,
    val description: String? = null,
    val videos: List<YouTubeVideoItem> = emptyList(),
    val continuation: String? = null,
    val isSubscribed: Boolean? = null,
) {
    companion object {
        const val VIDEOS_PARAMS = "EgZ2aWRlb3PyBgQKAjoA"
        const val SHORTS_PARAMS = "EgZzaG9ydHPyBgQKAjoA"
        const val LIVE_PARAMS = "EgRsaXZleyBgQKAjoA"
    }
}

@Serializable
data class YouTubeChannelPost(
    val postId: String,
    val authorName: String,
    val authorThumbnail: String? = null,
    val publishedTimeText: String? = null,
    val contentText: String? = null,
    val imageUrls: List<String> = emptyList(),
    val voteCountText: String? = null,
    val commentCountText: String? = null,
)

@Serializable
data class YouTubeSearchResultItem(
    val video: YouTubeVideoItem? = null,
    val channelId: String? = null,
    val playlistId: String? = null,
    val title: String? = null,
    val thumbnails: List<Thumbnail> = emptyList(),
    val channelName: String? = null,
    val videoCount: String? = null,
    val description: String? = null,
)

@Serializable
data class VideoFeedResult(
    val items: List<YouTubeVideoItem>,
    val continuation: String?,
)
