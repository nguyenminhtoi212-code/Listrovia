package com.listrovia.innertube.pages

import com.listrovia.innertube.models.SongItem

data class PlaylistContinuationPage(
    val songs: List<SongItem>,
    val continuation: String?,
)
