package com.listrovia.innertube.pages

import com.listrovia.innertube.models.YouTubeVideoItem
import com.listrovia.innertube.models.Thumbnail
import com.listrovia.innertube.models.YouTubeSearchResultItem
import com.listrovia.innertube.models.YouTubeChannelPage
import com.listrovia.innertube.models.YouTubeChannelPost
import com.listrovia.innertube.models.VideoFeedResult
import kotlinx.serialization.json.*

object VideoFeedPage {
    fun fromJson(json: JsonObject): VideoFeedResult {
        val items = mutableListOf<YouTubeVideoItem>()
        
        // This is a simplified parser for standard YouTube feed responses
        // In a real app, you'd want a more robust implementation using Serializable models
        
        val contents = json["contents"]?.jsonObject
            ?.get("twoColumnBrowseResultsRenderer")?.jsonObject
            ?.get("tabs")?.jsonArray?.firstOrNull()?.jsonObject
            ?.get("tabRenderer")?.jsonObject
            ?.get("content")?.jsonObject
            ?.get("sectionListRenderer")?.jsonObject
            ?.get("contents")?.jsonArray
            ?: json["onResponseReceivedActions"]?.jsonArray?.firstOrNull()?.jsonObject
                ?.get("appendContinuationItemsAction")?.jsonObject
                ?.get("continuationItems")?.jsonArray
            ?: return VideoFeedResult(emptyList(), null)

        var continuation: String? = null

        contents.forEach { content ->
            val itemSection = content.jsonObject["itemSectionRenderer"]?.jsonObject
            val shelf = content.jsonObject["richShelfRenderer"]?.jsonObject
            val richGrid = content.jsonObject["richGridRenderer"]?.jsonObject
            
            val videoItems = mutableListOf<JsonObject>()
            
            if (itemSection != null) {
                itemSection["contents"]?.jsonArray?.forEach { videoItems.add(it.jsonObject) }
            } else if (shelf != null) {
                shelf["contents"]?.jsonArray?.forEach { videoItems.add(it.jsonObject["richItemRenderer"]?.jsonObject ?: it.jsonObject) }
            } else if (richGrid != null) {
                richGrid["contents"]?.jsonArray?.forEach { videoItems.add(it.jsonObject["richItemRenderer"]?.jsonObject ?: it.jsonObject) }
                continuation = richGrid["continuations"]?.jsonArray?.firstOrNull()?.jsonObject
                    ?.get("nextContinuationData")?.jsonObject?.get("continuation")?.jsonPrimitive?.content
            } else if (content.jsonObject.containsKey("richItemRenderer")) {
                videoItems.add(content.jsonObject["richItemRenderer"]!!.jsonObject)
            } else if (content.jsonObject.containsKey("continuationItemRenderer")) {
                 continuation = content.jsonObject["continuationItemRenderer"]?.jsonObject
                    ?.get("continuationEndpoint")?.jsonObject
                    ?.get("continuationCommand")?.jsonObject
                    ?.get("token")?.jsonPrimitive?.content
            }

            videoItems.forEach { videoJson ->
                val renderer = videoJson["videoRenderer"]?.jsonObject 
                    ?: videoJson["gridVideoRenderer"]?.jsonObject
                    ?: videoJson["content"]?.jsonObject?.get("videoRenderer")?.jsonObject
                
                if (renderer != null) {
                    val videoId = renderer["videoId"]?.jsonPrimitive?.content ?: return@forEach
                    val title = renderer["title"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content ?: ""
                    val channelName = renderer["shortBylineText"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content ?: ""
                    val channelId = renderer["shortBylineText"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject
                        ?.get("navigationEndpoint")?.jsonObject?.get("browseEndpoint")?.jsonObject?.get("browseId")?.jsonPrimitive?.content
                    
                    val thumbnails = renderer["thumbnail"]?.jsonObject?.get("thumbnails")?.jsonArray?.map {
                        Thumbnail(
                            url = it.jsonObject["url"]!!.jsonPrimitive.content,
                            width = it.jsonObject["width"]?.jsonPrimitive?.intOrNull,
                            height = it.jsonObject["height"]?.jsonPrimitive?.intOrNull
                        )
                    } ?: emptyList()

                    val viewCountText = renderer["viewCountText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content
                        ?: renderer["viewCountText"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content
                    val publishedTimeText = renderer["publishedTimeText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content
                    val durationText = renderer["lengthText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content

                    items.add(YouTubeVideoItem(
                        videoId = videoId,
                        title = title,
                        channelName = channelName,
                        channelId = channelId,
                        thumbnails = thumbnails,
                        viewCountText = viewCountText,
                        publishedTimeText = publishedTimeText,
                        durationText = durationText
                    ))
                }
            }
        }

        return VideoFeedResult(items, continuation)
    }

    fun parseSearch(json: JsonObject): VideoFeedResult {
        val items = mutableListOf<YouTubeVideoItem>()
        val contents = json["contents"]?.jsonObject
            ?.get("twoColumnSearchResultsRenderer")?.jsonObject
            ?.get("primaryContents")?.jsonObject
            ?.get("sectionListRenderer")?.jsonObject
            ?.get("contents")?.jsonArray
            ?: return VideoFeedResult(emptyList(), null)

        var continuation: String? = null

        contents.forEach { content ->
            val itemSection = content.jsonObject["itemSectionRenderer"]?.jsonObject ?: return@forEach
            itemSection["contents"]?.jsonArray?.forEach { videoJson ->
                val renderer = videoJson.jsonObject["videoRenderer"]?.jsonObject ?: return@forEach
                val videoId = renderer["videoId"]?.jsonPrimitive?.content ?: return@forEach
                val title = renderer["title"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content ?: ""
                val channelName = renderer["ownerText"]?.jsonObject?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject?.get("text")?.jsonPrimitive?.content ?: ""
                
                val thumbnails = renderer["thumbnail"]?.jsonObject?.get("thumbnails")?.jsonArray?.map {
                    Thumbnail(
                        url = it.jsonObject["url"]!!.jsonPrimitive.content,
                        width = it.jsonObject["width"]?.jsonPrimitive?.intOrNull,
                        height = it.jsonObject["height"]?.jsonPrimitive?.intOrNull
                    )
                } ?: emptyList()

                val viewCountText = renderer["viewCountText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content
                val publishedTimeText = renderer["publishedTimeText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content
                val durationText = renderer["lengthText"]?.jsonObject?.get("simpleText")?.jsonPrimitive?.content

                items.add(YouTubeVideoItem(
                    videoId = videoId,
                    title = title,
                    channelName = channelName,
                    thumbnails = thumbnails,
                    viewCountText = viewCountText,
                    publishedTimeText = publishedTimeText,
                    durationText = durationText
                ))
            }
            
            if (continuation == null) {
                continuation = itemSection["continuations"]?.jsonArray?.firstOrNull()?.jsonObject
                    ?.get("nextContinuationData")?.jsonObject?.get("continuation")?.jsonPrimitive?.content
            }
        }

        return VideoFeedResult(items, continuation)
    }
}
