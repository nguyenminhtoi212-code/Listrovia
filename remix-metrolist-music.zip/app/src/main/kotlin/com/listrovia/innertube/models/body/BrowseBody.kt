package com.listrovia.innertube.models.body

import com.listrovia.innertube.models.Context
import com.listrovia.innertube.models.Continuation
import kotlinx.serialization.Serializable

@Serializable
data class BrowseBody(
    val context: Context,
    val browseId: String?,
    val params: String?,
    val continuation: String?
)
