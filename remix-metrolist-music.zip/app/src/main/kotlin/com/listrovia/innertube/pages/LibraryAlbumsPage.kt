package com.listrovia.innertube.pages

import com.listrovia.innertube.models.Album
import com.listrovia.innertube.models.AlbumItem
import com.listrovia.innertube.models.Artist
import com.listrovia.innertube.models.ArtistItem
import com.listrovia.innertube.models.MusicResponsiveListItemRenderer
import com.listrovia.innertube.models.MusicTwoRowItemRenderer
import com.listrovia.innertube.models.PlaylistItem
import com.listrovia.innertube.models.SongItem
import com.listrovia.innertube.models.YTItem
import com.listrovia.innertube.models.oddElements
import com.listrovia.innertube.utils.parseTime

data class LibraryAlbumsPage(
    val albums: List<AlbumItem>,
    val continuation: String?,
) {
    companion object {
        fun fromMusicTwoRowItemRenderer(renderer: MusicTwoRowItemRenderer): AlbumItem? {
            return AlbumItem(
                        browseId = renderer.navigationEndpoint.browseEndpoint?.browseId ?: return null,
                        playlistId = renderer.thumbnailOverlay?.musicItemThumbnailOverlayRenderer?.content
                            ?.musicPlayButtonRenderer?.playNavigationEndpoint
                            ?.watchPlaylistEndpoint?.playlistId ?: return null,
                        title = renderer.title.runs?.firstOrNull()?.text ?: return null,
                        artists = null,
                        year = renderer.subtitle?.runs?.lastOrNull()?.text?.toIntOrNull(),
                        thumbnail = renderer.thumbnailRenderer.musicThumbnailRenderer?.getThumbnailUrl() ?: return null,
                        explicit = renderer.subtitleBadges?.find {
                            it.musicInlineBadgeRenderer?.icon?.iconType == "MUSIC_EXPLICIT_BADGE"
                        } != null
                    )
        }
    }
}
