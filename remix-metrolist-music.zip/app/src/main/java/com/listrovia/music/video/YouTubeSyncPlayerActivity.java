package com.listrovia.music.video;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;

public class YouTubeSyncPlayerActivity extends AppCompatActivity {

    // Đường dẫn gốc hoặc Video ID truyền vào
    private String youtubeVideoUrl = "https://www.youtube.com/watch?v=X3_0_8dZ3xY"; 
    private String videoId;

    private FrameLayout playerContainer;
    private WebView youtubeWebView;
    private ImageView albumArtImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Đọc Intent Extras từ VideoPlaybackManager hoặc Music Player
        if (getIntent() != null) {
            String intentUrl = getIntent().getStringExtra("VIDEO_URL");
            if (intentUrl != null && !intentUrl.trim().isEmpty()) {
                this.youtubeVideoUrl = intentUrl;
            }
            String intentVideoId = getIntent().getStringExtra("VIDEO_ID");
            if (intentVideoId != null && !intentVideoId.trim().isEmpty()) {
                this.videoId = intentVideoId;
            }
        }

        // 1. Tách lấy Video ID nếu nhận qua URL
        if (this.videoId == null || this.videoId.isEmpty()) {
            this.videoId = extractVideoId(youtubeVideoUrl);
        }

        // 2. Khởi tạo Khung chữ nhật chứa Video (Không dùng XML)
        playerContainer = new FrameLayout(this);
        playerContainer.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, 600)); // Chiều cao khung chữ nhật
        playerContainer.setBackgroundColor(Color.BLACK);

        // 3. Lớp ảnh bìa Thumbnail để tránh bị ĐEN XÌ khi API đang kết nối
        albumArtImageView = new ImageView(this);
        albumArtImageView.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        albumArtImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        
        // Tải ảnh xem trước trực tiếp từ đường dẫn gốc
        String thumbnailUrl = "https://img.youtube.com/vi/" + videoId + "/hqdefault.jpg";
        Glide.with(this).load(thumbnailUrl).into(albumArtImageView);

        // 4. Khởi tạo WebView phát Video đồng bộ
        youtubeWebView = new WebView(this);
        youtubeWebView.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        // Cấu hình cơ chế Xác thực & API YouTube không bị chặn lỗi 152-4
        WebSettings webSettings = youtubeWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setMediaPlaybackRequiresUserGesture(false); // Tự động phát không cần bấm
        webSettings.setAllowFileAccess(true);

        // GIẢI PHÁP 1: Đổi User-Agent sang Chrome Mobile chuẩn để VƯỢT LỖI 152-4
        String customUserAgent = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36";
        webSettings.setUserAgentString(customUserAgent);

        // GIẢI PHÁP 2: ÉP TẤT CẢ LIÊN KẾT PHÁT TRONG ỨNG DỤNG (Không mở web/app ngoài)
        youtubeWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.contains("youtube.com/watch") || url.contains("youtu.be") || url.contains("intent://") ||
                    url.contains("youtube.com/channel") || url.contains("youtube.com/@") || url.contains("youtube.com/user") ||
                    url.contains("youtube.com/results") || url.contains("google.com/url") || url.contains("accounts.google.com")) {
                    return true; 
                }
                return false;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && (url.contains("youtube.com/watch") || url.contains("youtu.be") || url.contains("intent://") ||
                    url.contains("youtube.com/channel") || url.contains("youtube.com/@") || url.contains("youtube.com/user") ||
                    url.contains("youtube.com/results") || url.contains("google.com/url") || url.contains("accounts.google.com"))) {
                    return true;
                }
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                // Ẩn ảnh bìa khi video đã tải xong và sẵn sàng phát
                albumArtImageView.animate().alpha(0f).setDuration(300).withEndAction(() -> 
                    albumArtImageView.setVisibility(View.GONE)
                );
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                // Giữ ảnh bìa hiển thị khi mất mạng / UnknownHostException
                albumArtImageView.setAlpha(1f);
                albumArtImageView.setVisibility(View.VISIBLE);
            }
        });
        youtubeWebView.setWebChromeClient(new WebChromeClient());

        // Xếp chồng WebView và Ảnh bìa
        playerContainer.addView(youtubeWebView);
        playerContainer.addView(albumArtImageView);

        setContentView(playerContainer);

        // 5. Nạp cấu hình nhúng API đồng bộ (VƯỢT LỖI 152)
        loadSyncYouTubePlayer(videoId);
    }

    // GIẢI PHÁP 3: HTML Nhúng chuẩn không bị YouTube chặn Embed (VƯỢT LỖI 152) & Canh chuẩn không bị lệch
    private void loadSyncYouTubePlayer(String id) {
        String htmlContent = "<!DOCTYPE html><html><head>"
                + "<meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no'>"
                + "<style>body,html{margin:0;padding:0;width:100%;height:100%;background:#000;overflow:hidden;display:flex;justify-content:center;align-items:center;}"
                + "iframe{position:absolute;top:0;left:0;width:100%;height:100%;border:none;}</style>"
                + "</head><body>"
                + "<iframe id='player' type='text/html' width='100%' height='100%' "
                + "src='https://www.youtube-nocookie.com/embed/" + id 
                + "?enablejsapi=1&autoplay=1&controls=1&playsinline=1&widget_referrer=https://www.youtube.com' "
                + "frameborder='0' allow='autoplay; encrypted-media' allowfullscreen></iframe>"
                + "</body></html>";

        // Sử dụng domain youtube-nocookie.com làm Origin để vượt rào cản lỗi 152
        youtubeWebView.loadDataWithBaseURL("https://www.youtube-nocookie.com", htmlContent, "text/html", "UTF-8", null);
    }

    // Hàm trích xuất ID từ Đường dẫn YouTube gốc
    private String extractVideoId(String url) {
        if (url != null && url.contains("v=")) {
            String[] parts = url.split("v=");
            String id = parts[1];
            int ampersandPosition = id.indexOf('&');
            if (ampersandPosition != -1) {
                return id.substring(0, ampersandPosition);
            }
            return id;
        }
        return "X3_0_8dZ3xY"; // ID mặc định nếu đường dẫn lỗi
    }

    @Override
    protected void onDestroy() {
        if (youtubeWebView != null) {
            youtubeWebView.loadUrl("about:blank");
            youtubeWebView.destroy();
        }
        super.onDestroy();
    }
}
