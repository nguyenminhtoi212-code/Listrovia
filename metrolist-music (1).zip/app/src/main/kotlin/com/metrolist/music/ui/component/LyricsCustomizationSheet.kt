/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.component

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.metrolist.music.R
import com.metrolist.music.constants.LyricsColorTheme
import com.metrolist.music.constants.LyricsColorThemeKey
import com.metrolist.music.constants.LyricsTextPositionKey
import com.metrolist.music.constants.LyricsTextSizeKey
import com.metrolist.music.constants.PlayerBackgroundStyle
import com.metrolist.music.ui.screens.settings.LyricsPosition
import com.metrolist.music.utils.rememberEnumPreference
import com.metrolist.music.utils.rememberPreference
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Returns the effective accent color for lyrics based on the chosen color theme.
 */
fun getLyricsThemeColor(
    colorThemeName: String,
    primaryColor: Color,
    playerBackground: PlayerBackgroundStyle = PlayerBackgroundStyle.DEFAULT
): Color {
    val theme = try {
        LyricsColorTheme.valueOf(colorThemeName)
    } catch (e: Exception) {
        LyricsColorTheme.DEFAULT
    }
    return when (theme) {
        LyricsColorTheme.DEFAULT -> when (playerBackground) {
            PlayerBackgroundStyle.DEFAULT -> primaryColor
            else -> Color.White
        }
        LyricsColorTheme.WHITE -> Color.White
        LyricsColorTheme.NEON_GREEN -> Color(0xFF1DB954)
        LyricsColorTheme.CYAN -> Color(0xFF00E5FF)
        LyricsColorTheme.AMBER -> Color(0xFFFFB300)
        LyricsColorTheme.PURPLE -> Color(0xFFB388FF)
        LyricsColorTheme.ROSE -> Color(0xFFFF4081)
        LyricsColorTheme.ORANGE -> Color(0xFFFF6D00)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LyricsCustomizationSheet(
    onDismissRequest: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val coroutineScope = rememberCoroutineScope()

    ModalBottomSheet(
        onDismissRequest = onDismissRequest,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = modifier,
    ) {
        LyricsCustomizationContent(
            onClose = {
                coroutineScope.launch {
                    sheetState.hide()
                    onDismissRequest()
                }
            }
        )
    }
}

@Composable
fun LyricsCustomizationContent(
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var lyricsTextSize by rememberPreference(LyricsTextSizeKey, 28f)
    var lyricsPosition by rememberEnumPreference(LyricsTextPositionKey, LyricsPosition.CENTER)
    var lyricsColorTheme by rememberPreference(LyricsColorThemeKey, LyricsColorTheme.DEFAULT.name)

    val activeColor = getLyricsThemeColor(
        colorThemeName = lyricsColorTheme,
        primaryColor = MaterialTheme.colorScheme.primary,
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp)
            .padding(bottom = 32.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text(
                    text = stringResource(R.string.lyrics_customization),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text = stringResource(R.string.lyrics_customization_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            TextButton(onClick = onClose) {
                Text(stringResource(R.string.close))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Live Preview Box
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
            ) {
                val previewAlignment = when (lyricsPosition) {
                    LyricsPosition.LEFT -> TextAlign.Start
                    LyricsPosition.CENTER -> TextAlign.Center
                    LyricsPosition.RIGHT -> TextAlign.End
                }

                Text(
                    text = "♪ Lời bài hát đồng bộ thời gian",
                    fontSize = (lyricsTextSize * 0.75f).sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    textAlign = previewAlignment,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Dòng lời đang phát hiện tại...",
                    fontSize = lyricsTextSize.sp,
                    fontWeight = FontWeight.Bold,
                    color = activeColor,
                    textAlign = previewAlignment,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Giai điệu tiếp theo trong bài hát ♪",
                    fontSize = (lyricsTextSize * 0.75f).sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    textAlign = previewAlignment,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 1. Font Size Control
        Text(
            text = "${stringResource(R.string.lyrics_font_size)}: ${lyricsTextSize.roundToInt()} sp",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(modifier = Modifier.height(6.dp))
        Slider(
            value = lyricsTextSize,
            onValueChange = { lyricsTextSize = it },
            valueRange = 16f..42f,
            modifier = Modifier.fillMaxWidth(),
        )
        // Preset Size Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val sizeChips = listOf(
                "Nhỏ (20sp)" to 20f,
                "Vừa (26sp)" to 26f,
                "Lớn (32sp)" to 32f,
                "Cực lớn (38sp)" to 38f,
            )
            for ((label, size) in sizeChips) {
                FilterChip(
                    selected = lyricsTextSize.roundToInt() == size.roundToInt(),
                    onClick = { lyricsTextSize = size },
                    label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 2. Alignment Control
        Text(
            text = stringResource(R.string.lyrics_alignment),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val alignmentOptions = listOf(
                LyricsPosition.LEFT to "Trái",
                LyricsPosition.CENTER to "Giữa",
                LyricsPosition.RIGHT to "Phải",
            )
            for ((pos, labelText) in alignmentOptions) {
                val isSelected = lyricsPosition == pos
                val containerColor by animateColorAsState(
                    targetValue = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                    label = "alignColor",
                )
                val contentColor by animateColorAsState(
                    targetValue = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                    label = "alignTextColor",
                )

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = containerColor,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { lyricsPosition = pos },
                ) {
                    Box(
                        modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = labelText,
                            style = MaterialTheme.typography.labelMedium,
                            color = contentColor,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 3. Color Theme Control
        Text(
            text = stringResource(R.string.lyrics_color_theme),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            for (theme in LyricsColorTheme.values()) {
                val isSelected = lyricsColorTheme == theme.name
                val swatchColor = when (theme) {
                    LyricsColorTheme.DEFAULT -> MaterialTheme.colorScheme.primary
                    LyricsColorTheme.WHITE -> Color.White
                    LyricsColorTheme.NEON_GREEN -> Color(0xFF1DB954)
                    LyricsColorTheme.CYAN -> Color(0xFF00E5FF)
                    LyricsColorTheme.AMBER -> Color(0xFFFFB300)
                    LyricsColorTheme.PURPLE -> Color(0xFFB388FF)
                    LyricsColorTheme.ROSE -> Color(0xFFFF4081)
                    LyricsColorTheme.ORANGE -> Color(0xFFFF6D00)
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { lyricsColorTheme = theme.name }
                        .padding(6.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(swatchColor)
                            .then(
                                if (isSelected) {
                                    Modifier.border(3.dp, MaterialTheme.colorScheme.primary, CircleShape)
                                } else {
                                    Modifier.border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), CircleShape)
                                }
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (isSelected) {
                            Icon(
                                painter = painterResource(R.drawable.check),
                                contentDescription = null,
                                modifier = Modifier.size(20.dp),
                                tint = if (swatchColor == Color.White) Color.Black else Color.White,
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = theme.displayName,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    )
                }
            }
        }
    }
}
