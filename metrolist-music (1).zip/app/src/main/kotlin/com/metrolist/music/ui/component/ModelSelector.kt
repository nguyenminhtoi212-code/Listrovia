/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.music.ui.component

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.metrolist.music.R
import com.metrolist.music.api.DeepInfraClassifiedModels
import com.metrolist.music.api.DeepInfraModelItem
import com.metrolist.music.api.DeepInfraModelManager
import com.metrolist.music.constants.DeepInfraDefaultModel
import com.metrolist.music.viewmodels.ModelViewModel
import com.valentinilk.shimmer.shimmer
import kotlinx.coroutines.launch

/**
 * Reusable 'ModelSelector' Composable that fetches the model list from the DeepInfra API
 * (https://api.deepinfra.com/v1/openai/models) using Ktor and displays them in a modern,
 * Material 3 Dropdown menu for selecting AI models.
 *
 * Supports:
 * - Real-time live API reading via Ktor engine with fallback resilience.
 * - Bilingual support (Vietnamese & English) for model descriptions and ranking badges.
 * - Categorization (⭐ Ranked, 💬 Chat, 🧠 Reasoning, 🌐 All).
 * - Live search filter within the dropdown.
 * - Custom Model ID entry.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModelSelector(
    modifier: Modifier = Modifier,
    selectedModel: String,
    onModelSelected: (String) -> Unit,
    onCustomModelClick: (() -> Unit)? = null,
    onShowAllModelsClick: (() -> Unit)? = null,
    viewModel: ModelViewModel = hiltViewModel(),
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val modelManager = remember { DeepInfraModelManager.getInstance(context) }

    val vmDeepInfraModels by viewModel.deepInfraModels.collectAsStateWithLifecycle()
    val isVmLoading by viewModel.isDeepInfraLoading.collectAsStateWithLifecycle()

    var localModels by remember { mutableStateOf<DeepInfraClassifiedModels?>(vmDeepInfraModels) }
    var isLocalLoading by remember { mutableStateOf(false) }

    val activeModels = localModels ?: vmDeepInfraModels
    val isLoading = isLocalLoading || (isVmLoading && activeModels == null)

    var dropdownExpanded by remember { mutableStateOf(false) }
    var selectedCategoryIndex by remember { mutableStateOf(0) } // 0: Ranked, 1: Chat, 2: Reasoning, 3: All
    var searchQuery by remember { mutableStateOf("") }
    var isVietnamese by remember { mutableStateOf(true) }

    val loadModels: (Boolean) -> Unit = { force ->
        coroutineScope.launch {
            isLocalLoading = true
            try {
                val fetched = modelManager.fetchModels(forceRefresh = force)
                localModels = fetched
                if (force) {
                    Toast.makeText(
                        context,
                        if (isVietnamese) "Đã cập nhật ${fetched.allModels.size} mô hình từ DeepInfra (Ktor)"
                        else "Updated ${fetched.allModels.size} models from DeepInfra (Ktor)",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } catch (e: Exception) {
                if (force) {
                    Toast.makeText(context, "Lỗi kết nối / Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            } finally {
                isLocalLoading = false
            }
        }
    }

    LaunchedEffect(Unit) {
        if (activeModels == null) {
            loadModels(false)
        }
    }

    val currentCategoryList: List<DeepInfraModelItem> = remember(activeModels, selectedCategoryIndex) {
        val models = activeModels ?: return@remember emptyList()
        when (selectedCategoryIndex) {
            0 -> models.recommended
            1 -> models.chatModels
            2 -> models.reasoningModels
            else -> models.allModels
        }
    }

    val filteredModels: List<DeepInfraModelItem> = remember(currentCategoryList, searchQuery) {
        if (searchQuery.isBlank()) {
            currentCategoryList
        } else {
            val q = searchQuery.trim().lowercase()
            currentCategoryList.filter {
                it.id.lowercase().contains(q) ||
                    it.name.lowercase().contains(q) ||
                    it.providerName.lowercase().contains(q) ||
                    it.description.lowercase().contains(q) ||
                    it.descriptionVi.lowercase().contains(q)
            }
        }
    }

    val activeModelObj = remember(activeModels, selectedModel) {
        activeModels?.allModels?.firstOrNull { it.id == selectedModel }
            ?: activeModels?.recommended?.firstOrNull { it.id == selectedModel }
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // Header with DeepInfra icon, title, language toggle, and refresh button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.discover_tune),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = stringResource(R.string.ai_deepinfra_models_title),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Text(
                            text = "api.deepinfra.com/v1/openai/models",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Language switcher button
                    Surface(
                        onClick = { isVietnamese = !isVietnamese },
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                    ) {
                        Text(
                            text = if (isVietnamese) "🇻🇳 VI" else "🇬🇧 EN",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Ktor Live Refresh Button
                    IconButton(
                        onClick = { loadModels(true) },
                        enabled = !isLoading,
                        modifier = Modifier.size(36.dp),
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                            )
                        } else {
                            Icon(
                                painter = painterResource(R.drawable.sync),
                                contentDescription = stringResource(R.string.ai_deepinfra_refresh),
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp),
                            )
                        }
                    }
                }
            }

            // Shimmer skeleton when loading initially
            AnimatedVisibility(
                visible = isLoading && activeModels == null,
                enter = fadeIn(),
                exit = fadeOut(),
            ) {
                ModelSelectorShimmerSkeleton()
            }

            // Main Interactive Dropdown Selector
            AnimatedVisibility(
                visible = !(isLoading && activeModels == null),
                enter = fadeIn(),
                exit = fadeOut(),
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    // Horizontal category filter chips: ⭐ Ranked | 💬 Chat | 🧠 Reasoning | 🌐 All
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        val categories = listOf(
                            0 to if (isVietnamese) "⭐ Đề xuất có hạng (${activeModels?.recommended?.size ?: 0})" else "⭐ Ranked (${activeModels?.recommended?.size ?: 0})",
                            1 to if (isVietnamese) "💬 Trò chuyện & Dịch (${activeModels?.chatModels?.size ?: 0})" else "💬 Chat & Text (${activeModels?.chatModels?.size ?: 0})",
                            2 to if (isVietnamese) "🧠 Suy luận (${activeModels?.reasoningModels?.size ?: 0})" else "🧠 Reasoning (${activeModels?.reasoningModels?.size ?: 0})",
                            3 to if (isVietnamese) "🌐 Tất cả (${activeModels?.allModels?.size ?: 0})" else "🌐 All (${activeModels?.allModels?.size ?: 0})",
                        )

                        categories.forEach { (index, title) ->
                            FilterChip(
                                selected = selectedCategoryIndex == index,
                                onClick = { selectedCategoryIndex = index },
                                label = { Text(text = title, style = MaterialTheme.typography.labelSmall) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                    selectedLabelColor = MaterialTheme.colorScheme.primary,
                                ),
                                shape = RoundedCornerShape(8.dp),
                            )
                        }
                    }

                    // ExposedDropdownMenuBox for model selection
                    ExposedDropdownMenuBox(
                        expanded = dropdownExpanded,
                        onExpandedChange = { dropdownExpanded = !dropdownExpanded },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        val displayTitle = activeModelObj?.name
                            ?: selectedModel.ifBlank { DeepInfraDefaultModel }

                        OutlinedTextField(
                            value = displayTitle,
                            onValueChange = {},
                            readOnly = true,
                            label = {
                                Text(
                                    if (isVietnamese) "Mô hình DeepInfra (Ktor Real-time)"
                                    else "DeepInfra Model (Ktor Real-time)"
                                )
                            },
                            supportingText = {
                                Text(
                                    text = activeModelObj?.let { obj ->
                                        val rankText = if (obj.rank < 999) "Rank #${obj.rank} • " else ""
                                        val costText = if (obj.inputCost == 0.0) "Miễn phí / Free" else "$${obj.inputCost}/M"
                                        "$rankText${obj.id} • $costText"
                                    } ?: selectedModel.ifBlank { DeepInfraDefaultModel },
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            },
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded)
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth(),
                        )

                        ExposedDropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = {
                                dropdownExpanded = false
                                searchQuery = ""
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 420.dp),
                        ) {
                            // Search Box inside Dropdown
                            Box(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                                OutlinedTextField(
                                    value = searchQuery,
                                    onValueChange = { searchQuery = it },
                                    placeholder = {
                                        Text(
                                            if (isVietnamese) "Tìm mô hình DeepInfra..."
                                            else stringResource(R.string.ai_deepinfra_search_hint)
                                        )
                                    },
                                    leadingIcon = {
                                        Icon(
                                            painter = painterResource(R.drawable.search),
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp),
                                        )
                                    },
                                    trailingIcon = {
                                        if (searchQuery.isNotEmpty()) {
                                            IconButton(onClick = { searchQuery = "" }) {
                                                Icon(
                                                    painter = painterResource(R.drawable.close),
                                                    contentDescription = null,
                                                    modifier = Modifier.size(16.dp),
                                                )
                                            }
                                        }
                                    },
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth(),
                                )
                            }

                            HorizontalDivider()

                            if (isLoading && filteredModels.isEmpty()) {
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                            Text(
                                                text = if (isVietnamese) "Đang tải mô hình qua Ktor..." else "Loading models via Ktor...",
                                                style = MaterialTheme.typography.bodyMedium,
                                            )
                                        }
                                    },
                                    onClick = {},
                                    enabled = false,
                                )
                            } else if (filteredModels.isEmpty()) {
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = if (isVietnamese) "Không tìm thấy mô hình phù hợp" else "No matching models found",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    },
                                    onClick = {},
                                    enabled = false,
                                )
                            } else {
                                val limitedModels = filteredModels.take(15)
                                limitedModels.forEach { item ->
                                    val isSelected = item.id == selectedModel
                                    DropdownMenuItem(
                                        text = {
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 4.dp),
                                                verticalArrangement = Arrangement.spacedBy(2.dp),
                                            ) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                ) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        modifier = Modifier.weight(1f)
                                                    ) {
                                                        Text(
                                                            text = item.name,
                                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis,
                                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                                        )
                                                        if (item.providerName.isNotBlank()) {
                                                            Spacer(modifier = Modifier.width(6.dp))
                                                            Surface(
                                                                color = MaterialTheme.colorScheme.surfaceVariant,
                                                                shape = RoundedCornerShape(4.dp),
                                                            ) {
                                                                Text(
                                                                    text = item.providerName,
                                                                    style = MaterialTheme.typography.labelSmall,
                                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                                                                )
                                                            }
                                                        }
                                                    }

                                                    // Context Length badge
                                                    if (item.contextLength > 0) {
                                                        val contextK = item.contextLength / 1000
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Surface(
                                                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                                                            shape = RoundedCornerShape(6.dp),
                                                        ) {
                                                            Text(
                                                                text = "${contextK}k",
                                                                style = MaterialTheme.typography.labelSmall,
                                                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                                                            )
                                                        }
                                                    }
                                                }

                                                // Rank Badge if available
                                                if (item.rank < 999) {
                                                    val rankTitle = when (item.rank) {
                                                        1 -> if (isVietnamese) "#1 Đề xuất: Siêu tốc & Đa ngôn ngữ tối ưu" else "#1 Pick: Ultra-Fast Multilingual Inference"
                                                        2 -> if (isVietnamese) "#2 Suy luận đỉnh cao: Lý luận phức tạp" else "#2 Top Reasoning: Complex Problem Solving"
                                                        3 -> if (isVietnamese) "#3 Mã nguồn mở: Dịch thuật ngữ cảnh sâu" else "#3 Open Weights: Deep Context Translation"
                                                        4 -> if (isVietnamese) "#4 Hiệu năng cao: Phản hồi tức thì" else "#4 High Performance: Instant Response"
                                                        5 -> if (isVietnamese) "#5 Tiết kiệm & Tối ưu năng lượng" else "#5 Cost-Efficient & Lightweight"
                                                        6 -> if (isVietnamese) "#6 Lập trình & Logic âm nhạc" else "#6 Code & Music Logic Master"
                                                        else -> if (isVietnamese) "#${item.rank} Mô hình chất lượng cao" else "#${item.rank} High Quality Model"
                                                    }
                                                    Text(
                                                        text = rankTitle,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.tertiary,
                                                        fontWeight = FontWeight.SemiBold,
                                                    )
                                                }

                                                // Bilingual Description
                                                val description = if (isVietnamese && item.descriptionVi.isNotBlank()) {
                                                    item.descriptionVi
                                                } else {
                                                    item.description
                                                }
                                                if (description.isNotBlank()) {
                                                    Text(
                                                        text = description,
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        maxLines = 2,
                                                        overflow = TextOverflow.Ellipsis,
                                                    )
                                                }

                                                // Model ID
                                                Text(
                                                    text = item.id,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.outline,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                )
                                            }
                                        },
                                        leadingIcon = {
                                            Icon(
                                                painter = painterResource(
                                                    if (isSelected) R.drawable.check else R.drawable.discover_tune
                                                ),
                                                contentDescription = null,
                                                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(18.dp),
                                            )
                                        },
                                        onClick = {
                                            onModelSelected(item.id)
                                            dropdownExpanded = false
                                            searchQuery = ""
                                        },
                                    )
                                }

                                if (filteredModels.size > 15) {
                                    HorizontalDivider()
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                text = if (isVietnamese)
                                                    "🔍 Xem thêm ${filteredModels.size - 15} mô hình chuyên sâu khác..."
                                                    else "🔍 View ${filteredModels.size - 15} more models in dialog...",
                                                color = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.bodyMedium,
                                            )
                                        },
                                        leadingIcon = {
                                            Icon(
                                                painter = painterResource(R.drawable.search),
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(18.dp),
                                            )
                                        },
                                        onClick = {
                                            dropdownExpanded = false
                                            searchQuery = ""
                                            onShowAllModelsClick?.invoke()
                                        }
                                    )
                                }
                            }

                            if (onCustomModelClick != null) {
                                HorizontalDivider()
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = if (isVietnamese) "✎ Nhập Model ID tùy chỉnh..." else "✎ Enter Custom Model ID...",
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Medium,
                                        )
                                    },
                                    leadingIcon = {
                                        Icon(
                                            painter = painterResource(R.drawable.edit),
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(18.dp),
                                        )
                                    },
                                    onClick = {
                                        dropdownExpanded = false
                                        searchQuery = ""
                                        onCustomModelClick()
                                    },
                                )
                            }
                        }
                    }

                    // Status footer
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            text = if (isVietnamese) "● Ktor Real-time API" else "● Ktor Real-time API",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                        )
                        Text(
                            text = "${activeModels?.allModels?.size ?: 0} ${if (isVietnamese) "mô hình sẵn có" else "models ready"}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ModelSelectorShimmerSkeleton() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shimmer(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.7f)
                .height(28.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
        )
        Box(
            modifier = Modifier
                .fillMaxWidth(0.5f)
                .height(16.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
        )
    }
}
