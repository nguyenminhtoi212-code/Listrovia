package com.metrolist.music.ui.component

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.metrolist.music.R
import com.metrolist.music.api.DeepInfraClassifiedModels
import com.metrolist.music.api.DeepInfraModelItem
import com.metrolist.music.api.DeepInfraModelManager
import kotlinx.coroutines.launch
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DeepInfraModelDialog(
    currentModel: String,
    onDismiss: () -> Unit,
    onSelectModel: (String) -> Unit,
    onCustomInput: () -> Unit,
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val modelManager = remember { DeepInfraModelManager.getInstance(context) }

    var classifiedModels by remember { mutableStateOf<DeepInfraClassifiedModels?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var selectedTab by rememberSaveable { mutableIntStateOf(0) } // 0: Ranked, 1: Chat, 2: Reasoning, 3: All
    var searchQuery by rememberSaveable { mutableStateOf("") }

    // Bilingual toggle: Default to true if user's device is set to Vietnamese
    val isDefaultVi = remember { Locale.getDefault().language == "vi" }
    var isVietnamese by rememberSaveable { mutableStateOf(isDefaultVi) }

    fun loadModels(forceRefresh: Boolean = false) {
        coroutineScope.launch {
            isLoading = true
            try {
                classifiedModels = modelManager.fetchModels(forceRefresh = forceRefresh)
            } finally {
                isLoading = false
            }
        }
    }

    LaunchedEffect(Unit) {
        loadModels(forceRefresh = false)
    }

    val currentList: List<DeepInfraModelItem> =
        remember(classifiedModels, selectedTab, searchQuery) {
            val models = classifiedModels ?: return@remember emptyList()
            val baseList = when (selectedTab) {
                0 -> models.recommended
                1 -> models.chatModels
                2 -> models.reasoningModels
                else -> models.allModels
            }
            if (searchQuery.isBlank()) {
                baseList
            } else {
                val q = searchQuery.trim().lowercase()
                baseList.filter {
                    it.id.lowercase().contains(q) ||
                            it.name.lowercase().contains(q) ||
                            it.description.lowercase().contains(q) ||
                            it.descriptionVi.lowercase().contains(q) ||
                            it.providerName.lowercase().contains(q)
                }
            }
        }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isVietnamese) "Mô hình AI DeepInfra" else "DeepInfra AI Models",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(top = 2.dp),
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF4CAF50)),
                            )
                            Text(
                                text = if (isVietnamese) "Thời gian thực: api.deepinfra.com" else "Live: api.deepinfra.com",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Language switcher button [VN / EN]
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { isVietnamese = !isVietnamese }
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                        ) {
                            Text(
                                text = if (isVietnamese) "🇻🇳 Tiếng Việt" else "🇬🇧 English",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        IconButton(
                            onClick = { loadModels(forceRefresh = true) },
                            enabled = !isLoading,
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp,
                                )
                            } else {
                                Icon(
                                    painter = painterResource(R.drawable.sync),
                                    contentDescription = stringResource(R.string.ai_deepinfra_refresh),
                                    tint = MaterialTheme.colorScheme.primary,
                                )
                            }
                        }
                    }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .animateContentSize()
            ) {
                // Search bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            if (isVietnamese) "Tìm kiếm mô hình DeepInfra…"
                            else "Search DeepInfra models…"
                        )
                    },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.search),
                            contentDescription = null,
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    painter = painterResource(R.drawable.close),
                                    contentDescription = null,
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth(),
                )

                Spacer(modifier = Modifier.height(8.dp))

                val recCount = classifiedModels?.recommended?.size ?: 0
                val chatCount = classifiedModels?.chatModels?.size ?: 0
                val reasonCount = classifiedModels?.reasoningModels?.size ?: 0
                val allCount = classifiedModels?.allModels?.size ?: 0

                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    edgePadding = 0.dp,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Text(
                                text = if (isVietnamese) "⭐ Đề xuất ($recCount)" else "⭐ Ranked ($recCount)",
                                style = MaterialTheme.typography.labelMedium,
                            )
                        },
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Text(
                                text = if (isVietnamese) "💬 Dịch & Chat ($chatCount)" else "💬 Chat ($chatCount)",
                                style = MaterialTheme.typography.labelMedium,
                            )
                        },
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = {
                            Text(
                                text = if (isVietnamese) "🧠 Suy luận ($reasonCount)" else "🧠 Reasoning ($reasonCount)",
                                style = MaterialTheme.typography.labelMedium,
                            )
                        },
                    )
                    Tab(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        text = {
                            Text(
                                text = if (isVietnamese) "🌐 Tất cả ($allCount)" else "🌐 All ($allCount)",
                                style = MaterialTheme.typography.labelMedium,
                            )
                        },
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 380.dp),
                ) {
                    if (isLoading && classifiedModels == null) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(32.dp))
                            Text(
                                text = if (isVietnamese) "Đang đọc mô hình thời gian thực từ DeepInfra…"
                                else "Fetching real-time models from DeepInfra…",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    } else if (currentList.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 32.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = if (isVietnamese) "Không tìm thấy mô hình phù hợp" else "No matching models found",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    } else {
                        LazyColumn(modifier = Modifier.fillMaxWidth()) {
                            items(currentList, key = { it.id }) { model ->
                                val isSelected = model.id == currentModel
                                val rankTitle = model.getRankTitleByLanguage(isVietnamese)
                                val description = model.getDescriptionByLanguage(isVietnamese)

                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable { onSelectModel(model.id) }
                                        .background(
                                            if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                                            else MaterialTheme.colorScheme.surface
                                        )
                                        .padding(horizontal = 8.dp, vertical = 8.dp),
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.Top,
                                    ) {
                                        RadioButton(
                                            selected = isSelected,
                                            onClick = { onSelectModel(model.id) },
                                            modifier = Modifier.padding(top = 2.dp),
                                        )

                                        Spacer(modifier = Modifier.width(6.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            // Rank Badge if model has rank
                                            if (rankTitle.isNotBlank()) {
                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = MaterialTheme.colorScheme.primaryContainer,
                                                    modifier = Modifier.padding(bottom = 4.dp),
                                                ) {
                                                    Text(
                                                        text = rankTitle,
                                                        style = MaterialTheme.typography.labelSmall.copy(
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.Bold,
                                                        ),
                                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                    )
                                                }
                                            }

                                            // Model Name + Provider
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            ) {
                                                Text(
                                                    text = model.name,
                                                    style = MaterialTheme.typography.titleSmall,
                                                    fontWeight = FontWeight.SemiBold,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    modifier = Modifier.weight(1f, fill = false),
                                                )

                                                if (model.providerName.isNotBlank()) {
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f),
                                                    ) {
                                                        Text(
                                                            text = model.providerName,
                                                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                                                        )
                                                    }
                                                }
                                            }

                                            // Badges row: Context, Price, Reasoning
                                            FlowRow(
                                                modifier = Modifier.padding(vertical = 4.dp),
                                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                verticalArrangement = Arrangement.spacedBy(4.dp),
                                            ) {
                                                if (model.formattedContext.isNotBlank()) {
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = MaterialTheme.colorScheme.tertiaryContainer,
                                                    ) {
                                                        Text(
                                                            text = "${model.formattedContext} ctx",
                                                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                                            color = MaterialTheme.colorScheme.onTertiaryContainer,
                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                                                        )
                                                    }
                                                }

                                                if (model.pricingBadge.isNotBlank()) {
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = if (model.pricingBadge == "Free") Color(0xFFE8F5E9) else MaterialTheme.colorScheme.surfaceVariant,
                                                    ) {
                                                        Text(
                                                            text = if (model.pricingBadge == "Free") (if (isVietnamese) "Miễn phí" else "Free") else model.pricingBadge,
                                                            style = MaterialTheme.typography.labelSmall.copy(
                                                                fontSize = 9.sp,
                                                                fontWeight = FontWeight.Medium,
                                                            ),
                                                            color = if (model.pricingBadge == "Free") Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant,
                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                                                        )
                                                    }
                                                }

                                                if (model.isReasoning) {
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f),
                                                    ) {
                                                        Text(
                                                            text = if (isVietnamese) "Suy luận" else "Reasoning",
                                                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                                            color = MaterialTheme.colorScheme.onErrorContainer,
                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                                                        )
                                                    }
                                                }
                                            }

                                            // Model Description (Vietnamese or English)
                                            if (description.isNotBlank()) {
                                                Text(
                                                    text = description,
                                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, lineHeight = 15.sp),
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 3,
                                                    overflow = TextOverflow.Ellipsis,
                                                    modifier = Modifier.padding(top = 2.dp),
                                                )
                                            }

                                            // Model ID (subtle)
                                            Text(
                                                text = model.id,
                                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 9.sp),
                                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                modifier = Modifier.padding(top = 2.dp),
                                            )
                                        }
                                    }

                                    HorizontalDivider(
                                        thickness = 0.5.dp,
                                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                                        modifier = Modifier.padding(top = 8.dp),
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onCustomInput) {
                Text(if (isVietnamese) "Nhập ID tùy chỉnh" else stringResource(R.string.ai_model_custom))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (isVietnamese) "Đóng" else stringResource(android.R.string.cancel))
            }
        },
    )
}
